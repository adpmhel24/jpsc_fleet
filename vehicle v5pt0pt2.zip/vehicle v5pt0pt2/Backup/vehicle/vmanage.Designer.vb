﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vmanage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vmanage))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Button1 = New System.Windows.Forms.Button
        Me.btncanceladd = New System.Windows.Forms.Button
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.lbllastsearch = New System.Windows.Forms.Label
        Me.Label48 = New System.Windows.Forms.Label
        Me.lblselect = New System.Windows.Forms.Label
        Me.cmbcompsch = New System.Windows.Forms.ComboBox
        Me.Label33 = New System.Windows.Forms.Label
        Me.chkdeac = New System.Windows.Forms.CheckBox
        Me.btnrefresh = New System.Windows.Forms.Button
        Me.btncancelfilter = New System.Windows.Forms.Button
        Me.txtsearch = New System.Windows.Forms.TextBox
        Me.btnok = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmbtypesch = New System.Windows.Forms.ComboBox
        Me.cmbwhsesch = New System.Windows.Forms.ComboBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.btnvadd = New System.Windows.Forms.Button
        Me.btnvdeac = New System.Windows.Forms.Button
        Me.grdplate = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.lblplatebig = New System.Windows.Forms.Label
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.tab1 = New System.Windows.Forms.TabPage
        Me.grbiden = New System.Windows.Forms.GroupBox
        Me.Label58 = New System.Windows.Forms.Label
        Me.Label53 = New System.Windows.Forms.Label
        Me.cmbdriver = New System.Windows.Forms.ComboBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.txtdriver = New System.Windows.Forms.TextBox
        Me.Label32 = New System.Windows.Forms.Label
        Me.cmbcompany = New System.Windows.Forms.ComboBox
        Me.Label31 = New System.Windows.Forms.Label
        Me.cmbbody = New System.Windows.Forms.ComboBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.imgphoto = New System.Windows.Forms.PictureBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.lblid = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.cmbwhse = New System.Windows.Forms.ComboBox
        Me.cmbmake = New System.Windows.Forms.ComboBox
        Me.cmbtype = New System.Windows.Forms.ComboBox
        Me.txtsticker = New System.Windows.Forms.TextBox
        Me.txtvplate = New System.Windows.Forms.TextBox
        Me.txtplatenum = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lblprimary = New System.Windows.Forms.Label
        Me.txtchasis = New System.Windows.Forms.TextBox
        Me.txtmotor = New System.Windows.Forms.TextBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtmodel = New System.Windows.Forms.NumericUpDown
        Me.txtcolor = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txtnote = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.cmbsupplier = New System.Windows.Forms.ComboBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.btncancelupdate = New System.Windows.Forms.Button
        Me.lbldreason = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.listbox = New System.Windows.Forms.ListBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.Label57 = New System.Windows.Forms.Label
        Me.Label52 = New System.Windows.Forms.Label
        Me.txtinches = New System.Windows.Forms.TextBox
        Me.Label56 = New System.Windows.Forms.Label
        Me.txtwout = New System.Windows.Forms.TextBox
        Me.Label55 = New System.Windows.Forms.Label
        Me.txtwith = New System.Windows.Forms.TextBox
        Me.Label54 = New System.Windows.Forms.Label
        Me.txtbal = New System.Windows.Forms.TextBox
        Me.txtfull = New System.Windows.Forms.TextBox
        Me.Label51 = New System.Windows.Forms.Label
        Me.txtliter = New System.Windows.Forms.TextBox
        Me.Label50 = New System.Windows.Forms.Label
        Me.txttank = New System.Windows.Forms.TextBox
        Me.Label49 = New System.Windows.Forms.Label
        Me.btnupdategen = New System.Windows.Forms.Button
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.txtrems = New System.Windows.Forms.TextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.tab2 = New System.Windows.Forms.TabPage
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.lblexp = New System.Windows.Forms.Label
        Me.chkuse = New System.Windows.Forms.CheckBox
        Me.btnremovedoc = New System.Windows.Forms.Button
        Me.lbldocid = New System.Windows.Forms.Label
        Me.cmbinterval = New System.Windows.Forms.ComboBox
        Me.num = New System.Windows.Forms.NumericUpDown
        Me.dateexpired = New System.Windows.Forms.DateTimePicker
        Me.Label20 = New System.Windows.Forms.Label
        Me.btnadddoc = New System.Windows.Forms.Button
        Me.cmbdocname = New System.Windows.Forms.ComboBox
        Me.btnattach = New System.Windows.Forms.Button
        Me.datelastrenew = New System.Windows.Forms.DateTimePicker
        Me.txtattachname = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.grddoc = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.btncanceldoc = New System.Windows.Forms.Button
        Me.btnviewalldoc = New System.Windows.Forms.Button
        Me.btnupdatedoc = New System.Windows.Forms.Button
        Me.tab3 = New System.Windows.Forms.TabPage
        Me.GroupBox8 = New System.Windows.Forms.GroupBox
        Me.cmbpmswhse = New System.Windows.Forms.ComboBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.txtpmsrems = New System.Windows.Forms.TextBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.txtmiles = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.txtnextodo = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.btnpmsodo = New System.Windows.Forms.Button
        Me.txtlastodo = New System.Windows.Forms.TextBox
        Me.Label46 = New System.Windows.Forms.Label
        Me.lblpmsexp = New System.Windows.Forms.Label
        Me.btnpmsremove = New System.Windows.Forms.Button
        Me.lblpmsid = New System.Windows.Forms.Label
        Me.btnpmsadd = New System.Windows.Forms.Button
        Me.cmbpms = New System.Windows.Forms.ComboBox
        Me.datelastpms = New System.Windows.Forms.DateTimePicker
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label40 = New System.Windows.Forms.Label
        Me.grdpms = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.btnpmscancel = New System.Windows.Forms.Button
        Me.btnpmsview = New System.Windows.Forms.Button
        Me.btnpmsupdate = New System.Windows.Forms.Button
        Me.tab4 = New System.Windows.Forms.TabPage
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.btnimgdl = New System.Windows.Forms.Button
        Me.lblimgid = New System.Windows.Forms.Label
        Me.btnimgset = New System.Windows.Forms.Button
        Me.btnimgfull = New System.Windows.Forms.Button
        Me.btnimgupdate = New System.Windows.Forms.Button
        Me.txtimg = New System.Windows.Forms.TextBox
        Me.imgpanel = New System.Windows.Forms.Panel
        Me.imgbox = New System.Windows.Forms.PictureBox
        Me.btnimgremove = New System.Windows.Forms.Button
        Me.btnimgadd = New System.Windows.Forms.Button
        Me.btnimgcancel = New System.Windows.Forms.Button
        Me.btnimgrefresh = New System.Windows.Forms.Button
        Me.btnimgrename = New System.Windows.Forms.Button
        Me.tab5 = New System.Windows.Forms.TabPage
        Me.GroupBox10 = New System.Windows.Forms.GroupBox
        Me.linkhistory = New System.Windows.Forms.LinkLabel
        Me.lblrmid = New System.Windows.Forms.Label
        Me.txtmechanic = New System.Windows.Forms.TextBox
        Me.Label47 = New System.Windows.Forms.Label
        Me.txtothers = New System.Windows.Forms.TextBox
        Me.rbothers = New System.Windows.Forms.RadioButton
        Me.rbcheck = New System.Windows.Forms.RadioButton
        Me.btnreprefresh = New System.Windows.Forms.Button
        Me.rbrepair = New System.Windows.Forms.RadioButton
        Me.btnrepcancel = New System.Windows.Forms.Button
        Me.Label35 = New System.Windows.Forms.Label
        Me.btnrepedit = New System.Windows.Forms.Button
        Me.Label36 = New System.Windows.Forms.Label
        Me.btnrepadd = New System.Windows.Forms.Button
        Me.Label38 = New System.Windows.Forms.Label
        Me.grdrepair = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Label41 = New System.Windows.Forms.Label
        Me.datestart = New System.Windows.Forms.DateTimePicker
        Me.Label42 = New System.Windows.Forms.Label
        Me.txtdesc = New System.Windows.Forms.TextBox
        Me.Label43 = New System.Windows.Forms.Label
        Me.txtreason = New System.Windows.Forms.TextBox
        Me.Label44 = New System.Windows.Forms.Label
        Me.Label45 = New System.Windows.Forms.Label
        Me.btnrepparts = New System.Windows.Forms.Button
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        CType(Me.grdplate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.tab1.SuspendLayout()
        Me.grbiden.SuspendLayout()
        CType(Me.imgphoto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.txtmodel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.tab2.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.num, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grddoc, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab3.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        CType(Me.grdpms, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.imgbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab5.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        CType(Me.grdrepair, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 444.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(444, 671)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.btncanceladd)
        Me.Panel1.Controls.Add(Me.GroupBox9)
        Me.Panel1.Controls.Add(Me.btnvadd)
        Me.Panel1.Controls.Add(Me.btnvdeac)
        Me.Panel1.Controls.Add(Me.grdplate)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(438, 665)
        Me.Panel1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(9, 629)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 25
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'btncanceladd
        '
        Me.btncanceladd.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncanceladd.Enabled = False
        Me.btncanceladd.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncanceladd.Image = CType(resources.GetObject("btncanceladd.Image"), System.Drawing.Image)
        Me.btncanceladd.Location = New System.Drawing.Point(321, 625)
        Me.btncanceladd.Name = "btncanceladd"
        Me.btncanceladd.Size = New System.Drawing.Size(110, 30)
        Me.btncanceladd.TabIndex = 24
        Me.btncanceladd.Text = "Cancel"
        Me.btncanceladd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncanceladd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncanceladd.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox9.Controls.Add(Me.lbllastsearch)
        Me.GroupBox9.Controls.Add(Me.Label48)
        Me.GroupBox9.Controls.Add(Me.lblselect)
        Me.GroupBox9.Controls.Add(Me.cmbcompsch)
        Me.GroupBox9.Controls.Add(Me.Label33)
        Me.GroupBox9.Controls.Add(Me.chkdeac)
        Me.GroupBox9.Controls.Add(Me.btnrefresh)
        Me.GroupBox9.Controls.Add(Me.btncancelfilter)
        Me.GroupBox9.Controls.Add(Me.txtsearch)
        Me.GroupBox9.Controls.Add(Me.btnok)
        Me.GroupBox9.Controls.Add(Me.Label1)
        Me.GroupBox9.Controls.Add(Me.cmbtypesch)
        Me.GroupBox9.Controls.Add(Me.cmbwhsesch)
        Me.GroupBox9.Controls.Add(Me.Label26)
        Me.GroupBox9.Controls.Add(Me.Label25)
        Me.GroupBox9.Location = New System.Drawing.Point(5, 9)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(427, 210)
        Me.GroupBox9.TabIndex = 0
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Search"
        '
        'lbllastsearch
        '
        Me.lbllastsearch.AutoSize = True
        Me.lbllastsearch.Location = New System.Drawing.Point(5, 149)
        Me.lbllastsearch.Name = "lbllastsearch"
        Me.lbllastsearch.Size = New System.Drawing.Size(24, 15)
        Me.lbllastsearch.TabIndex = 28
        Me.lbllastsearch.Text = "sql"
        Me.lbllastsearch.Visible = False
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(4, 170)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(42, 15)
        Me.Label48.TabIndex = 27
        Me.Label48.Text = "Whse:"
        '
        'lblselect
        '
        Me.lblselect.AutoSize = True
        Me.lblselect.Location = New System.Drawing.Point(47, 170)
        Me.lblselect.Name = "lblselect"
        Me.lblselect.Size = New System.Drawing.Size(0, 15)
        Me.lblselect.TabIndex = 26
        '
        'cmbcompsch
        '
        Me.cmbcompsch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcompsch.FormattingEnabled = True
        Me.cmbcompsch.Location = New System.Drawing.Point(158, 16)
        Me.cmbcompsch.Name = "cmbcompsch"
        Me.cmbcompsch.Size = New System.Drawing.Size(215, 23)
        Me.cmbcompsch.TabIndex = 24
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(34, 19)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(118, 15)
        Me.Label33.TabIndex = 25
        Me.Label33.Text = "Assigned Company:"
        '
        'chkdeac
        '
        Me.chkdeac.AutoSize = True
        Me.chkdeac.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkdeac.ForeColor = System.Drawing.Color.OrangeRed
        Me.chkdeac.Location = New System.Drawing.Point(238, 143)
        Me.chkdeac.Name = "chkdeac"
        Me.chkdeac.Size = New System.Drawing.Size(135, 16)
        Me.chkdeac.TabIndex = 8
        Me.chkdeac.Text = "View Deactivated Vehicles"
        Me.chkdeac.UseVisualStyleBackColor = True
        '
        'btnrefresh
        '
        Me.btnrefresh.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefresh.Image = CType(resources.GetObject("btnrefresh.Image"), System.Drawing.Image)
        Me.btnrefresh.Location = New System.Drawing.Point(279, 173)
        Me.btnrefresh.Name = "btnrefresh"
        Me.btnrefresh.Size = New System.Drawing.Size(94, 23)
        Me.btnrefresh.TabIndex = 7
        Me.btnrefresh.Text = "Refresh"
        Me.btnrefresh.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefresh.UseVisualStyleBackColor = True
        '
        'btncancelfilter
        '
        Me.btncancelfilter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancelfilter.Image = CType(resources.GetObject("btncancelfilter.Image"), System.Drawing.Image)
        Me.btncancelfilter.Location = New System.Drawing.Point(341, 107)
        Me.btncancelfilter.Name = "btncancelfilter"
        Me.btncancelfilter.Size = New System.Drawing.Size(33, 23)
        Me.btncancelfilter.TabIndex = 4
        Me.btncancelfilter.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancelfilter.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancelfilter.UseVisualStyleBackColor = True
        '
        'txtsearch
        '
        Me.txtsearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtsearch.Location = New System.Drawing.Point(158, 107)
        Me.txtsearch.Name = "txtsearch"
        Me.txtsearch.Size = New System.Drawing.Size(177, 21)
        Me.txtsearch.TabIndex = 0
        '
        'btnok
        '
        Me.btnok.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnok.Image = CType(resources.GetObject("btnok.Image"), System.Drawing.Image)
        Me.btnok.Location = New System.Drawing.Point(179, 173)
        Me.btnok.Name = "btnok"
        Me.btnok.Size = New System.Drawing.Size(94, 23)
        Me.btnok.TabIndex = 3
        Me.btnok.Text = "Ok"
        Me.btnok.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnok.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnok.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(78, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 15)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Warehouse:"
        '
        'cmbtypesch
        '
        Me.cmbtypesch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbtypesch.FormattingEnabled = True
        Me.cmbtypesch.Location = New System.Drawing.Point(158, 75)
        Me.cmbtypesch.Name = "cmbtypesch"
        Me.cmbtypesch.Size = New System.Drawing.Size(215, 23)
        Me.cmbtypesch.TabIndex = 1
        '
        'cmbwhsesch
        '
        Me.cmbwhsesch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbwhsesch.FormattingEnabled = True
        Me.cmbwhsesch.Location = New System.Drawing.Point(158, 46)
        Me.cmbwhsesch.Name = "cmbwhsesch"
        Me.cmbwhsesch.Size = New System.Drawing.Size(215, 23)
        Me.cmbwhsesch.TabIndex = 2
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(75, 78)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(77, 15)
        Me.Label26.TabIndex = 23
        Me.Label26.Text = "Vehicle Type:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(66, 110)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(86, 15)
        Me.Label25.TabIndex = 20
        Me.Label25.Text = "Plate Number:"
        '
        'btnvadd
        '
        Me.btnvadd.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnvadd.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnvadd.Image = CType(resources.GetObject("btnvadd.Image"), System.Drawing.Image)
        Me.btnvadd.Location = New System.Drawing.Point(93, 625)
        Me.btnvadd.Name = "btnvadd"
        Me.btnvadd.Size = New System.Drawing.Size(110, 30)
        Me.btnvadd.TabIndex = 5
        Me.btnvadd.Text = "Add Vehicle"
        Me.btnvadd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnvadd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnvadd.UseVisualStyleBackColor = True
        '
        'btnvdeac
        '
        Me.btnvdeac.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnvdeac.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnvdeac.Image = CType(resources.GetObject("btnvdeac.Image"), System.Drawing.Image)
        Me.btnvdeac.Location = New System.Drawing.Point(205, 625)
        Me.btnvdeac.Name = "btnvdeac"
        Me.btnvdeac.Size = New System.Drawing.Size(110, 30)
        Me.btnvdeac.TabIndex = 6
        Me.btnvdeac.Text = "Deactivate"
        Me.btnvdeac.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnvdeac.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnvdeac.UseVisualStyleBackColor = True
        '
        'grdplate
        '
        Me.grdplate.AllowUserToAddRows = False
        Me.grdplate.AllowUserToDeleteRows = False
        Me.grdplate.AllowUserToResizeRows = False
        Me.grdplate.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdplate.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grdplate.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdplate.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grdplate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdplate.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.Column1, Me.Column5})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdplate.DefaultCellStyle = DataGridViewCellStyle2
        Me.grdplate.Location = New System.Drawing.Point(0, 225)
        Me.grdplate.MultiSelect = False
        Me.grdplate.Name = "grdplate"
        Me.grdplate.ReadOnly = True
        Me.grdplate.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdplate.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.grdplate.RowHeadersWidth = 10
        Me.grdplate.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdplate.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.grdplate.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdplate.Size = New System.Drawing.Size(435, 392)
        Me.grdplate.TabIndex = 1
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.HeaderText = "id"
        Me.DataGridViewTextBoxColumn13.MinimumWidth = 190
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        Me.DataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn13.Visible = False
        Me.DataGridViewTextBoxColumn13.Width = 190
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.HeaderText = "Plate Number*"
        Me.DataGridViewTextBoxColumn14.MinimumWidth = 150
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        Me.DataGridViewTextBoxColumn14.Width = 150
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.HeaderText = "Vehicle Type"
        Me.DataGridViewTextBoxColumn15.MinimumWidth = 130
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        Me.DataGridViewTextBoxColumn15.Width = 130
        '
        'Column1
        '
        Me.Column1.HeaderText = "Notifications"
        Me.Column1.MinimumWidth = 120
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 120
        '
        'Column5
        '
        Me.Column5.HeaderText = "Status"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Visible = False
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.AutoScroll = True
        Me.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.lblplatebig)
        Me.Panel2.Controls.Add(Me.TabControl1)
        Me.Panel2.Location = New System.Drawing.Point(447, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(885, 665)
        Me.Panel2.TabIndex = 1
        '
        'lblplatebig
        '
        Me.lblplatebig.BackColor = System.Drawing.Color.White
        Me.lblplatebig.Font = New System.Drawing.Font("Arial", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplatebig.Location = New System.Drawing.Point(3, 7)
        Me.lblplatebig.Name = "lblplatebig"
        Me.lblplatebig.Size = New System.Drawing.Size(876, 66)
        Me.lblplatebig.TabIndex = 1
        Me.lblplatebig.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.tab1)
        Me.TabControl1.Controls.Add(Me.tab2)
        Me.TabControl1.Controls.Add(Me.tab3)
        Me.TabControl1.Controls.Add(Me.tab4)
        Me.TabControl1.Controls.Add(Me.tab5)
        Me.TabControl1.Location = New System.Drawing.Point(3, 76)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(876, 576)
        Me.TabControl1.TabIndex = 0
        '
        'tab1
        '
        Me.tab1.Controls.Add(Me.grbiden)
        Me.tab1.Controls.Add(Me.GroupBox1)
        Me.tab1.Controls.Add(Me.GroupBox2)
        Me.tab1.Controls.Add(Me.btncancelupdate)
        Me.tab1.Controls.Add(Me.lbldreason)
        Me.tab1.Controls.Add(Me.GroupBox3)
        Me.tab1.Controls.Add(Me.GroupBox4)
        Me.tab1.Controls.Add(Me.btnupdategen)
        Me.tab1.Controls.Add(Me.GroupBox7)
        Me.tab1.Controls.Add(Me.Label29)
        Me.tab1.Controls.Add(Me.Label27)
        Me.tab1.Location = New System.Drawing.Point(4, 22)
        Me.tab1.Name = "tab1"
        Me.tab1.Padding = New System.Windows.Forms.Padding(3)
        Me.tab1.Size = New System.Drawing.Size(868, 550)
        Me.tab1.TabIndex = 0
        Me.tab1.Text = "General"
        Me.tab1.UseVisualStyleBackColor = True
        '
        'grbiden
        '
        Me.grbiden.Controls.Add(Me.Label58)
        Me.grbiden.Controls.Add(Me.Label53)
        Me.grbiden.Controls.Add(Me.cmbdriver)
        Me.grbiden.Controls.Add(Me.Label34)
        Me.grbiden.Controls.Add(Me.txtdriver)
        Me.grbiden.Controls.Add(Me.Label32)
        Me.grbiden.Controls.Add(Me.cmbcompany)
        Me.grbiden.Controls.Add(Me.Label31)
        Me.grbiden.Controls.Add(Me.cmbbody)
        Me.grbiden.Controls.Add(Me.Label12)
        Me.grbiden.Controls.Add(Me.Label23)
        Me.grbiden.Controls.Add(Me.Label19)
        Me.grbiden.Controls.Add(Me.imgphoto)
        Me.grbiden.Controls.Add(Me.Label9)
        Me.grbiden.Controls.Add(Me.lblid)
        Me.grbiden.Controls.Add(Me.Label22)
        Me.grbiden.Controls.Add(Me.cmbwhse)
        Me.grbiden.Controls.Add(Me.cmbmake)
        Me.grbiden.Controls.Add(Me.cmbtype)
        Me.grbiden.Controls.Add(Me.txtsticker)
        Me.grbiden.Controls.Add(Me.txtvplate)
        Me.grbiden.Controls.Add(Me.txtplatenum)
        Me.grbiden.Controls.Add(Me.Label10)
        Me.grbiden.Controls.Add(Me.Label7)
        Me.grbiden.Controls.Add(Me.Label5)
        Me.grbiden.Controls.Add(Me.Label4)
        Me.grbiden.Controls.Add(Me.Label3)
        Me.grbiden.Controls.Add(Me.Label2)
        Me.grbiden.Location = New System.Drawing.Point(10, 6)
        Me.grbiden.Name = "grbiden"
        Me.grbiden.Size = New System.Drawing.Size(487, 305)
        Me.grbiden.TabIndex = 2
        Me.grbiden.TabStop = False
        Me.grbiden.Text = "Identification"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.ForeColor = System.Drawing.Color.Red
        Me.Label58.Location = New System.Drawing.Point(419, 155)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(18, 16)
        Me.Label58.TabIndex = 42
        Me.Label58.Text = "**"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(355, 15)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(38, 13)
        Me.Label53.TabIndex = 31
        Me.Label53.Text = "Photo:"
        Me.Label53.Visible = False
        '
        'cmbdriver
        '
        Me.cmbdriver.FormattingEnabled = True
        Me.cmbdriver.Location = New System.Drawing.Point(141, 270)
        Me.cmbdriver.Name = "cmbdriver"
        Me.cmbdriver.Size = New System.Drawing.Size(223, 21)
        Me.cmbdriver.TabIndex = 41
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Red
        Me.Label34.Location = New System.Drawing.Point(370, 241)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(18, 16)
        Me.Label34.TabIndex = 40
        Me.Label34.Text = "**"
        '
        'txtdriver
        '
        Me.txtdriver.Location = New System.Drawing.Point(370, 273)
        Me.txtdriver.Name = "txtdriver"
        Me.txtdriver.Size = New System.Drawing.Size(40, 20)
        Me.txtdriver.TabIndex = 18
        Me.txtdriver.Visible = False
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(25, 273)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(38, 13)
        Me.Label32.TabIndex = 39
        Me.Label32.Text = "Driver:"
        '
        'cmbcompany
        '
        Me.cmbcompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcompany.FormattingEnabled = True
        Me.cmbcompany.Location = New System.Drawing.Point(141, 241)
        Me.cmbcompany.Name = "cmbcompany"
        Me.cmbcompany.Size = New System.Drawing.Size(223, 21)
        Me.cmbcompany.TabIndex = 17
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(25, 244)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(54, 13)
        Me.Label31.TabIndex = 37
        Me.Label31.Text = "Company:"
        '
        'cmbbody
        '
        Me.cmbbody.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbbody.FormattingEnabled = True
        Me.cmbbody.Location = New System.Drawing.Point(141, 183)
        Me.cmbbody.Name = "cmbbody"
        Me.cmbbody.Size = New System.Drawing.Size(272, 21)
        Me.cmbbody.TabIndex = 15
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(25, 186)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(61, 13)
        Me.Label12.TabIndex = 35
        Me.Label12.Text = "Body Type:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Red
        Me.Label23.Location = New System.Drawing.Point(339, 212)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(18, 16)
        Me.Label23.TabIndex = 33
        Me.Label23.Text = "**"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Red
        Me.Label19.Location = New System.Drawing.Point(339, 125)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(18, 16)
        Me.Label19.TabIndex = 32
        Me.Label19.Text = "**"
        '
        'imgphoto
        '
        Me.imgphoto.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.imgphoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgphoto.Location = New System.Drawing.Point(358, 34)
        Me.imgphoto.Name = "imgphoto"
        Me.imgphoto.Size = New System.Drawing.Size(123, 80)
        Me.imgphoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgphoto.TabIndex = 0
        Me.imgphoto.TabStop = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Red
        Me.Label9.Location = New System.Drawing.Point(339, 46)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(18, 16)
        Me.Label9.TabIndex = 29
        Me.Label9.Text = "**"
        '
        'lblid
        '
        Me.lblid.AutoSize = True
        Me.lblid.Location = New System.Drawing.Point(140, 23)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(0, 13)
        Me.lblid.TabIndex = 8
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(25, 23)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(58, 13)
        Me.Label22.TabIndex = 28
        Me.Label22.Text = "Entry ID #:"
        '
        'cmbwhse
        '
        Me.cmbwhse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbwhse.FormattingEnabled = True
        Me.cmbwhse.Location = New System.Drawing.Point(141, 212)
        Me.cmbwhse.Name = "cmbwhse"
        Me.cmbwhse.Size = New System.Drawing.Size(192, 21)
        Me.cmbwhse.TabIndex = 16
        '
        'cmbmake
        '
        Me.cmbmake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbmake.FormattingEnabled = True
        Me.cmbmake.Location = New System.Drawing.Point(141, 154)
        Me.cmbmake.Name = "cmbmake"
        Me.cmbmake.Size = New System.Drawing.Size(272, 21)
        Me.cmbmake.TabIndex = 14
        '
        'cmbtype
        '
        Me.cmbtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbtype.FormattingEnabled = True
        Me.cmbtype.Location = New System.Drawing.Point(141, 125)
        Me.cmbtype.Name = "cmbtype"
        Me.cmbtype.Size = New System.Drawing.Size(192, 21)
        Me.cmbtype.TabIndex = 12
        '
        'txtsticker
        '
        Me.txtsticker.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtsticker.Location = New System.Drawing.Point(141, 98)
        Me.txtsticker.Name = "txtsticker"
        Me.txtsticker.Size = New System.Drawing.Size(192, 20)
        Me.txtsticker.TabIndex = 11
        '
        'txtvplate
        '
        Me.txtvplate.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtvplate.Location = New System.Drawing.Point(141, 71)
        Me.txtvplate.Name = "txtvplate"
        Me.txtvplate.Size = New System.Drawing.Size(192, 20)
        Me.txtvplate.TabIndex = 10
        '
        'txtplatenum
        '
        Me.txtplatenum.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtplatenum.Location = New System.Drawing.Point(141, 44)
        Me.txtplatenum.Name = "txtplatenum"
        Me.txtplatenum.Size = New System.Drawing.Size(192, 20)
        Me.txtplatenum.TabIndex = 9
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(25, 215)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(65, 13)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Warehouse:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(25, 157)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(37, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Make:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(25, 74)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 13)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Virtual Plate:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(25, 101)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 13)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Conduction Sticker:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(25, 129)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Vehicle Type:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 13)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Plate Number:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.lblprimary)
        Me.GroupBox1.Controls.Add(Me.txtchasis)
        Me.GroupBox1.Controls.Add(Me.txtmotor)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtmodel)
        Me.GroupBox1.Controls.Add(Me.txtcolor)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Location = New System.Drawing.Point(511, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(340, 129)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Other Details"
        '
        'lblprimary
        '
        Me.lblprimary.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblprimary.AutoSize = True
        Me.lblprimary.Location = New System.Drawing.Point(73, 103)
        Me.lblprimary.Name = "lblprimary"
        Me.lblprimary.Size = New System.Drawing.Size(31, 13)
        Me.lblprimary.TabIndex = 37
        Me.lblprimary.Text = "imgid"
        Me.lblprimary.Visible = False
        '
        'txtchasis
        '
        Me.txtchasis.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtchasis.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtchasis.Location = New System.Drawing.Point(140, 73)
        Me.txtchasis.Name = "txtchasis"
        Me.txtchasis.Size = New System.Drawing.Size(184, 20)
        Me.txtchasis.TabIndex = 23
        '
        'txtmotor
        '
        Me.txtmotor.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtmotor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtmotor.Location = New System.Drawing.Point(140, 46)
        Me.txtmotor.Name = "txtmotor"
        Me.txtmotor.Size = New System.Drawing.Size(184, 20)
        Me.txtmotor.TabIndex = 22
        '
        'Label30
        '
        Me.Label30.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(24, 76)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(61, 13)
        Me.Label30.TabIndex = 18
        Me.Label30.Text = "Chasis No.:"
        '
        'Label21
        '
        Me.Label21.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(24, 49)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(57, 13)
        Me.Label21.TabIndex = 17
        Me.Label21.Text = "Motor No.:"
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(24, 21)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 13)
        Me.Label6.TabIndex = 16
        Me.Label6.Text = "Year Model:"
        '
        'txtmodel
        '
        Me.txtmodel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtmodel.Location = New System.Drawing.Point(140, 19)
        Me.txtmodel.Maximum = New Decimal(New Integer() {2016, 0, 0, 0})
        Me.txtmodel.Minimum = New Decimal(New Integer() {1970, 0, 0, 0})
        Me.txtmodel.Name = "txtmodel"
        Me.txtmodel.Size = New System.Drawing.Size(120, 20)
        Me.txtmodel.TabIndex = 21
        Me.txtmodel.Value = New Decimal(New Integer() {1988, 0, 0, 0})
        '
        'txtcolor
        '
        Me.txtcolor.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtcolor.Location = New System.Drawing.Point(140, 100)
        Me.txtcolor.Name = "txtcolor"
        Me.txtcolor.Size = New System.Drawing.Size(184, 20)
        Me.txtcolor.TabIndex = 24
        '
        'Label8
        '
        Me.Label8.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(24, 103)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(37, 13)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Color;:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.txtnote)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.cmbsupplier)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Location = New System.Drawing.Point(10, 317)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(487, 77)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Purchase"
        '
        'txtnote
        '
        Me.txtnote.Location = New System.Drawing.Point(141, 45)
        Me.txtnote.Name = "txtnote"
        Me.txtnote.Size = New System.Drawing.Size(315, 20)
        Me.txtnote.TabIndex = 20
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(25, 48)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(33, 13)
        Me.Label13.TabIndex = 31
        Me.Label13.Text = "Note:"
        '
        'cmbsupplier
        '
        Me.cmbsupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbsupplier.FormattingEnabled = True
        Me.cmbsupplier.Location = New System.Drawing.Point(141, 16)
        Me.cmbsupplier.Name = "cmbsupplier"
        Me.cmbsupplier.Size = New System.Drawing.Size(315, 21)
        Me.cmbsupplier.TabIndex = 19
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(25, 24)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(48, 13)
        Me.Label11.TabIndex = 28
        Me.Label11.Text = "Supplier:"
        '
        'btncancelupdate
        '
        Me.btncancelupdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncancelupdate.Enabled = False
        Me.btncancelupdate.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancelupdate.Image = CType(resources.GetObject("btncancelupdate.Image"), System.Drawing.Image)
        Me.btncancelupdate.Location = New System.Drawing.Point(750, 502)
        Me.btncancelupdate.Name = "btncancelupdate"
        Me.btncancelupdate.Size = New System.Drawing.Size(90, 30)
        Me.btncancelupdate.TabIndex = 25
        Me.btncancelupdate.Text = "Cancel"
        Me.btncancelupdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancelupdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancelupdate.UseVisualStyleBackColor = True
        '
        'lbldreason
        '
        Me.lbldreason.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lbldreason.AutoSize = True
        Me.lbldreason.ForeColor = System.Drawing.Color.Red
        Me.lbldreason.Location = New System.Drawing.Point(171, 517)
        Me.lbldreason.Name = "lbldreason"
        Me.lbldreason.Size = New System.Drawing.Size(45, 13)
        Me.lbldreason.TabIndex = 36
        Me.lbldreason.Text = "dreason"
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.Controls.Add(Me.listbox)
        Me.GroupBox3.Location = New System.Drawing.Point(10, 400)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(487, 99)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Notifications"
        '
        'listbox
        '
        Me.listbox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.listbox.FormattingEnabled = True
        Me.listbox.Location = New System.Drawing.Point(28, 19)
        Me.listbox.Name = "listbox"
        Me.listbox.Size = New System.Drawing.Size(428, 56)
        Me.listbox.Sorted = True
        Me.listbox.TabIndex = 25
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.Controls.Add(Me.Label57)
        Me.GroupBox4.Controls.Add(Me.Label52)
        Me.GroupBox4.Controls.Add(Me.txtinches)
        Me.GroupBox4.Controls.Add(Me.Label56)
        Me.GroupBox4.Controls.Add(Me.txtwout)
        Me.GroupBox4.Controls.Add(Me.Label55)
        Me.GroupBox4.Controls.Add(Me.txtwith)
        Me.GroupBox4.Controls.Add(Me.Label54)
        Me.GroupBox4.Controls.Add(Me.txtbal)
        Me.GroupBox4.Controls.Add(Me.txtfull)
        Me.GroupBox4.Controls.Add(Me.Label51)
        Me.GroupBox4.Controls.Add(Me.txtliter)
        Me.GroupBox4.Controls.Add(Me.Label50)
        Me.GroupBox4.Controls.Add(Me.txttank)
        Me.GroupBox4.Controls.Add(Me.Label49)
        Me.GroupBox4.Location = New System.Drawing.Point(511, 141)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(340, 223)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Diesel Parameters"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(279, 138)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(32, 13)
        Me.Label57.TabIndex = 38
        Me.Label57.Text = "Liters"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(279, 110)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(39, 13)
        Me.Label52.TabIndex = 37
        Me.Label52.Text = "Inches"
        '
        'txtinches
        '
        Me.txtinches.BackColor = System.Drawing.Color.White
        Me.txtinches.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtinches.Location = New System.Drawing.Point(140, 107)
        Me.txtinches.Name = "txtinches"
        Me.txtinches.ReadOnly = True
        Me.txtinches.Size = New System.Drawing.Size(133, 20)
        Me.txtinches.TabIndex = 27
        Me.txtinches.Text = "0.00"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(24, 110)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(106, 13)
        Me.Label56.TabIndex = 35
        Me.Label56.Text = "Maintaining Balance:"
        '
        'txtwout
        '
        Me.txtwout.BackColor = System.Drawing.Color.White
        Me.txtwout.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtwout.Location = New System.Drawing.Point(140, 191)
        Me.txtwout.Name = "txtwout"
        Me.txtwout.ReadOnly = True
        Me.txtwout.Size = New System.Drawing.Size(184, 20)
        Me.txtwout.TabIndex = 30
        Me.txtwout.Text = "0.00"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(24, 194)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(110, 13)
        Me.Label55.TabIndex = 33
        Me.Label55.Text = "Parameter W/o Load:"
        '
        'txtwith
        '
        Me.txtwith.BackColor = System.Drawing.Color.White
        Me.txtwith.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtwith.Location = New System.Drawing.Point(140, 163)
        Me.txtwith.Name = "txtwith"
        Me.txtwith.ReadOnly = True
        Me.txtwith.Size = New System.Drawing.Size(184, 20)
        Me.txtwith.TabIndex = 29
        Me.txtwith.Text = "0.00"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(24, 166)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(104, 13)
        Me.Label54.TabIndex = 31
        Me.Label54.Text = "Parameter W/ Load:"
        '
        'txtbal
        '
        Me.txtbal.BackColor = System.Drawing.Color.White
        Me.txtbal.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtbal.Location = New System.Drawing.Point(140, 135)
        Me.txtbal.Name = "txtbal"
        Me.txtbal.ReadOnly = True
        Me.txtbal.Size = New System.Drawing.Size(133, 20)
        Me.txtbal.TabIndex = 28
        Me.txtbal.Text = "0.00"
        '
        'txtfull
        '
        Me.txtfull.BackColor = System.Drawing.Color.White
        Me.txtfull.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtfull.Location = New System.Drawing.Point(140, 50)
        Me.txtfull.Name = "txtfull"
        Me.txtfull.ReadOnly = True
        Me.txtfull.Size = New System.Drawing.Size(184, 20)
        Me.txtfull.TabIndex = 25
        Me.txtfull.Text = "0"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(24, 53)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(54, 13)
        Me.Label51.TabIndex = 27
        Me.Label51.Text = "Full Tank:"
        '
        'txtliter
        '
        Me.txtliter.BackColor = System.Drawing.Color.White
        Me.txtliter.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtliter.Location = New System.Drawing.Point(140, 78)
        Me.txtliter.Name = "txtliter"
        Me.txtliter.ReadOnly = True
        Me.txtliter.Size = New System.Drawing.Size(184, 20)
        Me.txtliter.TabIndex = 26
        Me.txtliter.Text = "0.00"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(24, 81)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(72, 13)
        Me.Label50.TabIndex = 25
        Me.Label50.Text = "Liter per Inch:"
        '
        'txttank
        '
        Me.txttank.BackColor = System.Drawing.Color.White
        Me.txttank.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txttank.Location = New System.Drawing.Point(140, 23)
        Me.txttank.Name = "txttank"
        Me.txttank.ReadOnly = True
        Me.txttank.Size = New System.Drawing.Size(184, 20)
        Me.txttank.TabIndex = 24
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(24, 26)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(58, 13)
        Me.Label49.TabIndex = 23
        Me.Label49.Text = "Tank Size:"
        '
        'btnupdategen
        '
        Me.btnupdategen.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnupdategen.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdategen.Image = CType(resources.GetObject("btnupdategen.Image"), System.Drawing.Image)
        Me.btnupdategen.Location = New System.Drawing.Point(652, 502)
        Me.btnupdategen.Name = "btnupdategen"
        Me.btnupdategen.Size = New System.Drawing.Size(90, 30)
        Me.btnupdategen.TabIndex = 27
        Me.btnupdategen.Text = "Update"
        Me.btnupdategen.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnupdategen.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnupdategen.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox7.Controls.Add(Me.txtrems)
        Me.GroupBox7.Location = New System.Drawing.Point(511, 370)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(340, 116)
        Me.GroupBox7.TabIndex = 7
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Remarks"
        '
        'txtrems
        '
        Me.txtrems.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtrems.Location = New System.Drawing.Point(27, 24)
        Me.txtrems.Multiline = True
        Me.txtrems.Name = "txtrems"
        Me.txtrems.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtrems.Size = New System.Drawing.Size(297, 86)
        Me.txtrems.TabIndex = 26
        '
        'Label29
        '
        Me.Label29.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(35, 517)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(80, 14)
        Me.Label29.TabIndex = 35
        Me.Label29.Text = "- Reqiured field"
        '
        'Label27
        '
        Me.Label27.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.Red
        Me.Label27.Location = New System.Drawing.Point(20, 518)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(18, 16)
        Me.Label27.TabIndex = 34
        Me.Label27.Text = "**"
        '
        'tab2
        '
        Me.tab2.Controls.Add(Me.GroupBox6)
        Me.tab2.Location = New System.Drawing.Point(4, 22)
        Me.tab2.Name = "tab2"
        Me.tab2.Size = New System.Drawing.Size(868, 550)
        Me.tab2.TabIndex = 2
        Me.tab2.Text = "Documents"
        Me.tab2.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox6.Controls.Add(Me.lblexp)
        Me.GroupBox6.Controls.Add(Me.chkuse)
        Me.GroupBox6.Controls.Add(Me.btnremovedoc)
        Me.GroupBox6.Controls.Add(Me.lbldocid)
        Me.GroupBox6.Controls.Add(Me.cmbinterval)
        Me.GroupBox6.Controls.Add(Me.num)
        Me.GroupBox6.Controls.Add(Me.dateexpired)
        Me.GroupBox6.Controls.Add(Me.Label20)
        Me.GroupBox6.Controls.Add(Me.btnadddoc)
        Me.GroupBox6.Controls.Add(Me.cmbdocname)
        Me.GroupBox6.Controls.Add(Me.btnattach)
        Me.GroupBox6.Controls.Add(Me.datelastrenew)
        Me.GroupBox6.Controls.Add(Me.txtattachname)
        Me.GroupBox6.Controls.Add(Me.Label17)
        Me.GroupBox6.Controls.Add(Me.Label16)
        Me.GroupBox6.Controls.Add(Me.Label15)
        Me.GroupBox6.Controls.Add(Me.grddoc)
        Me.GroupBox6.Controls.Add(Me.btncanceldoc)
        Me.GroupBox6.Controls.Add(Me.btnviewalldoc)
        Me.GroupBox6.Controls.Add(Me.btnupdatedoc)
        Me.GroupBox6.Location = New System.Drawing.Point(19, 15)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(798, 529)
        Me.GroupBox6.TabIndex = 7
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Manage Document Expiration"
        '
        'lblexp
        '
        Me.lblexp.AutoSize = True
        Me.lblexp.Location = New System.Drawing.Point(438, 17)
        Me.lblexp.Name = "lblexp"
        Me.lblexp.Size = New System.Drawing.Size(24, 13)
        Me.lblexp.TabIndex = 40
        Me.lblexp.Text = "exp"
        Me.lblexp.Visible = False
        '
        'chkuse
        '
        Me.chkuse.AutoSize = True
        Me.chkuse.Checked = True
        Me.chkuse.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkuse.Location = New System.Drawing.Point(58, 95)
        Me.chkuse.Name = "chkuse"
        Me.chkuse.Size = New System.Drawing.Size(128, 17)
        Me.chkuse.TabIndex = 39
        Me.chkuse.Text = "Use Tracking Interval"
        Me.chkuse.UseVisualStyleBackColor = True
        '
        'btnremovedoc
        '
        Me.btnremovedoc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnremovedoc.Image = CType(resources.GetObject("btnremovedoc.Image"), System.Drawing.Image)
        Me.btnremovedoc.Location = New System.Drawing.Point(365, 179)
        Me.btnremovedoc.Name = "btnremovedoc"
        Me.btnremovedoc.Size = New System.Drawing.Size(101, 30)
        Me.btnremovedoc.TabIndex = 35
        Me.btnremovedoc.Text = "Remove"
        Me.btnremovedoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnremovedoc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnremovedoc.UseVisualStyleBackColor = True
        '
        'lbldocid
        '
        Me.lbldocid.AutoSize = True
        Me.lbldocid.Location = New System.Drawing.Point(219, 18)
        Me.lbldocid.Name = "lbldocid"
        Me.lbldocid.Size = New System.Drawing.Size(35, 13)
        Me.lbldocid.TabIndex = 38
        Me.lbldocid.Text = "Docid"
        Me.lbldocid.Visible = False
        '
        'cmbinterval
        '
        Me.cmbinterval.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbinterval.Enabled = False
        Me.cmbinterval.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmbinterval.FormattingEnabled = True
        Me.cmbinterval.Items.AddRange(New Object() {"", "Year(s)", "Month(s)", "Day(s)"})
        Me.cmbinterval.Location = New System.Drawing.Point(282, 91)
        Me.cmbinterval.Name = "cmbinterval"
        Me.cmbinterval.Size = New System.Drawing.Size(123, 21)
        Me.cmbinterval.TabIndex = 28
        '
        'num
        '
        Me.num.Enabled = False
        Me.num.Location = New System.Drawing.Point(222, 92)
        Me.num.Maximum = New Decimal(New Integer() {31, 0, 0, 0})
        Me.num.Name = "num"
        Me.num.Size = New System.Drawing.Size(54, 20)
        Me.num.TabIndex = 27
        '
        'dateexpired
        '
        Me.dateexpired.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dateexpired.Location = New System.Drawing.Point(222, 119)
        Me.dateexpired.Name = "dateexpired"
        Me.dateexpired.Size = New System.Drawing.Size(218, 20)
        Me.dateexpired.TabIndex = 29
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(55, 124)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(82, 13)
        Me.Label20.TabIndex = 26
        Me.Label20.Text = "Expiration Date:"
        '
        'btnadddoc
        '
        Me.btnadddoc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadddoc.Image = CType(resources.GetObject("btnadddoc.Image"), System.Drawing.Image)
        Me.btnadddoc.Location = New System.Drawing.Point(58, 179)
        Me.btnadddoc.Name = "btnadddoc"
        Me.btnadddoc.Size = New System.Drawing.Size(94, 30)
        Me.btnadddoc.TabIndex = 33
        Me.btnadddoc.Text = "Add"
        Me.btnadddoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnadddoc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnadddoc.UseVisualStyleBackColor = True
        '
        'cmbdocname
        '
        Me.cmbdocname.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbdocname.FormattingEnabled = True
        Me.cmbdocname.Location = New System.Drawing.Point(222, 36)
        Me.cmbdocname.Name = "cmbdocname"
        Me.cmbdocname.Size = New System.Drawing.Size(268, 21)
        Me.cmbdocname.TabIndex = 25
        '
        'btnattach
        '
        Me.btnattach.Location = New System.Drawing.Point(480, 145)
        Me.btnattach.Name = "btnattach"
        Me.btnattach.Size = New System.Drawing.Size(25, 23)
        Me.btnattach.TabIndex = 31
        Me.btnattach.Text = "..."
        Me.btnattach.UseVisualStyleBackColor = True
        Me.btnattach.Visible = False
        '
        'datelastrenew
        '
        Me.datelastrenew.CustomFormat = ""
        Me.datelastrenew.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datelastrenew.Location = New System.Drawing.Point(222, 65)
        Me.datelastrenew.Name = "datelastrenew"
        Me.datelastrenew.Size = New System.Drawing.Size(218, 20)
        Me.datelastrenew.TabIndex = 26
        '
        'txtattachname
        '
        Me.txtattachname.Location = New System.Drawing.Point(222, 146)
        Me.txtattachname.Name = "txtattachname"
        Me.txtattachname.Size = New System.Drawing.Size(244, 20)
        Me.txtattachname.TabIndex = 30
        Me.txtattachname.Visible = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(55, 153)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(60, 13)
        Me.Label17.TabIndex = 18
        Me.Label17.Text = "Attach File:"
        Me.Label17.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(55, 70)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(101, 13)
        Me.Label16.TabIndex = 17
        Me.Label16.Text = "Last Renewal Date:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(55, 44)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(90, 13)
        Me.Label15.TabIndex = 16
        Me.Label15.Text = "Document Name:"
        '
        'grddoc
        '
        Me.grddoc.AllowUserToAddRows = False
        Me.grddoc.AllowUserToDeleteRows = False
        Me.grddoc.AllowUserToResizeRows = False
        Me.grddoc.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grddoc.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grddoc.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddoc.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.grddoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grddoc.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.Column4, Me.Column3, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.Column2})
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.NullValue = Nothing
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddoc.DefaultCellStyle = DataGridViewCellStyle6
        Me.grddoc.Location = New System.Drawing.Point(11, 223)
        Me.grddoc.MultiSelect = False
        Me.grddoc.Name = "grddoc"
        Me.grddoc.ReadOnly = True
        Me.grddoc.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddoc.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.grddoc.RowHeadersWidth = 10
        Me.grddoc.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddoc.RowsDefaultCellStyle = DataGridViewCellStyle8
        Me.grddoc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grddoc.Size = New System.Drawing.Size(776, 288)
        Me.grddoc.TabIndex = 38
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "id"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 190
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn1.Visible = False
        Me.DataGridViewTextBoxColumn1.Width = 190
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Document Name"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 200
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 200
        '
        'Column4
        '
        Me.Column4.HeaderText = "Last Renewal Date"
        Me.Column4.MinimumWidth = 160
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Width = 160
        '
        'Column3
        '
        Me.Column3.HeaderText = "Tracking Interval"
        Me.Column3.MinimumWidth = 140
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 140
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "Expiration Date"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 140
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn3.Width = 140
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "Status"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Width = 120
        '
        'Column2
        '
        Me.Column2.HeaderText = "Attachment"
        Me.Column2.MinimumWidth = 150
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Visible = False
        Me.Column2.Width = 150
        '
        'btncanceldoc
        '
        Me.btncanceldoc.Enabled = False
        Me.btncanceldoc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncanceldoc.Image = CType(resources.GetObject("btncanceldoc.Image"), System.Drawing.Image)
        Me.btncanceldoc.Location = New System.Drawing.Point(265, 179)
        Me.btncanceldoc.Name = "btncanceldoc"
        Me.btncanceldoc.Size = New System.Drawing.Size(94, 30)
        Me.btncanceldoc.TabIndex = 36
        Me.btncanceldoc.Text = "Cancel"
        Me.btncanceldoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncanceldoc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncanceldoc.UseVisualStyleBackColor = True
        '
        'btnviewalldoc
        '
        Me.btnviewalldoc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnviewalldoc.Image = CType(resources.GetObject("btnviewalldoc.Image"), System.Drawing.Image)
        Me.btnviewalldoc.Location = New System.Drawing.Point(472, 179)
        Me.btnviewalldoc.Name = "btnviewalldoc"
        Me.btnviewalldoc.Size = New System.Drawing.Size(94, 30)
        Me.btnviewalldoc.TabIndex = 37
        Me.btnviewalldoc.Text = "View All"
        Me.btnviewalldoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnviewalldoc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnviewalldoc.UseVisualStyleBackColor = True
        '
        'btnupdatedoc
        '
        Me.btnupdatedoc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdatedoc.Image = CType(resources.GetObject("btnupdatedoc.Image"), System.Drawing.Image)
        Me.btnupdatedoc.Location = New System.Drawing.Point(158, 179)
        Me.btnupdatedoc.Name = "btnupdatedoc"
        Me.btnupdatedoc.Size = New System.Drawing.Size(101, 30)
        Me.btnupdatedoc.TabIndex = 34
        Me.btnupdatedoc.Text = "Update"
        Me.btnupdatedoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnupdatedoc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnupdatedoc.UseVisualStyleBackColor = True
        '
        'tab3
        '
        Me.tab3.Controls.Add(Me.GroupBox8)
        Me.tab3.Location = New System.Drawing.Point(4, 22)
        Me.tab3.Name = "tab3"
        Me.tab3.Size = New System.Drawing.Size(868, 550)
        Me.tab3.TabIndex = 5
        Me.tab3.Text = "PM Service"
        Me.tab3.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox8.Controls.Add(Me.cmbpmswhse)
        Me.GroupBox8.Controls.Add(Me.Label28)
        Me.GroupBox8.Controls.Add(Me.txtpmsrems)
        Me.GroupBox8.Controls.Add(Me.Label24)
        Me.GroupBox8.Controls.Add(Me.txtmiles)
        Me.GroupBox8.Controls.Add(Me.Label18)
        Me.GroupBox8.Controls.Add(Me.txtnextodo)
        Me.GroupBox8.Controls.Add(Me.Label14)
        Me.GroupBox8.Controls.Add(Me.btnpmsodo)
        Me.GroupBox8.Controls.Add(Me.txtlastodo)
        Me.GroupBox8.Controls.Add(Me.Label46)
        Me.GroupBox8.Controls.Add(Me.lblpmsexp)
        Me.GroupBox8.Controls.Add(Me.btnpmsremove)
        Me.GroupBox8.Controls.Add(Me.lblpmsid)
        Me.GroupBox8.Controls.Add(Me.btnpmsadd)
        Me.GroupBox8.Controls.Add(Me.cmbpms)
        Me.GroupBox8.Controls.Add(Me.datelastpms)
        Me.GroupBox8.Controls.Add(Me.Label39)
        Me.GroupBox8.Controls.Add(Me.Label40)
        Me.GroupBox8.Controls.Add(Me.grdpms)
        Me.GroupBox8.Controls.Add(Me.btnpmscancel)
        Me.GroupBox8.Controls.Add(Me.btnpmsview)
        Me.GroupBox8.Controls.Add(Me.btnpmsupdate)
        Me.GroupBox8.Location = New System.Drawing.Point(19, 15)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(818, 527)
        Me.GroupBox8.TabIndex = 17
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Preventive Maintenance Service"
        '
        'cmbpmswhse
        '
        Me.cmbpmswhse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbpmswhse.FormattingEnabled = True
        Me.cmbpmswhse.Location = New System.Drawing.Point(222, 90)
        Me.cmbpmswhse.Name = "cmbpmswhse"
        Me.cmbpmswhse.Size = New System.Drawing.Size(268, 21)
        Me.cmbpmswhse.TabIndex = 69
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(55, 94)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(94, 13)
        Me.Label28.TabIndex = 68
        Me.Label28.Text = "Last Performed At:"
        '
        'txtpmsrems
        '
        Me.txtpmsrems.Location = New System.Drawing.Point(554, 65)
        Me.txtpmsrems.Multiline = True
        Me.txtpmsrems.Name = "txtpmsrems"
        Me.txtpmsrems.Size = New System.Drawing.Size(231, 132)
        Me.txtpmsrems.TabIndex = 66
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(551, 44)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(52, 13)
        Me.Label24.TabIndex = 67
        Me.Label24.Text = "Remarks:"
        '
        'txtmiles
        '
        Me.txtmiles.Location = New System.Drawing.Point(222, 63)
        Me.txtmiles.Name = "txtmiles"
        Me.txtmiles.Size = New System.Drawing.Size(268, 20)
        Me.txtmiles.TabIndex = 65
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(55, 68)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(85, 13)
        Me.Label18.TabIndex = 64
        Me.Label18.Text = "Interval Mileage:"
        '
        'txtnextodo
        '
        Me.txtnextodo.Location = New System.Drawing.Point(222, 177)
        Me.txtnextodo.Name = "txtnextodo"
        Me.txtnextodo.ReadOnly = True
        Me.txtnextodo.Size = New System.Drawing.Size(268, 20)
        Me.txtnextodo.TabIndex = 62
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(55, 180)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(151, 13)
        Me.Label14.TabIndex = 63
        Me.Label14.Text = "Next Odometer for Change Oil:"
        '
        'btnpmsodo
        '
        Me.btnpmsodo.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpmsodo.Image = CType(resources.GetObject("btnpmsodo.Image"), System.Drawing.Image)
        Me.btnpmsodo.Location = New System.Drawing.Point(572, 213)
        Me.btnpmsodo.Name = "btnpmsodo"
        Me.btnpmsodo.Size = New System.Drawing.Size(101, 30)
        Me.btnpmsodo.TabIndex = 60
        Me.btnpmsodo.Text = "Odometer"
        Me.btnpmsodo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnpmsodo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnpmsodo.UseVisualStyleBackColor = True
        Me.btnpmsodo.Visible = False
        '
        'txtlastodo
        '
        Me.txtlastodo.Location = New System.Drawing.Point(222, 148)
        Me.txtlastodo.Name = "txtlastodo"
        Me.txtlastodo.Size = New System.Drawing.Size(268, 20)
        Me.txtlastodo.TabIndex = 50
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(55, 151)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(134, 13)
        Me.Label46.TabIndex = 61
        Me.Label46.Text = "Last Odometer Change Oil:"
        '
        'lblpmsexp
        '
        Me.lblpmsexp.AutoSize = True
        Me.lblpmsexp.Location = New System.Drawing.Point(438, 17)
        Me.lblpmsexp.Name = "lblpmsexp"
        Me.lblpmsexp.Size = New System.Drawing.Size(24, 13)
        Me.lblpmsexp.TabIndex = 60
        Me.lblpmsexp.Text = "exp"
        Me.lblpmsexp.Visible = False
        '
        'btnpmsremove
        '
        Me.btnpmsremove.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpmsremove.Image = CType(resources.GetObject("btnpmsremove.Image"), System.Drawing.Image)
        Me.btnpmsremove.Location = New System.Drawing.Point(365, 213)
        Me.btnpmsremove.Name = "btnpmsremove"
        Me.btnpmsremove.Size = New System.Drawing.Size(101, 30)
        Me.btnpmsremove.TabIndex = 55
        Me.btnpmsremove.Text = "Remove"
        Me.btnpmsremove.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnpmsremove.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnpmsremove.UseVisualStyleBackColor = True
        '
        'lblpmsid
        '
        Me.lblpmsid.AutoSize = True
        Me.lblpmsid.Location = New System.Drawing.Point(219, 18)
        Me.lblpmsid.Name = "lblpmsid"
        Me.lblpmsid.Size = New System.Drawing.Size(35, 13)
        Me.lblpmsid.TabIndex = 57
        Me.lblpmsid.Text = "Pmsid"
        Me.lblpmsid.Visible = False
        '
        'btnpmsadd
        '
        Me.btnpmsadd.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpmsadd.Image = CType(resources.GetObject("btnpmsadd.Image"), System.Drawing.Image)
        Me.btnpmsadd.Location = New System.Drawing.Point(58, 213)
        Me.btnpmsadd.Name = "btnpmsadd"
        Me.btnpmsadd.Size = New System.Drawing.Size(94, 30)
        Me.btnpmsadd.TabIndex = 52
        Me.btnpmsadd.Text = "Add"
        Me.btnpmsadd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnpmsadd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnpmsadd.UseVisualStyleBackColor = True
        '
        'cmbpms
        '
        Me.cmbpms.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbpms.FormattingEnabled = True
        Me.cmbpms.Location = New System.Drawing.Point(222, 36)
        Me.cmbpms.Name = "cmbpms"
        Me.cmbpms.Size = New System.Drawing.Size(268, 21)
        Me.cmbpms.TabIndex = 44
        '
        'datelastpms
        '
        Me.datelastpms.CustomFormat = ""
        Me.datelastpms.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datelastpms.Location = New System.Drawing.Point(222, 119)
        Me.datelastpms.Name = "datelastpms"
        Me.datelastpms.Size = New System.Drawing.Size(218, 20)
        Me.datelastpms.TabIndex = 46
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(55, 123)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(107, 13)
        Me.Label39.TabIndex = 42
        Me.Label39.Text = "Last Performed Date:"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(55, 44)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(96, 13)
        Me.Label40.TabIndex = 41
        Me.Label40.Text = "PM Service Name:"
        '
        'grdpms
        '
        Me.grdpms.AllowUserToAddRows = False
        Me.grdpms.AllowUserToDeleteRows = False
        Me.grdpms.AllowUserToResizeRows = False
        Me.grdpms.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdpms.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grdpms.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdpms.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.grdpms.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdpms.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.Column10, Me.Column12, Me.DataGridViewTextBoxColumn7, Me.Column7, Me.DataGridViewTextBoxColumn9, Me.Column9, Me.Column11, Me.DataGridViewTextBoxColumn10})
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.NullValue = Nothing
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdpms.DefaultCellStyle = DataGridViewCellStyle10
        Me.grdpms.Location = New System.Drawing.Point(11, 263)
        Me.grdpms.MultiSelect = False
        Me.grdpms.Name = "grdpms"
        Me.grdpms.ReadOnly = True
        Me.grdpms.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdpms.RowHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.grdpms.RowHeadersWidth = 10
        Me.grdpms.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdpms.RowsDefaultCellStyle = DataGridViewCellStyle12
        Me.grdpms.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdpms.Size = New System.Drawing.Size(796, 246)
        Me.grdpms.TabIndex = 58
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.HeaderText = "id"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 190
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn5.Visible = False
        Me.DataGridViewTextBoxColumn5.Width = 190
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.HeaderText = "PM Service Name"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.Width = 130
        '
        'Column10
        '
        Me.Column10.HeaderText = "Interval Mileage"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        '
        'Column12
        '
        Me.Column12.HeaderText = "Last Performed In"
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        Me.Column12.Width = 130
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.HeaderText = "Last Performed Date"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Width = 140
        '
        'Column7
        '
        Me.Column7.HeaderText = "Last Odometer Change Oil"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Width = 140
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.HeaderText = "Next Odometer for Change Oil"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn9.Width = 140
        '
        'Column9
        '
        Me.Column9.HeaderText = "Latest Ending Odometer"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        Me.Column9.Width = 140
        '
        'Column11
        '
        Me.Column11.HeaderText = "Remarks"
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "Status"
        Me.DataGridViewTextBoxColumn10.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        Me.DataGridViewTextBoxColumn10.Width = 120
        '
        'btnpmscancel
        '
        Me.btnpmscancel.Enabled = False
        Me.btnpmscancel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpmscancel.Image = CType(resources.GetObject("btnpmscancel.Image"), System.Drawing.Image)
        Me.btnpmscancel.Location = New System.Drawing.Point(265, 213)
        Me.btnpmscancel.Name = "btnpmscancel"
        Me.btnpmscancel.Size = New System.Drawing.Size(94, 30)
        Me.btnpmscancel.TabIndex = 54
        Me.btnpmscancel.Text = "Cancel"
        Me.btnpmscancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnpmscancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnpmscancel.UseVisualStyleBackColor = True
        '
        'btnpmsview
        '
        Me.btnpmsview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpmsview.Image = CType(resources.GetObject("btnpmsview.Image"), System.Drawing.Image)
        Me.btnpmsview.Location = New System.Drawing.Point(472, 213)
        Me.btnpmsview.Name = "btnpmsview"
        Me.btnpmsview.Size = New System.Drawing.Size(94, 30)
        Me.btnpmsview.TabIndex = 56
        Me.btnpmsview.Text = "View All"
        Me.btnpmsview.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnpmsview.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnpmsview.UseVisualStyleBackColor = True
        '
        'btnpmsupdate
        '
        Me.btnpmsupdate.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpmsupdate.Image = CType(resources.GetObject("btnpmsupdate.Image"), System.Drawing.Image)
        Me.btnpmsupdate.Location = New System.Drawing.Point(158, 213)
        Me.btnpmsupdate.Name = "btnpmsupdate"
        Me.btnpmsupdate.Size = New System.Drawing.Size(101, 30)
        Me.btnpmsupdate.TabIndex = 53
        Me.btnpmsupdate.Text = "Update"
        Me.btnpmsupdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnpmsupdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnpmsupdate.UseVisualStyleBackColor = True
        '
        'tab4
        '
        Me.tab4.Controls.Add(Me.GroupBox5)
        Me.tab4.Location = New System.Drawing.Point(4, 22)
        Me.tab4.Name = "tab4"
        Me.tab4.Size = New System.Drawing.Size(868, 550)
        Me.tab4.TabIndex = 6
        Me.tab4.Text = "Photo"
        Me.tab4.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox5.Controls.Add(Me.btnimgdl)
        Me.GroupBox5.Controls.Add(Me.lblimgid)
        Me.GroupBox5.Controls.Add(Me.btnimgset)
        Me.GroupBox5.Controls.Add(Me.btnimgfull)
        Me.GroupBox5.Controls.Add(Me.btnimgupdate)
        Me.GroupBox5.Controls.Add(Me.txtimg)
        Me.GroupBox5.Controls.Add(Me.imgpanel)
        Me.GroupBox5.Controls.Add(Me.imgbox)
        Me.GroupBox5.Controls.Add(Me.btnimgremove)
        Me.GroupBox5.Controls.Add(Me.btnimgadd)
        Me.GroupBox5.Controls.Add(Me.btnimgcancel)
        Me.GroupBox5.Controls.Add(Me.btnimgrefresh)
        Me.GroupBox5.Controls.Add(Me.btnimgrename)
        Me.GroupBox5.Location = New System.Drawing.Point(19, 15)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(818, 527)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Photos"
        '
        'btnimgdl
        '
        Me.btnimgdl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgdl.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl.Image = CType(resources.GetObject("btnimgdl.Image"), System.Drawing.Image)
        Me.btnimgdl.Location = New System.Drawing.Point(576, 420)
        Me.btnimgdl.Name = "btnimgdl"
        Me.btnimgdl.Size = New System.Drawing.Size(208, 30)
        Me.btnimgdl.TabIndex = 64
        Me.btnimgdl.Text = "Download Photo"
        Me.btnimgdl.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl.UseVisualStyleBackColor = True
        '
        'lblimgid
        '
        Me.lblimgid.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblimgid.AutoSize = True
        Me.lblimgid.Location = New System.Drawing.Point(536, 504)
        Me.lblimgid.Name = "lblimgid"
        Me.lblimgid.Size = New System.Drawing.Size(31, 13)
        Me.lblimgid.TabIndex = 68
        Me.lblimgid.Text = "imgid"
        Me.lblimgid.Visible = False
        '
        'btnimgset
        '
        Me.btnimgset.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgset.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgset.Image = CType(resources.GetObject("btnimgset.Image"), System.Drawing.Image)
        Me.btnimgset.Location = New System.Drawing.Point(576, 348)
        Me.btnimgset.Name = "btnimgset"
        Me.btnimgset.Size = New System.Drawing.Size(208, 30)
        Me.btnimgset.TabIndex = 62
        Me.btnimgset.Text = "Set as Primary Photo"
        Me.btnimgset.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgset.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgset.UseVisualStyleBackColor = True
        '
        'btnimgfull
        '
        Me.btnimgfull.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgfull.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull.Image = CType(resources.GetObject("btnimgfull.Image"), System.Drawing.Image)
        Me.btnimgfull.Location = New System.Drawing.Point(576, 456)
        Me.btnimgfull.Name = "btnimgfull"
        Me.btnimgfull.Size = New System.Drawing.Size(208, 30)
        Me.btnimgfull.TabIndex = 65
        Me.btnimgfull.Text = "View Larger"
        Me.btnimgfull.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull.UseVisualStyleBackColor = True
        '
        'btnimgupdate
        '
        Me.btnimgupdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgupdate.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgupdate.Image = CType(resources.GetObject("btnimgupdate.Image"), System.Drawing.Image)
        Me.btnimgupdate.Location = New System.Drawing.Point(576, 384)
        Me.btnimgupdate.Name = "btnimgupdate"
        Me.btnimgupdate.Size = New System.Drawing.Size(208, 30)
        Me.btnimgupdate.TabIndex = 63
        Me.btnimgupdate.Text = "Update Photo"
        Me.btnimgupdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgupdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgupdate.UseVisualStyleBackColor = True
        '
        'txtimg
        '
        Me.txtimg.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtimg.BackColor = System.Drawing.Color.White
        Me.txtimg.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtimg.Location = New System.Drawing.Point(539, 248)
        Me.txtimg.Name = "txtimg"
        Me.txtimg.ReadOnly = True
        Me.txtimg.Size = New System.Drawing.Size(273, 22)
        Me.txtimg.TabIndex = 57
        '
        'imgpanel
        '
        Me.imgpanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.imgpanel.AutoScroll = True
        Me.imgpanel.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel.Location = New System.Drawing.Point(6, 20)
        Me.imgpanel.Name = "imgpanel"
        Me.imgpanel.Size = New System.Drawing.Size(527, 501)
        Me.imgpanel.TabIndex = 63
        '
        'imgbox
        '
        Me.imgbox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.imgbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox.Location = New System.Drawing.Point(539, 20)
        Me.imgbox.Name = "imgbox"
        Me.imgbox.Size = New System.Drawing.Size(273, 219)
        Me.imgbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox.TabIndex = 62
        Me.imgbox.TabStop = False
        '
        'btnimgremove
        '
        Me.btnimgremove.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgremove.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove.Image = CType(resources.GetObject("btnimgremove.Image"), System.Drawing.Image)
        Me.btnimgremove.Location = New System.Drawing.Point(576, 312)
        Me.btnimgremove.Name = "btnimgremove"
        Me.btnimgremove.Size = New System.Drawing.Size(101, 30)
        Me.btnimgremove.TabIndex = 60
        Me.btnimgremove.Text = "Remove"
        Me.btnimgremove.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove.UseVisualStyleBackColor = True
        '
        'btnimgadd
        '
        Me.btnimgadd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgadd.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd.Image = CType(resources.GetObject("btnimgadd.Image"), System.Drawing.Image)
        Me.btnimgadd.Location = New System.Drawing.Point(576, 276)
        Me.btnimgadd.Name = "btnimgadd"
        Me.btnimgadd.Size = New System.Drawing.Size(101, 30)
        Me.btnimgadd.TabIndex = 58
        Me.btnimgadd.Text = "Add Photo"
        Me.btnimgadd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd.UseVisualStyleBackColor = True
        '
        'btnimgcancel
        '
        Me.btnimgcancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgcancel.Enabled = False
        Me.btnimgcancel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel.Image = CType(resources.GetObject("btnimgcancel.Image"), System.Drawing.Image)
        Me.btnimgcancel.Location = New System.Drawing.Point(683, 312)
        Me.btnimgcancel.Name = "btnimgcancel"
        Me.btnimgcancel.Size = New System.Drawing.Size(101, 30)
        Me.btnimgcancel.TabIndex = 61
        Me.btnimgcancel.Text = "Cancel"
        Me.btnimgcancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel.UseVisualStyleBackColor = True
        '
        'btnimgrefresh
        '
        Me.btnimgrefresh.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgrefresh.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh.Image = CType(resources.GetObject("btnimgrefresh.Image"), System.Drawing.Image)
        Me.btnimgrefresh.Location = New System.Drawing.Point(576, 492)
        Me.btnimgrefresh.Name = "btnimgrefresh"
        Me.btnimgrefresh.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh.TabIndex = 66
        Me.btnimgrefresh.Text = "Refresh"
        Me.btnimgrefresh.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh.UseVisualStyleBackColor = True
        '
        'btnimgrename
        '
        Me.btnimgrename.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgrename.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename.Image = CType(resources.GetObject("btnimgrename.Image"), System.Drawing.Image)
        Me.btnimgrename.Location = New System.Drawing.Point(683, 276)
        Me.btnimgrename.Name = "btnimgrename"
        Me.btnimgrename.Size = New System.Drawing.Size(101, 30)
        Me.btnimgrename.TabIndex = 59
        Me.btnimgrename.Text = "Rename"
        Me.btnimgrename.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename.UseVisualStyleBackColor = True
        '
        'tab5
        '
        Me.tab5.Controls.Add(Me.GroupBox10)
        Me.tab5.Location = New System.Drawing.Point(4, 22)
        Me.tab5.Name = "tab5"
        Me.tab5.Size = New System.Drawing.Size(868, 550)
        Me.tab5.TabIndex = 7
        Me.tab5.Text = "Repairs"
        Me.tab5.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox10.Controls.Add(Me.linkhistory)
        Me.GroupBox10.Controls.Add(Me.lblrmid)
        Me.GroupBox10.Controls.Add(Me.txtmechanic)
        Me.GroupBox10.Controls.Add(Me.Label47)
        Me.GroupBox10.Controls.Add(Me.txtothers)
        Me.GroupBox10.Controls.Add(Me.rbothers)
        Me.GroupBox10.Controls.Add(Me.rbcheck)
        Me.GroupBox10.Controls.Add(Me.btnreprefresh)
        Me.GroupBox10.Controls.Add(Me.rbrepair)
        Me.GroupBox10.Controls.Add(Me.btnrepcancel)
        Me.GroupBox10.Controls.Add(Me.Label35)
        Me.GroupBox10.Controls.Add(Me.btnrepedit)
        Me.GroupBox10.Controls.Add(Me.Label36)
        Me.GroupBox10.Controls.Add(Me.btnrepadd)
        Me.GroupBox10.Controls.Add(Me.Label38)
        Me.GroupBox10.Controls.Add(Me.grdrepair)
        Me.GroupBox10.Controls.Add(Me.Label41)
        Me.GroupBox10.Controls.Add(Me.datestart)
        Me.GroupBox10.Controls.Add(Me.Label42)
        Me.GroupBox10.Controls.Add(Me.txtdesc)
        Me.GroupBox10.Controls.Add(Me.Label43)
        Me.GroupBox10.Controls.Add(Me.txtreason)
        Me.GroupBox10.Controls.Add(Me.Label44)
        Me.GroupBox10.Controls.Add(Me.Label45)
        Me.GroupBox10.Controls.Add(Me.btnrepparts)
        Me.GroupBox10.Location = New System.Drawing.Point(19, 18)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(818, 527)
        Me.GroupBox10.TabIndex = 1
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Repairs / Check-up / Test"
        '
        'linkhistory
        '
        Me.linkhistory.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.linkhistory.AutoSize = True
        Me.linkhistory.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.linkhistory.LinkColor = System.Drawing.Color.Green
        Me.linkhistory.Location = New System.Drawing.Point(688, 503)
        Me.linkhistory.Name = "linkhistory"
        Me.linkhistory.Size = New System.Drawing.Size(117, 15)
        Me.linkhistory.TabIndex = 88
        Me.linkhistory.TabStop = True
        Me.linkhistory.Text = "Show Repair History"
        '
        'lblrmid
        '
        Me.lblrmid.AutoSize = True
        Me.lblrmid.Location = New System.Drawing.Point(6, 24)
        Me.lblrmid.Name = "lblrmid"
        Me.lblrmid.Size = New System.Drawing.Size(26, 13)
        Me.lblrmid.TabIndex = 87
        Me.lblrmid.Text = "rmid"
        Me.lblrmid.Visible = False
        '
        'txtmechanic
        '
        Me.txtmechanic.Location = New System.Drawing.Point(167, 136)
        Me.txtmechanic.Name = "txtmechanic"
        Me.txtmechanic.Size = New System.Drawing.Size(253, 20)
        Me.txtmechanic.TabIndex = 78
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(43, 139)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(101, 15)
        Me.Label47.TabIndex = 76
        Me.Label47.Text = "Mechanic Name:"
        '
        'txtothers
        '
        Me.txtothers.Location = New System.Drawing.Point(437, 20)
        Me.txtothers.Name = "txtothers"
        Me.txtothers.ReadOnly = True
        Me.txtothers.Size = New System.Drawing.Size(188, 20)
        Me.txtothers.TabIndex = 73
        '
        'rbothers
        '
        Me.rbothers.AutoSize = True
        Me.rbothers.Location = New System.Drawing.Point(358, 20)
        Me.rbothers.Name = "rbothers"
        Me.rbothers.Size = New System.Drawing.Size(56, 17)
        Me.rbothers.TabIndex = 72
        Me.rbothers.TabStop = True
        Me.rbothers.Text = "Others"
        Me.rbothers.UseVisualStyleBackColor = True
        '
        'rbcheck
        '
        Me.rbcheck.AutoSize = True
        Me.rbcheck.Location = New System.Drawing.Point(252, 21)
        Me.rbcheck.Name = "rbcheck"
        Me.rbcheck.Size = New System.Drawing.Size(71, 17)
        Me.rbcheck.TabIndex = 70
        Me.rbcheck.TabStop = True
        Me.rbcheck.Text = "Check-up"
        Me.rbcheck.UseVisualStyleBackColor = True
        '
        'btnreprefresh
        '
        Me.btnreprefresh.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnreprefresh.Image = CType(resources.GetObject("btnreprefresh.Image"), System.Drawing.Image)
        Me.btnreprefresh.Location = New System.Drawing.Point(621, 165)
        Me.btnreprefresh.Name = "btnreprefresh"
        Me.btnreprefresh.Size = New System.Drawing.Size(101, 30)
        Me.btnreprefresh.TabIndex = 84
        Me.btnreprefresh.Text = "Refresh"
        Me.btnreprefresh.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnreprefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnreprefresh.UseVisualStyleBackColor = True
        '
        'rbrepair
        '
        Me.rbrepair.AutoSize = True
        Me.rbrepair.Location = New System.Drawing.Point(167, 21)
        Me.rbrepair.Name = "rbrepair"
        Me.rbrepair.Size = New System.Drawing.Size(56, 17)
        Me.rbrepair.TabIndex = 69
        Me.rbrepair.TabStop = True
        Me.rbrepair.Text = "Repair"
        Me.rbrepair.UseVisualStyleBackColor = True
        '
        'btnrepcancel
        '
        Me.btnrepcancel.Enabled = False
        Me.btnrepcancel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrepcancel.Image = CType(resources.GetObject("btnrepcancel.Image"), System.Drawing.Image)
        Me.btnrepcancel.Location = New System.Drawing.Point(514, 165)
        Me.btnrepcancel.Name = "btnrepcancel"
        Me.btnrepcancel.Size = New System.Drawing.Size(101, 30)
        Me.btnrepcancel.TabIndex = 83
        Me.btnrepcancel.Text = "Cancel"
        Me.btnrepcancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrepcancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrepcancel.UseVisualStyleBackColor = True
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(108, 26)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(36, 15)
        Me.Label35.TabIndex = 0
        Me.Label35.Text = "Type:"
        '
        'btnrepedit
        '
        Me.btnrepedit.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrepedit.Image = CType(resources.GetObject("btnrepedit.Image"), System.Drawing.Image)
        Me.btnrepedit.Location = New System.Drawing.Point(407, 165)
        Me.btnrepedit.Name = "btnrepedit"
        Me.btnrepedit.Size = New System.Drawing.Size(101, 30)
        Me.btnrepedit.TabIndex = 82
        Me.btnrepedit.Text = "Edit"
        Me.btnrepedit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrepedit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrepedit.UseVisualStyleBackColor = True
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Red
        Me.Label36.Location = New System.Drawing.Point(79, 111)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(12, 15)
        Me.Label36.TabIndex = 68
        Me.Label36.Text = "*"
        '
        'btnrepadd
        '
        Me.btnrepadd.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrepadd.Image = CType(resources.GetObject("btnrepadd.Image"), System.Drawing.Image)
        Me.btnrepadd.Location = New System.Drawing.Point(300, 165)
        Me.btnrepadd.Name = "btnrepadd"
        Me.btnrepadd.Size = New System.Drawing.Size(101, 30)
        Me.btnrepadd.TabIndex = 81
        Me.btnrepadd.Text = "Add"
        Me.btnrepadd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrepadd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrepadd.UseVisualStyleBackColor = True
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Red
        Me.Label38.Location = New System.Drawing.Point(57, 83)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(12, 15)
        Me.Label38.TabIndex = 67
        Me.Label38.Text = "*"
        '
        'grdrepair
        '
        Me.grdrepair.AllowUserToAddRows = False
        Me.grdrepair.AllowUserToDeleteRows = False
        Me.grdrepair.AllowUserToResizeRows = False
        Me.grdrepair.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdrepair.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grdrepair.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdrepair.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.grdrepair.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdrepair.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn11, Me.Column8, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn19, Me.Column6})
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.NullValue = Nothing
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdrepair.DefaultCellStyle = DataGridViewCellStyle14
        Me.grdrepair.Location = New System.Drawing.Point(11, 203)
        Me.grdrepair.MultiSelect = False
        Me.grdrepair.Name = "grdrepair"
        Me.grdrepair.ReadOnly = True
        Me.grdrepair.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdrepair.RowHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.grdrepair.RowHeadersWidth = 10
        Me.grdrepair.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdrepair.RowsDefaultCellStyle = DataGridViewCellStyle16
        Me.grdrepair.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdrepair.Size = New System.Drawing.Size(796, 293)
        Me.grdrepair.TabIndex = 85
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "RMID"
        Me.DataGridViewTextBoxColumn11.MinimumWidth = 60
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        Me.DataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn11.Visible = False
        Me.DataGridViewTextBoxColumn11.Width = 60
        '
        'Column8
        '
        Me.Column8.HeaderText = "Type"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.HeaderText = "Description:"
        Me.DataGridViewTextBoxColumn16.MinimumWidth = 180
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.ReadOnly = True
        Me.DataGridViewTextBoxColumn16.Width = 180
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.HeaderText = "Reason:"
        Me.DataGridViewTextBoxColumn17.MinimumWidth = 140
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        Me.DataGridViewTextBoxColumn17.Width = 140
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.HeaderText = "Date Started"
        Me.DataGridViewTextBoxColumn12.MinimumWidth = 130
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        Me.DataGridViewTextBoxColumn12.Width = 130
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "Finished"
        Me.DataGridViewTextBoxColumn18.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        Me.DataGridViewTextBoxColumn18.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.HeaderText = "Date Finished"
        Me.DataGridViewTextBoxColumn19.MinimumWidth = 130
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.ReadOnly = True
        Me.DataGridViewTextBoxColumn19.Width = 130
        '
        'Column6
        '
        Me.Column6.HeaderText = "Mechanic Name:"
        Me.Column6.MinimumWidth = 140
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        Me.Column6.Width = 140
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.Red
        Me.Label41.Location = New System.Drawing.Point(51, 56)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(12, 15)
        Me.Label41.TabIndex = 66
        Me.Label41.Text = "*"
        '
        'datestart
        '
        Me.datestart.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datestart.Location = New System.Drawing.Point(167, 52)
        Me.datestart.Name = "datestart"
        Me.datestart.Size = New System.Drawing.Size(188, 20)
        Me.datestart.TabIndex = 74
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Red
        Me.Label42.Location = New System.Drawing.Point(97, 25)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(12, 15)
        Me.Label42.TabIndex = 65
        Me.Label42.Text = "*"
        '
        'txtdesc
        '
        Me.txtdesc.Location = New System.Drawing.Point(167, 80)
        Me.txtdesc.Name = "txtdesc"
        Me.txtdesc.Size = New System.Drawing.Size(492, 20)
        Me.txtdesc.TabIndex = 76
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(63, 57)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(81, 15)
        Me.Label43.TabIndex = 4
        Me.Label43.Text = "Date Started:"
        '
        'txtreason
        '
        Me.txtreason.Location = New System.Drawing.Point(167, 108)
        Me.txtreason.Name = "txtreason"
        Me.txtreason.Size = New System.Drawing.Size(492, 20)
        Me.txtreason.TabIndex = 77
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(69, 83)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(75, 15)
        Me.Label44.TabIndex = 5
        Me.Label44.Text = "Description:"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(91, 112)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(53, 15)
        Me.Label45.TabIndex = 6
        Me.Label45.Text = "Reason:"
        '
        'btnrepparts
        '
        Me.btnrepparts.Enabled = False
        Me.btnrepparts.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrepparts.Image = CType(resources.GetObject("btnrepparts.Image"), System.Drawing.Image)
        Me.btnrepparts.Location = New System.Drawing.Point(166, 167)
        Me.btnrepparts.Name = "btnrepparts"
        Me.btnrepparts.Size = New System.Drawing.Size(128, 27)
        Me.btnrepparts.TabIndex = 79
        Me.btnrepparts.Text = "Parts Needed"
        Me.btnrepparts.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrepparts.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrepparts.UseVisualStyleBackColor = True
        '
        'vmanage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1334, 671)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "vmanage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Manage Vehicle"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.grdplate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.tab1.ResumeLayout(False)
        Me.tab1.PerformLayout()
        Me.grbiden.ResumeLayout(False)
        Me.grbiden.PerformLayout()
        CType(Me.imgphoto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.txtmodel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.tab2.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.num, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grddoc, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab3.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        CType(Me.grdpms, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.imgbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab5.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        CType(Me.grdrepair, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents grdplate As System.Windows.Forms.DataGridView
    Friend WithEvents cmbwhsesch As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tab1 As System.Windows.Forms.TabPage
    Friend WithEvents tab2 As System.Windows.Forms.TabPage
    Friend WithEvents grbiden As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents imgphoto As System.Windows.Forms.PictureBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtvplate As System.Windows.Forms.TextBox
    Friend WithEvents txtplatenum As System.Windows.Forms.TextBox
    Friend WithEvents cmbwhse As System.Windows.Forms.ComboBox
    Friend WithEvents cmbmake As System.Windows.Forms.ComboBox
    Friend WithEvents txtcolor As System.Windows.Forms.TextBox
    Friend WithEvents cmbtype As System.Windows.Forms.ComboBox
    Friend WithEvents txtsticker As System.Windows.Forms.TextBox
    Friend WithEvents txtnote As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents cmbsupplier As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents lblplatebig As System.Windows.Forms.Label
    Friend WithEvents btncanceldoc As System.Windows.Forms.Button
    Friend WithEvents btnviewalldoc As System.Windows.Forms.Button
    Friend WithEvents btnupdatedoc As System.Windows.Forms.Button
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents datelastrenew As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents txtrems As System.Windows.Forms.TextBox
    Friend WithEvents tab3 As System.Windows.Forms.TabPage
    Friend WithEvents btnvadd As System.Windows.Forms.Button
    Friend WithEvents btnvdeac As System.Windows.Forms.Button
    Friend WithEvents btnupdategen As System.Windows.Forms.Button
    Friend WithEvents btnrefresh As System.Windows.Forms.Button
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbdocname As System.Windows.Forms.ComboBox
    Friend WithEvents btnadddoc As System.Windows.Forms.Button
    Friend WithEvents dateexpired As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents num As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents btncancelfilter As System.Windows.Forms.Button
    Friend WithEvents txtsearch As System.Windows.Forms.TextBox
    Friend WithEvents btnok As System.Windows.Forms.Button
    Friend WithEvents cmbtypesch As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents cmbinterval As System.Windows.Forms.ComboBox
    Friend WithEvents lblid As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents chkdeac As System.Windows.Forms.CheckBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents btncanceladd As System.Windows.Forms.Button
    Friend WithEvents lbldocid As System.Windows.Forms.Label
    Friend WithEvents btnremovedoc As System.Windows.Forms.Button
    Friend WithEvents chkuse As System.Windows.Forms.CheckBox
    Friend WithEvents btnattach As System.Windows.Forms.Button
    Friend WithEvents txtattachname As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lblexp As System.Windows.Forms.Label
    Friend WithEvents txtmodel As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbbody As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtdriver As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents cmbcompany As System.Windows.Forms.ComboBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents txtchasis As System.Windows.Forms.TextBox
    Friend WithEvents txtmotor As System.Windows.Forms.TextBox
    Friend WithEvents cmbcompsch As System.Windows.Forms.ComboBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents listbox As System.Windows.Forms.ListBox
    Friend WithEvents lblpmsexp As System.Windows.Forms.Label
    Friend WithEvents btnpmsremove As System.Windows.Forms.Button
    Friend WithEvents lblpmsid As System.Windows.Forms.Label
    Friend WithEvents btnpmsadd As System.Windows.Forms.Button
    Friend WithEvents cmbpms As System.Windows.Forms.ComboBox
    Friend WithEvents datelastpms As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents grdpms As System.Windows.Forms.DataGridView
    Friend WithEvents btnpmscancel As System.Windows.Forms.Button
    Friend WithEvents btnpmsview As System.Windows.Forms.Button
    Friend WithEvents btnpmsupdate As System.Windows.Forms.Button
    Friend WithEvents grddoc As System.Windows.Forms.DataGridView
    Friend WithEvents lbldreason As System.Windows.Forms.Label
    Friend WithEvents tab4 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents btnimgremove As System.Windows.Forms.Button
    Friend WithEvents btnimgadd As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh As System.Windows.Forms.Button
    Friend WithEvents btnimgrename As System.Windows.Forms.Button
    Friend WithEvents imgbox As System.Windows.Forms.PictureBox
    Friend WithEvents imgpanel As System.Windows.Forms.Panel
    Friend WithEvents btnimgset As System.Windows.Forms.Button
    Friend WithEvents btnimgfull As System.Windows.Forms.Button
    Friend WithEvents btnimgupdate As System.Windows.Forms.Button
    Friend WithEvents txtimg As System.Windows.Forms.TextBox
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents lblimgid As System.Windows.Forms.Label
    Friend WithEvents lblprimary As System.Windows.Forms.Label
    Friend WithEvents tab5 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents grdrepair As System.Windows.Forms.DataGridView
    Friend WithEvents btnreprefresh As System.Windows.Forms.Button
    Friend WithEvents btnrepcancel As System.Windows.Forms.Button
    Friend WithEvents btnrepedit As System.Windows.Forms.Button
    Friend WithEvents btnrepadd As System.Windows.Forms.Button
    Friend WithEvents rbcheck As System.Windows.Forms.RadioButton
    Friend WithEvents rbrepair As System.Windows.Forms.RadioButton
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents btnrepparts As System.Windows.Forms.Button
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents datestart As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtreason As System.Windows.Forms.TextBox
    Friend WithEvents txtothers As System.Windows.Forms.TextBox
    Friend WithEvents rbothers As System.Windows.Forms.RadioButton
    Friend WithEvents txtmechanic As System.Windows.Forms.TextBox
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents lblrmid As System.Windows.Forms.Label
    Friend WithEvents linkhistory As System.Windows.Forms.LinkLabel
    Friend WithEvents btncancelupdate As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents txtdesc As System.Windows.Forms.TextBox
    Friend WithEvents btnimgdl As System.Windows.Forms.Button
    Friend WithEvents txtlastodo As System.Windows.Forms.TextBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents lblselect As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents lbllastsearch As System.Windows.Forms.Label
    Friend WithEvents btnpmsodo As System.Windows.Forms.Button
    Friend WithEvents cmbdriver As System.Windows.Forms.ComboBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents txtbal As System.Windows.Forms.TextBox
    Friend WithEvents txtfull As System.Windows.Forms.TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents txtliter As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents txttank As System.Windows.Forms.TextBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents txtwout As System.Windows.Forms.TextBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents txtwith As System.Windows.Forms.TextBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents txtinches As System.Windows.Forms.TextBox
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtnextodo As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtmiles As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtpmsrems As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents cmbpmswhse As System.Windows.Forms.ComboBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
