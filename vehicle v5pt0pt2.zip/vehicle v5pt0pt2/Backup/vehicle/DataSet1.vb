﻿

Partial Public Class DataSet1
    Partial Class DataTable11DataTable

    End Class

    Partial Class DataTable10DataTable

        Private Sub DataTable10DataTable_ColumnChanging(ByVal sender As System.Object, ByVal e As System.Data.DataColumnChangeEventArgs) Handles Me.ColumnChanging
            If (e.Column.ColumnName = Me.RemarksColumn.ColumnName) Then
                'Add user code here
            End If

        End Sub

    End Class

    Partial Class DataTable6DataTable

        Private Sub DataTable6DataTable_DataTable6RowChanging(ByVal sender As System.Object, ByVal e As DataTable6RowChangeEvent) Handles Me.DataTable6RowChanging

        End Sub

    End Class

End Class
