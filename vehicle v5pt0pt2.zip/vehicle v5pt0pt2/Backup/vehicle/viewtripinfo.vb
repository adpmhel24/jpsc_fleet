﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Windows.Forms
Imports CrystalDecisions.ReportSource
Imports System.Drawing.Printing
Imports Excel = Microsoft.Office.Interop.Excel

Public Class viewtripinfo
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Dim clickbtn As String = "", selectedrow As Integer

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub viewtripinfo_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        txtdel.Text = ""
        txtplate.Text = ""
        txttype.Text = ""
        txtdriver.Text = ""
        txthelper.Text = ""
        txtorigin.Text = ""
        txtdes.Text = ""
        txtetd.Text = ""
        txtdatecr.Text = ""
        txtcreated.Text = ""
        txtdatemod.Text = ""
        txtmodify.Text = ""
        txtrems.Text = ""
        txtcancel.Text = ""
        txtdatecan.Text = ""
        txtcanby.Text = ""
        chkpick.Checked = False
    End Sub

    Private Sub viewtripinfo_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If login.whse = "Calamba" Then
            '/chkpick.Visible = True
        End If
        viewtrip()
        grdtrans.Columns(4).Frozen = True
        grddispatch.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    End Sub

    Public Sub viewtrip()
        Try
            Me.Cursor = Cursors.WaitCursor

            sql = "Select * from tbltripsum where tripsumid='" & lblid.Text & "'"
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            If dr1.Read Then
                txtdel.Text = Format(dr1("datepick"), "yyyy/MM/dd")
                txtplate.Text = dr1("platenum")
                txttype.Text = ""
                txtdriver.Text = dr1("driver")
                txthelper.Text = dr1("helper").ToString
                txtorigin.Text = dr1("origin")
                txtdes.Text = ""
                txtetd.Text = Format(dr1("etd"), "yyyy/MM/dd HH:mm")
                txtdatecr.Text = Format(dr1("datecreated"), "yyyy/MM/dd HH:mm")
                txtcreated.Text = dr1("createdby")
                txtdatemod.Text = Format(dr1("datemodified"), "yyyy/MM/dd HH:mm")
                txtmodify.Text = dr1("modifiedby")
                txtrems.Text = dr1("remarks")
                txtcancel.Text = dr1("creason").ToString
                If IsDBNull(dr1("datecancelled")) = False Then
                    txtdatecan.Text = Format(dr1("datecancelled"), "yyyy/MM/dd HH:mm")
                Else
                    txtdatecan.Text = ""
                End If
                txtcanby.Text = dr1("cancelledby").ToString
                If dr1("repair") = 1 Then
                    chkpick.Checked = True
                Else
                    chkpick.Checked = False
                End If
            End If
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            destin()


            'pickup
            connect()
            Dim pickupat As String = "", temptype As String = ""
            sql = "SELECT * FROM tbltripitems RIGHT OUTER JOIN tblortrans ON tbltripitems.transnum=tblortrans.transnum where tbltripitems.tripnum='" & lbltripnum.Text & "'"
            Dim cmd1x As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1x As SqlDataReader = cmd1x.ExecuteReader
            While dr1x.Read
                If dr1x("transtype").ToString.Contains("PICKUP") Then
                    Dim inSql As String = dr1x("transtype").ToString
                    Dim lastPart As String
                    Dim fromStart As Integer
                    Dim firstpart As String

                    fromStart = inSql.IndexOf("FRM ") + 4

                    firstpart = inSql.Substring(0, fromStart - 4)
                    temptype = Trim(firstpart)

                    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

                    temptype = lastPart & " "
                End If
            End While
            dr1x.Dispose()
            cmd1x.Dispose()
            conn.Close()


            pickupat = "p/up " & temptype


            grddispatch.Rows.Clear()

            connect()
            sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum.Text & "'"
            Dim cmdx1 As SqlCommand = New SqlCommand(sql, conn)
            Dim drx1 As SqlDataReader = cmdx1.ExecuteReader
            If drx1.Read Then
                Dim whatstep As String = "ON QUEUE"
                Dim des As String = ""

                Dim starttime1 As String = ""
                If IsDBNull(drx1("startpre")) = False Then
                    starttime1 = Format(drx1("startpre"), "yyyy/MM/dd HH:mm")
                End If
                Dim endtime1 As String = ""
                If IsDBNull(drx1("datestp1")) = False Then
                    endtime1 = Format(drx1("datestp1"), "yyyy/MM/dd HH:mm")
                End If

                If drx1("step1") = 1 Then
                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                        grddispatch.Rows.Add("Step 1 (PRE-INSPECTION)", starttime1, endtime1, drx1("namestp1").ToString, drx1("remstp1").ToString & " " & des, drx1("comstp1").ToString)

                    ElseIf drx1("namestp1").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                        grddispatch.Rows.Add("Step 1 (PRE-INSPECTION)", des, des, des, drx1("remstp1").ToString, drx1("comstp1").ToString)

                    ElseIf drx1("namestp1").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp1") & " ( " & endtime1 & " )"
                        whatstep = "STEP 1"
                        grddispatch.Rows.Add("Step 1 (PRE-INSPECTION)", starttime1, endtime1, drx1("namestp1").ToString, drx1("remstp1").ToString, drx1("comstp1").ToString)
                    End If

                    grddispatch.Rows(0).DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 128)
                Else
                    grddispatch.Rows.Add("Step 1 (PRE-INSPECTION)", starttime1, "", "", drx1("remstp1").ToString, "")
                End If

                Dim starttime2 As String = ""
                If IsDBNull(drx1("startdiesel")) = False Then
                    starttime2 = Format(drx1("startdiesel"), "yyyy/MM/dd HH:mm")
                End If
                Dim endtime2 As String = ""
                If IsDBNull(drx1("datestp2")) = False Then
                    endtime2 = Format(drx1("datestp2"), "yyyy/MM/dd HH:mm")
                End If

                If drx1("step2") = 1 Then
                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                        grddispatch.Rows.Add("Step 2 (DIESEL)", starttime2, endtime2, drx1("namestp2").ToString, drx1("remstp2").ToString & " " & des, drx1("comstp2").ToString)

                    ElseIf drx1("namestp2").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                        grddispatch.Rows.Add("Step 2 (DIESEL)", des, des, des, drx1("remstp2").ToString, drx1("comstp2").ToString)

                    ElseIf drx1("namestp2").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp2") & " ( " & endtime2 & " )"
                        whatstep = "STEP 2"
                        grddispatch.Rows.Add("Step 2 (DIESEL)", starttime2, endtime2, drx1("namestp2").ToString, drx1("remstp2").ToString, drx1("comstp2").ToString)
                    End If

                    grddispatch.Rows(1).DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 128)
                Else
                    grddispatch.Rows.Add("Step 2 (DIESEL)", starttime2, "", "", drx1("remstp2").ToString, "")
                End If

                Dim starttime3 As String = ""
                If IsDBNull(drx1("startload")) = False Then
                    starttime3 = Format(drx1("startload"), "yyyy/MM/dd HH:mm")
                End If
                Dim endtime3 As String = ""
                If IsDBNull(drx1("datestp3")) = False Then
                    endtime3 = Format(drx1("datestp3"), "yyyy/MM/dd HH:mm")
                End If

                If drx1("step3") = 1 Then
                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                        grddispatch.Rows.Add("Step 3 (LOADING)", starttime3, endtime3, drx1("namestp3").ToString, drx1("remstp3").ToString & " " & des, drx1("comstp3").ToString)
                    ElseIf drx1("namestp3").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                        If txtdes.Text = "Taxi" Then
                            pickupat = "Taxi"
                        End If
                        grddispatch.Rows.Add("Step 3 (LOADING)", des, des, des, drx1("remstp3").ToString & " " & pickupat, drx1("comstp3").ToString)
                    ElseIf drx1("namestp3").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp3") & " ( " & endtime3 & " )"
                        whatstep = "STEP 3"
                        grddispatch.Rows.Add("Step 3 (LOADING)", starttime3, endtime3, drx1("namestp3").ToString, drx1("remstp3").ToString, drx1("comstp3").ToString)
                    End If

                    grddispatch.Rows(2).DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 128)
                Else
                    grddispatch.Rows.Add("Step 3 (LOADING)", starttime3, "", "", drx1("remstp3").ToString, "")
                End If

                Dim starttime4 As String = ""
                If IsDBNull(drx1("startdoc")) = False Then
                    starttime4 = Format(drx1("startdoc"), "yyyy/MM/dd HH:mm")
                End If
                Dim endtime4 As String = ""
                If IsDBNull(drx1("datestp4")) = False Then
                    endtime4 = Format(drx1("datestp4"), "yyyy/MM/dd HH:mm")
                End If

                If drx1("step4") = 1 Then
                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                        grddispatch.Rows.Add("Step 4 (RELEASE DOCUMENTS)", starttime4, endtime4, drx1("namestp4").ToString, drx1("remstp4").ToString & " " & des, drx1("comstp4").ToString)

                    ElseIf drx1("namestp4").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                        grddispatch.Rows.Add("Step 4 (RELEASE DOCUMENTS)", des, des, des, drx1("remstp4").ToString, drx1("comstp4").ToString)

                    ElseIf drx1("namestp4").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp4") & " ( " & endtime4 & " )"
                        whatstep = "STEP 4"
                        grddispatch.Rows.Add("Step 4 (RELEASE DOCUMENTS)", starttime4, endtime4, drx1("namestp4").ToString, drx1("remstp4").ToString, drx1("comstp4").ToString)
                    End If

                    grddispatch.Rows(3).DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 128)
                Else
                    grddispatch.Rows.Add("Step 4 (RELEASE DOCUMENTS)", starttime4, "", "", drx1("remstp4").ToString, "")
                End If

                Dim starttime5 As String = ""
                If IsDBNull(drx1("startcash")) = False Then
                    starttime5 = Format(drx1("startcash"), "yyyy/MM/dd HH:mm")
                End If
                Dim endtime5 As String = ""
                If IsDBNull(drx1("datestp5")) = False Then
                    endtime5 = Format(drx1("datestp5"), "yyyy/MM/dd HH:mm")
                End If

                If drx1("step5") = 1 Then
                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                        grddispatch.Rows.Add("Step 5 (RELEASE PETTY CASH)", starttime5, endtime5, drx1("namestp5").ToString, drx1("remstp5").ToString & " " & des, drx1("comstp5").ToString)

                    ElseIf drx1("namestp5").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                        grddispatch.Rows.Add("Step 5 (RELEASE PETTY CASH)", des, des, des, drx1("remstp5").ToString, drx1("comstp5").ToString)

                    ElseIf drx1("namestp5").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp5") & " ( " & endtime5 & " )"
                        whatstep = "STEP 5"
                        If IsDBNull(drx1("timedep")) = False Then
                            whatstep = "DISPATCHED"
                        End If
                        grddispatch.Rows.Add("Step 5 (RELEASE PETTY CASH)", starttime5, endtime5, drx1("namestp5").ToString, drx1("remstp5").ToString, drx1("comstp5").ToString)
                    End If

                    grddispatch.Rows(4).DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 128)
                Else
                    grddispatch.Rows.Add("Step 5 (RELEASE PETTY CASH)", starttime5, "", "", drx1("remstp5").ToString, "")
                End If

                Dim starttime6 As String = ""
                If IsDBNull(drx1("timedep")) = False Then
                    starttime6 = Format(drx1("timedep"), "yyyy/MM/dd HH:mm")
                End If
                Dim endtime6 As String = ""
                If IsDBNull(drx1("datestp6")) = False Then
                    endtime6 = Format(drx1("datestp6"), "yyyy/MM/dd HH:mm")
                End If

                If drx1("step6") = 1 Then
                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                        grddispatch.Rows.Add("Step 6 (EXIT / RETURN)", starttime6, drx1("datestp6").ToString, drx1("namestp6").ToString, drx1("remstp6").ToString & " " & des, drx1("comstp6").ToString)

                    ElseIf drx1("namestp6").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                        grddispatch.Rows.Add("Step 6 (EXIT / RETURN)", des, des, des, drx1("remstp6").ToString, drx1("comstp6").ToString)

                    ElseIf drx1("namestp6").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp6") & " ( " & drx1("datestp6").ToString & " )"
                        whatstep = "STEP 6"
                        grddispatch.Rows.Add("Step 6 (EXIT / RETURN)", starttime6, Format(drx1("datestp6"), "yyyy/MM/dd HH:mm"), drx1("namestp6").ToString, drx1("remstp6").ToString, drx1("comstp6").ToString)
                        'grddispatch.Item(20, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                    End If

                    grddispatch.Rows(5).DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 128)
                Else
                    If IsDBNull(drx1("timedep")) = False Then
                        Dim depart As String = starttime6
                        grddispatch.Rows.Add("Step 6 (EXIT / RETURN)", depart, "", "", drx1("remstp6").ToString, drx1("comstp6").ToString)
                    Else
                        grddispatch.Rows.Add("Step 6 (EXIT / RETURN)", "", "", "", drx1("remstp6").ToString, "")
                    End If
                End If

                Dim starttime7 As String = ""
                If IsDBNull(drx1("startreturn")) = False Then
                    starttime7 = Format(drx1("startreturn"), "yyyy/MM/dd HH:mm")
                End If
                Dim endtime7 As String = ""
                If IsDBNull(drx1("datestp7")) = False Then
                    endtime7 = Format(drx1("datestp7"), "yyyy/MM/dd HH:mm")
                End If

                If drx1("step7") = 1 Then
                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                        grddispatch.Rows.Add("Step 7 (RETURN DOCUMENTS)", starttime7, endtime7, drx1("namestp7").ToString, drx1("remstp7").ToString & " " & des, drx1("comstp7").ToString)

                    ElseIf drx1("namestp7").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                        grddispatch.Rows.Add("Step 7 (RETURN DOCUMENTS)", des, des, des, drx1("remstp7").ToString, drx1("comstp7").ToString)

                    ElseIf drx1("namestp7").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp7") & " ( " & endtime7 & " )"
                        whatstep = "STEP 7"
                        grddispatch.Rows.Add("Step 7 (RETURN DOCUMENTS)", starttime7, endtime7, drx1("namestp7").ToString, drx1("remstp7").ToString, drx1("comstp7").ToString)
                    End If

                    grddispatch.Rows(6).DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 128)
                Else
                    grddispatch.Rows.Add("Step 7 (RETURN DOCUMENTS)", starttime7, "", "", drx1("remstp7").ToString, "")
                End If

                Dim starttime8 As String = ""
                If IsDBNull(drx1("startpost")) = False Then
                    starttime8 = Format(drx1("startpost"), "yyyy/MM/dd HH:mm")
                End If
                Dim endtime8 As String = ""
                If IsDBNull(drx1("datestp8")) = False Then
                    endtime8 = Format(drx1("datestp8"), "yyyy/MM/dd HH:mm")
                End If

                If drx1("step8") = 1 Then
                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                        grddispatch.Rows.Add("Step 8 (POST-INSPECTION)", starttime8, endtime8, drx1("namestp8").ToString, drx1("remstp8").ToString & " " & des, drx1("comstp8").ToString)

                    ElseIf drx1("namestp8").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                        grddispatch.Rows.Add("Step 8 (POST-INSPECTION)", des, des, des, drx1("remstp8").ToString, drx1("comstp8").ToString)

                    ElseIf drx1("namestp8").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp8") & " ( " & endtime8 & " )"
                        whatstep = "STEP 8"
                        grddispatch.Rows.Add("Step 8 (POST-INSPECTION)", starttime8, endtime8, drx1("namestp8").ToString, drx1("remstp8").ToString, drx1("comstp8").ToString)
                    End If

                    grddispatch.Rows(7).DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 128)
                Else
                    grddispatch.Rows.Add("Step 8 (POST-INSPECTION)", starttime8, "", "", drx1("remstp8").ToString, "")
                End If

                Dim starttime9 As String = ""
                If IsDBNull(drx1("startrecord")) = False Then
                    starttime9 = Format(drx1("startrecord"), "yyyy/MM/dd HH:mm")
                End If
                Dim endtime9 As String = ""
                If IsDBNull(drx1("datestp9")) = False Then
                    endtime9 = Format(drx1("datestp9"), "yyyy/MM/dd HH:mm")
                End If

                If drx1("step9") = 1 Then
                    If drx1("namestp9").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                        grddispatch.Rows.Add("Step 9 (RECORDING)", des, des, des, drx1("remstp9"), drx1("comstp9").ToString)

                    ElseIf drx1("namestp9").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp9") & " ( " & endtime9 & " )"
                        grddispatch.Rows.Add("Step 9 (RECORDING)", starttime9, endtime9, drx1("namestp9").ToString, drx1("remstp9").ToString, drx1("comstp9").ToString)

                    Else
                        des = ""
                        grddispatch.Rows.Add("Step 9 (RECORDING)", starttime9, des, des, drx1("remstp9").ToString, drx1("comstp9").ToString)
                    End If

                    whatstep = "COMPLETED"

                    grddispatch.Rows(8).DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 128)
                Else
                    grddispatch.Rows.Add("Step 9 (RECORDING)", starttime9, "", "", drx1("remstp9").ToString, "")
                End If
                ' grddispatch.Item(20, row.Index).Value = whatstep
            End If
            drx1.Dispose()
            cmdx1.Dispose()
            conn.Close()


            grdtrans.Rows.Clear()
            sql = "Select * from tbltripitems where tripnum='" & lbltripnum.Text & "'"
            connect()
            cmd1 = New SqlCommand(sql, conn)
            dr1 = cmd1.ExecuteReader
            While dr1.Read
                grdtrans.Rows.Add()
                grdtrans.Item(0, grdtrans.Rows.Count - 1).Value = dr1("tripid")
                grdtrans.Item(2, grdtrans.Rows.Count - 1).Value = dr1("transnum")
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            customer()

            grddispatch.ClearSelection()
            grddispatch.FirstDisplayedScrollingColumnIndex = grddispatch.Columns.Count - 1

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub destin()
        Try
            'truck type
            connect()
            sql = "Select * from tblgeneral where platenum='" & txtplate.Text & "' or vplate='" & txtplate.Text & "' or csticker='" & txtplate.Text & "'"
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                txttype.Text = dr("vtype")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            'destination
            connect()
            Dim temp As String = ""
            sql = "SELECT * FROM tbltripitems RIGHT OUTER JOIN tblortrans ON tbltripitems.transnum=tblortrans.transnum where tbltripitems.tripnum='" & lbltripnum.Text & "' and tbltripitems.status<>'0' and tbltripitems.status<>'3'"
            Dim cmd1x As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1x As SqlDataReader = cmd1x.ExecuteReader
            While dr1x.Read
                If temp = "" Then
                    temp = temp & dr1x("customer")
                Else
                    temp = temp & " / " & dr1x("customer")
                End If
            End While
            dr1x.Dispose()
            cmd1x.Dispose()
            conn.Close()

            If temp = "" Then
                temp = "Taxi"
            End If

            txtdes.Text = temp

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub customer()
        Try
            Me.Cursor = Cursors.WaitCursor

            For Each row As DataGridViewRow In grdtrans.Rows
                'MsgBox(grdtrans.Rows(row.Index).Cells(2).Value.ToString)
                sql = "Select * from tblortrans where transnum='" & grdtrans.Rows(row.Index).Cells(2).Value & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    Dim stat As String = ""
                    If dr("cancel") = 1 Then
                        stat = "Cancel"
                    ElseIf dr("status") = 1 Then
                        stat = "Available"
                    ElseIf dr("status") = 0 Then
                        stat = "In Process"
                    ElseIf dr("status") = 2 Then
                        stat = "Completed"
                    End If

                    grdtrans.Rows(row.Index).Cells(1).Value = Format(dr("deliverydate"), "yyyy/MM/dd")
                    grdtrans.Rows(row.Index).Cells(3).Value = dr("refnum")
                    grdtrans.Rows(row.Index).Cells(4).Value = dr("customer")
                    grdtrans.Rows(row.Index).Cells(5).Value = dr("transtype")
                    grdtrans.Rows(row.Index).Cells(6).Value = dr("arnum")
                    grdtrans.Rows(row.Index).Cells(7).Value = dr("rdrnum")
                    grdtrans.Rows(row.Index).Cells(8).Value = dr("drnum")
                    grdtrans.Rows(row.Index).Cells(9).Value = dr("dnnum")
                    grdtrans.Rows(row.Index).Cells(10).Value = dr("itrnum")
                    grdtrans.Rows(row.Index).Cells(11).Value = dr("itnum").ToString
                    grdtrans.Rows(row.Index).Cells(12).Value = dr("grponum").ToString
                    grdtrans.Rows(row.Index).Cells(13).Value = dr("cancel")
                    grdtrans.Rows(row.Index).Cells(14).Value = stat
                    grdtrans.Rows(row.Index).Cells(15).Value = dr("notes")
                    grdtrans.Rows(row.Index).Cells(16).Value = Format(dr("datecreated"), "yyyy/MM/dd HH:mm")
                    grdtrans.Rows(row.Index).Cells(17).Value = dr("createdby")
                    grdtrans.Rows(row.Index).Cells(18).Value = Format(dr("datemodified"), "yyyy/MM/dd HH:mm")
                    grdtrans.Rows(row.Index).Cells(19).Value = dr("modifiedby")
                    grdtrans.Rows(row.Index).Cells(20).Value = ""
                    grdtrans.Rows(row.Index).Cells(21).Value = ""
                    grdtrans.Rows(row.Index).Cells(22).Value = ""
                    grdtrans.Rows(row.Index).Cells(23).Value = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Next


            For Each row As DataGridViewRow In grdtrans.Rows
                sql = "Select * from tbltripitems where tripid='" & grdtrans.Rows(row.Index).Cells(0).Value & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    Dim stat As String = ""
                    '/MsgBox(dr("status").ToString)
                    If dr("status") = 0 Then
                        stat = "Cancel"
                        grdtrans.Rows(row.Index).Cells(14).Value = stat
                        grdtrans.Rows(row.Index).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                        grdtrans.Rows(row.Index).Cells(18).Value = Format(dr("canceldate"), "yyyy/MM/dd HH:mm")
                        grdtrans.Rows(row.Index).Cells(19).Value = dr("cancelby")

                    ElseIf dr("status") = 3 Then
                        stat = "Removed" 'remove from tripnum
                        grdtrans.Rows(row.Index).Cells(14).Value = stat
                        grdtrans.Rows(row.Index).DefaultCellStyle.BackColor = Color.Salmon
                        grdtrans.Rows(row.Index).Cells(18).Value = Format(dr("canceldate"), "yyyy/MM/dd HH:mm")
                        grdtrans.Rows(row.Index).Cells(19).Value = dr("cancelby")

                    ElseIf dr("status") = 4 Then
                        stat = "Rescheduled" 'resched from tripnum
                        grdtrans.Rows(row.Index).Cells(14).Value = stat
                        grdtrans.Rows(row.Index).DefaultCellStyle.BackColor = Color.Plum
                        grdtrans.Rows(row.Index).Cells(18).Value = Format(dr("canceldate"), "yyyy/MM/dd HH:mm")
                        grdtrans.Rows(row.Index).Cells(19).Value = dr("cancelby")

                    ElseIf dr("status") = 5 Then
                        stat = "For AR Credit Memo" 'credit memo from tripnum
                        grdtrans.Rows(row.Index).Cells(14).Value = stat
                        grdtrans.Rows(row.Index).DefaultCellStyle.BackColor = Color.Orange
                        grdtrans.Rows(row.Index).Cells(18).Value = Format(dr("canceldate"), "yyyy/MM/dd HH:mm")
                        grdtrans.Rows(row.Index).Cells(19).Value = dr("cancelby")

                    ElseIf dr("status") = 2 Then
                        stat = "Completed" 'credit memo from tripnum
                        grdtrans.Rows(row.Index).Cells(14).Value = stat
                        grdtrans.Rows(row.Index).Cells(22).Value = Format(dr("datemodified"), "yyyy/MM/dd HH:mm")
                        grdtrans.Rows(row.Index).Cells(23).Value = dr("modifiedby")
                    End If

                    If IsDBNull(dr("datecreated")) = False Then
                        grdtrans.Rows(row.Index).Cells(20).Value = Format(dr("datecreated"), "yyyy/MM/dd HH:mm")
                        grdtrans.Rows(row.Index).Cells(21).Value = dr("createdby")
                    End If
                    If IsDBNull(dr("alreadydisp")) = False Then
                        If dr("alreadydisp") = 1 Then 'departure
                            grdtrans.Item(20, row.Index).Style.BackColor = Color.FromArgb(192, 255, 255)
                            grdtrans.Item(21, row.Index).Style.BackColor = Color.FromArgb(192, 255, 255)
                        ElseIf dr("alreadydisp") = 2 Then 'arrival
                            grdtrans.Item(20, row.Index).Style.BackColor = Color.FromArgb(255, 224, 192)
                            grdtrans.Item(21, row.Index).Style.BackColor = Color.FromArgb(255, 224, 192)
                        End If
                    End If
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Next

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrans_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans.CellContentClick
        Try
            'link
            If e.ColumnIndex = 2 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdtrans.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrans.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdtrans.RowCount <> 0 Then
                    If grdtrans.Item(2, grdtrans.CurrentRow.Index).Value IsNot Nothing Then
                        'MsgBox(grdtrans.Item(12, ii).Value.ToString)
                        viewtrans.Text = "View Transaction"
                        viewtrans.grouptrans.Visible = False
                        viewtrans.lbltripnum.Text = lbltripnum.Text
                        viewtrans.txttrans.Text = grdtrans.Item(2, grdtrans.CurrentRow.Index).Value
                        viewtrans.sing = True
                        viewtrans.ShowDialog()
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grddispatch_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grddispatch.CellDoubleClick
        'check if selected cell=1 and what column index
        If grddispatch.SelectedCells.Count = 1 Then
            If e.RowIndex = 0 And e.ColumnIndex > -1 Then
                If Trim(grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString) <> "" Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "1"
                        viewstep1.Text = "View Step1 ( TRIP# " & lbltripnum.Text & " )"
                        viewstep1.lbltripnum1.Text = lbltripnum.Text
                        viewstep1.lblplate1.Text = txtplate.Text
                        viewstep1.lbltype1.Text = txttype.Text
                        viewstep1.txtdes.Text = txtdes.Text
                        viewstep1.finish()
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.RowIndex = 1 And e.ColumnIndex > -1 Then
                If Trim(grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString) <> "" Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "2"
                        viewstep1.Text = "View Step2 ( TRIP# " & lbltripnum.Text & " )"
                        viewstep1.lbltripnum1.Text = lbltripnum.Text
                        viewstep1.lblplate1.Text = txtplate.Text
                        viewstep1.lbltype1.Text = txttype.Text
                        viewstep1.txtdes.Text = txtdes.Text
                        viewstep1.finish()
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.RowIndex = 2 And e.ColumnIndex > -1 Then
                If Trim(grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString) <> "" Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "3"
                        viewstep1.Text = "View Step3 ( TRIP# " & lbltripnum.Text & " )"
                        viewstep1.lbltripnum1.Text = lbltripnum.Text
                        viewstep1.lblplate1.Text = txtplate.Text
                        viewstep1.lbltype1.Text = txttype.Text
                        viewstep1.txtdes.Text = txtdes.Text
                        viewstep1.finish()
                        viewstep1.ShowDialog()
                    End If
                End If

            ElseIf e.RowIndex = 3 And e.ColumnIndex > -1 Then
                If Trim(grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString) <> "" Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "4"
                        viewstep1.Text = "View Step4 ( TRIP# " & lbltripnum.Text & " )"
                        viewstep1.lbltripnum1.Text = lbltripnum.Text
                        viewstep1.lblplate1.Text = txtplate.Text
                        viewstep1.lbltype1.Text = txttype.Text
                        viewstep1.txtdes.Text = txtdes.Text
                        viewstep1.finish()
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.RowIndex = 4 And e.ColumnIndex > -1 Then
                If Trim(grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString) <> "" Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "5"
                        viewstep1.Text = "View Step5 ( TRIP# " & lbltripnum.Text & " )"
                        viewstep1.lbltripnum1.Text = lbltripnum.Text
                        viewstep1.lblplate1.Text = txtplate.Text
                        viewstep1.lbltype1.Text = txttype.Text
                        viewstep1.txtdes.Text = txtdes.Text
                        viewstep1.finish()
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.RowIndex = 5 And e.ColumnIndex > -1 Then
                If Trim(grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString) <> "" Or Trim(grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString) <> "" Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "6"
                        viewstep1.Text = "View Step6 ( TRIP# " & lbltripnum.Text & " )"
                        viewstep1.lbltripnum1.Text = lbltripnum.Text
                        viewstep1.lblplate1.Text = txtplate.Text
                        viewstep1.lbltype1.Text = txttype.Text
                        viewstep1.txtdes.Text = txtdes.Text
                        viewstep1.finish()
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.RowIndex = 6 And e.ColumnIndex > -1 Then
                If Trim(grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString) <> "" Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "7"
                        viewstep1.Text = "View Step7 ( TRIP# " & lbltripnum.Text & " )"
                        viewstep1.lbltripnum1.Text = lbltripnum.Text
                        viewstep1.lblplate1.Text = txtplate.Text
                        viewstep1.lbltype1.Text = txttype.Text
                        viewstep1.txtdes.Text = txtdes.Text
                        viewstep1.finish()
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.RowIndex = 7 And e.ColumnIndex > -1 Then
                If Trim(grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString) <> "" Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "8"
                        viewstep1.Text = "View Step8 ( TRIP# " & lbltripnum.Text & " )"
                        viewstep1.lbltripnum1.Text = lbltripnum.Text
                        viewstep1.lblplate1.Text = txtplate.Text
                        viewstep1.lbltype1.Text = txttype.Text
                        viewstep1.txtdes.Text = txtdes.Text
                        viewstep1.finish()
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.RowIndex = 8 And e.ColumnIndex > -1 Then
                If Trim(grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString) <> "" Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "9"
                        viewstep1.Text = "View Step9 ( TRIP# " & lbltripnum.Text & " )"
                        viewstep1.lbltripnum1.Text = lbltripnum.Text
                        viewstep1.lblplate1.Text = txtplate.Text
                        viewstep1.lbltype1.Text = txttype.Text
                        viewstep1.txtdes.Text = txtdes.Text
                        viewstep1.finish()
                        viewstep1.ShowDialog()
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub grddispatch_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grddispatch.CellContentClick

    End Sub

    Private Sub ViewEditReferenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewEditReferenceToolStripMenuItem.Click
        transoredit.lbltrans.Text = grdtrans.Item(2, selectedrow).Value
        transoredit.lblcus.Text = grdtrans.Item(4, selectedrow).Value
        transoredit.ShowDialog()
    End Sub

    Private Sub grdtrans_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdtrans.CellMouseClick
        If e.Button = Windows.Forms.MouseButtons.Right And e.RowIndex > -1 Then
            If e.ColumnIndex = 3 Then
                grdtrans.ClearSelection()
                grdtrans.Rows(e.RowIndex).Cells(3).Selected = True

                selectedrow = e.RowIndex

                Dim refnum As String = grdtrans.Rows(e.RowIndex).Cells(3).Value

                If refnum = "0000" Then
                    Exit Sub
                End If

                Me.ContextMenuStrip1.Show(Cursor.Position)
            End If
        End If
    End Sub

    Private Sub chkpup_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkpick.CheckedChanged
        If chkpick.Checked = True Then
            lblpick.Visible = True
        Else
            lblpick.Visible = False
        End If
    End Sub
End Class