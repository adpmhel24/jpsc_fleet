﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class trans
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(trans))
        Me.dateto = New System.Windows.Forms.DateTimePicker
        Me.Label2 = New System.Windows.Forms.Label
        Me.cmbcus = New System.Windows.Forms.ComboBox
        Me.datefrom = New System.Windows.Forms.DateTimePicker
        Me.Label1 = New System.Windows.Forms.Label
        Me.grdtrans = New System.Windows.Forms.DataGridView
        Me.btnview = New System.Windows.Forms.Button
        Me.btnsearch = New System.Windows.Forms.Button
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.cmbtype = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtsws = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.lblcount = New System.Windows.Forms.Label
        Me.btnprint = New System.Windows.Forms.Button
        Me.txtitr = New System.Windows.Forms.TextBox
        Me.txtpo = New System.Windows.Forms.TextBox
        Me.txtso = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.lbltrans = New System.Windows.Forms.Label
        Me.txttrans = New System.Windows.Forms.TextBox
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.EditTripToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditOrdersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CancelOrdersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column1 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column20 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn
        CType(Me.grdtrans, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dateto
        '
        Me.dateto.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.dateto.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dateto.Location = New System.Drawing.Point(135, 46)
        Me.dateto.Name = "dateto"
        Me.dateto.Size = New System.Drawing.Size(107, 21)
        Me.dateto.TabIndex = 21
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(106, 51)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(23, 15)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "To:"
        '
        'cmbcus
        '
        Me.cmbcus.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbcus.FormattingEnabled = True
        Me.cmbcus.Location = New System.Drawing.Point(330, 18)
        Me.cmbcus.Name = "cmbcus"
        Me.cmbcus.Size = New System.Drawing.Size(209, 23)
        Me.cmbcus.TabIndex = 19
        '
        'datefrom
        '
        Me.datefrom.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.datefrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datefrom.Location = New System.Drawing.Point(135, 16)
        Me.datefrom.Name = "datefrom"
        Me.datefrom.Size = New System.Drawing.Size(107, 21)
        Me.datefrom.TabIndex = 17
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(14, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(115, 15)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Date Created From:"
        '
        'grdtrans
        '
        Me.grdtrans.AllowUserToAddRows = False
        Me.grdtrans.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdtrans.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdtrans.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdtrans.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdtrans.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdtrans.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.grdtrans.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdtrans.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column4, Me.Column13, Me.Column1, Me.Column2, Me.Column3, Me.Column5, Me.Column8, Me.Column9, Me.Column10, Me.Column12, Me.Column11, Me.Column19, Me.Column20, Me.Column7, Me.Column17, Me.Column6, Me.Column18, Me.Column14, Me.Column15, Me.Column16})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans.DefaultCellStyle = DataGridViewCellStyle3
        Me.grdtrans.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdtrans.EnableHeadersVisualStyles = False
        Me.grdtrans.GridColor = System.Drawing.Color.Salmon
        Me.grdtrans.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdtrans.Location = New System.Drawing.Point(17, 79)
        Me.grdtrans.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdtrans.Name = "grdtrans"
        Me.grdtrans.ReadOnly = True
        Me.grdtrans.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.grdtrans.RowHeadersWidth = 15
        Me.grdtrans.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.NullValue = Nothing
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans.RowsDefaultCellStyle = DataGridViewCellStyle5
        Me.grdtrans.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrans.Size = New System.Drawing.Size(1160, 455)
        Me.grdtrans.TabIndex = 15
        '
        'btnview
        '
        Me.btnview.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnview.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.btnview.Image = CType(resources.GetObject("btnview.Image"), System.Drawing.Image)
        Me.btnview.Location = New System.Drawing.Point(990, 47)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(187, 23)
        Me.btnview.TabIndex = 14
        Me.btnview.Text = "View All Available"
        Me.btnview.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnview.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnview.UseVisualStyleBackColor = True
        '
        'btnsearch
        '
        Me.btnsearch.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnsearch.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.btnsearch.Image = CType(resources.GetObject("btnsearch.Image"), System.Drawing.Image)
        Me.btnsearch.Location = New System.Drawing.Point(990, 17)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(91, 23)
        Me.btnsearch.TabIndex = 12
        Me.btnsearch.Text = "Search"
        Me.btnsearch.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnsearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label6.Location = New System.Drawing.Point(262, 21)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 15)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Recipient:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label5.Location = New System.Drawing.Point(578, 21)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(85, 15)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Transaction #:"
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.Controls.Add(Me.cmbtype)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.txtsws)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.lblcount)
        Me.Panel1.Controls.Add(Me.btnprint)
        Me.Panel1.Controls.Add(Me.txtitr)
        Me.Panel1.Controls.Add(Me.txtpo)
        Me.Panel1.Controls.Add(Me.txtso)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.lbltrans)
        Me.Panel1.Controls.Add(Me.txttrans)
        Me.Panel1.Controls.Add(Me.grdtrans)
        Me.Panel1.Controls.Add(Me.dateto)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.cmbcus)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.datefrom)
        Me.Panel1.Controls.Add(Me.btnsearch)
        Me.Panel1.Controls.Add(Me.btnview)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1194, 571)
        Me.Panel1.TabIndex = 3
        '
        'cmbtype
        '
        Me.cmbtype.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbtype.FormattingEnabled = True
        Me.cmbtype.Location = New System.Drawing.Point(330, 76)
        Me.cmbtype.Name = "cmbtype"
        Me.cmbtype.Size = New System.Drawing.Size(112, 23)
        Me.cmbtype.TabIndex = 35
        Me.cmbtype.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label9.Location = New System.Drawing.Point(221, 79)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(103, 15)
        Me.Label9.TabIndex = 34
        Me.Label9.Text = "Transaction Type:"
        Me.Label9.Visible = False
        '
        'txtsws
        '
        Me.txtsws.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtsws.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.txtsws.Location = New System.Drawing.Point(876, 48)
        Me.txtsws.Name = "txtsws"
        Me.txtsws.Size = New System.Drawing.Size(112, 21)
        Me.txtsws.TabIndex = 33
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label8.Location = New System.Drawing.Point(812, 51)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(66, 15)
        Me.Label8.TabIndex = 32
        Me.Label8.Text = "Ref SWS#:"
        '
        'lblcount
        '
        Me.lblcount.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.lblcount.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcount.Location = New System.Drawing.Point(0, 546)
        Me.lblcount.Name = "lblcount"
        Me.lblcount.Size = New System.Drawing.Size(1194, 25)
        Me.lblcount.TabIndex = 31
        Me.lblcount.Text = "Count:"
        '
        'btnprint
        '
        Me.btnprint.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnprint.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.btnprint.Image = CType(resources.GetObject("btnprint.Image"), System.Drawing.Image)
        Me.btnprint.Location = New System.Drawing.Point(1087, 17)
        Me.btnprint.Name = "btnprint"
        Me.btnprint.Size = New System.Drawing.Size(90, 23)
        Me.btnprint.TabIndex = 30
        Me.btnprint.Text = "Export"
        Me.btnprint.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnprint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnprint.UseVisualStyleBackColor = True
        '
        'txtitr
        '
        Me.txtitr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtitr.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.txtitr.Location = New System.Drawing.Point(692, 48)
        Me.txtitr.Name = "txtitr"
        Me.txtitr.Size = New System.Drawing.Size(112, 21)
        Me.txtitr.TabIndex = 29
        '
        'txtpo
        '
        Me.txtpo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtpo.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.txtpo.Location = New System.Drawing.Point(510, 48)
        Me.txtpo.Name = "txtpo"
        Me.txtpo.Size = New System.Drawing.Size(112, 21)
        Me.txtpo.TabIndex = 28
        '
        'txtso
        '
        Me.txtso.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtso.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.txtso.Location = New System.Drawing.Point(330, 48)
        Me.txtso.Name = "txtso"
        Me.txtso.Size = New System.Drawing.Size(112, 21)
        Me.txtso.TabIndex = 27
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label7.Location = New System.Drawing.Point(628, 51)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 15)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "Ref ITR#:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label4.Location = New System.Drawing.Point(448, 51)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 15)
        Me.Label4.TabIndex = 25
        Me.Label4.Text = "Ref PO#:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label3.Location = New System.Drawing.Point(268, 51)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 15)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Ref SO#:"
        '
        'lbltrans
        '
        Me.lbltrans.AutoSize = True
        Me.lbltrans.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.lbltrans.Location = New System.Drawing.Point(663, 22)
        Me.lbltrans.Name = "lbltrans"
        Me.lbltrans.Size = New System.Drawing.Size(48, 15)
        Me.lbltrans.TabIndex = 23
        Me.lbltrans.Text = "O.MNL-"
        '
        'txttrans
        '
        Me.txttrans.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txttrans.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.txttrans.Location = New System.Drawing.Point(717, 19)
        Me.txttrans.Name = "txttrans"
        Me.txttrans.Size = New System.Drawing.Size(161, 21)
        Me.txttrans.TabIndex = 22
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditTripToolStripMenuItem, Me.EditOrdersToolStripMenuItem, Me.CancelOrdersToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(174, 70)
        '
        'EditTripToolStripMenuItem
        '
        Me.EditTripToolStripMenuItem.Image = CType(resources.GetObject("EditTripToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditTripToolStripMenuItem.Name = "EditTripToolStripMenuItem"
        Me.EditTripToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.EditTripToolStripMenuItem.Text = "Edit Transaction"
        Me.EditTripToolStripMenuItem.Visible = False
        '
        'EditOrdersToolStripMenuItem
        '
        Me.EditOrdersToolStripMenuItem.Image = CType(resources.GetObject("EditOrdersToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditOrdersToolStripMenuItem.Name = "EditOrdersToolStripMenuItem"
        Me.EditOrdersToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.EditOrdersToolStripMenuItem.Text = "Edit Orders"
        '
        'CancelOrdersToolStripMenuItem
        '
        Me.CancelOrdersToolStripMenuItem.Image = CType(resources.GetObject("CancelOrdersToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CancelOrdersToolStripMenuItem.Name = "CancelOrdersToolStripMenuItem"
        Me.CancelOrdersToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.CancelOrdersToolStripMenuItem.Text = "Cancel Transaction"
        '
        'Column4
        '
        Me.Column4.HeaderText = "ID"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Visible = False
        '
        'Column13
        '
        Me.Column13.HeaderText = "Date Booked"
        Me.Column13.Name = "Column13"
        Me.Column13.ReadOnly = True
        '
        'Column1
        '
        Me.Column1.HeaderText = "Transaction #"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column1.Width = 130
        '
        'Column2
        '
        Me.Column2.HeaderText = "Reference #"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 130
        '
        'Column3
        '
        Me.Column3.HeaderText = "Recipient"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 200
        '
        'Column5
        '
        Me.Column5.HeaderText = "Transaction Type"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Width = 280
        '
        'Column8
        '
        Me.Column8.HeaderText = "AR#"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'Column9
        '
        Me.Column9.HeaderText = "RDR#"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        '
        'Column10
        '
        Me.Column10.HeaderText = "DR#"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        '
        'Column12
        '
        Me.Column12.HeaderText = "DN#"
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        '
        'Column11
        '
        Me.Column11.HeaderText = "ITR#"
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        '
        'Column19
        '
        Me.Column19.HeaderText = "IT#"
        Me.Column19.Name = "Column19"
        Me.Column19.ReadOnly = True
        '
        'Column20
        '
        Me.Column20.HeaderText = "GRPO#"
        Me.Column20.Name = "Column20"
        Me.Column20.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.HeaderText = "Cancel"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Visible = False
        '
        'Column17
        '
        Me.Column17.HeaderText = "Status"
        Me.Column17.Name = "Column17"
        Me.Column17.ReadOnly = True
        '
        'Column6
        '
        Me.Column6.HeaderText = "Notes"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        Me.Column6.Width = 300
        '
        'Column18
        '
        Me.Column18.HeaderText = "Date Created"
        Me.Column18.Name = "Column18"
        Me.Column18.ReadOnly = True
        '
        'Column14
        '
        Me.Column14.HeaderText = "Created by"
        Me.Column14.Name = "Column14"
        Me.Column14.ReadOnly = True
        '
        'Column15
        '
        Me.Column15.HeaderText = "Date Modified"
        Me.Column15.Name = "Column15"
        Me.Column15.ReadOnly = True
        '
        'Column16
        '
        Me.Column16.HeaderText = "Modified by"
        Me.Column16.Name = "Column16"
        Me.Column16.ReadOnly = True
        '
        'trans
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1194, 571)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "trans"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Transaction Summary"
        CType(Me.grdtrans, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnview As System.Windows.Forms.Button
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents grdtrans As System.Windows.Forms.DataGridView
    Friend WithEvents datefrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbcus As System.Windows.Forms.ComboBox
    Friend WithEvents dateto As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents EditTripToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txttrans As System.Windows.Forms.TextBox
    Friend WithEvents lbltrans As System.Windows.Forms.Label
    Friend WithEvents EditOrdersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CancelOrdersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txtitr As System.Windows.Forms.TextBox
    Friend WithEvents txtpo As System.Windows.Forms.TextBox
    Friend WithEvents txtso As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnprint As System.Windows.Forms.Button
    Friend WithEvents lblcount As System.Windows.Forms.Label
    Friend WithEvents txtsws As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cmbtype As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column16 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
