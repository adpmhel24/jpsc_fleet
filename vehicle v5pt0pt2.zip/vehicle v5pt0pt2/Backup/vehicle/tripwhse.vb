﻿Public Class tripwhse

    Private Sub tripwhse_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        
    End Sub

    Private Sub tripwhse_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Trim(cmbwhse.Text) <> "" Then
            tripdispatch.arrwhse = cmbwhse.Text
            Me.Dispose()
        Else
            MsgBox("Select warehouse.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        tripdispatch.arrwhse = ""
        Me.Dispose()
    End Sub
End Class