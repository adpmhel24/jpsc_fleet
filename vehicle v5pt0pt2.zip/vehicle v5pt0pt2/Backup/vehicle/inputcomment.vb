﻿Public Class inputcomment
    Public cncel As Boolean, cnn As Boolean = False

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        
        cncel = False
        tripdispatchsum.tip = Trim(box.Text)
        Me.Close()
        tripdispatchsum.Show()
    End Sub

    Private Sub box_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles box.KeyPress
        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 Then
            If Asc(e.KeyChar) = 39 Then
                e.Handled = True
            End If
        End If
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            Button1.PerformClick()
        End If
    End Sub

    Private Sub inputcalamba_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed

    End Sub

    Private Sub inputcalamba_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        cncel = True
        '/tripdispatchsum.ccel = cncel
        Me.Close()
    End Sub

    Private Sub inputcomment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class