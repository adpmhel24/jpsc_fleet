﻿Imports System.IO
Imports System.Data.SqlClient

Public Class tripcancel
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public canceltrans As Boolean = False, cancelreason As String

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub tripcancel_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        viewtranscancel()
        grdadd.Columns(2).ReadOnly = True
        grdadd.Columns(3).ReadOnly = True
        grdadd.Columns(4).ReadOnly = True
        grdadd.Columns(5).ReadOnly = True
        grdadd.Columns(6).ReadOnly = True
    End Sub

    Public Sub viewtranscancel()
        Try
            grdadd.Rows.Clear()
            Dim ctr As Integer = 0

            sql = "SELECT tblortrans.cancel, tblortrans.status, tblortrans.transid, tblortrans.transnum, tblortrans.refnum, tblortrans.datecreated, tblortrans.customer, tblortrans.transtype, tblortrans.notes, tbltripitems.tripid FROM tbltripitems RIGHT OUTER JOIN tblortrans ON tbltripitems.transnum=tblortrans.transnum where tbltripitems.tripnum='" & lbltripnum.Text & "' and tbltripitems.status<>'3'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                Dim stat As String = ""
                Dim cancel As Integer = 0
                If dr("cancel") = 1 Then
                    stat = "Cancelled"
                ElseIf dr("status") = 1 Then
                    stat = "Available"
                ElseIf dr("status") = 0 Then
                    stat = "In Process"
                ElseIf dr("status") = 2 Then
                    stat = "Completed"
                End If

                grdadd.Rows.Add(dr("transid"), False, dr("transnum"), dr("refnum"), dr("datecreated"), dr("customer"), dr("transtype"), stat, dr("notes"), dr("tripid"))
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(ctr).Cells(1), DataGridViewCheckBoxCell)
                checkCell.Value = False
                ctr += 1

            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdadd_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdadd.CellContentClick
        Try
            'checkbox
            If grdadd.CurrentCell.ColumnIndex = 1 Then
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(grdadd.CurrentRow.Index).Cells(1), DataGridViewCheckBoxCell)
                Button1.PerformClick()
                If checkCell.Value = True And grdadd.Rows(grdadd.CurrentRow.Index).Cells(7).Value = "Cancelled" Then
                    MsgBox("Cannot select transaction with cancelled status.", MsgBoxStyle.Exclamation, "")
                    checkCell.Value = False
                ElseIf checkCell.Value = True And grdadd.Rows(grdadd.CurrentRow.Index).Cells(7).Value <> "Cancelled" Then
                    checkCell.Value = True
                End If
            End If

            'link
            If e.ColumnIndex = 2 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdadd.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdadd.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdadd.RowCount <> 0 Then
                    If grdadd.Item(2, grdadd.CurrentRow.Index).Value IsNot Nothing Then
                        'MsgBox(grdadd.Item(12, ii).Value.ToString)
                        viewtrans.txttrans.Text = grdadd.Item(2, grdadd.CurrentRow.Index).Value
                        viewtrans.ShowDialog()
                    End If
                End If
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        Try
            'Dim a As String = MsgBox("Are you sure you want to cancel transactions?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
            'If a = vbYes Then
            Dim meron As Boolean = False

            'tignan sa tbltripitems kung lahat ng status is zero if ganung cancel ung buong trip
            connect()
            For Each row As DataGridViewRow In grdadd.Rows
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                'Button1.PerformClick()
                If checkCell.Value = True Then
                    meron = True
                End If

                If checkCell.Value = True And grdadd.Rows(row.Index).Cells(7).Value <> "In Process" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot cancel Transaction# " & grdadd.Rows(row.Index).Cells(2).Value & ".", MsgBoxStyle.Critical, "")
                    grdadd.Rows(row.Index).Cells(1).Value = False
                    meron = False
                End If
            Next

            If meron = True Then
                canceltrans = False
                confirm.ShowDialog()
                If canceltrans = True Then

                    'tignan sa tbltripitems kung lahat ng status is zero if ganung cancel ung buong trip
                    For Each row As DataGridViewRow In grdadd.Rows
                        Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                        'Button1.PerformClick()
                        If checkCell.Value = True Then
                            meron = True

                            sql = "Update tblortrans set cancel='1' where transnum='" & grdadd.Rows(row.Index).Cells(2).Value & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            sql = "Update tbltripitems set status='0', cancelby='" & login.cashier & "', canceldate=GetDate() where transnum='" & grdadd.Rows(row.Index).Cells(2).Value & "' and tripnum='" & lbltripnum.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            MsgBox("Successfully cancelled transaction # " & grdadd.Rows(row.Index).Cells(2).Value & ".", MsgBoxStyle.Information, "")
                        End If
                    Next

                    If meron = True Then
                        'MsgBox("Successfully cancelled.", MsgBoxStyle.Information, "")
                        viewtranscancel()
                    Else
                        MsgBox("Select transactions to be cancelled.", MsgBoxStyle.Information, "")
                    End If

                    Dim ndelahatcancel As Boolean = False
                    'check tbltripitems if all transnum status is cancelled
                    sql = "Select * from tbltripitems where tripnum='" & lbltripnum.Text & "' and status='1'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    While dr.Read
                        ndelahatcancel = True
                    End While
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    If ndelahatcancel = False And btncanceltrip.Enabled = True Then
                        'update tbltripsum status into 3 meaning cancelled trip and all the transactions
                        '/ sql = "Update tbltripsum set status='3' where tripnum='" & lbltripnum.Text & "'"
                        '/ connect()
                        '/ cmd = New SqlCommand(sql, conn)
                        '/ cmd.ExecuteNonQuery()
                        '/ cmd.Dispose()
                    End If

                    If btncanceltrip.Enabled = False Then
                        'update yung step 7 return documents if nde pa sya confirm
                        Dim ndepaconfirm As Boolean = False
                        sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            If dr("step7") = 0 Then
                                ndepaconfirm = True
                            End If
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()
                    End If
                End If
            Else
                MsgBox("No transaction selected.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncanceltrip_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncanceltrip.Click
        Try
            'Dim a As String = MsgBox("Are you sure you want to cancel transactions?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
            'If a = vbYes Then
            'lagay ng reasons bakit kelangan i cancel
            cancelreason = ""
            tripcancelreason.ShowDialog()
            If cancelreason <> "" Then
                canceltrans = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If canceltrans = True Then
                    ExecuteCancelTripOnly(strconn)
                End If
            Else
                MsgBox("User cancelled cancelling trip.", MsgBoxStyle.Information, "")
            End If

            
            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteCancelTripOnly(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            ' Start a local transaction
            transaction = connection.BeginTransaction("CancelTripOnlyTransaction")

            ' Must assign both transaction object and connection 
            ' to Command object for a pending local transaction.
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor

                'tignan sa tbltripitems kung lahat ng status is zero if ganun taxi na sya
                For Each row As DataGridViewRow In grdadd.Rows
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                    'Button1.PerformClick()
                    If grdadd.Rows(row.Index).Cells(7).Value = "In Process" Then
                        Dim doublecreate As Boolean = False
                        sql = "Select tripid from tbltripitems where transnum='" & grdadd.Rows(row.Index).Cells(2).Value & "' and status='1' and tripid<>'" & grdadd.Rows(row.Index).Cells(9).Value & "'"
                        command.CommandText = sql
                        dr = command.ExecuteReader
                        If dr.Read Then
                            doublecreate = True
                        End If
                        dr.Dispose()
                        '/cmd.Dispose()
                        '/conn.Close()

                        If doublecreate = False Then
                            sql = "Update tblortrans set status='1' where transnum='" & grdadd.Rows(row.Index).Cells(2).Value & "'"
                            command.CommandText = sql
                            command.ExecuteNonQuery()
                        End If
                    End If

                    sql = "Update tbltripitems set status='0', cancelby='" & login.cashier & "', canceldate=GetDate() where tripid='" & grdadd.Rows(row.Index).Cells(9).Value & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                Next

                'update tbltrip sum status into 3 meaning cancelled trip and all the transactions
                sql = "Update tbltripsum set status='3', creason='" & cancelreason & "', datecancelled=GetDate(), cancelledby='" & login.cashier & "' where tripnum='" & lbltripnum.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully cancelled.", MsgBoxStyle.Information, "")
                viewtranscancel()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                '/Console.WriteLine("Commit Exception Type: {0}", ex.GetType())
                '/Console.WriteLine("  Message: {0}", ex.Message)
                '/Dim typeName = ex.GetType().Name
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    ' This catch block will handle any errors that may have occurred 
                    ' on the server that would cause the rollback to fail, such as 
                    ' a closed connection.
                    Me.Cursor = Cursors.Default
                    '/Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType())
                    '/Console.WriteLine("  Message: {0}", ex2.Message)
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Click Cancel Trip Only again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btnremove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnremove.Click
        Try
            'Dim a As String = MsgBox("Are you sure you want to cancel transactions?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
            'If a = vbYes Then
            Dim meron As Boolean = False

            'tignan sa tbltripitems kung lahat ng status is zero if ganung cancel ung buong trip
            For Each row As DataGridViewRow In grdadd.Rows
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                'Button1.PerformClick()
                If checkCell.Value = True Then
                    meron = True
                End If

                If checkCell.Value = True And grdadd.Rows(row.Index).Cells(7).Value <> "In Process" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot remove Transaction# " & grdadd.Rows(row.Index).Cells(2).Value & ".", MsgBoxStyle.Critical, "")
                    grdadd.Rows(row.Index).Cells(1).Value = False
                    meron = False
                End If
            Next

            If meron = True Then
                canceltrans = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If canceltrans = True Then

                    If lblreturn.Text = "Returned" Then
                        '/ExecuteReschedReturn(strconn)
                    Else
                        'not yet dispatched
                        ExecuteReschedNotDepart(strconn)
                    End If
                End If
            Else
                MsgBox("No transaction selected.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteReschedReturn(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            ' Start a local transaction
            transaction = connection.BeginTransaction("ReschedReturnTransaction")

            ' Must assign both transaction object and connection 
            ' to Command object for a pending local transaction.
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                
                'arrived
                For Each row As DataGridViewRow In grdadd.Rows
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                    'Button1.PerformClick()
                    If checkCell.Value = True Then

                        sql = "Update tblortrans set status='1' where transnum='" & grdadd.Rows(row.Index).Cells(2).Value & "'"
                        command.CommandText = sql
                        command.ExecuteNonQuery()

                        sql = "Update tbltripitems set status='0', cancelby='" & login.cashier & "', canceldate=GetDate() where transnum='" & grdadd.Rows(row.Index).Cells(2).Value & "' and tripnum='" & lbltripnum.Text & "'"
                        command.CommandText = sql
                        command.ExecuteNonQuery()
                    End If
                Next

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully removed transaction(s).", MsgBoxStyle.Information, "")
                viewtranscancel()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                '/Console.WriteLine("Commit Exception Type: {0}", ex.GetType())
                '/Console.WriteLine("  Message: {0}", ex.Message)
                '/Dim typeName = ex.GetType().Name
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    ' This catch block will handle any errors that may have occurred 
                    ' on the server that would cause the rollback to fail, such as 
                    ' a closed connection.
                    Me.Cursor = Cursors.Default
                    '/Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType())
                    '/Console.WriteLine("  Message: {0}", ex2.Message)
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Click Reschedule to other Trip again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub ExecuteReschedNotDepart(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            ' Start a local transaction
            transaction = connection.BeginTransaction("ReschedNotDepartTransaction")

            ' Must assign both transaction object and connection 
            ' to Command object for a pending local transaction.
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor

                For Each row As DataGridViewRow In grdadd.Rows
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                    'Button1.PerformClick()
                    If checkCell.Value = True Then
                        sql = "Update tblortrans set status='1' where transnum='" & grdadd.Rows(row.Index).Cells(2).Value & "'"
                        command.CommandText = sql
                        command.ExecuteNonQuery()

                        sql = "Update tbltripitems set status='3', cancelby='" & login.cashier & "', canceldate=GetDate() where transnum='" & grdadd.Rows(row.Index).Cells(2).Value & "' and tripnum='" & lbltripnum.Text & "'"
                        command.CommandText = sql
                        command.ExecuteNonQuery()
                    End If
                Next

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully removed transaction(s).", MsgBoxStyle.Information, "")
                viewtranscancel()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                '/Console.WriteLine("Commit Exception Type: {0}", ex.GetType())
                '/Console.WriteLine("  Message: {0}", ex.Message)
                '/Dim typeName = ex.GetType().Name
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    ' This catch block will handle any errors that may have occurred 
                    ' on the server that would cause the rollback to fail, such as 
                    ' a closed connection.
                    Me.Cursor = Cursors.Default
                    '/Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType())
                    '/Console.WriteLine("  Message: {0}", ex2.Message)
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Click Reschedule to other Trip again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btnresched_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreschedule.Click
        Try
            'Dim a As String = MsgBox("Are you sure you want to cancel transactions?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
            'If a = vbYes Then
            Dim meron As Boolean = False

            'tignan sa tbltripitems kung lahat ng status is zero if ganung cancel ung buong trip
            For Each row As DataGridViewRow In grdadd.Rows
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                'Button1.PerformClick()
                If checkCell.Value = True Then
                    meron = True
                End If

                If checkCell.Value = True And grdadd.Rows(row.Index).Cells(7).Value <> "In Process" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot cancel for reschedule Transaction# " & grdadd.Rows(row.Index).Cells(2).Value & ".", MsgBoxStyle.Critical, "")
                    grdadd.Rows(row.Index).Cells(1).Value = False
                    meron = False
                End If
            Next

            If meron = True Then
                canceltrans = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If canceltrans = True Then

                    'tignan sa tbltripitems kung lahat ng status is zero if ganung cancel ung buong trip
                    For Each row As DataGridViewRow In grdadd.Rows
                        Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                        'Button1.PerformClick()
                        If checkCell.Value = True Then
                            meron = True

                            sql = "Update tblortrans set status='1' where transnum='" & grdadd.Rows(row.Index).Cells(2).Value & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            sql = "Update tbltripitems set status='0', cancelby='" & login.cashier & "', canceldate=GetDate() where transnum='" & grdadd.Rows(row.Index).Cells(2).Value & "' and tripnum='" & lbltripnum.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            MsgBox("Successfully cancelled for reschedule transaction # " & grdadd.Rows(row.Index).Cells(2).Value & ".", MsgBoxStyle.Information, "")
                        End If
                    Next

                    If meron = True Then
                        'MsgBox("Successfully cancelled.", MsgBoxStyle.Information, "")
                        viewtranscancel()
                    Else
                        MsgBox("Select transactions to be cancelled.", MsgBoxStyle.Information, "")
                    End If

                    Dim ndelahatcancel As Boolean = False
                    'check tbltripitems if all transnum status is cancelled
                    sql = "Select * from tbltripitems where tripnum='" & lbltripnum.Text & "' and status='1'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    While dr.Read
                        ndelahatcancel = True
                    End While
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    If ndelahatcancel = False And btncanceltrip.Enabled = True Then
                        'update tbltripsum status into 3 meaning cancelled trip and all the transactions
                        '/ sql = "Update tbltripsum set status='3' where tripnum='" & lbltripnum.Text & "'"
                        '/ connect()
                        '/ cmd = New SqlCommand(sql, conn)
                        '/ cmd.ExecuteNonQuery()
                        '/ cmd.Dispose()
                    End If

                    If btncanceltrip.Enabled = False Then
                        'update yung step 7 return documents if nde pa sya confirm
                        Dim ndepaconfirm As Boolean = False
                        sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            If dr("step7") = 0 Then
                                ndepaconfirm = True
                            End If
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()
                    End If
                End If
            Else
                MsgBox("No transaction selected.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try
            'cancel sa tripitems then sa tblortrans
            'check pa ba ung may ibng tripnumber na 


        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class