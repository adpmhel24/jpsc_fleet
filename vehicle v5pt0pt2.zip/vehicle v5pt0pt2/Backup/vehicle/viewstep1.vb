﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Drawing.Image
Imports System.ComponentModel
Imports System.Net.NetworkInformation
Imports System.Globalization

Public Class viewstep1
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Dim ofdstp1 As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim picstp1 As PictureBox, meronstp1 As Boolean = False

    Dim tip As String, stp As String, selectedrow As Integer
    Public cnfcom As Boolean = False
    Dim culture As CultureInfo = Nothing
    Public comstat As Integer = 2, edited As Boolean = False

    Dim bgw As BackgroundWorker, threadEnabled As Boolean = False, panelsql As String
    Dim wid As Int32, widlbl As Int32
    Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer
    Dim linkcheck As Boolean = False

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Private Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub viewstep1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        lbltripnum1.Text = ""
        lblplate1.Text = ""
        lbltype1.Text = ""
        lblstart.Text = ""
        lblsave.Text = ""
        lblfinish.Text = ""
        lblstartby.Text = ""
        lblsaveby.Text = ""
        lblfinishby.Text = ""
        txtrescue.Text = ""
        txtrems.Text = ""
        txtcomment.Text = ""
        txtimg1.Text = ""
        txtdes.Text = ""
        txtlabor.Text = ""
        lblimgdate1.Text = ""
        lblimgname1.Text = ""
        imgbox1.Image = Nothing

        grdtrans4.Rows.Clear()

        imgpanel1.Visible = False
        imgpanel1.Controls.Clear()
        imgpanel1.Visible = True

        txtcomment.ReadOnly = True
        btncomment.Text = "Edit Comment"
        picinfo.Visible = False
        picwarn.Visible = False
        rbok.Visible = False
        rbwarn.Visible = False

        'Stop background operation
        bgw.CancelAsync()
    End Sub

    Private Sub viewstep1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        culture = CultureInfo.CreateSpecificCulture("en-US")
        ExecuteView(strconn)
        tripinfo()
        refreshimg()
        linkcheck = False
    End Sub

    Private Sub viewstep1_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        
    End Sub

    Private Sub btnimgrefresh1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrefresh1.Click
        refreshimg()
    End Sub

    Public Sub refreshimg()
        Try
            Me.Cursor = Cursors.WaitCursor
            
            meronstp1 = False
            imgpanel1.Visible = False
            imgpanel1.Controls.Clear()
            imgpanel1.Visible = True

            wid = 0
            widlbl = 0
            temp = 0
            y = 0
            mody = 0
            row = 0

            Dim ctr As Integer = 0
            stp = lblstep.Text

            bgw = New BackgroundWorker()

            AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
            AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
            AddHandler bgw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not bgw.IsBusy Then
                lblloading.Visible = True
                '/Panel1.Enabled = False
                '/ProgressBar1.Visible = True
                '/ProgressBar1.Minimum = 0
                bgw.WorkerReportsProgress = True
                bgw.WorkerSupportsCancellation = True
                bgw.RunWorkerAsync() 'start ng select query
            End If

            imgbox1.Image = Nothing
            txtimg1.Text = ""
            lblimgid1.Text = ""

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub bgw_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabled = True
        
        Dim imgtag As String = ""
        If stp = "1" Then
            sql = "Select * from tbldispatchstp1 where tripnum='" & lbltripnum1.Text & "'"
        ElseIf stp = "2" Then
            sql = "Select * from tbldispatchstp2 where tripnum='" & lbltripnum1.Text & "'"
        ElseIf stp = "3" Then
            sql = "Select * from tbldispatchstp3 where tripnum='" & lbltripnum1.Text & "'"
        ElseIf stp = "4" Then
            sql = "Select * from tbldispatchstp4 where tripnum='" & lbltripnum1.Text & "'"
        ElseIf stp = "5" Then
            sql = "Select * from tbldispatchstp5 where tripnum='" & lbltripnum1.Text & "'"
        ElseIf stp = "6" Then
            sql = "Select * from tbldispatchstp6 where tripnum='" & lbltripnum1.Text & "'"
        ElseIf stp = "7" Then
            sql = "Select * from tbldispatchstp7 where tripnum='" & lbltripnum1.Text & "'"
        ElseIf stp = "8" Then
            sql = "Select * from tbldispatchstp8 where tripnum='" & lbltripnum1.Text & "'"
        ElseIf stp = "9" Then
            sql = "Select * from tbldispatchstp9 where tripnum='" & lbltripnum1.Text & "'"
        End If
        panelsql = sql

        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If

        cmd = New SqlCommand(panelsql, connection)
        dr = cmd.ExecuteReader
        While dr.Read
            meronstp1 = True

            Dim data As Byte() = DirectCast(dr("img"), Byte())
            Dim ms As New MemoryStream(data)

            If stp = "1" Then
                imgtag = dr("stp1imgid")
            ElseIf stp = "2" Then
                imgtag = dr("stp2imgid")
            ElseIf stp = "3" Then
                imgtag = dr("stp3imgid")
            ElseIf stp = "4" Then
                imgtag = dr("stp4imgid")
            ElseIf stp = "5" Then
                imgtag = dr("stp5imgid")
            ElseIf stp = "6" Then
                imgtag = dr("stp6imgid")
            ElseIf stp = "7" Then
                imgtag = dr("stp7imgid")
            ElseIf stp = "8" Then
                imgtag = dr("stp8imgid")
            ElseIf stp = "9" Then
                imgtag = dr("stp9imgid")
            End If

            If imgpanel1.InvokeRequired Then
                imgpanel1.Invoke(m_addRowDelegate, ms, imgtag, dr("name"))
            Else
                AddDGVRow(ms, imgtag, dr("name"))
            End If
        End While
        dr.Dispose()
        cmd.Dispose()
        connection.Close()
    End Sub

    Delegate Sub AddRowDelegate(ByVal value0 As Object, ByVal value1 As Object, ByVal value2 As Object)
    Private m_addRowDelegate As AddRowDelegate

    Private Sub AddDGVRow(ByVal val0ms As Object, ByVal val3imgtag As String, ByVal val4name As String)
        If threadEnabled = True Then
            If imgpanel1.InvokeRequired Then
                imgpanel1.BeginInvoke(New AddRowDelegate(AddressOf AddDGVRow), val0ms, val3imgtag, val4name)
            Else
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                picstp1 = New PictureBox
                picstp1.Image = Image.FromStream(val0ms)
                picstp1.SizeMode = PictureBoxSizeMode.Zoom
                picstp1.SetBounds(wid, y, 104, 100)
                picstp1.BorderStyle = BorderStyle.FixedSingle
                picstp1.Tag = val3imgtag

                Dim lbl As Label
                lbl = New Label
                lbl.Text = val4name
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                lbl.Tag = val3imgtag

                wid += 111
                widlbl += 111

                AddHandler picstp1.Click, AddressOf convertPic1
                imgpanel1.Controls.Add(picstp1)
                imgpanel1.Controls.Add(lbl)
            End If
        End If
    End Sub

    Private Sub bgw_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        Me.Cursor = Cursors.Default
        lblloading.Visible = False
        If e.Error IsNot Nothing Then
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            If meronstp1 = False Then
                btnimgrename1.Enabled = False
                btnimgremove1.Enabled = False
                btnimgcancel1.Enabled = False
                btnimgset1.Enabled = False
                btnimgupdate1.Enabled = False
                btnimgdl1.Enabled = False
                btnimgfull1.Enabled = False
            Else
                imgcancelfalse1()
            End If
        End If
    End Sub

    Private Sub bgw_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label12.Text = e.ProgressPercentage.ToString() & "% complete"
    End Sub

    Sub convertPic1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            picstp1 = CType(sender, PictureBox)
            imgbox1.Image = picstp1.Image
            lblimgid1.Text = picstp1.Tag

            If lblstep.Text = "1" Then
                sql = "Select name,datecreated,createdby from tbldispatchstp1 where stp1imgid='" & lblimgid1.Text & "'"
            ElseIf lblstep.Text = "2" Then
                sql = "Select name,datecreated,createdby from tbldispatchstp2 where stp2imgid='" & lblimgid1.Text & "'"
            ElseIf lblstep.Text = "3" Then
                sql = "Select name,datecreated,createdby from tbldispatchstp3 where stp3imgid='" & lblimgid1.Text & "'"
            ElseIf lblstep.Text = "4" Then
                sql = "Select name,datecreated,createdby from tbldispatchstp4 where stp4imgid='" & lblimgid1.Text & "'"
            ElseIf lblstep.Text = "5" Then
                sql = "Select name,datecreated,createdby from tbldispatchstp5 where stp5imgid='" & lblimgid1.Text & "'"
            ElseIf lblstep.Text = "6" Then
                sql = "Select name,datecreated,createdby from tbldispatchstp6 where stp6imgid='" & lblimgid1.Text & "'"
            ElseIf lblstep.Text = "7" Then
                sql = "Select name,datecreated,createdby from tbldispatchstp7 where stp7imgid='" & lblimgid1.Text & "'"
            ElseIf lblstep.Text = "8" Then
                sql = "Select name,datecreated,createdby from tbldispatchstp8 where stp8imgid='" & lblimgid1.Text & "'"
            ElseIf lblstep.Text = "9" Then
                sql = "Select name,datecreated,createdby from tbldispatchstp9 where stp9imgid='" & lblimgid1.Text & "'"
            End If

            '/sql = "Select name,datecreated,createdby from tbldispatchstp1 where stp1imgid='" & lblimgid1.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                txtimg1.Text = dr("name")
                If IsDBNull(dr("datecreated")) = False Then
                    lblimgdate1.Text = Format(dr("datecreated"), "MM/dd/yyyy h:mm tt")
                Else
                    lblimgdate1.Text = ""
                End If
                lblimgname1.Text = dr("createdby").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            '/For Each n As Control In imgpanel1.Controls
            '/If n.GetType Is GetType(System.Windows.Forms.Label) Then
            '/If n.Tag = picstp1.Tag Then
            '/txtimg1.Text = n.Text
            '/Exit For
            '/End If
            '/End If
            '/Next

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgfull1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgfull1.Click
        If lblimgid1.Text <> "" Then
            viewimage.btnprev.Visible = True
            viewimage.btnnext.Visible = True
            viewimage.imgbox.Image = imgbox1.Image
            viewimage.lblimgname.Text = txtimg1.Text
            viewimage.ShowDialog()
            viewimage.btnprev.Visible = False
            viewimage.btnnext.Visible = False
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Public Sub tripinfo()
        Try
            txtdefault()
            lblfinishby.Text = ""
            lblstartby.Text = ""

            sql = "Select * from tbltripsum where tripnum='" & lbltripnum1.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                txt3.Text = dr("odostart")
                txt4.Text = dr("odoactual")

                txt5.Text = dr("diswith")
                txt6.Text = dr("diswout")
                txt7.Text = dr("dshould")
                txt8.Text = dr("dieselbeg")
                txt9.Text = dr("dieselactual")
                txt10.Text = dr("podiesel")
                txt11.Text = dr("addpo")

                txt3.Text = dr("odostart")
                txt4.Text = dr("odoactual")

                txt5.Text = dr("diswith")
                txt6.Text = dr("diswout")
                txt7.Text = dr("dshould")
                txt8.Text = dr("dieselbeg")
                txt9.Text = dr("dieselactual")
                txt10.Text = dr("podiesel")
                txt11.Text = dr("addpo")

                txt12.Text = dr("odoend")
                txt13.Text = dr("postaddpo")
                txt14.Text = dr("dieselend")

                txtlabor.Text = dr("loadscale")

                If dr("repair") = 1 Then
                    lblpick.Visible = True
                    imgbox1.Location = New System.Drawing.Point(600, 61)
                    imgbox1.Size = New System.Drawing.Point(273, 205)
                Else
                    lblpick.Visible = False
                    imgbox1.Location = New System.Drawing.Point(600, 21)
                    imgbox1.Size = New System.Drawing.Point(273, 244)
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum1.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If lblstep.Text = "1" Then
                    lbl1.Text = "Time Start Pre - Inspection:"
                    lblstart.Text = dr("startpre").ToString
                    lblstartby.Text = dr("startpreby").ToString

                    lbl2.Text = "Time Finish Pre - Inspection:"
                    lblfinish.Text = dr("datestp1").ToString
                    lblfinishby.Text = dr("namestp1").ToString

                    lbldraft.Text = "Time Save as Draft Pre - Inspection:"
                    lblsave.Text = dr("sdeytstp1").ToString
                    lblsaveby.Text = dr("sneymstp1").ToString

                    txtcomment.Text = dr("comstp1").ToString
                    lbllogis.Text = dr("cneymstp1").ToString
                    txtrems.Text = dr("remstp1").ToString

                    If IsDBNull(dr("cstatstp1")) = False Then
                        If dr("cstatstp1") = 1 Then
                            rbok.Checked = True
                            comstat = 1
                        ElseIf dr("cstatstp1") = 0 Then
                            rbwarn.Checked = True
                            comstat = 0
                        End If
                    Else
                        comstat = 2
                    End If

                    Panel4.Visible = False

                ElseIf lblstep.Text = "2" Then
                    lbl1.Text = "Time Start Diesel:"
                    lblstart.Text = dr("startdiesel").ToString
                    lblstartby.Text = dr("startdieselby").ToString

                    lbl2.Text = "Time Finish Diesel:"
                    lblfinish.Text = dr("datestp2").ToString
                    lblfinishby.Text = dr("namestp2").ToString

                    lbldraft.Text = "Time Save as Draft Diesel:"
                    lblsave.Text = dr("sdeytstp2").ToString
                    lblsaveby.Text = dr("sneymstp2").ToString

                    txtcomment.Text = dr("comstp2").ToString
                    lbllogis.Text = dr("cneymstp2").ToString
                    txtrems.Text = dr("remstp2").ToString

                    If IsDBNull(dr("cstatstp2")) = False Then
                        If dr("cstatstp2") = 1 Then
                            rbok.Checked = True
                            comstat = 1
                        ElseIf dr("cstatstp2") = 0 Then
                            rbwarn.Checked = True
                            comstat = 0
                        End If
                    Else
                        comstat = 2
                    End If

                    Panel4.Visible = False

                ElseIf lblstep.Text = "3" Then
                    lbl1.Text = "Time Start Loading:"
                    lbl2.Text = "Time Finish Loading:"

                    If IsDBNull(dr("startload")) = False Then
                        lblstart.Text = dr("startload").ToString
                        lblstartby.Text = dr("startloadby").ToString
                        lblfinish.Text = dr("datestp3").ToString
                        lblfinishby.Text = dr("namestp3").ToString
                    Else
                        lblstart.Text = ""
                        lbl2.Text = "Confirm N/A:"
                        lblfinish.Text = dr("datestp3").ToString
                        lblfinishby.Text = dr("namestp3").ToString
                    End If

                    lbldraft.Text = "Time Save as Draft Loading:"
                    lblsave.Text = dr("sdeytstp3").ToString
                    lblsaveby.Text = dr("sneymstp3").ToString

                    txtcomment.Text = dr("comstp3").ToString
                    lbllogis.Text = dr("cneymstp3").ToString
                    txtrems.Text = dr("remstp3").ToString

                    If IsDBNull(dr("cstatstp3")) = False Then
                        If dr("cstatstp3") = 1 Then
                            rbok.Checked = True
                            comstat = 1
                        ElseIf dr("cstatstp3") = 0 Then
                            rbwarn.Checked = True
                            comstat = 0
                        End If
                    Else
                        comstat = 2
                    End If

                    Panel4.Visible = True

                ElseIf lblstep.Text = "4" Then
                    lbl1.Text = "Time Start Release Documents:"
                    lblstart.Text = dr("startdoc").ToString
                    lblstartby.Text = dr("startdocby").ToString

                    lbl2.Text = "Time Finish Release Documents:"
                    lblfinish.Text = dr("datestp4").ToString
                    lblfinishby.Text = dr("namestp4").ToString

                    lbldraft.Text = "Time Save as Draft Release Documents:"
                    lblsave.Text = dr("sdeytstp4").ToString
                    lblsaveby.Text = dr("sneymstp4").ToString

                    txtrems.Text = dr("remstp4").ToString
                    txtcomment.Text = dr("comstp4").ToString
                    lbllogis.Text = dr("cneymstp4").ToString

                    If IsDBNull(dr("cstatstp4")) = False Then
                        If dr("cstatstp4") = 1 Then
                            rbok.Checked = True
                            comstat = 1
                        ElseIf dr("cstatstp4") = 0 Then
                            rbwarn.Checked = True
                            comstat = 0
                        End If
                    Else
                        comstat = 2
                    End If

                    Panel4.Visible = False

                ElseIf lblstep.Text = "5" Then
                    lbl1.Text = "Time Start Petty Cash:"
                    lblstart.Text = dr("startcash").ToString
                    lblstartby.Text = dr("startcashby").ToString

                    lbl2.Text = "Time Finish Petty Cash:"
                    lblfinish.Text = dr("datestp5").ToString
                    lblfinishby.Text = dr("namestp5").ToString

                    lbldraft.Text = "Time Save as Draft Petty Cash:"
                    lblsave.Text = dr("sdeytstp5").ToString
                    lblsaveby.Text = dr("sneymstp5").ToString

                    txtrems.Text = dr("remstp5").ToString
                    txtcomment.Text = dr("comstp5").ToString
                    lbllogis.Text = dr("cneymstp5").ToString

                    If IsDBNull(dr("cstatstp5")) = False Then
                        If dr("cstatstp5") = 1 Then
                            rbok.Checked = True
                            comstat = 1
                        ElseIf dr("cstatstp5") = 0 Then
                            rbwarn.Checked = True
                            comstat = 0
                        End If
                    Else
                        comstat = 2
                    End If

                    Panel4.Visible = False

                ElseIf lblstep.Text = "6" Then
                    lbl1.Text = "Time Departure Truck Exit Whse:"
                    lbl2.Text = "Time Arrival Truck Return Whse:"
                    If IsDBNull(dr("datestp6")) = False Then
                        lblfinish.Text = dr("datestp6").ToString
                        lblfinishby.Text = dr("namestp6").ToString
                    Else
                        lblfinish.Text = ""
                    End If

                    If IsDBNull(dr("timedep")) = False Then
                        lblstart.Text = dr("timedep").ToString
                        lblstartby.Text = dr("timedepby").ToString
                    Else
                        lblstart.Text = ""
                    End If

                    If IsDBNull(dr("cstatstp6")) = False Then
                        If dr("cstatstp6") = 1 Then
                            rbok.Checked = True
                            comstat = 1
                        ElseIf dr("cstatstp6") = 0 Then
                            rbwarn.Checked = True
                            comstat = 0
                        End If
                    Else
                        comstat = 2
                    End If
                    lbldraft.Text = "Time Save as Draft Exit/Return:"
                    lblsave.Text = dr("sdeytstp6").ToString
                    lblsaveby.Text = dr("sneymstp6").ToString

                    txtrems.Text = dr("remstp6").ToString
                    txtcomment.Text = dr("comstp6").ToString
                    lbllogis.Text = dr("cneymstp6").ToString

                    If IsDBNull(dr("cstatstp6")) = False Then
                        If dr("cstatstp6") = 1 Then
                            rbok.Checked = True
                        Else
                            rbwarn.Checked = True
                        End If
                    Else
                        rbok.Checked = True
                    End If

                    Panel4.Visible = False

                ElseIf lblstep.Text = "7" Then
                    lbl1.Text = "Time Start Return of Documents:"
                    lblstart.Text = dr("startreturn").ToString
                    lblstartby.Text = dr("startreturnby").ToString

                    lbl2.Text = "Time Finish Return of Documents:"
                    lblfinish.Text = dr("datestp7").ToString
                    lblfinishby.Text = dr("namestp7").ToString

                    lbldraft.Text = "Time Save as Draft Return of Documents:"
                    lblsave.Text = dr("sdeytstp7").ToString
                    lblsaveby.Text = dr("sneymstp7").ToString

                    txtrems.Text = dr("remstp7").ToString
                    txtcomment.Text = dr("comstp7").ToString
                    lbllogis.Text = dr("cneymstp7").ToString

                    If IsDBNull(dr("cstatstp7")) = False Then
                        If dr("cstatstp7") = 1 Then
                            rbok.Checked = True
                            comstat = 1
                        ElseIf dr("cstatstp7") = 0 Then
                            rbwarn.Checked = True
                            comstat = 0
                        End If
                    Else
                        comstat = 2
                    End If

                    Panel4.Visible = False

                ElseIf lblstep.Text = "8" Then
                    lbl1.Text = "Time Start Post - Inspection:"
                    lblstart.Text = dr("startpost").ToString
                    lblstartby.Text = dr("startpostby").ToString

                    lbl2.Text = "Time Finish Post - Inspection:"
                    lblfinish.Text = dr("datestp8").ToString
                    lblfinishby.Text = dr("namestp8").ToString

                    lbldraft.Text = "Time Save as Draft Post - Inspection:"
                    lblsave.Text = dr("sdeytstp8").ToString
                    lblsaveby.Text = dr("sneymstp8").ToString

                    txtrems.Text = dr("remstp8").ToString
                    txtcomment.Text = dr("comstp8").ToString
                    lbllogis.Text = dr("cneymstp8").ToString

                    If IsDBNull(dr("cstatstp8")) = False Then
                        If dr("cstatstp8") = 1 Then
                            rbok.Checked = True
                            comstat = 1
                        ElseIf dr("cstatstp8") = 0 Then
                            rbwarn.Checked = True
                            comstat = 0
                        End If
                    Else
                        comstat = 2
                    End If

                    Panel4.Visible = False

                ElseIf lblstep.Text = "9" Then
                    lbl1.Text = "Time Start Recording:"
                    lblstart.Text = dr("startrecord").ToString
                    lblstartby.Text = dr("startrecordby").ToString

                    lbl2.Text = "Time Finish Recording:"
                    lblfinish.Text = dr("datestp9").ToString
                    lblfinishby.Text = dr("namestp9").ToString

                    lbldraft.Text = "Time Save as Draft Recording:"
                    lblsave.Text = dr("sdeytstp9").ToString
                    lblsaveby.Text = dr("sneymstp9").ToString

                    txtrems.Text = dr("remstp9").ToString
                    txtcomment.Text = dr("comstp9").ToString
                    lbllogis.Text = dr("cneymstp9").ToString

                    If IsDBNull(dr("cstatstp9")) = False Then
                        If dr("cstatstp9") = 1 Then
                            rbok.Checked = True
                            comstat = 1
                        ElseIf dr("cstatstp9") = 0 Then
                            rbwarn.Checked = True
                            comstat = 0
                        End If
                    Else
                        comstat = 2
                    End If

                    Panel4.Visible = False

                End If
                txtrescue.Text = dr("rescue").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Dim actualdis As Double = Double.Parse(txt12.Text, culture) - Double.Parse(txt4.Text, culture)
            txt15.Text = actualdis.ToString("n2")

            'txt9 + txt10 + txt11 + txt13 - txt14
            Dim actualdie As Double = (Double.Parse(txt9.Text, culture) + Double.Parse(txt10.Text, culture) + Double.Parse(txt11.Text, culture) + Double.Parse(txt13.Text, culture)) - Double.Parse(txt14.Text, culture)
            txt16.Text = actualdie.ToString("n2")

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub viewtransgrid()
        Try
            

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub txtdefault()
        txt3.Text = "0"
        txt4.Text = "0"
        txt5.Text = "0"
        txt6.Text = "0"
        txt7.Text = "0"
        txt8.Text = "0"
        txt9.Text = "0"
        txt10.Text = "0"
        txt11.Text = "0"
        txt12.Text = "0"
        txt13.Text = "0"
        txt14.Text = "0"
    End Sub

    Private Sub btnimgrename1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrename1.Click
        If login.neym <> "Manager" And login.neym <> "Whse Logistics Staff" Then
            MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
            Exit Sub
        End If

        If btnimgrename1.Text = "Rename" Then
            If Trim(txtimg1.Text) <> "" And imgbox1.Image IsNot Nothing Then
                Dim tempname As String = Trim(txtimg1.Text)
                If tempname.ToLower.Contains("signature") Then
                    MsgBox("Cannot rename photo.", MsgBoxStyle.Exclamation, "")
                    txtimg1.Focus()
                    Exit Sub
                End If
                txtimg1.Enabled = True
                txtimg1.Focus()
            ElseIf Trim(txtimg1.Text) = "" And imgbox1.Image IsNot Nothing Then
                Me.Cursor = Cursors.Default
                MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                txtimg1.Focus()
                Exit Sub
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                txtimg1.Focus()
                Exit Sub
            End If

            imgpanel1.Enabled = False
            imgcanceltrue1()
            btnimgrename1.Enabled = True
            btnimgrename1.Text = "Save"
            txtimg1.ReadOnly = False
        Else
            'search image name if existing
            conn.Open()
            '/connect()
            cmd = New SqlCommand("Select * from tbldispatchstp1 where tripnum='" & lbltripnum1.Text & "' and name='" & Trim(txtimg1.Text) & "'", conn)
            dr = cmd.ExecuteReader()
            If dr.Read = True Then
                Me.Cursor = Cursors.Default
                MessageBox.Show("Image " & Trim(txtimg1.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtimg1.Focus()
                Exit Sub
            Else
                If txtimg1.Text.ToLower.Contains("signature") Then
                    MsgBox("Invalid photo name.", MsgBoxStyle.Exclamation, "")
                    txtimg1.Text = ""
                    txtimg1.Focus()
                    Exit Sub
                End If

                'irename.. update yung name lng where imgid = lblimgid.text
                If lblstep.Text = "1" Then
                    sql = "Update tbldispatchstp1 set name='" & Trim(txtimg1.Text) & "' where stp1imgid='" & lblimgid1.Text & "'"
                ElseIf lblstep.Text = "2" Then
                    sql = "Update tbldispatchstp2 set name='" & Trim(txtimg1.Text) & "' where stp2imgid='" & lblimgid1.Text & "'"
                ElseIf lblstep.Text = "3" Then
                    sql = "Update tbldispatchstp3 set name='" & Trim(txtimg1.Text) & "' where stp3imgid='" & lblimgid1.Text & "'"
                ElseIf lblstep.Text = "4" Then
                    sql = "Update tbldispatchstp4 set name='" & Trim(txtimg1.Text) & "' where stp4imgid='" & lblimgid1.Text & "'"
                ElseIf lblstep.Text = "5" Then
                    sql = "Update tbldispatchstp5 set name='" & Trim(txtimg1.Text) & "' where stp5imgid='" & lblimgid1.Text & "'"
                ElseIf lblstep.Text = "6" Then
                    sql = "Update tbldispatchstp6 set name='" & Trim(txtimg1.Text) & "' where stp6imgid='" & lblimgid1.Text & "'"
                ElseIf lblstep.Text = "7" Then
                    sql = "Update tbldispatchstp7 set name='" & Trim(txtimg1.Text) & "' where stp7imgid='" & lblimgid1.Text & "'"
                ElseIf lblstep.Text = "8" Then
                    sql = "Update tbldispatchstp8 set name='" & Trim(txtimg1.Text) & "' where stp8imgid='" & lblimgid1.Text & "'"
                ElseIf lblstep.Text = "9" Then
                    sql = "Update tbldispatchstp9 set name='" & Trim(txtimg1.Text) & "' where stp9imgid='" & lblimgid1.Text & "'"
                End If

                conn.Open()
                '/connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                btnimgrename1.Text = "Rename"
                imgcancelfalse1()
                imgpanel1.Enabled = True
                btnimgrefresh1.PerformClick()
                Me.Cursor = Cursors.Default
                txtimg1.ReadOnly = True
            End If
            disconnect()
        End If
    End Sub

    Public Sub imgcanceltrue1()
        btnimgadd1.Enabled = False
        btnimgrename1.Enabled = False
        btnimgremove1.Enabled = False
        btnimgcancel1.Enabled = True
        btnimgdl1.Enabled = False
        btnimgfull1.Enabled = False
        btnimgrefresh1.Enabled = False
    End Sub

    Public Sub imgcancelfalse1()
        txtimg1.Text = ""
        btnimgadd1.Text = "Add Photo"
        btnimgrename1.Text = "Rename"
        btnimgadd1.Enabled = True
        btnimgrename1.Enabled = True
        btnimgremove1.Enabled = True
        btnimgcancel1.Enabled = False
        btnimgdl1.Enabled = True
        btnimgfull1.Enabled = True
        btnimgrefresh1.Enabled = True
        imgpanel1.Enabled = True
    End Sub

    Private Sub btnimgcancel1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel1.Click
        imgbox1.Image = Nothing
        txtimg1.Text = ""
        lblimgid1.Text = ""
        imgcancelfalse1()

        If meronstp1 = False Then
            btnimgrename1.Enabled = False
            btnimgremove1.Enabled = False
            btnimgcancel1.Enabled = False
            btnimgdl1.Enabled = False
            btnimgfull1.Enabled = False
        Else
            imgcancelfalse1()
        End If
    End Sub

    Private Sub btnimgdl1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgdl1.Click
        Try
            If lblimgid1.Text <> "" Then
                If Trim(txtimg1.Text) <> "" And imgbox1.Image IsNot Nothing Then
                    Dim tempname As String = Trim(txtimg1.Text)
                    If tempname.ToLower.Contains("signature") Then
                        MsgBox("Cannot download signature.", MsgBoxStyle.Exclamation, "")
                        txtimg1.Focus()
                        Exit Sub
                    End If
                    txtimg1.Enabled = True
                    txtimg1.Focus()
                End If
                saveimagesteps.ShowDialog()
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncomment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncomment.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If btncomment.Text = "Edit Comment" Then
                txtcomment.ReadOnly = False
                btncomment.Text = "Save Comment"
                txtcomment.Focus()

                picinfo.Visible = True
                picwarn.Visible = True
                rbok.Visible = True
                rbok.Checked = False
                rbwarn.Visible = True
                rbwarn.Checked = False
            Else
                comstat = 2
                If rbok.Checked = True Then
                    comstat = 1
                ElseIf rbwarn.Checked = True Then
                    comstat = 0
                    If Trim(txtcomment.Text) = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Input comment.", MsgBoxStyle.Exclamation, "")
                        txtcomment.Focus()
                        Exit Sub
                    End If
                Else
                    MsgBox("Select first.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If

                If linkcheck = False And (lblstep.Text = "7" Or lblstep.Text = "8" Or lblstep.Text = "9") Then
                    '/MsgBox("Click the View Trip Info link first to ensure that all the remarks and comments from other steps are checked.", MsgBoxStyle.Exclamation, "")
                    '/Exit Sub
                    viewtripinfo.lblid.Text = tripdispatchsum.grddispatch.Item(0, tripdispatchsum.grddispatch.CurrentRow.Index).Value.ToString
                    viewtripinfo.lbltripnum.Text = lbltripnum1.Text
                    viewtripinfo.Text = "Trip Information (" & lbltripnum1.Text & ")"
                    viewtripinfo.ShowDialog()
                    linkcheck = True
                End If

                cnfcom = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If cnfcom = True Then
                    tip = txtcomment.Text
                    'inputcomment.box.Text = tip
                    'inputcomment.box.Focus()
                    'inputcomment.ShowDialog()

                    'If inputcomment.cncel = False Then
                    Dim cell As DataGridViewCell = tripdispatchsum.grddispatch.CurrentCell
                    cell.ErrorText = tip
                    If Not cell.Value.ToString.Contains("Time Departure") Then
                        cell.Tag = "True"
                    End If

                    If comstat = 1 Then
                        cell.ErrorText = ""
                    End If

                    If lblstep.Text = "1" Then
                        sql = "Update tbldispatchsum set cneymstp1='" & login.cashier & "',cdeytstp1=GetDate(),comstp1='" & tip & "',cstatstp1='" & comstat & "' where tripnum ='" & lbltripnum1.Text & "'"

                    ElseIf lblstep.Text = "2" Then
                        sql = "Update tbldispatchsum set cneymstp2='" & login.cashier & "',cdeytstp2=GetDate(),comstp2='" & tip & "',cstatstp2='" & comstat & "' where tripnum ='" & lbltripnum1.Text & "'"

                    ElseIf lblstep.Text = "3" Then
                        sql = "Update tbldispatchsum set cneymstp3='" & login.cashier & "',cdeytstp3=GetDate(),comstp3='" & tip & "',cstatstp3='" & comstat & "' where tripnum ='" & lbltripnum1.Text & "'"

                    ElseIf lblstep.Text = "4" Then
                        sql = "Update tbldispatchsum set cneymstp4='" & login.cashier & "',cdeytstp4=GetDate(),comstp4='" & tip & "',cstatstp4='" & comstat & "' where tripnum ='" & lbltripnum1.Text & "'"

                    ElseIf lblstep.Text = "5" Then
                        sql = "Update tbldispatchsum set cneymstp5='" & login.cashier & "',cdeytstp5=GetDate(),comstp5='" & tip & "',cstatstp5='" & comstat & "' where tripnum ='" & lbltripnum1.Text & "'"

                    ElseIf lblstep.Text = "6" Then
                        sql = "Update tbldispatchsum set cneymstp6='" & login.cashier & "',cdeytstp6=GetDate(),comstp6='" & tip & "',cstatstp6='" & comstat & "' where tripnum ='" & lbltripnum1.Text & "'"

                    ElseIf lblstep.Text = "7" Then
                        sql = "Update tbldispatchsum set cneymstp7='" & login.cashier & "',cdeytstp7=GetDate(),comstp7='" & tip & "',cstatstp7='" & comstat & "' where tripnum ='" & lbltripnum1.Text & "'"

                    ElseIf lblstep.Text = "8" Then
                        sql = "Update tbldispatchsum set cneymstp8='" & login.cashier & "',cdeytstp8=GetDate(),comstp8='" & tip & "',cstatstp8='" & comstat & "' where tripnum ='" & lbltripnum1.Text & "'"

                    ElseIf lblstep.Text = "9" Then
                        sql = "Update tbldispatchsum set cneymstp9='" & login.cashier & "',cdeytstp9=GetDate(),comstp9='" & tip & "',cstatstp9='" & comstat & "' where tripnum ='" & lbltripnum1.Text & "'"
                    Else
                        Exit Sub
                    End If

                    conn.Open()
                    '/connect()
                    cmd = New SqlCommand(sql, conn) 'New OleDbCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    txtcomment.ReadOnly = True
                    btncomment.Text = "Edit Comment"

                    picinfo.Visible = False
                    picwarn.Visible = False
                    rbok.Visible = False
                    rbwarn.Visible = False
                    linkcheck = False
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            disconnect()
        End Try
        'End If
    End Sub

    Private Sub grdtrans4_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans4.CellContentClick
        Try
            'link
            If e.ColumnIndex = 1 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdtrans4.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrans4.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdtrans4.RowCount <> 0 Then
                    If grdtrans4.Item(1, grdtrans4.CurrentRow.Index).Value IsNot Nothing Then
                        'MsgBox(grdtrans4.Item(12, ii).Value.ToString)
                        viewtrans.Text = "View Transaction"
                        viewtrans.grouptrans.Visible = False
                        viewtrans.lbltripnum.Text = lbltripnum1.Text
                        viewtrans.txttrans.Text = grdtrans4.Item(1, grdtrans4.CurrentRow.Index).Value
                        viewtrans.sing = True
                        viewtrans.ShowDialog()
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtcomment_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtcomment.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtcomment_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcomment.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtcomment.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtcomment.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtcomment.Text.Length - 1
            Letter = txtcomment.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtcomment.Text = theText
        txtcomment.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub ExecuteView(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            ' Start a local transaction
            transaction = connection.BeginTransaction("SampleTransaction")

            ' Must assign both transaction object and connection 
            ' to Command object for a pending local transaction.
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Select * from tbltripsum where tripnum='" & lbltripnum1.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then

                    txt3.Text = dr("odostart")
                    txt4.Text = dr("odoactual")

                    txt5.Text = dr("diswith")
                    txt6.Text = dr("diswout")
                    txt7.Text = dr("dshould")
                    txt8.Text = dr("dieselbeg")
                    txt9.Text = dr("dieselactual")
                    txt10.Text = dr("podiesel")
                    txt11.Text = dr("addpo")

                    txt3.Text = dr("odostart")
                    txt4.Text = dr("odoactual")

                    txt5.Text = dr("diswith")
                    txt6.Text = dr("diswout")
                    txt7.Text = dr("dshould")
                    txt8.Text = dr("dieselbeg")
                    txt9.Text = dr("dieselactual")
                    txt10.Text = dr("podiesel")
                    txt11.Text = dr("addpo")

                    txt12.Text = dr("odoend")
                    txt13.Text = dr("postaddpo")
                    txt14.Text = dr("dieselend")

                    txtlabor.Text = dr("loadscale")
                End If
                dr.Dispose()

                sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum1.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    If lblstep.Text = "1" Then
                        lbl1.Text = "Time Start Pre - Inspection:"
                        lblstart.Text = dr("startpre").ToString
                        lblstartby.Text = dr("startpreby").ToString

                        lbl2.Text = "Time Finish Pre - Inspection:"
                        lblfinish.Text = dr("datestp1").ToString
                        lblfinishby.Text = dr("namestp1").ToString

                        lbldraft.Text = "Time Save as Draft Pre - Inspection:"
                        lblsave.Text = dr("sdeytstp1").ToString
                        lblsaveby.Text = dr("sneymstp1").ToString

                        txtcomment.Text = dr("comstp1").ToString
                        lbllogis.Text = dr("cneymstp1").ToString
                        txtrems.Text = dr("remstp1").ToString

                        If IsDBNull(dr("cstatstp1")) = False Then
                            If dr("cstatstp1") = 1 Then
                                rbok.Checked = True
                                comstat = 1
                            ElseIf dr("cstatstp1") = 0 Then
                                rbwarn.Checked = True
                                comstat = 0
                            End If
                        Else
                            comstat = 2
                        End If

                        Panel4.Visible = False

                    ElseIf lblstep.Text = "2" Then
                        lbl1.Text = "Time Start Diesel:"
                        lblstart.Text = dr("startdiesel").ToString
                        lblstartby.Text = dr("startdieselby").ToString

                        lbl2.Text = "Time Finish Diesel:"
                        lblfinish.Text = dr("datestp2").ToString
                        lblfinishby.Text = dr("namestp2").ToString

                        lbldraft.Text = "Time Save as Draft Diesel:"
                        lblsave.Text = dr("sdeytstp2").ToString
                        lblsaveby.Text = dr("sneymstp2").ToString

                        txtcomment.Text = dr("comstp2").ToString
                        lbllogis.Text = dr("cneymstp2").ToString
                        txtrems.Text = dr("remstp2").ToString

                        If IsDBNull(dr("cstatstp2")) = False Then
                            If dr("cstatstp2") = 1 Then
                                rbok.Checked = True
                                comstat = 1
                            ElseIf dr("cstatstp2") = 0 Then
                                rbwarn.Checked = True
                                comstat = 0
                            End If
                        Else
                            comstat = 2
                        End If

                        Panel4.Visible = False

                    ElseIf lblstep.Text = "3" Then
                        lbl1.Text = "Time Start Loading:"
                        lbl2.Text = "Time Finish Loading:"

                        If IsDBNull(dr("startload")) = False Then
                            lblstart.Text = dr("startload").ToString
                            lblstartby.Text = dr("startloadby").ToString
                            lblfinish.Text = dr("datestp3").ToString
                            lblfinishby.Text = dr("namestp3").ToString
                        Else
                            lblstart.Text = ""
                            lbl2.Text = "Confirm N/A:"
                            lblfinish.Text = dr("datestp3").ToString
                            lblfinishby.Text = dr("namestp3").ToString
                        End If

                        lbldraft.Text = "Time Save as Draft Loading:"
                        lblsave.Text = dr("sdeytstp3").ToString
                        lblsaveby.Text = dr("sneymstp3").ToString

                        txtcomment.Text = dr("comstp3").ToString
                        lbllogis.Text = dr("cneymstp3").ToString
                        txtrems.Text = dr("remstp3").ToString

                        If IsDBNull(dr("cstatstp3")) = False Then
                            If dr("cstatstp3") = 1 Then
                                rbok.Checked = True
                                comstat = 1
                            ElseIf dr("cstatstp3") = 0 Then
                                rbwarn.Checked = True
                                comstat = 0
                            End If
                        Else
                            comstat = 2
                        End If

                        Panel4.Visible = True

                    ElseIf lblstep.Text = "4" Then
                        lbl1.Text = "Time Start Release Documents:"
                        lblstart.Text = dr("startdoc").ToString
                        lblstartby.Text = dr("startdocby").ToString

                        lbl2.Text = "Time Finish Release Documents:"
                        lblfinish.Text = dr("datestp4").ToString
                        lblfinishby.Text = dr("namestp4").ToString

                        lbldraft.Text = "Time Save as Draft Release Documents:"
                        lblsave.Text = dr("sdeytstp4").ToString
                        lblsaveby.Text = dr("sneymstp4").ToString

                        txtrems.Text = dr("remstp4").ToString
                        txtcomment.Text = dr("comstp4").ToString
                        lbllogis.Text = dr("cneymstp4").ToString

                        If IsDBNull(dr("cstatstp4")) = False Then
                            If dr("cstatstp4") = 1 Then
                                rbok.Checked = True
                                comstat = 1
                            ElseIf dr("cstatstp4") = 0 Then
                                rbwarn.Checked = True
                                comstat = 0
                            End If
                        Else
                            comstat = 2
                        End If

                        Panel4.Visible = False

                    ElseIf lblstep.Text = "5" Then
                        lbl1.Text = "Time Start Petty Cash:"
                        lblstart.Text = dr("startcash").ToString
                        lblstartby.Text = dr("startcashby").ToString

                        lbl2.Text = "Time Finish Petty Cash:"
                        lblfinish.Text = dr("datestp5").ToString
                        lblfinishby.Text = dr("namestp5").ToString

                        lbldraft.Text = "Time Save as Draft Petty Cash:"
                        lblsave.Text = dr("sdeytstp5").ToString
                        lblsaveby.Text = dr("sneymstp5").ToString

                        txtrems.Text = dr("remstp5").ToString
                        txtcomment.Text = dr("comstp5").ToString
                        lbllogis.Text = dr("cneymstp5").ToString

                        If IsDBNull(dr("cstatstp5")) = False Then
                            If dr("cstatstp5") = 1 Then
                                rbok.Checked = True
                                comstat = 1
                            ElseIf dr("cstatstp5") = 0 Then
                                rbwarn.Checked = True
                                comstat = 0
                            End If
                        Else
                            comstat = 2
                        End If

                        Panel4.Visible = False

                    ElseIf lblstep.Text = "6" Then
                        lbl1.Text = "Time Departure Truck Exit Whse:"
                        lbl2.Text = "Time Arrival Truck Return Whse:"
                        If IsDBNull(dr("datestp6")) = False Then
                            lblfinish.Text = dr("datestp6").ToString
                            lblfinishby.Text = dr("namestp6").ToString
                        Else
                            lblfinish.Text = ""
                        End If

                        If IsDBNull(dr("timedep")) = False Then
                            lblstart.Text = dr("timedep").ToString
                            lblstartby.Text = dr("timedepby").ToString
                        Else
                            lblstart.Text = ""
                        End If

                        If IsDBNull(dr("cstatstp6")) = False Then
                            If dr("cstatstp6") = 1 Then
                                rbok.Checked = True
                                comstat = 1
                            ElseIf dr("cstatstp6") = 0 Then
                                rbwarn.Checked = True
                                comstat = 0
                            End If
                        Else
                            comstat = 2
                        End If
                        lbldraft.Text = "Time Save as Draft Exit/Return:"
                        lblsave.Text = dr("sdeytstp6").ToString
                        lblsaveby.Text = dr("sneymstp6").ToString

                        txtrems.Text = dr("remstp6").ToString
                        txtcomment.Text = dr("comstp6").ToString
                        lbllogis.Text = dr("cneymstp6").ToString

                        If IsDBNull(dr("cstatstp6")) = False Then
                            If dr("cstatstp6") = 1 Then
                                rbok.Checked = True
                            Else
                                rbwarn.Checked = True
                            End If
                        Else
                            rbok.Checked = True
                        End If

                        Panel4.Visible = False

                    ElseIf lblstep.Text = "7" Then
                        lbl1.Text = "Time Start Return of Documents:"
                        lblstart.Text = dr("startreturn").ToString
                        lblstartby.Text = dr("startreturnby").ToString

                        lbl2.Text = "Time Finish Return of Documents:"
                        lblfinish.Text = dr("datestp7").ToString
                        lblfinishby.Text = dr("namestp7").ToString

                        lbldraft.Text = "Time Save as Draft Return of Documents:"
                        lblsave.Text = dr("sdeytstp7").ToString
                        lblsaveby.Text = dr("sneymstp7").ToString

                        txtrems.Text = dr("remstp7").ToString
                        txtcomment.Text = dr("comstp7").ToString
                        lbllogis.Text = dr("cneymstp7").ToString

                        If IsDBNull(dr("cstatstp7")) = False Then
                            If dr("cstatstp7") = 1 Then
                                rbok.Checked = True
                                comstat = 1
                            ElseIf dr("cstatstp7") = 0 Then
                                rbwarn.Checked = True
                                comstat = 0
                            End If
                        Else
                            comstat = 2
                        End If

                        Panel4.Visible = False

                    ElseIf lblstep.Text = "8" Then
                        lbl1.Text = "Time Start Post - Inspection:"
                        lblstart.Text = dr("startpost").ToString
                        lblstartby.Text = dr("startpostby").ToString

                        lbl2.Text = "Time Finish Post - Inspection:"
                        lblfinish.Text = dr("datestp8").ToString
                        lblfinishby.Text = dr("namestp8").ToString

                        lbldraft.Text = "Time Save as Draft Post - Inspection:"
                        lblsave.Text = dr("sdeytstp8").ToString
                        lblsaveby.Text = dr("sneymstp8").ToString

                        txtrems.Text = dr("remstp8").ToString
                        txtcomment.Text = dr("comstp8").ToString
                        lbllogis.Text = dr("cneymstp8").ToString

                        If IsDBNull(dr("cstatstp8")) = False Then
                            If dr("cstatstp8") = 1 Then
                                rbok.Checked = True
                                comstat = 1
                            ElseIf dr("cstatstp8") = 0 Then
                                rbwarn.Checked = True
                                comstat = 0
                            End If
                        Else
                            comstat = 2
                        End If

                        Panel4.Visible = False

                    ElseIf lblstep.Text = "9" Then
                        lbl1.Text = "Time Start Recording:"
                        lblstart.Text = dr("startrecord").ToString
                        lblstartby.Text = dr("startrecordby").ToString

                        lbl2.Text = "Time Finish Recording:"
                        lblfinish.Text = dr("datestp9").ToString
                        lblfinishby.Text = dr("namestp9").ToString

                        lbldraft.Text = "Time Save as Draft Recording:"
                        lblsave.Text = dr("sdeytstp9").ToString
                        lblsaveby.Text = dr("sneymstp9").ToString

                        txtrems.Text = dr("remstp9").ToString
                        txtcomment.Text = dr("comstp9").ToString
                        lbllogis.Text = dr("cneymstp9").ToString

                        If IsDBNull(dr("cstatstp9")) = False Then
                            If dr("cstatstp9") = 1 Then
                                rbok.Checked = True
                                comstat = 1
                            ElseIf dr("cstatstp9") = 0 Then
                                rbwarn.Checked = True
                                comstat = 0
                            End If
                        Else
                            comstat = 2
                        End If

                        Panel4.Visible = False

                    End If
                    txtrescue.Text = dr("rescue").ToString
                End If
                dr.Dispose()

                cmbtrans4.Items.Clear()
                sql = "Select transnum from tbltripitems where tripnum='" & lbltripnum1.Text & "' and status<>'3'"
                command.CommandText = sql
                dr = command.ExecuteReader
                While dr.Read
                    cmbtrans4.Items.Add(dr("transnum"))
                End While
                dr.Dispose()

                grdtrans4.Rows.Clear()
                For i = 0 To cmbtrans4.Items.Count - 1
                    cmbtrans4.SelectedIndex = i
                    sql = "Select * from tblortrans where transnum='" & cmbtrans4.SelectedItem & "'"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    If dr.Read Then
                        grdtrans4.Rows.Add(dr("transid"), dr("transnum"), dr("refnum"), dr("customer"), dr("arnum"), dr("rdrnum"), dr("drnum"), dr("dnnum"), dr("itrnum"), dr("itnum"), dr("grponum"), dr("transtype"), dr("notes"), dr("manager").ToString, "", "", "")
                    End If
                    dr.Dispose()
                Next

                For Each rowx In grdtrans4.Rows
                    sql = "Select record from tblcustomer where customer='" & grdtrans4.Rows(rowx.index).Cells(3).Value & "' and record is not NULL"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    If dr.Read Then
                        If grdtrans4.Rows(rowx.index).Cells(2).Value = "0000" And grdtrans4.Rows(rowx.index).Cells(11).Value.ToString.Contains("Trucking only for Oro Allado Customers") = False Then
                            grdtrans4.Rows(rowx.index).Cells(3).ErrorText = "    AGI Accounting Staff"
                        ElseIf Trim(dr("record").ToString) <> "" Then
                            grdtrans4.Rows(rowx.index).Cells(3).ErrorText = "    " & dr("record")
                        End If
                    End If
                    dr.Dispose()
                Next


                For Each row As DataGridViewRow In grdtrans4.Rows
                    'MsgBox(grdtrans.Rows(row.Index).Cells(2).Value.ToString)
                    sql = "SELECT tbltripitems.tripnum,tbltripitems.status,tblortrans.transnum,tbltripitems.datecreated,tbltripitems.alreadydisp,tbltripitems.modifiedby,tbltripitems.datemodified"
                    sql = sql & " FROM tblortrans RIGHT OUTER JOIN tbltripitems ON tblortrans.transnum=tbltripitems.transnum where tblortrans.transnum='" & grdtrans4.Rows(row.Index).Cells(1).Value & "' and tbltripitems.tripnum='" & lbltripnum1.Text & "'"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    If dr.Read Then
                        Dim stat As String = ""
                        If dr("status") = 0 Then
                            stat = 0
                            grdtrans4.Rows(row.Index).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                        ElseIf dr("status") = 4 Then
                            grdtrans4.Rows(row.Index).DefaultCellStyle.BackColor = Color.Plum
                        ElseIf dr("status") = 5 Then
                            grdtrans4.Rows(row.Index).DefaultCellStyle.BackColor = Color.Orange
                        ElseIf dr("status") = 2 Then
                            grdtrans4.Rows(row.Index).Cells(15).Value = dr("modifiedby")
                            grdtrans4.Rows(row.Index).Cells(16).Value = dr("datemodified")
                            grdtrans4.Rows(row.Index).DefaultCellStyle.BackColor = Color.Yellow
                        End If

                        If IsDBNull(dr("datecreated")) = False Then
                            grdtrans4.Rows(row.Index).Cells(14).Value = dr("datecreated") 'ormat(dr("datecreated"), "yyyy/MM/dd HH:mm")
                        End If
                        If IsDBNull(dr("alreadydisp")) = False Then
                            If dr("alreadydisp") = 1 Then 'departure
                                grdtrans4.Item(14, row.Index).Style.BackColor = Color.FromArgb(192, 255, 255)
                            ElseIf dr("alreadydisp") = 2 Then 'arrival
                                grdtrans4.Item(14, row.Index).Style.BackColor = Color.FromArgb(255, 224, 192)
                            End If
                        End If
                    End If
                    dr.Dispose()
                Next

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.ToString, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub grdtrans4_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdtrans4.CellMouseClick
        Try
            If e.Button = Windows.Forms.MouseButtons.Right And e.RowIndex > -1 Then
                If e.ColumnIndex = 2 Then

                    grdtrans4.ClearSelection()
                    grdtrans4.Rows(e.RowIndex).Cells(2).Selected = True

                    selectedrow = e.RowIndex

                    Dim refnum As String = grdtrans4.Rows(e.RowIndex).Cells(2).Value

                    If refnum = "0000" Then
                        Exit Sub
                    End If

                    Me.ContextMenuStrip1.Show(Cursor.Position)
                    viewvisiblefalse()
                    ViewRefHistoryToolStripMenuItem.Visible = True

                    If login.neym = "Administrator" Or login.neym = "Supervisor" Then
                        If grdtrans4.Rows(e.RowIndex).DefaultCellStyle.BackColor <> Color.DeepSkyBlue Then
                            If refnum.ToUpper.ToString.Contains("SO#") = True Then
                                EditSOToolStripMenuItem.Visible = True
                            End If
                            If refnum.ToUpper.ToString.Contains("PO#") = True Then
                                EditPOToolStripMenuItem.Visible = True
                            ElseIf refnum.ToUpper.ToString.Contains("ITR#") = True Then
                                EditITRToolStripMenuItem.Visible = True
                            ElseIf refnum.ToUpper.ToString.Contains("SWS#") = True Then
                                EditSWSToolStripMenuItem.Visible = True
                            End If
                        End If
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub viewvisiblefalse()
        EditSOToolStripMenuItem.Visible = False
        EditPOToolStripMenuItem.Visible = False
        EditITRToolStripMenuItem.Visible = False
        EditSWSToolStripMenuItem.Visible = False
        ViewRefHistoryToolStripMenuItem.Visible = False
        EditToolStripMenuItem.Visible = False
        ViewEditHistoryToolStripMenuItem.Visible = False
    End Sub

    Private Sub EditSOToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditSOToolStripMenuItem.Click
        edited = False
        tripeditref.lbl1.Text = "SO#"
        tripeditref.lbl2.Text = "SO#"

        editrefnum()
    End Sub

    Private Sub EditPOToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditPOToolStripMenuItem.Click
        edited = False
        tripeditref.lbl1.Text = "PO#"
        tripeditref.lbl2.Text = "PO#"

        editrefnum()
    End Sub

    Private Sub EditITRToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditITRToolStripMenuItem.Click
        edited = False
        tripeditref.lbl1.Text = "ITR#"
        tripeditref.lbl2.Text = "ITR#"

        editrefnum()
    End Sub

    Private Sub EditSWSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditSWSToolStripMenuItem.Click
        edited = False
        tripeditref.lbl1.Text = "SWS#"
        tripeditref.lbl2.Text = "SWS#"

        editrefnum()
    End Sub

    Public Sub editrefnum()
        tripeditref.frm = Me.Name
        tripeditref.txttransid.Text = grdtrans4.Rows(selectedrow).Cells(0).Value
        tripeditref.txttransnum.Text = grdtrans4.Rows(selectedrow).Cells(1).Value
        tripeditref.txtcus.Text = grdtrans4.Rows(selectedrow).Cells(3).Value
        tripeditref.ShowDialog()

        If edited = True Then
            grdtrans4.Rows(selectedrow).Cells(2).Value = tripeditref.refnum
        End If
    End Sub

    Private Sub ViewRefHistoryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewRefHistoryToolStripMenuItem.Click
        transoredit.lbltrans.Text = grdtrans4.Item(1, grdtrans4.CurrentRow.Index).Value
        transoredit.lblcus.Text = grdtrans4.Item(3, grdtrans4.CurrentRow.Index).Value
        transoredit.ShowDialog()
    End Sub

    Private Sub tripinfolink_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles tripinfolink.LinkClicked
        viewtripinfo.lblid.Text = tripdispatchsum.grddispatch.Item(0, tripdispatchsum.grddispatch.CurrentRow.Index).Value.ToString
        viewtripinfo.lbltripnum.Text = lbltripnum1.Text
        viewtripinfo.Text = "Trip Information (" & lbltripnum1.Text & ")"
        viewtripinfo.ShowDialog()
        linkcheck = True
    End Sub

    Public Sub notfinish()
        Label9.Visible = False
        txtcomment.Visible = False
        btncomment.Visible = False
    End Sub

    Public Sub finish()
        Label9.Visible = True
        txtcomment.Visible = True
        btncomment.Visible = True
    End Sub

    Private Sub grdtrans4_CellPainting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles grdtrans4.CellPainting
        If e.Handled Then
            Exit Sub 'Already handled.
        End If

        'Paint everything except the ErrorIcon the standard way.
        e.Paint(e.ClipBounds, e.PaintParts And Not DataGridViewPaintParts.ErrorIcon)

        'Paint the ErrorIcon, if necessary, the custom way.
        If (e.PaintParts And DataGridViewPaintParts.ErrorIcon) = DataGridViewPaintParts.ErrorIcon Then
            If e.ErrorText <> "" Then
                With e.Graphics
                    Dim gstate As Drawing2D.GraphicsState = .Save()
                    Dim iconRect As Rectangle = New Rectangle(e.CellBounds.Right - 20, e.CellBounds.Top + e.CellBounds.Height \ 2 - 6, 12, 12)
                    Dim backColor As Color
                    If (e.State And DataGridViewElementStates.Selected) = DataGridViewElementStates.Selected Then
                        backColor = e.CellStyle.SelectionBackColor
                    Else
                        backColor = e.CellStyle.BackColor
                    End If

                    'Restrict drawing within cell boundaries.
                    .SetClip(e.CellBounds)
                    'Clear background area behind the icon.
                    Using brush As New SolidBrush(backColor)
                        .FillRectangle(brush, iconRect)
                    End Using
                    'Draw the icon.
                    .DrawIcon(SystemIcons.Information, iconRect)
                    .Restore(gstate)
                End With
            End If
        End If

        e.Handled = True
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        '/ListBox1.Items.Add(login.cashier & "-" & Date.Now & " - " & txtcomment.Text)
    End Sub

    Dim clickedit As String = ""
    Private Sub btnodobeg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnodobeg.Click
        clickedit = btnodobeg.Tag

        If login.neym = "Administrator" Or login.neym = "Supervisor" Or login.neym = "Logistics Staff" Then
            viewvisiblefalse()
            EditToolStripMenuItem.Text = "Edit " & clickedit
            EditToolStripMenuItem.Visible = True
            ViewEditHistoryToolStripMenuItem.Visible = True
            Me.ContextMenuStrip1.Show(Cursor.Position)
        Else
            tripsumedit.tayp = clickedit
            tripsumedit.lbltripnum.Text = lbltripnum1.Text
            tripsumedit.ShowDialog()
        End If
    End Sub

    Private Sub EditToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditToolStripMenuItem.Click
        tripeditothers.tayp = clickedit
        tripeditothers.txttripnum.Text = lbltripnum1.Text
        tripeditothers.ShowDialog()
    End Sub

    Private Sub ViewEditHistoryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewEditHistoryToolStripMenuItem.Click
        tripsumedit.tayp = clickedit
        tripsumedit.lbltripnum.Text = lbltripnum1.Text
        tripsumedit.ShowDialog()
    End Sub

    Private Sub btnodoend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnodoend.Click
        clickedit = btnodoend.Tag

        If login.neym = "Administrator" Or login.neym = "Supervisor" Or login.neym = "Logistics Staff" Then
            viewvisiblefalse()
            EditToolStripMenuItem.Text = "Edit " & clickedit
            EditToolStripMenuItem.Visible = True
            ViewEditHistoryToolStripMenuItem.Visible = True
            Me.ContextMenuStrip1.Show(Cursor.Position)
        Else
            tripsumedit.tayp = clickedit
            tripsumedit.lbltripnum.Text = lbltripnum1.Text
            tripsumedit.ShowDialog()
        End If
    End Sub
End Class