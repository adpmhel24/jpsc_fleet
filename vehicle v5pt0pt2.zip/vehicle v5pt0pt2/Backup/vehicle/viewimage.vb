﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing.Printing

Public Class viewimage
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String
    Friend WithEvents prntDoc As New PrintDocument()

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub viewimage_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub viewimage_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        lblimgname.Text = ""
        imgbox.Width = 1350
        imgbox.Height = 650
        imgbox.Location = New System.Drawing.Point(11, 11)
        imgbox.SizeMode = PictureBoxSizeMode.Zoom
        Panel1.AutoScrollPosition = New Point(Integer.Parse(11), Integer.Parse(11))
    End Sub

    Private Sub viewimage_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.Control And e.KeyCode.ToString = "P" Then
            ' When the user presses both the 'ALT' key and 'F' key,
            ' KeyPreview is set to False, and a message appears.
            ' This message is only displayed when KeyPreview is set to True.
            Me.KeyPreview = False
            'MsgBox("KeyPreview is True, and this is from the FORM.")
            Button1.PerformClick()
        End If
    End Sub

    Private Sub viewimage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Me.KeyPreview = True
            sql = "Select * from tblimage where imgid='" & lblimgid.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                imgbox.Image = Image.FromStream(ms)
                imgbox.SizeMode = PictureBoxSizeMode.Zoom
                imgbox.BorderStyle = BorderStyle.FixedSingle
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            '1350, 650
            imgbox.Width = 1350
            imgbox.Height = 650
            imgbox.Location = New System.Drawing.Point(11, 11)
            imgbox.SizeMode = PictureBoxSizeMode.Zoom


        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub prntDoc_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles prntDoc.PrintPage
        e.Graphics.DrawImage(Me.imgbox.Image, 0, 0)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim prnDialog As New PrintDialog()
        prnDialog.Document = prntDoc
        prnDialog.UseEXDialog = True
        ' Optional Dialog:   
        Dim r As DialogResult = prnDialog.ShowDialog
        If r = DialogResult.OK Then
            prntDoc.Print()
        End If
    End Sub

    Private Sub btnzin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnzin.Click
        imgbox.Width *= 1.2
        imgbox.Height *= 1.2
    End Sub

    Private Sub btnzout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnzout.Click
        imgbox.Width *= 0.8
        imgbox.Height *= 0.8

        If imgbox.Width < 991 Then
            imgbox.Width = 991
            imgbox.Height = 532
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        imgbox.Image.RotateFlip(RotateFlipType.Rotate90FlipNone)
        imgbox.Refresh()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim bitmap1 As Bitmap
        bitmap1 = CType(imgbox.Image, Bitmap)
        If bitmap1 IsNot Nothing Then
            bitmap1.RotateFlip(RotateFlipType.Rotate180FlipY)
            imgbox.Image = bitmap1
        End If
    End Sub

    Private Sub btnnext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnext.Click
        'imgbox.Width = 1350
        'imgbox.Height = 650
        'imgbox.Location = New System.Drawing.Point(11, 11)
        'imgbox.SizeMode = PictureBoxSizeMode.Zoom

        Dim ctr As Integer = 0, pic As Integer = 0, lbl As Integer = 0
        For Each n As Control In viewstep1.imgpanel1.Controls
            If TypeOf n Is Label Then
                If n.Text = lblimgname.Text Then
                    '/MsgBox(ctr)
                    Exit For
                End If
                ctr += 1
            End If
        Next

        For Each n As Control In viewstep1.imgpanel1.Controls
            If TypeOf n Is PictureBox Then
                If ctr + 1 = pic Then
                    '/MsgBox(ctr + 1 & " " & pic)
                    Dim pb As PictureBox = DirectCast(n, PictureBox)
                    imgbox.Image = pb.Image

                    lbl = 0
                    For Each n2 As Control In viewstep1.imgpanel1.Controls
                        If TypeOf n2 Is Label Then
                            If ctr + 1 = lbl Then
                                lblimgname.Text = n2.Text
                                Exit For
                            End If
                            lbl += 1
                        End If
                    Next

                End If
                pic += 1
            End If
        Next
    End Sub

    Private Sub btnprev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprev.Click
        'imgbox.Width = 1350
        'imgbox.Height = 650
        'imgbox.Location = New System.Drawing.Point(11, 11)
        'imgbox.SizeMode = PictureBoxSizeMode.Zoom

        Dim ctr As Integer = 0, pic As Integer = 0, lbl As Integer = 0
        For Each n As Control In viewstep1.imgpanel1.Controls
            If TypeOf n Is Label Then
                If n.Text = lblimgname.Text Then
                    '/MsgBox(ctr)
                    Exit For
                End If
                ctr += 1
            End If
        Next

        For Each n As Control In viewstep1.imgpanel1.Controls
            If TypeOf n Is PictureBox Then
                If ctr - 1 = pic Then
                    '/MsgBox(ctr - 1 & " " & pic)
                    Dim pb As PictureBox = DirectCast(n, PictureBox)
                    imgbox.Image = pb.Image

                    lbl = 0
                    For Each n2 As Control In viewstep1.imgpanel1.Controls
                        If TypeOf n2 Is Label Then
                            If ctr - 1 = lbl Then
                                lblimgname.Text = n2.Text
                                Exit For
                            End If
                            lbl += 1
                        End If
                    Next

                End If
                pic += 1
            End If
        Next
    End Sub
End Class