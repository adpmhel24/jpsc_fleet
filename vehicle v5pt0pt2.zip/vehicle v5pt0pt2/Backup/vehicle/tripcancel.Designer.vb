﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class tripcancel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(tripcancel))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lblreturn = New System.Windows.Forms.Label
        Me.lblvtype = New System.Windows.Forms.Label
        Me.btndelete = New System.Windows.Forms.Button
        Me.btnreschedule = New System.Windows.Forms.Button
        Me.btnremove = New System.Windows.Forms.Button
        Me.btncanceltrip = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.lbltripnum = New System.Windows.Forms.Label
        Me.btncancel = New System.Windows.Forms.Button
        Me.grdadd = New System.Windows.Forms.DataGridView
        Me.itemname = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.itemdes = New System.Windows.Forms.DataGridViewLinkColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.unit = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.unitprice = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.totalcost = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.remarks = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.GroupBox1.SuspendLayout()
        CType(Me.grdadd, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.lblreturn)
        Me.GroupBox1.Controls.Add(Me.lblvtype)
        Me.GroupBox1.Controls.Add(Me.btndelete)
        Me.GroupBox1.Controls.Add(Me.btnreschedule)
        Me.GroupBox1.Controls.Add(Me.btnremove)
        Me.GroupBox1.Controls.Add(Me.btncanceltrip)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.lbltripnum)
        Me.GroupBox1.Controls.Add(Me.btncancel)
        Me.GroupBox1.Controls.Add(Me.grdadd)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(964, 531)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'lblreturn
        '
        Me.lblreturn.AutoSize = True
        Me.lblreturn.Location = New System.Drawing.Point(858, 15)
        Me.lblreturn.Name = "lblreturn"
        Me.lblreturn.Size = New System.Drawing.Size(58, 15)
        Me.lblreturn.TabIndex = 20
        Me.lblreturn.Text = "Returned"
        '
        'lblvtype
        '
        Me.lblvtype.AutoSize = True
        Me.lblvtype.Location = New System.Drawing.Point(561, 15)
        Me.lblvtype.Name = "lblvtype"
        Me.lblvtype.Size = New System.Drawing.Size(0, 15)
        Me.lblvtype.TabIndex = 19
        Me.lblvtype.Visible = False
        '
        'btndelete
        '
        Me.btndelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btndelete.Image = CType(resources.GetObject("btndelete.Image"), System.Drawing.Image)
        Me.btndelete.Location = New System.Drawing.Point(889, 467)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(22, 23)
        Me.btndelete.TabIndex = 18
        Me.btndelete.Text = "Delete Customer Transaction"
        Me.btndelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btndelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btndelete.UseVisualStyleBackColor = True
        Me.btndelete.Visible = False
        '
        'btnreschedule
        '
        Me.btnreschedule.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnreschedule.Image = CType(resources.GetObject("btnreschedule.Image"), System.Drawing.Image)
        Me.btnreschedule.Location = New System.Drawing.Point(861, 467)
        Me.btnreschedule.Name = "btnreschedule"
        Me.btnreschedule.Size = New System.Drawing.Size(22, 23)
        Me.btnreschedule.TabIndex = 16
        Me.btnreschedule.Text = "Cancel Customer Transaction"
        Me.btnreschedule.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnreschedule.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnreschedule.UseVisualStyleBackColor = True
        Me.btnreschedule.Visible = False
        '
        'btnremove
        '
        Me.btnremove.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnremove.Image = CType(resources.GetObject("btnremove.Image"), System.Drawing.Image)
        Me.btnremove.Location = New System.Drawing.Point(6, 495)
        Me.btnremove.Name = "btnremove"
        Me.btnremove.Size = New System.Drawing.Size(241, 23)
        Me.btnremove.TabIndex = 15
        Me.btnremove.Text = "Remove Customer Transaction"
        Me.btnremove.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnremove.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnremove.UseVisualStyleBackColor = True
        '
        'btncanceltrip
        '
        Me.btncanceltrip.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncanceltrip.Image = CType(resources.GetObject("btncanceltrip.Image"), System.Drawing.Image)
        Me.btncanceltrip.Location = New System.Drawing.Point(6, 495)
        Me.btncanceltrip.Name = "btncanceltrip"
        Me.btncanceltrip.Size = New System.Drawing.Size(164, 23)
        Me.btncanceltrip.TabIndex = 13
        Me.btncanceltrip.Text = "Cancel Trip Only"
        Me.btncanceltrip.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncanceltrip.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncanceltrip.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(-11, 468)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(10, 10)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(60, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 15)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Trip #:"
        '
        'lbltripnum
        '
        Me.lbltripnum.AutoSize = True
        Me.lbltripnum.Location = New System.Drawing.Point(107, 15)
        Me.lbltripnum.Name = "lbltripnum"
        Me.lbltripnum.Size = New System.Drawing.Size(53, 15)
        Me.lbltripnum.TabIndex = 11
        Me.lbltripnum.Text = "Tripnum"
        '
        'btncancel
        '
        Me.btncancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncancel.Image = CType(resources.GetObject("btncancel.Image"), System.Drawing.Image)
        Me.btncancel.Location = New System.Drawing.Point(917, 467)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(41, 23)
        Me.btncancel.TabIndex = 10
        Me.btncancel.Text = "Cancel Order Transactions"
        Me.btncancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancel.UseVisualStyleBackColor = True
        Me.btncancel.Visible = False
        '
        'grdadd
        '
        Me.grdadd.AllowUserToAddRows = False
        Me.grdadd.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdadd.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdadd.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdadd.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdadd.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdadd.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdadd.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.grdadd.ColumnHeadersHeight = 30
        Me.grdadd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdadd.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.itemname, Me.Column2, Me.itemdes, Me.Column3, Me.unit, Me.unitprice, Me.Column1, Me.totalcost, Me.remarks, Me.Column4})
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdadd.DefaultCellStyle = DataGridViewCellStyle4
        Me.grdadd.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdadd.EnableHeadersVisualStyles = False
        Me.grdadd.GridColor = System.Drawing.Color.Salmon
        Me.grdadd.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdadd.Location = New System.Drawing.Point(6, 40)
        Me.grdadd.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdadd.Name = "grdadd"
        Me.grdadd.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdadd.RowHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.grdadd.RowHeadersWidth = 10
        Me.grdadd.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.NullValue = Nothing
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdadd.RowsDefaultCellStyle = DataGridViewCellStyle6
        Me.grdadd.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdadd.Size = New System.Drawing.Size(952, 439)
        Me.grdadd.TabIndex = 4
        '
        'itemname
        '
        Me.itemname.HeaderText = "ID"
        Me.itemname.MinimumWidth = 100
        Me.itemname.Name = "itemname"
        Me.itemname.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.itemname.Visible = False
        '
        'Column2
        '
        Me.Column2.HeaderText = "Select"
        Me.Column2.MinimumWidth = 80
        Me.Column2.Name = "Column2"
        Me.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column2.Width = 80
        '
        'itemdes
        '
        Me.itemdes.ActiveLinkColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White
        Me.itemdes.DefaultCellStyle = DataGridViewCellStyle3
        Me.itemdes.HeaderText = "Transaction #"
        Me.itemdes.LinkColor = System.Drawing.Color.Red
        Me.itemdes.MinimumWidth = 120
        Me.itemdes.Name = "itemdes"
        Me.itemdes.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.itemdes.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.itemdes.VisitedLinkColor = System.Drawing.Color.Red
        Me.itemdes.Width = 120
        '
        'Column3
        '
        Me.Column3.HeaderText = "Reference #"
        Me.Column3.MinimumWidth = 150
        Me.Column3.Name = "Column3"
        Me.Column3.Width = 150
        '
        'unit
        '
        Me.unit.HeaderText = "Booked Date"
        Me.unit.MinimumWidth = 100
        Me.unit.Name = "unit"
        Me.unit.Visible = False
        '
        'unitprice
        '
        Me.unitprice.HeaderText = "Destination"
        Me.unitprice.MinimumWidth = 220
        Me.unitprice.Name = "unitprice"
        Me.unitprice.Width = 220
        '
        'Column1
        '
        Me.Column1.HeaderText = "Transaction Type"
        Me.Column1.MinimumWidth = 230
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 230
        '
        'totalcost
        '
        Me.totalcost.HeaderText = "Status"
        Me.totalcost.MinimumWidth = 120
        Me.totalcost.Name = "totalcost"
        Me.totalcost.Width = 120
        '
        'remarks
        '
        Me.remarks.HeaderText = "Notes"
        Me.remarks.MinimumWidth = 180
        Me.remarks.Name = "remarks"
        Me.remarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.remarks.Visible = False
        Me.remarks.Width = 180
        '
        'Column4
        '
        Me.Column4.HeaderText = "tripitemsid"
        Me.Column4.Name = "Column4"
        '
        'tripcancel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(988, 555)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "tripcancel"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cancel Trip or Transactions"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.grdadd, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents grdadd As System.Windows.Forms.DataGridView
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbltripnum As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btncanceltrip As System.Windows.Forms.Button
    Friend WithEvents btnremove As System.Windows.Forms.Button
    Friend WithEvents btnreschedule As System.Windows.Forms.Button
    Friend WithEvents btndelete As System.Windows.Forms.Button
    Friend WithEvents lblvtype As System.Windows.Forms.Label
    Friend WithEvents lblreturn As System.Windows.Forms.Label
    Friend WithEvents itemname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents itemdes As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents unit As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents unitprice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents totalcost As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents remarks As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
