﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class tripdispatch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(tripdispatch))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle31 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle32 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle33 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle34 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle35 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle36 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle38 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle39 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle40 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle37 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle41 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle42 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle43 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle44 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle45 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle46 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle47 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle49 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle50 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle51 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle48 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle52 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle53 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle55 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle56 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle57 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle54 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle58 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle59 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle60 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle61 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle62 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle63 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle64 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle66 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle67 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle68 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle65 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle69 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle70 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle72 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle73 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle74 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle71 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle75 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle76 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle77 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle78 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle79 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.tab1 = New System.Windows.Forms.TabPage
        Me.panelstp1 = New System.Windows.Forms.Panel
        Me.gstep1 = New System.Windows.Forms.GroupBox
        Me.lblload1 = New System.Windows.Forms.Label
        Me.btnrefstep1 = New System.Windows.Forms.Button
        Me.grdstep1 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column20 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column28 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.grp1 = New System.Windows.Forms.GroupBox
        Me.lblimgname1 = New System.Windows.Forms.Label
        Me.lblimgdate1 = New System.Windows.Forms.Label
        Me.tripinfo1 = New System.Windows.Forms.LinkLabel
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.lblDesiredSize = New System.Windows.Forms.TextBox
        Me.lblOriginalSize = New System.Windows.Forms.Label
        Me.lblCompressedSize = New System.Windows.Forms.Label
        Me.lblCompressionLevel = New System.Windows.Forms.Label
        Me.pgbar1 = New System.Windows.Forms.ProgressBar
        Me.lblconfirm1 = New System.Windows.Forms.Label
        Me.btnstartpre = New System.Windows.Forms.Button
        Me.lbltype1 = New System.Windows.Forms.Label
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel18 = New System.Windows.Forms.Panel
        Me.txtodo = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Panel20 = New System.Windows.Forms.Panel
        Me.btnodo = New System.Windows.Forms.Button
        Me.txtodoend1 = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.cmbimg1 = New System.Windows.Forms.ComboBox
        Me.txtrems1 = New System.Windows.Forms.TextBox
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.btnexempt1 = New System.Windows.Forms.Button
        Me.btnconfirm1 = New System.Windows.Forms.Button
        Me.Label32 = New System.Windows.Forms.Label
        Me.lbltripnum1 = New System.Windows.Forms.Label
        Me.lblplate1 = New System.Windows.Forms.Label
        Me.btnimgdl1 = New System.Windows.Forms.Button
        Me.lblimgid1 = New System.Windows.Forms.Label
        Me.btnimgfull1 = New System.Windows.Forms.Button
        Me.imgpanel1 = New System.Windows.Forms.Panel
        Me.imgbox1 = New System.Windows.Forms.PictureBox
        Me.btnimgremove1 = New System.Windows.Forms.Button
        Me.btnimgadd1 = New System.Windows.Forms.Button
        Me.btnimgcancel1 = New System.Windows.Forms.Button
        Me.btnimgrefresh1 = New System.Windows.Forms.Button
        Me.btnimgrename1 = New System.Windows.Forms.Button
        Me.tab2 = New System.Windows.Forms.TabPage
        Me.panelstp2 = New System.Windows.Forms.Panel
        Me.gstep2 = New System.Windows.Forms.GroupBox
        Me.lblload2 = New System.Windows.Forms.Label
        Me.cmbtrans2 = New System.Windows.Forms.ComboBox
        Me.btnrefstep2 = New System.Windows.Forms.Button
        Me.grdstep2 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn70 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column29 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.grp2 = New System.Windows.Forms.GroupBox
        Me.Panelinch2 = New System.Windows.Forms.Panel
        Me.btninch2cancel = New System.Windows.Forms.Button
        Me.btninch2ok = New System.Windows.Forms.Button
        Me.Label24 = New System.Windows.Forms.Label
        Me.txtinch2 = New System.Windows.Forms.TextBox
        Me.lblimgname2 = New System.Windows.Forms.Label
        Me.lblimgdate2 = New System.Windows.Forms.Label
        Me.tripinfo2 = New System.Windows.Forms.LinkLabel
        Me.pgbar2 = New System.Windows.Forms.ProgressBar
        Me.lblconfirm2 = New System.Windows.Forms.Label
        Me.lblmake2 = New System.Windows.Forms.Label
        Me.lbltype2 = New System.Windows.Forms.Label
        Me.btnstartdiesel = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel13 = New System.Windows.Forms.Panel
        Me.txtpo = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Panel9 = New System.Windows.Forms.Panel
        Me.btnpo = New System.Windows.Forms.Button
        Me.txtaddpo = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.lblfull = New System.Windows.Forms.Label
        Me.txtdestin = New System.Windows.Forms.TextBox
        Me.lblinch = New System.Windows.Forms.Label
        Me.lblpwout = New System.Windows.Forms.Label
        Me.lblpwith = New System.Windows.Forms.Label
        Me.Panel7 = New System.Windows.Forms.Panel
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel15 = New System.Windows.Forms.Panel
        Me.btninch2 = New System.Windows.Forms.Button
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtdiesel = New System.Windows.Forms.TextBox
        Me.Panel10 = New System.Windows.Forms.Panel
        Me.btndis = New System.Windows.Forms.Button
        Me.txtdieselbeg1 = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.dieselpanel3 = New System.Windows.Forms.Panel
        Me.txtdshould = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel16 = New System.Windows.Forms.Panel
        Me.txtdiswout = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel12 = New System.Windows.Forms.Panel
        Me.txtdiswith = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.cmbimg2 = New System.Windows.Forms.ComboBox
        Me.txtrems2 = New System.Windows.Forms.TextBox
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.btnexempt2 = New System.Windows.Forms.Button
        Me.btnconfirm2 = New System.Windows.Forms.Button
        Me.lbltripnum2 = New System.Windows.Forms.Label
        Me.lblplate2 = New System.Windows.Forms.Label
        Me.btnimgdl2 = New System.Windows.Forms.Button
        Me.lblimgid2 = New System.Windows.Forms.Label
        Me.btnimgfull2 = New System.Windows.Forms.Button
        Me.imgpanel2 = New System.Windows.Forms.Panel
        Me.imgbox2 = New System.Windows.Forms.PictureBox
        Me.btnimgremove2 = New System.Windows.Forms.Button
        Me.btnimgadd2 = New System.Windows.Forms.Button
        Me.btnimgcancel2 = New System.Windows.Forms.Button
        Me.btnimgrefresh2 = New System.Windows.Forms.Button
        Me.btnimgrename2 = New System.Windows.Forms.Button
        Me.tab3 = New System.Windows.Forms.TabPage
        Me.panelstp3 = New System.Windows.Forms.Panel
        Me.gstep3 = New System.Windows.Forms.GroupBox
        Me.lblload3 = New System.Windows.Forms.Label
        Me.cmbtrans3 = New System.Windows.Forms.ComboBox
        Me.btnrefstep3 = New System.Windows.Forms.Button
        Me.grdstep3 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn71 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn89 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.grp3 = New System.Windows.Forms.GroupBox
        Me.lblimgname3 = New System.Windows.Forms.Label
        Me.lblimgdate3 = New System.Windows.Forms.Label
        Me.tripinfo3 = New System.Windows.Forms.LinkLabel
        Me.grdtrans3 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn79 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewLinkColumn2 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.DataGridViewTextBoxColumn80 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn81 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn82 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn83 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn84 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn85 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn86 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column33 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column34 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn87 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn88 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.pgbar3 = New System.Windows.Forms.ProgressBar
        Me.lblconfirm3 = New System.Windows.Forms.Label
        Me.lbltype3 = New System.Windows.Forms.Label
        Me.btnstartload = New System.Windows.Forms.Button
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.txtlabor = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.cmbimg3 = New System.Windows.Forms.ComboBox
        Me.txtrems3 = New System.Windows.Forms.TextBox
        Me.Panel8 = New System.Windows.Forms.Panel
        Me.btnexempt3 = New System.Windows.Forms.Button
        Me.btnnot3 = New System.Windows.Forms.Button
        Me.btnconfirm3 = New System.Windows.Forms.Button
        Me.lbltripnum3 = New System.Windows.Forms.Label
        Me.lblplate3 = New System.Windows.Forms.Label
        Me.btnimgdl3 = New System.Windows.Forms.Button
        Me.lblimgid3 = New System.Windows.Forms.Label
        Me.btnimgfull3 = New System.Windows.Forms.Button
        Me.imgpanel3 = New System.Windows.Forms.Panel
        Me.imgbox3 = New System.Windows.Forms.PictureBox
        Me.btnimgremove3 = New System.Windows.Forms.Button
        Me.btnimgadd3 = New System.Windows.Forms.Button
        Me.btnimgcancel3 = New System.Windows.Forms.Button
        Me.btnimgrefresh3 = New System.Windows.Forms.Button
        Me.btnimgrename3 = New System.Windows.Forms.Button
        Me.tab4 = New System.Windows.Forms.TabPage
        Me.panelstp4 = New System.Windows.Forms.Panel
        Me.gstep4 = New System.Windows.Forms.GroupBox
        Me.lblload4 = New System.Windows.Forms.Label
        Me.cmbtrans4 = New System.Windows.Forms.ComboBox
        Me.btnrefstep4 = New System.Windows.Forms.Button
        Me.grdstep4 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn72 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn90 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.grp4 = New System.Windows.Forms.GroupBox
        Me.lblimgname4 = New System.Windows.Forms.Label
        Me.lblimgdate4 = New System.Windows.Forms.Label
        Me.tripinfo4 = New System.Windows.Forms.LinkLabel
        Me.pgbar4 = New System.Windows.Forms.ProgressBar
        Me.lblconfirm4 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.lbltype4 = New System.Windows.Forms.Label
        Me.btnstartdoc = New System.Windows.Forms.Button
        Me.grdtrans4 = New System.Windows.Forms.DataGridView
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column10 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Column4 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column21 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.cmbimg4 = New System.Windows.Forms.ComboBox
        Me.txtrems4 = New System.Windows.Forms.TextBox
        Me.Panel11 = New System.Windows.Forms.Panel
        Me.btnexempt4 = New System.Windows.Forms.Button
        Me.btnconfirm4 = New System.Windows.Forms.Button
        Me.lbltripnum4 = New System.Windows.Forms.Label
        Me.lblplate4 = New System.Windows.Forms.Label
        Me.btnimgdl4 = New System.Windows.Forms.Button
        Me.lblimgid4 = New System.Windows.Forms.Label
        Me.btnimgfull4 = New System.Windows.Forms.Button
        Me.imgpanel4 = New System.Windows.Forms.Panel
        Me.imgbox4 = New System.Windows.Forms.PictureBox
        Me.btnimgremove4 = New System.Windows.Forms.Button
        Me.btnimgadd4 = New System.Windows.Forms.Button
        Me.btnimgcancel4 = New System.Windows.Forms.Button
        Me.btnimgrefresh4 = New System.Windows.Forms.Button
        Me.btnimgrename4 = New System.Windows.Forms.Button
        Me.tab5 = New System.Windows.Forms.TabPage
        Me.panelstp5 = New System.Windows.Forms.Panel
        Me.gstep5 = New System.Windows.Forms.GroupBox
        Me.lblload5 = New System.Windows.Forms.Label
        Me.cmbtrans5 = New System.Windows.Forms.ComboBox
        Me.btnrefstep5 = New System.Windows.Forms.Button
        Me.grdstep5 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn73 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn91 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.grp5 = New System.Windows.Forms.GroupBox
        Me.lblimgname5 = New System.Windows.Forms.Label
        Me.lblimgdate5 = New System.Windows.Forms.Label
        Me.tripinfo5 = New System.Windows.Forms.LinkLabel
        Me.pgbar5 = New System.Windows.Forms.ProgressBar
        Me.lblconfirm5 = New System.Windows.Forms.Label
        Me.btnstartcash = New System.Windows.Forms.Button
        Me.lbltype5 = New System.Windows.Forms.Label
        Me.grdtrans5 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn26 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn27 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.DataGridViewTextBoxColumn28 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn29 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn30 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn31 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn32 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn33 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn34 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn35 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn36 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.cmbimg5 = New System.Windows.Forms.ComboBox
        Me.txtrems5 = New System.Windows.Forms.TextBox
        Me.Panel14 = New System.Windows.Forms.Panel
        Me.btnexempt5 = New System.Windows.Forms.Button
        Me.btnconfirm5 = New System.Windows.Forms.Button
        Me.lbltripnum5 = New System.Windows.Forms.Label
        Me.lblplate5 = New System.Windows.Forms.Label
        Me.btnimgdl5 = New System.Windows.Forms.Button
        Me.lblimgid5 = New System.Windows.Forms.Label
        Me.btnimgfull5 = New System.Windows.Forms.Button
        Me.imgpanel5 = New System.Windows.Forms.Panel
        Me.imgbox5 = New System.Windows.Forms.PictureBox
        Me.btnimgremove5 = New System.Windows.Forms.Button
        Me.btnimgadd5 = New System.Windows.Forms.Button
        Me.btnimgcancel5 = New System.Windows.Forms.Button
        Me.btnimgrefresh5 = New System.Windows.Forms.Button
        Me.btnimgrename5 = New System.Windows.Forms.Button
        Me.tab6 = New System.Windows.Forms.TabPage
        Me.panelstp6 = New System.Windows.Forms.Panel
        Me.gstep6 = New System.Windows.Forms.GroupBox
        Me.lblload6 = New System.Windows.Forms.Label
        Me.cmbtrans6 = New System.Windows.Forms.ComboBox
        Me.btnrefstep6 = New System.Windows.Forms.Button
        Me.grdstep6 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn24 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn74 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn92 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column23 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.grp6 = New System.Windows.Forms.GroupBox
        Me.lblpup6 = New System.Windows.Forms.Label
        Me.pgbar6 = New System.Windows.Forms.ProgressBar
        Me.lblconfirm6 = New System.Windows.Forms.Label
        Me.txtcustomer = New System.Windows.Forms.TextBox
        Me.btndepart = New System.Windows.Forms.Button
        Me.lbltype6 = New System.Windows.Forms.Label
        Me.txtetd = New System.Windows.Forms.TextBox
        Me.cmbimg6 = New System.Windows.Forms.ComboBox
        Me.txtrems6 = New System.Windows.Forms.TextBox
        Me.Panel17 = New System.Windows.Forms.Panel
        Me.btnexempt6 = New System.Windows.Forms.Button
        Me.btnmtc = New System.Windows.Forms.Button
        Me.btnother6 = New System.Windows.Forms.Button
        Me.btnconfirm6 = New System.Windows.Forms.Button
        Me.lbltripnum6 = New System.Windows.Forms.Label
        Me.lblplate6 = New System.Windows.Forms.Label
        Me.btnimgdl6 = New System.Windows.Forms.Button
        Me.lblimgid6 = New System.Windows.Forms.Label
        Me.btnimgfull6 = New System.Windows.Forms.Button
        Me.imgpanel6 = New System.Windows.Forms.Panel
        Me.imgbox6 = New System.Windows.Forms.PictureBox
        Me.btnimgremove6 = New System.Windows.Forms.Button
        Me.btnimgadd6 = New System.Windows.Forms.Button
        Me.btnimgcancel6 = New System.Windows.Forms.Button
        Me.btnimgrefresh6 = New System.Windows.Forms.Button
        Me.btnimgrename6 = New System.Windows.Forms.Button
        Me.tab7 = New System.Windows.Forms.TabPage
        Me.panelstp7 = New System.Windows.Forms.Panel
        Me.gstep7 = New System.Windows.Forms.GroupBox
        Me.lbls7 = New System.Windows.Forms.Label
        Me.btntrip7 = New System.Windows.Forms.Button
        Me.txts7 = New System.Windows.Forms.TextBox
        Me.lblload7 = New System.Windows.Forms.Label
        Me.cmbtrans7 = New System.Windows.Forms.ComboBox
        Me.btnrefstep7 = New System.Windows.Forms.Button
        Me.grdstep7 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn37 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn38 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn39 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn40 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn75 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn93 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.grp7 = New System.Windows.Forms.GroupBox
        Me.link2to7 = New System.Windows.Forms.LinkLabel
        Me.lblpick7 = New System.Windows.Forms.Label
        Me.lblimgname7 = New System.Windows.Forms.Label
        Me.lblimgdate7 = New System.Windows.Forms.Label
        Me.txtpo7 = New System.Windows.Forms.TextBox
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.tripinfo7 = New System.Windows.Forms.LinkLabel
        Me.Label23 = New System.Windows.Forms.Label
        Me.btnimgdl7 = New System.Windows.Forms.Button
        Me.pgbar7 = New System.Windows.Forms.ProgressBar
        Me.lblconfirm7 = New System.Windows.Forms.Label
        Me.btnstartreturn = New System.Windows.Forms.Button
        Me.lbltype7 = New System.Windows.Forms.Label
        Me.grdtrans7 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn41 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn42 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.DataGridViewTextBoxColumn43 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn44 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column24 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Column31 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.DataGridViewTextBoxColumn45 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn46 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn47 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn48 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn49 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn50 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn51 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn96 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn97 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column27 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.cmbimg7 = New System.Windows.Forms.ComboBox
        Me.txtrems7 = New System.Windows.Forms.TextBox
        Me.Panel19 = New System.Windows.Forms.Panel
        Me.chkpending = New System.Windows.Forms.CheckBox
        Me.btnexempt7 = New System.Windows.Forms.Button
        Me.btnconfirm7 = New System.Windows.Forms.Button
        Me.lbltripnum7 = New System.Windows.Forms.Label
        Me.lblplate7 = New System.Windows.Forms.Label
        Me.lblimgid7 = New System.Windows.Forms.Label
        Me.btnimgfull7 = New System.Windows.Forms.Button
        Me.imgpanel7 = New System.Windows.Forms.Panel
        Me.imgbox7 = New System.Windows.Forms.PictureBox
        Me.btnimgremove7 = New System.Windows.Forms.Button
        Me.btnimgadd7 = New System.Windows.Forms.Button
        Me.btnimgcancel7 = New System.Windows.Forms.Button
        Me.btnimgrefresh7 = New System.Windows.Forms.Button
        Me.btnimgrename7 = New System.Windows.Forms.Button
        Me.tab8 = New System.Windows.Forms.TabPage
        Me.panelstp8 = New System.Windows.Forms.Panel
        Me.gstep8 = New System.Windows.Forms.GroupBox
        Me.lblload8 = New System.Windows.Forms.Label
        Me.cmbtrans8 = New System.Windows.Forms.ComboBox
        Me.btnrefstep8 = New System.Windows.Forms.Button
        Me.grdstep8 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn52 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn53 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn54 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn55 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn76 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn94 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.grp8 = New System.Windows.Forms.GroupBox
        Me.Panelinch8 = New System.Windows.Forms.Panel
        Me.btninch8cancel = New System.Windows.Forms.Button
        Me.btninch8ok = New System.Windows.Forms.Button
        Me.Label22 = New System.Windows.Forms.Label
        Me.txtinch8 = New System.Windows.Forms.TextBox
        Me.lblimgname8 = New System.Windows.Forms.Label
        Me.lblimgdate8 = New System.Windows.Forms.Label
        Me.tripinfo8 = New System.Windows.Forms.LinkLabel
        Me.pgbar8 = New System.Windows.Forms.ProgressBar
        Me.lblconfirm8 = New System.Windows.Forms.Label
        Me.lblmake8 = New System.Windows.Forms.Label
        Me.lbltaxi = New System.Windows.Forms.Label
        Me.lbltype8 = New System.Windows.Forms.Label
        Me.btnstartpost = New System.Windows.Forms.Button
        Me.Panel23 = New System.Windows.Forms.Panel
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel26 = New System.Windows.Forms.Panel
        Me.txtodobeg = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Panel24 = New System.Windows.Forms.Panel
        Me.txtodoend = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.txtdestin8 = New System.Windows.Forms.TextBox
        Me.Panel21 = New System.Windows.Forms.Panel
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel25 = New System.Windows.Forms.Panel
        Me.txttotaldiesel = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.btninch8 = New System.Windows.Forms.Button
        Me.txtdieselend = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Panel22 = New System.Windows.Forms.Panel
        Me.txtpostpo = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.cmbimg8 = New System.Windows.Forms.ComboBox
        Me.txtrems8 = New System.Windows.Forms.TextBox
        Me.Panel29 = New System.Windows.Forms.Panel
        Me.btnexempt8 = New System.Windows.Forms.Button
        Me.btnconfirm8 = New System.Windows.Forms.Button
        Me.lbltripnum8 = New System.Windows.Forms.Label
        Me.lblplate8 = New System.Windows.Forms.Label
        Me.btnimgdl8 = New System.Windows.Forms.Button
        Me.lblimgid8 = New System.Windows.Forms.Label
        Me.btnimgfull8 = New System.Windows.Forms.Button
        Me.imgpanel8 = New System.Windows.Forms.Panel
        Me.imgbox8 = New System.Windows.Forms.PictureBox
        Me.btnimgremove8 = New System.Windows.Forms.Button
        Me.btnimgadd8 = New System.Windows.Forms.Button
        Me.btnimgcancel8 = New System.Windows.Forms.Button
        Me.btnimgrefresh8 = New System.Windows.Forms.Button
        Me.btnimgrename8 = New System.Windows.Forms.Button
        Me.tab9 = New System.Windows.Forms.TabPage
        Me.panelstp9 = New System.Windows.Forms.Panel
        Me.gstep9 = New System.Windows.Forms.GroupBox
        Me.lbls9 = New System.Windows.Forms.Label
        Me.btntrip9 = New System.Windows.Forms.Button
        Me.txts9 = New System.Windows.Forms.TextBox
        Me.lblload9 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.cmbwhse9 = New System.Windows.Forms.ComboBox
        Me.cmbtrans9 = New System.Windows.Forms.ComboBox
        Me.btnrefstep9 = New System.Windows.Forms.Button
        Me.grdstep9 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn56 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn57 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn58 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn59 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn77 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column26 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn95 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.grp9 = New System.Windows.Forms.GroupBox
        Me.link2to9 = New System.Windows.Forms.LinkLabel
        Me.lblpick9 = New System.Windows.Forms.Label
        Me.lblimgname9 = New System.Windows.Forms.Label
        Me.lblimgdate9 = New System.Windows.Forms.Label
        Me.txtpo9 = New System.Windows.Forms.TextBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.tripinfo9 = New System.Windows.Forms.LinkLabel
        Me.pgbar9 = New System.Windows.Forms.ProgressBar
        Me.lblconfirm9 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.grdtrans9 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn60 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewLinkColumn1 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.DataGridViewTextBoxColumn61 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn62 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column25 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Column30 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.DataGridViewTextBoxColumn63 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn64 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn65 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn66 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn67 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column35 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column36 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn68 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn69 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn78 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column37 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column32 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Column39 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column38 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.btnstartrecord = New System.Windows.Forms.Button
        Me.lbltype9 = New System.Windows.Forms.Label
        Me.cmbimg9 = New System.Windows.Forms.ComboBox
        Me.txtrems9 = New System.Windows.Forms.TextBox
        Me.Panel35 = New System.Windows.Forms.Panel
        Me.btnexempt9 = New System.Windows.Forms.Button
        Me.btnconfirm9 = New System.Windows.Forms.Button
        Me.lbltripnum9 = New System.Windows.Forms.Label
        Me.lblplate9 = New System.Windows.Forms.Label
        Me.btnimgdl9 = New System.Windows.Forms.Button
        Me.lblimgid9 = New System.Windows.Forms.Label
        Me.btnimgfull9 = New System.Windows.Forms.Button
        Me.imgpanel9 = New System.Windows.Forms.Panel
        Me.imgbox9 = New System.Windows.Forms.PictureBox
        Me.btnimgremove9 = New System.Windows.Forms.Button
        Me.btnimgadd9 = New System.Windows.Forms.Button
        Me.btnimgcancel9 = New System.Windows.Forms.Button
        Me.btnimgrefresh9 = New System.Windows.Forms.Button
        Me.btnimgrename9 = New System.Windows.Forms.Button
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.EditSOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditPOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditITRToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditSWSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewEditReferenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToBeRecordedByToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LCAccountingStaffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AGIAccountingStaffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.C3ManilaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CalambaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PagbilaoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MilaorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CebuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DavaoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BacolodToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TaclobanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Panel27 = New System.Windows.Forms.Panel
        Me.TabControl1.SuspendLayout()
        Me.tab1.SuspendLayout()
        Me.panelstp1.SuspendLayout()
        Me.gstep1.SuspendLayout()
        CType(Me.grdstep1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp1.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.imgbox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab2.SuspendLayout()
        Me.panelstp2.SuspendLayout()
        Me.gstep2.SuspendLayout()
        CType(Me.grdstep2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp2.SuspendLayout()
        Me.Panelinch2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.dieselpanel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.imgbox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab3.SuspendLayout()
        Me.panelstp3.SuspendLayout()
        Me.gstep3.SuspendLayout()
        CType(Me.grdstep3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp3.SuspendLayout()
        CType(Me.grdtrans3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel8.SuspendLayout()
        CType(Me.imgbox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab4.SuspendLayout()
        Me.panelstp4.SuspendLayout()
        Me.gstep4.SuspendLayout()
        CType(Me.grdstep4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp4.SuspendLayout()
        CType(Me.grdtrans4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel11.SuspendLayout()
        CType(Me.imgbox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab5.SuspendLayout()
        Me.panelstp5.SuspendLayout()
        Me.gstep5.SuspendLayout()
        CType(Me.grdstep5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp5.SuspendLayout()
        CType(Me.grdtrans5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel14.SuspendLayout()
        CType(Me.imgbox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab6.SuspendLayout()
        Me.panelstp6.SuspendLayout()
        Me.gstep6.SuspendLayout()
        CType(Me.grdstep6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp6.SuspendLayout()
        Me.Panel17.SuspendLayout()
        CType(Me.imgbox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab7.SuspendLayout()
        Me.panelstp7.SuspendLayout()
        Me.gstep7.SuspendLayout()
        CType(Me.grdstep7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp7.SuspendLayout()
        CType(Me.grdtrans7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel19.SuspendLayout()
        CType(Me.imgbox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab8.SuspendLayout()
        Me.panelstp8.SuspendLayout()
        Me.gstep8.SuspendLayout()
        CType(Me.grdstep8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp8.SuspendLayout()
        Me.Panelinch8.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        Me.Panel26.SuspendLayout()
        Me.Panel24.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.Panel29.SuspendLayout()
        CType(Me.imgbox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab9.SuspendLayout()
        Me.panelstp9.SuspendLayout()
        Me.gstep9.SuspendLayout()
        CType(Me.grdstep9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp9.SuspendLayout()
        CType(Me.grdtrans9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel35.SuspendLayout()
        CType(Me.imgbox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.ContextMenuStrip2.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.tab1)
        Me.TabControl1.Controls.Add(Me.tab2)
        Me.TabControl1.Controls.Add(Me.tab3)
        Me.TabControl1.Controls.Add(Me.tab4)
        Me.TabControl1.Controls.Add(Me.tab5)
        Me.TabControl1.Controls.Add(Me.tab6)
        Me.TabControl1.Controls.Add(Me.tab7)
        Me.TabControl1.Controls.Add(Me.tab8)
        Me.TabControl1.Controls.Add(Me.tab9)
        Me.TabControl1.ItemSize = New System.Drawing.Size(206, 30)
        Me.TabControl1.Location = New System.Drawing.Point(3, 3)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.ShowToolTips = True
        Me.TabControl1.Size = New System.Drawing.Size(1258, 670)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight
        Me.TabControl1.TabIndex = 1
        '
        'tab1
        '
        Me.tab1.Controls.Add(Me.panelstp1)
        Me.tab1.Location = New System.Drawing.Point(4, 64)
        Me.tab1.Name = "tab1"
        Me.tab1.Size = New System.Drawing.Size(1250, 602)
        Me.tab1.TabIndex = 2
        Me.tab1.Text = "     STEP 1 ( FOR PRE-INSPECTION )     "
        Me.tab1.UseVisualStyleBackColor = True
        '
        'panelstp1
        '
        Me.panelstp1.AutoScroll = True
        Me.panelstp1.Controls.Add(Me.gstep1)
        Me.panelstp1.Controls.Add(Me.grp1)
        Me.panelstp1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelstp1.Location = New System.Drawing.Point(0, 0)
        Me.panelstp1.Name = "panelstp1"
        Me.panelstp1.Size = New System.Drawing.Size(1250, 602)
        Me.panelstp1.TabIndex = 3
        '
        'gstep1
        '
        Me.gstep1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gstep1.Controls.Add(Me.lblload1)
        Me.gstep1.Controls.Add(Me.btnrefstep1)
        Me.gstep1.Controls.Add(Me.grdstep1)
        Me.gstep1.Location = New System.Drawing.Point(6, 10)
        Me.gstep1.Name = "gstep1"
        Me.gstep1.Size = New System.Drawing.Size(379, 582)
        Me.gstep1.TabIndex = 0
        Me.gstep1.TabStop = False
        Me.gstep1.Text = "STEP 1 Trip"
        '
        'lblload1
        '
        Me.lblload1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload1.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload1.Location = New System.Drawing.Point(7, 52)
        Me.lblload1.Name = "lblload1"
        Me.lblload1.Size = New System.Drawing.Size(365, 489)
        Me.lblload1.TabIndex = 98
        Me.lblload1.Text = "Loading..."
        Me.lblload1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnrefstep1
        '
        Me.btnrefstep1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefstep1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefstep1.Image = CType(resources.GetObject("btnrefstep1.Image"), System.Drawing.Image)
        Me.btnrefstep1.Location = New System.Drawing.Point(272, 546)
        Me.btnrefstep1.Name = "btnrefstep1"
        Me.btnrefstep1.Size = New System.Drawing.Size(101, 30)
        Me.btnrefstep1.TabIndex = 70
        Me.btnrefstep1.Text = "Refresh List"
        Me.btnrefstep1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefstep1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefstep1.UseVisualStyleBackColor = True
        '
        'grdstep1
        '
        Me.grdstep1.AllowUserToAddRows = False
        Me.grdstep1.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdstep1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdstep1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdstep1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdstep1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.grdstep1.ColumnHeadersHeight = 30
        Me.grdstep1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdstep1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.Column20, Me.Column28})
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep1.DefaultCellStyle = DataGridViewCellStyle4
        Me.grdstep1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdstep1.EnableHeadersVisualStyles = False
        Me.grdstep1.GridColor = System.Drawing.Color.Salmon
        Me.grdstep1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdstep1.Location = New System.Drawing.Point(6, 20)
        Me.grdstep1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdstep1.MultiSelect = False
        Me.grdstep1.Name = "grdstep1"
        Me.grdstep1.ReadOnly = True
        Me.grdstep1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep1.RowHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.grdstep1.RowHeadersWidth = 10
        Me.grdstep1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.NullValue = Nothing
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep1.RowsDefaultCellStyle = DataGridViewCellStyle6
        Me.grdstep1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdstep1.Size = New System.Drawing.Size(367, 521)
        Me.grdstep1.TabIndex = 10
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.Frozen = True
        Me.DataGridViewTextBoxColumn1.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Visible = False
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.Frozen = True
        Me.DataGridViewTextBoxColumn2.HeaderText = "Trip #"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn2.Width = 120
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.Frozen = True
        Me.DataGridViewTextBoxColumn3.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn3.Width = 130
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "Driver"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn4.Width = 150
        '
        'Column20
        '
        Me.Column20.HeaderText = "Helper"
        Me.Column20.MinimumWidth = 100
        Me.Column20.Name = "Column20"
        Me.Column20.ReadOnly = True
        Me.Column20.Width = 180
        '
        'Column28
        '
        DataGridViewCellStyle3.Format = "yyyy/MM/dd"
        Me.Column28.DefaultCellStyle = DataGridViewCellStyle3
        Me.Column28.HeaderText = "Date"
        Me.Column28.Name = "Column28"
        Me.Column28.ReadOnly = True
        Me.Column28.Visible = False
        '
        'grp1
        '
        Me.grp1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grp1.Controls.Add(Me.lblimgname1)
        Me.grp1.Controls.Add(Me.lblimgdate1)
        Me.grp1.Controls.Add(Me.tripinfo1)
        Me.grp1.Controls.Add(Me.Button1)
        Me.grp1.Controls.Add(Me.Button3)
        Me.grp1.Controls.Add(Me.lblDesiredSize)
        Me.grp1.Controls.Add(Me.lblOriginalSize)
        Me.grp1.Controls.Add(Me.lblCompressedSize)
        Me.grp1.Controls.Add(Me.lblCompressionLevel)
        Me.grp1.Controls.Add(Me.pgbar1)
        Me.grp1.Controls.Add(Me.lblconfirm1)
        Me.grp1.Controls.Add(Me.btnstartpre)
        Me.grp1.Controls.Add(Me.lbltype1)
        Me.grp1.Controls.Add(Me.TableLayoutPanel4)
        Me.grp1.Controls.Add(Me.cmbimg1)
        Me.grp1.Controls.Add(Me.txtrems1)
        Me.grp1.Controls.Add(Me.Panel3)
        Me.grp1.Controls.Add(Me.lbltripnum1)
        Me.grp1.Controls.Add(Me.lblplate1)
        Me.grp1.Controls.Add(Me.btnimgdl1)
        Me.grp1.Controls.Add(Me.lblimgid1)
        Me.grp1.Controls.Add(Me.btnimgfull1)
        Me.grp1.Controls.Add(Me.imgpanel1)
        Me.grp1.Controls.Add(Me.imgbox1)
        Me.grp1.Controls.Add(Me.btnimgremove1)
        Me.grp1.Controls.Add(Me.btnimgadd1)
        Me.grp1.Controls.Add(Me.btnimgcancel1)
        Me.grp1.Controls.Add(Me.btnimgrefresh1)
        Me.grp1.Controls.Add(Me.btnimgrename1)
        Me.grp1.Location = New System.Drawing.Point(388, 10)
        Me.grp1.Name = "grp1"
        Me.grp1.Size = New System.Drawing.Size(859, 582)
        Me.grp1.TabIndex = 1
        Me.grp1.TabStop = False
        Me.grp1.Text = "Photos"
        '
        'lblimgname1
        '
        Me.lblimgname1.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgname1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgname1.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgname1.Location = New System.Drawing.Point(724, 271)
        Me.lblimgname1.Name = "lblimgname1"
        Me.lblimgname1.Size = New System.Drawing.Size(129, 20)
        Me.lblimgname1.TabIndex = 103
        Me.lblimgname1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgdate1
        '
        Me.lblimgdate1.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgdate1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgdate1.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgdate1.Location = New System.Drawing.Point(580, 271)
        Me.lblimgdate1.Name = "lblimgdate1"
        Me.lblimgdate1.Size = New System.Drawing.Size(138, 20)
        Me.lblimgdate1.TabIndex = 102
        Me.lblimgdate1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tripinfo1
        '
        Me.tripinfo1.AutoSize = True
        Me.tripinfo1.Location = New System.Drawing.Point(745, 444)
        Me.tripinfo1.Name = "tripinfo1"
        Me.tripinfo1.Size = New System.Drawing.Size(80, 15)
        Me.tripinfo1.TabIndex = 100
        Me.tripinfo1.TabStop = True
        Me.tripinfo1.Text = "View Trip Info"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(817, 484)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(19, 23)
        Me.Button1.TabIndex = 99
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(785, 487)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(26, 21)
        Me.Button3.TabIndex = 97
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        Me.Button3.Visible = False
        '
        'lblDesiredSize
        '
        Me.lblDesiredSize.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblDesiredSize.Location = New System.Drawing.Point(581, 463)
        Me.lblDesiredSize.Name = "lblDesiredSize"
        Me.lblDesiredSize.Size = New System.Drawing.Size(34, 21)
        Me.lblDesiredSize.TabIndex = 96
        Me.lblDesiredSize.Visible = False
        '
        'lblOriginalSize
        '
        Me.lblOriginalSize.AutoSize = True
        Me.lblOriginalSize.Location = New System.Drawing.Point(614, 466)
        Me.lblOriginalSize.Name = "lblOriginalSize"
        Me.lblOriginalSize.Size = New System.Drawing.Size(73, 15)
        Me.lblOriginalSize.TabIndex = 95
        Me.lblOriginalSize.Text = "original size"
        Me.lblOriginalSize.Visible = False
        '
        'lblCompressedSize
        '
        Me.lblCompressedSize.AutoSize = True
        Me.lblCompressedSize.Location = New System.Drawing.Point(693, 466)
        Me.lblCompressedSize.Name = "lblCompressedSize"
        Me.lblCompressedSize.Size = New System.Drawing.Size(63, 15)
        Me.lblCompressedSize.TabIndex = 94
        Me.lblCompressedSize.Text = "comp size"
        Me.lblCompressedSize.Visible = False
        '
        'lblCompressionLevel
        '
        Me.lblCompressionLevel.AutoSize = True
        Me.lblCompressionLevel.Location = New System.Drawing.Point(762, 466)
        Me.lblCompressionLevel.Name = "lblCompressionLevel"
        Me.lblCompressionLevel.Size = New System.Drawing.Size(66, 15)
        Me.lblCompressionLevel.TabIndex = 93
        Me.lblCompressionLevel.Text = "comp level"
        Me.lblCompressionLevel.Visible = False
        '
        'pgbar1
        '
        Me.pgbar1.Location = New System.Drawing.Point(580, 216)
        Me.pgbar1.Name = "pgbar1"
        Me.pgbar1.Size = New System.Drawing.Size(273, 23)
        Me.pgbar1.TabIndex = 85
        Me.pgbar1.Visible = False
        '
        'lblconfirm1
        '
        Me.lblconfirm1.BackColor = System.Drawing.Color.Transparent
        Me.lblconfirm1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblconfirm1.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblconfirm1.Location = New System.Drawing.Point(6, 77)
        Me.lblconfirm1.Name = "lblconfirm1"
        Me.lblconfirm1.Size = New System.Drawing.Size(132, 38)
        Me.lblconfirm1.TabIndex = 82
        Me.lblconfirm1.Text = "0"
        Me.lblconfirm1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblconfirm1.Visible = False
        '
        'btnstartpre
        '
        Me.btnstartpre.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnstartpre.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstartpre.Image = CType(resources.GetObject("btnstartpre.Image"), System.Drawing.Image)
        Me.btnstartpre.Location = New System.Drawing.Point(6, 65)
        Me.btnstartpre.Name = "btnstartpre"
        Me.btnstartpre.Size = New System.Drawing.Size(569, 62)
        Me.btnstartpre.TabIndex = 80
        Me.btnstartpre.Text = "TIME START PRE-INSPECTION"
        Me.btnstartpre.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnstartpre.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnstartpre.UseVisualStyleBackColor = False
        '
        'lbltype1
        '
        Me.lbltype1.BackColor = System.Drawing.Color.Transparent
        Me.lbltype1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype1.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltype1.Location = New System.Drawing.Point(360, 22)
        Me.lbltype1.Name = "lbltype1"
        Me.lbltype1.Size = New System.Drawing.Size(215, 38)
        Me.lbltype1.TabIndex = 81
        Me.lbltype1.Text = "TYPE"
        Me.lbltype1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.47917!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.52083!))
        Me.TableLayoutPanel4.Controls.Add(Me.Panel18, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Panel20, 0, 0)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(6, 432)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 1
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(569, 65)
        Me.TableLayoutPanel4.TabIndex = 79
        '
        'Panel18
        '
        Me.Panel18.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel18.BackColor = System.Drawing.Color.PowderBlue
        Me.Panel18.Controls.Add(Me.txtodo)
        Me.Panel18.Controls.Add(Me.Label15)
        Me.Panel18.Location = New System.Drawing.Point(284, 3)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(282, 59)
        Me.Panel18.TabIndex = 3
        '
        'txtodo
        '
        Me.txtodo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtodo.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtodo.Location = New System.Drawing.Point(3, 30)
        Me.txtodo.Name = "txtodo"
        Me.txtodo.Size = New System.Drawing.Size(274, 22)
        Me.txtodo.TabIndex = 76
        Me.txtodo.Text = "0"
        Me.txtodo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(5, 6)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(172, 16)
        Me.Label15.TabIndex = 71
        Me.Label15.Text = "Actual Odometer Reading"
        '
        'Panel20
        '
        Me.Panel20.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel20.BackColor = System.Drawing.Color.PowderBlue
        Me.Panel20.Controls.Add(Me.btnodo)
        Me.Panel20.Controls.Add(Me.txtodoend1)
        Me.Panel20.Controls.Add(Me.Label17)
        Me.Panel20.Location = New System.Drawing.Point(3, 3)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(275, 59)
        Me.Panel20.TabIndex = 2
        '
        'btnodo
        '
        Me.btnodo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnodo.BackColor = System.Drawing.Color.Transparent
        Me.btnodo.FlatAppearance.BorderSize = 0
        Me.btnodo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnodo.Image = CType(resources.GetObject("btnodo.Image"), System.Drawing.Image)
        Me.btnodo.Location = New System.Drawing.Point(245, 29)
        Me.btnodo.Name = "btnodo"
        Me.btnodo.Size = New System.Drawing.Size(27, 23)
        Me.btnodo.TabIndex = 107
        Me.btnodo.Tag = "1"
        Me.btnodo.UseVisualStyleBackColor = False
        Me.btnodo.Visible = False
        '
        'txtodoend1
        '
        Me.txtodoend1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtodoend1.BackColor = System.Drawing.Color.White
        Me.txtodoend1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtodoend1.Location = New System.Drawing.Point(4, 30)
        Me.txtodoend1.Name = "txtodoend1"
        Me.txtodoend1.ReadOnly = True
        Me.txtodoend1.Size = New System.Drawing.Size(266, 22)
        Me.txtodoend1.TabIndex = 76
        Me.txtodoend1.Text = "0"
        Me.txtodoend1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label17
        '
        Me.Label17.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(3, 6)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(178, 16)
        Me.Label17.TabIndex = 71
        Me.Label17.Text = "Previous Ending Odometer"
        '
        'cmbimg1
        '
        Me.cmbimg1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbimg1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbimg1.FormattingEnabled = True
        Me.cmbimg1.Items.AddRange(New Object() {"", "Truck Documents", "Truck Repair and Maintenance Check", "Roadworthiness Check", "Odometer Reading", "Truck CheckList Form"})
        Me.cmbimg1.Location = New System.Drawing.Point(580, 245)
        Me.cmbimg1.Name = "cmbimg1"
        Me.cmbimg1.Size = New System.Drawing.Size(273, 23)
        Me.cmbimg1.TabIndex = 73
        '
        'txtrems1
        '
        Me.txtrems1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtrems1.Location = New System.Drawing.Point(6, 503)
        Me.txtrems1.Multiline = True
        Me.txtrems1.Name = "txtrems1"
        Me.txtrems1.Size = New System.Drawing.Size(569, 71)
        Me.txtrems1.TabIndex = 72
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel3.Controls.Add(Me.btnexempt1)
        Me.Panel3.Controls.Add(Me.btnconfirm1)
        Me.Panel3.Controls.Add(Me.Label32)
        Me.Panel3.Location = New System.Drawing.Point(580, 503)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(273, 71)
        Me.Panel3.TabIndex = 71
        '
        'btnexempt1
        '
        Me.btnexempt1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnexempt1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexempt1.Image = CType(resources.GetObject("btnexempt1.Image"), System.Drawing.Image)
        Me.btnexempt1.Location = New System.Drawing.Point(139, 3)
        Me.btnexempt1.Name = "btnexempt1"
        Me.btnexempt1.Size = New System.Drawing.Size(130, 62)
        Me.btnexempt1.TabIndex = 73
        Me.btnexempt1.Text = "SAVE AS DRAFT"
        Me.btnexempt1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnexempt1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnexempt1.UseVisualStyleBackColor = True
        '
        'btnconfirm1
        '
        Me.btnconfirm1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnconfirm1.Enabled = False
        Me.btnconfirm1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirm1.Image = CType(resources.GetObject("btnconfirm1.Image"), System.Drawing.Image)
        Me.btnconfirm1.Location = New System.Drawing.Point(3, 3)
        Me.btnconfirm1.Name = "btnconfirm1"
        Me.btnconfirm1.Size = New System.Drawing.Size(130, 62)
        Me.btnconfirm1.TabIndex = 72
        Me.btnconfirm1.Text = "CONFIRM"
        Me.btnconfirm1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnconfirm1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnconfirm1.UseVisualStyleBackColor = True
        '
        'Label32
        '
        Me.Label32.Location = New System.Drawing.Point(173, -16)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(71, 27)
        Me.Label32.TabIndex = 101
        Me.Label32.Visible = False
        '
        'lbltripnum1
        '
        Me.lbltripnum1.BackColor = System.Drawing.Color.Transparent
        Me.lbltripnum1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltripnum1.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltripnum1.Location = New System.Drawing.Point(6, 22)
        Me.lbltripnum1.Name = "lbltripnum1"
        Me.lbltripnum1.Size = New System.Drawing.Size(132, 38)
        Me.lbltripnum1.TabIndex = 70
        Me.lbltripnum1.Text = "Trip#"
        Me.lbltripnum1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbltripnum1.Visible = False
        '
        'lblplate1
        '
        Me.lblplate1.BackColor = System.Drawing.Color.Transparent
        Me.lblplate1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate1.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate1.Location = New System.Drawing.Point(6, 22)
        Me.lblplate1.Name = "lblplate1"
        Me.lblplate1.Size = New System.Drawing.Size(360, 38)
        Me.lblplate1.TabIndex = 69
        Me.lblplate1.Text = "Plate #"
        Me.lblplate1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnimgdl1
        '
        Me.btnimgdl1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl1.Image = CType(resources.GetObject("btnimgdl1.Image"), System.Drawing.Image)
        Me.btnimgdl1.Location = New System.Drawing.Point(581, 22)
        Me.btnimgdl1.Name = "btnimgdl1"
        Me.btnimgdl1.Size = New System.Drawing.Size(34, 39)
        Me.btnimgdl1.TabIndex = 64
        Me.btnimgdl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl1.UseVisualStyleBackColor = True
        Me.btnimgdl1.Visible = False
        '
        'lblimgid1
        '
        Me.lblimgid1.AutoSize = True
        Me.lblimgid1.Location = New System.Drawing.Point(577, 423)
        Me.lblimgid1.Name = "lblimgid1"
        Me.lblimgid1.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid1.TabIndex = 68
        Me.lblimgid1.Text = "imgid"
        Me.lblimgid1.Visible = False
        '
        'btnimgfull1
        '
        Me.btnimgfull1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull1.Image = CType(resources.GetObject("btnimgfull1.Image"), System.Drawing.Image)
        Me.btnimgfull1.Location = New System.Drawing.Point(617, 375)
        Me.btnimgfull1.Name = "btnimgfull1"
        Me.btnimgfull1.Size = New System.Drawing.Size(208, 30)
        Me.btnimgfull1.TabIndex = 65
        Me.btnimgfull1.Text = "View Larger"
        Me.btnimgfull1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull1.UseVisualStyleBackColor = True
        '
        'imgpanel1
        '
        Me.imgpanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.imgpanel1.AutoScroll = True
        Me.imgpanel1.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel1.Location = New System.Drawing.Point(6, 133)
        Me.imgpanel1.Name = "imgpanel1"
        Me.imgpanel1.Size = New System.Drawing.Size(569, 296)
        Me.imgpanel1.TabIndex = 63
        '
        'imgbox1
        '
        Me.imgbox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox1.Location = New System.Drawing.Point(580, 20)
        Me.imgbox1.Name = "imgbox1"
        Me.imgbox1.Size = New System.Drawing.Size(273, 219)
        Me.imgbox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox1.TabIndex = 62
        Me.imgbox1.TabStop = False
        '
        'btnimgremove1
        '
        Me.btnimgremove1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove1.Image = CType(resources.GetObject("btnimgremove1.Image"), System.Drawing.Image)
        Me.btnimgremove1.Location = New System.Drawing.Point(617, 339)
        Me.btnimgremove1.Name = "btnimgremove1"
        Me.btnimgremove1.Size = New System.Drawing.Size(101, 30)
        Me.btnimgremove1.TabIndex = 60
        Me.btnimgremove1.Text = "Remove"
        Me.btnimgremove1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove1.UseVisualStyleBackColor = True
        '
        'btnimgadd1
        '
        Me.btnimgadd1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd1.Image = CType(resources.GetObject("btnimgadd1.Image"), System.Drawing.Image)
        Me.btnimgadd1.Location = New System.Drawing.Point(617, 303)
        Me.btnimgadd1.Name = "btnimgadd1"
        Me.btnimgadd1.Size = New System.Drawing.Size(101, 30)
        Me.btnimgadd1.TabIndex = 58
        Me.btnimgadd1.Text = "Add Photo"
        Me.btnimgadd1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd1.UseVisualStyleBackColor = True
        '
        'btnimgcancel1
        '
        Me.btnimgcancel1.Enabled = False
        Me.btnimgcancel1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel1.Image = CType(resources.GetObject("btnimgcancel1.Image"), System.Drawing.Image)
        Me.btnimgcancel1.Location = New System.Drawing.Point(724, 339)
        Me.btnimgcancel1.Name = "btnimgcancel1"
        Me.btnimgcancel1.Size = New System.Drawing.Size(101, 30)
        Me.btnimgcancel1.TabIndex = 61
        Me.btnimgcancel1.Text = "Cancel"
        Me.btnimgcancel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel1.UseVisualStyleBackColor = True
        '
        'btnimgrefresh1
        '
        Me.btnimgrefresh1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh1.Image = CType(resources.GetObject("btnimgrefresh1.Image"), System.Drawing.Image)
        Me.btnimgrefresh1.Location = New System.Drawing.Point(617, 411)
        Me.btnimgrefresh1.Name = "btnimgrefresh1"
        Me.btnimgrefresh1.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh1.TabIndex = 66
        Me.btnimgrefresh1.Text = "Refresh Photos"
        Me.btnimgrefresh1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh1.UseVisualStyleBackColor = True
        '
        'btnimgrename1
        '
        Me.btnimgrename1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename1.Image = CType(resources.GetObject("btnimgrename1.Image"), System.Drawing.Image)
        Me.btnimgrename1.Location = New System.Drawing.Point(724, 303)
        Me.btnimgrename1.Name = "btnimgrename1"
        Me.btnimgrename1.Size = New System.Drawing.Size(101, 30)
        Me.btnimgrename1.TabIndex = 59
        Me.btnimgrename1.Text = "Rename"
        Me.btnimgrename1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename1.UseVisualStyleBackColor = True
        '
        'tab2
        '
        Me.tab2.Controls.Add(Me.panelstp2)
        Me.tab2.Location = New System.Drawing.Point(4, 64)
        Me.tab2.Name = "tab2"
        Me.tab2.Size = New System.Drawing.Size(1250, 602)
        Me.tab2.TabIndex = 5
        Me.tab2.Text = "     STEP 2 ( FOR DIESEL )     "
        Me.tab2.UseVisualStyleBackColor = True
        '
        'panelstp2
        '
        Me.panelstp2.AutoScroll = True
        Me.panelstp2.Controls.Add(Me.gstep2)
        Me.panelstp2.Controls.Add(Me.grp2)
        Me.panelstp2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelstp2.Location = New System.Drawing.Point(0, 0)
        Me.panelstp2.Name = "panelstp2"
        Me.panelstp2.Size = New System.Drawing.Size(1250, 602)
        Me.panelstp2.TabIndex = 3
        '
        'gstep2
        '
        Me.gstep2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gstep2.Controls.Add(Me.lblload2)
        Me.gstep2.Controls.Add(Me.cmbtrans2)
        Me.gstep2.Controls.Add(Me.btnrefstep2)
        Me.gstep2.Controls.Add(Me.grdstep2)
        Me.gstep2.Location = New System.Drawing.Point(6, 10)
        Me.gstep2.Name = "gstep2"
        Me.gstep2.Size = New System.Drawing.Size(379, 582)
        Me.gstep2.TabIndex = 0
        Me.gstep2.TabStop = False
        Me.gstep2.Text = "STEP 2 Trip"
        '
        'lblload2
        '
        Me.lblload2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload2.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload2.Location = New System.Drawing.Point(7, 52)
        Me.lblload2.Name = "lblload2"
        Me.lblload2.Size = New System.Drawing.Size(365, 489)
        Me.lblload2.TabIndex = 99
        Me.lblload2.Text = "Loading..."
        Me.lblload2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbtrans2
        '
        Me.cmbtrans2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbtrans2.FormattingEnabled = True
        Me.cmbtrans2.Location = New System.Drawing.Point(145, 547)
        Me.cmbtrans2.Name = "cmbtrans2"
        Me.cmbtrans2.Size = New System.Drawing.Size(121, 23)
        Me.cmbtrans2.TabIndex = 71
        Me.cmbtrans2.Visible = False
        '
        'btnrefstep2
        '
        Me.btnrefstep2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefstep2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefstep2.Image = CType(resources.GetObject("btnrefstep2.Image"), System.Drawing.Image)
        Me.btnrefstep2.Location = New System.Drawing.Point(272, 546)
        Me.btnrefstep2.Name = "btnrefstep2"
        Me.btnrefstep2.Size = New System.Drawing.Size(101, 30)
        Me.btnrefstep2.TabIndex = 70
        Me.btnrefstep2.Text = "Refresh List"
        Me.btnrefstep2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefstep2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefstep2.UseVisualStyleBackColor = True
        '
        'grdstep2
        '
        Me.grdstep2.AllowUserToAddRows = False
        Me.grdstep2.AllowUserToDeleteRows = False
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdstep2.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle7
        Me.grdstep2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdstep2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdstep2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle8.NullValue = Nothing
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.grdstep2.ColumnHeadersHeight = 30
        Me.grdstep2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdstep2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn70, Me.Column29})
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep2.DefaultCellStyle = DataGridViewCellStyle10
        Me.grdstep2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdstep2.EnableHeadersVisualStyles = False
        Me.grdstep2.GridColor = System.Drawing.Color.Salmon
        Me.grdstep2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdstep2.Location = New System.Drawing.Point(6, 20)
        Me.grdstep2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdstep2.MultiSelect = False
        Me.grdstep2.Name = "grdstep2"
        Me.grdstep2.ReadOnly = True
        Me.grdstep2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep2.RowHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.grdstep2.RowHeadersWidth = 10
        Me.grdstep2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle12.NullValue = Nothing
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep2.RowsDefaultCellStyle = DataGridViewCellStyle12
        Me.grdstep2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdstep2.Size = New System.Drawing.Size(367, 521)
        Me.grdstep2.TabIndex = 10
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.Frozen = True
        Me.DataGridViewTextBoxColumn5.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Visible = False
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.Frozen = True
        Me.DataGridViewTextBoxColumn6.HeaderText = "Trip #"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn6.Width = 120
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.Frozen = True
        Me.DataGridViewTextBoxColumn7.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn7.Width = 130
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.HeaderText = "Driver"
        Me.DataGridViewTextBoxColumn8.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn8.Width = 150
        '
        'DataGridViewTextBoxColumn70
        '
        Me.DataGridViewTextBoxColumn70.HeaderText = "Helper"
        Me.DataGridViewTextBoxColumn70.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn70.Name = "DataGridViewTextBoxColumn70"
        Me.DataGridViewTextBoxColumn70.ReadOnly = True
        Me.DataGridViewTextBoxColumn70.Width = 180
        '
        'Column29
        '
        DataGridViewCellStyle9.Format = "yyyy/MM/dd"
        Me.Column29.DefaultCellStyle = DataGridViewCellStyle9
        Me.Column29.HeaderText = "Date"
        Me.Column29.Name = "Column29"
        Me.Column29.ReadOnly = True
        Me.Column29.Visible = False
        '
        'grp2
        '
        Me.grp2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grp2.Controls.Add(Me.Panelinch2)
        Me.grp2.Controls.Add(Me.lblimgname2)
        Me.grp2.Controls.Add(Me.lblimgdate2)
        Me.grp2.Controls.Add(Me.tripinfo2)
        Me.grp2.Controls.Add(Me.pgbar2)
        Me.grp2.Controls.Add(Me.lblconfirm2)
        Me.grp2.Controls.Add(Me.lblmake2)
        Me.grp2.Controls.Add(Me.lbltype2)
        Me.grp2.Controls.Add(Me.btnstartdiesel)
        Me.grp2.Controls.Add(Me.Panel1)
        Me.grp2.Controls.Add(Me.lblfull)
        Me.grp2.Controls.Add(Me.txtdestin)
        Me.grp2.Controls.Add(Me.lblinch)
        Me.grp2.Controls.Add(Me.lblpwout)
        Me.grp2.Controls.Add(Me.lblpwith)
        Me.grp2.Controls.Add(Me.Panel7)
        Me.grp2.Controls.Add(Me.Panel2)
        Me.grp2.Controls.Add(Me.cmbimg2)
        Me.grp2.Controls.Add(Me.txtrems2)
        Me.grp2.Controls.Add(Me.Panel5)
        Me.grp2.Controls.Add(Me.lbltripnum2)
        Me.grp2.Controls.Add(Me.lblplate2)
        Me.grp2.Controls.Add(Me.btnimgdl2)
        Me.grp2.Controls.Add(Me.lblimgid2)
        Me.grp2.Controls.Add(Me.btnimgfull2)
        Me.grp2.Controls.Add(Me.imgpanel2)
        Me.grp2.Controls.Add(Me.imgbox2)
        Me.grp2.Controls.Add(Me.btnimgremove2)
        Me.grp2.Controls.Add(Me.btnimgadd2)
        Me.grp2.Controls.Add(Me.btnimgcancel2)
        Me.grp2.Controls.Add(Me.btnimgrefresh2)
        Me.grp2.Controls.Add(Me.btnimgrename2)
        Me.grp2.Location = New System.Drawing.Point(388, 10)
        Me.grp2.Name = "grp2"
        Me.grp2.Size = New System.Drawing.Size(860, 582)
        Me.grp2.TabIndex = 1
        Me.grp2.TabStop = False
        Me.grp2.Text = "Photos"
        '
        'Panelinch2
        '
        Me.Panelinch2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panelinch2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panelinch2.Controls.Add(Me.btninch2cancel)
        Me.Panelinch2.Controls.Add(Me.btninch2ok)
        Me.Panelinch2.Controls.Add(Me.Label24)
        Me.Panelinch2.Controls.Add(Me.txtinch2)
        Me.Panelinch2.Location = New System.Drawing.Point(384, 502)
        Me.Panelinch2.Name = "Panelinch2"
        Me.Panelinch2.Size = New System.Drawing.Size(188, 78)
        Me.Panelinch2.TabIndex = 117
        Me.Panelinch2.Visible = False
        '
        'btninch2cancel
        '
        Me.btninch2cancel.Image = CType(resources.GetObject("btninch2cancel.Image"), System.Drawing.Image)
        Me.btninch2cancel.Location = New System.Drawing.Point(98, 48)
        Me.btninch2cancel.Name = "btninch2cancel"
        Me.btninch2cancel.Size = New System.Drawing.Size(75, 23)
        Me.btninch2cancel.TabIndex = 74
        Me.btninch2cancel.Text = "Cancel"
        Me.btninch2cancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btninch2cancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btninch2cancel.UseVisualStyleBackColor = True
        '
        'btninch2ok
        '
        Me.btninch2ok.Image = CType(resources.GetObject("btninch2ok.Image"), System.Drawing.Image)
        Me.btninch2ok.Location = New System.Drawing.Point(17, 48)
        Me.btninch2ok.Name = "btninch2ok"
        Me.btninch2ok.Size = New System.Drawing.Size(75, 23)
        Me.btninch2ok.TabIndex = 73
        Me.btninch2ok.Text = "Ok"
        Me.btninch2ok.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btninch2ok.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btninch2ok.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(17, 7)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(154, 15)
        Me.Label24.TabIndex = 72
        Me.Label24.Text = "Inches to Liters Converter"
        '
        'txtinch2
        '
        Me.txtinch2.Location = New System.Drawing.Point(11, 24)
        Me.txtinch2.Name = "txtinch2"
        Me.txtinch2.Size = New System.Drawing.Size(166, 21)
        Me.txtinch2.TabIndex = 0
        '
        'lblimgname2
        '
        Me.lblimgname2.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgname2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgname2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgname2.Location = New System.Drawing.Point(724, 271)
        Me.lblimgname2.Name = "lblimgname2"
        Me.lblimgname2.Size = New System.Drawing.Size(129, 20)
        Me.lblimgname2.TabIndex = 105
        Me.lblimgname2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgdate2
        '
        Me.lblimgdate2.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgdate2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgdate2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgdate2.Location = New System.Drawing.Point(580, 271)
        Me.lblimgdate2.Name = "lblimgdate2"
        Me.lblimgdate2.Size = New System.Drawing.Size(138, 20)
        Me.lblimgdate2.TabIndex = 104
        Me.lblimgdate2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tripinfo2
        '
        Me.tripinfo2.AutoSize = True
        Me.tripinfo2.Location = New System.Drawing.Point(745, 444)
        Me.tripinfo2.Name = "tripinfo2"
        Me.tripinfo2.Size = New System.Drawing.Size(80, 15)
        Me.tripinfo2.TabIndex = 98
        Me.tripinfo2.TabStop = True
        Me.tripinfo2.Text = "View Trip Info"
        '
        'pgbar2
        '
        Me.pgbar2.Location = New System.Drawing.Point(580, 216)
        Me.pgbar2.Name = "pgbar2"
        Me.pgbar2.Size = New System.Drawing.Size(273, 23)
        Me.pgbar2.TabIndex = 86
        Me.pgbar2.Visible = False
        '
        'lblconfirm2
        '
        Me.lblconfirm2.BackColor = System.Drawing.Color.Transparent
        Me.lblconfirm2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblconfirm2.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblconfirm2.Location = New System.Drawing.Point(6, 76)
        Me.lblconfirm2.Name = "lblconfirm2"
        Me.lblconfirm2.Size = New System.Drawing.Size(132, 38)
        Me.lblconfirm2.TabIndex = 87
        Me.lblconfirm2.Text = "0"
        Me.lblconfirm2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblconfirm2.Visible = False
        '
        'lblmake2
        '
        Me.lblmake2.BackColor = System.Drawing.Color.Transparent
        Me.lblmake2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblmake2.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmake2.Location = New System.Drawing.Point(404, 528)
        Me.lblmake2.Name = "lblmake2"
        Me.lblmake2.Size = New System.Drawing.Size(163, 38)
        Me.lblmake2.TabIndex = 86
        Me.lblmake2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblmake2.Visible = False
        '
        'lbltype2
        '
        Me.lbltype2.BackColor = System.Drawing.Color.Transparent
        Me.lbltype2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype2.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltype2.Location = New System.Drawing.Point(360, 22)
        Me.lbltype2.Name = "lbltype2"
        Me.lbltype2.Size = New System.Drawing.Size(215, 38)
        Me.lbltype2.TabIndex = 85
        Me.lbltype2.Text = "TYPE"
        Me.lbltype2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnstartdiesel
        '
        Me.btnstartdiesel.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnstartdiesel.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstartdiesel.Image = CType(resources.GetObject("btnstartdiesel.Image"), System.Drawing.Image)
        Me.btnstartdiesel.Location = New System.Drawing.Point(6, 65)
        Me.btnstartdiesel.Name = "btnstartdiesel"
        Me.btnstartdiesel.Size = New System.Drawing.Size(569, 62)
        Me.btnstartdiesel.TabIndex = 84
        Me.btnstartdiesel.Text = "TIME START DIESEL"
        Me.btnstartdiesel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnstartdiesel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnstartdiesel.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel1.Controls.Add(Me.TableLayoutPanel5)
        Me.Panel1.Location = New System.Drawing.Point(6, 428)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(569, 71)
        Me.Panel1.TabIndex = 83
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel5.ColumnCount = 2
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.47644!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.52356!))
        Me.TableLayoutPanel5.Controls.Add(Me.Panel13, 0, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Panel9, 1, 0)
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 1
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(563, 65)
        Me.TableLayoutPanel5.TabIndex = 0
        '
        'Panel13
        '
        Me.Panel13.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel13.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel13.Controls.Add(Me.txtpo)
        Me.Panel13.Controls.Add(Me.Label8)
        Me.Panel13.Location = New System.Drawing.Point(3, 3)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(272, 59)
        Me.Panel13.TabIndex = 2
        '
        'txtpo
        '
        Me.txtpo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtpo.BackColor = System.Drawing.Color.White
        Me.txtpo.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtpo.Location = New System.Drawing.Point(4, 30)
        Me.txtpo.Name = "txtpo"
        Me.txtpo.ReadOnly = True
        Me.txtpo.Size = New System.Drawing.Size(263, 22)
        Me.txtpo.TabIndex = 76
        Me.txtpo.Text = "0"
        Me.txtpo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(3, 6)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(133, 16)
        Me.Label8.TabIndex = 71
        Me.Label8.Text = "Diesel (PO) in Liters"
        '
        'Panel9
        '
        Me.Panel9.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel9.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel9.Controls.Add(Me.btnpo)
        Me.Panel9.Controls.Add(Me.txtaddpo)
        Me.Panel9.Controls.Add(Me.Label5)
        Me.Panel9.Location = New System.Drawing.Point(281, 3)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(279, 59)
        Me.Panel9.TabIndex = 1
        '
        'btnpo
        '
        Me.btnpo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnpo.BackColor = System.Drawing.Color.Transparent
        Me.btnpo.FlatAppearance.BorderSize = 0
        Me.btnpo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpo.Image = CType(resources.GetObject("btnpo.Image"), System.Drawing.Image)
        Me.btnpo.Location = New System.Drawing.Point(250, 4)
        Me.btnpo.Name = "btnpo"
        Me.btnpo.Size = New System.Drawing.Size(27, 23)
        Me.btnpo.TabIndex = 99
        Me.btnpo.UseVisualStyleBackColor = False
        '
        'txtaddpo
        '
        Me.txtaddpo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtaddpo.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtaddpo.Location = New System.Drawing.Point(4, 30)
        Me.txtaddpo.Name = "txtaddpo"
        Me.txtaddpo.Size = New System.Drawing.Size(269, 22)
        Me.txtaddpo.TabIndex = 76
        Me.txtaddpo.Text = "0"
        Me.txtaddpo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(3, 6)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(169, 16)
        Me.Label5.TabIndex = 71
        Me.Label5.Text = "Add'l Diesel (PO) in Liters"
        '
        'lblfull
        '
        Me.lblfull.AutoSize = True
        Me.lblfull.Location = New System.Drawing.Point(580, 361)
        Me.lblfull.Name = "lblfull"
        Me.lblfull.Size = New System.Drawing.Size(23, 15)
        Me.lblfull.TabIndex = 82
        Me.lblfull.Text = "full"
        Me.lblfull.Visible = False
        '
        'txtdestin
        '
        Me.txtdestin.BackColor = System.Drawing.Color.White
        Me.txtdestin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdestin.Location = New System.Drawing.Point(6, 129)
        Me.txtdestin.Name = "txtdestin"
        Me.txtdestin.ReadOnly = True
        Me.txtdestin.Size = New System.Drawing.Size(569, 21)
        Me.txtdestin.TabIndex = 81
        Me.txtdestin.Text = "Destination:"
        '
        'lblinch
        '
        Me.lblinch.AutoSize = True
        Me.lblinch.Location = New System.Drawing.Point(580, 339)
        Me.lblinch.Name = "lblinch"
        Me.lblinch.Size = New System.Drawing.Size(30, 15)
        Me.lblinch.TabIndex = 79
        Me.lblinch.Text = "inch"
        Me.lblinch.Visible = False
        '
        'lblpwout
        '
        Me.lblpwout.AutoSize = True
        Me.lblpwout.Location = New System.Drawing.Point(580, 314)
        Me.lblpwout.Name = "lblpwout"
        Me.lblpwout.Size = New System.Drawing.Size(40, 15)
        Me.lblpwout.TabIndex = 78
        Me.lblpwout.Text = "pwout"
        Me.lblpwout.Visible = False
        '
        'lblpwith
        '
        Me.lblpwith.AutoSize = True
        Me.lblpwith.Location = New System.Drawing.Point(580, 289)
        Me.lblpwith.Name = "lblpwith"
        Me.lblpwith.Size = New System.Drawing.Size(36, 15)
        Me.lblpwith.TabIndex = 77
        Me.lblpwith.Text = "pwith"
        Me.lblpwith.Visible = False
        '
        'Panel7
        '
        Me.Panel7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel7.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel7.Controls.Add(Me.TableLayoutPanel2)
        Me.Panel7.Location = New System.Drawing.Point(6, 351)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(569, 71)
        Me.Panel7.TabIndex = 75
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 178.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 194.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 238.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Panel15, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel10, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.dieselpanel3, 0, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(563, 65)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel15.Controls.Add(Me.btninch2)
        Me.Panel15.Controls.Add(Me.Label9)
        Me.Panel15.Controls.Add(Me.txtdiesel)
        Me.Panel15.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel15.Location = New System.Drawing.Point(375, 3)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(185, 59)
        Me.Panel15.TabIndex = 2
        '
        'btninch2
        '
        Me.btninch2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btninch2.BackColor = System.Drawing.Color.Transparent
        Me.btninch2.Enabled = False
        Me.btninch2.FlatAppearance.BorderSize = 0
        Me.btninch2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btninch2.Image = CType(resources.GetObject("btninch2.Image"), System.Drawing.Image)
        Me.btninch2.Location = New System.Drawing.Point(158, 2)
        Me.btninch2.Name = "btninch2"
        Me.btninch2.Size = New System.Drawing.Size(23, 23)
        Me.btninch2.TabIndex = 107
        Me.btninch2.Tag = "1"
        Me.btninch2.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(3, 6)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(150, 15)
        Me.Label9.TabIndex = 71
        Me.Label9.Text = "Actual Diesel Beg (Liters)"
        '
        'txtdiesel
        '
        Me.txtdiesel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtdiesel.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtdiesel.Location = New System.Drawing.Point(4, 30)
        Me.txtdiesel.Name = "txtdiesel"
        Me.txtdiesel.Size = New System.Drawing.Size(175, 22)
        Me.txtdiesel.TabIndex = 75
        Me.txtdiesel.Text = "0"
        Me.txtdiesel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel10.Controls.Add(Me.btndis)
        Me.Panel10.Controls.Add(Me.txtdieselbeg1)
        Me.Panel10.Controls.Add(Me.Label6)
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel10.Location = New System.Drawing.Point(181, 3)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(188, 59)
        Me.Panel10.TabIndex = 0
        '
        'btndis
        '
        Me.btndis.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btndis.BackColor = System.Drawing.Color.Transparent
        Me.btndis.FlatAppearance.BorderSize = 0
        Me.btndis.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndis.Image = CType(resources.GetObject("btndis.Image"), System.Drawing.Image)
        Me.btndis.Location = New System.Drawing.Point(158, 29)
        Me.btndis.Name = "btndis"
        Me.btndis.Size = New System.Drawing.Size(27, 23)
        Me.btndis.TabIndex = 106
        Me.btndis.Tag = "1"
        Me.btndis.UseVisualStyleBackColor = False
        Me.btndis.Visible = False
        '
        'txtdieselbeg1
        '
        Me.txtdieselbeg1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtdieselbeg1.BackColor = System.Drawing.Color.White
        Me.txtdieselbeg1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtdieselbeg1.Location = New System.Drawing.Point(4, 30)
        Me.txtdieselbeg1.Name = "txtdieselbeg1"
        Me.txtdieselbeg1.ReadOnly = True
        Me.txtdieselbeg1.Size = New System.Drawing.Size(181, 22)
        Me.txtdieselbeg1.TabIndex = 75
        Me.txtdieselbeg1.Text = "0"
        Me.txtdieselbeg1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(3, 6)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(180, 14)
        Me.Label6.TabIndex = 71
        Me.Label6.Text = "Previous Diesel Ending  (Liters)"
        '
        'dieselpanel3
        '
        Me.dieselpanel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.dieselpanel3.Controls.Add(Me.txtdshould)
        Me.dieselpanel3.Controls.Add(Me.Label2)
        Me.dieselpanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dieselpanel3.Location = New System.Drawing.Point(3, 3)
        Me.dieselpanel3.Name = "dieselpanel3"
        Me.dieselpanel3.Size = New System.Drawing.Size(172, 59)
        Me.dieselpanel3.TabIndex = 1
        '
        'txtdshould
        '
        Me.txtdshould.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtdshould.BackColor = System.Drawing.Color.White
        Me.txtdshould.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtdshould.Location = New System.Drawing.Point(4, 30)
        Me.txtdshould.Name = "txtdshould"
        Me.txtdshould.ReadOnly = True
        Me.txtdshould.Size = New System.Drawing.Size(163, 22)
        Me.txtdshould.TabIndex = 76
        Me.txtdshould.Text = "0"
        Me.txtdshould.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.Label2.Location = New System.Drawing.Point(3, 1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(164, 28)
        Me.Label2.TabIndex = 71
        Me.Label2.Text = "Diesel Should be + Maintaining Balance"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel2.Controls.Add(Me.TableLayoutPanel1)
        Me.Panel2.Location = New System.Drawing.Point(6, 274)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(569, 71)
        Me.Panel2.TabIndex = 74
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.47917!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.52083!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel16, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel12, 0, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(563, 65)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel16
        '
        Me.Panel16.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel16.BackColor = System.Drawing.Color.LightGreen
        Me.Panel16.Controls.Add(Me.txtdiswout)
        Me.Panel16.Controls.Add(Me.Label1)
        Me.Panel16.Location = New System.Drawing.Point(281, 3)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(279, 59)
        Me.Panel16.TabIndex = 3
        '
        'txtdiswout
        '
        Me.txtdiswout.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtdiswout.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtdiswout.Location = New System.Drawing.Point(4, 30)
        Me.txtdiswout.Name = "txtdiswout"
        Me.txtdiswout.Size = New System.Drawing.Size(270, 22)
        Me.txtdiswout.TabIndex = 76
        Me.txtdiswout.Text = "0"
        Me.txtdiswout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(193, 16)
        Me.Label1.TabIndex = 71
        Me.Label1.Text = "Total Distance w/o Load (Km)"
        '
        'Panel12
        '
        Me.Panel12.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel12.BackColor = System.Drawing.Color.LightGreen
        Me.Panel12.Controls.Add(Me.txtdiswith)
        Me.Panel12.Controls.Add(Me.Label7)
        Me.Panel12.Location = New System.Drawing.Point(3, 3)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(272, 59)
        Me.Panel12.TabIndex = 2
        '
        'txtdiswith
        '
        Me.txtdiswith.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtdiswith.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtdiswith.Location = New System.Drawing.Point(4, 30)
        Me.txtdiswith.Name = "txtdiswith"
        Me.txtdiswith.Size = New System.Drawing.Size(263, 22)
        Me.txtdiswith.TabIndex = 76
        Me.txtdiswith.Text = "0"
        Me.txtdiswith.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(3, 6)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(185, 16)
        Me.Label7.TabIndex = 71
        Me.Label7.Text = "Total Distance w/ Load (Km)"
        '
        'cmbimg2
        '
        Me.cmbimg2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbimg2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbimg2.FormattingEnabled = True
        Me.cmbimg2.Items.AddRange(New Object() {"", "Withdrawal slip", "Diesel PO"})
        Me.cmbimg2.Location = New System.Drawing.Point(580, 245)
        Me.cmbimg2.Name = "cmbimg2"
        Me.cmbimg2.Size = New System.Drawing.Size(273, 23)
        Me.cmbimg2.TabIndex = 73
        '
        'txtrems2
        '
        Me.txtrems2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtrems2.Location = New System.Drawing.Point(6, 505)
        Me.txtrems2.Multiline = True
        Me.txtrems2.Name = "txtrems2"
        Me.txtrems2.Size = New System.Drawing.Size(569, 71)
        Me.txtrems2.TabIndex = 72
        '
        'Panel5
        '
        Me.Panel5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel5.Controls.Add(Me.btnexempt2)
        Me.Panel5.Controls.Add(Me.btnconfirm2)
        Me.Panel5.Location = New System.Drawing.Point(580, 505)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(273, 71)
        Me.Panel5.TabIndex = 71
        '
        'btnexempt2
        '
        Me.btnexempt2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnexempt2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexempt2.Image = CType(resources.GetObject("btnexempt2.Image"), System.Drawing.Image)
        Me.btnexempt2.Location = New System.Drawing.Point(139, 3)
        Me.btnexempt2.Name = "btnexempt2"
        Me.btnexempt2.Size = New System.Drawing.Size(130, 62)
        Me.btnexempt2.TabIndex = 73
        Me.btnexempt2.Text = "SAVE AS DRAFT"
        Me.btnexempt2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnexempt2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnexempt2.UseVisualStyleBackColor = True
        '
        'btnconfirm2
        '
        Me.btnconfirm2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnconfirm2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirm2.Image = CType(resources.GetObject("btnconfirm2.Image"), System.Drawing.Image)
        Me.btnconfirm2.Location = New System.Drawing.Point(3, 3)
        Me.btnconfirm2.Name = "btnconfirm2"
        Me.btnconfirm2.Size = New System.Drawing.Size(130, 62)
        Me.btnconfirm2.TabIndex = 72
        Me.btnconfirm2.Text = "CONFIRM"
        Me.btnconfirm2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnconfirm2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnconfirm2.UseVisualStyleBackColor = True
        '
        'lbltripnum2
        '
        Me.lbltripnum2.BackColor = System.Drawing.Color.Transparent
        Me.lbltripnum2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltripnum2.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltripnum2.Location = New System.Drawing.Point(6, 22)
        Me.lbltripnum2.Name = "lbltripnum2"
        Me.lbltripnum2.Size = New System.Drawing.Size(129, 38)
        Me.lbltripnum2.TabIndex = 70
        Me.lbltripnum2.Text = "Trip#"
        Me.lbltripnum2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbltripnum2.Visible = False
        '
        'lblplate2
        '
        Me.lblplate2.BackColor = System.Drawing.Color.Transparent
        Me.lblplate2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate2.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate2.Location = New System.Drawing.Point(6, 22)
        Me.lblplate2.Name = "lblplate2"
        Me.lblplate2.Size = New System.Drawing.Size(360, 38)
        Me.lblplate2.TabIndex = 69
        Me.lblplate2.Text = "Plate #"
        Me.lblplate2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnimgdl2
        '
        Me.btnimgdl2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl2.Image = CType(resources.GetObject("btnimgdl2.Image"), System.Drawing.Image)
        Me.btnimgdl2.Location = New System.Drawing.Point(583, 439)
        Me.btnimgdl2.Name = "btnimgdl2"
        Me.btnimgdl2.Size = New System.Drawing.Size(20, 30)
        Me.btnimgdl2.TabIndex = 64
        Me.btnimgdl2.Text = "Download Photo"
        Me.btnimgdl2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl2.UseVisualStyleBackColor = True
        Me.btnimgdl2.Visible = False
        '
        'lblimgid2
        '
        Me.lblimgid2.AutoSize = True
        Me.lblimgid2.Location = New System.Drawing.Point(580, 408)
        Me.lblimgid2.Name = "lblimgid2"
        Me.lblimgid2.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid2.TabIndex = 68
        Me.lblimgid2.Text = "imgid"
        Me.lblimgid2.Visible = False
        '
        'btnimgfull2
        '
        Me.btnimgfull2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull2.Image = CType(resources.GetObject("btnimgfull2.Image"), System.Drawing.Image)
        Me.btnimgfull2.Location = New System.Drawing.Point(617, 375)
        Me.btnimgfull2.Name = "btnimgfull2"
        Me.btnimgfull2.Size = New System.Drawing.Size(208, 30)
        Me.btnimgfull2.TabIndex = 65
        Me.btnimgfull2.Text = "View Larger"
        Me.btnimgfull2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull2.UseVisualStyleBackColor = True
        '
        'imgpanel2
        '
        Me.imgpanel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.imgpanel2.AutoScroll = True
        Me.imgpanel2.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel2.Location = New System.Drawing.Point(6, 154)
        Me.imgpanel2.Name = "imgpanel2"
        Me.imgpanel2.Size = New System.Drawing.Size(569, 117)
        Me.imgpanel2.TabIndex = 63
        '
        'imgbox2
        '
        Me.imgbox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox2.Location = New System.Drawing.Point(580, 20)
        Me.imgbox2.Name = "imgbox2"
        Me.imgbox2.Size = New System.Drawing.Size(273, 219)
        Me.imgbox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox2.TabIndex = 62
        Me.imgbox2.TabStop = False
        '
        'btnimgremove2
        '
        Me.btnimgremove2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove2.Image = CType(resources.GetObject("btnimgremove2.Image"), System.Drawing.Image)
        Me.btnimgremove2.Location = New System.Drawing.Point(617, 339)
        Me.btnimgremove2.Name = "btnimgremove2"
        Me.btnimgremove2.Size = New System.Drawing.Size(101, 30)
        Me.btnimgremove2.TabIndex = 60
        Me.btnimgremove2.Text = "Remove"
        Me.btnimgremove2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove2.UseVisualStyleBackColor = True
        '
        'btnimgadd2
        '
        Me.btnimgadd2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd2.Image = CType(resources.GetObject("btnimgadd2.Image"), System.Drawing.Image)
        Me.btnimgadd2.Location = New System.Drawing.Point(617, 303)
        Me.btnimgadd2.Name = "btnimgadd2"
        Me.btnimgadd2.Size = New System.Drawing.Size(101, 30)
        Me.btnimgadd2.TabIndex = 58
        Me.btnimgadd2.Text = "Add Photo"
        Me.btnimgadd2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd2.UseVisualStyleBackColor = True
        '
        'btnimgcancel2
        '
        Me.btnimgcancel2.Enabled = False
        Me.btnimgcancel2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel2.Image = CType(resources.GetObject("btnimgcancel2.Image"), System.Drawing.Image)
        Me.btnimgcancel2.Location = New System.Drawing.Point(724, 339)
        Me.btnimgcancel2.Name = "btnimgcancel2"
        Me.btnimgcancel2.Size = New System.Drawing.Size(101, 30)
        Me.btnimgcancel2.TabIndex = 61
        Me.btnimgcancel2.Text = "Cancel"
        Me.btnimgcancel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel2.UseVisualStyleBackColor = True
        '
        'btnimgrefresh2
        '
        Me.btnimgrefresh2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh2.Image = CType(resources.GetObject("btnimgrefresh2.Image"), System.Drawing.Image)
        Me.btnimgrefresh2.Location = New System.Drawing.Point(617, 411)
        Me.btnimgrefresh2.Name = "btnimgrefresh2"
        Me.btnimgrefresh2.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh2.TabIndex = 66
        Me.btnimgrefresh2.Text = "Refresh Photos"
        Me.btnimgrefresh2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh2.UseVisualStyleBackColor = True
        '
        'btnimgrename2
        '
        Me.btnimgrename2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename2.Image = CType(resources.GetObject("btnimgrename2.Image"), System.Drawing.Image)
        Me.btnimgrename2.Location = New System.Drawing.Point(724, 303)
        Me.btnimgrename2.Name = "btnimgrename2"
        Me.btnimgrename2.Size = New System.Drawing.Size(101, 30)
        Me.btnimgrename2.TabIndex = 59
        Me.btnimgrename2.Text = "Rename"
        Me.btnimgrename2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename2.UseVisualStyleBackColor = True
        '
        'tab3
        '
        Me.tab3.Controls.Add(Me.panelstp3)
        Me.tab3.Location = New System.Drawing.Point(4, 64)
        Me.tab3.Name = "tab3"
        Me.tab3.Size = New System.Drawing.Size(1250, 602)
        Me.tab3.TabIndex = 6
        Me.tab3.Text = "     STEP 3 ( FOR LOADING / SCALING)     "
        Me.tab3.UseVisualStyleBackColor = True
        '
        'panelstp3
        '
        Me.panelstp3.AutoScroll = True
        Me.panelstp3.Controls.Add(Me.gstep3)
        Me.panelstp3.Controls.Add(Me.grp3)
        Me.panelstp3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelstp3.Location = New System.Drawing.Point(0, 0)
        Me.panelstp3.Name = "panelstp3"
        Me.panelstp3.Size = New System.Drawing.Size(1250, 602)
        Me.panelstp3.TabIndex = 3
        '
        'gstep3
        '
        Me.gstep3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gstep3.Controls.Add(Me.lblload3)
        Me.gstep3.Controls.Add(Me.cmbtrans3)
        Me.gstep3.Controls.Add(Me.btnrefstep3)
        Me.gstep3.Controls.Add(Me.grdstep3)
        Me.gstep3.Location = New System.Drawing.Point(6, 10)
        Me.gstep3.Name = "gstep3"
        Me.gstep3.Size = New System.Drawing.Size(379, 582)
        Me.gstep3.TabIndex = 0
        Me.gstep3.TabStop = False
        Me.gstep3.Text = "STEP 3 Trip"
        '
        'lblload3
        '
        Me.lblload3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload3.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload3.Location = New System.Drawing.Point(7, 53)
        Me.lblload3.Name = "lblload3"
        Me.lblload3.Size = New System.Drawing.Size(365, 488)
        Me.lblload3.TabIndex = 100
        Me.lblload3.Text = "Loading..."
        Me.lblload3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbtrans3
        '
        Me.cmbtrans3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbtrans3.FormattingEnabled = True
        Me.cmbtrans3.Location = New System.Drawing.Point(145, 551)
        Me.cmbtrans3.Name = "cmbtrans3"
        Me.cmbtrans3.Size = New System.Drawing.Size(121, 23)
        Me.cmbtrans3.TabIndex = 71
        Me.cmbtrans3.Visible = False
        '
        'btnrefstep3
        '
        Me.btnrefstep3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefstep3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefstep3.Image = CType(resources.GetObject("btnrefstep3.Image"), System.Drawing.Image)
        Me.btnrefstep3.Location = New System.Drawing.Point(272, 546)
        Me.btnrefstep3.Name = "btnrefstep3"
        Me.btnrefstep3.Size = New System.Drawing.Size(101, 30)
        Me.btnrefstep3.TabIndex = 70
        Me.btnrefstep3.Text = "Refresh List"
        Me.btnrefstep3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefstep3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefstep3.UseVisualStyleBackColor = True
        '
        'grdstep3
        '
        Me.grdstep3.AllowUserToAddRows = False
        Me.grdstep3.AllowUserToDeleteRows = False
        DataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdstep3.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle13
        Me.grdstep3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdstep3.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdstep3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle14.NullValue = Nothing
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep3.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle14
        Me.grdstep3.ColumnHeadersHeight = 30
        Me.grdstep3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdstep3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn71, Me.DataGridViewTextBoxColumn89})
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep3.DefaultCellStyle = DataGridViewCellStyle16
        Me.grdstep3.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdstep3.EnableHeadersVisualStyles = False
        Me.grdstep3.GridColor = System.Drawing.Color.Salmon
        Me.grdstep3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdstep3.Location = New System.Drawing.Point(6, 20)
        Me.grdstep3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdstep3.MultiSelect = False
        Me.grdstep3.Name = "grdstep3"
        Me.grdstep3.ReadOnly = True
        Me.grdstep3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep3.RowHeadersDefaultCellStyle = DataGridViewCellStyle17
        Me.grdstep3.RowHeadersWidth = 10
        Me.grdstep3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle18.NullValue = Nothing
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep3.RowsDefaultCellStyle = DataGridViewCellStyle18
        Me.grdstep3.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdstep3.Size = New System.Drawing.Size(367, 521)
        Me.grdstep3.TabIndex = 10
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.Frozen = True
        Me.DataGridViewTextBoxColumn9.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.Visible = False
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.Frozen = True
        Me.DataGridViewTextBoxColumn10.HeaderText = "Trip #"
        Me.DataGridViewTextBoxColumn10.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        Me.DataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn10.Width = 120
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.Frozen = True
        Me.DataGridViewTextBoxColumn11.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn11.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        Me.DataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn11.Width = 130
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.HeaderText = "Driver"
        Me.DataGridViewTextBoxColumn12.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        Me.DataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn12.Width = 150
        '
        'DataGridViewTextBoxColumn71
        '
        Me.DataGridViewTextBoxColumn71.HeaderText = "Helper"
        Me.DataGridViewTextBoxColumn71.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn71.Name = "DataGridViewTextBoxColumn71"
        Me.DataGridViewTextBoxColumn71.ReadOnly = True
        Me.DataGridViewTextBoxColumn71.Width = 180
        '
        'DataGridViewTextBoxColumn89
        '
        DataGridViewCellStyle15.Format = "yyyy/MM/dd"
        Me.DataGridViewTextBoxColumn89.DefaultCellStyle = DataGridViewCellStyle15
        Me.DataGridViewTextBoxColumn89.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn89.Name = "DataGridViewTextBoxColumn89"
        Me.DataGridViewTextBoxColumn89.ReadOnly = True
        Me.DataGridViewTextBoxColumn89.Visible = False
        '
        'grp3
        '
        Me.grp3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grp3.Controls.Add(Me.lblimgname3)
        Me.grp3.Controls.Add(Me.lblimgdate3)
        Me.grp3.Controls.Add(Me.tripinfo3)
        Me.grp3.Controls.Add(Me.grdtrans3)
        Me.grp3.Controls.Add(Me.pgbar3)
        Me.grp3.Controls.Add(Me.lblconfirm3)
        Me.grp3.Controls.Add(Me.lbltype3)
        Me.grp3.Controls.Add(Me.btnstartload)
        Me.grp3.Controls.Add(Me.Panel4)
        Me.grp3.Controls.Add(Me.cmbimg3)
        Me.grp3.Controls.Add(Me.txtrems3)
        Me.grp3.Controls.Add(Me.Panel8)
        Me.grp3.Controls.Add(Me.lbltripnum3)
        Me.grp3.Controls.Add(Me.lblplate3)
        Me.grp3.Controls.Add(Me.btnimgdl3)
        Me.grp3.Controls.Add(Me.lblimgid3)
        Me.grp3.Controls.Add(Me.btnimgfull3)
        Me.grp3.Controls.Add(Me.imgpanel3)
        Me.grp3.Controls.Add(Me.imgbox3)
        Me.grp3.Controls.Add(Me.btnimgremove3)
        Me.grp3.Controls.Add(Me.btnimgadd3)
        Me.grp3.Controls.Add(Me.btnimgcancel3)
        Me.grp3.Controls.Add(Me.btnimgrefresh3)
        Me.grp3.Controls.Add(Me.btnimgrename3)
        Me.grp3.Location = New System.Drawing.Point(388, 10)
        Me.grp3.Name = "grp3"
        Me.grp3.Size = New System.Drawing.Size(860, 582)
        Me.grp3.TabIndex = 1
        Me.grp3.TabStop = False
        Me.grp3.Text = "Photos"
        '
        'lblimgname3
        '
        Me.lblimgname3.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgname3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgname3.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgname3.Location = New System.Drawing.Point(724, 271)
        Me.lblimgname3.Name = "lblimgname3"
        Me.lblimgname3.Size = New System.Drawing.Size(129, 20)
        Me.lblimgname3.TabIndex = 107
        Me.lblimgname3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgdate3
        '
        Me.lblimgdate3.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgdate3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgdate3.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgdate3.Location = New System.Drawing.Point(580, 271)
        Me.lblimgdate3.Name = "lblimgdate3"
        Me.lblimgdate3.Size = New System.Drawing.Size(138, 20)
        Me.lblimgdate3.TabIndex = 106
        Me.lblimgdate3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tripinfo3
        '
        Me.tripinfo3.AutoSize = True
        Me.tripinfo3.Location = New System.Drawing.Point(745, 444)
        Me.tripinfo3.Name = "tripinfo3"
        Me.tripinfo3.Size = New System.Drawing.Size(80, 15)
        Me.tripinfo3.TabIndex = 98
        Me.tripinfo3.TabStop = True
        Me.tripinfo3.Text = "View Trip Info"
        '
        'grdtrans3
        '
        Me.grdtrans3.AllowUserToAddRows = False
        Me.grdtrans3.AllowUserToDeleteRows = False
        DataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdtrans3.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle19
        Me.grdtrans3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grdtrans3.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdtrans3.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdtrans3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle20.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle20.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle20.NullValue = Nothing
        DataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans3.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle20
        Me.grdtrans3.ColumnHeadersHeight = 30
        Me.grdtrans3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdtrans3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn79, Me.DataGridViewLinkColumn2, Me.DataGridViewTextBoxColumn80, Me.DataGridViewTextBoxColumn81, Me.DataGridViewTextBoxColumn82, Me.DataGridViewTextBoxColumn83, Me.DataGridViewTextBoxColumn84, Me.DataGridViewTextBoxColumn85, Me.DataGridViewTextBoxColumn86, Me.Column33, Me.Column34, Me.DataGridViewTextBoxColumn87, Me.DataGridViewTextBoxColumn88})
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle21.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans3.DefaultCellStyle = DataGridViewCellStyle21
        Me.grdtrans3.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdtrans3.EnableHeadersVisualStyles = False
        Me.grdtrans3.GridColor = System.Drawing.Color.Salmon
        Me.grdtrans3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdtrans3.Location = New System.Drawing.Point(6, 320)
        Me.grdtrans3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdtrans3.MultiSelect = False
        Me.grdtrans3.Name = "grdtrans3"
        Me.grdtrans3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle22.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans3.RowHeadersDefaultCellStyle = DataGridViewCellStyle22
        Me.grdtrans3.RowHeadersWidth = 10
        Me.grdtrans3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle23.NullValue = Nothing
        DataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans3.RowsDefaultCellStyle = DataGridViewCellStyle23
        Me.grdtrans3.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrans3.Size = New System.Drawing.Size(569, 177)
        Me.grdtrans3.TabIndex = 88
        '
        'DataGridViewTextBoxColumn79
        '
        Me.DataGridViewTextBoxColumn79.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn79.Name = "DataGridViewTextBoxColumn79"
        Me.DataGridViewTextBoxColumn79.Visible = False
        '
        'DataGridViewLinkColumn2
        '
        Me.DataGridViewLinkColumn2.ActiveLinkColor = System.Drawing.Color.Black
        Me.DataGridViewLinkColumn2.HeaderText = "Transaction #"
        Me.DataGridViewLinkColumn2.LinkColor = System.Drawing.Color.Red
        Me.DataGridViewLinkColumn2.MinimumWidth = 130
        Me.DataGridViewLinkColumn2.Name = "DataGridViewLinkColumn2"
        Me.DataGridViewLinkColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewLinkColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewLinkColumn2.Width = 130
        '
        'DataGridViewTextBoxColumn80
        '
        Me.DataGridViewTextBoxColumn80.HeaderText = "Reference #"
        Me.DataGridViewTextBoxColumn80.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn80.Name = "DataGridViewTextBoxColumn80"
        Me.DataGridViewTextBoxColumn80.Width = 120
        '
        'DataGridViewTextBoxColumn81
        '
        Me.DataGridViewTextBoxColumn81.HeaderText = "Recipient"
        Me.DataGridViewTextBoxColumn81.MinimumWidth = 150
        Me.DataGridViewTextBoxColumn81.Name = "DataGridViewTextBoxColumn81"
        Me.DataGridViewTextBoxColumn81.Width = 150
        '
        'DataGridViewTextBoxColumn82
        '
        Me.DataGridViewTextBoxColumn82.HeaderText = "AR #"
        Me.DataGridViewTextBoxColumn82.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn82.Name = "DataGridViewTextBoxColumn82"
        Me.DataGridViewTextBoxColumn82.Width = 120
        '
        'DataGridViewTextBoxColumn83
        '
        Me.DataGridViewTextBoxColumn83.HeaderText = "RDR"
        Me.DataGridViewTextBoxColumn83.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn83.Name = "DataGridViewTextBoxColumn83"
        Me.DataGridViewTextBoxColumn83.Width = 120
        '
        'DataGridViewTextBoxColumn84
        '
        Me.DataGridViewTextBoxColumn84.HeaderText = "DR#"
        Me.DataGridViewTextBoxColumn84.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn84.Name = "DataGridViewTextBoxColumn84"
        Me.DataGridViewTextBoxColumn84.Width = 120
        '
        'DataGridViewTextBoxColumn85
        '
        Me.DataGridViewTextBoxColumn85.HeaderText = "DN#"
        Me.DataGridViewTextBoxColumn85.Name = "DataGridViewTextBoxColumn85"
        '
        'DataGridViewTextBoxColumn86
        '
        Me.DataGridViewTextBoxColumn86.HeaderText = "ITR#"
        Me.DataGridViewTextBoxColumn86.Name = "DataGridViewTextBoxColumn86"
        '
        'Column33
        '
        Me.Column33.HeaderText = "IT#"
        Me.Column33.Name = "Column33"
        Me.Column33.Visible = False
        '
        'Column34
        '
        Me.Column34.HeaderText = "GRPO#"
        Me.Column34.Name = "Column34"
        Me.Column34.Visible = False
        '
        'DataGridViewTextBoxColumn87
        '
        Me.DataGridViewTextBoxColumn87.HeaderText = "Transaction Type"
        Me.DataGridViewTextBoxColumn87.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn87.Name = "DataGridViewTextBoxColumn87"
        Me.DataGridViewTextBoxColumn87.Width = 200
        '
        'DataGridViewTextBoxColumn88
        '
        Me.DataGridViewTextBoxColumn88.HeaderText = "Notes"
        Me.DataGridViewTextBoxColumn88.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn88.Name = "DataGridViewTextBoxColumn88"
        Me.DataGridViewTextBoxColumn88.Width = 220
        '
        'pgbar3
        '
        Me.pgbar3.Location = New System.Drawing.Point(580, 216)
        Me.pgbar3.Name = "pgbar3"
        Me.pgbar3.Size = New System.Drawing.Size(273, 23)
        Me.pgbar3.TabIndex = 87
        Me.pgbar3.Visible = False
        '
        'lblconfirm3
        '
        Me.lblconfirm3.BackColor = System.Drawing.Color.Transparent
        Me.lblconfirm3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblconfirm3.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblconfirm3.Location = New System.Drawing.Point(6, 76)
        Me.lblconfirm3.Name = "lblconfirm3"
        Me.lblconfirm3.Size = New System.Drawing.Size(132, 38)
        Me.lblconfirm3.TabIndex = 83
        Me.lblconfirm3.Text = "0"
        Me.lblconfirm3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblconfirm3.Visible = False
        '
        'lbltype3
        '
        Me.lbltype3.BackColor = System.Drawing.Color.Transparent
        Me.lbltype3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype3.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold)
        Me.lbltype3.Location = New System.Drawing.Point(360, 22)
        Me.lbltype3.Name = "lbltype3"
        Me.lbltype3.Size = New System.Drawing.Size(215, 38)
        Me.lbltype3.TabIndex = 82
        Me.lbltype3.Text = "TYPE"
        Me.lbltype3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnstartload
        '
        Me.btnstartload.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnstartload.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstartload.Image = CType(resources.GetObject("btnstartload.Image"), System.Drawing.Image)
        Me.btnstartload.Location = New System.Drawing.Point(6, 65)
        Me.btnstartload.Name = "btnstartload"
        Me.btnstartload.Size = New System.Drawing.Size(569, 62)
        Me.btnstartload.TabIndex = 76
        Me.btnstartload.Text = "TIME START LOADING"
        Me.btnstartload.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnstartload.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnstartload.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel4.BackColor = System.Drawing.Color.LightGreen
        Me.Panel4.Controls.Add(Me.txtlabor)
        Me.Panel4.Controls.Add(Me.Label3)
        Me.Panel4.Location = New System.Drawing.Point(580, 486)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(273, 30)
        Me.Panel4.TabIndex = 75
        '
        'txtlabor
        '
        Me.txtlabor.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtlabor.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlabor.Location = New System.Drawing.Point(100, 4)
        Me.txtlabor.Name = "txtlabor"
        Me.txtlabor.Size = New System.Drawing.Size(169, 22)
        Me.txtlabor.TabIndex = 76
        Me.txtlabor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 7)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 16)
        Me.Label3.TabIndex = 75
        Me.Label3.Text = "No. of Labor"
        '
        'cmbimg3
        '
        Me.cmbimg3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbimg3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbimg3.FormattingEnabled = True
        Me.cmbimg3.Items.AddRange(New Object() {"", "Truck Inspection Report before Loading", "SO signed by Checker and Driver", "ITR signed by Checker and Driver", "Truck Scale"})
        Me.cmbimg3.Location = New System.Drawing.Point(580, 245)
        Me.cmbimg3.Name = "cmbimg3"
        Me.cmbimg3.Size = New System.Drawing.Size(273, 23)
        Me.cmbimg3.TabIndex = 73
        '
        'txtrems3
        '
        Me.txtrems3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtrems3.Location = New System.Drawing.Point(6, 503)
        Me.txtrems3.Multiline = True
        Me.txtrems3.Name = "txtrems3"
        Me.txtrems3.Size = New System.Drawing.Size(569, 71)
        Me.txtrems3.TabIndex = 72
        '
        'Panel8
        '
        Me.Panel8.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel8.Controls.Add(Me.btnexempt3)
        Me.Panel8.Controls.Add(Me.btnnot3)
        Me.Panel8.Controls.Add(Me.btnconfirm3)
        Me.Panel8.Location = New System.Drawing.Point(580, 522)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(273, 52)
        Me.Panel8.TabIndex = 71
        '
        'btnexempt3
        '
        Me.btnexempt3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnexempt3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexempt3.Image = CType(resources.GetObject("btnexempt3.Image"), System.Drawing.Image)
        Me.btnexempt3.Location = New System.Drawing.Point(139, 3)
        Me.btnexempt3.Name = "btnexempt3"
        Me.btnexempt3.Size = New System.Drawing.Size(130, 45)
        Me.btnexempt3.TabIndex = 74
        Me.btnexempt3.Text = "SAVE AS DRAFT"
        Me.btnexempt3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnexempt3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnexempt3.UseVisualStyleBackColor = True
        '
        'btnnot3
        '
        Me.btnnot3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnnot3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnot3.Image = CType(resources.GetObject("btnnot3.Image"), System.Drawing.Image)
        Me.btnnot3.Location = New System.Drawing.Point(139, 3)
        Me.btnnot3.Name = "btnnot3"
        Me.btnnot3.Size = New System.Drawing.Size(130, 45)
        Me.btnnot3.TabIndex = 73
        Me.btnnot3.Text = "NOT APPLICABLE"
        Me.btnnot3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnnot3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnnot3.UseVisualStyleBackColor = True
        Me.btnnot3.Visible = False
        '
        'btnconfirm3
        '
        Me.btnconfirm3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnconfirm3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirm3.Image = CType(resources.GetObject("btnconfirm3.Image"), System.Drawing.Image)
        Me.btnconfirm3.Location = New System.Drawing.Point(3, 3)
        Me.btnconfirm3.Name = "btnconfirm3"
        Me.btnconfirm3.Size = New System.Drawing.Size(130, 45)
        Me.btnconfirm3.TabIndex = 72
        Me.btnconfirm3.Text = "CONFIRM"
        Me.btnconfirm3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnconfirm3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnconfirm3.UseVisualStyleBackColor = True
        '
        'lbltripnum3
        '
        Me.lbltripnum3.BackColor = System.Drawing.Color.Transparent
        Me.lbltripnum3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltripnum3.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltripnum3.Location = New System.Drawing.Point(6, 22)
        Me.lbltripnum3.Name = "lbltripnum3"
        Me.lbltripnum3.Size = New System.Drawing.Size(132, 38)
        Me.lbltripnum3.TabIndex = 70
        Me.lbltripnum3.Text = "Trip#"
        Me.lbltripnum3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbltripnum3.Visible = False
        '
        'lblplate3
        '
        Me.lblplate3.BackColor = System.Drawing.Color.Transparent
        Me.lblplate3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate3.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate3.Location = New System.Drawing.Point(6, 22)
        Me.lblplate3.Name = "lblplate3"
        Me.lblplate3.Size = New System.Drawing.Size(360, 38)
        Me.lblplate3.TabIndex = 69
        Me.lblplate3.Text = "Plate #"
        Me.lblplate3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnimgdl3
        '
        Me.btnimgdl3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl3.Image = CType(resources.GetObject("btnimgdl3.Image"), System.Drawing.Image)
        Me.btnimgdl3.Location = New System.Drawing.Point(590, 426)
        Me.btnimgdl3.Name = "btnimgdl3"
        Me.btnimgdl3.Size = New System.Drawing.Size(25, 30)
        Me.btnimgdl3.TabIndex = 64
        Me.btnimgdl3.Text = "Download Photo"
        Me.btnimgdl3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl3.UseVisualStyleBackColor = True
        Me.btnimgdl3.Visible = False
        '
        'lblimgid3
        '
        Me.lblimgid3.AutoSize = True
        Me.lblimgid3.Location = New System.Drawing.Point(577, 402)
        Me.lblimgid3.Name = "lblimgid3"
        Me.lblimgid3.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid3.TabIndex = 68
        Me.lblimgid3.Text = "imgid"
        Me.lblimgid3.Visible = False
        '
        'btnimgfull3
        '
        Me.btnimgfull3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull3.Image = CType(resources.GetObject("btnimgfull3.Image"), System.Drawing.Image)
        Me.btnimgfull3.Location = New System.Drawing.Point(617, 375)
        Me.btnimgfull3.Name = "btnimgfull3"
        Me.btnimgfull3.Size = New System.Drawing.Size(208, 30)
        Me.btnimgfull3.TabIndex = 65
        Me.btnimgfull3.Text = "View Larger"
        Me.btnimgfull3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull3.UseVisualStyleBackColor = True
        '
        'imgpanel3
        '
        Me.imgpanel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.imgpanel3.AutoScroll = True
        Me.imgpanel3.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel3.Location = New System.Drawing.Point(6, 133)
        Me.imgpanel3.Name = "imgpanel3"
        Me.imgpanel3.Size = New System.Drawing.Size(569, 181)
        Me.imgpanel3.TabIndex = 63
        '
        'imgbox3
        '
        Me.imgbox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox3.Location = New System.Drawing.Point(580, 20)
        Me.imgbox3.Name = "imgbox3"
        Me.imgbox3.Size = New System.Drawing.Size(273, 219)
        Me.imgbox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox3.TabIndex = 62
        Me.imgbox3.TabStop = False
        '
        'btnimgremove3
        '
        Me.btnimgremove3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove3.Image = CType(resources.GetObject("btnimgremove3.Image"), System.Drawing.Image)
        Me.btnimgremove3.Location = New System.Drawing.Point(617, 339)
        Me.btnimgremove3.Name = "btnimgremove3"
        Me.btnimgremove3.Size = New System.Drawing.Size(101, 30)
        Me.btnimgremove3.TabIndex = 60
        Me.btnimgremove3.Text = "Remove"
        Me.btnimgremove3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove3.UseVisualStyleBackColor = True
        '
        'btnimgadd3
        '
        Me.btnimgadd3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd3.Image = CType(resources.GetObject("btnimgadd3.Image"), System.Drawing.Image)
        Me.btnimgadd3.Location = New System.Drawing.Point(617, 303)
        Me.btnimgadd3.Name = "btnimgadd3"
        Me.btnimgadd3.Size = New System.Drawing.Size(101, 30)
        Me.btnimgadd3.TabIndex = 58
        Me.btnimgadd3.Text = "Add Photo"
        Me.btnimgadd3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd3.UseVisualStyleBackColor = True
        '
        'btnimgcancel3
        '
        Me.btnimgcancel3.Enabled = False
        Me.btnimgcancel3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel3.Image = CType(resources.GetObject("btnimgcancel3.Image"), System.Drawing.Image)
        Me.btnimgcancel3.Location = New System.Drawing.Point(724, 339)
        Me.btnimgcancel3.Name = "btnimgcancel3"
        Me.btnimgcancel3.Size = New System.Drawing.Size(101, 30)
        Me.btnimgcancel3.TabIndex = 61
        Me.btnimgcancel3.Text = "Cancel"
        Me.btnimgcancel3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel3.UseVisualStyleBackColor = True
        '
        'btnimgrefresh3
        '
        Me.btnimgrefresh3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh3.Image = CType(resources.GetObject("btnimgrefresh3.Image"), System.Drawing.Image)
        Me.btnimgrefresh3.Location = New System.Drawing.Point(617, 411)
        Me.btnimgrefresh3.Name = "btnimgrefresh3"
        Me.btnimgrefresh3.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh3.TabIndex = 66
        Me.btnimgrefresh3.Text = "Refresh Photos"
        Me.btnimgrefresh3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh3.UseVisualStyleBackColor = True
        '
        'btnimgrename3
        '
        Me.btnimgrename3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename3.Image = CType(resources.GetObject("btnimgrename3.Image"), System.Drawing.Image)
        Me.btnimgrename3.Location = New System.Drawing.Point(724, 303)
        Me.btnimgrename3.Name = "btnimgrename3"
        Me.btnimgrename3.Size = New System.Drawing.Size(101, 30)
        Me.btnimgrename3.TabIndex = 59
        Me.btnimgrename3.Text = "Rename"
        Me.btnimgrename3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename3.UseVisualStyleBackColor = True
        '
        'tab4
        '
        Me.tab4.Controls.Add(Me.panelstp4)
        Me.tab4.Location = New System.Drawing.Point(4, 64)
        Me.tab4.Name = "tab4"
        Me.tab4.Size = New System.Drawing.Size(1250, 602)
        Me.tab4.TabIndex = 7
        Me.tab4.Text = "     STEP 4 ( RELEASE DOCUMENTS )     "
        Me.tab4.UseVisualStyleBackColor = True
        '
        'panelstp4
        '
        Me.panelstp4.AutoScroll = True
        Me.panelstp4.Controls.Add(Me.gstep4)
        Me.panelstp4.Controls.Add(Me.grp4)
        Me.panelstp4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelstp4.Location = New System.Drawing.Point(0, 0)
        Me.panelstp4.Name = "panelstp4"
        Me.panelstp4.Size = New System.Drawing.Size(1250, 602)
        Me.panelstp4.TabIndex = 3
        '
        'gstep4
        '
        Me.gstep4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gstep4.Controls.Add(Me.lblload4)
        Me.gstep4.Controls.Add(Me.cmbtrans4)
        Me.gstep4.Controls.Add(Me.btnrefstep4)
        Me.gstep4.Controls.Add(Me.grdstep4)
        Me.gstep4.Location = New System.Drawing.Point(6, 10)
        Me.gstep4.Name = "gstep4"
        Me.gstep4.Size = New System.Drawing.Size(379, 582)
        Me.gstep4.TabIndex = 0
        Me.gstep4.TabStop = False
        Me.gstep4.Text = "STEP 4 Trip"
        '
        'lblload4
        '
        Me.lblload4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload4.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload4.Location = New System.Drawing.Point(7, 52)
        Me.lblload4.Name = "lblload4"
        Me.lblload4.Size = New System.Drawing.Size(365, 489)
        Me.lblload4.TabIndex = 101
        Me.lblload4.Text = "Loading..."
        Me.lblload4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbtrans4
        '
        Me.cmbtrans4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbtrans4.FormattingEnabled = True
        Me.cmbtrans4.Location = New System.Drawing.Point(162, 548)
        Me.cmbtrans4.Name = "cmbtrans4"
        Me.cmbtrans4.Size = New System.Drawing.Size(104, 23)
        Me.cmbtrans4.TabIndex = 72
        Me.cmbtrans4.Visible = False
        '
        'btnrefstep4
        '
        Me.btnrefstep4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefstep4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefstep4.Image = CType(resources.GetObject("btnrefstep4.Image"), System.Drawing.Image)
        Me.btnrefstep4.Location = New System.Drawing.Point(272, 546)
        Me.btnrefstep4.Name = "btnrefstep4"
        Me.btnrefstep4.Size = New System.Drawing.Size(101, 30)
        Me.btnrefstep4.TabIndex = 70
        Me.btnrefstep4.Text = "Refresh List"
        Me.btnrefstep4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefstep4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefstep4.UseVisualStyleBackColor = True
        '
        'grdstep4
        '
        Me.grdstep4.AllowUserToAddRows = False
        Me.grdstep4.AllowUserToDeleteRows = False
        DataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdstep4.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle24
        Me.grdstep4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdstep4.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdstep4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle25.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle25.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle25.NullValue = Nothing
        DataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep4.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle25
        Me.grdstep4.ColumnHeadersHeight = 30
        Me.grdstep4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdstep4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn72, Me.DataGridViewTextBoxColumn90})
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle27.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep4.DefaultCellStyle = DataGridViewCellStyle27
        Me.grdstep4.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdstep4.EnableHeadersVisualStyles = False
        Me.grdstep4.GridColor = System.Drawing.Color.Salmon
        Me.grdstep4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdstep4.Location = New System.Drawing.Point(6, 20)
        Me.grdstep4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdstep4.MultiSelect = False
        Me.grdstep4.Name = "grdstep4"
        Me.grdstep4.ReadOnly = True
        Me.grdstep4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle28.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep4.RowHeadersDefaultCellStyle = DataGridViewCellStyle28
        Me.grdstep4.RowHeadersWidth = 10
        Me.grdstep4.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle29.NullValue = Nothing
        DataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep4.RowsDefaultCellStyle = DataGridViewCellStyle29
        Me.grdstep4.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdstep4.Size = New System.Drawing.Size(367, 521)
        Me.grdstep4.TabIndex = 10
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.Frozen = True
        Me.DataGridViewTextBoxColumn13.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        Me.DataGridViewTextBoxColumn13.Visible = False
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.Frozen = True
        Me.DataGridViewTextBoxColumn14.HeaderText = "Trip #"
        Me.DataGridViewTextBoxColumn14.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        Me.DataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn14.Width = 120
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.Frozen = True
        Me.DataGridViewTextBoxColumn15.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn15.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        Me.DataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn15.Width = 130
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.HeaderText = "Driver"
        Me.DataGridViewTextBoxColumn16.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.ReadOnly = True
        Me.DataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn16.Width = 150
        '
        'DataGridViewTextBoxColumn72
        '
        Me.DataGridViewTextBoxColumn72.HeaderText = "Helper"
        Me.DataGridViewTextBoxColumn72.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn72.Name = "DataGridViewTextBoxColumn72"
        Me.DataGridViewTextBoxColumn72.ReadOnly = True
        Me.DataGridViewTextBoxColumn72.Width = 180
        '
        'DataGridViewTextBoxColumn90
        '
        DataGridViewCellStyle26.Format = "yyyy/MM/dd"
        Me.DataGridViewTextBoxColumn90.DefaultCellStyle = DataGridViewCellStyle26
        Me.DataGridViewTextBoxColumn90.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn90.Name = "DataGridViewTextBoxColumn90"
        Me.DataGridViewTextBoxColumn90.ReadOnly = True
        Me.DataGridViewTextBoxColumn90.Visible = False
        '
        'grp4
        '
        Me.grp4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grp4.Controls.Add(Me.lblimgname4)
        Me.grp4.Controls.Add(Me.lblimgdate4)
        Me.grp4.Controls.Add(Me.tripinfo4)
        Me.grp4.Controls.Add(Me.pgbar4)
        Me.grp4.Controls.Add(Me.lblconfirm4)
        Me.grp4.Controls.Add(Me.Label20)
        Me.grp4.Controls.Add(Me.Label11)
        Me.grp4.Controls.Add(Me.Label10)
        Me.grp4.Controls.Add(Me.lbltype4)
        Me.grp4.Controls.Add(Me.btnstartdoc)
        Me.grp4.Controls.Add(Me.grdtrans4)
        Me.grp4.Controls.Add(Me.cmbimg4)
        Me.grp4.Controls.Add(Me.txtrems4)
        Me.grp4.Controls.Add(Me.Panel11)
        Me.grp4.Controls.Add(Me.lbltripnum4)
        Me.grp4.Controls.Add(Me.lblplate4)
        Me.grp4.Controls.Add(Me.btnimgdl4)
        Me.grp4.Controls.Add(Me.lblimgid4)
        Me.grp4.Controls.Add(Me.btnimgfull4)
        Me.grp4.Controls.Add(Me.imgpanel4)
        Me.grp4.Controls.Add(Me.imgbox4)
        Me.grp4.Controls.Add(Me.btnimgremove4)
        Me.grp4.Controls.Add(Me.btnimgadd4)
        Me.grp4.Controls.Add(Me.btnimgcancel4)
        Me.grp4.Controls.Add(Me.btnimgrefresh4)
        Me.grp4.Controls.Add(Me.btnimgrename4)
        Me.grp4.Location = New System.Drawing.Point(388, 10)
        Me.grp4.Name = "grp4"
        Me.grp4.Size = New System.Drawing.Size(860, 582)
        Me.grp4.TabIndex = 1
        Me.grp4.TabStop = False
        Me.grp4.Text = "Photos"
        '
        'lblimgname4
        '
        Me.lblimgname4.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgname4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgname4.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgname4.Location = New System.Drawing.Point(724, 271)
        Me.lblimgname4.Name = "lblimgname4"
        Me.lblimgname4.Size = New System.Drawing.Size(129, 20)
        Me.lblimgname4.TabIndex = 109
        Me.lblimgname4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgdate4
        '
        Me.lblimgdate4.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgdate4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgdate4.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgdate4.Location = New System.Drawing.Point(580, 271)
        Me.lblimgdate4.Name = "lblimgdate4"
        Me.lblimgdate4.Size = New System.Drawing.Size(138, 20)
        Me.lblimgdate4.TabIndex = 108
        Me.lblimgdate4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tripinfo4
        '
        Me.tripinfo4.AutoSize = True
        Me.tripinfo4.Location = New System.Drawing.Point(745, 444)
        Me.tripinfo4.Name = "tripinfo4"
        Me.tripinfo4.Size = New System.Drawing.Size(80, 15)
        Me.tripinfo4.TabIndex = 89
        Me.tripinfo4.TabStop = True
        Me.tripinfo4.Text = "View Trip Info"
        '
        'pgbar4
        '
        Me.pgbar4.Location = New System.Drawing.Point(580, 216)
        Me.pgbar4.Name = "pgbar4"
        Me.pgbar4.Size = New System.Drawing.Size(273, 23)
        Me.pgbar4.TabIndex = 88
        Me.pgbar4.Visible = False
        '
        'lblconfirm4
        '
        Me.lblconfirm4.BackColor = System.Drawing.Color.Transparent
        Me.lblconfirm4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblconfirm4.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblconfirm4.Location = New System.Drawing.Point(6, 76)
        Me.lblconfirm4.Name = "lblconfirm4"
        Me.lblconfirm4.Size = New System.Drawing.Size(132, 38)
        Me.lblconfirm4.TabIndex = 83
        Me.lblconfirm4.Text = "0"
        Me.lblconfirm4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblconfirm4.Visible = False
        '
        'Label20
        '
        Me.Label20.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Red
        Me.Label20.Location = New System.Drawing.Point(179, 306)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(175, 14)
        Me.Label20.TabIndex = 85
        Me.Label20.Text = "-Write  TO FOLLOW  if to follow."
        '
        'Label11
        '
        Me.Label11.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Red
        Me.Label11.Location = New System.Drawing.Point(6, 306)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(167, 14)
        Me.Label11.TabIndex = 84
        Me.Label11.Text = "-Write  N/A  if not applicable."
        '
        'Label10
        '
        Me.Label10.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Red
        Me.Label10.Location = New System.Drawing.Point(3, 290)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(405, 14)
        Me.Label10.TabIndex = 83
        Me.Label10.Text = "-Tick the SO box / PO box / ITR box if you check the details of SO / PO / ITR."
        '
        'lbltype4
        '
        Me.lbltype4.BackColor = System.Drawing.Color.Transparent
        Me.lbltype4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype4.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold)
        Me.lbltype4.Location = New System.Drawing.Point(360, 22)
        Me.lbltype4.Name = "lbltype4"
        Me.lbltype4.Size = New System.Drawing.Size(215, 38)
        Me.lbltype4.TabIndex = 82
        Me.lbltype4.Text = "TYPE"
        Me.lbltype4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnstartdoc
        '
        Me.btnstartdoc.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnstartdoc.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstartdoc.Image = CType(resources.GetObject("btnstartdoc.Image"), System.Drawing.Image)
        Me.btnstartdoc.Location = New System.Drawing.Point(6, 65)
        Me.btnstartdoc.Name = "btnstartdoc"
        Me.btnstartdoc.Size = New System.Drawing.Size(569, 62)
        Me.btnstartdoc.TabIndex = 77
        Me.btnstartdoc.Text = "TIME START RELEASE DOCUMENTS"
        Me.btnstartdoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnstartdoc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnstartdoc.UseVisualStyleBackColor = False
        '
        'grdtrans4
        '
        Me.grdtrans4.AllowUserToAddRows = False
        Me.grdtrans4.AllowUserToDeleteRows = False
        DataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdtrans4.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle30
        Me.grdtrans4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grdtrans4.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdtrans4.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdtrans4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle31.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle31.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle31.NullValue = Nothing
        DataGridViewCellStyle31.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans4.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle31
        Me.grdtrans4.ColumnHeadersHeight = 30
        Me.grdtrans4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdtrans4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column9, Me.Column10, Me.Column11, Me.Column15, Me.Column2, Me.Column3, Me.Column4, Me.Column12, Me.Column13, Me.Column14, Me.Column18, Me.Column19, Me.Column16, Me.Column17, Me.Column21})
        DataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle32.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans4.DefaultCellStyle = DataGridViewCellStyle32
        Me.grdtrans4.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdtrans4.EnableHeadersVisualStyles = False
        Me.grdtrans4.GridColor = System.Drawing.Color.Salmon
        Me.grdtrans4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdtrans4.Location = New System.Drawing.Point(6, 326)
        Me.grdtrans4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdtrans4.MultiSelect = False
        Me.grdtrans4.Name = "grdtrans4"
        Me.grdtrans4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle33.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle33.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle33.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle33.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans4.RowHeadersDefaultCellStyle = DataGridViewCellStyle33
        Me.grdtrans4.RowHeadersWidth = 10
        Me.grdtrans4.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle34.NullValue = Nothing
        DataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans4.RowsDefaultCellStyle = DataGridViewCellStyle34
        Me.grdtrans4.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrans4.Size = New System.Drawing.Size(569, 172)
        Me.grdtrans4.TabIndex = 75
        '
        'Column9
        '
        Me.Column9.Frozen = True
        Me.Column9.HeaderText = "ID"
        Me.Column9.Name = "Column9"
        Me.Column9.Visible = False
        '
        'Column10
        '
        Me.Column10.ActiveLinkColor = System.Drawing.Color.Black
        Me.Column10.Frozen = True
        Me.Column10.HeaderText = "Transaction #"
        Me.Column10.LinkColor = System.Drawing.Color.Red
        Me.Column10.MinimumWidth = 130
        Me.Column10.Name = "Column10"
        Me.Column10.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column10.Width = 130
        '
        'Column11
        '
        Me.Column11.Frozen = True
        Me.Column11.HeaderText = "Reference #"
        Me.Column11.MinimumWidth = 120
        Me.Column11.Name = "Column11"
        Me.Column11.Width = 120
        '
        'Column15
        '
        Me.Column15.Frozen = True
        Me.Column15.HeaderText = "Recipient"
        Me.Column15.MinimumWidth = 150
        Me.Column15.Name = "Column15"
        Me.Column15.Width = 150
        '
        'Column2
        '
        Me.Column2.HeaderText = "SO"
        Me.Column2.MinimumWidth = 50
        Me.Column2.Name = "Column2"
        Me.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column2.Width = 50
        '
        'Column3
        '
        Me.Column3.HeaderText = "PO"
        Me.Column3.MinimumWidth = 50
        Me.Column3.Name = "Column3"
        Me.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column3.Width = 50
        '
        'Column4
        '
        Me.Column4.HeaderText = "ITR"
        Me.Column4.MinimumWidth = 50
        Me.Column4.Name = "Column4"
        Me.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column4.Width = 50
        '
        'Column12
        '
        Me.Column12.HeaderText = "AR #"
        Me.Column12.MinimumWidth = 120
        Me.Column12.Name = "Column12"
        Me.Column12.Width = 120
        '
        'Column13
        '
        Me.Column13.HeaderText = "RDR"
        Me.Column13.MinimumWidth = 120
        Me.Column13.Name = "Column13"
        Me.Column13.Width = 120
        '
        'Column14
        '
        Me.Column14.HeaderText = "DR#"
        Me.Column14.MinimumWidth = 120
        Me.Column14.Name = "Column14"
        Me.Column14.Width = 120
        '
        'Column18
        '
        Me.Column18.HeaderText = "DN#"
        Me.Column18.Name = "Column18"
        '
        'Column19
        '
        Me.Column19.HeaderText = "ITR#"
        Me.Column19.Name = "Column19"
        '
        'Column16
        '
        Me.Column16.HeaderText = "Transaction Type"
        Me.Column16.MinimumWidth = 10
        Me.Column16.Name = "Column16"
        Me.Column16.Width = 180
        '
        'Column17
        '
        Me.Column17.HeaderText = "Notes"
        Me.Column17.MinimumWidth = 200
        Me.Column17.Name = "Column17"
        Me.Column17.Width = 220
        '
        'Column21
        '
        Me.Column21.HeaderText = "manager"
        Me.Column21.Name = "Column21"
        Me.Column21.Visible = False
        '
        'cmbimg4
        '
        Me.cmbimg4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbimg4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbimg4.FormattingEnabled = True
        Me.cmbimg4.Items.AddRange(New Object() {"", "DR signed by Driver / Checker", "SWS (Stock Withdrawal Slip)"})
        Me.cmbimg4.Location = New System.Drawing.Point(580, 245)
        Me.cmbimg4.Name = "cmbimg4"
        Me.cmbimg4.Size = New System.Drawing.Size(273, 23)
        Me.cmbimg4.TabIndex = 73
        '
        'txtrems4
        '
        Me.txtrems4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtrems4.Location = New System.Drawing.Point(6, 503)
        Me.txtrems4.Multiline = True
        Me.txtrems4.Name = "txtrems4"
        Me.txtrems4.Size = New System.Drawing.Size(569, 71)
        Me.txtrems4.TabIndex = 72
        '
        'Panel11
        '
        Me.Panel11.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel11.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel11.Controls.Add(Me.btnexempt4)
        Me.Panel11.Controls.Add(Me.btnconfirm4)
        Me.Panel11.Location = New System.Drawing.Point(580, 503)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(273, 71)
        Me.Panel11.TabIndex = 71
        '
        'btnexempt4
        '
        Me.btnexempt4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnexempt4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexempt4.Image = CType(resources.GetObject("btnexempt4.Image"), System.Drawing.Image)
        Me.btnexempt4.Location = New System.Drawing.Point(139, 3)
        Me.btnexempt4.Name = "btnexempt4"
        Me.btnexempt4.Size = New System.Drawing.Size(130, 62)
        Me.btnexempt4.TabIndex = 73
        Me.btnexempt4.Text = "SAVE AS DRAFT"
        Me.btnexempt4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnexempt4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnexempt4.UseVisualStyleBackColor = True
        '
        'btnconfirm4
        '
        Me.btnconfirm4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnconfirm4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirm4.Image = CType(resources.GetObject("btnconfirm4.Image"), System.Drawing.Image)
        Me.btnconfirm4.Location = New System.Drawing.Point(3, 3)
        Me.btnconfirm4.Name = "btnconfirm4"
        Me.btnconfirm4.Size = New System.Drawing.Size(130, 62)
        Me.btnconfirm4.TabIndex = 72
        Me.btnconfirm4.Text = "CONFIRM"
        Me.btnconfirm4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnconfirm4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnconfirm4.UseVisualStyleBackColor = True
        '
        'lbltripnum4
        '
        Me.lbltripnum4.BackColor = System.Drawing.Color.Transparent
        Me.lbltripnum4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltripnum4.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltripnum4.Location = New System.Drawing.Point(6, 22)
        Me.lbltripnum4.Name = "lbltripnum4"
        Me.lbltripnum4.Size = New System.Drawing.Size(184, 38)
        Me.lbltripnum4.TabIndex = 70
        Me.lbltripnum4.Text = "Trip#"
        Me.lbltripnum4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbltripnum4.Visible = False
        '
        'lblplate4
        '
        Me.lblplate4.BackColor = System.Drawing.Color.Transparent
        Me.lblplate4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate4.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate4.Location = New System.Drawing.Point(6, 22)
        Me.lblplate4.Name = "lblplate4"
        Me.lblplate4.Size = New System.Drawing.Size(360, 38)
        Me.lblplate4.TabIndex = 69
        Me.lblplate4.Text = "Plate #"
        Me.lblplate4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnimgdl4
        '
        Me.btnimgdl4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl4.Image = CType(resources.GetObject("btnimgdl4.Image"), System.Drawing.Image)
        Me.btnimgdl4.Location = New System.Drawing.Point(589, 450)
        Me.btnimgdl4.Name = "btnimgdl4"
        Me.btnimgdl4.Size = New System.Drawing.Size(26, 30)
        Me.btnimgdl4.TabIndex = 64
        Me.btnimgdl4.Text = "Download Photo"
        Me.btnimgdl4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl4.UseVisualStyleBackColor = True
        Me.btnimgdl4.Visible = False
        '
        'lblimgid4
        '
        Me.lblimgid4.AutoSize = True
        Me.lblimgid4.Location = New System.Drawing.Point(577, 423)
        Me.lblimgid4.Name = "lblimgid4"
        Me.lblimgid4.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid4.TabIndex = 68
        Me.lblimgid4.Text = "imgid"
        Me.lblimgid4.Visible = False
        '
        'btnimgfull4
        '
        Me.btnimgfull4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull4.Image = CType(resources.GetObject("btnimgfull4.Image"), System.Drawing.Image)
        Me.btnimgfull4.Location = New System.Drawing.Point(617, 375)
        Me.btnimgfull4.Name = "btnimgfull4"
        Me.btnimgfull4.Size = New System.Drawing.Size(208, 30)
        Me.btnimgfull4.TabIndex = 65
        Me.btnimgfull4.Text = "View Larger"
        Me.btnimgfull4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull4.UseVisualStyleBackColor = True
        '
        'imgpanel4
        '
        Me.imgpanel4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.imgpanel4.AutoScroll = True
        Me.imgpanel4.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel4.Location = New System.Drawing.Point(6, 133)
        Me.imgpanel4.Name = "imgpanel4"
        Me.imgpanel4.Size = New System.Drawing.Size(569, 152)
        Me.imgpanel4.TabIndex = 63
        '
        'imgbox4
        '
        Me.imgbox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox4.Location = New System.Drawing.Point(580, 20)
        Me.imgbox4.Name = "imgbox4"
        Me.imgbox4.Size = New System.Drawing.Size(273, 219)
        Me.imgbox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox4.TabIndex = 62
        Me.imgbox4.TabStop = False
        '
        'btnimgremove4
        '
        Me.btnimgremove4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove4.Image = CType(resources.GetObject("btnimgremove4.Image"), System.Drawing.Image)
        Me.btnimgremove4.Location = New System.Drawing.Point(617, 339)
        Me.btnimgremove4.Name = "btnimgremove4"
        Me.btnimgremove4.Size = New System.Drawing.Size(101, 30)
        Me.btnimgremove4.TabIndex = 60
        Me.btnimgremove4.Text = "Remove"
        Me.btnimgremove4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove4.UseVisualStyleBackColor = True
        '
        'btnimgadd4
        '
        Me.btnimgadd4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd4.Image = CType(resources.GetObject("btnimgadd4.Image"), System.Drawing.Image)
        Me.btnimgadd4.Location = New System.Drawing.Point(617, 303)
        Me.btnimgadd4.Name = "btnimgadd4"
        Me.btnimgadd4.Size = New System.Drawing.Size(101, 30)
        Me.btnimgadd4.TabIndex = 58
        Me.btnimgadd4.Text = "Add Photo"
        Me.btnimgadd4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd4.UseVisualStyleBackColor = True
        '
        'btnimgcancel4
        '
        Me.btnimgcancel4.Enabled = False
        Me.btnimgcancel4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel4.Image = CType(resources.GetObject("btnimgcancel4.Image"), System.Drawing.Image)
        Me.btnimgcancel4.Location = New System.Drawing.Point(724, 339)
        Me.btnimgcancel4.Name = "btnimgcancel4"
        Me.btnimgcancel4.Size = New System.Drawing.Size(101, 30)
        Me.btnimgcancel4.TabIndex = 61
        Me.btnimgcancel4.Text = "Cancel"
        Me.btnimgcancel4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel4.UseVisualStyleBackColor = True
        '
        'btnimgrefresh4
        '
        Me.btnimgrefresh4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh4.Image = CType(resources.GetObject("btnimgrefresh4.Image"), System.Drawing.Image)
        Me.btnimgrefresh4.Location = New System.Drawing.Point(617, 411)
        Me.btnimgrefresh4.Name = "btnimgrefresh4"
        Me.btnimgrefresh4.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh4.TabIndex = 66
        Me.btnimgrefresh4.Text = "Refresh Photos"
        Me.btnimgrefresh4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh4.UseVisualStyleBackColor = True
        '
        'btnimgrename4
        '
        Me.btnimgrename4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename4.Image = CType(resources.GetObject("btnimgrename4.Image"), System.Drawing.Image)
        Me.btnimgrename4.Location = New System.Drawing.Point(724, 303)
        Me.btnimgrename4.Name = "btnimgrename4"
        Me.btnimgrename4.Size = New System.Drawing.Size(101, 30)
        Me.btnimgrename4.TabIndex = 59
        Me.btnimgrename4.Text = "Rename"
        Me.btnimgrename4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename4.UseVisualStyleBackColor = True
        '
        'tab5
        '
        Me.tab5.Controls.Add(Me.panelstp5)
        Me.tab5.Location = New System.Drawing.Point(4, 64)
        Me.tab5.Name = "tab5"
        Me.tab5.Padding = New System.Windows.Forms.Padding(3)
        Me.tab5.Size = New System.Drawing.Size(1250, 602)
        Me.tab5.TabIndex = 8
        Me.tab5.Text = "     STEP 5 ( RELEASE PETTY CASH )     "
        Me.tab5.UseVisualStyleBackColor = True
        '
        'panelstp5
        '
        Me.panelstp5.AutoScroll = True
        Me.panelstp5.Controls.Add(Me.gstep5)
        Me.panelstp5.Controls.Add(Me.grp5)
        Me.panelstp5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelstp5.Location = New System.Drawing.Point(3, 3)
        Me.panelstp5.Name = "panelstp5"
        Me.panelstp5.Size = New System.Drawing.Size(1244, 596)
        Me.panelstp5.TabIndex = 3
        '
        'gstep5
        '
        Me.gstep5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gstep5.Controls.Add(Me.lblload5)
        Me.gstep5.Controls.Add(Me.cmbtrans5)
        Me.gstep5.Controls.Add(Me.btnrefstep5)
        Me.gstep5.Controls.Add(Me.grdstep5)
        Me.gstep5.Location = New System.Drawing.Point(5, 10)
        Me.gstep5.Name = "gstep5"
        Me.gstep5.Size = New System.Drawing.Size(379, 582)
        Me.gstep5.TabIndex = 0
        Me.gstep5.TabStop = False
        Me.gstep5.Text = "STEP 5 Trip"
        '
        'lblload5
        '
        Me.lblload5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload5.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload5.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload5.Location = New System.Drawing.Point(7, 53)
        Me.lblload5.Name = "lblload5"
        Me.lblload5.Size = New System.Drawing.Size(365, 470)
        Me.lblload5.TabIndex = 102
        Me.lblload5.Text = "Loading..."
        Me.lblload5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbtrans5
        '
        Me.cmbtrans5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbtrans5.FormattingEnabled = True
        Me.cmbtrans5.Location = New System.Drawing.Point(145, 551)
        Me.cmbtrans5.Name = "cmbtrans5"
        Me.cmbtrans5.Size = New System.Drawing.Size(121, 23)
        Me.cmbtrans5.TabIndex = 73
        Me.cmbtrans5.Visible = False
        '
        'btnrefstep5
        '
        Me.btnrefstep5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefstep5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefstep5.Image = CType(resources.GetObject("btnrefstep5.Image"), System.Drawing.Image)
        Me.btnrefstep5.Location = New System.Drawing.Point(272, 546)
        Me.btnrefstep5.Name = "btnrefstep5"
        Me.btnrefstep5.Size = New System.Drawing.Size(101, 30)
        Me.btnrefstep5.TabIndex = 70
        Me.btnrefstep5.Text = "Refresh List"
        Me.btnrefstep5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefstep5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefstep5.UseVisualStyleBackColor = True
        '
        'grdstep5
        '
        Me.grdstep5.AllowUserToAddRows = False
        Me.grdstep5.AllowUserToDeleteRows = False
        DataGridViewCellStyle35.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdstep5.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle35
        Me.grdstep5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdstep5.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdstep5.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle36.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle36.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle36.NullValue = Nothing
        DataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep5.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle36
        Me.grdstep5.ColumnHeadersHeight = 30
        Me.grdstep5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdstep5.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn73, Me.DataGridViewTextBoxColumn91})
        DataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle38.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep5.DefaultCellStyle = DataGridViewCellStyle38
        Me.grdstep5.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdstep5.EnableHeadersVisualStyles = False
        Me.grdstep5.GridColor = System.Drawing.Color.Salmon
        Me.grdstep5.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdstep5.Location = New System.Drawing.Point(6, 20)
        Me.grdstep5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdstep5.MultiSelect = False
        Me.grdstep5.Name = "grdstep5"
        Me.grdstep5.ReadOnly = True
        Me.grdstep5.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle39.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle39.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle39.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle39.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep5.RowHeadersDefaultCellStyle = DataGridViewCellStyle39
        Me.grdstep5.RowHeadersWidth = 10
        Me.grdstep5.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle40.NullValue = Nothing
        DataGridViewCellStyle40.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep5.RowsDefaultCellStyle = DataGridViewCellStyle40
        Me.grdstep5.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdstep5.Size = New System.Drawing.Size(367, 521)
        Me.grdstep5.TabIndex = 10
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.Frozen = True
        Me.DataGridViewTextBoxColumn17.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        Me.DataGridViewTextBoxColumn17.Visible = False
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.Frozen = True
        Me.DataGridViewTextBoxColumn18.HeaderText = "Trip #"
        Me.DataGridViewTextBoxColumn18.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        Me.DataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn18.Width = 120
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.Frozen = True
        Me.DataGridViewTextBoxColumn19.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn19.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.ReadOnly = True
        Me.DataGridViewTextBoxColumn19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn19.Width = 130
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.HeaderText = "Driver"
        Me.DataGridViewTextBoxColumn20.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.ReadOnly = True
        Me.DataGridViewTextBoxColumn20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn20.Width = 150
        '
        'DataGridViewTextBoxColumn73
        '
        Me.DataGridViewTextBoxColumn73.HeaderText = "Helper"
        Me.DataGridViewTextBoxColumn73.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn73.Name = "DataGridViewTextBoxColumn73"
        Me.DataGridViewTextBoxColumn73.ReadOnly = True
        Me.DataGridViewTextBoxColumn73.Width = 180
        '
        'DataGridViewTextBoxColumn91
        '
        DataGridViewCellStyle37.Format = "yyyy/MM/dd"
        Me.DataGridViewTextBoxColumn91.DefaultCellStyle = DataGridViewCellStyle37
        Me.DataGridViewTextBoxColumn91.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn91.Name = "DataGridViewTextBoxColumn91"
        Me.DataGridViewTextBoxColumn91.ReadOnly = True
        Me.DataGridViewTextBoxColumn91.Visible = False
        '
        'grp5
        '
        Me.grp5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grp5.Controls.Add(Me.lblimgname5)
        Me.grp5.Controls.Add(Me.lblimgdate5)
        Me.grp5.Controls.Add(Me.tripinfo5)
        Me.grp5.Controls.Add(Me.pgbar5)
        Me.grp5.Controls.Add(Me.lblconfirm5)
        Me.grp5.Controls.Add(Me.btnstartcash)
        Me.grp5.Controls.Add(Me.lbltype5)
        Me.grp5.Controls.Add(Me.grdtrans5)
        Me.grp5.Controls.Add(Me.cmbimg5)
        Me.grp5.Controls.Add(Me.txtrems5)
        Me.grp5.Controls.Add(Me.Panel14)
        Me.grp5.Controls.Add(Me.lbltripnum5)
        Me.grp5.Controls.Add(Me.lblplate5)
        Me.grp5.Controls.Add(Me.btnimgdl5)
        Me.grp5.Controls.Add(Me.lblimgid5)
        Me.grp5.Controls.Add(Me.btnimgfull5)
        Me.grp5.Controls.Add(Me.imgpanel5)
        Me.grp5.Controls.Add(Me.imgbox5)
        Me.grp5.Controls.Add(Me.btnimgremove5)
        Me.grp5.Controls.Add(Me.btnimgadd5)
        Me.grp5.Controls.Add(Me.btnimgcancel5)
        Me.grp5.Controls.Add(Me.btnimgrefresh5)
        Me.grp5.Controls.Add(Me.btnimgrename5)
        Me.grp5.Location = New System.Drawing.Point(386, 10)
        Me.grp5.Name = "grp5"
        Me.grp5.Size = New System.Drawing.Size(855, 582)
        Me.grp5.TabIndex = 1
        Me.grp5.TabStop = False
        Me.grp5.Text = "Photos"
        '
        'lblimgname5
        '
        Me.lblimgname5.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgname5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgname5.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgname5.Location = New System.Drawing.Point(723, 271)
        Me.lblimgname5.Name = "lblimgname5"
        Me.lblimgname5.Size = New System.Drawing.Size(129, 20)
        Me.lblimgname5.TabIndex = 111
        Me.lblimgname5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgdate5
        '
        Me.lblimgdate5.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgdate5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgdate5.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgdate5.Location = New System.Drawing.Point(579, 271)
        Me.lblimgdate5.Name = "lblimgdate5"
        Me.lblimgdate5.Size = New System.Drawing.Size(138, 20)
        Me.lblimgdate5.TabIndex = 110
        Me.lblimgdate5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tripinfo5
        '
        Me.tripinfo5.AutoSize = True
        Me.tripinfo5.Location = New System.Drawing.Point(745, 444)
        Me.tripinfo5.Name = "tripinfo5"
        Me.tripinfo5.Size = New System.Drawing.Size(80, 15)
        Me.tripinfo5.TabIndex = 97
        Me.tripinfo5.TabStop = True
        Me.tripinfo5.Text = "View Trip Info"
        '
        'pgbar5
        '
        Me.pgbar5.Location = New System.Drawing.Point(579, 216)
        Me.pgbar5.Name = "pgbar5"
        Me.pgbar5.Size = New System.Drawing.Size(273, 23)
        Me.pgbar5.TabIndex = 89
        Me.pgbar5.Visible = False
        '
        'lblconfirm5
        '
        Me.lblconfirm5.BackColor = System.Drawing.Color.Transparent
        Me.lblconfirm5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblconfirm5.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblconfirm5.Location = New System.Drawing.Point(6, 76)
        Me.lblconfirm5.Name = "lblconfirm5"
        Me.lblconfirm5.Size = New System.Drawing.Size(132, 38)
        Me.lblconfirm5.TabIndex = 83
        Me.lblconfirm5.Text = "0"
        Me.lblconfirm5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblconfirm5.Visible = False
        '
        'btnstartcash
        '
        Me.btnstartcash.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnstartcash.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstartcash.Image = CType(resources.GetObject("btnstartcash.Image"), System.Drawing.Image)
        Me.btnstartcash.Location = New System.Drawing.Point(6, 65)
        Me.btnstartcash.Name = "btnstartcash"
        Me.btnstartcash.Size = New System.Drawing.Size(569, 62)
        Me.btnstartcash.TabIndex = 78
        Me.btnstartcash.Text = "TIME START RELEASE PETTY CASH"
        Me.btnstartcash.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnstartcash.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnstartcash.UseVisualStyleBackColor = False
        '
        'lbltype5
        '
        Me.lbltype5.BackColor = System.Drawing.Color.Transparent
        Me.lbltype5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype5.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltype5.Location = New System.Drawing.Point(360, 22)
        Me.lbltype5.Name = "lbltype5"
        Me.lbltype5.Size = New System.Drawing.Size(215, 38)
        Me.lbltype5.TabIndex = 82
        Me.lbltype5.Text = "TYPE"
        Me.lbltype5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grdtrans5
        '
        Me.grdtrans5.AllowUserToAddRows = False
        Me.grdtrans5.AllowUserToDeleteRows = False
        DataGridViewCellStyle41.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdtrans5.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle41
        Me.grdtrans5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grdtrans5.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdtrans5.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdtrans5.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle42.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle42.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle42.NullValue = Nothing
        DataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans5.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle42
        Me.grdtrans5.ColumnHeadersHeight = 30
        Me.grdtrans5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdtrans5.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn26, Me.DataGridViewTextBoxColumn27, Me.DataGridViewTextBoxColumn28, Me.DataGridViewTextBoxColumn29, Me.DataGridViewTextBoxColumn30, Me.DataGridViewTextBoxColumn31, Me.DataGridViewTextBoxColumn32, Me.DataGridViewTextBoxColumn33, Me.DataGridViewTextBoxColumn34, Me.DataGridViewTextBoxColumn35, Me.DataGridViewTextBoxColumn36})
        DataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle43.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle43.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle43.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle43.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle43.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans5.DefaultCellStyle = DataGridViewCellStyle43
        Me.grdtrans5.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdtrans5.EnableHeadersVisualStyles = False
        Me.grdtrans5.GridColor = System.Drawing.Color.Salmon
        Me.grdtrans5.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdtrans5.Location = New System.Drawing.Point(6, 321)
        Me.grdtrans5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdtrans5.MultiSelect = False
        Me.grdtrans5.Name = "grdtrans5"
        Me.grdtrans5.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle44.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle44.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle44.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans5.RowHeadersDefaultCellStyle = DataGridViewCellStyle44
        Me.grdtrans5.RowHeadersWidth = 10
        Me.grdtrans5.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle45.NullValue = Nothing
        DataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans5.RowsDefaultCellStyle = DataGridViewCellStyle45
        Me.grdtrans5.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrans5.Size = New System.Drawing.Size(569, 173)
        Me.grdtrans5.TabIndex = 77
        '
        'DataGridViewTextBoxColumn26
        '
        Me.DataGridViewTextBoxColumn26.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn26.Name = "DataGridViewTextBoxColumn26"
        Me.DataGridViewTextBoxColumn26.Visible = False
        '
        'DataGridViewTextBoxColumn27
        '
        Me.DataGridViewTextBoxColumn27.ActiveLinkColor = System.Drawing.Color.Black
        Me.DataGridViewTextBoxColumn27.HeaderText = "Transaction #"
        Me.DataGridViewTextBoxColumn27.LinkColor = System.Drawing.Color.Red
        Me.DataGridViewTextBoxColumn27.MinimumWidth = 130
        Me.DataGridViewTextBoxColumn27.Name = "DataGridViewTextBoxColumn27"
        Me.DataGridViewTextBoxColumn27.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn27.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn27.Width = 130
        '
        'DataGridViewTextBoxColumn28
        '
        Me.DataGridViewTextBoxColumn28.HeaderText = "Reference #"
        Me.DataGridViewTextBoxColumn28.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn28.Name = "DataGridViewTextBoxColumn28"
        Me.DataGridViewTextBoxColumn28.Width = 120
        '
        'DataGridViewTextBoxColumn29
        '
        Me.DataGridViewTextBoxColumn29.HeaderText = "Recipient"
        Me.DataGridViewTextBoxColumn29.MinimumWidth = 150
        Me.DataGridViewTextBoxColumn29.Name = "DataGridViewTextBoxColumn29"
        Me.DataGridViewTextBoxColumn29.Width = 150
        '
        'DataGridViewTextBoxColumn30
        '
        Me.DataGridViewTextBoxColumn30.HeaderText = "AR #"
        Me.DataGridViewTextBoxColumn30.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn30.Name = "DataGridViewTextBoxColumn30"
        Me.DataGridViewTextBoxColumn30.Width = 120
        '
        'DataGridViewTextBoxColumn31
        '
        Me.DataGridViewTextBoxColumn31.HeaderText = "RDR"
        Me.DataGridViewTextBoxColumn31.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn31.Name = "DataGridViewTextBoxColumn31"
        Me.DataGridViewTextBoxColumn31.Width = 120
        '
        'DataGridViewTextBoxColumn32
        '
        Me.DataGridViewTextBoxColumn32.HeaderText = "DR#"
        Me.DataGridViewTextBoxColumn32.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn32.Name = "DataGridViewTextBoxColumn32"
        Me.DataGridViewTextBoxColumn32.Width = 120
        '
        'DataGridViewTextBoxColumn33
        '
        Me.DataGridViewTextBoxColumn33.HeaderText = "DN#"
        Me.DataGridViewTextBoxColumn33.Name = "DataGridViewTextBoxColumn33"
        '
        'DataGridViewTextBoxColumn34
        '
        Me.DataGridViewTextBoxColumn34.HeaderText = "ITR#"
        Me.DataGridViewTextBoxColumn34.Name = "DataGridViewTextBoxColumn34"
        '
        'DataGridViewTextBoxColumn35
        '
        Me.DataGridViewTextBoxColumn35.HeaderText = "Transaction Type"
        Me.DataGridViewTextBoxColumn35.MinimumWidth = 150
        Me.DataGridViewTextBoxColumn35.Name = "DataGridViewTextBoxColumn35"
        Me.DataGridViewTextBoxColumn35.Width = 150
        '
        'DataGridViewTextBoxColumn36
        '
        Me.DataGridViewTextBoxColumn36.HeaderText = "Notes"
        Me.DataGridViewTextBoxColumn36.MinimumWidth = 200
        Me.DataGridViewTextBoxColumn36.Name = "DataGridViewTextBoxColumn36"
        Me.DataGridViewTextBoxColumn36.Width = 200
        '
        'cmbimg5
        '
        Me.cmbimg5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbimg5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbimg5.FormattingEnabled = True
        Me.cmbimg5.Items.AddRange(New Object() {"", "Petty Cash Voucher"})
        Me.cmbimg5.Location = New System.Drawing.Point(579, 245)
        Me.cmbimg5.Name = "cmbimg5"
        Me.cmbimg5.Size = New System.Drawing.Size(273, 23)
        Me.cmbimg5.TabIndex = 73
        '
        'txtrems5
        '
        Me.txtrems5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtrems5.Location = New System.Drawing.Point(6, 499)
        Me.txtrems5.Multiline = True
        Me.txtrems5.Name = "txtrems5"
        Me.txtrems5.Size = New System.Drawing.Size(569, 71)
        Me.txtrems5.TabIndex = 72
        '
        'Panel14
        '
        Me.Panel14.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel14.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel14.Controls.Add(Me.btnexempt5)
        Me.Panel14.Controls.Add(Me.btnconfirm5)
        Me.Panel14.Location = New System.Drawing.Point(579, 499)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(273, 71)
        Me.Panel14.TabIndex = 71
        '
        'btnexempt5
        '
        Me.btnexempt5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnexempt5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexempt5.Image = CType(resources.GetObject("btnexempt5.Image"), System.Drawing.Image)
        Me.btnexempt5.Location = New System.Drawing.Point(139, 3)
        Me.btnexempt5.Name = "btnexempt5"
        Me.btnexempt5.Size = New System.Drawing.Size(130, 62)
        Me.btnexempt5.TabIndex = 73
        Me.btnexempt5.Text = "SAVE AS DRAFT"
        Me.btnexempt5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnexempt5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnexempt5.UseVisualStyleBackColor = True
        '
        'btnconfirm5
        '
        Me.btnconfirm5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnconfirm5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirm5.Image = CType(resources.GetObject("btnconfirm5.Image"), System.Drawing.Image)
        Me.btnconfirm5.Location = New System.Drawing.Point(3, 3)
        Me.btnconfirm5.Name = "btnconfirm5"
        Me.btnconfirm5.Size = New System.Drawing.Size(130, 62)
        Me.btnconfirm5.TabIndex = 72
        Me.btnconfirm5.Text = "CONFIRM"
        Me.btnconfirm5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnconfirm5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnconfirm5.UseVisualStyleBackColor = True
        '
        'lbltripnum5
        '
        Me.lbltripnum5.BackColor = System.Drawing.Color.Transparent
        Me.lbltripnum5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltripnum5.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltripnum5.Location = New System.Drawing.Point(6, 22)
        Me.lbltripnum5.Name = "lbltripnum5"
        Me.lbltripnum5.Size = New System.Drawing.Size(129, 38)
        Me.lbltripnum5.TabIndex = 70
        Me.lbltripnum5.Text = "Trip#"
        Me.lbltripnum5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbltripnum5.Visible = False
        '
        'lblplate5
        '
        Me.lblplate5.BackColor = System.Drawing.Color.Transparent
        Me.lblplate5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate5.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate5.Location = New System.Drawing.Point(6, 22)
        Me.lblplate5.Name = "lblplate5"
        Me.lblplate5.Size = New System.Drawing.Size(360, 38)
        Me.lblplate5.TabIndex = 69
        Me.lblplate5.Text = "Plate #"
        Me.lblplate5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnimgdl5
        '
        Me.btnimgdl5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl5.Image = CType(resources.GetObject("btnimgdl5.Image"), System.Drawing.Image)
        Me.btnimgdl5.Location = New System.Drawing.Point(590, 447)
        Me.btnimgdl5.Name = "btnimgdl5"
        Me.btnimgdl5.Size = New System.Drawing.Size(25, 30)
        Me.btnimgdl5.TabIndex = 64
        Me.btnimgdl5.Text = "Download Photo"
        Me.btnimgdl5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl5.UseVisualStyleBackColor = True
        Me.btnimgdl5.Visible = False
        '
        'lblimgid5
        '
        Me.lblimgid5.AutoSize = True
        Me.lblimgid5.Location = New System.Drawing.Point(577, 423)
        Me.lblimgid5.Name = "lblimgid5"
        Me.lblimgid5.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid5.TabIndex = 68
        Me.lblimgid5.Text = "imgid"
        Me.lblimgid5.Visible = False
        '
        'btnimgfull5
        '
        Me.btnimgfull5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull5.Image = CType(resources.GetObject("btnimgfull5.Image"), System.Drawing.Image)
        Me.btnimgfull5.Location = New System.Drawing.Point(617, 375)
        Me.btnimgfull5.Name = "btnimgfull5"
        Me.btnimgfull5.Size = New System.Drawing.Size(208, 30)
        Me.btnimgfull5.TabIndex = 65
        Me.btnimgfull5.Text = "View Larger"
        Me.btnimgfull5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull5.UseVisualStyleBackColor = True
        '
        'imgpanel5
        '
        Me.imgpanel5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.imgpanel5.AutoScroll = True
        Me.imgpanel5.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel5.Location = New System.Drawing.Point(6, 133)
        Me.imgpanel5.Name = "imgpanel5"
        Me.imgpanel5.Size = New System.Drawing.Size(569, 183)
        Me.imgpanel5.TabIndex = 63
        '
        'imgbox5
        '
        Me.imgbox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox5.Location = New System.Drawing.Point(579, 20)
        Me.imgbox5.Name = "imgbox5"
        Me.imgbox5.Size = New System.Drawing.Size(273, 219)
        Me.imgbox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox5.TabIndex = 62
        Me.imgbox5.TabStop = False
        '
        'btnimgremove5
        '
        Me.btnimgremove5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove5.Image = CType(resources.GetObject("btnimgremove5.Image"), System.Drawing.Image)
        Me.btnimgremove5.Location = New System.Drawing.Point(617, 339)
        Me.btnimgremove5.Name = "btnimgremove5"
        Me.btnimgremove5.Size = New System.Drawing.Size(101, 30)
        Me.btnimgremove5.TabIndex = 60
        Me.btnimgremove5.Text = "Remove"
        Me.btnimgremove5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove5.UseVisualStyleBackColor = True
        '
        'btnimgadd5
        '
        Me.btnimgadd5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd5.Image = CType(resources.GetObject("btnimgadd5.Image"), System.Drawing.Image)
        Me.btnimgadd5.Location = New System.Drawing.Point(617, 303)
        Me.btnimgadd5.Name = "btnimgadd5"
        Me.btnimgadd5.Size = New System.Drawing.Size(101, 30)
        Me.btnimgadd5.TabIndex = 58
        Me.btnimgadd5.Text = "Add Photo"
        Me.btnimgadd5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd5.UseVisualStyleBackColor = True
        '
        'btnimgcancel5
        '
        Me.btnimgcancel5.Enabled = False
        Me.btnimgcancel5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel5.Image = CType(resources.GetObject("btnimgcancel5.Image"), System.Drawing.Image)
        Me.btnimgcancel5.Location = New System.Drawing.Point(724, 339)
        Me.btnimgcancel5.Name = "btnimgcancel5"
        Me.btnimgcancel5.Size = New System.Drawing.Size(101, 30)
        Me.btnimgcancel5.TabIndex = 61
        Me.btnimgcancel5.Text = "Cancel"
        Me.btnimgcancel5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel5.UseVisualStyleBackColor = True
        '
        'btnimgrefresh5
        '
        Me.btnimgrefresh5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh5.Image = CType(resources.GetObject("btnimgrefresh5.Image"), System.Drawing.Image)
        Me.btnimgrefresh5.Location = New System.Drawing.Point(617, 411)
        Me.btnimgrefresh5.Name = "btnimgrefresh5"
        Me.btnimgrefresh5.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh5.TabIndex = 66
        Me.btnimgrefresh5.Text = "Refresh Photos"
        Me.btnimgrefresh5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh5.UseVisualStyleBackColor = True
        '
        'btnimgrename5
        '
        Me.btnimgrename5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename5.Image = CType(resources.GetObject("btnimgrename5.Image"), System.Drawing.Image)
        Me.btnimgrename5.Location = New System.Drawing.Point(724, 303)
        Me.btnimgrename5.Name = "btnimgrename5"
        Me.btnimgrename5.Size = New System.Drawing.Size(101, 30)
        Me.btnimgrename5.TabIndex = 59
        Me.btnimgrename5.Text = "Rename"
        Me.btnimgrename5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename5.UseVisualStyleBackColor = True
        '
        'tab6
        '
        Me.tab6.Controls.Add(Me.panelstp6)
        Me.tab6.Location = New System.Drawing.Point(4, 64)
        Me.tab6.Name = "tab6"
        Me.tab6.Size = New System.Drawing.Size(1250, 602)
        Me.tab6.TabIndex = 9
        Me.tab6.Text = "     STEP 6 ( GUARD EXIT / RETURN )     "
        Me.tab6.UseVisualStyleBackColor = True
        '
        'panelstp6
        '
        Me.panelstp6.AutoScroll = True
        Me.panelstp6.Controls.Add(Me.gstep6)
        Me.panelstp6.Controls.Add(Me.grp6)
        Me.panelstp6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelstp6.Location = New System.Drawing.Point(0, 0)
        Me.panelstp6.Name = "panelstp6"
        Me.panelstp6.Size = New System.Drawing.Size(1250, 602)
        Me.panelstp6.TabIndex = 3
        '
        'gstep6
        '
        Me.gstep6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gstep6.Controls.Add(Me.lblload6)
        Me.gstep6.Controls.Add(Me.cmbtrans6)
        Me.gstep6.Controls.Add(Me.btnrefstep6)
        Me.gstep6.Controls.Add(Me.grdstep6)
        Me.gstep6.Location = New System.Drawing.Point(6, 10)
        Me.gstep6.Name = "gstep6"
        Me.gstep6.Size = New System.Drawing.Size(379, 582)
        Me.gstep6.TabIndex = 0
        Me.gstep6.TabStop = False
        Me.gstep6.Text = "STEP 6 Trip"
        '
        'lblload6
        '
        Me.lblload6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload6.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload6.Location = New System.Drawing.Point(7, 52)
        Me.lblload6.Name = "lblload6"
        Me.lblload6.Size = New System.Drawing.Size(365, 489)
        Me.lblload6.TabIndex = 103
        Me.lblload6.Text = "Loading..."
        Me.lblload6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbtrans6
        '
        Me.cmbtrans6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbtrans6.FormattingEnabled = True
        Me.cmbtrans6.Location = New System.Drawing.Point(145, 550)
        Me.cmbtrans6.Name = "cmbtrans6"
        Me.cmbtrans6.Size = New System.Drawing.Size(121, 23)
        Me.cmbtrans6.TabIndex = 74
        Me.cmbtrans6.Visible = False
        '
        'btnrefstep6
        '
        Me.btnrefstep6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefstep6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefstep6.Image = CType(resources.GetObject("btnrefstep6.Image"), System.Drawing.Image)
        Me.btnrefstep6.Location = New System.Drawing.Point(272, 546)
        Me.btnrefstep6.Name = "btnrefstep6"
        Me.btnrefstep6.Size = New System.Drawing.Size(101, 30)
        Me.btnrefstep6.TabIndex = 70
        Me.btnrefstep6.Text = "Refresh List"
        Me.btnrefstep6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefstep6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefstep6.UseVisualStyleBackColor = True
        '
        'grdstep6
        '
        Me.grdstep6.AllowUserToAddRows = False
        Me.grdstep6.AllowUserToDeleteRows = False
        DataGridViewCellStyle46.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdstep6.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle46
        Me.grdstep6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdstep6.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdstep6.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle47.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle47.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle47.NullValue = Nothing
        DataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep6.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle47
        Me.grdstep6.ColumnHeadersHeight = 30
        Me.grdstep6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdstep6.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn21, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23, Me.DataGridViewTextBoxColumn24, Me.DataGridViewTextBoxColumn74, Me.DataGridViewTextBoxColumn92, Me.Column23})
        DataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle49.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle49.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle49.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle49.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle49.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep6.DefaultCellStyle = DataGridViewCellStyle49
        Me.grdstep6.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdstep6.EnableHeadersVisualStyles = False
        Me.grdstep6.GridColor = System.Drawing.Color.Salmon
        Me.grdstep6.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdstep6.Location = New System.Drawing.Point(6, 20)
        Me.grdstep6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdstep6.MultiSelect = False
        Me.grdstep6.Name = "grdstep6"
        Me.grdstep6.ReadOnly = True
        Me.grdstep6.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle50.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle50.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle50.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle50.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle50.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle50.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep6.RowHeadersDefaultCellStyle = DataGridViewCellStyle50
        Me.grdstep6.RowHeadersWidth = 10
        Me.grdstep6.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle51.NullValue = Nothing
        DataGridViewCellStyle51.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep6.RowsDefaultCellStyle = DataGridViewCellStyle51
        Me.grdstep6.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdstep6.Size = New System.Drawing.Size(367, 521)
        Me.grdstep6.TabIndex = 10
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.Frozen = True
        Me.DataGridViewTextBoxColumn21.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.ReadOnly = True
        Me.DataGridViewTextBoxColumn21.Visible = False
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.Frozen = True
        Me.DataGridViewTextBoxColumn22.HeaderText = "Trip #"
        Me.DataGridViewTextBoxColumn22.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.ReadOnly = True
        Me.DataGridViewTextBoxColumn22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn22.Width = 120
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.Frozen = True
        Me.DataGridViewTextBoxColumn23.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn23.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.ReadOnly = True
        Me.DataGridViewTextBoxColumn23.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn23.Width = 130
        '
        'DataGridViewTextBoxColumn24
        '
        Me.DataGridViewTextBoxColumn24.HeaderText = "Driver"
        Me.DataGridViewTextBoxColumn24.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn24.Name = "DataGridViewTextBoxColumn24"
        Me.DataGridViewTextBoxColumn24.ReadOnly = True
        Me.DataGridViewTextBoxColumn24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn24.Width = 150
        '
        'DataGridViewTextBoxColumn74
        '
        Me.DataGridViewTextBoxColumn74.HeaderText = "Helper"
        Me.DataGridViewTextBoxColumn74.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn74.Name = "DataGridViewTextBoxColumn74"
        Me.DataGridViewTextBoxColumn74.ReadOnly = True
        Me.DataGridViewTextBoxColumn74.Width = 180
        '
        'DataGridViewTextBoxColumn92
        '
        DataGridViewCellStyle48.Format = "yyyy/MM/dd"
        Me.DataGridViewTextBoxColumn92.DefaultCellStyle = DataGridViewCellStyle48
        Me.DataGridViewTextBoxColumn92.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn92.Name = "DataGridViewTextBoxColumn92"
        Me.DataGridViewTextBoxColumn92.ReadOnly = True
        Me.DataGridViewTextBoxColumn92.Visible = False
        '
        'Column23
        '
        Me.Column23.HeaderText = "timedep"
        Me.Column23.Name = "Column23"
        Me.Column23.ReadOnly = True
        Me.Column23.Visible = False
        '
        'grp6
        '
        Me.grp6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grp6.Controls.Add(Me.lblpup6)
        Me.grp6.Controls.Add(Me.pgbar6)
        Me.grp6.Controls.Add(Me.lblconfirm6)
        Me.grp6.Controls.Add(Me.txtcustomer)
        Me.grp6.Controls.Add(Me.btndepart)
        Me.grp6.Controls.Add(Me.lbltype6)
        Me.grp6.Controls.Add(Me.txtetd)
        Me.grp6.Controls.Add(Me.cmbimg6)
        Me.grp6.Controls.Add(Me.txtrems6)
        Me.grp6.Controls.Add(Me.Panel17)
        Me.grp6.Controls.Add(Me.lbltripnum6)
        Me.grp6.Controls.Add(Me.lblplate6)
        Me.grp6.Controls.Add(Me.btnimgdl6)
        Me.grp6.Controls.Add(Me.lblimgid6)
        Me.grp6.Controls.Add(Me.btnimgfull6)
        Me.grp6.Controls.Add(Me.imgpanel6)
        Me.grp6.Controls.Add(Me.imgbox6)
        Me.grp6.Controls.Add(Me.btnimgremove6)
        Me.grp6.Controls.Add(Me.btnimgadd6)
        Me.grp6.Controls.Add(Me.btnimgcancel6)
        Me.grp6.Controls.Add(Me.btnimgrefresh6)
        Me.grp6.Controls.Add(Me.btnimgrename6)
        Me.grp6.Location = New System.Drawing.Point(388, 10)
        Me.grp6.Name = "grp6"
        Me.grp6.Size = New System.Drawing.Size(860, 582)
        Me.grp6.TabIndex = 1
        Me.grp6.TabStop = False
        Me.grp6.Text = "Photos"
        '
        'lblpup6
        '
        Me.lblpup6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpup6.BackColor = System.Drawing.Color.Transparent
        Me.lblpup6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblpup6.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpup6.Location = New System.Drawing.Point(489, 76)
        Me.lblpup6.Name = "lblpup6"
        Me.lblpup6.Size = New System.Drawing.Size(85, 38)
        Me.lblpup6.TabIndex = 91
        Me.lblpup6.Text = "0"
        Me.lblpup6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblpup6.Visible = False
        '
        'pgbar6
        '
        Me.pgbar6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pgbar6.Location = New System.Drawing.Point(580, 155)
        Me.pgbar6.Name = "pgbar6"
        Me.pgbar6.Size = New System.Drawing.Size(273, 23)
        Me.pgbar6.TabIndex = 90
        Me.pgbar6.Visible = False
        '
        'lblconfirm6
        '
        Me.lblconfirm6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblconfirm6.BackColor = System.Drawing.Color.Transparent
        Me.lblconfirm6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblconfirm6.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblconfirm6.Location = New System.Drawing.Point(6, 76)
        Me.lblconfirm6.Name = "lblconfirm6"
        Me.lblconfirm6.Size = New System.Drawing.Size(85, 38)
        Me.lblconfirm6.TabIndex = 86
        Me.lblconfirm6.Text = "0"
        Me.lblconfirm6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblconfirm6.Visible = False
        '
        'txtcustomer
        '
        Me.txtcustomer.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtcustomer.BackColor = System.Drawing.Color.White
        Me.txtcustomer.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtcustomer.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcustomer.Location = New System.Drawing.Point(6, 154)
        Me.txtcustomer.Name = "txtcustomer"
        Me.txtcustomer.ReadOnly = True
        Me.txtcustomer.Size = New System.Drawing.Size(569, 15)
        Me.txtcustomer.TabIndex = 85
        Me.txtcustomer.Text = "CUSTOMER"
        Me.txtcustomer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btndepart
        '
        Me.btndepart.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btndepart.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btndepart.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndepart.Image = CType(resources.GetObject("btndepart.Image"), System.Drawing.Image)
        Me.btndepart.Location = New System.Drawing.Point(6, 65)
        Me.btndepart.Name = "btndepart"
        Me.btndepart.Size = New System.Drawing.Size(569, 62)
        Me.btndepart.TabIndex = 83
        Me.btndepart.Text = "TIME DEPARTURE TRUCK EXIT WHSE"
        Me.btndepart.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btndepart.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btndepart.UseVisualStyleBackColor = False
        '
        'lbltype6
        '
        Me.lbltype6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbltype6.BackColor = System.Drawing.Color.Transparent
        Me.lbltype6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype6.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltype6.Location = New System.Drawing.Point(360, 22)
        Me.lbltype6.Name = "lbltype6"
        Me.lbltype6.Size = New System.Drawing.Size(215, 38)
        Me.lbltype6.TabIndex = 84
        Me.lbltype6.Text = "TYPE"
        Me.lbltype6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtetd
        '
        Me.txtetd.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtetd.BackColor = System.Drawing.Color.White
        Me.txtetd.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtetd.Location = New System.Drawing.Point(6, 134)
        Me.txtetd.Name = "txtetd"
        Me.txtetd.ReadOnly = True
        Me.txtetd.Size = New System.Drawing.Size(569, 14)
        Me.txtetd.TabIndex = 82
        Me.txtetd.Text = "ETD:"
        '
        'cmbimg6
        '
        Me.cmbimg6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbimg6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbimg6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbimg6.FormattingEnabled = True
        Me.cmbimg6.Items.AddRange(New Object() {"", "Time of Departure", "Time of Arrival"})
        Me.cmbimg6.Location = New System.Drawing.Point(580, 184)
        Me.cmbimg6.Name = "cmbimg6"
        Me.cmbimg6.Size = New System.Drawing.Size(273, 23)
        Me.cmbimg6.TabIndex = 73
        '
        'txtrems6
        '
        Me.txtrems6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtrems6.Location = New System.Drawing.Point(6, 481)
        Me.txtrems6.Multiline = True
        Me.txtrems6.Name = "txtrems6"
        Me.txtrems6.Size = New System.Drawing.Size(569, 91)
        Me.txtrems6.TabIndex = 72
        '
        'Panel17
        '
        Me.Panel17.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel17.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel17.Controls.Add(Me.btnexempt6)
        Me.Panel17.Controls.Add(Me.btnmtc)
        Me.Panel17.Controls.Add(Me.btnother6)
        Me.Panel17.Controls.Add(Me.btnconfirm6)
        Me.Panel17.Location = New System.Drawing.Point(580, 407)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(273, 165)
        Me.Panel17.TabIndex = 71
        '
        'btnexempt6
        '
        Me.btnexempt6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnexempt6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexempt6.Image = CType(resources.GetObject("btnexempt6.Image"), System.Drawing.Image)
        Me.btnexempt6.Location = New System.Drawing.Point(139, 120)
        Me.btnexempt6.Name = "btnexempt6"
        Me.btnexempt6.Size = New System.Drawing.Size(130, 42)
        Me.btnexempt6.TabIndex = 75
        Me.btnexempt6.Text = "SAVE AS DRAFT"
        Me.btnexempt6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnexempt6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnexempt6.UseVisualStyleBackColor = True
        '
        'btnmtc
        '
        Me.btnmtc.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnmtc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmtc.Image = CType(resources.GetObject("btnmtc.Image"), System.Drawing.Image)
        Me.btnmtc.Location = New System.Drawing.Point(139, 70)
        Me.btnmtc.Name = "btnmtc"
        Me.btnmtc.Size = New System.Drawing.Size(130, 45)
        Me.btnmtc.TabIndex = 74
        Me.btnmtc.Text = "CONFIRM MTC"
        Me.btnmtc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnmtc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnmtc.UseVisualStyleBackColor = True
        '
        'btnother6
        '
        Me.btnother6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnother6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnother6.Image = CType(resources.GetObject("btnother6.Image"), System.Drawing.Image)
        Me.btnother6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnother6.Location = New System.Drawing.Point(139, 3)
        Me.btnother6.Name = "btnother6"
        Me.btnother6.Size = New System.Drawing.Size(130, 62)
        Me.btnother6.TabIndex = 73
        Me.btnother6.Text = "CONFIRM ARRIVAL TO OTHER WHSE"
        Me.btnother6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnother6.UseVisualStyleBackColor = True
        '
        'btnconfirm6
        '
        Me.btnconfirm6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnconfirm6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirm6.Image = CType(resources.GetObject("btnconfirm6.Image"), System.Drawing.Image)
        Me.btnconfirm6.Location = New System.Drawing.Point(3, 3)
        Me.btnconfirm6.Name = "btnconfirm6"
        Me.btnconfirm6.Size = New System.Drawing.Size(130, 159)
        Me.btnconfirm6.TabIndex = 72
        Me.btnconfirm6.Text = "CONFIRM ARRIVAL"
        Me.btnconfirm6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnconfirm6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnconfirm6.UseVisualStyleBackColor = True
        '
        'lbltripnum6
        '
        Me.lbltripnum6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbltripnum6.BackColor = System.Drawing.Color.Transparent
        Me.lbltripnum6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltripnum6.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltripnum6.Location = New System.Drawing.Point(6, 22)
        Me.lbltripnum6.Name = "lbltripnum6"
        Me.lbltripnum6.Size = New System.Drawing.Size(74, 38)
        Me.lbltripnum6.TabIndex = 70
        Me.lbltripnum6.Text = "Trip#"
        Me.lbltripnum6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbltripnum6.Visible = False
        '
        'lblplate6
        '
        Me.lblplate6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblplate6.BackColor = System.Drawing.Color.Transparent
        Me.lblplate6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate6.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate6.Location = New System.Drawing.Point(6, 22)
        Me.lblplate6.Name = "lblplate6"
        Me.lblplate6.Size = New System.Drawing.Size(360, 38)
        Me.lblplate6.TabIndex = 69
        Me.lblplate6.Text = "Plate #"
        Me.lblplate6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnimgdl6
        '
        Me.btnimgdl6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgdl6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl6.Image = CType(resources.GetObject("btnimgdl6.Image"), System.Drawing.Image)
        Me.btnimgdl6.Location = New System.Drawing.Point(830, 325)
        Me.btnimgdl6.Name = "btnimgdl6"
        Me.btnimgdl6.Size = New System.Drawing.Size(23, 26)
        Me.btnimgdl6.TabIndex = 64
        Me.btnimgdl6.Text = "Download Photo"
        Me.btnimgdl6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl6.UseVisualStyleBackColor = True
        Me.btnimgdl6.Visible = False
        '
        'lblimgid6
        '
        Me.lblimgid6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblimgid6.AutoSize = True
        Me.lblimgid6.Location = New System.Drawing.Point(577, 333)
        Me.lblimgid6.Name = "lblimgid6"
        Me.lblimgid6.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid6.TabIndex = 68
        Me.lblimgid6.Text = "imgid"
        Me.lblimgid6.Visible = False
        '
        'btnimgfull6
        '
        Me.btnimgfull6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgfull6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull6.Image = CType(resources.GetObject("btnimgfull6.Image"), System.Drawing.Image)
        Me.btnimgfull6.Location = New System.Drawing.Point(617, 285)
        Me.btnimgfull6.Name = "btnimgfull6"
        Me.btnimgfull6.Size = New System.Drawing.Size(208, 30)
        Me.btnimgfull6.TabIndex = 65
        Me.btnimgfull6.Text = "View Larger"
        Me.btnimgfull6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull6.UseVisualStyleBackColor = True
        '
        'imgpanel6
        '
        Me.imgpanel6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.imgpanel6.AutoScroll = True
        Me.imgpanel6.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel6.Location = New System.Drawing.Point(6, 175)
        Me.imgpanel6.Name = "imgpanel6"
        Me.imgpanel6.Size = New System.Drawing.Size(569, 300)
        Me.imgpanel6.TabIndex = 63
        '
        'imgbox6
        '
        Me.imgbox6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.imgbox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox6.Location = New System.Drawing.Point(580, 20)
        Me.imgbox6.Name = "imgbox6"
        Me.imgbox6.Size = New System.Drawing.Size(273, 158)
        Me.imgbox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox6.TabIndex = 62
        Me.imgbox6.TabStop = False
        '
        'btnimgremove6
        '
        Me.btnimgremove6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgremove6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove6.Image = CType(resources.GetObject("btnimgremove6.Image"), System.Drawing.Image)
        Me.btnimgremove6.Location = New System.Drawing.Point(617, 249)
        Me.btnimgremove6.Name = "btnimgremove6"
        Me.btnimgremove6.Size = New System.Drawing.Size(101, 30)
        Me.btnimgremove6.TabIndex = 60
        Me.btnimgremove6.Text = "Remove"
        Me.btnimgremove6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove6.UseVisualStyleBackColor = True
        '
        'btnimgadd6
        '
        Me.btnimgadd6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgadd6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd6.Image = CType(resources.GetObject("btnimgadd6.Image"), System.Drawing.Image)
        Me.btnimgadd6.Location = New System.Drawing.Point(617, 213)
        Me.btnimgadd6.Name = "btnimgadd6"
        Me.btnimgadd6.Size = New System.Drawing.Size(101, 30)
        Me.btnimgadd6.TabIndex = 58
        Me.btnimgadd6.Text = "Add Photo"
        Me.btnimgadd6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd6.UseVisualStyleBackColor = True
        '
        'btnimgcancel6
        '
        Me.btnimgcancel6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgcancel6.Enabled = False
        Me.btnimgcancel6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel6.Image = CType(resources.GetObject("btnimgcancel6.Image"), System.Drawing.Image)
        Me.btnimgcancel6.Location = New System.Drawing.Point(724, 249)
        Me.btnimgcancel6.Name = "btnimgcancel6"
        Me.btnimgcancel6.Size = New System.Drawing.Size(101, 30)
        Me.btnimgcancel6.TabIndex = 61
        Me.btnimgcancel6.Text = "Cancel"
        Me.btnimgcancel6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel6.UseVisualStyleBackColor = True
        '
        'btnimgrefresh6
        '
        Me.btnimgrefresh6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgrefresh6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh6.Image = CType(resources.GetObject("btnimgrefresh6.Image"), System.Drawing.Image)
        Me.btnimgrefresh6.Location = New System.Drawing.Point(617, 321)
        Me.btnimgrefresh6.Name = "btnimgrefresh6"
        Me.btnimgrefresh6.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh6.TabIndex = 66
        Me.btnimgrefresh6.Text = "Refresh Photos"
        Me.btnimgrefresh6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh6.UseVisualStyleBackColor = True
        '
        'btnimgrename6
        '
        Me.btnimgrename6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgrename6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename6.Image = CType(resources.GetObject("btnimgrename6.Image"), System.Drawing.Image)
        Me.btnimgrename6.Location = New System.Drawing.Point(724, 213)
        Me.btnimgrename6.Name = "btnimgrename6"
        Me.btnimgrename6.Size = New System.Drawing.Size(101, 30)
        Me.btnimgrename6.TabIndex = 59
        Me.btnimgrename6.Text = "Rename"
        Me.btnimgrename6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename6.UseVisualStyleBackColor = True
        '
        'tab7
        '
        Me.tab7.Controls.Add(Me.panelstp7)
        Me.tab7.Location = New System.Drawing.Point(4, 64)
        Me.tab7.Name = "tab7"
        Me.tab7.Size = New System.Drawing.Size(1250, 602)
        Me.tab7.TabIndex = 10
        Me.tab7.Text = "     STEP 7 ( RETURN OF DOCUMENTS )     "
        Me.tab7.UseVisualStyleBackColor = True
        '
        'panelstp7
        '
        Me.panelstp7.AutoScroll = True
        Me.panelstp7.Controls.Add(Me.gstep7)
        Me.panelstp7.Controls.Add(Me.grp7)
        Me.panelstp7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelstp7.Location = New System.Drawing.Point(0, 0)
        Me.panelstp7.Name = "panelstp7"
        Me.panelstp7.Size = New System.Drawing.Size(1250, 602)
        Me.panelstp7.TabIndex = 4
        '
        'gstep7
        '
        Me.gstep7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gstep7.Controls.Add(Me.lbls7)
        Me.gstep7.Controls.Add(Me.btntrip7)
        Me.gstep7.Controls.Add(Me.txts7)
        Me.gstep7.Controls.Add(Me.lblload7)
        Me.gstep7.Controls.Add(Me.cmbtrans7)
        Me.gstep7.Controls.Add(Me.btnrefstep7)
        Me.gstep7.Controls.Add(Me.grdstep7)
        Me.gstep7.Location = New System.Drawing.Point(6, 10)
        Me.gstep7.Name = "gstep7"
        Me.gstep7.Size = New System.Drawing.Size(379, 582)
        Me.gstep7.TabIndex = 0
        Me.gstep7.TabStop = False
        Me.gstep7.Text = "STEP 7 Trip"
        '
        'lbls7
        '
        Me.lbls7.Location = New System.Drawing.Point(31, 18)
        Me.lbls7.Name = "lbls7"
        Me.lbls7.Size = New System.Drawing.Size(99, 18)
        Me.lbls7.TabIndex = 110
        Me.lbls7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btntrip7
        '
        Me.btntrip7.Image = CType(resources.GetObject("btntrip7.Image"), System.Drawing.Image)
        Me.btntrip7.Location = New System.Drawing.Point(261, 16)
        Me.btntrip7.Name = "btntrip7"
        Me.btntrip7.Size = New System.Drawing.Size(112, 23)
        Me.btntrip7.TabIndex = 109
        Me.btntrip7.Text = "Search Trip#"
        Me.btntrip7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btntrip7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btntrip7.UseVisualStyleBackColor = True
        '
        'txts7
        '
        Me.txts7.Location = New System.Drawing.Point(136, 17)
        Me.txts7.Name = "txts7"
        Me.txts7.Size = New System.Drawing.Size(121, 21)
        Me.txts7.TabIndex = 108
        '
        'lblload7
        '
        Me.lblload7.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload7.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload7.Location = New System.Drawing.Point(7, 76)
        Me.lblload7.Name = "lblload7"
        Me.lblload7.Size = New System.Drawing.Size(365, 465)
        Me.lblload7.TabIndex = 104
        Me.lblload7.Text = "Loading..."
        Me.lblload7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbtrans7
        '
        Me.cmbtrans7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbtrans7.FormattingEnabled = True
        Me.cmbtrans7.Location = New System.Drawing.Point(145, 551)
        Me.cmbtrans7.Name = "cmbtrans7"
        Me.cmbtrans7.Size = New System.Drawing.Size(121, 23)
        Me.cmbtrans7.TabIndex = 72
        Me.cmbtrans7.Visible = False
        '
        'btnrefstep7
        '
        Me.btnrefstep7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefstep7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefstep7.Image = CType(resources.GetObject("btnrefstep7.Image"), System.Drawing.Image)
        Me.btnrefstep7.Location = New System.Drawing.Point(272, 546)
        Me.btnrefstep7.Name = "btnrefstep7"
        Me.btnrefstep7.Size = New System.Drawing.Size(101, 30)
        Me.btnrefstep7.TabIndex = 70
        Me.btnrefstep7.Text = "Refresh List"
        Me.btnrefstep7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefstep7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefstep7.UseVisualStyleBackColor = True
        '
        'grdstep7
        '
        Me.grdstep7.AllowUserToAddRows = False
        Me.grdstep7.AllowUserToDeleteRows = False
        DataGridViewCellStyle52.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdstep7.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle52
        Me.grdstep7.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdstep7.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdstep7.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle53.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle53.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle53.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle53.NullValue = Nothing
        DataGridViewCellStyle53.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle53.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle53.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep7.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle53
        Me.grdstep7.ColumnHeadersHeight = 30
        Me.grdstep7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdstep7.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn37, Me.DataGridViewTextBoxColumn38, Me.DataGridViewTextBoxColumn39, Me.DataGridViewTextBoxColumn40, Me.DataGridViewTextBoxColumn75, Me.DataGridViewTextBoxColumn93})
        DataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle55.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle55.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle55.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle55.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle55.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle55.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep7.DefaultCellStyle = DataGridViewCellStyle55
        Me.grdstep7.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdstep7.EnableHeadersVisualStyles = False
        Me.grdstep7.GridColor = System.Drawing.Color.Salmon
        Me.grdstep7.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdstep7.Location = New System.Drawing.Point(6, 44)
        Me.grdstep7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdstep7.MultiSelect = False
        Me.grdstep7.Name = "grdstep7"
        Me.grdstep7.ReadOnly = True
        Me.grdstep7.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle56.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle56.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle56.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle56.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle56.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle56.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep7.RowHeadersDefaultCellStyle = DataGridViewCellStyle56
        Me.grdstep7.RowHeadersWidth = 10
        Me.grdstep7.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle57.NullValue = Nothing
        DataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep7.RowsDefaultCellStyle = DataGridViewCellStyle57
        Me.grdstep7.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdstep7.Size = New System.Drawing.Size(367, 497)
        Me.grdstep7.TabIndex = 10
        '
        'DataGridViewTextBoxColumn37
        '
        Me.DataGridViewTextBoxColumn37.Frozen = True
        Me.DataGridViewTextBoxColumn37.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn37.Name = "DataGridViewTextBoxColumn37"
        Me.DataGridViewTextBoxColumn37.ReadOnly = True
        Me.DataGridViewTextBoxColumn37.Visible = False
        '
        'DataGridViewTextBoxColumn38
        '
        Me.DataGridViewTextBoxColumn38.Frozen = True
        Me.DataGridViewTextBoxColumn38.HeaderText = "Trip #"
        Me.DataGridViewTextBoxColumn38.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn38.Name = "DataGridViewTextBoxColumn38"
        Me.DataGridViewTextBoxColumn38.ReadOnly = True
        Me.DataGridViewTextBoxColumn38.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn38.Width = 120
        '
        'DataGridViewTextBoxColumn39
        '
        Me.DataGridViewTextBoxColumn39.Frozen = True
        Me.DataGridViewTextBoxColumn39.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn39.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn39.Name = "DataGridViewTextBoxColumn39"
        Me.DataGridViewTextBoxColumn39.ReadOnly = True
        Me.DataGridViewTextBoxColumn39.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn39.Width = 130
        '
        'DataGridViewTextBoxColumn40
        '
        Me.DataGridViewTextBoxColumn40.HeaderText = "Driver"
        Me.DataGridViewTextBoxColumn40.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn40.Name = "DataGridViewTextBoxColumn40"
        Me.DataGridViewTextBoxColumn40.ReadOnly = True
        Me.DataGridViewTextBoxColumn40.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn40.Width = 150
        '
        'DataGridViewTextBoxColumn75
        '
        Me.DataGridViewTextBoxColumn75.HeaderText = "Helper"
        Me.DataGridViewTextBoxColumn75.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn75.Name = "DataGridViewTextBoxColumn75"
        Me.DataGridViewTextBoxColumn75.ReadOnly = True
        Me.DataGridViewTextBoxColumn75.Width = 180
        '
        'DataGridViewTextBoxColumn93
        '
        DataGridViewCellStyle54.Format = "yyyy/MM/dd"
        Me.DataGridViewTextBoxColumn93.DefaultCellStyle = DataGridViewCellStyle54
        Me.DataGridViewTextBoxColumn93.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn93.Name = "DataGridViewTextBoxColumn93"
        Me.DataGridViewTextBoxColumn93.ReadOnly = True
        Me.DataGridViewTextBoxColumn93.Visible = False
        '
        'grp7
        '
        Me.grp7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grp7.Controls.Add(Me.link2to7)
        Me.grp7.Controls.Add(Me.lblpick7)
        Me.grp7.Controls.Add(Me.lblimgname7)
        Me.grp7.Controls.Add(Me.lblimgdate7)
        Me.grp7.Controls.Add(Me.txtpo7)
        Me.grp7.Controls.Add(Me.Label33)
        Me.grp7.Controls.Add(Me.Label26)
        Me.grp7.Controls.Add(Me.tripinfo7)
        Me.grp7.Controls.Add(Me.Label23)
        Me.grp7.Controls.Add(Me.btnimgdl7)
        Me.grp7.Controls.Add(Me.pgbar7)
        Me.grp7.Controls.Add(Me.lblconfirm7)
        Me.grp7.Controls.Add(Me.btnstartreturn)
        Me.grp7.Controls.Add(Me.lbltype7)
        Me.grp7.Controls.Add(Me.grdtrans7)
        Me.grp7.Controls.Add(Me.cmbimg7)
        Me.grp7.Controls.Add(Me.txtrems7)
        Me.grp7.Controls.Add(Me.Panel19)
        Me.grp7.Controls.Add(Me.lbltripnum7)
        Me.grp7.Controls.Add(Me.lblplate7)
        Me.grp7.Controls.Add(Me.lblimgid7)
        Me.grp7.Controls.Add(Me.btnimgfull7)
        Me.grp7.Controls.Add(Me.imgpanel7)
        Me.grp7.Controls.Add(Me.imgbox7)
        Me.grp7.Controls.Add(Me.btnimgremove7)
        Me.grp7.Controls.Add(Me.btnimgadd7)
        Me.grp7.Controls.Add(Me.btnimgcancel7)
        Me.grp7.Controls.Add(Me.btnimgrefresh7)
        Me.grp7.Controls.Add(Me.btnimgrename7)
        Me.grp7.Location = New System.Drawing.Point(388, 10)
        Me.grp7.Name = "grp7"
        Me.grp7.Size = New System.Drawing.Size(860, 582)
        Me.grp7.TabIndex = 1
        Me.grp7.TabStop = False
        Me.grp7.Text = "Photos"
        '
        'link2to7
        '
        Me.link2to7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.link2to7.AutoSize = True
        Me.link2to7.Location = New System.Drawing.Point(832, 496)
        Me.link2to7.Name = "link2to7"
        Me.link2to7.Size = New System.Drawing.Size(21, 15)
        Me.link2to7.TabIndex = 115
        Me.link2to7.TabStop = True
        Me.link2to7.Text = ">>"
        '
        'lblpick7
        '
        Me.lblpick7.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblpick7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblpick7.Font = New System.Drawing.Font("HoloLens MDL2 Assets", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpick7.Location = New System.Drawing.Point(580, 22)
        Me.lblpick7.Name = "lblpick7"
        Me.lblpick7.Size = New System.Drawing.Size(273, 38)
        Me.lblpick7.TabIndex = 114
        Me.lblpick7.Text = "PICKUP TRIP ONLY"
        Me.lblpick7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgname7
        '
        Me.lblimgname7.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgname7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgname7.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgname7.Location = New System.Drawing.Point(724, 271)
        Me.lblimgname7.Name = "lblimgname7"
        Me.lblimgname7.Size = New System.Drawing.Size(129, 20)
        Me.lblimgname7.TabIndex = 113
        Me.lblimgname7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgdate7
        '
        Me.lblimgdate7.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgdate7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgdate7.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgdate7.Location = New System.Drawing.Point(580, 271)
        Me.lblimgdate7.Name = "lblimgdate7"
        Me.lblimgdate7.Size = New System.Drawing.Size(138, 20)
        Me.lblimgdate7.TabIndex = 112
        Me.lblimgdate7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtpo7
        '
        Me.txtpo7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtpo7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtpo7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtpo7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.txtpo7.Location = New System.Drawing.Point(679, 497)
        Me.txtpo7.Name = "txtpo7"
        Me.txtpo7.ReadOnly = True
        Me.txtpo7.Size = New System.Drawing.Size(151, 13)
        Me.txtpo7.TabIndex = 104
        '
        'Label33
        '
        Me.Label33.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(583, 497)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(91, 14)
        Me.Label33.TabIndex = 103
        Me.Label33.Text = "Total Diesel PO:"
        '
        'Label26
        '
        Me.Label26.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.Red
        Me.Label26.Location = New System.Drawing.Point(404, 275)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(167, 14)
        Me.Label26.TabIndex = 96
        Me.Label26.Text = "-Write  N/A  if not applicable."
        '
        'tripinfo7
        '
        Me.tripinfo7.AutoSize = True
        Me.tripinfo7.Location = New System.Drawing.Point(745, 437)
        Me.tripinfo7.Name = "tripinfo7"
        Me.tripinfo7.Size = New System.Drawing.Size(80, 15)
        Me.tripinfo7.TabIndex = 95
        Me.tripinfo7.TabStop = True
        Me.tripinfo7.Text = "View Trip Info"
        '
        'Label23
        '
        Me.Label23.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Red
        Me.Label23.Location = New System.Drawing.Point(6, 275)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(252, 14)
        Me.Label23.TabIndex = 94
        Me.Label23.Text = "-Complete the Order Transaction Information."
        '
        'btnimgdl7
        '
        Me.btnimgdl7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl7.Image = CType(resources.GetObject("btnimgdl7.Image"), System.Drawing.Image)
        Me.btnimgdl7.Location = New System.Drawing.Point(580, 368)
        Me.btnimgdl7.Name = "btnimgdl7"
        Me.btnimgdl7.Size = New System.Drawing.Size(22, 30)
        Me.btnimgdl7.TabIndex = 93
        Me.btnimgdl7.Text = "Download Photo"
        Me.btnimgdl7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl7.UseVisualStyleBackColor = True
        Me.btnimgdl7.Visible = False
        '
        'pgbar7
        '
        Me.pgbar7.Location = New System.Drawing.Point(580, 216)
        Me.pgbar7.Name = "pgbar7"
        Me.pgbar7.Size = New System.Drawing.Size(273, 23)
        Me.pgbar7.TabIndex = 91
        Me.pgbar7.Visible = False
        '
        'lblconfirm7
        '
        Me.lblconfirm7.BackColor = System.Drawing.Color.Transparent
        Me.lblconfirm7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblconfirm7.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblconfirm7.Location = New System.Drawing.Point(6, 76)
        Me.lblconfirm7.Name = "lblconfirm7"
        Me.lblconfirm7.Size = New System.Drawing.Size(132, 38)
        Me.lblconfirm7.TabIndex = 88
        Me.lblconfirm7.Text = "0"
        Me.lblconfirm7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblconfirm7.Visible = False
        '
        'btnstartreturn
        '
        Me.btnstartreturn.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnstartreturn.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstartreturn.Image = CType(resources.GetObject("btnstartreturn.Image"), System.Drawing.Image)
        Me.btnstartreturn.Location = New System.Drawing.Point(6, 65)
        Me.btnstartreturn.Name = "btnstartreturn"
        Me.btnstartreturn.Size = New System.Drawing.Size(569, 62)
        Me.btnstartreturn.TabIndex = 84
        Me.btnstartreturn.Text = "TIME START RETURN OF DOCUMENTS"
        Me.btnstartreturn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnstartreturn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnstartreturn.UseVisualStyleBackColor = False
        '
        'lbltype7
        '
        Me.lbltype7.BackColor = System.Drawing.Color.Transparent
        Me.lbltype7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype7.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltype7.Location = New System.Drawing.Point(360, 22)
        Me.lbltype7.Name = "lbltype7"
        Me.lbltype7.Size = New System.Drawing.Size(215, 38)
        Me.lbltype7.TabIndex = 82
        Me.lbltype7.Text = "TYPE"
        Me.lbltype7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grdtrans7
        '
        Me.grdtrans7.AllowUserToAddRows = False
        Me.grdtrans7.AllowUserToDeleteRows = False
        DataGridViewCellStyle58.BackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.grdtrans7.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle58
        Me.grdtrans7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grdtrans7.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdtrans7.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdtrans7.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle59.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle59.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle59.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle59.NullValue = Nothing
        DataGridViewCellStyle59.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle59.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle59.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans7.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle59
        Me.grdtrans7.ColumnHeadersHeight = 30
        Me.grdtrans7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdtrans7.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn41, Me.DataGridViewTextBoxColumn42, Me.DataGridViewTextBoxColumn43, Me.DataGridViewTextBoxColumn44, Me.Column24, Me.Column31, Me.DataGridViewTextBoxColumn45, Me.DataGridViewTextBoxColumn46, Me.DataGridViewTextBoxColumn47, Me.DataGridViewTextBoxColumn48, Me.DataGridViewTextBoxColumn49, Me.DataGridViewTextBoxColumn50, Me.DataGridViewTextBoxColumn51, Me.DataGridViewTextBoxColumn96, Me.DataGridViewTextBoxColumn97, Me.Column27, Me.Column1})
        DataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle60.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle60.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle60.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle60.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle60.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle60.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans7.DefaultCellStyle = DataGridViewCellStyle60
        Me.grdtrans7.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdtrans7.EnableHeadersVisualStyles = False
        Me.grdtrans7.GridColor = System.Drawing.Color.Salmon
        Me.grdtrans7.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdtrans7.Location = New System.Drawing.Point(6, 290)
        Me.grdtrans7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdtrans7.MultiSelect = False
        Me.grdtrans7.Name = "grdtrans7"
        Me.grdtrans7.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle61.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle61.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle61.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle61.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle61.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle61.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans7.RowHeadersDefaultCellStyle = DataGridViewCellStyle61
        Me.grdtrans7.RowHeadersWidth = 10
        Me.grdtrans7.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle62.NullValue = Nothing
        DataGridViewCellStyle62.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans7.RowsDefaultCellStyle = DataGridViewCellStyle62
        Me.grdtrans7.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrans7.Size = New System.Drawing.Size(569, 208)
        Me.grdtrans7.TabIndex = 75
        '
        'DataGridViewTextBoxColumn41
        '
        Me.DataGridViewTextBoxColumn41.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn41.Name = "DataGridViewTextBoxColumn41"
        Me.DataGridViewTextBoxColumn41.Visible = False
        '
        'DataGridViewTextBoxColumn42
        '
        Me.DataGridViewTextBoxColumn42.ActiveLinkColor = System.Drawing.Color.Black
        Me.DataGridViewTextBoxColumn42.HeaderText = "Transaction #"
        Me.DataGridViewTextBoxColumn42.LinkColor = System.Drawing.Color.Red
        Me.DataGridViewTextBoxColumn42.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn42.Name = "DataGridViewTextBoxColumn42"
        Me.DataGridViewTextBoxColumn42.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn42.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn42.Width = 110
        '
        'DataGridViewTextBoxColumn43
        '
        Me.DataGridViewTextBoxColumn43.HeaderText = "Reference #"
        Me.DataGridViewTextBoxColumn43.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn43.Name = "DataGridViewTextBoxColumn43"
        '
        'DataGridViewTextBoxColumn44
        '
        Me.DataGridViewTextBoxColumn44.HeaderText = "Recipient"
        Me.DataGridViewTextBoxColumn44.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn44.Name = "DataGridViewTextBoxColumn44"
        Me.DataGridViewTextBoxColumn44.Width = 145
        '
        'Column24
        '
        Me.Column24.HeaderText = "Reschedule"
        Me.Column24.Name = "Column24"
        Me.Column24.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column24.Width = 80
        '
        'Column31
        '
        Me.Column31.HeaderText = "For AR Credit Memo"
        Me.Column31.Name = "Column31"
        Me.Column31.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column31.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column31.Width = 83
        '
        'DataGridViewTextBoxColumn45
        '
        Me.DataGridViewTextBoxColumn45.HeaderText = "AR #"
        Me.DataGridViewTextBoxColumn45.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn45.Name = "DataGridViewTextBoxColumn45"
        Me.DataGridViewTextBoxColumn45.Width = 120
        '
        'DataGridViewTextBoxColumn46
        '
        Me.DataGridViewTextBoxColumn46.HeaderText = "RDR"
        Me.DataGridViewTextBoxColumn46.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn46.Name = "DataGridViewTextBoxColumn46"
        Me.DataGridViewTextBoxColumn46.Width = 120
        '
        'DataGridViewTextBoxColumn47
        '
        Me.DataGridViewTextBoxColumn47.HeaderText = "DR#"
        Me.DataGridViewTextBoxColumn47.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn47.Name = "DataGridViewTextBoxColumn47"
        Me.DataGridViewTextBoxColumn47.Width = 120
        '
        'DataGridViewTextBoxColumn48
        '
        Me.DataGridViewTextBoxColumn48.HeaderText = "DN#"
        Me.DataGridViewTextBoxColumn48.Name = "DataGridViewTextBoxColumn48"
        '
        'DataGridViewTextBoxColumn49
        '
        Me.DataGridViewTextBoxColumn49.HeaderText = "ITR#"
        Me.DataGridViewTextBoxColumn49.Name = "DataGridViewTextBoxColumn49"
        '
        'DataGridViewTextBoxColumn50
        '
        Me.DataGridViewTextBoxColumn50.HeaderText = "IT#"
        Me.DataGridViewTextBoxColumn50.Name = "DataGridViewTextBoxColumn50"
        '
        'DataGridViewTextBoxColumn51
        '
        Me.DataGridViewTextBoxColumn51.HeaderText = "GRPO#"
        Me.DataGridViewTextBoxColumn51.Name = "DataGridViewTextBoxColumn51"
        '
        'DataGridViewTextBoxColumn96
        '
        Me.DataGridViewTextBoxColumn96.HeaderText = "Transaction Type"
        Me.DataGridViewTextBoxColumn96.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn96.Name = "DataGridViewTextBoxColumn96"
        Me.DataGridViewTextBoxColumn96.Width = 200
        '
        'DataGridViewTextBoxColumn97
        '
        Me.DataGridViewTextBoxColumn97.HeaderText = "Notes"
        Me.DataGridViewTextBoxColumn97.MinimumWidth = 200
        Me.DataGridViewTextBoxColumn97.Name = "DataGridViewTextBoxColumn97"
        Me.DataGridViewTextBoxColumn97.Width = 220
        '
        'Column27
        '
        Me.Column27.HeaderText = "Date Added to Trip"
        Me.Column27.Name = "Column27"
        Me.Column27.Width = 140
        '
        'Column1
        '
        Me.Column1.HeaderText = "Odometer"
        Me.Column1.Name = "Column1"
        '
        'cmbimg7
        '
        Me.cmbimg7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbimg7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbimg7.FormattingEnabled = True
        Me.cmbimg7.Items.AddRange(New Object() {"", "DR Signed by Customer", "Driver Expense Report", "Diesel Receipt", "DR with GRPO/PO/ITR", "DR LUDO Received by Whse", "Delivery Note", "SWS with Received/Signed by Checker/Driver", "Order Slip with Received/Signed by Checker/Driver", "Order Slip Signed by Customer", "ATW/ DR&SI/ OS", "ITR Signed by Warehouse", "Return of Goods"})
        Me.cmbimg7.Location = New System.Drawing.Point(580, 245)
        Me.cmbimg7.Name = "cmbimg7"
        Me.cmbimg7.Size = New System.Drawing.Size(273, 23)
        Me.cmbimg7.TabIndex = 73
        '
        'txtrems7
        '
        Me.txtrems7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtrems7.Location = New System.Drawing.Point(6, 503)
        Me.txtrems7.Multiline = True
        Me.txtrems7.Name = "txtrems7"
        Me.txtrems7.Size = New System.Drawing.Size(569, 71)
        Me.txtrems7.TabIndex = 72
        '
        'Panel19
        '
        Me.Panel19.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel19.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel19.Controls.Add(Me.chkpending)
        Me.Panel19.Controls.Add(Me.btnexempt7)
        Me.Panel19.Controls.Add(Me.btnconfirm7)
        Me.Panel19.Location = New System.Drawing.Point(580, 516)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(273, 58)
        Me.Panel19.TabIndex = 71
        '
        'chkpending
        '
        Me.chkpending.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkpending.AutoSize = True
        Me.chkpending.BackColor = System.Drawing.SystemColors.Control
        Me.chkpending.Location = New System.Drawing.Point(32, 8)
        Me.chkpending.Name = "chkpending"
        Me.chkpending.Size = New System.Drawing.Size(213, 19)
        Me.chkpending.TabIndex = 74
        Me.chkpending.Text = "With Pending Receipt(s) c/o Driver"
        Me.chkpending.UseVisualStyleBackColor = False
        Me.chkpending.Visible = False
        '
        'btnexempt7
        '
        Me.btnexempt7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnexempt7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexempt7.Image = CType(resources.GetObject("btnexempt7.Image"), System.Drawing.Image)
        Me.btnexempt7.Location = New System.Drawing.Point(139, 4)
        Me.btnexempt7.Name = "btnexempt7"
        Me.btnexempt7.Size = New System.Drawing.Size(130, 50)
        Me.btnexempt7.TabIndex = 73
        Me.btnexempt7.Text = "SAVE AS DRAFT"
        Me.btnexempt7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnexempt7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnexempt7.UseVisualStyleBackColor = True
        '
        'btnconfirm7
        '
        Me.btnconfirm7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnconfirm7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirm7.Image = CType(resources.GetObject("btnconfirm7.Image"), System.Drawing.Image)
        Me.btnconfirm7.Location = New System.Drawing.Point(3, 4)
        Me.btnconfirm7.Name = "btnconfirm7"
        Me.btnconfirm7.Size = New System.Drawing.Size(130, 50)
        Me.btnconfirm7.TabIndex = 72
        Me.btnconfirm7.Text = "CONFIRM"
        Me.btnconfirm7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnconfirm7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnconfirm7.UseVisualStyleBackColor = True
        '
        'lbltripnum7
        '
        Me.lbltripnum7.BackColor = System.Drawing.Color.Transparent
        Me.lbltripnum7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltripnum7.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltripnum7.Location = New System.Drawing.Point(6, 22)
        Me.lbltripnum7.Name = "lbltripnum7"
        Me.lbltripnum7.Size = New System.Drawing.Size(120, 38)
        Me.lbltripnum7.TabIndex = 70
        Me.lbltripnum7.Text = "Trip#"
        Me.lbltripnum7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbltripnum7.Visible = False
        '
        'lblplate7
        '
        Me.lblplate7.BackColor = System.Drawing.Color.Transparent
        Me.lblplate7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate7.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate7.Location = New System.Drawing.Point(6, 22)
        Me.lblplate7.Name = "lblplate7"
        Me.lblplate7.Size = New System.Drawing.Size(360, 38)
        Me.lblplate7.TabIndex = 69
        Me.lblplate7.Text = "Plate #"
        Me.lblplate7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgid7
        '
        Me.lblimgid7.AutoSize = True
        Me.lblimgid7.BackColor = System.Drawing.Color.White
        Me.lblimgid7.Location = New System.Drawing.Point(577, 416)
        Me.lblimgid7.Name = "lblimgid7"
        Me.lblimgid7.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid7.TabIndex = 68
        Me.lblimgid7.Text = "imgid"
        Me.lblimgid7.Visible = False
        '
        'btnimgfull7
        '
        Me.btnimgfull7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull7.Image = CType(resources.GetObject("btnimgfull7.Image"), System.Drawing.Image)
        Me.btnimgfull7.Location = New System.Drawing.Point(617, 368)
        Me.btnimgfull7.Name = "btnimgfull7"
        Me.btnimgfull7.Size = New System.Drawing.Size(208, 30)
        Me.btnimgfull7.TabIndex = 65
        Me.btnimgfull7.Text = "View Larger"
        Me.btnimgfull7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull7.UseVisualStyleBackColor = True
        '
        'imgpanel7
        '
        Me.imgpanel7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.imgpanel7.AutoScroll = True
        Me.imgpanel7.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel7.Location = New System.Drawing.Point(6, 133)
        Me.imgpanel7.Name = "imgpanel7"
        Me.imgpanel7.Size = New System.Drawing.Size(569, 138)
        Me.imgpanel7.TabIndex = 63
        '
        'imgbox7
        '
        Me.imgbox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox7.Location = New System.Drawing.Point(580, 65)
        Me.imgbox7.Name = "imgbox7"
        Me.imgbox7.Size = New System.Drawing.Size(273, 174)
        Me.imgbox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox7.TabIndex = 62
        Me.imgbox7.TabStop = False
        '
        'btnimgremove7
        '
        Me.btnimgremove7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove7.Image = CType(resources.GetObject("btnimgremove7.Image"), System.Drawing.Image)
        Me.btnimgremove7.Location = New System.Drawing.Point(617, 332)
        Me.btnimgremove7.Name = "btnimgremove7"
        Me.btnimgremove7.Size = New System.Drawing.Size(101, 30)
        Me.btnimgremove7.TabIndex = 60
        Me.btnimgremove7.Text = "Remove"
        Me.btnimgremove7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove7.UseVisualStyleBackColor = True
        '
        'btnimgadd7
        '
        Me.btnimgadd7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd7.Image = CType(resources.GetObject("btnimgadd7.Image"), System.Drawing.Image)
        Me.btnimgadd7.Location = New System.Drawing.Point(617, 296)
        Me.btnimgadd7.Name = "btnimgadd7"
        Me.btnimgadd7.Size = New System.Drawing.Size(101, 30)
        Me.btnimgadd7.TabIndex = 58
        Me.btnimgadd7.Text = "Add Photo"
        Me.btnimgadd7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd7.UseVisualStyleBackColor = True
        '
        'btnimgcancel7
        '
        Me.btnimgcancel7.Enabled = False
        Me.btnimgcancel7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel7.Image = CType(resources.GetObject("btnimgcancel7.Image"), System.Drawing.Image)
        Me.btnimgcancel7.Location = New System.Drawing.Point(724, 332)
        Me.btnimgcancel7.Name = "btnimgcancel7"
        Me.btnimgcancel7.Size = New System.Drawing.Size(101, 30)
        Me.btnimgcancel7.TabIndex = 61
        Me.btnimgcancel7.Text = "Cancel"
        Me.btnimgcancel7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel7.UseVisualStyleBackColor = True
        '
        'btnimgrefresh7
        '
        Me.btnimgrefresh7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh7.Image = CType(resources.GetObject("btnimgrefresh7.Image"), System.Drawing.Image)
        Me.btnimgrefresh7.Location = New System.Drawing.Point(617, 404)
        Me.btnimgrefresh7.Name = "btnimgrefresh7"
        Me.btnimgrefresh7.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh7.TabIndex = 66
        Me.btnimgrefresh7.Text = "Refresh Photos"
        Me.btnimgrefresh7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh7.UseVisualStyleBackColor = True
        '
        'btnimgrename7
        '
        Me.btnimgrename7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename7.Image = CType(resources.GetObject("btnimgrename7.Image"), System.Drawing.Image)
        Me.btnimgrename7.Location = New System.Drawing.Point(724, 296)
        Me.btnimgrename7.Name = "btnimgrename7"
        Me.btnimgrename7.Size = New System.Drawing.Size(101, 30)
        Me.btnimgrename7.TabIndex = 59
        Me.btnimgrename7.Text = "Rename"
        Me.btnimgrename7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename7.UseVisualStyleBackColor = True
        '
        'tab8
        '
        Me.tab8.Controls.Add(Me.panelstp8)
        Me.tab8.Location = New System.Drawing.Point(4, 64)
        Me.tab8.Name = "tab8"
        Me.tab8.Size = New System.Drawing.Size(1250, 602)
        Me.tab8.TabIndex = 11
        Me.tab8.Text = "     STEP 8 ( FOR POST-INSPECTION )     "
        Me.tab8.UseVisualStyleBackColor = True
        '
        'panelstp8
        '
        Me.panelstp8.AutoScroll = True
        Me.panelstp8.Controls.Add(Me.gstep8)
        Me.panelstp8.Controls.Add(Me.grp8)
        Me.panelstp8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelstp8.Location = New System.Drawing.Point(0, 0)
        Me.panelstp8.Name = "panelstp8"
        Me.panelstp8.Size = New System.Drawing.Size(1250, 602)
        Me.panelstp8.TabIndex = 4
        '
        'gstep8
        '
        Me.gstep8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gstep8.Controls.Add(Me.lblload8)
        Me.gstep8.Controls.Add(Me.cmbtrans8)
        Me.gstep8.Controls.Add(Me.btnrefstep8)
        Me.gstep8.Controls.Add(Me.grdstep8)
        Me.gstep8.Location = New System.Drawing.Point(6, 10)
        Me.gstep8.Name = "gstep8"
        Me.gstep8.Size = New System.Drawing.Size(379, 582)
        Me.gstep8.TabIndex = 0
        Me.gstep8.TabStop = False
        Me.gstep8.Text = "STEP 8 Trip"
        '
        'lblload8
        '
        Me.lblload8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload8.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload8.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload8.Location = New System.Drawing.Point(7, 52)
        Me.lblload8.Name = "lblload8"
        Me.lblload8.Size = New System.Drawing.Size(365, 489)
        Me.lblload8.TabIndex = 104
        Me.lblload8.Text = "Loading..."
        Me.lblload8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbtrans8
        '
        Me.cmbtrans8.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbtrans8.FormattingEnabled = True
        Me.cmbtrans8.Location = New System.Drawing.Point(144, 553)
        Me.cmbtrans8.Name = "cmbtrans8"
        Me.cmbtrans8.Size = New System.Drawing.Size(121, 23)
        Me.cmbtrans8.TabIndex = 71
        Me.cmbtrans8.Visible = False
        '
        'btnrefstep8
        '
        Me.btnrefstep8.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefstep8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefstep8.Image = CType(resources.GetObject("btnrefstep8.Image"), System.Drawing.Image)
        Me.btnrefstep8.Location = New System.Drawing.Point(271, 546)
        Me.btnrefstep8.Name = "btnrefstep8"
        Me.btnrefstep8.Size = New System.Drawing.Size(101, 30)
        Me.btnrefstep8.TabIndex = 70
        Me.btnrefstep8.Text = "Refresh List"
        Me.btnrefstep8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefstep8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefstep8.UseVisualStyleBackColor = True
        '
        'grdstep8
        '
        Me.grdstep8.AllowUserToAddRows = False
        Me.grdstep8.AllowUserToDeleteRows = False
        DataGridViewCellStyle63.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdstep8.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle63
        Me.grdstep8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdstep8.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdstep8.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle64.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle64.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle64.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle64.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle64.NullValue = Nothing
        DataGridViewCellStyle64.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle64.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle64.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep8.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle64
        Me.grdstep8.ColumnHeadersHeight = 30
        Me.grdstep8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdstep8.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn52, Me.DataGridViewTextBoxColumn53, Me.DataGridViewTextBoxColumn54, Me.DataGridViewTextBoxColumn55, Me.DataGridViewTextBoxColumn76, Me.DataGridViewTextBoxColumn94})
        DataGridViewCellStyle66.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle66.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle66.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle66.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle66.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle66.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle66.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep8.DefaultCellStyle = DataGridViewCellStyle66
        Me.grdstep8.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdstep8.EnableHeadersVisualStyles = False
        Me.grdstep8.GridColor = System.Drawing.Color.Salmon
        Me.grdstep8.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdstep8.Location = New System.Drawing.Point(6, 20)
        Me.grdstep8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdstep8.MultiSelect = False
        Me.grdstep8.Name = "grdstep8"
        Me.grdstep8.ReadOnly = True
        Me.grdstep8.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle67.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle67.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle67.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle67.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle67.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle67.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle67.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep8.RowHeadersDefaultCellStyle = DataGridViewCellStyle67
        Me.grdstep8.RowHeadersWidth = 10
        Me.grdstep8.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle68.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle68.NullValue = Nothing
        DataGridViewCellStyle68.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep8.RowsDefaultCellStyle = DataGridViewCellStyle68
        Me.grdstep8.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdstep8.Size = New System.Drawing.Size(367, 521)
        Me.grdstep8.TabIndex = 10
        '
        'DataGridViewTextBoxColumn52
        '
        Me.DataGridViewTextBoxColumn52.Frozen = True
        Me.DataGridViewTextBoxColumn52.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn52.Name = "DataGridViewTextBoxColumn52"
        Me.DataGridViewTextBoxColumn52.ReadOnly = True
        Me.DataGridViewTextBoxColumn52.Visible = False
        '
        'DataGridViewTextBoxColumn53
        '
        Me.DataGridViewTextBoxColumn53.Frozen = True
        Me.DataGridViewTextBoxColumn53.HeaderText = "Trip #"
        Me.DataGridViewTextBoxColumn53.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn53.Name = "DataGridViewTextBoxColumn53"
        Me.DataGridViewTextBoxColumn53.ReadOnly = True
        Me.DataGridViewTextBoxColumn53.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn53.Width = 120
        '
        'DataGridViewTextBoxColumn54
        '
        Me.DataGridViewTextBoxColumn54.Frozen = True
        Me.DataGridViewTextBoxColumn54.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn54.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn54.Name = "DataGridViewTextBoxColumn54"
        Me.DataGridViewTextBoxColumn54.ReadOnly = True
        Me.DataGridViewTextBoxColumn54.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn54.Width = 130
        '
        'DataGridViewTextBoxColumn55
        '
        Me.DataGridViewTextBoxColumn55.HeaderText = "Driver"
        Me.DataGridViewTextBoxColumn55.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn55.Name = "DataGridViewTextBoxColumn55"
        Me.DataGridViewTextBoxColumn55.ReadOnly = True
        Me.DataGridViewTextBoxColumn55.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn55.Width = 150
        '
        'DataGridViewTextBoxColumn76
        '
        Me.DataGridViewTextBoxColumn76.HeaderText = "Helper"
        Me.DataGridViewTextBoxColumn76.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn76.Name = "DataGridViewTextBoxColumn76"
        Me.DataGridViewTextBoxColumn76.ReadOnly = True
        Me.DataGridViewTextBoxColumn76.Width = 180
        '
        'DataGridViewTextBoxColumn94
        '
        DataGridViewCellStyle65.Format = "yyyy/MM/dd"
        Me.DataGridViewTextBoxColumn94.DefaultCellStyle = DataGridViewCellStyle65
        Me.DataGridViewTextBoxColumn94.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn94.Name = "DataGridViewTextBoxColumn94"
        Me.DataGridViewTextBoxColumn94.ReadOnly = True
        Me.DataGridViewTextBoxColumn94.Visible = False
        '
        'grp8
        '
        Me.grp8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grp8.Controls.Add(Me.Panelinch8)
        Me.grp8.Controls.Add(Me.lblimgname8)
        Me.grp8.Controls.Add(Me.lblimgdate8)
        Me.grp8.Controls.Add(Me.tripinfo8)
        Me.grp8.Controls.Add(Me.pgbar8)
        Me.grp8.Controls.Add(Me.lblconfirm8)
        Me.grp8.Controls.Add(Me.lblmake8)
        Me.grp8.Controls.Add(Me.lbltaxi)
        Me.grp8.Controls.Add(Me.lbltype8)
        Me.grp8.Controls.Add(Me.btnstartpost)
        Me.grp8.Controls.Add(Me.Panel23)
        Me.grp8.Controls.Add(Me.txtdestin8)
        Me.grp8.Controls.Add(Me.Panel21)
        Me.grp8.Controls.Add(Me.cmbimg8)
        Me.grp8.Controls.Add(Me.txtrems8)
        Me.grp8.Controls.Add(Me.Panel29)
        Me.grp8.Controls.Add(Me.lbltripnum8)
        Me.grp8.Controls.Add(Me.lblplate8)
        Me.grp8.Controls.Add(Me.btnimgdl8)
        Me.grp8.Controls.Add(Me.lblimgid8)
        Me.grp8.Controls.Add(Me.btnimgfull8)
        Me.grp8.Controls.Add(Me.imgpanel8)
        Me.grp8.Controls.Add(Me.imgbox8)
        Me.grp8.Controls.Add(Me.btnimgremove8)
        Me.grp8.Controls.Add(Me.btnimgadd8)
        Me.grp8.Controls.Add(Me.btnimgcancel8)
        Me.grp8.Controls.Add(Me.btnimgrefresh8)
        Me.grp8.Controls.Add(Me.btnimgrename8)
        Me.grp8.Location = New System.Drawing.Point(388, 10)
        Me.grp8.Name = "grp8"
        Me.grp8.Size = New System.Drawing.Size(860, 582)
        Me.grp8.TabIndex = 1
        Me.grp8.TabStop = False
        Me.grp8.Text = "Photos"
        '
        'Panelinch8
        '
        Me.Panelinch8.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panelinch8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panelinch8.Controls.Add(Me.btninch8cancel)
        Me.Panelinch8.Controls.Add(Me.btninch8ok)
        Me.Panelinch8.Controls.Add(Me.Label22)
        Me.Panelinch8.Controls.Add(Me.txtinch8)
        Me.Panelinch8.Location = New System.Drawing.Point(385, 502)
        Me.Panelinch8.Name = "Panelinch8"
        Me.Panelinch8.Size = New System.Drawing.Size(188, 78)
        Me.Panelinch8.TabIndex = 116
        Me.Panelinch8.Visible = False
        '
        'btninch8cancel
        '
        Me.btninch8cancel.Image = CType(resources.GetObject("btninch8cancel.Image"), System.Drawing.Image)
        Me.btninch8cancel.Location = New System.Drawing.Point(98, 48)
        Me.btninch8cancel.Name = "btninch8cancel"
        Me.btninch8cancel.Size = New System.Drawing.Size(75, 23)
        Me.btninch8cancel.TabIndex = 74
        Me.btninch8cancel.Text = "Cancel"
        Me.btninch8cancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btninch8cancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btninch8cancel.UseVisualStyleBackColor = True
        '
        'btninch8ok
        '
        Me.btninch8ok.Image = CType(resources.GetObject("btninch8ok.Image"), System.Drawing.Image)
        Me.btninch8ok.Location = New System.Drawing.Point(17, 48)
        Me.btninch8ok.Name = "btninch8ok"
        Me.btninch8ok.Size = New System.Drawing.Size(75, 23)
        Me.btninch8ok.TabIndex = 73
        Me.btninch8ok.Text = "Ok"
        Me.btninch8ok.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btninch8ok.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btninch8ok.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(17, 7)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(154, 15)
        Me.Label22.TabIndex = 72
        Me.Label22.Text = "Inches to Liters Converter"
        '
        'txtinch8
        '
        Me.txtinch8.Location = New System.Drawing.Point(11, 24)
        Me.txtinch8.Name = "txtinch8"
        Me.txtinch8.Size = New System.Drawing.Size(166, 21)
        Me.txtinch8.TabIndex = 0
        '
        'lblimgname8
        '
        Me.lblimgname8.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgname8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgname8.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgname8.Location = New System.Drawing.Point(724, 271)
        Me.lblimgname8.Name = "lblimgname8"
        Me.lblimgname8.Size = New System.Drawing.Size(129, 20)
        Me.lblimgname8.TabIndex = 115
        Me.lblimgname8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgdate8
        '
        Me.lblimgdate8.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgdate8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgdate8.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgdate8.Location = New System.Drawing.Point(580, 271)
        Me.lblimgdate8.Name = "lblimgdate8"
        Me.lblimgdate8.Size = New System.Drawing.Size(138, 20)
        Me.lblimgdate8.TabIndex = 114
        Me.lblimgdate8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tripinfo8
        '
        Me.tripinfo8.AutoSize = True
        Me.tripinfo8.Location = New System.Drawing.Point(745, 444)
        Me.tripinfo8.Name = "tripinfo8"
        Me.tripinfo8.Size = New System.Drawing.Size(80, 15)
        Me.tripinfo8.TabIndex = 97
        Me.tripinfo8.TabStop = True
        Me.tripinfo8.Text = "View Trip Info"
        '
        'pgbar8
        '
        Me.pgbar8.Location = New System.Drawing.Point(580, 216)
        Me.pgbar8.Name = "pgbar8"
        Me.pgbar8.Size = New System.Drawing.Size(273, 23)
        Me.pgbar8.TabIndex = 92
        Me.pgbar8.Visible = False
        '
        'lblconfirm8
        '
        Me.lblconfirm8.BackColor = System.Drawing.Color.Transparent
        Me.lblconfirm8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblconfirm8.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblconfirm8.Location = New System.Drawing.Point(6, 76)
        Me.lblconfirm8.Name = "lblconfirm8"
        Me.lblconfirm8.Size = New System.Drawing.Size(132, 38)
        Me.lblconfirm8.TabIndex = 88
        Me.lblconfirm8.Text = "0"
        Me.lblconfirm8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblconfirm8.Visible = False
        '
        'lblmake8
        '
        Me.lblmake8.BackColor = System.Drawing.Color.Transparent
        Me.lblmake8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblmake8.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmake8.Location = New System.Drawing.Point(323, 532)
        Me.lblmake8.Name = "lblmake8"
        Me.lblmake8.Size = New System.Drawing.Size(131, 38)
        Me.lblmake8.TabIndex = 87
        Me.lblmake8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblmake8.Visible = False
        '
        'lbltaxi
        '
        Me.lbltaxi.BackColor = System.Drawing.Color.Transparent
        Me.lbltaxi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltaxi.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltaxi.Location = New System.Drawing.Point(6, 538)
        Me.lbltaxi.Name = "lbltaxi"
        Me.lbltaxi.Size = New System.Drawing.Size(125, 38)
        Me.lbltaxi.TabIndex = 85
        Me.lbltaxi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbltaxi.Visible = False
        '
        'lbltype8
        '
        Me.lbltype8.BackColor = System.Drawing.Color.Transparent
        Me.lbltype8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype8.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltype8.Location = New System.Drawing.Point(360, 22)
        Me.lbltype8.Name = "lbltype8"
        Me.lbltype8.Size = New System.Drawing.Size(215, 38)
        Me.lbltype8.TabIndex = 82
        Me.lbltype8.Text = "TYPE"
        Me.lbltype8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnstartpost
        '
        Me.btnstartpost.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnstartpost.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstartpost.Image = CType(resources.GetObject("btnstartpost.Image"), System.Drawing.Image)
        Me.btnstartpost.Location = New System.Drawing.Point(6, 65)
        Me.btnstartpost.Name = "btnstartpost"
        Me.btnstartpost.Size = New System.Drawing.Size(569, 62)
        Me.btnstartpost.TabIndex = 84
        Me.btnstartpost.Text = "TIME START POST-INSPECTION"
        Me.btnstartpost.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnstartpost.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnstartpost.UseVisualStyleBackColor = False
        '
        'Panel23
        '
        Me.Panel23.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel23.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel23.Controls.Add(Me.TableLayoutPanel6)
        Me.Panel23.Location = New System.Drawing.Point(6, 350)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(569, 71)
        Me.Panel23.TabIndex = 82
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel6.ColumnCount = 2
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.47644!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.52356!))
        Me.TableLayoutPanel6.Controls.Add(Me.Panel26, 0, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.Panel24, 1, 0)
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 1
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(563, 65)
        Me.TableLayoutPanel6.TabIndex = 0
        '
        'Panel26
        '
        Me.Panel26.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel26.BackColor = System.Drawing.Color.LightGreen
        Me.Panel26.Controls.Add(Me.txtodobeg)
        Me.Panel26.Controls.Add(Me.Label18)
        Me.Panel26.Location = New System.Drawing.Point(3, 3)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(272, 59)
        Me.Panel26.TabIndex = 0
        '
        'txtodobeg
        '
        Me.txtodobeg.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtodobeg.BackColor = System.Drawing.Color.White
        Me.txtodobeg.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtodobeg.Location = New System.Drawing.Point(5, 30)
        Me.txtodobeg.Name = "txtodobeg"
        Me.txtodobeg.ReadOnly = True
        Me.txtodobeg.Size = New System.Drawing.Size(263, 22)
        Me.txtodobeg.TabIndex = 75
        Me.txtodobeg.Text = "0"
        Me.txtodobeg.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label18
        '
        Me.Label18.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(3, 6)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(214, 16)
        Me.Label18.TabIndex = 71
        Me.Label18.Text = "Actual Odometer Reading (Start)"
        '
        'Panel24
        '
        Me.Panel24.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel24.BackColor = System.Drawing.Color.LightGreen
        Me.Panel24.Controls.Add(Me.txtodoend)
        Me.Panel24.Controls.Add(Me.Label16)
        Me.Panel24.Location = New System.Drawing.Point(281, 3)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(279, 59)
        Me.Panel24.TabIndex = 0
        '
        'txtodoend
        '
        Me.txtodoend.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtodoend.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtodoend.Location = New System.Drawing.Point(5, 30)
        Me.txtodoend.Name = "txtodoend"
        Me.txtodoend.Size = New System.Drawing.Size(270, 22)
        Me.txtodoend.TabIndex = 75
        Me.txtodoend.Text = "0"
        Me.txtodoend.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label16
        '
        Me.Label16.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(3, 6)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(184, 16)
        Me.Label16.TabIndex = 71
        Me.Label16.Text = "Odometer Reading (Ending)"
        '
        'txtdestin8
        '
        Me.txtdestin8.BackColor = System.Drawing.Color.White
        Me.txtdestin8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtdestin8.Location = New System.Drawing.Point(6, 134)
        Me.txtdestin8.Name = "txtdestin8"
        Me.txtdestin8.ReadOnly = True
        Me.txtdestin8.Size = New System.Drawing.Size(568, 14)
        Me.txtdestin8.TabIndex = 81
        Me.txtdestin8.Text = "Destination:"
        '
        'Panel21
        '
        Me.Panel21.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel21.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel21.Controls.Add(Me.TableLayoutPanel3)
        Me.Panel21.Location = New System.Drawing.Point(6, 427)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(569, 71)
        Me.Panel21.TabIndex = 75
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel3.ColumnCount = 3
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.04082!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.95918!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 194.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.Panel25, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Panel6, 2, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Panel22, 1, 0)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(563, 65)
        Me.TableLayoutPanel3.TabIndex = 0
        '
        'Panel25
        '
        Me.Panel25.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel25.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel25.Controls.Add(Me.txttotaldiesel)
        Me.Panel25.Controls.Add(Me.Label13)
        Me.Panel25.Location = New System.Drawing.Point(3, 3)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(186, 59)
        Me.Panel25.TabIndex = 2
        '
        'txttotaldiesel
        '
        Me.txttotaldiesel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txttotaldiesel.BackColor = System.Drawing.Color.White
        Me.txttotaldiesel.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txttotaldiesel.Location = New System.Drawing.Point(4, 30)
        Me.txttotaldiesel.Name = "txttotaldiesel"
        Me.txttotaldiesel.ReadOnly = True
        Me.txttotaldiesel.Size = New System.Drawing.Size(177, 22)
        Me.txttotaldiesel.TabIndex = 76
        Me.txttotaldiesel.Text = "0"
        Me.txttotaldiesel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label13
        '
        Me.Label13.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label13.Location = New System.Drawing.Point(1, 6)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(188, 15)
        Me.Label13.TabIndex = 71
        Me.Label13.Text = "Total Diesel (Beginning) in Liters"
        '
        'Panel6
        '
        Me.Panel6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel6.Controls.Add(Me.btninch8)
        Me.Panel6.Controls.Add(Me.txtdieselend)
        Me.Panel6.Controls.Add(Me.Label4)
        Me.Panel6.Location = New System.Drawing.Point(371, 3)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(189, 59)
        Me.Panel6.TabIndex = 3
        '
        'btninch8
        '
        Me.btninch8.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btninch8.BackColor = System.Drawing.Color.Transparent
        Me.btninch8.Enabled = False
        Me.btninch8.FlatAppearance.BorderSize = 0
        Me.btninch8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btninch8.Image = CType(resources.GetObject("btninch8.Image"), System.Drawing.Image)
        Me.btninch8.Location = New System.Drawing.Point(162, 3)
        Me.btninch8.Name = "btninch8"
        Me.btninch8.Size = New System.Drawing.Size(23, 23)
        Me.btninch8.TabIndex = 108
        Me.btninch8.Tag = "1"
        Me.btninch8.UseVisualStyleBackColor = False
        '
        'txtdieselend
        '
        Me.txtdieselend.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtdieselend.BackColor = System.Drawing.Color.White
        Me.txtdieselend.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtdieselend.Location = New System.Drawing.Point(6, 30)
        Me.txtdieselend.Name = "txtdieselend"
        Me.txtdieselend.Size = New System.Drawing.Size(179, 22)
        Me.txtdieselend.TabIndex = 76
        Me.txtdieselend.Text = "0"
        Me.txtdieselend.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label4.Location = New System.Drawing.Point(3, 6)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(132, 15)
        Me.Label4.TabIndex = 71
        Me.Label4.Text = "Diesel Ending in Liters"
        '
        'Panel22
        '
        Me.Panel22.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel22.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel22.Controls.Add(Me.txtpostpo)
        Me.Panel22.Controls.Add(Me.Label14)
        Me.Panel22.Location = New System.Drawing.Point(195, 3)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(170, 59)
        Me.Panel22.TabIndex = 2
        '
        'txtpostpo
        '
        Me.txtpostpo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtpostpo.BackColor = System.Drawing.Color.White
        Me.txtpostpo.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtpostpo.Location = New System.Drawing.Point(6, 30)
        Me.txtpostpo.Name = "txtpostpo"
        Me.txtpostpo.Size = New System.Drawing.Size(154, 22)
        Me.txtpostpo.TabIndex = 76
        Me.txtpostpo.Text = "0"
        Me.txtpostpo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label14
        '
        Me.Label14.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label14.Location = New System.Drawing.Point(3, 6)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(150, 15)
        Me.Label14.TabIndex = 71
        Me.Label14.Text = "Add'l Diesel (PO) in Liters"
        '
        'cmbimg8
        '
        Me.cmbimg8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbimg8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbimg8.FormattingEnabled = True
        Me.cmbimg8.Items.AddRange(New Object() {"", "Ending Odometer Reading", "Ending Diesel Balance", "Diesel Receipt"})
        Me.cmbimg8.Location = New System.Drawing.Point(580, 245)
        Me.cmbimg8.Name = "cmbimg8"
        Me.cmbimg8.Size = New System.Drawing.Size(273, 23)
        Me.cmbimg8.TabIndex = 73
        '
        'txtrems8
        '
        Me.txtrems8.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtrems8.Location = New System.Drawing.Point(6, 504)
        Me.txtrems8.Multiline = True
        Me.txtrems8.Name = "txtrems8"
        Me.txtrems8.Size = New System.Drawing.Size(569, 71)
        Me.txtrems8.TabIndex = 72
        '
        'Panel29
        '
        Me.Panel29.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel29.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel29.Controls.Add(Me.btnexempt8)
        Me.Panel29.Controls.Add(Me.btnconfirm8)
        Me.Panel29.Location = New System.Drawing.Point(580, 504)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(273, 71)
        Me.Panel29.TabIndex = 71
        '
        'btnexempt8
        '
        Me.btnexempt8.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnexempt8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexempt8.Image = CType(resources.GetObject("btnexempt8.Image"), System.Drawing.Image)
        Me.btnexempt8.Location = New System.Drawing.Point(139, 3)
        Me.btnexempt8.Name = "btnexempt8"
        Me.btnexempt8.Size = New System.Drawing.Size(130, 62)
        Me.btnexempt8.TabIndex = 76
        Me.btnexempt8.Text = "SAVE AS DRAFT"
        Me.btnexempt8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnexempt8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnexempt8.UseVisualStyleBackColor = True
        '
        'btnconfirm8
        '
        Me.btnconfirm8.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnconfirm8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirm8.Image = CType(resources.GetObject("btnconfirm8.Image"), System.Drawing.Image)
        Me.btnconfirm8.Location = New System.Drawing.Point(3, 3)
        Me.btnconfirm8.Name = "btnconfirm8"
        Me.btnconfirm8.Size = New System.Drawing.Size(130, 62)
        Me.btnconfirm8.TabIndex = 72
        Me.btnconfirm8.Text = "CONFIRM"
        Me.btnconfirm8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnconfirm8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnconfirm8.UseVisualStyleBackColor = True
        '
        'lbltripnum8
        '
        Me.lbltripnum8.BackColor = System.Drawing.Color.Transparent
        Me.lbltripnum8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltripnum8.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltripnum8.Location = New System.Drawing.Point(6, 22)
        Me.lbltripnum8.Name = "lbltripnum8"
        Me.lbltripnum8.Size = New System.Drawing.Size(125, 38)
        Me.lbltripnum8.TabIndex = 70
        Me.lbltripnum8.Text = "Trip#"
        Me.lbltripnum8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbltripnum8.Visible = False
        '
        'lblplate8
        '
        Me.lblplate8.BackColor = System.Drawing.Color.Transparent
        Me.lblplate8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate8.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate8.Location = New System.Drawing.Point(6, 22)
        Me.lblplate8.Name = "lblplate8"
        Me.lblplate8.Size = New System.Drawing.Size(360, 38)
        Me.lblplate8.TabIndex = 69
        Me.lblplate8.Text = "Plate #"
        Me.lblplate8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnimgdl8
        '
        Me.btnimgdl8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl8.Image = CType(resources.GetObject("btnimgdl8.Image"), System.Drawing.Image)
        Me.btnimgdl8.Location = New System.Drawing.Point(587, 423)
        Me.btnimgdl8.Name = "btnimgdl8"
        Me.btnimgdl8.Size = New System.Drawing.Size(28, 30)
        Me.btnimgdl8.TabIndex = 64
        Me.btnimgdl8.Text = "Download Photo"
        Me.btnimgdl8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl8.UseVisualStyleBackColor = True
        Me.btnimgdl8.Visible = False
        '
        'lblimgid8
        '
        Me.lblimgid8.AutoSize = True
        Me.lblimgid8.Location = New System.Drawing.Point(577, 394)
        Me.lblimgid8.Name = "lblimgid8"
        Me.lblimgid8.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid8.TabIndex = 68
        Me.lblimgid8.Text = "imgid"
        Me.lblimgid8.Visible = False
        '
        'btnimgfull8
        '
        Me.btnimgfull8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull8.Image = CType(resources.GetObject("btnimgfull8.Image"), System.Drawing.Image)
        Me.btnimgfull8.Location = New System.Drawing.Point(617, 375)
        Me.btnimgfull8.Name = "btnimgfull8"
        Me.btnimgfull8.Size = New System.Drawing.Size(208, 30)
        Me.btnimgfull8.TabIndex = 65
        Me.btnimgfull8.Text = "View Larger"
        Me.btnimgfull8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull8.UseVisualStyleBackColor = True
        '
        'imgpanel8
        '
        Me.imgpanel8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.imgpanel8.AutoScroll = True
        Me.imgpanel8.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel8.Location = New System.Drawing.Point(6, 154)
        Me.imgpanel8.Name = "imgpanel8"
        Me.imgpanel8.Size = New System.Drawing.Size(569, 190)
        Me.imgpanel8.TabIndex = 63
        '
        'imgbox8
        '
        Me.imgbox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox8.Location = New System.Drawing.Point(580, 20)
        Me.imgbox8.Name = "imgbox8"
        Me.imgbox8.Size = New System.Drawing.Size(273, 219)
        Me.imgbox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox8.TabIndex = 62
        Me.imgbox8.TabStop = False
        '
        'btnimgremove8
        '
        Me.btnimgremove8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove8.Image = CType(resources.GetObject("btnimgremove8.Image"), System.Drawing.Image)
        Me.btnimgremove8.Location = New System.Drawing.Point(617, 339)
        Me.btnimgremove8.Name = "btnimgremove8"
        Me.btnimgremove8.Size = New System.Drawing.Size(101, 30)
        Me.btnimgremove8.TabIndex = 60
        Me.btnimgremove8.Text = "Remove"
        Me.btnimgremove8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove8.UseVisualStyleBackColor = True
        '
        'btnimgadd8
        '
        Me.btnimgadd8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd8.Image = CType(resources.GetObject("btnimgadd8.Image"), System.Drawing.Image)
        Me.btnimgadd8.Location = New System.Drawing.Point(617, 303)
        Me.btnimgadd8.Name = "btnimgadd8"
        Me.btnimgadd8.Size = New System.Drawing.Size(101, 30)
        Me.btnimgadd8.TabIndex = 58
        Me.btnimgadd8.Text = "Add Photo"
        Me.btnimgadd8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd8.UseVisualStyleBackColor = True
        '
        'btnimgcancel8
        '
        Me.btnimgcancel8.Enabled = False
        Me.btnimgcancel8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel8.Image = CType(resources.GetObject("btnimgcancel8.Image"), System.Drawing.Image)
        Me.btnimgcancel8.Location = New System.Drawing.Point(724, 339)
        Me.btnimgcancel8.Name = "btnimgcancel8"
        Me.btnimgcancel8.Size = New System.Drawing.Size(101, 30)
        Me.btnimgcancel8.TabIndex = 61
        Me.btnimgcancel8.Text = "Cancel"
        Me.btnimgcancel8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel8.UseVisualStyleBackColor = True
        '
        'btnimgrefresh8
        '
        Me.btnimgrefresh8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh8.Image = CType(resources.GetObject("btnimgrefresh8.Image"), System.Drawing.Image)
        Me.btnimgrefresh8.Location = New System.Drawing.Point(617, 411)
        Me.btnimgrefresh8.Name = "btnimgrefresh8"
        Me.btnimgrefresh8.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh8.TabIndex = 66
        Me.btnimgrefresh8.Text = "Refresh Photos"
        Me.btnimgrefresh8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh8.UseVisualStyleBackColor = True
        '
        'btnimgrename8
        '
        Me.btnimgrename8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename8.Image = CType(resources.GetObject("btnimgrename8.Image"), System.Drawing.Image)
        Me.btnimgrename8.Location = New System.Drawing.Point(724, 303)
        Me.btnimgrename8.Name = "btnimgrename8"
        Me.btnimgrename8.Size = New System.Drawing.Size(101, 30)
        Me.btnimgrename8.TabIndex = 59
        Me.btnimgrename8.Text = "Rename"
        Me.btnimgrename8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename8.UseVisualStyleBackColor = True
        '
        'tab9
        '
        Me.tab9.Controls.Add(Me.panelstp9)
        Me.tab9.Location = New System.Drawing.Point(4, 64)
        Me.tab9.Name = "tab9"
        Me.tab9.Size = New System.Drawing.Size(1250, 602)
        Me.tab9.TabIndex = 12
        Me.tab9.Text = "     STEP 9 ( FOR RECORDING )     "
        Me.tab9.UseVisualStyleBackColor = True
        '
        'panelstp9
        '
        Me.panelstp9.AutoScroll = True
        Me.panelstp9.Controls.Add(Me.gstep9)
        Me.panelstp9.Controls.Add(Me.grp9)
        Me.panelstp9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelstp9.Location = New System.Drawing.Point(0, 0)
        Me.panelstp9.Name = "panelstp9"
        Me.panelstp9.Size = New System.Drawing.Size(1250, 602)
        Me.panelstp9.TabIndex = 5
        '
        'gstep9
        '
        Me.gstep9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gstep9.Controls.Add(Me.lbls9)
        Me.gstep9.Controls.Add(Me.btntrip9)
        Me.gstep9.Controls.Add(Me.txts9)
        Me.gstep9.Controls.Add(Me.lblload9)
        Me.gstep9.Controls.Add(Me.Label25)
        Me.gstep9.Controls.Add(Me.cmbwhse9)
        Me.gstep9.Controls.Add(Me.cmbtrans9)
        Me.gstep9.Controls.Add(Me.btnrefstep9)
        Me.gstep9.Controls.Add(Me.grdstep9)
        Me.gstep9.Location = New System.Drawing.Point(6, 10)
        Me.gstep9.Name = "gstep9"
        Me.gstep9.Size = New System.Drawing.Size(379, 582)
        Me.gstep9.TabIndex = 0
        Me.gstep9.TabStop = False
        Me.gstep9.Text = "STEP 9 Trip"
        '
        'lbls9
        '
        Me.lbls9.Location = New System.Drawing.Point(31, 18)
        Me.lbls9.Name = "lbls9"
        Me.lbls9.Size = New System.Drawing.Size(99, 18)
        Me.lbls9.TabIndex = 111
        Me.lbls9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btntrip9
        '
        Me.btntrip9.Image = CType(resources.GetObject("btntrip9.Image"), System.Drawing.Image)
        Me.btntrip9.Location = New System.Drawing.Point(259, 16)
        Me.btntrip9.Name = "btntrip9"
        Me.btntrip9.Size = New System.Drawing.Size(112, 23)
        Me.btntrip9.TabIndex = 107
        Me.btntrip9.Text = "Search Trip#"
        Me.btntrip9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btntrip9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btntrip9.UseVisualStyleBackColor = True
        '
        'txts9
        '
        Me.txts9.Location = New System.Drawing.Point(136, 17)
        Me.txts9.Name = "txts9"
        Me.txts9.Size = New System.Drawing.Size(119, 21)
        Me.txts9.TabIndex = 106
        '
        'lblload9
        '
        Me.lblload9.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload9.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload9.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload9.Location = New System.Drawing.Point(7, 76)
        Me.lblload9.Name = "lblload9"
        Me.lblload9.Size = New System.Drawing.Size(363, 464)
        Me.lblload9.TabIndex = 104
        Me.lblload9.Text = "Loading..."
        Me.lblload9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label25
        '
        Me.Label25.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(6, 554)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(37, 15)
        Me.Label25.TabIndex = 73
        Me.Label25.Text = "Filter:"
        '
        'cmbwhse9
        '
        Me.cmbwhse9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmbwhse9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbwhse9.FormattingEnabled = True
        Me.cmbwhse9.Items.AddRange(New Object() {"All", "LC Accounting Staff", "AGI Accounting Staff", "C3 Manila", "Calamba", "Pagbilao", "Milaor", "Cebu", "Davao", "JP-Store", "Bacolod", "Tacloban"})
        Me.cmbwhse9.Location = New System.Drawing.Point(49, 551)
        Me.cmbwhse9.Name = "cmbwhse9"
        Me.cmbwhse9.Size = New System.Drawing.Size(165, 23)
        Me.cmbwhse9.TabIndex = 72
        '
        'cmbtrans9
        '
        Me.cmbtrans9.FormattingEnabled = True
        Me.cmbtrans9.Location = New System.Drawing.Point(220, 551)
        Me.cmbtrans9.Name = "cmbtrans9"
        Me.cmbtrans9.Size = New System.Drawing.Size(44, 23)
        Me.cmbtrans9.TabIndex = 71
        Me.cmbtrans9.Visible = False
        '
        'btnrefstep9
        '
        Me.btnrefstep9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefstep9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefstep9.Image = CType(resources.GetObject("btnrefstep9.Image"), System.Drawing.Image)
        Me.btnrefstep9.Location = New System.Drawing.Point(270, 546)
        Me.btnrefstep9.Name = "btnrefstep9"
        Me.btnrefstep9.Size = New System.Drawing.Size(101, 30)
        Me.btnrefstep9.TabIndex = 70
        Me.btnrefstep9.Text = "Refresh List"
        Me.btnrefstep9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefstep9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefstep9.UseVisualStyleBackColor = True
        '
        'grdstep9
        '
        Me.grdstep9.AllowUserToAddRows = False
        Me.grdstep9.AllowUserToDeleteRows = False
        DataGridViewCellStyle69.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdstep9.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle69
        Me.grdstep9.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdstep9.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdstep9.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle70.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle70.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle70.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle70.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle70.NullValue = Nothing
        DataGridViewCellStyle70.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle70.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle70.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep9.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle70
        Me.grdstep9.ColumnHeadersHeight = 30
        Me.grdstep9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdstep9.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn56, Me.DataGridViewTextBoxColumn57, Me.DataGridViewTextBoxColumn58, Me.DataGridViewTextBoxColumn59, Me.DataGridViewTextBoxColumn77, Me.Column26, Me.DataGridViewTextBoxColumn95})
        DataGridViewCellStyle72.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle72.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle72.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle72.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle72.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle72.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle72.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep9.DefaultCellStyle = DataGridViewCellStyle72
        Me.grdstep9.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdstep9.EnableHeadersVisualStyles = False
        Me.grdstep9.GridColor = System.Drawing.Color.Salmon
        Me.grdstep9.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdstep9.Location = New System.Drawing.Point(6, 44)
        Me.grdstep9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdstep9.MultiSelect = False
        Me.grdstep9.Name = "grdstep9"
        Me.grdstep9.ReadOnly = True
        Me.grdstep9.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle73.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle73.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle73.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle73.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle73.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle73.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle73.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep9.RowHeadersDefaultCellStyle = DataGridViewCellStyle73
        Me.grdstep9.RowHeadersWidth = 10
        Me.grdstep9.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle74.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle74.NullValue = Nothing
        DataGridViewCellStyle74.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep9.RowsDefaultCellStyle = DataGridViewCellStyle74
        Me.grdstep9.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdstep9.Size = New System.Drawing.Size(365, 497)
        Me.grdstep9.TabIndex = 10
        '
        'DataGridViewTextBoxColumn56
        '
        Me.DataGridViewTextBoxColumn56.Frozen = True
        Me.DataGridViewTextBoxColumn56.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn56.Name = "DataGridViewTextBoxColumn56"
        Me.DataGridViewTextBoxColumn56.ReadOnly = True
        Me.DataGridViewTextBoxColumn56.Visible = False
        '
        'DataGridViewTextBoxColumn57
        '
        Me.DataGridViewTextBoxColumn57.Frozen = True
        Me.DataGridViewTextBoxColumn57.HeaderText = "Trip #"
        Me.DataGridViewTextBoxColumn57.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn57.Name = "DataGridViewTextBoxColumn57"
        Me.DataGridViewTextBoxColumn57.ReadOnly = True
        Me.DataGridViewTextBoxColumn57.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn57.Width = 120
        '
        'DataGridViewTextBoxColumn58
        '
        Me.DataGridViewTextBoxColumn58.Frozen = True
        Me.DataGridViewTextBoxColumn58.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn58.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn58.Name = "DataGridViewTextBoxColumn58"
        Me.DataGridViewTextBoxColumn58.ReadOnly = True
        Me.DataGridViewTextBoxColumn58.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn58.Width = 130
        '
        'DataGridViewTextBoxColumn59
        '
        Me.DataGridViewTextBoxColumn59.HeaderText = "Driver"
        Me.DataGridViewTextBoxColumn59.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn59.Name = "DataGridViewTextBoxColumn59"
        Me.DataGridViewTextBoxColumn59.ReadOnly = True
        Me.DataGridViewTextBoxColumn59.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn59.Width = 150
        '
        'DataGridViewTextBoxColumn77
        '
        Me.DataGridViewTextBoxColumn77.HeaderText = "Helper"
        Me.DataGridViewTextBoxColumn77.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn77.Name = "DataGridViewTextBoxColumn77"
        Me.DataGridViewTextBoxColumn77.ReadOnly = True
        Me.DataGridViewTextBoxColumn77.Width = 180
        '
        'Column26
        '
        Me.Column26.HeaderText = "To be Recorded by"
        Me.Column26.Name = "Column26"
        Me.Column26.ReadOnly = True
        Me.Column26.Visible = False
        '
        'DataGridViewTextBoxColumn95
        '
        DataGridViewCellStyle71.Format = "yyyy/MM/dd"
        Me.DataGridViewTextBoxColumn95.DefaultCellStyle = DataGridViewCellStyle71
        Me.DataGridViewTextBoxColumn95.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn95.Name = "DataGridViewTextBoxColumn95"
        Me.DataGridViewTextBoxColumn95.ReadOnly = True
        Me.DataGridViewTextBoxColumn95.Visible = False
        '
        'grp9
        '
        Me.grp9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grp9.Controls.Add(Me.link2to9)
        Me.grp9.Controls.Add(Me.lblpick9)
        Me.grp9.Controls.Add(Me.lblimgname9)
        Me.grp9.Controls.Add(Me.lblimgdate9)
        Me.grp9.Controls.Add(Me.txtpo9)
        Me.grp9.Controls.Add(Me.Label30)
        Me.grp9.Controls.Add(Me.Label31)
        Me.grp9.Controls.Add(Me.Label29)
        Me.grp9.Controls.Add(Me.Label28)
        Me.grp9.Controls.Add(Me.Label27)
        Me.grp9.Controls.Add(Me.tripinfo9)
        Me.grp9.Controls.Add(Me.pgbar9)
        Me.grp9.Controls.Add(Me.lblconfirm9)
        Me.grp9.Controls.Add(Me.Label21)
        Me.grp9.Controls.Add(Me.Label12)
        Me.grp9.Controls.Add(Me.grdtrans9)
        Me.grp9.Controls.Add(Me.btnstartrecord)
        Me.grp9.Controls.Add(Me.lbltype9)
        Me.grp9.Controls.Add(Me.cmbimg9)
        Me.grp9.Controls.Add(Me.txtrems9)
        Me.grp9.Controls.Add(Me.Panel35)
        Me.grp9.Controls.Add(Me.lbltripnum9)
        Me.grp9.Controls.Add(Me.lblplate9)
        Me.grp9.Controls.Add(Me.btnimgdl9)
        Me.grp9.Controls.Add(Me.lblimgid9)
        Me.grp9.Controls.Add(Me.btnimgfull9)
        Me.grp9.Controls.Add(Me.imgpanel9)
        Me.grp9.Controls.Add(Me.imgbox9)
        Me.grp9.Controls.Add(Me.btnimgremove9)
        Me.grp9.Controls.Add(Me.btnimgadd9)
        Me.grp9.Controls.Add(Me.btnimgcancel9)
        Me.grp9.Controls.Add(Me.btnimgrefresh9)
        Me.grp9.Controls.Add(Me.btnimgrename9)
        Me.grp9.Location = New System.Drawing.Point(388, 10)
        Me.grp9.Name = "grp9"
        Me.grp9.Size = New System.Drawing.Size(860, 582)
        Me.grp9.TabIndex = 1
        Me.grp9.TabStop = False
        Me.grp9.Text = "Photos"
        '
        'link2to9
        '
        Me.link2to9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.link2to9.AutoSize = True
        Me.link2to9.Location = New System.Drawing.Point(832, 505)
        Me.link2to9.Name = "link2to9"
        Me.link2to9.Size = New System.Drawing.Size(21, 15)
        Me.link2to9.TabIndex = 119
        Me.link2to9.TabStop = True
        Me.link2to9.Text = ">>"
        Me.link2to9.Visible = False
        '
        'lblpick9
        '
        Me.lblpick9.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblpick9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblpick9.Font = New System.Drawing.Font("HoloLens MDL2 Assets", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpick9.Location = New System.Drawing.Point(580, 22)
        Me.lblpick9.Name = "lblpick9"
        Me.lblpick9.Size = New System.Drawing.Size(273, 38)
        Me.lblpick9.TabIndex = 118
        Me.lblpick9.Text = "PICKUP TRIP ONLY"
        Me.lblpick9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgname9
        '
        Me.lblimgname9.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgname9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgname9.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgname9.Location = New System.Drawing.Point(724, 271)
        Me.lblimgname9.Name = "lblimgname9"
        Me.lblimgname9.Size = New System.Drawing.Size(129, 20)
        Me.lblimgname9.TabIndex = 117
        Me.lblimgname9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgdate9
        '
        Me.lblimgdate9.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgdate9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgdate9.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgdate9.Location = New System.Drawing.Point(580, 271)
        Me.lblimgdate9.Name = "lblimgdate9"
        Me.lblimgdate9.Size = New System.Drawing.Size(138, 20)
        Me.lblimgdate9.TabIndex = 116
        Me.lblimgdate9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtpo9
        '
        Me.txtpo9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtpo9.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtpo9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtpo9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.txtpo9.Location = New System.Drawing.Point(676, 506)
        Me.txtpo9.Name = "txtpo9"
        Me.txtpo9.ReadOnly = True
        Me.txtpo9.Size = New System.Drawing.Size(154, 13)
        Me.txtpo9.TabIndex = 102
        Me.txtpo9.Visible = False
        '
        'Label30
        '
        Me.Label30.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(580, 462)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(52, 14)
        Me.Label30.TabIndex = 100
        Me.Label30.Text = "Legend:"
        '
        'Label31
        '
        Me.Label31.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(580, 506)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(91, 14)
        Me.Label31.TabIndex = 101
        Me.Label31.Text = "Total Diesel PO:"
        Me.Label31.Visible = False
        '
        'Label29
        '
        Me.Label29.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Plum
        Me.Label29.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(774, 484)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(72, 14)
        Me.Label29.TabIndex = 99
        Me.Label29.Text = "Reschedule"
        '
        'Label28
        '
        Me.Label28.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Orange
        Me.Label28.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(650, 483)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(118, 14)
        Me.Label28.TabIndex = 98
        Me.Label28.Text = "For AR Credit Memo"
        '
        'Label27
        '
        Me.Label27.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Yellow
        Me.Label27.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(584, 483)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(60, 14)
        Me.Label27.TabIndex = 97
        Me.Label27.Text = "Recorded"
        '
        'tripinfo9
        '
        Me.tripinfo9.AutoSize = True
        Me.tripinfo9.Location = New System.Drawing.Point(745, 437)
        Me.tripinfo9.Name = "tripinfo9"
        Me.tripinfo9.Size = New System.Drawing.Size(80, 15)
        Me.tripinfo9.TabIndex = 96
        Me.tripinfo9.TabStop = True
        Me.tripinfo9.Text = "View Trip Info"
        '
        'pgbar9
        '
        Me.pgbar9.Location = New System.Drawing.Point(580, 216)
        Me.pgbar9.Name = "pgbar9"
        Me.pgbar9.Size = New System.Drawing.Size(273, 23)
        Me.pgbar9.TabIndex = 93
        Me.pgbar9.Visible = False
        '
        'lblconfirm9
        '
        Me.lblconfirm9.BackColor = System.Drawing.Color.Transparent
        Me.lblconfirm9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblconfirm9.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblconfirm9.Location = New System.Drawing.Point(6, 76)
        Me.lblconfirm9.Name = "lblconfirm9"
        Me.lblconfirm9.Size = New System.Drawing.Size(132, 38)
        Me.lblconfirm9.TabIndex = 88
        Me.lblconfirm9.Text = "0"
        Me.lblconfirm9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblconfirm9.Visible = False
        '
        'Label21
        '
        Me.Label21.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Red
        Me.Label21.Location = New System.Drawing.Point(405, 279)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(167, 14)
        Me.Label21.TabIndex = 87
        Me.Label21.Text = "-Write  N/A  if not applicable."
        '
        'Label12
        '
        Me.Label12.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Red
        Me.Label12.Location = New System.Drawing.Point(6, 279)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(252, 14)
        Me.Label12.TabIndex = 86
        Me.Label12.Text = "-Complete the Order Transaction Information."
        '
        'grdtrans9
        '
        Me.grdtrans9.AllowUserToAddRows = False
        Me.grdtrans9.AllowUserToDeleteRows = False
        DataGridViewCellStyle75.BackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.grdtrans9.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle75
        Me.grdtrans9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grdtrans9.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdtrans9.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdtrans9.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle76.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle76.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle76.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle76.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle76.NullValue = Nothing
        DataGridViewCellStyle76.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle76.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle76.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans9.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle76
        Me.grdtrans9.ColumnHeadersHeight = 30
        Me.grdtrans9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdtrans9.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn60, Me.DataGridViewLinkColumn1, Me.DataGridViewTextBoxColumn61, Me.DataGridViewTextBoxColumn62, Me.Column25, Me.Column30, Me.DataGridViewTextBoxColumn63, Me.DataGridViewTextBoxColumn64, Me.DataGridViewTextBoxColumn65, Me.DataGridViewTextBoxColumn66, Me.DataGridViewTextBoxColumn67, Me.Column35, Me.Column36, Me.DataGridViewTextBoxColumn68, Me.DataGridViewTextBoxColumn69, Me.DataGridViewTextBoxColumn78, Me.Column37, Me.Column32, Me.Column39, Me.Column38})
        DataGridViewCellStyle77.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle77.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle77.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle77.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle77.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle77.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle77.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans9.DefaultCellStyle = DataGridViewCellStyle77
        Me.grdtrans9.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdtrans9.EnableHeadersVisualStyles = False
        Me.grdtrans9.GridColor = System.Drawing.Color.Salmon
        Me.grdtrans9.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdtrans9.Location = New System.Drawing.Point(6, 294)
        Me.grdtrans9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdtrans9.MultiSelect = False
        Me.grdtrans9.Name = "grdtrans9"
        Me.grdtrans9.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle78.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle78.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle78.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle78.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle78.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle78.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle78.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans9.RowHeadersDefaultCellStyle = DataGridViewCellStyle78
        Me.grdtrans9.RowHeadersWidth = 10
        Me.grdtrans9.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle79.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle79.NullValue = Nothing
        DataGridViewCellStyle79.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans9.RowsDefaultCellStyle = DataGridViewCellStyle79
        Me.grdtrans9.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrans9.Size = New System.Drawing.Size(569, 208)
        Me.grdtrans9.TabIndex = 85
        '
        'DataGridViewTextBoxColumn60
        '
        Me.DataGridViewTextBoxColumn60.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn60.Name = "DataGridViewTextBoxColumn60"
        Me.DataGridViewTextBoxColumn60.Visible = False
        '
        'DataGridViewLinkColumn1
        '
        Me.DataGridViewLinkColumn1.ActiveLinkColor = System.Drawing.Color.Black
        Me.DataGridViewLinkColumn1.HeaderText = "Transaction #"
        Me.DataGridViewLinkColumn1.LinkColor = System.Drawing.Color.Red
        Me.DataGridViewLinkColumn1.Name = "DataGridViewLinkColumn1"
        Me.DataGridViewLinkColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewLinkColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewLinkColumn1.Width = 105
        '
        'DataGridViewTextBoxColumn61
        '
        Me.DataGridViewTextBoxColumn61.HeaderText = "Reference #"
        Me.DataGridViewTextBoxColumn61.Name = "DataGridViewTextBoxColumn61"
        '
        'DataGridViewTextBoxColumn62
        '
        Me.DataGridViewTextBoxColumn62.HeaderText = "Recipient"
        Me.DataGridViewTextBoxColumn62.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn62.Name = "DataGridViewTextBoxColumn62"
        Me.DataGridViewTextBoxColumn62.Width = 145
        '
        'Column25
        '
        Me.Column25.HeaderText = "Reschedule"
        Me.Column25.Name = "Column25"
        Me.Column25.Width = 80
        '
        'Column30
        '
        Me.Column30.HeaderText = "For AR Credit Memo"
        Me.Column30.Name = "Column30"
        Me.Column30.Width = 83
        '
        'DataGridViewTextBoxColumn63
        '
        Me.DataGridViewTextBoxColumn63.HeaderText = "AR #"
        Me.DataGridViewTextBoxColumn63.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn63.Name = "DataGridViewTextBoxColumn63"
        Me.DataGridViewTextBoxColumn63.Width = 120
        '
        'DataGridViewTextBoxColumn64
        '
        Me.DataGridViewTextBoxColumn64.HeaderText = "RDR"
        Me.DataGridViewTextBoxColumn64.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn64.Name = "DataGridViewTextBoxColumn64"
        Me.DataGridViewTextBoxColumn64.Width = 120
        '
        'DataGridViewTextBoxColumn65
        '
        Me.DataGridViewTextBoxColumn65.HeaderText = "DR#"
        Me.DataGridViewTextBoxColumn65.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn65.Name = "DataGridViewTextBoxColumn65"
        Me.DataGridViewTextBoxColumn65.Width = 120
        '
        'DataGridViewTextBoxColumn66
        '
        Me.DataGridViewTextBoxColumn66.HeaderText = "DN#"
        Me.DataGridViewTextBoxColumn66.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn66.Name = "DataGridViewTextBoxColumn66"
        '
        'DataGridViewTextBoxColumn67
        '
        Me.DataGridViewTextBoxColumn67.HeaderText = "ITR#"
        Me.DataGridViewTextBoxColumn67.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn67.Name = "DataGridViewTextBoxColumn67"
        '
        'Column35
        '
        Me.Column35.HeaderText = "IT#"
        Me.Column35.Name = "Column35"
        '
        'Column36
        '
        Me.Column36.HeaderText = "GRPO#"
        Me.Column36.Name = "Column36"
        '
        'DataGridViewTextBoxColumn68
        '
        Me.DataGridViewTextBoxColumn68.HeaderText = "Transaction Type"
        Me.DataGridViewTextBoxColumn68.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn68.Name = "DataGridViewTextBoxColumn68"
        Me.DataGridViewTextBoxColumn68.Width = 180
        '
        'DataGridViewTextBoxColumn69
        '
        Me.DataGridViewTextBoxColumn69.HeaderText = "Notes"
        Me.DataGridViewTextBoxColumn69.MinimumWidth = 200
        Me.DataGridViewTextBoxColumn69.Name = "DataGridViewTextBoxColumn69"
        Me.DataGridViewTextBoxColumn69.Width = 210
        '
        'DataGridViewTextBoxColumn78
        '
        Me.DataGridViewTextBoxColumn78.HeaderText = "Date Added to Trip"
        Me.DataGridViewTextBoxColumn78.Name = "DataGridViewTextBoxColumn78"
        Me.DataGridViewTextBoxColumn78.Width = 140
        '
        'Column37
        '
        Me.Column37.HeaderText = "trip ID"
        Me.Column37.Name = "Column37"
        Me.Column37.Visible = False
        '
        'Column32
        '
        Me.Column32.HeaderText = "Recorded"
        Me.Column32.Name = "Column32"
        Me.Column32.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column32.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'Column39
        '
        Me.Column39.HeaderText = "Recorded By"
        Me.Column39.Name = "Column39"
        '
        'Column38
        '
        Me.Column38.HeaderText = "Date Recorded"
        Me.Column38.Name = "Column38"
        Me.Column38.Width = 140
        '
        'btnstartrecord
        '
        Me.btnstartrecord.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnstartrecord.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstartrecord.Image = CType(resources.GetObject("btnstartrecord.Image"), System.Drawing.Image)
        Me.btnstartrecord.Location = New System.Drawing.Point(6, 65)
        Me.btnstartrecord.Name = "btnstartrecord"
        Me.btnstartrecord.Size = New System.Drawing.Size(569, 62)
        Me.btnstartrecord.TabIndex = 84
        Me.btnstartrecord.Text = "TIME START RECORDING"
        Me.btnstartrecord.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnstartrecord.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnstartrecord.UseVisualStyleBackColor = False
        '
        'lbltype9
        '
        Me.lbltype9.BackColor = System.Drawing.Color.Transparent
        Me.lbltype9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype9.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltype9.Location = New System.Drawing.Point(360, 22)
        Me.lbltype9.Name = "lbltype9"
        Me.lbltype9.Size = New System.Drawing.Size(215, 38)
        Me.lbltype9.TabIndex = 82
        Me.lbltype9.Text = "TYPE"
        Me.lbltype9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbimg9
        '
        Me.cmbimg9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbimg9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbimg9.FormattingEnabled = True
        Me.cmbimg9.Items.AddRange(New Object() {"", "SWS with ITR/IT/AR", "Transmittal", "Order Slip", "DN with ITR/IT", "Record SOA", "Record IT", "Record AR", "Record Sales Return", "Record Goods Return"})
        Me.cmbimg9.Location = New System.Drawing.Point(580, 245)
        Me.cmbimg9.Name = "cmbimg9"
        Me.cmbimg9.Size = New System.Drawing.Size(273, 23)
        Me.cmbimg9.TabIndex = 73
        '
        'txtrems9
        '
        Me.txtrems9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtrems9.Location = New System.Drawing.Point(6, 508)
        Me.txtrems9.Multiline = True
        Me.txtrems9.Name = "txtrems9"
        Me.txtrems9.Size = New System.Drawing.Size(569, 71)
        Me.txtrems9.TabIndex = 72
        '
        'Panel35
        '
        Me.Panel35.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel35.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel35.Controls.Add(Me.btnexempt9)
        Me.Panel35.Controls.Add(Me.btnconfirm9)
        Me.Panel35.Location = New System.Drawing.Point(580, 523)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(273, 56)
        Me.Panel35.TabIndex = 71
        '
        'btnexempt9
        '
        Me.btnexempt9.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnexempt9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexempt9.Image = CType(resources.GetObject("btnexempt9.Image"), System.Drawing.Image)
        Me.btnexempt9.Location = New System.Drawing.Point(139, 3)
        Me.btnexempt9.Name = "btnexempt9"
        Me.btnexempt9.Size = New System.Drawing.Size(130, 50)
        Me.btnexempt9.TabIndex = 73
        Me.btnexempt9.Text = "SAVE AS DRAFT"
        Me.btnexempt9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnexempt9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnexempt9.UseVisualStyleBackColor = True
        '
        'btnconfirm9
        '
        Me.btnconfirm9.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnconfirm9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirm9.Image = CType(resources.GetObject("btnconfirm9.Image"), System.Drawing.Image)
        Me.btnconfirm9.Location = New System.Drawing.Point(3, 3)
        Me.btnconfirm9.Name = "btnconfirm9"
        Me.btnconfirm9.Size = New System.Drawing.Size(130, 50)
        Me.btnconfirm9.TabIndex = 72
        Me.btnconfirm9.Text = "CONFIRM"
        Me.btnconfirm9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnconfirm9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnconfirm9.UseVisualStyleBackColor = True
        '
        'lbltripnum9
        '
        Me.lbltripnum9.BackColor = System.Drawing.Color.Transparent
        Me.lbltripnum9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltripnum9.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltripnum9.Location = New System.Drawing.Point(6, 22)
        Me.lbltripnum9.Name = "lbltripnum9"
        Me.lbltripnum9.Size = New System.Drawing.Size(130, 38)
        Me.lbltripnum9.TabIndex = 70
        Me.lbltripnum9.Text = "Trip#"
        Me.lbltripnum9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbltripnum9.Visible = False
        '
        'lblplate9
        '
        Me.lblplate9.BackColor = System.Drawing.Color.Transparent
        Me.lblplate9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate9.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate9.Location = New System.Drawing.Point(6, 22)
        Me.lblplate9.Name = "lblplate9"
        Me.lblplate9.Size = New System.Drawing.Size(360, 38)
        Me.lblplate9.TabIndex = 69
        Me.lblplate9.Text = "Plate #"
        Me.lblplate9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnimgdl9
        '
        Me.btnimgdl9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl9.Image = CType(resources.GetObject("btnimgdl9.Image"), System.Drawing.Image)
        Me.btnimgdl9.Location = New System.Drawing.Point(587, 297)
        Me.btnimgdl9.Name = "btnimgdl9"
        Me.btnimgdl9.Size = New System.Drawing.Size(29, 30)
        Me.btnimgdl9.TabIndex = 64
        Me.btnimgdl9.Text = "Download Photo"
        Me.btnimgdl9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl9.UseVisualStyleBackColor = True
        Me.btnimgdl9.Visible = False
        '
        'lblimgid9
        '
        Me.lblimgid9.AutoSize = True
        Me.lblimgid9.BackColor = System.Drawing.Color.Transparent
        Me.lblimgid9.Location = New System.Drawing.Point(577, 416)
        Me.lblimgid9.Name = "lblimgid9"
        Me.lblimgid9.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid9.TabIndex = 68
        Me.lblimgid9.Text = "imgid"
        Me.lblimgid9.Visible = False
        '
        'btnimgfull9
        '
        Me.btnimgfull9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull9.Image = CType(resources.GetObject("btnimgfull9.Image"), System.Drawing.Image)
        Me.btnimgfull9.Location = New System.Drawing.Point(617, 368)
        Me.btnimgfull9.Name = "btnimgfull9"
        Me.btnimgfull9.Size = New System.Drawing.Size(208, 30)
        Me.btnimgfull9.TabIndex = 65
        Me.btnimgfull9.Text = "View Larger"
        Me.btnimgfull9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull9.UseVisualStyleBackColor = True
        '
        'imgpanel9
        '
        Me.imgpanel9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.imgpanel9.AutoScroll = True
        Me.imgpanel9.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel9.Location = New System.Drawing.Point(6, 132)
        Me.imgpanel9.Name = "imgpanel9"
        Me.imgpanel9.Size = New System.Drawing.Size(569, 144)
        Me.imgpanel9.TabIndex = 63
        '
        'imgbox9
        '
        Me.imgbox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox9.Location = New System.Drawing.Point(580, 65)
        Me.imgbox9.Name = "imgbox9"
        Me.imgbox9.Size = New System.Drawing.Size(273, 174)
        Me.imgbox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox9.TabIndex = 62
        Me.imgbox9.TabStop = False
        '
        'btnimgremove9
        '
        Me.btnimgremove9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove9.Image = CType(resources.GetObject("btnimgremove9.Image"), System.Drawing.Image)
        Me.btnimgremove9.Location = New System.Drawing.Point(617, 332)
        Me.btnimgremove9.Name = "btnimgremove9"
        Me.btnimgremove9.Size = New System.Drawing.Size(101, 30)
        Me.btnimgremove9.TabIndex = 60
        Me.btnimgremove9.Text = "Remove"
        Me.btnimgremove9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove9.UseVisualStyleBackColor = True
        '
        'btnimgadd9
        '
        Me.btnimgadd9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd9.Image = CType(resources.GetObject("btnimgadd9.Image"), System.Drawing.Image)
        Me.btnimgadd9.Location = New System.Drawing.Point(617, 296)
        Me.btnimgadd9.Name = "btnimgadd9"
        Me.btnimgadd9.Size = New System.Drawing.Size(101, 30)
        Me.btnimgadd9.TabIndex = 58
        Me.btnimgadd9.Text = "Add Photo"
        Me.btnimgadd9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd9.UseVisualStyleBackColor = True
        '
        'btnimgcancel9
        '
        Me.btnimgcancel9.Enabled = False
        Me.btnimgcancel9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel9.Image = CType(resources.GetObject("btnimgcancel9.Image"), System.Drawing.Image)
        Me.btnimgcancel9.Location = New System.Drawing.Point(724, 332)
        Me.btnimgcancel9.Name = "btnimgcancel9"
        Me.btnimgcancel9.Size = New System.Drawing.Size(101, 30)
        Me.btnimgcancel9.TabIndex = 61
        Me.btnimgcancel9.Text = "Cancel"
        Me.btnimgcancel9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel9.UseVisualStyleBackColor = True
        '
        'btnimgrefresh9
        '
        Me.btnimgrefresh9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh9.Image = CType(resources.GetObject("btnimgrefresh9.Image"), System.Drawing.Image)
        Me.btnimgrefresh9.Location = New System.Drawing.Point(617, 404)
        Me.btnimgrefresh9.Name = "btnimgrefresh9"
        Me.btnimgrefresh9.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh9.TabIndex = 66
        Me.btnimgrefresh9.Text = "Refresh Photos"
        Me.btnimgrefresh9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh9.UseVisualStyleBackColor = True
        '
        'btnimgrename9
        '
        Me.btnimgrename9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename9.Image = CType(resources.GetObject("btnimgrename9.Image"), System.Drawing.Image)
        Me.btnimgrename9.Location = New System.Drawing.Point(724, 296)
        Me.btnimgrename9.Name = "btnimgrename9"
        Me.btnimgrename9.Size = New System.Drawing.Size(101, 30)
        Me.btnimgrename9.TabIndex = 59
        Me.btnimgrename9.Text = "Rename"
        Me.btnimgrename9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename9.UseVisualStyleBackColor = True
        '
        'BackgroundWorker1
        '
        Me.BackgroundWorker1.WorkerReportsProgress = True
        Me.BackgroundWorker1.WorkerSupportsCancellation = True
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditSOToolStripMenuItem, Me.EditPOToolStripMenuItem, Me.EditITRToolStripMenuItem, Me.EditSWSToolStripMenuItem, Me.ViewEditReferenceToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(168, 114)
        '
        'EditSOToolStripMenuItem
        '
        Me.EditSOToolStripMenuItem.Image = CType(resources.GetObject("EditSOToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditSOToolStripMenuItem.Name = "EditSOToolStripMenuItem"
        Me.EditSOToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.EditSOToolStripMenuItem.Text = "Edit SO#"
        '
        'EditPOToolStripMenuItem
        '
        Me.EditPOToolStripMenuItem.Image = CType(resources.GetObject("EditPOToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditPOToolStripMenuItem.Name = "EditPOToolStripMenuItem"
        Me.EditPOToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.EditPOToolStripMenuItem.Text = "Edit PO#"
        '
        'EditITRToolStripMenuItem
        '
        Me.EditITRToolStripMenuItem.Image = CType(resources.GetObject("EditITRToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditITRToolStripMenuItem.Name = "EditITRToolStripMenuItem"
        Me.EditITRToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.EditITRToolStripMenuItem.Text = "Edit ITR#"
        '
        'EditSWSToolStripMenuItem
        '
        Me.EditSWSToolStripMenuItem.Image = CType(resources.GetObject("EditSWSToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditSWSToolStripMenuItem.Name = "EditSWSToolStripMenuItem"
        Me.EditSWSToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.EditSWSToolStripMenuItem.Text = "Edit SWS#"
        '
        'ViewEditReferenceToolStripMenuItem
        '
        Me.ViewEditReferenceToolStripMenuItem.Image = CType(resources.GetObject("ViewEditReferenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewEditReferenceToolStripMenuItem.Name = "ViewEditReferenceToolStripMenuItem"
        Me.ViewEditReferenceToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.ViewEditReferenceToolStripMenuItem.Text = "View Ref# History"
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToBeRecordedByToolStripMenuItem})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(172, 26)
        '
        'ToBeRecordedByToolStripMenuItem
        '
        Me.ToBeRecordedByToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LCAccountingStaffToolStripMenuItem, Me.AGIAccountingStaffToolStripMenuItem, Me.C3ManilaToolStripMenuItem, Me.CalambaToolStripMenuItem, Me.PagbilaoToolStripMenuItem, Me.MilaorToolStripMenuItem, Me.CebuToolStripMenuItem, Me.DavaoToolStripMenuItem, Me.BacolodToolStripMenuItem, Me.TaclobanToolStripMenuItem})
        Me.ToBeRecordedByToolStripMenuItem.Image = CType(resources.GetObject("ToBeRecordedByToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ToBeRecordedByToolStripMenuItem.Name = "ToBeRecordedByToolStripMenuItem"
        Me.ToBeRecordedByToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.ToBeRecordedByToolStripMenuItem.Text = "To be Recorded by"
        '
        'LCAccountingStaffToolStripMenuItem
        '
        Me.LCAccountingStaffToolStripMenuItem.Image = CType(resources.GetObject("LCAccountingStaffToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LCAccountingStaffToolStripMenuItem.Name = "LCAccountingStaffToolStripMenuItem"
        Me.LCAccountingStaffToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.LCAccountingStaffToolStripMenuItem.Text = "LC Accounting Staff"
        '
        'AGIAccountingStaffToolStripMenuItem
        '
        Me.AGIAccountingStaffToolStripMenuItem.Image = CType(resources.GetObject("AGIAccountingStaffToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AGIAccountingStaffToolStripMenuItem.Name = "AGIAccountingStaffToolStripMenuItem"
        Me.AGIAccountingStaffToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.AGIAccountingStaffToolStripMenuItem.Text = "AGI Accounting Staff"
        '
        'C3ManilaToolStripMenuItem
        '
        Me.C3ManilaToolStripMenuItem.Image = CType(resources.GetObject("C3ManilaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.C3ManilaToolStripMenuItem.Name = "C3ManilaToolStripMenuItem"
        Me.C3ManilaToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.C3ManilaToolStripMenuItem.Text = "C3 Manila"
        '
        'CalambaToolStripMenuItem
        '
        Me.CalambaToolStripMenuItem.Image = CType(resources.GetObject("CalambaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CalambaToolStripMenuItem.Name = "CalambaToolStripMenuItem"
        Me.CalambaToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.CalambaToolStripMenuItem.Text = "Calamba"
        '
        'PagbilaoToolStripMenuItem
        '
        Me.PagbilaoToolStripMenuItem.Image = CType(resources.GetObject("PagbilaoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PagbilaoToolStripMenuItem.Name = "PagbilaoToolStripMenuItem"
        Me.PagbilaoToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.PagbilaoToolStripMenuItem.Text = "Pagbilao"
        '
        'MilaorToolStripMenuItem
        '
        Me.MilaorToolStripMenuItem.Image = CType(resources.GetObject("MilaorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MilaorToolStripMenuItem.Name = "MilaorToolStripMenuItem"
        Me.MilaorToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.MilaorToolStripMenuItem.Text = "Milaor"
        '
        'CebuToolStripMenuItem
        '
        Me.CebuToolStripMenuItem.Image = CType(resources.GetObject("CebuToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CebuToolStripMenuItem.Name = "CebuToolStripMenuItem"
        Me.CebuToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.CebuToolStripMenuItem.Text = "Cebu"
        '
        'DavaoToolStripMenuItem
        '
        Me.DavaoToolStripMenuItem.Image = CType(resources.GetObject("DavaoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DavaoToolStripMenuItem.Name = "DavaoToolStripMenuItem"
        Me.DavaoToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.DavaoToolStripMenuItem.Text = "Davao"
        '
        'BacolodToolStripMenuItem
        '
        Me.BacolodToolStripMenuItem.Image = CType(resources.GetObject("BacolodToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BacolodToolStripMenuItem.Name = "BacolodToolStripMenuItem"
        Me.BacolodToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.BacolodToolStripMenuItem.Text = "Bacolod"
        '
        'TaclobanToolStripMenuItem
        '
        Me.TaclobanToolStripMenuItem.Image = CType(resources.GetObject("TaclobanToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TaclobanToolStripMenuItem.Name = "TaclobanToolStripMenuItem"
        Me.TaclobanToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.TaclobanToolStripMenuItem.Text = "Tacloban"
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "completed")
        Me.ImageList1.Images.SetKeyName(1, "alertwarn")
        '
        'Panel27
        '
        Me.Panel27.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel27.AutoScroll = True
        Me.Panel27.BackColor = System.Drawing.SystemColors.Control
        Me.Panel27.Controls.Add(Me.TabControl1)
        Me.Panel27.Location = New System.Drawing.Point(0, 2)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(1277, 691)
        Me.Panel27.TabIndex = 2
        '
        'tripdispatch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1279, 696)
        Me.Controls.Add(Me.Panel27)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "tripdispatch"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " Trip Dispatch"
        Me.TabControl1.ResumeLayout(False)
        Me.tab1.ResumeLayout(False)
        Me.panelstp1.ResumeLayout(False)
        Me.gstep1.ResumeLayout(False)
        CType(Me.grdstep1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp1.ResumeLayout(False)
        Me.grp1.PerformLayout()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        CType(Me.imgbox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab2.ResumeLayout(False)
        Me.panelstp2.ResumeLayout(False)
        Me.gstep2.ResumeLayout(False)
        CType(Me.grdstep2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp2.ResumeLayout(False)
        Me.grp2.PerformLayout()
        Me.Panelinch2.ResumeLayout(False)
        Me.Panelinch2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.dieselpanel3.ResumeLayout(False)
        Me.dieselpanel3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        CType(Me.imgbox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab3.ResumeLayout(False)
        Me.panelstp3.ResumeLayout(False)
        Me.gstep3.ResumeLayout(False)
        CType(Me.grdstep3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp3.ResumeLayout(False)
        Me.grp3.PerformLayout()
        CType(Me.grdtrans3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        CType(Me.imgbox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab4.ResumeLayout(False)
        Me.panelstp4.ResumeLayout(False)
        Me.gstep4.ResumeLayout(False)
        CType(Me.grdstep4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp4.ResumeLayout(False)
        Me.grp4.PerformLayout()
        CType(Me.grdtrans4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel11.ResumeLayout(False)
        CType(Me.imgbox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab5.ResumeLayout(False)
        Me.panelstp5.ResumeLayout(False)
        Me.gstep5.ResumeLayout(False)
        CType(Me.grdstep5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp5.ResumeLayout(False)
        Me.grp5.PerformLayout()
        CType(Me.grdtrans5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel14.ResumeLayout(False)
        CType(Me.imgbox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab6.ResumeLayout(False)
        Me.panelstp6.ResumeLayout(False)
        Me.gstep6.ResumeLayout(False)
        CType(Me.grdstep6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp6.ResumeLayout(False)
        Me.grp6.PerformLayout()
        Me.Panel17.ResumeLayout(False)
        CType(Me.imgbox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab7.ResumeLayout(False)
        Me.panelstp7.ResumeLayout(False)
        Me.gstep7.ResumeLayout(False)
        Me.gstep7.PerformLayout()
        CType(Me.grdstep7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp7.ResumeLayout(False)
        Me.grp7.PerformLayout()
        CType(Me.grdtrans7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        CType(Me.imgbox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab8.ResumeLayout(False)
        Me.panelstp8.ResumeLayout(False)
        Me.gstep8.ResumeLayout(False)
        CType(Me.grdstep8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp8.ResumeLayout(False)
        Me.grp8.PerformLayout()
        Me.Panelinch8.ResumeLayout(False)
        Me.Panelinch8.PerformLayout()
        Me.Panel23.ResumeLayout(False)
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.Panel26.ResumeLayout(False)
        Me.Panel26.PerformLayout()
        Me.Panel24.ResumeLayout(False)
        Me.Panel24.PerformLayout()
        Me.Panel21.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.Panel25.ResumeLayout(False)
        Me.Panel25.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        Me.Panel29.ResumeLayout(False)
        CType(Me.imgbox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab9.ResumeLayout(False)
        Me.panelstp9.ResumeLayout(False)
        Me.gstep9.ResumeLayout(False)
        Me.gstep9.PerformLayout()
        CType(Me.grdstep9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp9.ResumeLayout(False)
        Me.grp9.PerformLayout()
        CType(Me.grdtrans9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel35.ResumeLayout(False)
        CType(Me.imgbox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ContextMenuStrip2.ResumeLayout(False)
        Me.Panel27.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tab1 As System.Windows.Forms.TabPage
    Friend WithEvents tab3 As System.Windows.Forms.TabPage
    Friend WithEvents tab4 As System.Windows.Forms.TabPage
    Friend WithEvents tab5 As System.Windows.Forms.TabPage
    Friend WithEvents tab6 As System.Windows.Forms.TabPage
    Friend WithEvents tab7 As System.Windows.Forms.TabPage
    Friend WithEvents tab8 As System.Windows.Forms.TabPage
    Friend WithEvents tab9 As System.Windows.Forms.TabPage
    Friend WithEvents tab2 As System.Windows.Forms.TabPage
    Friend WithEvents panelstp1 As System.Windows.Forms.Panel
    Friend WithEvents gstep1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnrefstep1 As System.Windows.Forms.Button
    Friend WithEvents grdstep1 As System.Windows.Forms.DataGridView
    Friend WithEvents grp1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbimg1 As System.Windows.Forms.ComboBox
    Friend WithEvents txtrems1 As System.Windows.Forms.TextBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents btnexempt1 As System.Windows.Forms.Button
    Friend WithEvents btnconfirm1 As System.Windows.Forms.Button
    Friend WithEvents lbltripnum1 As System.Windows.Forms.Label
    Friend WithEvents lblplate1 As System.Windows.Forms.Label
    Friend WithEvents btnimgdl1 As System.Windows.Forms.Button
    Friend WithEvents lblimgid1 As System.Windows.Forms.Label
    Friend WithEvents btnimgfull1 As System.Windows.Forms.Button
    Friend WithEvents imgpanel1 As System.Windows.Forms.Panel
    Friend WithEvents imgbox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnimgremove1 As System.Windows.Forms.Button
    Friend WithEvents btnimgadd1 As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel1 As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh1 As System.Windows.Forms.Button
    Friend WithEvents btnimgrename1 As System.Windows.Forms.Button
    Friend WithEvents panelstp2 As System.Windows.Forms.Panel
    Friend WithEvents gstep2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnrefstep2 As System.Windows.Forms.Button
    Friend WithEvents grdstep2 As System.Windows.Forms.DataGridView
    Friend WithEvents grp2 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbimg2 As System.Windows.Forms.ComboBox
    Friend WithEvents txtrems2 As System.Windows.Forms.TextBox
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents btnexempt2 As System.Windows.Forms.Button
    Friend WithEvents btnconfirm2 As System.Windows.Forms.Button
    Friend WithEvents lbltripnum2 As System.Windows.Forms.Label
    Friend WithEvents lblplate2 As System.Windows.Forms.Label
    Friend WithEvents btnimgdl2 As System.Windows.Forms.Button
    Friend WithEvents lblimgid2 As System.Windows.Forms.Label
    Friend WithEvents btnimgfull2 As System.Windows.Forms.Button
    Friend WithEvents imgpanel2 As System.Windows.Forms.Panel
    Friend WithEvents imgbox2 As System.Windows.Forms.PictureBox
    Friend WithEvents btnimgremove2 As System.Windows.Forms.Button
    Friend WithEvents btnimgadd2 As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel2 As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh2 As System.Windows.Forms.Button
    Friend WithEvents btnimgrename2 As System.Windows.Forms.Button
    Friend WithEvents panelstp3 As System.Windows.Forms.Panel
    Friend WithEvents gstep3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnrefstep3 As System.Windows.Forms.Button
    Friend WithEvents grdstep3 As System.Windows.Forms.DataGridView
    Friend WithEvents grp3 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbimg3 As System.Windows.Forms.ComboBox
    Friend WithEvents txtrems3 As System.Windows.Forms.TextBox
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents btnnot3 As System.Windows.Forms.Button
    Friend WithEvents btnconfirm3 As System.Windows.Forms.Button
    Friend WithEvents lbltripnum3 As System.Windows.Forms.Label
    Friend WithEvents lblplate3 As System.Windows.Forms.Label
    Friend WithEvents btnimgdl3 As System.Windows.Forms.Button
    Friend WithEvents lblimgid3 As System.Windows.Forms.Label
    Friend WithEvents btnimgfull3 As System.Windows.Forms.Button
    Friend WithEvents imgpanel3 As System.Windows.Forms.Panel
    Friend WithEvents imgbox3 As System.Windows.Forms.PictureBox
    Friend WithEvents btnimgremove3 As System.Windows.Forms.Button
    Friend WithEvents btnimgadd3 As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel3 As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh3 As System.Windows.Forms.Button
    Friend WithEvents btnimgrename3 As System.Windows.Forms.Button
    Friend WithEvents panelstp4 As System.Windows.Forms.Panel
    Friend WithEvents gstep4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnrefstep4 As System.Windows.Forms.Button
    Friend WithEvents grdstep4 As System.Windows.Forms.DataGridView
    Friend WithEvents grp4 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbimg4 As System.Windows.Forms.ComboBox
    Friend WithEvents txtrems4 As System.Windows.Forms.TextBox
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents btnexempt4 As System.Windows.Forms.Button
    Friend WithEvents btnconfirm4 As System.Windows.Forms.Button
    Friend WithEvents lbltripnum4 As System.Windows.Forms.Label
    Friend WithEvents lblplate4 As System.Windows.Forms.Label
    Friend WithEvents btnimgdl4 As System.Windows.Forms.Button
    Friend WithEvents lblimgid4 As System.Windows.Forms.Label
    Friend WithEvents btnimgfull4 As System.Windows.Forms.Button
    Friend WithEvents imgpanel4 As System.Windows.Forms.Panel
    Friend WithEvents imgbox4 As System.Windows.Forms.PictureBox
    Friend WithEvents btnimgremove4 As System.Windows.Forms.Button
    Friend WithEvents btnimgadd4 As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel4 As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh4 As System.Windows.Forms.Button
    Friend WithEvents btnimgrename4 As System.Windows.Forms.Button
    Friend WithEvents panelstp5 As System.Windows.Forms.Panel
    Friend WithEvents gstep5 As System.Windows.Forms.GroupBox
    Friend WithEvents btnrefstep5 As System.Windows.Forms.Button
    Friend WithEvents grdstep5 As System.Windows.Forms.DataGridView
    Friend WithEvents grp5 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbimg5 As System.Windows.Forms.ComboBox
    Friend WithEvents txtrems5 As System.Windows.Forms.TextBox
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents btnexempt5 As System.Windows.Forms.Button
    Friend WithEvents btnconfirm5 As System.Windows.Forms.Button
    Friend WithEvents lbltripnum5 As System.Windows.Forms.Label
    Friend WithEvents lblplate5 As System.Windows.Forms.Label
    Friend WithEvents btnimgdl5 As System.Windows.Forms.Button
    Friend WithEvents lblimgid5 As System.Windows.Forms.Label
    Friend WithEvents btnimgfull5 As System.Windows.Forms.Button
    Friend WithEvents imgpanel5 As System.Windows.Forms.Panel
    Friend WithEvents imgbox5 As System.Windows.Forms.PictureBox
    Friend WithEvents btnimgremove5 As System.Windows.Forms.Button
    Friend WithEvents btnimgadd5 As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel5 As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh5 As System.Windows.Forms.Button
    Friend WithEvents btnimgrename5 As System.Windows.Forms.Button
    Friend WithEvents panelstp6 As System.Windows.Forms.Panel
    Friend WithEvents gstep6 As System.Windows.Forms.GroupBox
    Friend WithEvents btnrefstep6 As System.Windows.Forms.Button
    Friend WithEvents grdstep6 As System.Windows.Forms.DataGridView
    Friend WithEvents grp6 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbimg6 As System.Windows.Forms.ComboBox
    Friend WithEvents txtrems6 As System.Windows.Forms.TextBox
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents btnother6 As System.Windows.Forms.Button
    Friend WithEvents btnconfirm6 As System.Windows.Forms.Button
    Friend WithEvents lbltripnum6 As System.Windows.Forms.Label
    Friend WithEvents lblplate6 As System.Windows.Forms.Label
    Friend WithEvents btnimgdl6 As System.Windows.Forms.Button
    Friend WithEvents lblimgid6 As System.Windows.Forms.Label
    Friend WithEvents btnimgfull6 As System.Windows.Forms.Button
    Friend WithEvents imgpanel6 As System.Windows.Forms.Panel
    Friend WithEvents imgbox6 As System.Windows.Forms.PictureBox
    Friend WithEvents btnimgremove6 As System.Windows.Forms.Button
    Friend WithEvents btnimgadd6 As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel6 As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh6 As System.Windows.Forms.Button
    Friend WithEvents btnimgrename6 As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents dieselpanel3 As System.Windows.Forms.Panel
    Friend WithEvents txtdshould As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents grdtrans4 As System.Windows.Forms.DataGridView
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents txtlabor As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents txtaddpo As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents txtdiesel As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents txtpo As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents txtdiswith As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents txtdiswout As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblpwout As System.Windows.Forms.Label
    Friend WithEvents lblpwith As System.Windows.Forms.Label
    Friend WithEvents lblinch As System.Windows.Forms.Label
    Friend WithEvents cmbtrans2 As System.Windows.Forms.ComboBox
    Friend WithEvents txtdestin As System.Windows.Forms.TextBox
    Friend WithEvents cmbtrans3 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbtrans4 As System.Windows.Forms.ComboBox
    Friend WithEvents grdtrans5 As System.Windows.Forms.DataGridView
    Friend WithEvents cmbtrans5 As System.Windows.Forms.ComboBox
    Friend WithEvents txtetd As System.Windows.Forms.TextBox
    Friend WithEvents panelstp7 As System.Windows.Forms.Panel
    Friend WithEvents gstep7 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbtrans7 As System.Windows.Forms.ComboBox
    Friend WithEvents btnrefstep7 As System.Windows.Forms.Button
    Friend WithEvents grdstep7 As System.Windows.Forms.DataGridView
    Friend WithEvents grp7 As System.Windows.Forms.GroupBox
    Friend WithEvents grdtrans7 As System.Windows.Forms.DataGridView
    Friend WithEvents cmbimg7 As System.Windows.Forms.ComboBox
    Friend WithEvents txtrems7 As System.Windows.Forms.TextBox
    Friend WithEvents Panel19 As System.Windows.Forms.Panel
    Friend WithEvents btnexempt7 As System.Windows.Forms.Button
    Friend WithEvents btnconfirm7 As System.Windows.Forms.Button
    Friend WithEvents lbltripnum7 As System.Windows.Forms.Label
    Friend WithEvents lblplate7 As System.Windows.Forms.Label
    Friend WithEvents lblimgid7 As System.Windows.Forms.Label
    Friend WithEvents btnimgfull7 As System.Windows.Forms.Button
    Friend WithEvents imgpanel7 As System.Windows.Forms.Panel
    Friend WithEvents imgbox7 As System.Windows.Forms.PictureBox
    Friend WithEvents btnimgremove7 As System.Windows.Forms.Button
    Friend WithEvents btnimgadd7 As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel7 As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh7 As System.Windows.Forms.Button
    Friend WithEvents btnimgrename7 As System.Windows.Forms.Button
    Friend WithEvents panelstp8 As System.Windows.Forms.Panel
    Friend WithEvents gstep8 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbtrans8 As System.Windows.Forms.ComboBox
    Friend WithEvents btnrefstep8 As System.Windows.Forms.Button
    Friend WithEvents grdstep8 As System.Windows.Forms.DataGridView
    Friend WithEvents grp8 As System.Windows.Forms.GroupBox
    Friend WithEvents txtdestin8 As System.Windows.Forms.TextBox
    Friend WithEvents Panel21 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel22 As System.Windows.Forms.Panel
    Friend WithEvents txtdieselend As System.Windows.Forms.TextBox
    Friend WithEvents Panel24 As System.Windows.Forms.Panel
    Friend WithEvents txtodoend As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents cmbimg8 As System.Windows.Forms.ComboBox
    Friend WithEvents txtrems8 As System.Windows.Forms.TextBox
    Friend WithEvents Panel29 As System.Windows.Forms.Panel
    Friend WithEvents btnconfirm8 As System.Windows.Forms.Button
    Friend WithEvents lbltripnum8 As System.Windows.Forms.Label
    Friend WithEvents lblplate8 As System.Windows.Forms.Label
    Friend WithEvents btnimgdl8 As System.Windows.Forms.Button
    Friend WithEvents lblimgid8 As System.Windows.Forms.Label
    Friend WithEvents btnimgfull8 As System.Windows.Forms.Button
    Friend WithEvents imgpanel8 As System.Windows.Forms.Panel
    Friend WithEvents imgbox8 As System.Windows.Forms.PictureBox
    Friend WithEvents btnimgremove8 As System.Windows.Forms.Button
    Friend WithEvents btnimgadd8 As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel8 As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh8 As System.Windows.Forms.Button
    Friend WithEvents btnimgrename8 As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents lblfull As System.Windows.Forms.Label
    Friend WithEvents txtodo As System.Windows.Forms.TextBox
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Panel20 As System.Windows.Forms.Panel
    Friend WithEvents txtodoend1 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel5 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel15 As System.Windows.Forms.Panel
    Friend WithEvents txtdieselbeg1 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnstartload As System.Windows.Forms.Button
    Friend WithEvents Panel23 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel6 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel25 As System.Windows.Forms.Panel
    Friend WithEvents txttotaldiesel As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Panel26 As System.Windows.Forms.Panel
    Friend WithEvents txtodobeg As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents panelstp9 As System.Windows.Forms.Panel
    Friend WithEvents gstep9 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbtrans9 As System.Windows.Forms.ComboBox
    Friend WithEvents btnrefstep9 As System.Windows.Forms.Button
    Friend WithEvents grdstep9 As System.Windows.Forms.DataGridView
    Friend WithEvents grp9 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbimg9 As System.Windows.Forms.ComboBox
    Friend WithEvents txtrems9 As System.Windows.Forms.TextBox
    Friend WithEvents Panel35 As System.Windows.Forms.Panel
    Friend WithEvents btnexempt9 As System.Windows.Forms.Button
    Friend WithEvents btnconfirm9 As System.Windows.Forms.Button
    Friend WithEvents lbltripnum9 As System.Windows.Forms.Label
    Friend WithEvents lblplate9 As System.Windows.Forms.Label
    Friend WithEvents btnimgdl9 As System.Windows.Forms.Button
    Friend WithEvents lblimgid9 As System.Windows.Forms.Label
    Friend WithEvents btnimgfull9 As System.Windows.Forms.Button
    Friend WithEvents imgpanel9 As System.Windows.Forms.Panel
    Friend WithEvents imgbox9 As System.Windows.Forms.PictureBox
    Friend WithEvents btnimgremove9 As System.Windows.Forms.Button
    Friend WithEvents btnimgadd9 As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel9 As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh9 As System.Windows.Forms.Button
    Friend WithEvents btnimgrename9 As System.Windows.Forms.Button
    Friend WithEvents btnstartpre As System.Windows.Forms.Button
    Friend WithEvents btnstartdiesel As System.Windows.Forms.Button
    Friend WithEvents btnstartdoc As System.Windows.Forms.Button
    Friend WithEvents btnstartcash As System.Windows.Forms.Button
    Friend WithEvents btndepart As System.Windows.Forms.Button
    Friend WithEvents btnstartreturn As System.Windows.Forms.Button
    Friend WithEvents btnstartpost As System.Windows.Forms.Button
    Friend WithEvents btnstartrecord As System.Windows.Forms.Button
    Friend WithEvents lbltype1 As System.Windows.Forms.Label
    Friend WithEvents lbltype2 As System.Windows.Forms.Label
    Friend WithEvents lbltype3 As System.Windows.Forms.Label
    Friend WithEvents lbltype4 As System.Windows.Forms.Label
    Friend WithEvents lbltype5 As System.Windows.Forms.Label
    Friend WithEvents lbltype6 As System.Windows.Forms.Label
    Friend WithEvents lbltype7 As System.Windows.Forms.Label
    Friend WithEvents lbltype8 As System.Windows.Forms.Label
    Friend WithEvents lbltype9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents grdtrans9 As System.Windows.Forms.DataGridView
    Friend WithEvents btnmtc As System.Windows.Forms.Button
    Friend WithEvents lbltaxi As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents txtpostpo As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnexempt3 As System.Windows.Forms.Button
    Friend WithEvents btnexempt6 As System.Windows.Forms.Button
    Friend WithEvents btnexempt8 As System.Windows.Forms.Button
    Friend WithEvents txtcustomer As System.Windows.Forms.TextBox
    Friend WithEvents cmbtrans6 As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblmake2 As System.Windows.Forms.Label
    Friend WithEvents lblmake8 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewTextBoxColumn26 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn27 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents DataGridViewTextBoxColumn28 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn29 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn30 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn31 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn32 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn33 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn34 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn35 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn36 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents lblconfirm1 As System.Windows.Forms.Label
    Friend WithEvents lblconfirm2 As System.Windows.Forms.Label
    Friend WithEvents lblconfirm3 As System.Windows.Forms.Label
    Friend WithEvents lblconfirm4 As System.Windows.Forms.Label
    Friend WithEvents lblconfirm5 As System.Windows.Forms.Label
    Friend WithEvents lblconfirm6 As System.Windows.Forms.Label
    Friend WithEvents lblconfirm7 As System.Windows.Forms.Label
    Friend WithEvents lblconfirm8 As System.Windows.Forms.Label
    Friend WithEvents lblconfirm9 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents lblDesiredSize As System.Windows.Forms.TextBox
    Friend WithEvents lblOriginalSize As System.Windows.Forms.Label
    Friend WithEvents lblCompressedSize As System.Windows.Forms.Label
    Friend WithEvents lblCompressionLevel As System.Windows.Forms.Label
    Friend WithEvents pgbar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents pgbar2 As System.Windows.Forms.ProgressBar
    Friend WithEvents pgbar3 As System.Windows.Forms.ProgressBar
    Friend WithEvents pgbar4 As System.Windows.Forms.ProgressBar
    Friend WithEvents pgbar5 As System.Windows.Forms.ProgressBar
    Friend WithEvents pgbar6 As System.Windows.Forms.ProgressBar
    Friend WithEvents pgbar7 As System.Windows.Forms.ProgressBar
    Friend WithEvents pgbar8 As System.Windows.Forms.ProgressBar
    Friend WithEvents pgbar9 As System.Windows.Forms.ProgressBar
    Friend WithEvents chkpending As System.Windows.Forms.CheckBox
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents EditSOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditPOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditITRToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditSWSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnimgdl7 As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents cmbwhse9 As System.Windows.Forms.ComboBox
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToBeRecordedByToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LCAccountingStaffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AGIAccountingStaffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents C3ManilaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalambaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PagbilaoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MilaorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CebuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DavaoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents grdtrans3 As System.Windows.Forms.DataGridView
    Friend WithEvents lblload1 As System.Windows.Forms.Label
    Friend WithEvents lblload2 As System.Windows.Forms.Label
    Friend WithEvents lblload3 As System.Windows.Forms.Label
    Friend WithEvents lblload4 As System.Windows.Forms.Label
    Friend WithEvents lblload5 As System.Windows.Forms.Label
    Friend WithEvents lblload6 As System.Windows.Forms.Label
    Friend WithEvents lblload7 As System.Windows.Forms.Label
    Friend WithEvents lblload8 As System.Windows.Forms.Label
    Friend WithEvents lblload9 As System.Windows.Forms.Label
    Friend WithEvents tripinfo4 As System.Windows.Forms.LinkLabel
    Friend WithEvents tripinfo7 As System.Windows.Forms.LinkLabel
    Friend WithEvents tripinfo9 As System.Windows.Forms.LinkLabel
    Friend WithEvents tripinfo8 As System.Windows.Forms.LinkLabel
    Friend WithEvents ViewEditReferenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewTextBoxColumn60 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewLinkColumn1 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents DataGridViewTextBoxColumn61 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn62 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column25 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Column30 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn63 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn64 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn65 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn66 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn67 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column35 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column36 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn68 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn69 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn78 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column37 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column32 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Column39 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column38 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents tripinfo3 As System.Windows.Forms.LinkLabel
    Friend WithEvents tripinfo5 As System.Windows.Forms.LinkLabel
    Friend WithEvents tripinfo1 As System.Windows.Forms.LinkLabel
    Friend WithEvents tripinfo2 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents btnpo As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents txtpo9 As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents txtpo7 As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column28 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn70 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column29 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn71 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn89 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn72 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn90 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn73 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn91 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn37 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn38 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn39 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn40 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn75 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn93 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn52 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn53 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn54 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn55 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn76 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn94 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn79 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewLinkColumn2 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents DataGridViewTextBoxColumn80 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn81 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn82 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn83 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn84 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn85 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn86 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column33 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column34 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn87 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn88 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btntrip9 As System.Windows.Forms.Button
    Friend WithEvents txts9 As System.Windows.Forms.TextBox
    Friend WithEvents lblimgname1 As System.Windows.Forms.Label
    Friend WithEvents lblimgdate1 As System.Windows.Forms.Label
    Friend WithEvents lblimgname2 As System.Windows.Forms.Label
    Friend WithEvents lblimgdate2 As System.Windows.Forms.Label
    Friend WithEvents lblimgname3 As System.Windows.Forms.Label
    Friend WithEvents lblimgdate3 As System.Windows.Forms.Label
    Friend WithEvents lblimgname4 As System.Windows.Forms.Label
    Friend WithEvents lblimgdate4 As System.Windows.Forms.Label
    Friend WithEvents lblimgname5 As System.Windows.Forms.Label
    Friend WithEvents lblimgdate5 As System.Windows.Forms.Label
    Friend WithEvents lblimgname7 As System.Windows.Forms.Label
    Friend WithEvents lblimgdate7 As System.Windows.Forms.Label
    Friend WithEvents lblimgname8 As System.Windows.Forms.Label
    Friend WithEvents lblimgdate8 As System.Windows.Forms.Label
    Friend WithEvents lblimgname9 As System.Windows.Forms.Label
    Friend WithEvents lblimgdate9 As System.Windows.Forms.Label
    Friend WithEvents btntrip7 As System.Windows.Forms.Button
    Friend WithEvents txts7 As System.Windows.Forms.TextBox
    Friend WithEvents BacolodToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TaclobanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblpup6 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewTextBoxColumn21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn24 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn74 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn92 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lbls7 As System.Windows.Forms.Label
    Friend WithEvents lbls9 As System.Windows.Forms.Label
    Friend WithEvents lblpick7 As System.Windows.Forms.Label
    Friend WithEvents Panel27 As System.Windows.Forms.Panel
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lblpick9 As System.Windows.Forms.Label
    Friend WithEvents btndis As System.Windows.Forms.Button
    Friend WithEvents btnodo As System.Windows.Forms.Button
    Friend WithEvents btninch2 As System.Windows.Forms.Button
    Friend WithEvents link2to7 As System.Windows.Forms.LinkLabel
    Friend WithEvents link2to9 As System.Windows.Forms.LinkLabel
    Friend WithEvents DataGridViewTextBoxColumn56 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn57 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn58 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn59 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn77 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column26 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn95 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btninch8 As System.Windows.Forms.Button
    Friend WithEvents Panelinch8 As System.Windows.Forms.Panel
    Friend WithEvents btninch8cancel As System.Windows.Forms.Button
    Friend WithEvents btninch8ok As System.Windows.Forms.Button
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtinch8 As System.Windows.Forms.TextBox
    Friend WithEvents Panelinch2 As System.Windows.Forms.Panel
    Friend WithEvents btninch2cancel As System.Windows.Forms.Button
    Friend WithEvents btninch2ok As System.Windows.Forms.Button
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtinch2 As System.Windows.Forms.TextBox
    Friend WithEvents DataGridViewTextBoxColumn41 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn42 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents DataGridViewTextBoxColumn43 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn44 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column24 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Column31 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn45 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn46 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn47 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn48 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn49 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn50 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn51 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn96 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn97 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column27 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
