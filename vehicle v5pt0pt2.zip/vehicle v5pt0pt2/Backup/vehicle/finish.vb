﻿Public Class finish
    Public fnsh As Boolean = False, cncel As Boolean = False

    Private Sub btnrepadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        fnsh = False
        cncel = False
        confirm.ShowDialog()
        If fnsh = True Then
            vmanage.dfinish = datefinish.Value
            Me.Close()
        End If
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        cncel = True
        Me.Close()
    End Sub

    Private Sub finish_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        datefinish.CustomFormat = "yyyy/MM/dd"
        datefinish.MinDate = vmanage.grdrepair.Rows(vmanage.grdrepair.CurrentRow.Index).Cells(4).Value
        datefinish.MaxDate = Date.Now
    End Sub
End Class