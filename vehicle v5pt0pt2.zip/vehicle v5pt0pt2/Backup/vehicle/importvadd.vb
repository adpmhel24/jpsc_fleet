﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel

Public Class importvadd
    Dim SheetList As New ArrayList
    Dim MyConnection As OleDbConnection
    Dim DtSet As System.Data.DataSet
    Dim MyCommand As OleDbDataAdapter
    Dim ii As Integer
    Dim checkBoxColumn As New DataGridViewCheckBoxColumn()
    Dim ds As New DataSet
    Dim dv As DataView

    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim derrors As Boolean = False
    Public importcnf As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub importvadd_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub importvadd_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'DtSet.Clear()
        txtPath.Text = ""
        btnLoadData.Enabled = False
        btncheck.Enabled = False
        btnadd.Enabled = False
        'dgvdata.Rows.Clear()
        dgvdata.Columns.Clear()
    End Sub

    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        With OpenFileDialog1
            .FileName = "Excel File"
            .Filter = "Excel Worksheets|*.xls;*.xlsx"
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                txtPath.Text = .FileName
                If txtPath.Text <> "" Then
                    btnLoadData.Enabled = True
                    btncheck.Enabled = False
                    btnadd.Enabled = False
                Else
                    btnLoadData.Enabled = False
                End If
            End If
        End With
    End Sub

    Private Sub btnLoadData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadData.Click
        Try
            ' DtSet.Clear()
            Me.Cursor = Cursors.WaitCursor
            MyConnection = New OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0;Data Source='" & txtPath.Text & "';Extended Properties=""Excel 8.0;HDR={1}""")

            Dim objExcel As Excel.Application
            Dim objWorkBook As Excel.Workbook
            Dim objWorkSheets As Excel.Worksheet
            Dim ExcelSheetName As String = ""

            objExcel = CreateObject("Excel.Application")
            objWorkBook = objExcel.Workbooks.Open(txtPath.Text)

            For Each objWorkSheets In objWorkBook.Worksheets
                SheetList.Add(objWorkSheets.Name)
            Next

            MyCommand = New OleDbDataAdapter("select * from [" & SheetList(0) & "$]", MyConnection)
            MyCommand.TableMappings.Add("Table", "Net-informations.com")
            'MsgBox(SheetList(0).ToString)
            DtSet = New System.Data.DataSet
            MyCommand.Fill(DtSet)
            dgvdata.DataSource = DtSet.Tables(0)
            ' MyCommand.Dispose()
            MyConnection.Close()

            objWorkBook.Close()
            objExcel.Quit()

            releaseObject(objWorkBook)
            releaseObject(objExcel)

            Me.Cursor = Cursors.Default

            dgvdata.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True
            'dgvdata.ColumnHeadersHeight = 40
            dgvdata.Columns(0).Width = 150
            dgvdata.Columns(1).Width = 150
            dgvdata.Columns(2).Width = 300
            dgvdata.Columns(3).Width = 120
            dgvdata.Columns(4).Width = 130

            If dgvdata.Rows.Count <> 0 Then
                btncheck.Enabled = True
            Else
                btncheck.Enabled = False
            End If

            derrors = False

            'remember: sa price kung nde sya numeric di sya iloload
            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " + ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub btncheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncheck.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If dgvdata.ColumnCount = 16 Then
                checkplnull()
                checkplate()
                checkvtype()
                checkdriver()
                checkyear()
                checkno()

                If derrors = False Then
                    MsgBox("Click add button to continue.", MsgBoxStyle.Information, "")
                    btnadd.Enabled = True
                Else
                    MsgBox("Error occurred. Please correct the highlighted errors and try again.", MsgBoxStyle.Critical, "")
                    btnadd.Enabled = False
                End If
            Else
                MsgBox("Invalid Columns.", MsgBoxStyle.Critical, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checkplnull()
        Try
            For Each row As DataGridViewRow In dgvdata.Rows
                'check if null yung tatlong platenum
                If dgvdata.Rows(row.Index).Cells(0).Value.ToString = "" And dgvdata.Rows(row.Index).Cells(1).Value.ToString = "" And dgvdata.Rows(row.Index).Cells(2).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(0).ToolTipText = "Plate number, Virtual plate and conduction sticker must have atleast one."
                    dgvdata.Rows(row.Index).Cells(0).Selected = True
                    dgvdata.Rows(row.Index).Cells(0).Style.BackColor = Color.Yellow
                    dgvdata.Rows(row.Index).Cells(1).Selected = True
                    dgvdata.Rows(row.Index).Cells(1).Style.BackColor = Color.Yellow
                    dgvdata.Rows(row.Index).Cells(2).Selected = True
                    dgvdata.Rows(row.Index).Cells(2).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(4).Value.ToString = "" Or (dgvdata.Rows(row.Index).Cells(4).Value.ToString <> "Truck" And dgvdata.Rows(row.Index).Cells(4).Value.ToString <> "Service") Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(4).ToolTipText = "Make should not be null. Specify if it is Truck or Service vehicle."
                    dgvdata.Rows(row.Index).Cells(4).Selected = True
                    dgvdata.Rows(row.Index).Cells(4).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checkplate()
        Try
            'check if category in the datagrid are in the tblcat

            'platenum
            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                If dgvdata.Rows(row.Index).Cells(0).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(0).Value = dgvdata.Rows(row.Index).Cells(0).Value.ToString.Replace("'", "")
                End If

                If dgvdata.Rows(row.Index).Cells(0).Value.ToString <> "" Then
                    sql = "Select * from tblgeneral where platenum='" & dgvdata.Rows(row.Index).Cells(0).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        'gawing tooltip ung mga msgbox
                        'kc iibahin ko nlng ng background color ung cells na may error
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(0).ToolTipText = "Plate number " & dgvdata.Rows(row.Index).Cells(0).Value.ToString & " is already exist."
                        dgvdata.Rows(row.Index).Cells(0).Selected = True
                        dgvdata.Rows(row.Index).Cells(0).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    Else
                        dgvdata.Rows(row.Index).Cells(0).Value = dgvdata.Rows(row.Index).Cells(0).Value.ToString.ToUpper
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Next

            'vplate

            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                If dgvdata.Rows(row.Index).Cells(1).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(1).Value = dgvdata.Rows(row.Index).Cells(1).Value.ToString.Replace("'", "")
                End If

                If dgvdata.Rows(row.Index).Cells(1).Value.ToString <> "" Then
                    sql = "Select * from tblgeneral where vplate='" & dgvdata.Rows(row.Index).Cells(1).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        'gawing tooltip ung mga msgbox
                        'kc iibahin ko nlng ng background color ung cells na may error
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(1).ToolTipText = "virtual plate " & dgvdata.Rows(row.Index).Cells(1).Value.ToString & " is already exist."
                        dgvdata.Rows(row.Index).Cells(1).Selected = True
                        dgvdata.Rows(row.Index).Cells(1).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    Else
                        dgvdata.Rows(row.Index).Cells(1).Value = dgvdata.Rows(row.Index).Cells(1).Value.ToString.ToUpper
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Next

            'csticker
            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                If dgvdata.Rows(row.Index).Cells(2).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(2).Value = dgvdata.Rows(row.Index).Cells(2).Value.ToString.Replace("'", "")
                End If

                If dgvdata.Rows(row.Index).Cells(2).Value.ToString <> "" Then
                    sql = "Select * from tblgeneral where csticker='" & dgvdata.Rows(row.Index).Cells(2).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        'gawing tooltip ung mga msgbox
                        'kc iibahin ko nlng ng background color ung cells na may error
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(2).ToolTipText = "Conduction Sticker " & dgvdata.Rows(row.Index).Cells(2).Value.ToString & " is already exist."
                        dgvdata.Rows(row.Index).Cells(2).Selected = True
                        dgvdata.Rows(row.Index).Cells(2).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    Else
                        dgvdata.Rows(row.Index).Cells(2).Value = dgvdata.Rows(row.Index).Cells(2).Value.ToString.ToUpper
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            importcnf = False
            If derrors = False Then
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If importcnf = True Then
                    For Each row As DataGridViewRow In dgvdata.Rows
                        Dim iplate As String = dgvdata.Rows(row.Index).Cells(0).Value.ToString
                        Dim ivplate As String = dgvdata.Rows(row.Index).Cells(1).Value.ToString
                        Dim isticker As String = dgvdata.Rows(row.Index).Cells(2).Value.ToString
                        Dim ivtype As String = dgvdata.Rows(row.Index).Cells(3).Value.ToString
                        Dim imake As String = dgvdata.Rows(row.Index).Cells(4).Value.ToString
                        Dim ibody As String = dgvdata.Rows(row.Index).Cells(5).Value.ToString
                        Dim iwhse As String = dgvdata.Rows(row.Index).Cells(6).Value.ToString
                        Dim icomp As String = dgvdata.Rows(row.Index).Cells(7).Value.ToString
                        Dim idriver As String = dgvdata.Rows(row.Index).Cells(8).Value.ToString
                        Dim iyear As String = dgvdata.Rows(row.Index).Cells(9).Value.ToString
                        Dim imotor As String = dgvdata.Rows(row.Index).Cells(10).Value.ToString
                        Dim ichasis As String = dgvdata.Rows(row.Index).Cells(11).Value.ToString
                        Dim icolor As String = dgvdata.Rows(row.Index).Cells(12).Value.ToString
                        Dim isupp As String = dgvdata.Rows(row.Index).Cells(13).Value.ToString
                        Dim inote As String = dgvdata.Rows(row.Index).Cells(14).Value.ToString
                        Dim irems As String = dgvdata.Rows(row.Index).Cells(15).Value.ToString

                        Dim gnum As String = "1", temp As String = ""
                        sql = "Select Top 1 * from tblgeneral order by genid DESC"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            gnum = Val(dr("genid")) + 1
                        End If
                        cmd.Dispose()
                        dr.Dispose()
                        conn.Close()

                        sql = "Insert into tblgeneral (platenum, vplate, csticker, vtype, makename, bodytype, whsename, company, driver, model, motorno, chasisno, color, supplier, note, remarks, dreason, datecreated, createdby, datemodified, modifiedby, status) values ('" & Trim(iplate) & "', '" & Trim(ivplate) & "', '" & Trim(isticker) & "', '" & Trim(ivtype) & "', '" & Trim(imake) & "', '" & Trim(ibody) & "', '" & Trim(iwhse) & "', '" & Trim(icomp) & "', '" & Trim(idriver) & "', '" & Trim(iyear) & "', '" & Trim(imotor) & "', '" & Trim(ichasis) & "', '" & Trim(icolor) & "', '" & Trim(isupp) & "', '" & Trim(inote) & "', '" & Trim(irems) & "', '', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                        connect()
                        cmd = New SqlCommand(sql, conn) 'New OleDbCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        sql = "Insert into tbldiesel (genid, tanksize, liter, fulltank, twoinch, pwith, pwout, datemodified, modifiedby) values ('" & gnum & "', '', '0', '0', '0', '0', '0', GetDate(), '" & login.cashier & "')"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()
                    Next

                    importcnf = False
                    MsgBox("Successfully Added.", MsgBoxStyle.Information, "")
                    Me.Close()
                End If
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checkvtype()
        Try         'cell 3 upto 7
            'check if category in the datagrid are in the tblcat
            'cells(3)
            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                If dgvdata.Rows(row.Index).Cells(3).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(3).Value = dgvdata.Rows(row.Index).Cells(3).Value.ToString.Replace("'", "")
                End If

                'check if null
                If dgvdata.Rows(row.Index).Cells(3).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(3).ToolTipText = "Vehicle type should not be null."
                    dgvdata.Rows(row.Index).Cells(3).Selected = True
                    dgvdata.Rows(row.Index).Cells(3).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(3).Value.ToString <> "" Then
                    sql = "Select * from tblvtype where vtype='" & dgvdata.Rows(row.Index).Cells(3).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        If dr("status").ToString = "0" Then
                            'gawing tooltip ung mga msgbox
                            'kc iibahin ko nlng ng background color ung cells na may error
                            dgvdata.ClearSelection()
                            dgvdata.Rows(row.Index).Cells(3).ToolTipText = "Vehicle type " & dgvdata.Rows(row.Index).Cells(3).Value.ToString & " status is deactivated."
                            dgvdata.Rows(row.Index).Cells(3).Selected = True
                            dgvdata.Rows(row.Index).Cells(3).Style.BackColor = Color.Yellow
                            dgvdata.ClearSelection()
                            derrors = True
                        Else
                            dgvdata.Rows(row.Index).Cells(3).Value = dr("vtype").ToString
                        End If
                    Else
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(3).ToolTipText = "Cannot found Vehicle type " & dgvdata.Rows(row.Index).Cells(3).Value.ToString & "."
                        dgvdata.Rows(row.Index).Cells(3).Selected = True
                        dgvdata.Rows(row.Index).Cells(3).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Next

            'cells(4)

            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                If dgvdata.Rows(row.Index).Cells(4).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(4).Value = dgvdata.Rows(row.Index).Cells(4).Value.ToString.Replace("'", "")
                End If

                If dgvdata.Rows(row.Index).Cells(4).Value.ToString <> "" Then
                    sql = "Select * from tblmake where makename='" & dgvdata.Rows(row.Index).Cells(4).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        If dr("status").ToString = "0" Then
                            dgvdata.ClearSelection()
                            dgvdata.Rows(row.Index).Cells(4).ToolTipText = "Make name " & dgvdata.Rows(row.Index).Cells(4).Value.ToString & " status is deactivated."
                            dgvdata.Rows(row.Index).Cells(4).Selected = True
                            dgvdata.Rows(row.Index).Cells(4).Style.BackColor = Color.Yellow
                            dgvdata.ClearSelection()
                            derrors = True
                        Else
                            dgvdata.Rows(row.Index).Cells(4).Value = dr("makename").ToString
                        End If
                    Else
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(4).ToolTipText = "Cannot found Make name " & dgvdata.Rows(row.Index).Cells(4).Value.ToString & "."
                        dgvdata.Rows(row.Index).Cells(4).Selected = True
                        dgvdata.Rows(row.Index).Cells(4).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Next

            'cells(5)

            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                If dgvdata.Rows(row.Index).Cells(5).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(5).Value = dgvdata.Rows(row.Index).Cells(5).Value.ToString.Replace("'", "")
                End If

                If dgvdata.Rows(row.Index).Cells(5).Value.ToString <> "" Then
                    sql = "Select * from tblbody where bodytype='" & dgvdata.Rows(row.Index).Cells(5).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        If dr("status").ToString = "0" Then
                            dgvdata.ClearSelection()
                            dgvdata.Rows(row.Index).Cells(5).ToolTipText = "Body type " & dgvdata.Rows(row.Index).Cells(5).Value.ToString & " status is deactivated."
                            dgvdata.Rows(row.Index).Cells(5).Selected = True
                            dgvdata.Rows(row.Index).Cells(5).Style.BackColor = Color.Yellow
                            dgvdata.ClearSelection()
                            derrors = True
                        Else
                            dgvdata.Rows(row.Index).Cells(5).Value = dr("bodytype").ToString
                        End If
                    Else
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(5).ToolTipText = "Cannot found Body type " & dgvdata.Rows(row.Index).Cells(5).Value.ToString & "."
                        dgvdata.Rows(row.Index).Cells(5).Selected = True
                        dgvdata.Rows(row.Index).Cells(5).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Next

            'cells(7)
            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                If dgvdata.Rows(row.Index).Cells(7).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(7).Value = dgvdata.Rows(row.Index).Cells(7).Value.ToString.Replace("'", "")
                End If

                'check if null
                If dgvdata.Rows(row.Index).Cells(7).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(7).ToolTipText = "Company should not be null."
                    dgvdata.Rows(row.Index).Cells(7).Selected = True
                    dgvdata.Rows(row.Index).Cells(7).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(7).Value.ToString <> "" Then
                    sql = "Select * from tblcompany where company='" & dgvdata.Rows(row.Index).Cells(7).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        If dr("status").ToString = "0" Then
                            dgvdata.ClearSelection()
                            dgvdata.Rows(row.Index).Cells(7).ToolTipText = "Company " & dgvdata.Rows(row.Index).Cells(7).Value.ToString & " status is deactivated."
                            dgvdata.Rows(row.Index).Cells(7).Selected = True
                            dgvdata.Rows(row.Index).Cells(7).Style.BackColor = Color.Yellow
                            dgvdata.ClearSelection()
                            derrors = True
                        Else
                            dgvdata.Rows(row.Index).Cells(7).Value = dr("company").ToString
                        End If
                    Else
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(7).ToolTipText = "Cannot found Company " & dgvdata.Rows(row.Index).Cells(7).Value.ToString & "."
                        dgvdata.Rows(row.Index).Cells(7).Selected = True
                        dgvdata.Rows(row.Index).Cells(7).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                End If
            Next

            'cells(6)

            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                If dgvdata.Rows(row.Index).Cells(6).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(6).Value = dgvdata.Rows(row.Index).Cells(6).Value.ToString.Replace("'", "")
                End If

                'check if null
                If dgvdata.Rows(row.Index).Cells(6).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(6).ToolTipText = "Warehouse should not be null."
                    dgvdata.Rows(row.Index).Cells(6).Selected = True
                    dgvdata.Rows(row.Index).Cells(6).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(6).Value.ToString <> "" Then
                    sql = "Select * from tblwhse where whsename='" & dgvdata.Rows(row.Index).Cells(6).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        If dr("status").ToString = "0" Then
                            dgvdata.ClearSelection()
                            dgvdata.Rows(row.Index).Cells(6).ToolTipText = "Warehouse " & dgvdata.Rows(row.Index).Cells(6).Value.ToString & " status is deactivated."
                            dgvdata.Rows(row.Index).Cells(6).Selected = True
                            dgvdata.Rows(row.Index).Cells(6).Style.BackColor = Color.Yellow
                            dgvdata.ClearSelection()
                            derrors = True
                        Else
                            If dgvdata.Rows(row.Index).Cells(7).Value = dr("company").ToString Then
                                dgvdata.Rows(row.Index).Cells(6).Value = dr("whsename").ToString
                            Else
                                dgvdata.ClearSelection()
                                dgvdata.Rows(row.Index).Cells(6).ToolTipText = "Warehouse " & dgvdata.Rows(row.Index).Cells(6).Value.ToString & " cannot found in " & dgvdata.Rows(row.Index).Cells(7).Value.ToString & " company."
                                dgvdata.Rows(row.Index).Cells(6).Selected = True
                                dgvdata.Rows(row.Index).Cells(6).Style.BackColor = Color.Yellow
                                dgvdata.ClearSelection()
                                derrors = True
                            End If
                        End If
                    Else
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(6).ToolTipText = "Cannot found Warehouse " & dgvdata.Rows(row.Index).Cells(6).Value.ToString & "."
                        dgvdata.Rows(row.Index).Cells(6).Selected = True
                        dgvdata.Rows(row.Index).Cells(6).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checkdriver()
        Try

            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                'cells(8)
                If dgvdata.Rows(row.Index).Cells(8).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(8).Value = dgvdata.Rows(row.Index).Cells(8).Value.ToString.Replace("'", "")
                End If
                dgvdata.Rows(row.Index).Cells(8).Value = StrConv(dgvdata.Rows(row.Index).Cells(8).Value.ToString, VbStrConv.ProperCase)

                If dgvdata.Rows(row.Index).Cells(8).Value.ToString <> "" Then
                    sql = "Select * from tbldriver where driver ='" & dgvdata.Rows(row.Index).Cells(8).Value.ToString & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then

                    Else
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(8).ToolTipText = "Cannot found driver " & dgvdata.Rows(row.Index).Cells(8).Value.ToString & "."
                        dgvdata.Rows(row.Index).Cells(8).Selected = True
                        dgvdata.Rows(row.Index).Cells(8).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If

                'cells(12)
                If dgvdata.Rows(row.Index).Cells(12).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(12).Value = dgvdata.Rows(row.Index).Cells(12).Value.ToString.Replace("'", "")
                End If
                dgvdata.Rows(row.Index).Cells(12).Value = StrConv(dgvdata.Rows(row.Index).Cells(12).Value.ToString, VbStrConv.ProperCase)

                'cells(13)
                If dgvdata.Rows(row.Index).Cells(13).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(13).Value = dgvdata.Rows(row.Index).Cells(13).Value.ToString.Replace("'", "")
                End If
                dgvdata.Rows(row.Index).Cells(13).Value = StrConv(dgvdata.Rows(row.Index).Cells(13).Value.ToString, VbStrConv.ProperCase)
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checkyear()
        Try
            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                If dgvdata.Rows(row.Index).Cells(9).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(9).Value = dgvdata.Rows(row.Index).Cells(9).Value.ToString.Replace("'", "")
                End If

                If dgvdata.Rows(row.Index).Cells(9).Value.ToString <> "" Then
                    If IsNumeric(dgvdata.Rows(row.Index).Cells(9).Value) = True Then
                        Dim ymodel As Integer = dgvdata.Rows(row.Index).Cells(9).Value
                        If ymodel >= 1970 Then
                            dgvdata.Rows(row.Index).Cells(9).Value = ymodel
                        Else
                            dgvdata.ClearSelection()
                            dgvdata.Rows(row.Index).Cells(9).ToolTipText = "Invalid Year model."
                            dgvdata.Rows(row.Index).Cells(9).Selected = True
                            dgvdata.Rows(row.Index).Cells(9).Style.BackColor = Color.Yellow
                            dgvdata.ClearSelection()
                            derrors = True
                        End If
                    Else
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(9).ToolTipText = "Year model should be number."
                        dgvdata.Rows(row.Index).Cells(9).Selected = True
                        dgvdata.Rows(row.Index).Cells(9).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    End If
                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checkno()
        Try
            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                'cells(10)
                If dgvdata.Rows(row.Index).Cells(10).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(10).Value = dgvdata.Rows(row.Index).Cells(10).Value.ToString.Replace("'", "")
                End If
                dgvdata.Rows(row.Index).Cells(10).Value = dgvdata.Rows(row.Index).Cells(10).Value.ToString.ToUpper

                'cells(11)
                If dgvdata.Rows(row.Index).Cells(11).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(11).Value = dgvdata.Rows(row.Index).Cells(11).Value.ToString.Replace("'", "")
                End If
                dgvdata.Rows(row.Index).Cells(11).Value = dgvdata.Rows(row.Index).Cells(11).Value.ToString.ToUpper

                'cells(14)
                If dgvdata.Rows(row.Index).Cells(14).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(14).Value = dgvdata.Rows(row.Index).Cells(14).Value.ToString.Replace("'", "")
                End If
                
                'cells(15)
                If dgvdata.Rows(row.Index).Cells(15).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(15).Value = dgvdata.Rows(row.Index).Cells(15).Value.ToString.Replace("'", "")
                End If
            Next


        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class