﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mainmenucreate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle31 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle32 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mainmenucreate))
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.grdorders = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel19 = New System.Windows.Forms.Panel
        Me.cmbcus = New System.Windows.Forms.ComboBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Panel18 = New System.Windows.Forms.Panel
        Me.lbltransid = New System.Windows.Forms.Label
        Me.lbltrnum = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Panel14 = New System.Windows.Forms.Panel
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel17 = New System.Windows.Forms.Panel
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtnotes = New System.Windows.Forms.TextBox
        Me.Panel21 = New System.Windows.Forms.Panel
        Me.datedel = New System.Windows.Forms.DateTimePicker
        Me.Label5 = New System.Windows.Forms.Label
        Me.Panel10 = New System.Windows.Forms.Panel
        Me.btnok = New System.Windows.Forms.Button
        Me.btnvoid = New System.Windows.Forms.Button
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel9 = New System.Windows.Forms.Panel
        Me.txtpo = New System.Windows.Forms.TextBox
        Me.lblpo = New System.Windows.Forms.Label
        Me.txtso = New System.Windows.Forms.TextBox
        Me.lblso = New System.Windows.Forms.Label
        Me.Panel8 = New System.Windows.Forms.Panel
        Me.chkoro = New System.Windows.Forms.CheckBox
        Me.chkso = New System.Windows.Forms.CheckBox
        Me.chkagi = New System.Windows.Forms.CheckBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.cmbtype = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.cmbtrans = New System.Windows.Forms.ComboBox
        Me.cmbpick = New System.Windows.Forms.ComboBox
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.imgbox = New System.Windows.Forms.PictureBox
        Me.btnimgremove = New System.Windows.Forms.Button
        Me.btnimgcancel = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btnview = New System.Windows.Forms.Button
        Me.imgbox2 = New System.Windows.Forms.PictureBox
        Me.imgbox22 = New System.Windows.Forms.PictureBox
        Me.btncancel = New System.Windows.Forms.Button
        Me.imgbox222 = New System.Windows.Forms.PictureBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.imgbox1 = New System.Windows.Forms.PictureBox
        Me.imgbox11 = New System.Windows.Forms.PictureBox
        Me.imgbox111 = New System.Windows.Forms.PictureBox
        Me.btnattachpo = New System.Windows.Forms.Button
        Me.btnattachso = New System.Windows.Forms.Button
        Me.btnimgrefresh = New System.Windows.Forms.Button
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel7 = New System.Windows.Forms.Panel
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel15 = New System.Windows.Forms.Panel
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Panel16 = New System.Windows.Forms.Panel
        Me.RadioButton3 = New System.Windows.Forms.RadioButton
        Me.RadioButton4 = New System.Windows.Forms.RadioButton
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.cmbcustemp = New System.Windows.Forms.ComboBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Panel1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.grdorders, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.imgbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.imgbox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgbox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgbox222, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.imgbox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgbox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgbox111, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.AutoScroll = True
        Me.Panel1.Controls.Add(Me.TableLayoutPanel1)
        Me.Panel1.Location = New System.Drawing.Point(5, 1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1252, 645)
        Me.Panel1.TabIndex = 1
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 1.045556!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 98.95444!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 623.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel3, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel6, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel2, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel4, 2, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 5)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.77972!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.22029!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1245, 631)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel3.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel3.Controls.Add(Me.grdorders)
        Me.Panel3.Controls.Add(Me.TableLayoutPanel5)
        Me.Panel3.Location = New System.Drawing.Point(9, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(609, 428)
        Me.Panel3.TabIndex = 1
        '
        'grdorders
        '
        Me.grdorders.AllowUserToAddRows = False
        Me.grdorders.AllowUserToResizeRows = False
        DataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdorders.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle25
        Me.grdorders.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdorders.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle26.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdorders.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle26
        Me.grdorders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdorders.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18})
        DataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle31.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle31.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle31.Format = "N2"
        DataGridViewCellStyle31.NullValue = Nothing
        DataGridViewCellStyle31.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdorders.DefaultCellStyle = DataGridViewCellStyle31
        Me.grdorders.Location = New System.Drawing.Point(3, 63)
        Me.grdorders.Name = "grdorders"
        Me.grdorders.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle32.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle32.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdorders.RowHeadersDefaultCellStyle = DataGridViewCellStyle32
        Me.grdorders.RowHeadersWidth = 10
        Me.grdorders.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.grdorders.Size = New System.Drawing.Size(603, 357)
        Me.grdorders.TabIndex = 15
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox
        Me.DataGridViewTextBoxColumn13.DropDownWidth = 250
        Me.DataGridViewTextBoxColumn13.HeaderText = "Description"
        Me.DataGridViewTextBoxColumn13.MinimumWidth = 160
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn13.Width = 280
        '
        'DataGridViewTextBoxColumn14
        '
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn14.DefaultCellStyle = DataGridViewCellStyle27
        Me.DataGridViewTextBoxColumn14.HeaderText = "Qty"
        Me.DataGridViewTextBoxColumn14.MinimumWidth = 80
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn14.Width = 80
        '
        'DataGridViewTextBoxColumn15
        '
        DataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn15.DefaultCellStyle = DataGridViewCellStyle28
        Me.DataGridViewTextBoxColumn15.HeaderText = "Price"
        Me.DataGridViewTextBoxColumn15.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'DataGridViewTextBoxColumn16
        '
        DataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn16.DefaultCellStyle = DataGridViewCellStyle29
        Me.DataGridViewTextBoxColumn16.HeaderText = "Discount %"
        Me.DataGridViewTextBoxColumn16.MinimumWidth = 90
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn16.Visible = False
        Me.DataGridViewTextBoxColumn16.Width = 90
        '
        'DataGridViewTextBoxColumn17
        '
        DataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn17.DefaultCellStyle = DataGridViewCellStyle30
        Me.DataGridViewTextBoxColumn17.HeaderText = "Amount"
        Me.DataGridViewTextBoxColumn17.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn17.Width = 120
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "Request"
        Me.DataGridViewTextBoxColumn18.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn18.Visible = False
        Me.DataGridViewTextBoxColumn18.Width = 120
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel5.BackColor = System.Drawing.Color.LightGray
        Me.TableLayoutPanel5.ColumnCount = 2
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.38617!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.61383!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.Panel19, 1, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Panel18, 0, 0)
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 1
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(603, 57)
        Me.TableLayoutPanel5.TabIndex = 10
        '
        'Panel19
        '
        Me.Panel19.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel19.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel19.Controls.Add(Me.cmbcus)
        Me.Panel19.Controls.Add(Me.Label13)
        Me.Panel19.Location = New System.Drawing.Point(288, 3)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(312, 51)
        Me.Panel19.TabIndex = 0
        '
        'cmbcus
        '
        Me.cmbcus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbcus.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.cmbcus.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbcus.FormattingEnabled = True
        Me.cmbcus.Location = New System.Drawing.Point(7, 24)
        Me.cmbcus.Name = "cmbcus"
        Me.cmbcus.Size = New System.Drawing.Size(302, 24)
        Me.cmbcus.TabIndex = 5
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(4, 4)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(79, 16)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "RECIPIENT:"
        '
        'Panel18
        '
        Me.Panel18.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel18.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel18.Controls.Add(Me.lbltransid)
        Me.Panel18.Controls.Add(Me.lbltrnum)
        Me.Panel18.Controls.Add(Me.Label3)
        Me.Panel18.Location = New System.Drawing.Point(3, 3)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(279, 51)
        Me.Panel18.TabIndex = 2
        '
        'lbltransid
        '
        Me.lbltransid.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltransid.Location = New System.Drawing.Point(223, 4)
        Me.lbltransid.Name = "lbltransid"
        Me.lbltransid.Size = New System.Drawing.Size(116, 16)
        Me.lbltransid.TabIndex = 35
        Me.lbltransid.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbltrnum
        '
        Me.lbltrnum.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbltrnum.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold)
        Me.lbltrnum.Location = New System.Drawing.Point(12, 25)
        Me.lbltrnum.Name = "lbltrnum"
        Me.lbltrnum.Size = New System.Drawing.Size(258, 18)
        Me.lbltrnum.TabIndex = 34
        Me.lbltrnum.Text = "0000"
        Me.lbltrnum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 4)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 16)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "TRANSACTION #:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel2.Controls.Add(Me.Panel14)
        Me.Panel2.Location = New System.Drawing.Point(3, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1, 428)
        Me.Panel2.TabIndex = 0
        '
        'Panel14
        '
        Me.Panel14.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel14.AutoScroll = True
        Me.Panel14.Location = New System.Drawing.Point(9, 12)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(0, 405)
        Me.Panel14.TabIndex = 27
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.BackColor = System.Drawing.Color.LightGray
        Me.TableLayoutPanel6.ColumnCount = 2
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.22824!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70.77176!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel6.Controls.Add(Me.Panel17, 1, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.Panel21, 0, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.Panel10, 1, 1)
        Me.TableLayoutPanel6.Controls.Add(Me.Panel5, 0, 1)
        Me.TableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(9, 437)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 2
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 115.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(609, 191)
        Me.TableLayoutPanel6.TabIndex = 11
        '
        'Panel17
        '
        Me.Panel17.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel17.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel17.Controls.Add(Me.cmbcustemp)
        Me.Panel17.Controls.Add(Me.Label8)
        Me.Panel17.Location = New System.Drawing.Point(180, 3)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(426, 70)
        Me.Panel17.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label4.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold)
        Me.Label4.Location = New System.Drawing.Point(0, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 109)
        Me.Label4.TabIndex = 37
        Me.Label4.Text = "NOTES:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtnotes
        '
        Me.txtnotes.Dock = System.Windows.Forms.DockStyle.Right
        Me.txtnotes.Location = New System.Drawing.Point(95, 0)
        Me.txtnotes.Multiline = True
        Me.txtnotes.Name = "txtnotes"
        Me.txtnotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtnotes.Size = New System.Drawing.Size(331, 109)
        Me.txtnotes.TabIndex = 36
        '
        'Panel21
        '
        Me.Panel21.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel21.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel21.Controls.Add(Me.datedel)
        Me.Panel21.Controls.Add(Me.Label5)
        Me.Panel21.Location = New System.Drawing.Point(3, 3)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(171, 70)
        Me.Panel21.TabIndex = 2
        '
        'datedel
        '
        Me.datedel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.datedel.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datedel.Location = New System.Drawing.Point(21, 33)
        Me.datedel.MinDate = New Date(2017, 1, 1, 0, 0, 0, 0)
        Me.datedel.Name = "datedel"
        Me.datedel.Size = New System.Drawing.Size(135, 26)
        Me.datedel.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(6, 13)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(87, 16)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "BOOK DATE:"
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.White
        Me.Panel10.Controls.Add(Me.txtnotes)
        Me.Panel10.Controls.Add(Me.Label4)
        Me.Panel10.Controls.Add(Me.btnvoid)
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel10.Location = New System.Drawing.Point(180, 79)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(426, 109)
        Me.Panel10.TabIndex = 3
        '
        'btnok
        '
        Me.btnok.BackColor = System.Drawing.Color.SkyBlue
        Me.btnok.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnok.Font = New System.Drawing.Font("Arial Black", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnok.Location = New System.Drawing.Point(0, 0)
        Me.btnok.Name = "btnok"
        Me.btnok.Size = New System.Drawing.Size(171, 109)
        Me.btnok.TabIndex = 22
        Me.btnok.Text = "OK"
        Me.btnok.UseVisualStyleBackColor = False
        '
        'btnvoid
        '
        Me.btnvoid.BackColor = System.Drawing.Color.SkyBlue
        Me.btnvoid.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnvoid.Location = New System.Drawing.Point(-130, 6)
        Me.btnvoid.Name = "btnvoid"
        Me.btnvoid.Size = New System.Drawing.Size(69, 62)
        Me.btnvoid.TabIndex = 16
        Me.btnvoid.Text = "VOID"
        Me.btnvoid.UseVisualStyleBackColor = False
        Me.btnvoid.Visible = False
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.BackColor = System.Drawing.Color.LightGray
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.04731!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.95269!))
        Me.TableLayoutPanel2.Controls.Add(Me.Panel9, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel8, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(624, 437)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(618, 191)
        Me.TableLayoutPanel2.TabIndex = 8
        '
        'Panel9
        '
        Me.Panel9.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel9.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel9.Controls.Add(Me.txtpo)
        Me.Panel9.Controls.Add(Me.lblpo)
        Me.Panel9.Controls.Add(Me.txtso)
        Me.Panel9.Controls.Add(Me.lblso)
        Me.Panel9.Location = New System.Drawing.Point(417, 3)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(198, 185)
        Me.Panel9.TabIndex = 1
        '
        'txtpo
        '
        Me.txtpo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtpo.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtpo.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtpo.Enabled = False
        Me.txtpo.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold)
        Me.txtpo.Location = New System.Drawing.Point(3, 118)
        Me.txtpo.Name = "txtpo"
        Me.txtpo.Size = New System.Drawing.Size(192, 18)
        Me.txtpo.TabIndex = 45
        Me.txtpo.Text = "0000"
        Me.txtpo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblpo
        '
        Me.lblpo.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold)
        Me.lblpo.Location = New System.Drawing.Point(1, 97)
        Me.lblpo.Name = "lblpo"
        Me.lblpo.Size = New System.Drawing.Size(50, 20)
        Me.lblpo.TabIndex = 44
        Me.lblpo.Text = "PO#"
        Me.lblpo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtso
        '
        Me.txtso.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtso.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtso.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtso.Enabled = False
        Me.txtso.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold)
        Me.txtso.Location = New System.Drawing.Point(3, 29)
        Me.txtso.Name = "txtso"
        Me.txtso.Size = New System.Drawing.Size(192, 18)
        Me.txtso.TabIndex = 43
        Me.txtso.Text = "0000"
        Me.txtso.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblso
        '
        Me.lblso.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold)
        Me.lblso.Location = New System.Drawing.Point(1, 5)
        Me.lblso.Name = "lblso"
        Me.lblso.Size = New System.Drawing.Size(50, 20)
        Me.lblso.TabIndex = 2
        Me.lblso.Text = "SO#"
        Me.lblso.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel8
        '
        Me.Panel8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel8.Controls.Add(Me.chkoro)
        Me.Panel8.Controls.Add(Me.chkso)
        Me.Panel8.Controls.Add(Me.chkagi)
        Me.Panel8.Controls.Add(Me.Label7)
        Me.Panel8.Controls.Add(Me.cmbtype)
        Me.Panel8.Controls.Add(Me.Label6)
        Me.Panel8.Controls.Add(Me.cmbtrans)
        Me.Panel8.Controls.Add(Me.cmbpick)
        Me.Panel8.Location = New System.Drawing.Point(3, 3)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(408, 185)
        Me.Panel8.TabIndex = 0
        '
        'chkoro
        '
        Me.chkoro.AutoSize = True
        Me.chkoro.Enabled = False
        Me.chkoro.Location = New System.Drawing.Point(73, 157)
        Me.chkoro.Name = "chkoro"
        Me.chkoro.Size = New System.Drawing.Size(209, 17)
        Me.chkoro.TabIndex = 64
        Me.chkoro.Text = "Trucking only for Oro Allado Customers"
        Me.chkoro.UseVisualStyleBackColor = True
        '
        'chkso
        '
        Me.chkso.AutoSize = True
        Me.chkso.Location = New System.Drawing.Point(73, 134)
        Me.chkso.Name = "chkso"
        Me.chkso.Size = New System.Drawing.Size(132, 17)
        Me.chkso.TabIndex = 63
        Me.chkso.Text = "NO SO Direct DR only"
        Me.chkso.UseVisualStyleBackColor = True
        '
        'chkagi
        '
        Me.chkagi.AutoSize = True
        Me.chkagi.Enabled = False
        Me.chkagi.Location = New System.Drawing.Point(73, 111)
        Me.chkagi.Name = "chkagi"
        Me.chkagi.Size = New System.Drawing.Size(178, 17)
        Me.chkagi.TabIndex = 62
        Me.chkagi.Text = "Trucking only for AGI Customers"
        Me.chkagi.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold)
        Me.Label7.Location = New System.Drawing.Point(29, 82)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(118, 18)
        Me.Label7.TabIndex = 60
        Me.Label7.Text = "PICK UP FROM"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmbtype
        '
        Me.cmbtype.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.cmbtype.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbtype.FormattingEnabled = True
        Me.cmbtype.Items.AddRange(New Object() {"", "JPSC STOCK TRANSFER PICKUP", "JPSC STOCK TRANSFER WHSE TO WHSE", "JPSC SALES TRANSACTION", "JPSC SALES TRANSACTION PICKUP", "CUSTOMER SALES TRANSACTION WHSE", "CUSTOMER SALES TRANSACTION PICKUP", "TRUCKING STOCK TRANSFER PICKUP", "TRUCKING STOCK TRANSFER WHSE TO WHSE", "TRUCKING SALES TRANSACTION WHSE", "TRUCKING SALES TRANSACTION PICKUP"})
        Me.cmbtype.Location = New System.Drawing.Point(32, 41)
        Me.cmbtype.Margin = New System.Windows.Forms.Padding(3, 10, 3, 10)
        Me.cmbtype.Name = "cmbtype"
        Me.cmbtype.Size = New System.Drawing.Size(347, 24)
        Me.cmbtype.TabIndex = 59
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold)
        Me.Label6.Location = New System.Drawing.Point(9, 6)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(308, 20)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "Transaction Type:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmbtrans
        '
        Me.cmbtrans.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbtrans.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.cmbtrans.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbtrans.FormattingEnabled = True
        Me.cmbtrans.Items.AddRange(New Object() {"", "SALES TRANSACTION", "CUSTOMER DIRECT PICKUP FRM WHSE", "JPSC DIRECT PICKUP FRM AGI", "CUSTOMER DIRECT PICKUP FRM AGI", "STOCK TRANSFER PICKUP FRM AGI", "STOCK TRANSFER WHSE TO WHSE", "STOCK TRANSFER PICKUP FRM PIER", "JPSC DIRECT PICKUP FRM PIER", "CUSTOMER DIRECT PICKUP FRM PIER", "TRUCKING DIRECT PICKUP FRM PIER"})
        Me.cmbtrans.Location = New System.Drawing.Point(146, 3)
        Me.cmbtrans.Margin = New System.Windows.Forms.Padding(3, 10, 3, 10)
        Me.cmbtrans.Name = "cmbtrans"
        Me.cmbtrans.Size = New System.Drawing.Size(10, 24)
        Me.cmbtrans.TabIndex = 50
        Me.cmbtrans.Visible = False
        '
        'cmbpick
        '
        Me.cmbpick.Enabled = False
        Me.cmbpick.Font = New System.Drawing.Font("Arial", 9.75!)
        Me.cmbpick.FormattingEnabled = True
        Me.cmbpick.Items.AddRange(New Object() {"", "AGI", "PIER", "WHSE"})
        Me.cmbpick.Location = New System.Drawing.Point(153, 78)
        Me.cmbpick.Name = "cmbpick"
        Me.cmbpick.Size = New System.Drawing.Size(226, 24)
        Me.cmbpick.TabIndex = 60
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.GroupBox5)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(624, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(618, 428)
        Me.Panel4.TabIndex = 12
        '
        'GroupBox5
        '
        Me.GroupBox5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox5.Controls.Add(Me.GroupBox4)
        Me.GroupBox5.Controls.Add(Me.GroupBox2)
        Me.GroupBox5.Controls.Add(Me.GroupBox1)
        Me.GroupBox5.Controls.Add(Me.btnattachpo)
        Me.GroupBox5.Controls.Add(Me.btnattachso)
        Me.GroupBox5.Controls.Add(Me.btnimgrefresh)
        Me.GroupBox5.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(617, 428)
        Me.GroupBox5.TabIndex = 1
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Photos"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.imgbox)
        Me.GroupBox4.Controls.Add(Me.btnimgremove)
        Me.GroupBox4.Controls.Add(Me.btnimgcancel)
        Me.GroupBox4.Location = New System.Drawing.Point(15, 328)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(331, 93)
        Me.GroupBox4.TabIndex = 74
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Selected Photo"
        '
        'imgbox
        '
        Me.imgbox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.imgbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox.Location = New System.Drawing.Point(26, 19)
        Me.imgbox.Name = "imgbox"
        Me.imgbox.Size = New System.Drawing.Size(85, 64)
        Me.imgbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox.TabIndex = 62
        Me.imgbox.TabStop = False
        '
        'btnimgremove
        '
        Me.btnimgremove.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgremove.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove.Image = CType(resources.GetObject("btnimgremove.Image"), System.Drawing.Image)
        Me.btnimgremove.Location = New System.Drawing.Point(127, 19)
        Me.btnimgremove.Name = "btnimgremove"
        Me.btnimgremove.Size = New System.Drawing.Size(85, 64)
        Me.btnimgremove.TabIndex = 60
        Me.btnimgremove.Text = "Remove"
        Me.btnimgremove.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove.UseVisualStyleBackColor = True
        '
        'btnimgcancel
        '
        Me.btnimgcancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgcancel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel.Image = CType(resources.GetObject("btnimgcancel.Image"), System.Drawing.Image)
        Me.btnimgcancel.Location = New System.Drawing.Point(218, 19)
        Me.btnimgcancel.Name = "btnimgcancel"
        Me.btnimgcancel.Size = New System.Drawing.Size(85, 64)
        Me.btnimgcancel.TabIndex = 61
        Me.btnimgcancel.Text = "Cancel"
        Me.btnimgcancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.btnview)
        Me.GroupBox2.Controls.Add(Me.imgbox2)
        Me.GroupBox2.Controls.Add(Me.imgbox22)
        Me.GroupBox2.Controls.Add(Me.btncancel)
        Me.GroupBox2.Controls.Add(Me.imgbox222)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.GroupBox2.Location = New System.Drawing.Point(15, 168)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(589, 155)
        Me.GroupBox2.TabIndex = 73
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "PO"
        '
        'btnview
        '
        Me.btnview.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnview.BackColor = System.Drawing.Color.SkyBlue
        Me.btnview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnview.Location = New System.Drawing.Point(475, 90)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(108, 62)
        Me.btnview.TabIndex = 46
        Me.btnview.Text = "VIEW ALL TRANSACTION"
        Me.btnview.UseVisualStyleBackColor = False
        Me.btnview.Visible = False
        '
        'imgbox2
        '
        Me.imgbox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox2.Location = New System.Drawing.Point(26, 22)
        Me.imgbox2.Name = "imgbox2"
        Me.imgbox2.Size = New System.Drawing.Size(155, 130)
        Me.imgbox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox2.TabIndex = 49
        Me.imgbox2.TabStop = False
        '
        'imgbox22
        '
        Me.imgbox22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox22.Location = New System.Drawing.Point(196, 22)
        Me.imgbox22.Name = "imgbox22"
        Me.imgbox22.Size = New System.Drawing.Size(155, 130)
        Me.imgbox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox22.TabIndex = 69
        Me.imgbox22.TabStop = False
        '
        'btncancel
        '
        Me.btncancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncancel.BackColor = System.Drawing.Color.SkyBlue
        Me.btncancel.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.Location = New System.Drawing.Point(359, 89)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(111, 60)
        Me.btncancel.TabIndex = 17
        Me.btncancel.Text = "CANCEL TRANSACTION"
        Me.btncancel.UseVisualStyleBackColor = False
        Me.btncancel.Visible = False
        '
        'imgbox222
        '
        Me.imgbox222.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox222.Location = New System.Drawing.Point(365, 22)
        Me.imgbox222.Name = "imgbox222"
        Me.imgbox222.Size = New System.Drawing.Size(155, 130)
        Me.imgbox222.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox222.TabIndex = 70
        Me.imgbox222.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.imgbox1)
        Me.GroupBox1.Controls.Add(Me.imgbox11)
        Me.GroupBox1.Controls.Add(Me.imgbox111)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(15, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(589, 155)
        Me.GroupBox1.TabIndex = 72
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "SO"
        '
        'imgbox1
        '
        Me.imgbox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox1.Location = New System.Drawing.Point(26, 19)
        Me.imgbox1.Name = "imgbox1"
        Me.imgbox1.Size = New System.Drawing.Size(155, 130)
        Me.imgbox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox1.TabIndex = 48
        Me.imgbox1.TabStop = False
        '
        'imgbox11
        '
        Me.imgbox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox11.Location = New System.Drawing.Point(196, 19)
        Me.imgbox11.Name = "imgbox11"
        Me.imgbox11.Size = New System.Drawing.Size(155, 130)
        Me.imgbox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox11.TabIndex = 67
        Me.imgbox11.TabStop = False
        '
        'imgbox111
        '
        Me.imgbox111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox111.Location = New System.Drawing.Point(365, 19)
        Me.imgbox111.Name = "imgbox111"
        Me.imgbox111.Size = New System.Drawing.Size(155, 130)
        Me.imgbox111.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox111.TabIndex = 68
        Me.imgbox111.TabStop = False
        '
        'btnattachpo
        '
        Me.btnattachpo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnattachpo.BackColor = System.Drawing.Color.SkyBlue
        Me.btnattachpo.Enabled = False
        Me.btnattachpo.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnattachpo.Location = New System.Drawing.Point(469, 341)
        Me.btnattachpo.Name = "btnattachpo"
        Me.btnattachpo.Size = New System.Drawing.Size(101, 72)
        Me.btnattachpo.TabIndex = 48
        Me.btnattachpo.Text = "ATTACH PO"
        Me.btnattachpo.UseVisualStyleBackColor = False
        '
        'btnattachso
        '
        Me.btnattachso.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnattachso.BackColor = System.Drawing.Color.SkyBlue
        Me.btnattachso.Enabled = False
        Me.btnattachso.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnattachso.Location = New System.Drawing.Point(362, 341)
        Me.btnattachso.Name = "btnattachso"
        Me.btnattachso.Size = New System.Drawing.Size(101, 72)
        Me.btnattachso.TabIndex = 47
        Me.btnattachso.Text = "ATTACH SO"
        Me.btnattachso.UseVisualStyleBackColor = False
        '
        'btnimgrefresh
        '
        Me.btnimgrefresh.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgrefresh.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh.Image = CType(resources.GetObject("btnimgrefresh.Image"), System.Drawing.Image)
        Me.btnimgrefresh.Location = New System.Drawing.Point(375, 492)
        Me.btnimgrefresh.Name = "btnimgrefresh"
        Me.btnimgrefresh.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh.TabIndex = 66
        Me.btnimgrefresh.Text = "Refresh"
        Me.btnimgrefresh.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel3.BackColor = System.Drawing.Color.LightGray
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.97906!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.02094!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.Panel6, 1, 0)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(200, 100)
        Me.TableLayoutPanel3.TabIndex = 0
        '
        'Panel6
        '
        Me.Panel6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel6.Controls.Add(Me.TextBox1)
        Me.Panel6.Controls.Add(Me.Label1)
        Me.Panel6.Location = New System.Drawing.Point(108, 3)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(89, 94)
        Me.Panel6.TabIndex = 1
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold)
        Me.TextBox1.Location = New System.Drawing.Point(77, 21)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(198, 20)
        Me.TextBox1.TabIndex = 43
        Me.TextBox1.Text = "0000"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 94)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "SO#:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Panel7
        '
        Me.Panel7.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel7.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel7.Controls.Add(Me.RadioButton1)
        Me.Panel7.Controls.Add(Me.RadioButton2)
        Me.Panel7.Location = New System.Drawing.Point(3, 3)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(322, 63)
        Me.Panel7.TabIndex = 0
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.RadioButton1.Location = New System.Drawing.Point(181, 21)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(171, 24)
        Me.RadioButton1.TabIndex = 45
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "STOCK TRANSFER"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.RadioButton2.Location = New System.Drawing.Point(15, 21)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(197, 24)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "SALES TRANSACTION"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel4.BackColor = System.Drawing.Color.LightGray
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.97906!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.02094!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.Panel15, 1, 0)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 1
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(200, 100)
        Me.TableLayoutPanel4.TabIndex = 0
        '
        'Panel15
        '
        Me.Panel15.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel15.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel15.Controls.Add(Me.TextBox2)
        Me.Panel15.Controls.Add(Me.Label2)
        Me.Panel15.Location = New System.Drawing.Point(108, 3)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(89, 94)
        Me.Panel15.TabIndex = 1
        '
        'TextBox2
        '
        Me.TextBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold)
        Me.TextBox2.Location = New System.Drawing.Point(77, 21)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(0, 20)
        Me.TextBox2.TabIndex = 43
        Me.TextBox2.Text = "0000"
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label2.Location = New System.Drawing.Point(0, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 94)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "SO#:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Panel16
        '
        Me.Panel16.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel16.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel16.Controls.Add(Me.RadioButton3)
        Me.Panel16.Controls.Add(Me.RadioButton4)
        Me.Panel16.Location = New System.Drawing.Point(3, 3)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(46, 88)
        Me.Panel16.TabIndex = 0
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.RadioButton3.Location = New System.Drawing.Point(181, 21)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(171, 24)
        Me.RadioButton3.TabIndex = 45
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "STOCK TRANSFER"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.RadioButton4.Location = New System.Drawing.Point(15, 21)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(197, 24)
        Me.RadioButton4.TabIndex = 1
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "SALES TRANSACTION"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.btnok)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(3, 79)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(171, 109)
        Me.Panel5.TabIndex = 4
        '
        'cmbcustemp
        '
        Me.cmbcustemp.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbcustemp.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.cmbcustemp.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbcustemp.FormattingEnabled = True
        Me.cmbcustemp.Location = New System.Drawing.Point(41, 33)
        Me.cmbcustemp.Name = "cmbcustemp"
        Me.cmbcustemp.Size = New System.Drawing.Size(290, 24)
        Me.cmbcustemp.TabIndex = 7
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(20, 13)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(149, 16)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "SPECIFIC CUSTOMER:"
        '
        'mainmenucreate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1269, 653)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "mainmenucreate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Create Order"
        Me.Panel1.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        CType(Me.grdorders, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.imgbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.imgbox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgbox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgbox222, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.imgbox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgbox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgbox111, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents btnok As System.Windows.Forms.Button
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btnvoid As System.Windows.Forms.Button
    Friend WithEvents btnview As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents txtso As System.Windows.Forms.TextBox
    Friend WithEvents lblso As System.Windows.Forms.Label
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel5 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel19 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel15 As System.Windows.Forms.Panel
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lbltrnum As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtnotes As System.Windows.Forms.TextBox
    Friend WithEvents btnattachso As System.Windows.Forms.Button
    Friend WithEvents imgbox1 As System.Windows.Forms.PictureBox
    Friend WithEvents cmbcus As System.Windows.Forms.ComboBox
    Friend WithEvents TableLayoutPanel6 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents Panel21 As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents datedel As System.Windows.Forms.DateTimePicker
    Friend WithEvents imgbox2 As System.Windows.Forms.PictureBox
    Friend WithEvents txtpo As System.Windows.Forms.TextBox
    Friend WithEvents lblpo As System.Windows.Forms.Label
    Friend WithEvents btnattachpo As System.Windows.Forms.Button
    Friend WithEvents grdorders As System.Windows.Forms.DataGridView
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents imgbox As System.Windows.Forms.PictureBox
    Friend WithEvents btnimgremove As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh As System.Windows.Forms.Button
    Friend WithEvents imgbox111 As System.Windows.Forms.PictureBox
    Friend WithEvents imgbox11 As System.Windows.Forms.PictureBox
    Friend WithEvents imgbox222 As System.Windows.Forms.PictureBox
    Friend WithEvents imgbox22 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbtrans As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbpick As System.Windows.Forms.ComboBox
    Friend WithEvents cmbtype As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents lbltransid As System.Windows.Forms.Label
    Friend WithEvents chkagi As System.Windows.Forms.CheckBox
    Friend WithEvents chkso As System.Windows.Forms.CheckBox
    Friend WithEvents chkoro As System.Windows.Forms.CheckBox
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents cmbcustemp As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
End Class
