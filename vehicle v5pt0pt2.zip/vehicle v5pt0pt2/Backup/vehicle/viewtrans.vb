﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.ComponentModel

Public Class viewtrans
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Dim ofd As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim pic As PictureBox, meronstp1 As Boolean = False, frmload As Boolean = False
    Dim culture As CultureInfo = Nothing
    Dim bgw As BackgroundWorker, threadEnabled As Boolean = False, panelsql As String
    Dim wid As Int32, widlbl As Int32
    Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer
    Public sing As Boolean

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub viewtrans_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        grouptrans.Visible = True
        lbltripnum.Text = ""
        txtdateadded.Text = ""
        imgbox1.Image = Nothing
        imgbox2.Image = Nothing

        grdtrans.Rows.Clear()
        imgpanel1.Visible = False
        imgpanel1.Controls.Clear()
        imgpanel1.Visible = True
        sing = False
    End Sub

    Private Sub viewtrans_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        frmload = True
        view()
        refimg()
    End Sub

    Public Sub view()
        Try
            grdorders.Rows.Clear()

            sql = "Select * from tblortrans where transnum='" & txttrans.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                txtref.Text = dr("refnum")
                txttype.Text = dr("transtype")
                txtdes.Text = dr("customer")
                If dr("cancel") = 1 Then
                    txtstatus.Text = "Cancelled"
                ElseIf dr("status") = 1 Then
                    txtstatus.Text = "Available"
                ElseIf dr("status") = 0 Then
                    txtstatus.Text = "In Process"
                ElseIf dr("status") = 2 Then
                    'MsgBox(dr("status").ToString & dr("transnum").ToString)
                    txtstatus.Text = "Completed"
                End If
                txtbook.Text = Format(dr("deliverydate"), "yyyy/MM/dd")
                txtcreate.Text = dr("createdby")
                txtnotes.Text = dr("notes")
                If IsDBNull(dr("datecreated")) = False Then
                    txtdatecreated.Text = Format(dr("datecreated"), "yyyy/MM/dd HH:mm")
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If Me.Text <> "View Transaction" Or lbltripnum.Text <> "" Then
                Label8.Visible = True
                txtdateadded.Visible = True
                Label9.Location = New System.Drawing.Point(463, 97)
                txtstatus.Location = New System.Drawing.Point(514, 94)

                sql = "Select * from tbltripitems where tripnum='" & lbltripnum.Text & "' and transnum='" & txttrans.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    If IsDBNull(dr("datecreated")) = False Then
                        txtdateadded.Text = Format(dr("datecreated"), "yyyy/MM/dd HH:mm")
                        If dr("status") = 0 Then
                            txtstatus.Text = "Cancelled"
                        ElseIf dr("status") = 1 Then
                            txtstatus.Text = "In Process"
                        ElseIf dr("status") = 2 Then
                            txtstatus.Text = "Completed"
                        ElseIf dr("status") = 3 Then
                            txtstatus.Text = "Remove"
                        ElseIf dr("status") = 4 Then
                            txtstatus.Text = "Rescheduled"
                        ElseIf dr("status") = 5 Then
                            txtstatus.Text = "AR Credit Memo"
                        End If
                    End If
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Else
                Label8.Visible = False
                txtdateadded.Visible = False
                Label9.Location = New System.Drawing.Point(463, 70)
                txtstatus.Location = New System.Drawing.Point(514, 67)
            End If

            sql = "Select * from tblorder where transnum='" & txttrans.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grdorders.Rows.Add(dr("itemname"), dr("qty"), dr("price"), dr("dscnt"), dr("totalprice"), dr("request"), True)

                Dim checkCell As DataGridViewCheckBoxCell = CType(grdorders.Rows(grdorders.RowCount - 1).Cells(6), DataGridViewCheckBoxCell)
                If dr("free") <> 0 Then
                    checkCell.Value = True
                Else
                    checkCell.Value = False
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            imgbox1.Image = Nothing
            Dim ctr As Integer = 0
            sql = "Select * from tblorimage where transnum='" & txttrans.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                'MsgBox(dr("name").ToString)
                ctr += 1

                If txttype.Text = "SALES TRANSACTION" Then
                    Dim data As Byte() = DirectCast(dr("img"), Byte())
                    Dim ms As New MemoryStream(data)

                    imgbox1.Image = Image.FromStream(ms)
                    imgbox1.SizeMode = PictureBoxSizeMode.Zoom

                ElseIf txttype.Text = "STOCK TRANSFER" Then
                    Dim data As Byte() = DirectCast(dr("img"), Byte())
                    Dim ms As New MemoryStream(data)

                    imgbox2.Image = Image.FromStream(ms)
                    imgbox2.SizeMode = PictureBoxSizeMode.Zoom

                Else
                    If ctr = 1 Then
                        Dim data As Byte() = DirectCast(dr("img"), Byte())
                        Dim ms As New MemoryStream(data)

                        imgbox1.Image = Image.FromStream(ms)
                        imgbox1.SizeMode = PictureBoxSizeMode.Zoom
                    Else
                        Dim data As Byte() = DirectCast(dr("img"), Byte())
                        Dim ms As New MemoryStream(data)

                        imgbox2.Image = Image.FromStream(ms)
                        imgbox2.SizeMode = PictureBoxSizeMode.Zoom
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub imgbox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles imgbox1.Click
        If imgbox1.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox1.Image
            viewimage.ShowDialog()
        End If
    End Sub

    Private Sub grdtrans_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans.CellClick
        If grdtrans.Rows.Count > -1 Then
            frmload = False
            txttrans.Text = grdtrans.Rows(grdtrans.CurrentRow.Index).Cells(0).Value
            view()
            refimg()
        End If
    End Sub

    Private Sub grdtrans_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdtrans.SelectionChanged
        
    End Sub

    Private Sub imgbox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles imgbox2.Click
        If imgbox2.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox2.Image
            viewimage.ShowDialog()
        End If
    End Sub

    Public Sub refimg()
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label

            meronstp1 = False
            imgpanel1.Visible = False
            imgpanel1.Controls.Clear()
            imgpanel1.Visible = True

            wid = 0
            widlbl = 0
            temp = 0
            y = 0
            mody = 0
            row = 0

            Dim ctr As Integer = 0

            panelsql = "Select * from tblorimage where transnum='" & txttrans.Text & "'"

            bgw = New BackgroundWorker()

            AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
            AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not bgw.IsBusy Then
                lblloading.Visible = True
                '/Panel1.Enabled = False
                '/ProgressBar1.Visible = True
                '/ProgressBar1.Minimum = 0
                bgw.WorkerReportsProgress = True
                bgw.WorkerSupportsCancellation = True
                bgw.RunWorkerAsync() 'start ng select query
            End If


            'txtimg1.Text = ""
            'lblimgid.Text = ""

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Sub convertPic(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            pic = CType(sender, PictureBox)
            viewimage.imgbox.Image = pic.Image
            viewimage.ShowDialog()

            

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub bgw_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabled = True
        Dim imgtag As String = ""

        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If

        cmd = New SqlCommand(panelsql, connection)
        Dim drx As SqlDataReader = cmd.ExecuteReader
        While drx.Read
            meronstp1 = True

            Dim data As Byte() = DirectCast(drx("img"), Byte())
            Dim ms As New MemoryStream(data)

            imgtag = drx("imgid")

            AddDGVRow(ms, imgtag, drx("name"))
        End While
        drx.Dispose()
        cmd.Dispose()
        connection.Close()
    End Sub

    Delegate Sub AddRowDelegate(ByVal value0 As Object, ByVal value1 As Object, ByVal value2 As Object)
    Private m_addRowDelegate As AddRowDelegate

    Private Sub AddDGVRow(ByVal val0ms As Object, ByVal val3imgtag As String, ByVal val4name As String)
        If threadEnabled = True Then
            If imgpanel1.InvokeRequired Then
                imgpanel1.BeginInvoke(New AddRowDelegate(AddressOf AddDGVRow), val0ms, val3imgtag, val4name)
            Else
                temp = temp + 1
                mody = temp Mod 3
                row = temp / 3

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                pic = New PictureBox
                pic.Image = Image.FromStream(val0ms)
                pic.SizeMode = PictureBoxSizeMode.Zoom
                pic.SetBounds(wid, y, 85, 87)
                pic.BorderStyle = BorderStyle.FixedSingle
                pic.Tag = val3imgtag

                Dim lbl As Label
                lbl = New Label
                lbl.Text = val4name
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(85, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 93 + y)
                lbl.Tag = val3imgtag

                wid += 92
                widlbl += 92

                AddHandler pic.Click, AddressOf convertPic
                imgpanel1.Controls.Add(pic)
                imgpanel1.Controls.Add(lbl)
            End If
        End If
    End Sub

    Private Sub bgw_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        Me.Cursor = Cursors.Default
        lblloading.Visible = False
        If e.Error IsNot Nothing Then
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            If frmload = True Then
                If sing = False Then
                    Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                    grdtrans.Rows(0).Cells(0).Selected = True
                    grdtrans_CellClick(grdtrans, eventArgs)
                End If
            End If
        End If
    End Sub

    Private Sub grdtrans_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans.CellContentClick

    End Sub
End Class