﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class repair
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim stat As String
    Public rscnf As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            If Trim(txtcode.Text) = "" Then
                grdrepair.Rows.Clear()
                MsgBox("Input repair service code first.", MsgBoxStyle.Exclamation, "")
                txtcode.Focus()
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

            sql = "Select * from tblrepair where rscode like '" & Trim(txtcode.Text) & "%'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                grdrepair.Rows.Clear()
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdrepair.Rows.Add(dr("repairid"), dr("rscode"), dr("description"), stat)
                txtcode.Text = ""
            Else
                MsgBox("Cannot found " & Trim(txtcode.Text), MsgBoxStyle.Critical, "")
                txtcode.Text = ""
                txtcode.Focus()
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If Trim(txtcode.Text) <> "" Then
                sql = "Select * from tblrepair where rscode='" & Trim(txtcode.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    MsgBox(Trim(txtcode.Text) & " is already exist", MsgBoxStyle.Information, "")
                    btnupdate.Text = "&Update"
                    txtcode.Text = ""
                    txtcode.Focus()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                sql = "Select * from tblrepair where desscription='" & Trim(txtdes.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    MsgBox(Trim(txtdes.Text) & " is already exist", MsgBoxStyle.Information, "")
                    btnupdate.Text = "&Update"
                    txtcode.Text = ""
                    txtcode.Focus()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                rscnf = False
                confirm.ShowDialog()
                If rscnf = True Then
                    sql = "Insert into tblrepair (rscode, description, datecreated, createdby, datemodified, modifiedby, status) values('" & Trim(txtcode.Text) & "','" & Trim(txtdes.Text) & "',GetDate(),'" & login.cashier & "',GetDate(),'" & login.cashier & "','1')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Added", MsgBoxStyle.Information, "")
                    btnview.PerformClick()
                End If

                txtcode.Text = ""
                txtcode.Focus()
                rscnf = False
            Else
                MsgBox("Complete the fields.", MsgBoxStyle.Exclamation, "")
                txtcode.Focus()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        Try
            grdrepair.Rows.Clear()
            Dim stat As String = ""


            sql = "Select * from tblrepair"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdrepair.Rows.Add(dr("repairid"), dr("rscode"), dr("description"), stat)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If grdrepair.Rows.Count = 0 Then
                btnupdate.Enabled = False
            Else
                btnupdate.Enabled = True
            End If

            btncancel.PerformClick()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txttype_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtcode.Leave
        'txttype.Text = StrConv(txttype.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txttype_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcode.TextChanged
        If (Trim(txtcode.Text) <> "" Or Trim(txtdes.Text) <> "") Then
            btncancel.Enabled = True
        ElseIf (Trim(txtcode.Text) = "" And Trim(txtdes.Text) = "") And btnupdate.Text = "&Save" Then
            btncancel.Enabled = True
        Else
            btncancel.Enabled = False
        End If

        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtcode.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtcode.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtcode.Text.Length - 1
            Letter = txtcode.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtcode.Text = theText
        txtcode.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtdes_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtdes.Leave
        txtdes.Text = StrConv(txtdes.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txtdes_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdes.TextChanged
        If (Trim(txtcode.Text) <> "" Or Trim(txtdes.Text) <> "") Then
            btncancel.Enabled = True
        ElseIf (Trim(txtcode.Text) = "" And Trim(txtdes.Text) = "") And btnupdate.Text = "&Save" Then
            btncancel.Enabled = True
        Else
            btncancel.Enabled = False
        End If

        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtdes.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtdes.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtdes.Text.Length - 1
            Letter = txtdes.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtdes.Text = theText
        txtdes.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub rscodes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnview.PerformClick()
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        txtcode.Text = ""
        txtdes.Text = ""
        btnupdate.Text = "&Update"
        btnsearch.Enabled = True
        btndeactivate.Enabled = True
        btnadd.Enabled = True
        btncancel.Enabled = False
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdrepair.SelectedRows.Count = 1 Or grdrepair.SelectedCells.Count = 1 Then
                If btnupdate.Text = "&Update" Then
                    If grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(3).Value = "Deactivated" Then
                        MsgBox("Cannot update deactivated repair service.", MsgBoxStyle.Exclamation, "")
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    lblcat.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(1).Value
                    txtcode.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(1).Value
                    txtdes.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(2).Value
                    lblid.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(0).Value
                    btnsearch.Enabled = False
                    btnadd.Enabled = False
                    btnupdate.Text = "&Save"
                    btncancel.Enabled = True
                    btndeactivate.Enabled = False
                Else
                    'update
                    If Trim(txtcode.Text) = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("RS code should not be empty.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If

                    sql = "Select * from tblrepair where rscode='" & Trim(txtcode.Text) & "' and description='" & Trim(txtdes.Text) & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox(Trim(txtcode.Text) & " is already exist.", MsgBoxStyle.Information, "")
                        btnupdate.Text = "&Update"
                        btnsearch.Enabled = True
                        btnadd.Enabled = True
                        btncancel.Enabled = False
                        btndeactivate.Enabled = False
                        txtcode.Text = ""
                        txtdes.Text = ""
                        txtcode.Focus()
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    rscnf = False
                    confirm.ShowDialog()
                    If rscnf = True Then
                        If Trim(txtcode.Text) <> Trim(lblcat.Text) Then
                            sql = "Update tblrepair set rscode='" & Trim(txtcode.Text) & "', description='" & Trim(txtdes.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where repairid='" & lblid.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                        End If


                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    btnupdate.Text = "&Update"
                    btnsearch.Enabled = True
                    btnadd.Enabled = True
                    btndeactivate.Enabled = True
                    btncancel.Enabled = False
                    txtcode.Text = ""
                    txtdes.Text = ""
                    txtcode.Focus()
                    rscnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
                btnview.PerformClick()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btndeactivate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndeactivate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdrepair.SelectedRows.Count = 1 Or grdrepair.SelectedCells.Count = 1 Then
                lblid.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(0).Value
                If btndeactivate.Text = "&Deactivate" Then

                    rscnf = False
                    confirm.ShowDialog()
                    If rscnf = True Then
                        sql = "Update tblrepair set status='0', datemodified=GetDate(), modifiedby='" & login.cashier & "' where repairid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    rscnf = False
                Else
                    rscnf = False
                    confirm.ShowDialog()
                    If rscnf = True Then
                        sql = "Update tblrepair set status='1', datemodified=GetDate(), modifiedby='" & login.cashier & "' where repairid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    rscnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtype_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdrepair.SelectionChanged
        If grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(3).Value = "Active" Then
            btndeactivate.Text = "&Deactivate"
        Else
            btndeactivate.Text = "A&ctivate"
        End If
    End Sub
End Class