﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class tripsum
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(tripsum))
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.dateto = New System.Windows.Forms.DateTimePicker
        Me.Label2 = New System.Windows.Forms.Label
        Me.cmbdriver = New System.Windows.Forms.ComboBox
        Me.cmbplate = New System.Windows.Forms.ComboBox
        Me.datefrom = New System.Windows.Forms.DateTimePicker
        Me.Label1 = New System.Windows.Forms.Label
        Me.grdtrip = New System.Windows.Forms.DataGridView
        Me.btnview = New System.Windows.Forms.Button
        Me.btnsearch = New System.Windows.Forms.Button
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.pgb1 = New System.Windows.Forms.ProgressBar
        Me.lblloading = New System.Windows.Forms.Label
        Me.cmbcus = New System.Windows.Forms.ComboBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.chkhide = New System.Windows.Forms.CheckBox
        Me.cmbtype = New System.Windows.Forms.ComboBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.lblcount = New System.Windows.Forms.Label
        Me.btnexport = New System.Windows.Forms.Button
        Me.btnreport = New System.Windows.Forms.Button
        Me.lbltrip = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txttrip = New System.Windows.Forms.TextBox
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.EditTripToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeTripDateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeDriverToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditHelperToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CancelTripToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RemoveCustomerTransactionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RescueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.UpdateRemarksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewTripInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column1 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column37 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column36 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column35 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column26 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column28 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column30 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column31 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column27 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column29 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column32 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column20 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column33 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column34 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column25 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column21 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column22 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column23 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column24 = New System.Windows.Forms.DataGridViewTextBoxColumn
        CType(Me.grdtrip, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dateto
        '
        Me.dateto.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.dateto.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dateto.Location = New System.Drawing.Point(108, 48)
        Me.dateto.Name = "dateto"
        Me.dateto.Size = New System.Drawing.Size(119, 21)
        Me.dateto.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(79, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(23, 15)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "To:"
        '
        'cmbdriver
        '
        Me.cmbdriver.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbdriver.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbdriver.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbdriver.FormattingEnabled = True
        Me.cmbdriver.Location = New System.Drawing.Point(601, 18)
        Me.cmbdriver.Name = "cmbdriver"
        Me.cmbdriver.Size = New System.Drawing.Size(202, 23)
        Me.cmbdriver.TabIndex = 5
        '
        'cmbplate
        '
        Me.cmbplate.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbplate.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbplate.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbplate.FormattingEnabled = True
        Me.cmbplate.Location = New System.Drawing.Point(328, 18)
        Me.cmbplate.Name = "cmbplate"
        Me.cmbplate.Size = New System.Drawing.Size(183, 23)
        Me.cmbplate.Sorted = True
        Me.cmbplate.TabIndex = 3
        '
        'datefrom
        '
        Me.datefrom.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.datefrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datefrom.Location = New System.Drawing.Point(108, 21)
        Me.datefrom.Name = "datefrom"
        Me.datefrom.Size = New System.Drawing.Size(119, 21)
        Me.datefrom.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(10, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 15)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Trip Date From:"
        '
        'grdtrip
        '
        Me.grdtrip.AllowUserToAddRows = False
        Me.grdtrip.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdtrip.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdtrip.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdtrip.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdtrip.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdtrip.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrip.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.grdtrip.ColumnHeadersHeight = 45
        Me.grdtrip.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdtrip.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column4, Me.Column6, Me.Column1, Me.Column3, Me.Column37, Me.Column2, Me.Column36, Me.Column5, Me.Column10, Me.Column7, Me.Column8, Me.Column35, Me.Column11, Me.Column26, Me.Column12, Me.Column28, Me.Column13, Me.Column14, Me.Column30, Me.Column31, Me.Column15, Me.Column16, Me.Column27, Me.Column17, Me.Column18, Me.Column19, Me.Column29, Me.Column32, Me.Column20, Me.Column33, Me.Column34, Me.Column9, Me.Column25, Me.Column21, Me.Column22, Me.Column23, Me.Column24})
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrip.DefaultCellStyle = DataGridViewCellStyle10
        Me.grdtrip.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdtrip.EnableHeadersVisualStyles = False
        Me.grdtrip.GridColor = System.Drawing.Color.Salmon
        Me.grdtrip.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdtrip.Location = New System.Drawing.Point(12, 101)
        Me.grdtrip.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdtrip.Name = "grdtrip"
        Me.grdtrip.ReadOnly = True
        Me.grdtrip.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrip.RowHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.grdtrip.RowHeadersWidth = 15
        Me.grdtrip.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle12.NullValue = Nothing
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrip.RowsDefaultCellStyle = DataGridViewCellStyle12
        Me.grdtrip.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrip.Size = New System.Drawing.Size(1329, 534)
        Me.grdtrip.TabIndex = 10
        '
        'btnview
        '
        Me.btnview.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnview.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.btnview.Image = CType(resources.GetObject("btnview.Image"), System.Drawing.Image)
        Me.btnview.Location = New System.Drawing.Point(1125, 45)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(130, 23)
        Me.btnview.TabIndex = 0
        Me.btnview.Text = "View All Pending"
        Me.btnview.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnview.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnview.UseVisualStyleBackColor = True
        '
        'btnsearch
        '
        Me.btnsearch.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnsearch.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.btnsearch.Image = CType(resources.GetObject("btnsearch.Image"), System.Drawing.Image)
        Me.btnsearch.Location = New System.Drawing.Point(1125, 18)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(106, 23)
        Me.btnsearch.TabIndex = 7
        Me.btnsearch.Text = "Search"
        Me.btnsearch.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnsearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label6.Location = New System.Drawing.Point(533, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(42, 15)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Driver:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label5.Location = New System.Drawing.Point(249, 22)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 15)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Plate No:"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.pgb1)
        Me.Panel1.Controls.Add(Me.lblloading)
        Me.Panel1.Controls.Add(Me.cmbcus)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.chkhide)
        Me.Panel1.Controls.Add(Me.cmbtype)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.lblcount)
        Me.Panel1.Controls.Add(Me.btnexport)
        Me.Panel1.Controls.Add(Me.btnreport)
        Me.Panel1.Controls.Add(Me.lbltrip)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.txttrip)
        Me.Panel1.Controls.Add(Me.grdtrip)
        Me.Panel1.Controls.Add(Me.dateto)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.cmbdriver)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.cmbplate)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.datefrom)
        Me.Panel1.Controls.Add(Me.btnsearch)
        Me.Panel1.Controls.Add(Me.btnview)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1353, 671)
        Me.Panel1.TabIndex = 3
        '
        'pgb1
        '
        Me.pgb1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pgb1.Location = New System.Drawing.Point(13, 620)
        Me.pgb1.MarqueeAnimationSpeed = 50
        Me.pgb1.Maximum = 10
        Me.pgb1.Name = "pgb1"
        Me.pgb1.Size = New System.Drawing.Size(1326, 23)
        Me.pgb1.Style = System.Windows.Forms.ProgressBarStyle.Marquee
        Me.pgb1.TabIndex = 100
        '
        'lblloading
        '
        Me.lblloading.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblloading.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblloading.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblloading.Location = New System.Drawing.Point(13, 147)
        Me.lblloading.Name = "lblloading"
        Me.lblloading.Size = New System.Drawing.Size(1326, 469)
        Me.lblloading.TabIndex = 98
        Me.lblloading.Text = "Loading..."
        Me.lblloading.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbcus
        '
        Me.cmbcus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbcus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbcus.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbcus.FormattingEnabled = True
        Me.cmbcus.Location = New System.Drawing.Point(601, 47)
        Me.cmbcus.Name = "cmbcus"
        Me.cmbcus.Size = New System.Drawing.Size(202, 23)
        Me.cmbcus.TabIndex = 33
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label8.Location = New System.Drawing.Point(533, 51)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 15)
        Me.Label8.TabIndex = 32
        Me.Label8.Text = "Recipient:"
        '
        'chkhide
        '
        Me.chkhide.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkhide.AutoSize = True
        Me.chkhide.Location = New System.Drawing.Point(1223, 79)
        Me.chkhide.Name = "chkhide"
        Me.chkhide.Size = New System.Drawing.Size(124, 17)
        Me.chkhide.TabIndex = 31
        Me.chkhide.Text = "Hide Cancelled Trips"
        Me.chkhide.UseVisualStyleBackColor = True
        '
        'cmbtype
        '
        Me.cmbtype.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbtype.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbtype.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbtype.FormattingEnabled = True
        Me.cmbtype.Location = New System.Drawing.Point(328, 47)
        Me.cmbtype.Name = "cmbtype"
        Me.cmbtype.Size = New System.Drawing.Size(183, 23)
        Me.cmbtype.TabIndex = 4
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label7.Location = New System.Drawing.Point(249, 53)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 15)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "Truck Type:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(847, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 29
        Me.Label4.Text = "Label4"
        Me.Label4.Visible = False
        '
        'lblcount
        '
        Me.lblcount.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.lblcount.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcount.Location = New System.Drawing.Point(0, 646)
        Me.lblcount.Name = "lblcount"
        Me.lblcount.Size = New System.Drawing.Size(1353, 25)
        Me.lblcount.TabIndex = 28
        Me.lblcount.Text = "Count:"
        '
        'btnexport
        '
        Me.btnexport.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnexport.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.btnexport.Image = CType(resources.GetObject("btnexport.Image"), System.Drawing.Image)
        Me.btnexport.Location = New System.Drawing.Point(1261, 45)
        Me.btnexport.Name = "btnexport"
        Me.btnexport.Size = New System.Drawing.Size(80, 23)
        Me.btnexport.TabIndex = 9
        Me.btnexport.Text = "Export"
        Me.btnexport.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnexport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnexport.UseVisualStyleBackColor = True
        '
        'btnreport
        '
        Me.btnreport.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnreport.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.btnreport.Image = CType(resources.GetObject("btnreport.Image"), System.Drawing.Image)
        Me.btnreport.Location = New System.Drawing.Point(1237, 18)
        Me.btnreport.Name = "btnreport"
        Me.btnreport.Size = New System.Drawing.Size(104, 23)
        Me.btnreport.TabIndex = 8
        Me.btnreport.Text = "Report"
        Me.btnreport.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnreport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnreport.UseVisualStyleBackColor = True
        '
        'lbltrip
        '
        Me.lbltrip.AutoSize = True
        Me.lbltrip.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.lbltrip.Location = New System.Drawing.Point(837, 51)
        Me.lbltrip.Name = "lbltrip"
        Me.lbltrip.Size = New System.Drawing.Size(45, 15)
        Me.lbltrip.TabIndex = 27
        Me.lbltrip.Text = "T.MNL-"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label3.Location = New System.Drawing.Point(837, 27)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 15)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "Trip #:"
        '
        'txttrip
        '
        Me.txttrip.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txttrip.Location = New System.Drawing.Point(882, 48)
        Me.txttrip.Name = "txttrip"
        Me.txttrip.Size = New System.Drawing.Size(144, 20)
        Me.txttrip.TabIndex = 6
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditTripToolStripMenuItem, Me.ChangeTripDateToolStripMenuItem, Me.ChangeDriverToolStripMenuItem, Me.EditHelperToolStripMenuItem, Me.CancelTripToolStripMenuItem, Me.RemoveCustomerTransactionToolStripMenuItem, Me.RescueToolStripMenuItem, Me.UpdateRemarksToolStripMenuItem, Me.ViewTripInformationToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(236, 202)
        '
        'EditTripToolStripMenuItem
        '
        Me.EditTripToolStripMenuItem.Image = CType(resources.GetObject("EditTripToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditTripToolStripMenuItem.Name = "EditTripToolStripMenuItem"
        Me.EditTripToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.EditTripToolStripMenuItem.Text = "Edit Trip Schedule"
        '
        'ChangeTripDateToolStripMenuItem
        '
        Me.ChangeTripDateToolStripMenuItem.Image = CType(resources.GetObject("ChangeTripDateToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ChangeTripDateToolStripMenuItem.Name = "ChangeTripDateToolStripMenuItem"
        Me.ChangeTripDateToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.ChangeTripDateToolStripMenuItem.Text = "Change Trip Date"
        '
        'ChangeDriverToolStripMenuItem
        '
        Me.ChangeDriverToolStripMenuItem.Image = CType(resources.GetObject("ChangeDriverToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ChangeDriverToolStripMenuItem.Name = "ChangeDriverToolStripMenuItem"
        Me.ChangeDriverToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.ChangeDriverToolStripMenuItem.Text = "Change Driver"
        '
        'EditHelperToolStripMenuItem
        '
        Me.EditHelperToolStripMenuItem.Image = CType(resources.GetObject("EditHelperToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditHelperToolStripMenuItem.Name = "EditHelperToolStripMenuItem"
        Me.EditHelperToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.EditHelperToolStripMenuItem.Text = "Edit Helper"
        '
        'CancelTripToolStripMenuItem
        '
        Me.CancelTripToolStripMenuItem.Image = CType(resources.GetObject("CancelTripToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CancelTripToolStripMenuItem.Name = "CancelTripToolStripMenuItem"
        Me.CancelTripToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.CancelTripToolStripMenuItem.Text = "Cancel Trip Only"
        '
        'RemoveCustomerTransactionToolStripMenuItem
        '
        Me.RemoveCustomerTransactionToolStripMenuItem.Image = CType(resources.GetObject("RemoveCustomerTransactionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RemoveCustomerTransactionToolStripMenuItem.Name = "RemoveCustomerTransactionToolStripMenuItem"
        Me.RemoveCustomerTransactionToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.RemoveCustomerTransactionToolStripMenuItem.Text = "Remove Customer Transaction"
        '
        'RescueToolStripMenuItem
        '
        Me.RescueToolStripMenuItem.Image = CType(resources.GetObject("RescueToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RescueToolStripMenuItem.Name = "RescueToolStripMenuItem"
        Me.RescueToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.RescueToolStripMenuItem.Text = "Rescue"
        Me.RescueToolStripMenuItem.Visible = False
        '
        'UpdateRemarksToolStripMenuItem
        '
        Me.UpdateRemarksToolStripMenuItem.Image = CType(resources.GetObject("UpdateRemarksToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UpdateRemarksToolStripMenuItem.Name = "UpdateRemarksToolStripMenuItem"
        Me.UpdateRemarksToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.UpdateRemarksToolStripMenuItem.Text = "Update Remarks"
        '
        'ViewTripInformationToolStripMenuItem
        '
        Me.ViewTripInformationToolStripMenuItem.Image = CType(resources.GetObject("ViewTripInformationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewTripInformationToolStripMenuItem.Name = "ViewTripInformationToolStripMenuItem"
        Me.ViewTripInformationToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.ViewTripInformationToolStripMenuItem.Text = "View Trip Information"
        '
        'Column4
        '
        Me.Column4.HeaderText = "ID"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Visible = False
        '
        'Column6
        '
        DataGridViewCellStyle3.Format = "yyyy/MM/dd"
        Me.Column6.DefaultCellStyle = DataGridViewCellStyle3
        Me.Column6.HeaderText = "Trip Date"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        Me.Column6.Width = 80
        '
        'Column1
        '
        Me.Column1.ActiveLinkColor = System.Drawing.Color.White
        Me.Column1.HeaderText = "Trip #"
        Me.Column1.LinkColor = System.Drawing.Color.Red
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column1.VisitedLinkColor = System.Drawing.Color.Red
        Me.Column1.Width = 120
        '
        'Column3
        '
        Me.Column3.HeaderText = "Plate #"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 110
        '
        'Column37
        '
        Me.Column37.HeaderText = "Truck Type"
        Me.Column37.Name = "Column37"
        Me.Column37.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.HeaderText = "Driver"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 115
        '
        'Column36
        '
        Me.Column36.HeaderText = "Helper"
        Me.Column36.Name = "Column36"
        Me.Column36.ReadOnly = True
        Me.Column36.Width = 115
        '
        'Column5
        '
        Me.Column5.HeaderText = "Origin"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Width = 120
        '
        'Column10
        '
        Me.Column10.HeaderText = "Destination"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        Me.Column10.Width = 150
        '
        'Column7
        '
        DataGridViewCellStyle4.Format = "HH:mm"
        Me.Column7.DefaultCellStyle = DataGridViewCellStyle4
        Me.Column7.HeaderText = "ETD"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Width = 80
        '
        'Column8
        '
        Me.Column8.HeaderText = "Time Departure"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'Column35
        '
        Me.Column35.HeaderText = "Time Arrival"
        Me.Column35.Name = "Column35"
        Me.Column35.ReadOnly = True
        '
        'Column11
        '
        Me.Column11.HeaderText = "Odometer (Previous)"
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        '
        'Column26
        '
        Me.Column26.HeaderText = "Actual Odometer (Start)"
        Me.Column26.Name = "Column26"
        Me.Column26.ReadOnly = True
        '
        'Column12
        '
        Me.Column12.HeaderText = "Odometer (End)"
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        '
        'Column28
        '
        DataGridViewCellStyle5.Format = "n2"
        Me.Column28.DefaultCellStyle = DataGridViewCellStyle5
        Me.Column28.HeaderText = "Actual Distance"
        Me.Column28.Name = "Column28"
        Me.Column28.ReadOnly = True
        '
        'Column13
        '
        Me.Column13.HeaderText = "Distance w/ Load"
        Me.Column13.Name = "Column13"
        Me.Column13.ReadOnly = True
        '
        'Column14
        '
        Me.Column14.HeaderText = "Distance w/o Load"
        Me.Column14.Name = "Column14"
        Me.Column14.ReadOnly = True
        '
        'Column30
        '
        Me.Column30.HeaderText = "Total Distance"
        Me.Column30.Name = "Column30"
        Me.Column30.ReadOnly = True
        '
        'Column31
        '
        DataGridViewCellStyle6.Format = "n2"
        Me.Column31.DefaultCellStyle = DataGridViewCellStyle6
        Me.Column31.HeaderText = "Variance (Actual Distance - Total Distance)"
        Me.Column31.Name = "Column31"
        Me.Column31.ReadOnly = True
        '
        'Column15
        '
        Me.Column15.HeaderText = "Diesel Should be"
        Me.Column15.Name = "Column15"
        Me.Column15.ReadOnly = True
        '
        'Column16
        '
        Me.Column16.HeaderText = "Diesel (Previous)"
        Me.Column16.Name = "Column16"
        Me.Column16.ReadOnly = True
        '
        'Column27
        '
        Me.Column27.HeaderText = "Actual Diesel (Beg)"
        Me.Column27.Name = "Column27"
        Me.Column27.ReadOnly = True
        '
        'Column17
        '
        Me.Column17.HeaderText = "PO Diesel"
        Me.Column17.Name = "Column17"
        Me.Column17.ReadOnly = True
        '
        'Column18
        '
        Me.Column18.HeaderText = "Add'l PO and Post Add'l PO"
        Me.Column18.Name = "Column18"
        Me.Column18.ReadOnly = True
        '
        'Column19
        '
        Me.Column19.HeaderText = "Diesel (End)"
        Me.Column19.Name = "Column19"
        Me.Column19.ReadOnly = True
        '
        'Column29
        '
        Me.Column29.HeaderText = "Actual Diesel Used"
        Me.Column29.Name = "Column29"
        Me.Column29.ReadOnly = True
        '
        'Column32
        '
        DataGridViewCellStyle7.Format = "n2"
        Me.Column32.DefaultCellStyle = DataGridViewCellStyle7
        Me.Column32.HeaderText = "Variance (Actual Diesel - Diesel Should be)"
        Me.Column32.Name = "Column32"
        Me.Column32.ReadOnly = True
        '
        'Column20
        '
        Me.Column20.HeaderText = "No. of Labor"
        Me.Column20.Name = "Column20"
        Me.Column20.ReadOnly = True
        Me.Column20.Visible = False
        '
        'Column33
        '
        Me.Column33.HeaderText = "Load Scale"
        Me.Column33.Name = "Column33"
        Me.Column33.ReadOnly = True
        Me.Column33.Width = 150
        '
        'Column34
        '
        Me.Column34.HeaderText = "Rescued by"
        Me.Column34.Name = "Column34"
        Me.Column34.ReadOnly = True
        Me.Column34.Visible = False
        '
        'Column9
        '
        Me.Column9.HeaderText = "Remarks"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        Me.Column9.Width = 120
        '
        'Column25
        '
        Me.Column25.HeaderText = "Status"
        Me.Column25.Name = "Column25"
        Me.Column25.ReadOnly = True
        Me.Column25.Width = 120
        '
        'Column21
        '
        DataGridViewCellStyle8.Format = "yyyy/MM/dd HH:mm"
        Me.Column21.DefaultCellStyle = DataGridViewCellStyle8
        Me.Column21.HeaderText = "Date Created"
        Me.Column21.Name = "Column21"
        Me.Column21.ReadOnly = True
        Me.Column21.Width = 90
        '
        'Column22
        '
        Me.Column22.HeaderText = "Created by"
        Me.Column22.Name = "Column22"
        Me.Column22.ReadOnly = True
        '
        'Column23
        '
        DataGridViewCellStyle9.Format = "yyyy/MM/dd HH:mm"
        Me.Column23.DefaultCellStyle = DataGridViewCellStyle9
        Me.Column23.HeaderText = "Date Modified"
        Me.Column23.Name = "Column23"
        Me.Column23.ReadOnly = True
        Me.Column23.Width = 90
        '
        'Column24
        '
        Me.Column24.HeaderText = "Modified by"
        Me.Column24.Name = "Column24"
        Me.Column24.ReadOnly = True
        '
        'tripsum
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1353, 671)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "tripsum"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Trip Summary"
        CType(Me.grdtrip, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnview As System.Windows.Forms.Button
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents grdtrip As System.Windows.Forms.DataGridView
    Friend WithEvents datefrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbdriver As System.Windows.Forms.ComboBox
    Friend WithEvents cmbplate As System.Windows.Forms.ComboBox
    Friend WithEvents dateto As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents EditTripToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CancelTripToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RescueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lbltrip As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txttrip As System.Windows.Forms.TextBox
    Friend WithEvents UpdateRemarksToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnreport As System.Windows.Forms.Button
    Friend WithEvents btnexport As System.Windows.Forms.Button
    Friend WithEvents EditHelperToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblcount As System.Windows.Forms.Label
    Friend WithEvents ViewTripInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ChangeDriverToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmbtype As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents chkhide As System.Windows.Forms.CheckBox
    Friend WithEvents cmbcus As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents ChangeTripDateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblloading As System.Windows.Forms.Label
    Friend WithEvents pgb1 As System.Windows.Forms.ProgressBar
    Friend WithEvents RemoveCustomerTransactionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column37 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column36 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column35 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column26 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column28 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column30 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column31 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column27 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column29 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column32 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column33 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column34 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column25 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column24 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
