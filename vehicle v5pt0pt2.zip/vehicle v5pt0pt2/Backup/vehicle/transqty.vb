﻿Imports System.IO
Imports System.Data.SqlClient

Public Class transqty
    Dim lines = System.IO.File.ReadAllLines("cnstringdashboard.txt")
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub transqty_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            If Trim(txttripid.Text) <> "" And Trim(txtso.Text) <> "" Then
                sql = "Select * from tblsostatus where sonum='" & Trim(txtso.Text) & "' and tripid='" & Trim(txttripid.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    lblid.Text = dr("flwhseid")
                    txttrip.Text = dr("tripnum")
                    txttrans.Text = dr("transnum")
                    txtqty.Text = dr("soqty")
                Else
                    MsgBox("Cannot found.", MsgBoxStyle.Critical, "")
                    lblid.Text = ""
                    txttripid.Text = ""
                    txtso.Text = ""
                    txttrip.Text = ""
                    txttrans.Text = ""
                    txtqty.Text = ""
                    txtnew.Text = ""
                    chk.Checked = False
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Else
                MsgBox("Input Trip id and SO#.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txttripid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttripid.KeyPress
        If Asc(e.KeyChar) <= 48 And Asc(e.KeyChar) >= 57 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txttripid_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttripid.TextChanged
        Dim charactersDisallowed As String = "0123456789"
        Dim theText As String = txttripid.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txttripid.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txttripid.Text.Length - 1
            Letter = txttripid.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txttripid.Text = theText
        txttripid.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtso_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtso.KeyPress
        If Asc(e.KeyChar) <= 48 And Asc(e.KeyChar) >= 57 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtso_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtso.TextChanged
        Dim charactersDisallowed As String = "0123456789"
        Dim theText As String = txtso.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtso.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtso.Text.Length - 1
            Letter = txtso.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtso.Text = theText
        txtso.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        lblid.Text = ""
        txttripid.Text = ""
        txtso.Text = ""
        txttrip.Text = ""
        txttrans.Text = ""
        txtqty.Text = ""
        txtnew.Text = ""
        chk.Checked = False
        Me.Dispose()
        '/moduless.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            If Trim(lblid.Text) <> "" And Trim(txttripid.Text) <> "" And Trim(txtso.Text) <> "" And Trim(txttrip.Text) <> "" And Trim(txttrans.Text) <> "" And Trim(txtqty.Text) <> "" And Trim(txtnew.Text) <> "" And chk.Checked = True Then
                Me.Cursor = Cursors.WaitCursor

                sql = "Update tblsostatus set soqty='" & Trim(txtnew.Text) & "', adjust='1' where flwhseid='" & Trim(lblid.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                Me.Cursor = Cursors.Default
                MsgBox("Successfully saved.", MsgBoxStyle.Information, "")
                lblid.Text = ""
                txttripid.Text = ""
                txtso.Text = ""
                txttrip.Text = ""
                txttrans.Text = ""
                txtqty.Text = ""
                txtnew.Text = ""
                chk.Checked = False

            Else
                MsgBox("Complete the fields.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtnew_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtnew.KeyPress
        '/If Asc(e.KeyChar) <= 48 And Asc(e.KeyChar) >= 57 And Asc(e.KeyChar) <> 46 Then
        '/e.Handled = True
        '/End If

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                e.Handled = True
            Else
                If Val(txtnew.Text) = 0 Then
                    If Asc(e.KeyChar) = 48 Then
                        '/e.Handled = True
                    Else
                        '/txtnew.Text = ""
                    End If
                End If
            End If
        Else
            If Asc(e.KeyChar) = 46 And Trim(txtnew.Text) <> "" And txtnew.Text.Contains(".") = False Then

            ElseIf Asc(e.KeyChar) = 46 And Trim(txtnew.Text) <> "" And txtnew.Text.Contains(".") = True Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtnew_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtnew.TextChanged
        Dim charactersDisallowed As String = "0123456789."
        Dim theText As String = txtnew.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtnew.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtnew.Text.Length - 1
            Letter = txtnew.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtnew.Text = theText
        txtnew.Select(SelectionIndex - Change, 0)
    End Sub
End Class