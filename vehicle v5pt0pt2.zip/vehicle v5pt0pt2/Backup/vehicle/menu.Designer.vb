﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class menutrans
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(menutrans))
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txttrans = New System.Windows.Forms.TextBox
        Me.txtref = New System.Windows.Forms.TextBox
        Me.txttype = New System.Windows.Forms.TextBox
        Me.txtdes = New System.Windows.Forms.TextBox
        Me.txtcreate = New System.Windows.Forms.TextBox
        Me.txtstatus = New System.Windows.Forms.TextBox
        Me.txtnotes = New System.Windows.Forms.TextBox
        Me.grdorders = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.grouptrans = New System.Windows.Forms.GroupBox
        Me.grdtrans = New System.Windows.Forms.DataGridView
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.btnsave = New System.Windows.Forms.Button
        Me.btncancel = New System.Windows.Forms.Button
        Me.imgpanel1 = New System.Windows.Forms.Panel
        Me.lblimgid = New System.Windows.Forms.Label
        Me.btnimgadd1 = New System.Windows.Forms.Button
        Me.btnimgcancel1 = New System.Windows.Forms.Button
        Me.btnimgrename1 = New System.Windows.Forms.Button
        Me.txtimg1 = New System.Windows.Forms.TextBox
        Me.imgbox = New System.Windows.Forms.PictureBox
        Me.cmbcus = New System.Windows.Forms.ComboBox
        CType(Me.grdorders, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.grouptrans.SuspendLayout()
        CType(Me.grdtrans, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.imgpanel1.SuspendLayout()
        CType(Me.imgbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Transaction #:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Reference #:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(422, 15)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(62, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Recipient:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(26, 70)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Trans Type:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(442, 70)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 15)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Status:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(415, 42)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 15)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Created by:"
        '
        'txttrans
        '
        Me.txttrans.BackColor = System.Drawing.Color.White
        Me.txttrans.Location = New System.Drawing.Point(105, 12)
        Me.txttrans.Name = "txttrans"
        Me.txttrans.ReadOnly = True
        Me.txttrans.Size = New System.Drawing.Size(252, 21)
        Me.txttrans.TabIndex = 7
        '
        'txtref
        '
        Me.txtref.BackColor = System.Drawing.Color.White
        Me.txtref.Location = New System.Drawing.Point(105, 40)
        Me.txtref.Name = "txtref"
        Me.txtref.ReadOnly = True
        Me.txtref.Size = New System.Drawing.Size(252, 21)
        Me.txtref.TabIndex = 8
        '
        'txttype
        '
        Me.txttype.BackColor = System.Drawing.Color.White
        Me.txttype.Location = New System.Drawing.Point(105, 68)
        Me.txttype.Name = "txttype"
        Me.txttype.ReadOnly = True
        Me.txttype.Size = New System.Drawing.Size(252, 21)
        Me.txttype.TabIndex = 9
        '
        'txtdes
        '
        Me.txtdes.BackColor = System.Drawing.Color.White
        Me.txtdes.Location = New System.Drawing.Point(363, 12)
        Me.txtdes.Name = "txtdes"
        Me.txtdes.ReadOnly = True
        Me.txtdes.Size = New System.Drawing.Size(24, 21)
        Me.txtdes.TabIndex = 10
        Me.txtdes.Visible = False
        '
        'txtcreate
        '
        Me.txtcreate.BackColor = System.Drawing.Color.White
        Me.txtcreate.Location = New System.Drawing.Point(494, 40)
        Me.txtcreate.Name = "txtcreate"
        Me.txtcreate.ReadOnly = True
        Me.txtcreate.Size = New System.Drawing.Size(252, 21)
        Me.txtcreate.TabIndex = 11
        '
        'txtstatus
        '
        Me.txtstatus.BackColor = System.Drawing.Color.White
        Me.txtstatus.Location = New System.Drawing.Point(494, 68)
        Me.txtstatus.Name = "txtstatus"
        Me.txtstatus.ReadOnly = True
        Me.txtstatus.Size = New System.Drawing.Size(252, 21)
        Me.txtstatus.TabIndex = 12
        '
        'txtnotes
        '
        Me.txtnotes.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtnotes.BackColor = System.Drawing.Color.White
        Me.txtnotes.Location = New System.Drawing.Point(6, 20)
        Me.txtnotes.Multiline = True
        Me.txtnotes.Name = "txtnotes"
        Me.txtnotes.ReadOnly = True
        Me.txtnotes.Size = New System.Drawing.Size(1025, 51)
        Me.txtnotes.TabIndex = 13
        '
        'grdorders
        '
        Me.grdorders.AllowUserToAddRows = False
        Me.grdorders.AllowUserToDeleteRows = False
        Me.grdorders.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdorders.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdorders.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.grdorders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdorders.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18})
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.Format = "N2"
        DataGridViewCellStyle6.NullValue = Nothing
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdorders.DefaultCellStyle = DataGridViewCellStyle6
        Me.grdorders.Location = New System.Drawing.Point(15, 106)
        Me.grdorders.Name = "grdorders"
        Me.grdorders.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdorders.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.grdorders.RowHeadersWidth = 10
        Me.grdorders.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.grdorders.Size = New System.Drawing.Size(742, 313)
        Me.grdorders.TabIndex = 14
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox
        Me.DataGridViewTextBoxColumn13.HeaderText = "Description"
        Me.DataGridViewTextBoxColumn13.MinimumWidth = 160
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn13.Width = 160
        '
        'DataGridViewTextBoxColumn14
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn14.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridViewTextBoxColumn14.HeaderText = "Qty"
        Me.DataGridViewTextBoxColumn14.MinimumWidth = 80
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn14.Width = 80
        '
        'DataGridViewTextBoxColumn15
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn15.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridViewTextBoxColumn15.HeaderText = "Price"
        Me.DataGridViewTextBoxColumn15.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'DataGridViewTextBoxColumn16
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn16.DefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridViewTextBoxColumn16.HeaderText = "Discount %"
        Me.DataGridViewTextBoxColumn16.MinimumWidth = 90
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn16.Width = 90
        '
        'DataGridViewTextBoxColumn17
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn17.DefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridViewTextBoxColumn17.HeaderText = "Amount"
        Me.DataGridViewTextBoxColumn17.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn17.Width = 120
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "Request"
        Me.DataGridViewTextBoxColumn18.MinimumWidth = 100
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.txtnotes)
        Me.GroupBox2.Location = New System.Drawing.Point(15, 425)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(1037, 76)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Notes:"
        '
        'grouptrans
        '
        Me.grouptrans.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grouptrans.Controls.Add(Me.grdtrans)
        Me.grouptrans.Location = New System.Drawing.Point(12, 520)
        Me.grouptrans.Name = "grouptrans"
        Me.grouptrans.Size = New System.Drawing.Size(10, 10)
        Me.grouptrans.TabIndex = 17
        Me.grouptrans.TabStop = False
        Me.grouptrans.Text = "Transactions"
        Me.grouptrans.Visible = False
        '
        'grdtrans
        '
        Me.grdtrans.AllowUserToAddRows = False
        Me.grdtrans.AllowUserToDeleteRows = False
        Me.grdtrans.AllowUserToResizeRows = False
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdtrans.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle8
        Me.grdtrans.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdtrans.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.grdtrans.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.grdtrans.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdtrans.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1})
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle9.Format = "N2"
        DataGridViewCellStyle9.NullValue = Nothing
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrans.DefaultCellStyle = DataGridViewCellStyle9
        Me.grdtrans.Location = New System.Drawing.Point(6, 20)
        Me.grdtrans.Name = "grdtrans"
        Me.grdtrans.ReadOnly = True
        Me.grdtrans.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans.RowHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.grdtrans.RowHeadersWidth = 10
        Me.grdtrans.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.grdtrans.Size = New System.Drawing.Size(0, 0)
        Me.grdtrans.TabIndex = 18
        '
        'Column1
        '
        Me.Column1.HeaderText = "Transaction #"
        Me.Column1.MinimumWidth = 150
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'btnsave
        '
        Me.btnsave.Image = CType(resources.GetObject("btnsave.Image"), System.Drawing.Image)
        Me.btnsave.Location = New System.Drawing.Point(896, 507)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(75, 23)
        Me.btnsave.TabIndex = 20
        Me.btnsave.Text = "Save"
        Me.btnsave.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnsave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'btncancel
        '
        Me.btncancel.Image = CType(resources.GetObject("btncancel.Image"), System.Drawing.Image)
        Me.btncancel.Location = New System.Drawing.Point(977, 507)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(75, 23)
        Me.btncancel.TabIndex = 21
        Me.btncancel.Text = "Cancel"
        Me.btncancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'imgpanel1
        '
        Me.imgpanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.imgpanel1.AutoScroll = True
        Me.imgpanel1.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel1.Controls.Add(Me.lblimgid)
        Me.imgpanel1.Location = New System.Drawing.Point(763, 12)
        Me.imgpanel1.Name = "imgpanel1"
        Me.imgpanel1.Size = New System.Drawing.Size(289, 269)
        Me.imgpanel1.TabIndex = 64
        '
        'lblimgid
        '
        Me.lblimgid.AutoSize = True
        Me.lblimgid.Location = New System.Drawing.Point(3, 254)
        Me.lblimgid.Name = "lblimgid"
        Me.lblimgid.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid.TabIndex = 70
        Me.lblimgid.Text = "imgid"
        '
        'btnimgadd1
        '
        Me.btnimgadd1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgadd1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd1.Image = CType(resources.GetObject("btnimgadd1.Image"), System.Drawing.Image)
        Me.btnimgadd1.Location = New System.Drawing.Point(763, 287)
        Me.btnimgadd1.Name = "btnimgadd1"
        Me.btnimgadd1.Size = New System.Drawing.Size(135, 30)
        Me.btnimgadd1.TabIndex = 65
        Me.btnimgadd1.Text = "Add Photo"
        Me.btnimgadd1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd1.UseVisualStyleBackColor = True
        '
        'btnimgcancel1
        '
        Me.btnimgcancel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgcancel1.Enabled = False
        Me.btnimgcancel1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel1.Image = CType(resources.GetObject("btnimgcancel1.Image"), System.Drawing.Image)
        Me.btnimgcancel1.Location = New System.Drawing.Point(763, 359)
        Me.btnimgcancel1.Name = "btnimgcancel1"
        Me.btnimgcancel1.Size = New System.Drawing.Size(135, 30)
        Me.btnimgcancel1.TabIndex = 67
        Me.btnimgcancel1.Text = "Cancel"
        Me.btnimgcancel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel1.UseVisualStyleBackColor = True
        '
        'btnimgrename1
        '
        Me.btnimgrename1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgrename1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename1.Image = CType(resources.GetObject("btnimgrename1.Image"), System.Drawing.Image)
        Me.btnimgrename1.Location = New System.Drawing.Point(763, 323)
        Me.btnimgrename1.Name = "btnimgrename1"
        Me.btnimgrename1.Size = New System.Drawing.Size(135, 30)
        Me.btnimgrename1.TabIndex = 66
        Me.btnimgrename1.Text = "Rename"
        Me.btnimgrename1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename1.UseVisualStyleBackColor = True
        '
        'txtimg1
        '
        Me.txtimg1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtimg1.BackColor = System.Drawing.Color.White
        Me.txtimg1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtimg1.Location = New System.Drawing.Point(763, 397)
        Me.txtimg1.Name = "txtimg1"
        Me.txtimg1.Size = New System.Drawing.Size(289, 22)
        Me.txtimg1.TabIndex = 68
        '
        'imgbox
        '
        Me.imgbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox.Location = New System.Drawing.Point(914, 287)
        Me.imgbox.Name = "imgbox"
        Me.imgbox.Size = New System.Drawing.Size(138, 102)
        Me.imgbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox.TabIndex = 69
        Me.imgbox.TabStop = False
        '
        'cmbcus
        '
        Me.cmbcus.FormattingEnabled = True
        Me.cmbcus.Location = New System.Drawing.Point(494, 12)
        Me.cmbcus.Name = "cmbcus"
        Me.cmbcus.Size = New System.Drawing.Size(252, 23)
        Me.cmbcus.TabIndex = 70
        '
        'menutrans
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1069, 539)
        Me.Controls.Add(Me.cmbcus)
        Me.Controls.Add(Me.imgbox)
        Me.Controls.Add(Me.txtimg1)
        Me.Controls.Add(Me.btnimgadd1)
        Me.Controls.Add(Me.btnimgcancel1)
        Me.Controls.Add(Me.btnimgrename1)
        Me.Controls.Add(Me.imgpanel1)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.grouptrans)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.grdorders)
        Me.Controls.Add(Me.txtstatus)
        Me.Controls.Add(Me.txtcreate)
        Me.Controls.Add(Me.txtdes)
        Me.Controls.Add(Me.txttype)
        Me.Controls.Add(Me.txtref)
        Me.Controls.Add(Me.txttrans)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "menutrans"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "View Transaction"
        CType(Me.grdorders, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.grouptrans.ResumeLayout(False)
        CType(Me.grdtrans, System.ComponentModel.ISupportInitialize).EndInit()
        Me.imgpanel1.ResumeLayout(False)
        Me.imgpanel1.PerformLayout()
        CType(Me.imgbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txttrans As System.Windows.Forms.TextBox
    Friend WithEvents txtref As System.Windows.Forms.TextBox
    Friend WithEvents txttype As System.Windows.Forms.TextBox
    Friend WithEvents txtdes As System.Windows.Forms.TextBox
    Friend WithEvents txtcreate As System.Windows.Forms.TextBox
    Friend WithEvents txtstatus As System.Windows.Forms.TextBox
    Friend WithEvents txtnotes As System.Windows.Forms.TextBox
    Friend WithEvents grdorders As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents grouptrans As System.Windows.Forms.GroupBox
    Friend WithEvents grdtrans As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents imgpanel1 As System.Windows.Forms.Panel
    Friend WithEvents btnimgadd1 As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel1 As System.Windows.Forms.Button
    Friend WithEvents btnimgrename1 As System.Windows.Forms.Button
    Friend WithEvents txtimg1 As System.Windows.Forms.TextBox
    Friend WithEvents imgbox As System.Windows.Forms.PictureBox
    Friend WithEvents lblimgid As System.Windows.Forms.Label
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmbcus As System.Windows.Forms.ComboBox
End Class
