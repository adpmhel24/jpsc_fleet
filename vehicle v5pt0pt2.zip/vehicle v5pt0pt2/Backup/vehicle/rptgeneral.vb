﻿Imports System.IO
Imports System.Data.SqlClient

Public Class rptgeneral
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub notifsreport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        loadcomp()
        rbid.Checked = False
    End Sub

    Public Sub loadcomp()
        Try
            cmbcomp.Items.Clear()

            sql = "Select * from tblcompany where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbcomp.Items.Add(dr("company"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbcomp.Items.Count <> 0 Then
                cmbcomp.Items.Add("All")
                cmbcomp.SelectedItem = "All"
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbcomp_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcomp.SelectedIndexChanged
        Try
            cmbwhse.Items.Clear()

            If cmbcomp.SelectedItem = "All" Then
                sql = "Select * from tblwhse where status='1'"
            Else
                sql = "Select * from tblwhse where company='" & cmbcomp.SelectedItem & "' and status='1'"
            End If
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbwhse.Items.Add(dr("whsename"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbwhse.Items.Count <> 0 Then
                cmbwhse.Items.Add("All")
                cmbwhse.SelectedItem = "All"
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbwhse_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbwhse.SelectedIndexChanged
        Try
            cmbvtype.Items.Clear()

            sql = "Select * from tblvtype where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbvtype.Items.Add(dr("vtype"))
            End While
            dr.Read()
            cmd.Dispose()
            conn.Close()

            If cmbvtype.Items.Count <> 0 Then
                cmbvtype.Items.Add("All")
                cmbvtype.SelectedItem = "All"
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        Try
            If cmbcomp.SelectedItem <> "" And cmbvtype.SelectedItem <> "" And cmbwhse.SelectedItem <> "" Then
                Dim tempgenid As Integer = 0

                sql = "Select * from tblgeneral where status='1'"

                If cmbcomp.SelectedItem <> "All" Then
                    sql = sql & " and company='" & cmbcomp.SelectedItem & "'"
                End If

                If cmbwhse.SelectedItem <> "All" Then
                    sql = sql & " and whsename='" & cmbwhse.SelectedItem & "'"
                End If

                If cmbvtype.SelectedItem <> "All" Then
                    sql = sql & " and vtype='" & cmbvtype.SelectedItem & "'"
                End If

                'MsgBox(rptgeneralprev.condition)

                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    tempgenid = dr("genid")
                    If rbid.Checked = True Then
                        rptidinfoprev.condition = ""
                        rptidinfoprev.Close()
                        '/rptidinfoprev.MdiParent = mdiform
                        If cmbcomp.SelectedItem <> "All" Then
                            rptidinfoprev.condition = rptidinfoprev.condition & " and company='" & cmbcomp.SelectedItem & "'"
                        End If
                        If cmbwhse.SelectedItem <> "All" Then
                            rptidinfoprev.condition = rptidinfoprev.condition & " and whsename='" & cmbwhse.SelectedItem & "'"
                        End If
                        If cmbvtype.SelectedItem <> "All" Then
                            rptidinfoprev.condition = rptidinfoprev.condition & " and vtype='" & cmbvtype.SelectedItem & "'"
                        End If
                        rptidinfoprev.WindowState = FormWindowState.Maximized
                        rptidinfoprev.ShowDialog()

                    ElseIf rbdiesel.Checked = True Then
                        rptdieselprev.condition = ""
                        rptdieselprev.Close()
                        '/rptdieselprev.MdiParent = mdiform
                        If cmbcomp.SelectedItem <> "All" Then
                            rptdieselprev.condition = rptdieselprev.condition & " and tblgeneral.company='" & cmbcomp.SelectedItem & "'"
                        End If
                        If cmbwhse.SelectedItem <> "All" Then
                            rptdieselprev.condition = rptdieselprev.condition & " and tblgeneral.whsename='" & cmbwhse.SelectedItem & "'"
                        End If
                        If cmbvtype.SelectedItem <> "All" Then
                            rptdieselprev.condition = rptdieselprev.condition & " and tblgeneral.vtype='" & cmbvtype.SelectedItem & "'"
                        End If
                        rptdieselprev.WindowState = FormWindowState.Maximized
                        rptdieselprev.ShowDialog()

                    ElseIf rbgen.Checked = True Then
                        rptgeneralprev.condition = ""
                        rptgeneralprev.Close()
                        '/rptgeneralprev.MdiParent = mdiform
                        If cmbcomp.SelectedItem <> "All" Then
                            rptgeneralprev.condition = rptgeneralprev.condition & " and tblgeneral.company='" & cmbcomp.SelectedItem & "'"
                        End If
                        If cmbwhse.SelectedItem <> "All" Then
                            rptgeneralprev.condition = rptgeneralprev.condition & " and tblgeneral.whsename='" & cmbwhse.SelectedItem & "'"
                        End If
                        If cmbvtype.SelectedItem <> "All" Then
                            rptgeneralprev.condition = rptgeneralprev.condition & " and tblgeneral.vtype='" & cmbvtype.SelectedItem & "'"
                        End If
                        rptgeneralprev.WindowState = FormWindowState.Maximized
                        rptgeneralprev.ShowDialog()
                    End If
                    
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            Else
                MsgBox("Complete the fields.", MsgBoxStyle.Exclamation, "")
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class