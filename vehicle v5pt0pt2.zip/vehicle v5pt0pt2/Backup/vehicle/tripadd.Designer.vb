﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class tripadd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(tripadd))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.btnview = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.chkpick = New System.Windows.Forms.CheckBox
        Me.list1 = New System.Windows.Forms.ListBox
        Me.lblmake = New System.Windows.Forms.Label
        Me.lblvtype = New System.Windows.Forms.Label
        Me.cmbhelper = New System.Windows.Forms.ComboBox
        Me.cmbtranstype = New System.Windows.Forms.ComboBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.lbltripnum = New System.Windows.Forms.Label
        Me.btntaxi = New System.Windows.Forms.Button
        Me.btnexisting = New System.Windows.Forms.Button
        Me.txtetd = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.cmbwhse = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.datepick = New System.Windows.Forms.DateTimePicker
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtrems = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.btncancel = New System.Windows.Forms.Button
        Me.cmbdriver = New System.Windows.Forms.ComboBox
        Me.cmbplate = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.btnadd = New System.Windows.Forms.Button
        Me.Label5 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.dateto = New System.Windows.Forms.DateTimePicker
        Me.Label11 = New System.Windows.Forms.Label
        Me.cmbvtype = New System.Windows.Forms.ComboBox
        Me.btnvcancel = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.btnok = New System.Windows.Forms.Button
        Me.chkhide = New System.Windows.Forms.CheckBox
        Me.datefrom = New System.Windows.Forms.DateTimePicker
        Me.Label7 = New System.Windows.Forms.Label
        Me.cmbvcus = New System.Windows.Forms.ComboBox
        Me.cmbvwhse = New System.Windows.Forms.ComboBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.Panel14 = New System.Windows.Forms.Panel
        Me.grdadd = New System.Windows.Forms.DataGridView
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column6 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel14.SuspendLayout()
        CType(Me.grdadd, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnview
        '
        Me.btnview.Location = New System.Drawing.Point(308, 105)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(154, 23)
        Me.btnview.TabIndex = 0
        Me.btnview.Text = "View All Available"
        Me.btnview.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 78)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Customer"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Warehouse:"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.AutoScroll = True
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.64401!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.35599!))
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox2, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox1, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1256, 140)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkpick)
        Me.GroupBox2.Controls.Add(Me.list1)
        Me.GroupBox2.Controls.Add(Me.lblmake)
        Me.GroupBox2.Controls.Add(Me.lblvtype)
        Me.GroupBox2.Controls.Add(Me.cmbhelper)
        Me.GroupBox2.Controls.Add(Me.cmbtranstype)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.lbltripnum)
        Me.GroupBox2.Controls.Add(Me.btntaxi)
        Me.GroupBox2.Controls.Add(Me.btnexisting)
        Me.GroupBox2.Controls.Add(Me.txtetd)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.cmbwhse)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.datepick)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.txtrems)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.btncancel)
        Me.GroupBox2.Controls.Add(Me.cmbdriver)
        Me.GroupBox2.Controls.Add(Me.cmbplate)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.btnadd)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox2.Location = New System.Drawing.Point(500, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(753, 134)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Trip"
        '
        'chkpick
        '
        Me.chkpick.Location = New System.Drawing.Point(543, 83)
        Me.chkpick.Name = "chkpick"
        Me.chkpick.Size = New System.Drawing.Size(76, 44)
        Me.chkpick.TabIndex = 22
        Me.chkpick.Text = "Pickup Trip Only"
        Me.chkpick.UseVisualStyleBackColor = True
        Me.chkpick.Visible = False
        '
        'list1
        '
        Me.list1.FormattingEnabled = True
        Me.list1.ItemHeight = 15
        Me.list1.Location = New System.Drawing.Point(239, 18)
        Me.list1.Name = "list1"
        Me.list1.Size = New System.Drawing.Size(33, 19)
        Me.list1.TabIndex = 4
        Me.list1.Visible = False
        '
        'lblmake
        '
        Me.lblmake.AutoSize = True
        Me.lblmake.Location = New System.Drawing.Point(564, 48)
        Me.lblmake.Name = "lblmake"
        Me.lblmake.Size = New System.Drawing.Size(38, 15)
        Me.lblmake.TabIndex = 21
        Me.lblmake.Text = "make"
        Me.lblmake.Visible = False
        '
        'lblvtype
        '
        Me.lblvtype.AutoSize = True
        Me.lblvtype.Location = New System.Drawing.Point(524, 48)
        Me.lblvtype.Name = "lblvtype"
        Me.lblvtype.Size = New System.Drawing.Size(34, 15)
        Me.lblvtype.TabIndex = 20
        Me.lblvtype.Text = "vtype"
        Me.lblvtype.Visible = False
        '
        'cmbhelper
        '
        Me.cmbhelper.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbhelper.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbhelper.FormattingEnabled = True
        Me.cmbhelper.Location = New System.Drawing.Point(315, 45)
        Me.cmbhelper.Name = "cmbhelper"
        Me.cmbhelper.Size = New System.Drawing.Size(187, 23)
        Me.cmbhelper.TabIndex = 19
        '
        'cmbtranstype
        '
        Me.cmbtranstype.FormattingEnabled = True
        Me.cmbtranstype.Location = New System.Drawing.Point(181, 105)
        Me.cmbtranstype.Name = "cmbtranstype"
        Me.cmbtranstype.Size = New System.Drawing.Size(48, 23)
        Me.cmbtranstype.TabIndex = 4
        Me.cmbtranstype.Visible = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(262, 48)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(47, 15)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Helper:"
        '
        'lbltripnum
        '
        Me.lbltripnum.AutoSize = True
        Me.lbltripnum.Location = New System.Drawing.Point(608, 48)
        Me.lbltripnum.Name = "lbltripnum"
        Me.lbltripnum.Size = New System.Drawing.Size(49, 15)
        Me.lbltripnum.TabIndex = 16
        Me.lbltripnum.Text = "tripnum"
        Me.lbltripnum.Visible = False
        '
        'btntaxi
        '
        Me.btntaxi.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btntaxi.Image = CType(resources.GetObject("btntaxi.Image"), System.Drawing.Image)
        Me.btntaxi.Location = New System.Drawing.Point(647, 79)
        Me.btntaxi.Name = "btntaxi"
        Me.btntaxi.Size = New System.Drawing.Size(100, 23)
        Me.btntaxi.TabIndex = 13
        Me.btntaxi.Text = "   Taxi"
        Me.btntaxi.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btntaxi.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btntaxi.UseVisualStyleBackColor = True
        '
        'btnexisting
        '
        Me.btnexisting.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnexisting.Image = CType(resources.GetObject("btnexisting.Image"), System.Drawing.Image)
        Me.btnexisting.Location = New System.Drawing.Point(647, 35)
        Me.btnexisting.Name = "btnexisting"
        Me.btnexisting.Size = New System.Drawing.Size(100, 41)
        Me.btnexisting.TabIndex = 12
        Me.btnexisting.Text = "Add to Existing Trip"
        Me.btnexisting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnexisting.UseVisualStyleBackColor = True
        '
        'txtetd
        '
        Me.txtetd.Location = New System.Drawing.Point(73, 105)
        Me.txtetd.Name = "txtetd"
        Me.txtetd.Size = New System.Drawing.Size(103, 21)
        Me.txtetd.TabIndex = 8
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(39, 108)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(34, 15)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "ETD:"
        '
        'cmbwhse
        '
        Me.cmbwhse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbwhse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbwhse.FormattingEnabled = True
        Me.cmbwhse.Location = New System.Drawing.Point(73, 76)
        Me.cmbwhse.Name = "cmbwhse"
        Me.cmbwhse.Size = New System.Drawing.Size(156, 23)
        Me.cmbwhse.TabIndex = 7
        Me.cmbwhse.Tag = "warehouses"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 78)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 15)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Origin:"
        '
        'datepick
        '
        Me.datepick.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datepick.Location = New System.Drawing.Point(73, 48)
        Me.datepick.MinDate = New Date(2017, 1, 1, 0, 0, 0, 0)
        Me.datepick.Name = "datepick"
        Me.datepick.Size = New System.Drawing.Size(156, 21)
        Me.datepick.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 50)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 15)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Trip Date:"
        '
        'txtrems
        '
        Me.txtrems.Location = New System.Drawing.Point(315, 72)
        Me.txtrems.Multiline = True
        Me.txtrems.Name = "txtrems"
        Me.txtrems.Size = New System.Drawing.Size(222, 56)
        Me.txtrems.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(248, 76)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(61, 15)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Remarks:"
        '
        'btncancel
        '
        Me.btncancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncancel.Image = CType(resources.GetObject("btncancel.Image"), System.Drawing.Image)
        Me.btncancel.Location = New System.Drawing.Point(647, 105)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(100, 23)
        Me.btncancel.TabIndex = 14
        Me.btncancel.Text = "Cancel"
        Me.btncancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'cmbdriver
        '
        Me.cmbdriver.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbdriver.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbdriver.FormattingEnabled = True
        Me.cmbdriver.Items.AddRange(New Object() {"", "Driver1", "Driver2", "Driver3"})
        Me.cmbdriver.Location = New System.Drawing.Point(315, 16)
        Me.cmbdriver.Name = "cmbdriver"
        Me.cmbdriver.Size = New System.Drawing.Size(187, 23)
        Me.cmbdriver.TabIndex = 6
        '
        'cmbplate
        '
        Me.cmbplate.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbplate.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbplate.FormattingEnabled = True
        Me.cmbplate.Location = New System.Drawing.Point(73, 16)
        Me.cmbplate.Name = "cmbplate"
        Me.cmbplate.Size = New System.Drawing.Size(156, 23)
        Me.cmbplate.Sorted = True
        Me.cmbplate.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(267, 19)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(42, 15)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Driver:"
        '
        'btnadd
        '
        Me.btnadd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnadd.Image = CType(resources.GetObject("btnadd.Image"), System.Drawing.Image)
        Me.btnadd.Location = New System.Drawing.Point(647, 8)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(100, 23)
        Me.btnadd.TabIndex = 11
        Me.btnadd.Text = "Add Trip"
        Me.btnadd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnadd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 18)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 15)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Plate No:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dateto)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.cmbvtype)
        Me.GroupBox1.Controls.Add(Me.btnvcancel)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.btnok)
        Me.GroupBox1.Controls.Add(Me.chkhide)
        Me.GroupBox1.Controls.Add(Me.datefrom)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.cmbvcus)
        Me.GroupBox1.Controls.Add(Me.cmbvwhse)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.btnview)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(491, 134)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "View Available Transaction"
        '
        'dateto
        '
        Me.dateto.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dateto.Location = New System.Drawing.Point(308, 22)
        Me.dateto.MinDate = New Date(2017, 1, 1, 0, 0, 0, 0)
        Me.dateto.Name = "dateto"
        Me.dateto.Size = New System.Drawing.Size(154, 21)
        Me.dateto.TabIndex = 16
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(279, 27)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(23, 15)
        Me.Label11.TabIndex = 16
        Me.Label11.Text = "To:"
        '
        'cmbvtype
        '
        Me.cmbvtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbvtype.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.cmbvtype.FormattingEnabled = True
        Me.cmbvtype.Items.AddRange(New Object() {"", "JPSC STOCK TRANSFER PICKUP", "JPSC STOCK TRANSFER WHSE TO WHSE", "JPSC SALES TRANSACTION", "JPSC SALES TRANSACTION PICKUP", "CUSTOMER SALES TRANSACTION WHSE", "CUSTOMER SALES TRANSACTION PICKUP", "TRUCKING STOCK TRANSFER PICKUP", "TRUCKING SALES TRANSACTION PICKUP"})
        Me.cmbvtype.Location = New System.Drawing.Point(101, 105)
        Me.cmbvtype.Name = "cmbvtype"
        Me.cmbvtype.Size = New System.Drawing.Size(172, 23)
        Me.cmbvtype.TabIndex = 19
        '
        'btnvcancel
        '
        Me.btnvcancel.Location = New System.Drawing.Point(387, 78)
        Me.btnvcancel.Name = "btnvcancel"
        Me.btnvcancel.Size = New System.Drawing.Size(75, 23)
        Me.btnvcancel.TabIndex = 21
        Me.btnvcancel.Text = "Cancel"
        Me.btnvcancel.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(24, 108)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(73, 15)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Trans. Type:"
        '
        'btnok
        '
        Me.btnok.Location = New System.Drawing.Point(308, 77)
        Me.btnok.Name = "btnok"
        Me.btnok.Size = New System.Drawing.Size(75, 23)
        Me.btnok.TabIndex = 20
        Me.btnok.Text = "Ok"
        Me.btnok.UseVisualStyleBackColor = True
        '
        'chkhide
        '
        Me.chkhide.AutoSize = True
        Me.chkhide.Checked = True
        Me.chkhide.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkhide.Location = New System.Drawing.Point(282, 53)
        Me.chkhide.Name = "chkhide"
        Me.chkhide.Size = New System.Drawing.Size(189, 19)
        Me.chkhide.TabIndex = 13
        Me.chkhide.Text = "Hide In Process Transactions"
        Me.chkhide.UseVisualStyleBackColor = True
        '
        'datefrom
        '
        Me.datefrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datefrom.Location = New System.Drawing.Point(140, 23)
        Me.datefrom.MinDate = New Date(2017, 1, 1, 0, 0, 0, 0)
        Me.datefrom.Name = "datefrom"
        Me.datefrom.Size = New System.Drawing.Size(133, 21)
        Me.datefrom.TabIndex = 15
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(21, 27)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(115, 15)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Created Date From:"
        '
        'cmbvcus
        '
        Me.cmbvcus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbvcus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbvcus.FormattingEnabled = True
        Me.cmbvcus.Location = New System.Drawing.Point(101, 75)
        Me.cmbvcus.Name = "cmbvcus"
        Me.cmbvcus.Size = New System.Drawing.Size(172, 23)
        Me.cmbvcus.TabIndex = 18
        '
        'cmbvwhse
        '
        Me.cmbvwhse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbvwhse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbvwhse.Enabled = False
        Me.cmbvwhse.FormattingEnabled = True
        Me.cmbvwhse.Location = New System.Drawing.Point(101, 48)
        Me.cmbvwhse.Name = "cmbvwhse"
        Me.cmbvwhse.Size = New System.Drawing.Size(172, 23)
        Me.cmbvwhse.TabIndex = 17
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Location = New System.Drawing.Point(1212, 549)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(50, 10)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel14
        '
        Me.Panel14.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel14.AutoScroll = True
        Me.Panel14.Controls.Add(Me.grdadd)
        Me.Panel14.Controls.Add(Me.TableLayoutPanel1)
        Me.Panel14.Location = New System.Drawing.Point(12, 12)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(1256, 547)
        Me.Panel14.TabIndex = 28
        '
        'grdadd
        '
        Me.grdadd.AllowUserToAddRows = False
        Me.grdadd.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdadd.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdadd.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdadd.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdadd.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdadd.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdadd.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.grdadd.ColumnHeadersHeight = 30
        Me.grdadd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdadd.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column5, Me.Column6, Me.Column7, Me.Column8, Me.Column9, Me.Column10, Me.Column11, Me.Column12, Me.Column13, Me.Column14})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdadd.DefaultCellStyle = DataGridViewCellStyle3
        Me.grdadd.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdadd.EnableHeadersVisualStyles = False
        Me.grdadd.GridColor = System.Drawing.Color.Salmon
        Me.grdadd.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdadd.Location = New System.Drawing.Point(0, 145)
        Me.grdadd.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdadd.Name = "grdadd"
        Me.grdadd.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdadd.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.grdadd.RowHeadersWidth = 15
        Me.grdadd.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.NullValue = Nothing
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdadd.RowsDefaultCellStyle = DataGridViewCellStyle5
        Me.grdadd.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdadd.Size = New System.Drawing.Size(1256, 403)
        Me.grdadd.TabIndex = 12
        '
        'Column5
        '
        Me.Column5.HeaderText = "ID"
        Me.Column5.Name = "Column5"
        Me.Column5.Visible = False
        '
        'Column6
        '
        Me.Column6.HeaderText = "Select"
        Me.Column6.Name = "Column6"
        Me.Column6.Width = 60
        '
        'Column7
        '
        Me.Column7.HeaderText = "Transaction #"
        Me.Column7.Name = "Column7"
        Me.Column7.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Column7.Width = 120
        '
        'Column8
        '
        Me.Column8.HeaderText = "Reference #"
        Me.Column8.Name = "Column8"
        Me.Column8.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Column8.Width = 150
        '
        'Column9
        '
        Me.Column9.HeaderText = "Booked Date"
        Me.Column9.Name = "Column9"
        Me.Column9.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Column9.Width = 80
        '
        'Column10
        '
        Me.Column10.HeaderText = "Recipient"
        Me.Column10.Name = "Column10"
        Me.Column10.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Column10.Width = 220
        '
        'Column11
        '
        Me.Column11.HeaderText = "Transaction Type"
        Me.Column11.Name = "Column11"
        Me.Column11.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Column11.Width = 220
        '
        'Column12
        '
        Me.Column12.HeaderText = "Status"
        Me.Column12.Name = "Column12"
        Me.Column12.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Column12.Width = 80
        '
        'Column13
        '
        Me.Column13.HeaderText = "Notes"
        Me.Column13.Name = "Column13"
        Me.Column13.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Column13.Width = 300
        '
        'Column14
        '
        Me.Column14.HeaderText = "chkint"
        Me.Column14.Name = "Column14"
        Me.Column14.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Column14.Visible = False
        '
        'tripadd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1274, 571)
        Me.Controls.Add(Me.Panel14)
        Me.Controls.Add(Me.Button1)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "tripadd"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Trip Scheduling"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel14.ResumeLayout(False)
        CType(Me.grdadd, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnview As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents datepick As System.Windows.Forms.DateTimePicker
    Friend WithEvents cmbwhse As System.Windows.Forms.ComboBox
    Friend WithEvents cmbdriver As System.Windows.Forms.ComboBox
    Friend WithEvents cmbplate As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents datefrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cmbvcus As System.Windows.Forms.ComboBox
    Friend WithEvents cmbvwhse As System.Windows.Forms.ComboBox
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents cmbvtype As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txtrems As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents chkhide As System.Windows.Forms.CheckBox
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents btnvcancel As System.Windows.Forms.Button
    Friend WithEvents btnok As System.Windows.Forms.Button
    Friend WithEvents txtetd As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents dateto As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents btnexisting As System.Windows.Forms.Button
    Friend WithEvents btntaxi As System.Windows.Forms.Button
    Friend WithEvents lbltripnum As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents cmbtranstype As System.Windows.Forms.ComboBox
    Friend WithEvents cmbhelper As System.Windows.Forms.ComboBox
    Friend WithEvents lblvtype As System.Windows.Forms.Label
    Friend WithEvents lblmake As System.Windows.Forms.Label
    Friend WithEvents list1 As System.Windows.Forms.ListBox
    Friend WithEvents chkpick As System.Windows.Forms.CheckBox
    Friend WithEvents grdadd As System.Windows.Forms.DataGridView
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column14 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
