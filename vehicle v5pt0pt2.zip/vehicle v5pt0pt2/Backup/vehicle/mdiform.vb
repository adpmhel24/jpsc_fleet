﻿Public Class mdiform

    Private Sub mdiform_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub mdiform_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim a As String = MsgBox("Are you sure you want to close?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            moduless.Show()
            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub mdiform_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        vmanage.MdiParent = Me
        vmanage.Show()
        vmanage.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub logouttool_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles logouttool.Click
        Dim a As String = MsgBox("Are you sure you want to logout?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            moduless.Text = "Modules"
            login.Show()
            Me.Dispose()
        End If
    End Sub

    Private Sub MenuStrip2_ItemAdded(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemEventArgs) Handles MenuStrip2.ItemAdded
        Dim s As String = e.Item.GetType().ToString()
        If (s = "System.Windows.Forms.MdiControlStrip+SystemMenuItem") Then
            e.Item.Visible = False
        End If
    End Sub

    Private Sub VehicleTypeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleTypeToolStripMenuItem.Click
        vtypes.MdiParent = Me
        vtypes.Focus()
        vtypes.Show()
        vtypes.WindowState = FormWindowState.Normal
    End Sub

    Private Sub WarehouseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        whse.MdiParent = Me
        whse.Focus()
        whse.Show()
        whse.WindowState = FormWindowState.Normal
    End Sub

    Private Sub MakeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MakeToolStripMenuItem.Click
        makes.MdiParent = Me
        makes.Focus()
        makes.Show()
        makes.WindowState = FormWindowState.Normal
    End Sub

    Private Sub SupplierToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SupplierToolStripMenuItem.Click
        supplier.MdiParent = Me
        supplier.Focus()
        supplier.Show()
        supplier.WindowState = FormWindowState.Normal
    End Sub

    Private Sub DocumentsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        doc.MdiParent = Me
        doc.Focus()
        doc.Show()
        doc.WindowState = FormWindowState.Normal
    End Sub

    Private Sub CompanyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        comps.MdiParent = Me
        comps.Focus()
        comps.Show()
        comps.WindowState = FormWindowState.Normal
    End Sub

    Private Sub BodyTypeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BodyTypeToolStripMenuItem.Click
        bodytyp.MdiParent = Me
        bodytyp.Focus()
        bodytyp.Show()
        bodytyp.WindowState = FormWindowState.Normal
    End Sub

    Private Sub UpdateMoreVehicleDocumentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateMoreVehicleDocumentToolStripMenuItem.Click
        updatevdocs.MdiParent = Me
        updatevdocs.Focus()
        updatevdocs.Show()
        updatevdocs.WindowState = FormWindowState.Normal
    End Sub

    Private Sub ImportExcelToAddMoreVehiclesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportExcelToAddMoreVehiclesToolStripMenuItem.Click
        importvadd.MdiParent = Me
        importvadd.Show()
        importvadd.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub PMServiceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PMServiceToolStripMenuItem.Click
        pms.MdiParent = Me
        pms.Focus()
        pms.Show()
        pms.WindowState = FormWindowState.Normal
    End Sub

    Private Sub ListOfWarehouseToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfWarehouseToolStripMenuItem1.Click
        rptwhse.MdiParent = Me
        rptwhse.Show()
        rptwhse.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ListOfBodyTypeToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfBodyTypeToolStripMenuItem1.Click
        rptbody.MdiParent = Me
        rptbody.Show()
        rptbody.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ListOfVehicleTypeToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfVehicleTypeToolStripMenuItem1.Click
        rptvtype.MdiParent = Me
        rptvtype.Show()
        rptvtype.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ListOfCompanyToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfCompanyToolStripMenuItem1.Click
        rptcompany.MdiParent = Me
        rptcompany.Show()
        rptcompany.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ListOfMakeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfMakeToolStripMenuItem.Click
        rptmake.MdiParent = Me
        rptmake.Show()
        rptmake.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ListOfSupplierToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfSupplierToolStripMenuItem.Click
        rptsupplier.MdiParent = Me
        rptsupplier.Show()
        rptsupplier.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ListOfDocumentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfDocumentToolStripMenuItem.Click
        rptdocu.MdiParent = Me
        rptdocu.Show()
        rptdocu.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ListOfPMServicesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfPMServicesToolStripMenuItem.Click
        rptpms.MdiParent = Me
        rptpms.Show()
        rptpms.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub VehicleNotificationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleNotificationToolStripMenuItem.Click
        rptnotifs.MdiParent = Me
        rptnotifs.Focus()
        rptnotifs.Show()
        rptnotifs.WindowState = FormWindowState.Normal
    End Sub

    Private Sub RepairServicesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RepairServicesToolStripMenuItem.Click
        repair.MdiParent = Me
        repair.Focus()
        repair.Show()
        repair.WindowState = FormWindowState.Normal
    End Sub

    Private Sub ListOfPartsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfPartsToolStripMenuItem.Click
        parts.MdiParent = Me
        parts.Focus()
        parts.Show()
        parts.WindowState = FormWindowState.Normal
    End Sub

    Private Sub VehicleStatusToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleStatusToolStripMenuItem.Click
        rptvstatus.MdiParent = Me
        rptvstatus.Focus()
        rptvstatus.Show()
        rptvstatus.WindowState = FormWindowState.Normal
    End Sub

    Private Sub VehicleGeneralInformationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleGeneralInformationToolStripMenuItem.Click
        rptgeneral.MdiParent = Me
        rptgeneral.Focus()
        rptgeneral.Show()
        rptgeneral.WindowState = FormWindowState.Normal
    End Sub

    Private Sub BackupDatabasToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackupDatabasToolStripMenuItem.Click
        backup.MdiParent = Me
        backup.Focus()
        backup.Show()
        backup.WindowState = FormWindowState.Normal
    End Sub

    Private Sub ImportExcelToUpdateVehicleParametersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportExcelToUpdateVehicleParametersToolStripMenuItem.Click
        importparameters.MdiParent = Me
        importparameters.Show()
        importparameters.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub VehicleChangeOilToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleChangeOilToolStripMenuItem.Click
        rptchangeoil.MdiParent = Me
        rptchangeoil.Show()
        rptchangeoil.WindowState = FormWindowState.Maximized
    End Sub
End Class