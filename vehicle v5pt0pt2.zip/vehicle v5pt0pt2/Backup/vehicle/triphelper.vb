﻿Imports System.iio
Imports System.Data.SqlClient
Imports System.Drawing

Public Class triphelper
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try
            If Trim(cmbhelper.Text) = "" Then
                MsgBox("No helper.", MsgBoxStyle.Information, "")
            End If

            Dim a As String = MsgBox("Are you sure you want to save updated helper.", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
            If a = vbYes Then
                'save
                sql = "Update tbltripsum set helper='" & Trim(cmbhelper.Text) & "' where tripnum='" & lbltripnum.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Sucessfully Saved.", MsgBoxStyle.Information, "")
                Me.Close()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        If Trim(cmbhelper.Text) = "" Then
            MsgBox("Cancel edit helper.", MsgBoxStyle.Information, "")
        End If
        Me.Close()

    End Sub

    Private Sub triprems_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cmbhelper.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbhelper.DropDownStyle = ComboBoxStyle.DropDown
        cmbhelper.AutoCompleteSource = AutoCompleteSource.ListItems
    End Sub

    Private Sub cmbhelper_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbhelper.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbhelper_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbhelper.Leave
        Try
            If Trim(cmbhelper.Text) <> "" Then

                sql = "Select * from tblhelper where status='1' and helper='" & Trim(cmbhelper.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbhelper.SelectedItem = dr("helper")
                Else
                    'MsgBox("Cannot found helper " & cmbhelper.Text, MsgBoxStyle.Critical, "")
                    'cmbhelper.Text = ""
                    'Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                cmbhelper.Text = StrConv(Trim(cmbhelper.Text), VbStrConv.ProperCase)
            End If


        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub helper()
        Try
            cmbhelper.Items.Clear()
            cmbhelper.Items.Add("")
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tblhelper where status='1' order by helper"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read

                If dr1("company").ToString = "Customer" And Trim(lblvtype.Text) = "CUSTOMER TRUCK" Then
                    cmbhelper.Items.Add(dr1("helper"))

                ElseIf dr1("company").ToString = "Trucking" And Trim(lblvtype.Text) = "TRUCKING TRUCK" Then
                    cmbhelper.Items.Add(dr1("helper"))

                ElseIf dr1("company").ToString <> "Customer" And Trim(lblvtype.Text) = "CUSTOMER TRUCK" Then

                ElseIf dr1("company").ToString <> "Trucking" And Trim(lblvtype.Text) = "TRUCKING TRUCK" Then

                ElseIf dr1("company").ToString <> "Trucking" And dr1("company").ToString <> "Customer" Then
                    cmbhelper.Items.Add(dr1("helper"))

                End If

            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbhelper_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbhelper.SelectedIndexChanged

    End Sub
End Class