﻿Imports System.IO
Imports System.Data.SqlClient

Public Class tripdar
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub txtstart_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtstart.TextChanged
        'numbers only and period
    End Sub

    Private Sub txtend_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtend.TextChanged
        'numbers only and period
    End Sub
End Class