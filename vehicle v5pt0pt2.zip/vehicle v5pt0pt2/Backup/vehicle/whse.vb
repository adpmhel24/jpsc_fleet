﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class whse
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim stat As String
    Public whsecnf As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            If Trim(txtwhse.Text) = "" Then
                grdwhse.Rows.Clear()
                MsgBox("Input warehouse name first.", MsgBoxStyle.Exclamation, "")
                txtwhse.Focus()
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

            grdwhse.Rows.Clear()
            sql = "Select * from tblwhse where whsename like '" & Trim(txtwhse.Text) & "%'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdwhse.Rows.Add(dr("whseid"), dr("whsename"), dr("address"), dr("company"), stat)
                txtwhse.Text = ""
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If grdwhse.Rows.Count = 0 Then
                MsgBox("Cannot found " & Trim(txtwhse.Text), MsgBoxStyle.Critical, "")
                txtwhse.Text = ""
                txtwhse.Focus()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If Trim(txtwhse.Text) <> "" And cmbcompany.SelectedItem <> "" Then
                sql = "Select * from tblwhse where whsename='" & Trim(txtwhse.Text) & "' and company='" & cmbcompany.SelectedItem & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    MsgBox(Trim(txtwhse.Text) & " is already exist", MsgBoxStyle.Information, "")
                    btnupdate.Text = "&Update"
                    txtwhse.Text = ""
                    txtwhse.Focus()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                whsecnf = False
                confirm.ShowDialog()
                If whsecnf = True Then
                    sql = "Insert into tblwhse (company, whsename, address, datecreated, createdby, datemodified, modifiedby, status) values('" & cmbcompany.SelectedItem & "','" & Trim(txtwhse.Text) & "','" & Trim(txtaddress.Text) & "',GetDate(),'" & login.cashier & "',GetDate(),'" & login.cashier & "','1')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Added", MsgBoxStyle.Information, "")
                    btnview.PerformClick()
                End If

                txtwhse.Text = ""
                txtwhse.Focus()
                whsecnf = False
            Else
                MsgBox("Input warehouse name first", MsgBoxStyle.Exclamation, "")
                txtwhse.Focus()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        Try
            loadcompsch()
            grdwhse.Rows.Clear()
            Dim stat As String = ""


            sql = "Select * from tblwhse order by company, whsename"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdwhse.Rows.Add(dr("whseid"), dr("whsename"), dr("address"), dr("company"), stat)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If grdwhse.Rows.Count = 0 Then
                btnupdate.Enabled = False
            Else
                btnupdate.Enabled = True
            End If

            btncancel.PerformClick()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtwhse_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtwhse.Leave
        '/txtwhse.Text = StrConv(txtwhse.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txttype_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtwhse.TextChanged
        If (Trim(txtwhse.Text) <> "" Or Trim(txtaddress.Text) <> "") Then
            btncancel.Enabled = True
        ElseIf (Trim(txtwhse.Text) = "" And Trim(txtaddress.Text) = "") And btnupdate.Text = "&Save" Then
            btncancel.Enabled = True
        Else
            btncancel.Enabled = False
        End If

        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtwhse.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtwhse.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtwhse.Text.Length - 1
            Letter = txtwhse.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtwhse.Text = theText
        txtwhse.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtaddress_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtaddress.Leave
        txtaddress.Text = StrConv(txtaddress.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txtaddress_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtaddress.TextChanged
        If (Trim(txtwhse.Text) <> "" Or Trim(txtaddress.Text) <> "") Then
            btncancel.Enabled = True
        ElseIf (Trim(txtwhse.Text) = "" And Trim(txtaddress.Text) = "") And btnupdate.Text = "&Save" Then
            btncancel.Enabled = True
        Else
            btncancel.Enabled = False
        End If

        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtaddress.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtaddress.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtaddress.Text.Length - 1
            Letter = txtaddress.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtaddress.Text = theText
        txtaddress.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub whse_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        
    End Sub

    Private Sub whse_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnview.PerformClick()
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        txtwhse.Text = ""
        txtaddress.Text = ""
        btnupdate.Text = "&Update"
        btnsearch.Enabled = True
        btndeactivate.Enabled = True
        btnadd.Enabled = True
        btncancel.Enabled = False
        'MsgBox(btncancel.Enabled)
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdwhse.SelectedRows.Count = 1 Or grdwhse.SelectedCells.Count = 1 Then
                If btnupdate.Text = "&Update" Then
                    If grdwhse.Rows(grdwhse.CurrentRow.Index).Cells(4).Value = "Deactivated" Then
                        MsgBox("Cannot update deactivated warehouse name.", MsgBoxStyle.Exclamation, "")
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    lblcat.Text = grdwhse.Rows(grdwhse.CurrentRow.Index).Cells(1).Value
                    txtwhse.Text = grdwhse.Rows(grdwhse.CurrentRow.Index).Cells(1).Value
                    txtaddress.Text = grdwhse.Rows(grdwhse.CurrentRow.Index).Cells(2).Value
                    cmbcompany.SelectedItem = grdwhse.Rows(grdwhse.CurrentRow.Index).Cells(3).Value
                    lblid.Text = grdwhse.Rows(grdwhse.CurrentRow.Index).Cells(0).Value
                    btnsearch.Enabled = False
                    btnadd.Enabled = False
                    btndeactivate.Enabled = False
                    btnupdate.Text = "&Save"
                    btncancel.Enabled = True
                Else
                    'update
                    If Trim(txtwhse.Text) = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Warehouse name should not be empty.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If

                    sql = "Select * from tblwhse where whsename='" & Trim(txtwhse.Text) & "' and address='" & Trim(txtaddress.Text) & "' and company='" & cmbcompany.SelectedItem & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox(Trim(txtwhse.Text) & " is already exist", MsgBoxStyle.Information, "")
                        btnupdate.Text = "&Update"
                        btnsearch.Enabled = True
                        btnadd.Enabled = True
                        btncancel.Enabled = False
                        btndeactivate.Enabled = False
                        txtwhse.Text = ""
                        txtaddress.Text = ""
                        txtwhse.Focus()
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    whsecnf = False
                    confirm.ShowDialog()
                    If whsecnf = True Then
                        ExecuteUpdate(strconn)
                    End If

                    btnupdate.Text = "&Update"
                    btnsearch.Enabled = True
                    btnadd.Enabled = True
                    btndeactivate.Enabled = True
                    btncancel.Enabled = False
                    txtwhse.Text = ""
                    txtaddress.Text = ""
                    txtwhse.Focus()
                    whsecnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
                btnview.PerformClick()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteUpdate(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                ' If Trim(txtwhse.Text) <> Trim(lblcat.Text) Then
                sql = "Update tblwhse set whsename='" & Trim(txtwhse.Text) & "', address='" & Trim(txtaddress.Text) & "',company='" & cmbcompany.SelectedItem & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where whseid='" & lblid.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                sql = "Update tbldriver set whsename='" & Trim(txtwhse.Text) & "', company='" & cmbcompany.SelectedItem & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where whsename='" & lblcat.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                'update other tbl in database
                sql = "Update tblgeneral set whsename='" & Trim(txtwhse.Text) & "', company='" & cmbcompany.SelectedItem & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where whsename='" & lblcat.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                sql = "Update tblhelper set whsename='" & Trim(txtwhse.Text) & "', company='" & cmbcompany.SelectedItem & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where whsename='" & lblcat.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                sql = "Update tblversion set whsename='" & Trim(txtwhse.Text) & "' where whsename='" & lblcat.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                btnview.PerformClick()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btndeactivate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndeactivate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdwhse.SelectedRows.Count = 1 Or grdwhse.SelectedCells.Count = 1 Then
                lblid.Text = grdwhse.Rows(grdwhse.CurrentRow.Index).Cells(0).Value
                If btndeactivate.Text = "&Deactivate" Then
                    'check if theres item available status
                    sql = "Select * from tblgeneral where whsename='" & grdwhse.Rows(grdwhse.CurrentRow.Index).Cells(1).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox("Cannot deactivate. Warehouse name is still in use.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    whsecnf = False
                    confirm.ShowDialog()
                    If whsecnf = True Then
                        sql = "Update tblwhse set status='0', datemodified=GetDate(), modifiedby='" & login.cashier & "' where whseid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    whsecnf = False
                Else
                    whsecnf = False
                    confirm.ShowDialog()
                    If whsecnf = True Then
                        sql = "Update tblwhse set status='1', datemodified=GetDate(), modifiedby='" & login.cashier & "' where whseid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    whsecnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdwhse_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdwhse.SelectionChanged
        If grdwhse.Rows(grdwhse.CurrentRow.Index).Cells(4).Value = "Active" Then
            btndeactivate.Text = "&Deactivate"
        Else
            btndeactivate.Text = "A&ctivate"
        End If
    End Sub

    Public Sub loadcompsch()
        Try
            cmbcompany.Items.Clear()

            sql = "Select * from tblcompany where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbcompany.Items.Add(dr("company"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbcompany.Items.Count <> 0 Then
                cmbcompany.SelectedIndex = 0
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class