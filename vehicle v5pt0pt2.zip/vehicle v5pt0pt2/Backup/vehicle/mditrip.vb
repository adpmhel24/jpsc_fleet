﻿Imports System.Data.OleDb
Imports System.IO
Imports System.Data.SqlClient
Imports System.Security
Imports System.Security.Cryptography
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Imports System.Text

Public Class mditrip
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand
    Public steps As String
    Dim hasrows7 As Boolean = False
    Dim hasrows8 As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub mdiform_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub MenuStrip2_ItemAdded(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemEventArgs) Handles MenuStrip2.ItemAdded
        Dim s As String = e.Item.GetType().ToString()
        If (s = "System.Windows.Forms.MdiControlStrip+SystemMenuItem") Then
            e.Item.Visible = False
        End If
    End Sub

    Private Sub mdiform_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim a As String = MsgBox("Are you sure you want to logout?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            savelogout()
            moduless.Text = "Modules"
            login.Show()
            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub logouttool_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles logouttool.Click
        Dim a As String = MsgBox("Are you sure you want to logout?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            savelogout()
            moduless.Text = "Modules"
            login.Show()
            Me.Dispose()
        End If
    End Sub

    Public Sub savelogout()
        Try
            Dim logid As Integer = 0

            Sql = "Select TOP 1 * from tbllogin where datelogin='" & Format(Date.Now, "yyyy/MM/dd") & "' and username='" & login.cashier & "' and logout='' order by systemid DESC"
            connect()
            cmd = New SqlCommand(Sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                logid = dr("systemid")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Sql = "Update tbllogin set datelogout=GetDate(), logout='" & Format(Date.Now, "HH:mm") & "' where systemid='" & logid & "'"
            connect()
            cmd = New SqlCommand(Sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub TripDispatchingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TripDispatchingToolStripMenuItem.Click
        Dim myForm As New tripdispatch
        tripdispatch.Text = tripdispatch.Text
        tripdispatch.MdiParent = Me
        tripdispatch.WindowState = FormWindowState.Maximized
        tripdispatch.Show()
    End Sub

    Private Sub CreateOrderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateOrderToolStripMenuItem.Click
        Dim myForm As New mainmenucreate
        '/mainmenucreate.Text = mainmenucreate.Text 
        mainmenucreate.MdiParent = Me
        mainmenucreate.WindowState = FormWindowState.Maximized
        mainmenucreate.Show()
    End Sub

    Private Sub CategoryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CategoryToolStripMenuItem.Click
        Dim myForm As New category
        '/category.Text = category.Text 
        category.MdiParent = Me
        category.WindowState = FormWindowState.Maximized
        category.Show()
    End Sub

    Private Sub ItemsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ItemsToolStripMenuItem.Click
        Dim myForm As New newitems
        '/newitems.Text = newitems.Text 
        newitems.MdiParent = Me
        newitems.WindowState = FormWindowState.Maximized
        newitems.Show()
    End Sub

    Private Sub CustomerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomerToolStripMenuItem.Click
        Dim myForm As New customer
        '/customer.Text = customer.Text 
        customer.MdiParent = Me
        customer.WindowState = FormWindowState.Maximized
        customer.Show()
    End Sub

    Private Sub DriverToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DriverToolStripMenuItem.Click
        Dim myForm As New newdriver
        '/newdriver.Text = newdriver.Text 
        newdriver.MdiParent = Me
        newdriver.WindowState = FormWindowState.Maximized
        newdriver.Show()
    End Sub

    Private Sub HelperToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelperToolStripMenuItem.Click
        Dim myForm As New newhelper
        '/newhelper.Text = newhelper.Text 
        newhelper.MdiParent = Me
        newhelper.WindowState = FormWindowState.Maximized
        newhelper.Show()
    End Sub

    Private Sub CompanyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CompanyToolStripMenuItem.Click
        Dim myForm As New comps
        '/comps.Text = comps.Text 
        comps.MdiParent = Me
        comps.WindowState = FormWindowState.Maximized
        comps.Show()
    End Sub

    Private Sub WarehouseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WarehouseToolStripMenuItem.Click
        Dim myForm As New whse
        '/whse.Text = whse.Text 
        whse.MdiParent = Me
        whse.WindowState = FormWindowState.Maximized
        whse.Show()
    End Sub

    Private Sub DocumentsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DocumentsToolStripMenuItem.Click
        Dim myForm As New doc
        '/doc.Text = doc.Text 
        doc.MdiParent = Me
        doc.WindowState = FormWindowState.Maximized
        doc.Show()
    End Sub

    Private Sub TripDispatchSummaryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TripDispatchSummaryToolStripMenuItem.Click
        Dim myForm As New tripdispatchsum
        '/tripdispatchsum.Text = tripdispatchsum.Text 
        tripdispatchsum.MdiParent = Me
        tripdispatchsum.WindowState = FormWindowState.Maximized
        tripdispatchsum.Show()
    End Sub

    Private Sub TripSchedulingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TripSchedulingToolStripMenuItem.Click
        Dim myForm As New tripadd
        '/tripadd.Text = tripadd.Text 
        tripadd.MdiParent = Me
        tripadd.WindowState = FormWindowState.Maximized
        tripadd.Show()
    End Sub

    Private Sub TripSummaryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TripSummaryToolStripMenuItem.Click
        Dim myForm As New tripsum
        '/tripsum.Text = tripsum.Text 
        tripsum.MdiParent = Me
        tripsum.WindowState = FormWindowState.Maximized
        tripsum.Show()
    End Sub

    Private Sub OrderTransactionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrderTransactionsToolStripMenuItem.Click
        Dim myForm As New trans
        '/trans.Text = trans.Text 
        trans.MdiParent = Me
        trans.WindowState = FormWindowState.Maximized
        trans.Show()
    End Sub

    Private Sub LoginLogsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginLogsToolStripMenuItem.Click
        Dim myForm As New loginlogs
        '/loginlogs.Text = loginlogs.Text 
        loginlogs.MdiParent = Me
        loginlogs.WindowState = FormWindowState.Maximized
        loginlogs.Show()
    End Sub

    Private Sub UsersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UsersToolStripMenuItem.Click
        Dim myForm As New users
        '/users.Text = users.Text 
        users.MdiParent = Me
        users.WindowState = FormWindowState.Maximized
        users.Show()
    End Sub

    Private Sub VersionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VersionToolStripMenuItem.Click
        Dim myForm As New version
        '/version.Text = version.Text 
        version.MdiParent = Me
        version.WindowState = FormWindowState.Maximized
        version.Show()
    End Sub

    Private Sub TripScheduleReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TripScheduleReportToolStripMenuItem.Click
        Dim myForm As New tripreport
        '/tripreport.Text = tripreport.Text 
        tripreport.MdiParent = Me
        tripreport.WindowState = FormWindowState.Maximized
        tripreport.Show()
    End Sub

    Private Sub ForChangeOilToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ForChangeOilToolStripMenuItem.Click
        Dim myForm As New forchangeoil
        '/forchangeoil.Text = forchangeoil.Text 
        forchangeoil.MdiParent = Me
        forchangeoil.WindowState = FormWindowState.Maximized
        forchangeoil.Show()
    End Sub

    Private Sub AdjustQtyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AdjustQtyToolStripMenuItem.Click
        Dim myForm As New transqty
        '/transqty.Text = transqty.Text 
        transqty.MdiParent = Me
        transqty.WindowState = FormWindowState.Maximized
        transqty.Show()
    End Sub

    Private Sub InsertIntoDashboardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InsertIntoDashboardToolStripMenuItem.Click
        Dim myForm As New dashboard
        '/dashboard.Text = dashboard.Text 
        dashboard.MdiParent = Me
        dashboard.WindowState = FormWindowState.Maximized
        dashboard.Show()
    End Sub

    Private Sub RestoreCommentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RestoreCommentToolStripMenuItem.Click
        Dim myForm As New rptcomment
        '/rptcomment.Text = rptcomment.Text 
        rptcomment.MdiParent = Me
        rptcomment.WindowState = FormWindowState.Maximized
        rptcomment.Show()
    End Sub

    Private Sub DeletePreviousAttachmentsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeletePreviousAttachmentsToolStripMenuItem.Click
        Dim myForm As New sqlqueries
        '/sqlqueries.Text = sqlqueries.Text 
        sqlqueries.MdiParent = Me
        sqlqueries.WindowState = FormWindowState.Maximized
        sqlqueries.Show()
    End Sub

    Private Sub VehicleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleToolStripMenuItem.Click
        Dim myForm As New vmain
        '/vmain.Text = vmain.Text 
        vmain.MdiParent = Me
        vmain.WindowState = FormWindowState.Maximized
        vmain.Show()
    End Sub

    Private Sub mditrip_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        checkhasrows7()
        If hasrows7 = True Then
            pendingstep7.ShowDialog()
        End If

        checkhasrows8()
        If hasrows8 = True Then
            pendingstep8.ShowDialog()
        End If

        If login.whse <> "JP-Store" Then
            forchangeoil.view()
            If forchangeoil.grdpms.Rows.Count <> 0 Then
                forchangeoil.ShowDialog()
            End If
        End If
    End Sub

    Public Sub checkhasrows7()
        Try
            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step7<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) Then
                        hasrows7 = True
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub checkhasrows8()
        Try
            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step8<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) Then
                        hasrows8 = True
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class