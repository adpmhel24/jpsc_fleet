﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class tripaddexisting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(tripaddexisting))
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lbltaxi = New System.Windows.Forms.Label
        Me.lblmake = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.lblplnum = New System.Windows.Forms.Label
        Me.lblvtype = New System.Windows.Forms.Label
        Me.lblrems = New System.Windows.Forms.Label
        Me.txthelper = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.lblstat = New System.Windows.Forms.Label
        Me.lbltemp = New System.Windows.Forms.Label
        Me.lbltrip = New System.Windows.Forms.Label
        Me.txttripnum = New System.Windows.Forms.TextBox
        Me.txtetd = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.lbltripnum = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtrems = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtorigin = New System.Windows.Forms.TextBox
        Me.txtdatepick = New System.Windows.Forms.TextBox
        Me.txtdriver = New System.Windows.Forms.TextBox
        Me.txtplate = New System.Windows.Forms.TextBox
        Me.grd = New System.Windows.Forms.DataGridView
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column1 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.btnadd = New System.Windows.Forms.Button
        Me.btncancel = New System.Windows.Forms.Button
        Me.GroupBox2.SuspendLayout()
        CType(Me.grd, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.lbltaxi)
        Me.GroupBox2.Controls.Add(Me.lblmake)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.lblplnum)
        Me.GroupBox2.Controls.Add(Me.lblvtype)
        Me.GroupBox2.Controls.Add(Me.lblrems)
        Me.GroupBox2.Controls.Add(Me.txthelper)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.lblstat)
        Me.GroupBox2.Controls.Add(Me.lbltemp)
        Me.GroupBox2.Controls.Add(Me.lbltrip)
        Me.GroupBox2.Controls.Add(Me.txttripnum)
        Me.GroupBox2.Controls.Add(Me.txtetd)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.lbltripnum)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txtrems)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.txtorigin)
        Me.GroupBox2.Controls.Add(Me.txtdatepick)
        Me.GroupBox2.Controls.Add(Me.txtdriver)
        Me.GroupBox2.Controls.Add(Me.txtplate)
        Me.GroupBox2.Controls.Add(Me.grd)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(718, 481)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Trip"
        '
        'lbltaxi
        '
        Me.lbltaxi.AutoSize = True
        Me.lbltaxi.Location = New System.Drawing.Point(83, 129)
        Me.lbltaxi.Name = "lbltaxi"
        Me.lbltaxi.Size = New System.Drawing.Size(0, 13)
        Me.lbltaxi.TabIndex = 31
        '
        'lblmake
        '
        Me.lblmake.AutoSize = True
        Me.lblmake.Location = New System.Drawing.Point(563, 79)
        Me.lblmake.Name = "lblmake"
        Me.lblmake.Size = New System.Drawing.Size(0, 13)
        Me.lblmake.TabIndex = 30
        Me.lblmake.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(264, 129)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(85, 13)
        Me.Label9.TabIndex = 29
        Me.Label9.Text = "Dispatch Status:"
        '
        'lblplnum
        '
        Me.lblplnum.AutoSize = True
        Me.lblplnum.Location = New System.Drawing.Point(626, 23)
        Me.lblplnum.Name = "lblplnum"
        Me.lblplnum.Size = New System.Drawing.Size(135, 13)
        Me.lblplnum.TabIndex = 28
        Me.lblplnum.Text = "Plate No: galing ng trip add"
        Me.lblplnum.Visible = False
        '
        'lblvtype
        '
        Me.lblvtype.AutoSize = True
        Me.lblvtype.Location = New System.Drawing.Point(626, 75)
        Me.lblvtype.Name = "lblvtype"
        Me.lblvtype.Size = New System.Drawing.Size(0, 13)
        Me.lblvtype.TabIndex = 27
        Me.lblvtype.Visible = False
        '
        'lblrems
        '
        Me.lblrems.AutoSize = True
        Me.lblrems.Location = New System.Drawing.Point(563, 0)
        Me.lblrems.Name = "lblrems"
        Me.lblrems.Size = New System.Drawing.Size(0, 13)
        Me.lblrems.TabIndex = 26
        Me.lblrems.Visible = False
        '
        'txthelper
        '
        Me.txthelper.BackColor = System.Drawing.Color.White
        Me.txthelper.Location = New System.Drawing.Point(86, 101)
        Me.txthelper.Name = "txthelper"
        Me.txthelper.ReadOnly = True
        Me.txthelper.Size = New System.Drawing.Size(159, 20)
        Me.txthelper.TabIndex = 25
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(39, 104)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 13)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "Helper:"
        '
        'lblstat
        '
        Me.lblstat.AutoSize = True
        Me.lblstat.Location = New System.Drawing.Point(352, 129)
        Me.lblstat.Name = "lblstat"
        Me.lblstat.Size = New System.Drawing.Size(0, 13)
        Me.lblstat.TabIndex = 23
        '
        'lbltemp
        '
        Me.lbltemp.AutoSize = True
        Me.lbltemp.Location = New System.Drawing.Point(563, 50)
        Me.lbltemp.Name = "lbltemp"
        Me.lbltemp.Size = New System.Drawing.Size(30, 13)
        Me.lbltemp.TabIndex = 22
        Me.lbltemp.Text = "temp"
        Me.lbltemp.Visible = False
        '
        'lbltrip
        '
        Me.lbltrip.AutoSize = True
        Me.lbltrip.Location = New System.Drawing.Point(83, 19)
        Me.lbltrip.Name = "lbltrip"
        Me.lbltrip.Size = New System.Drawing.Size(38, 13)
        Me.lbltrip.TabIndex = 21
        Me.lbltrip.Text = "T.MIL-"
        '
        'txttripnum
        '
        Me.txttripnum.BackColor = System.Drawing.Color.White
        Me.txttripnum.Location = New System.Drawing.Point(127, 16)
        Me.txttripnum.Name = "txttripnum"
        Me.txttripnum.Size = New System.Drawing.Size(118, 20)
        Me.txttripnum.TabIndex = 20
        '
        'txtetd
        '
        Me.txtetd.BackColor = System.Drawing.Color.White
        Me.txtetd.Location = New System.Drawing.Point(355, 16)
        Me.txtetd.Name = "txtetd"
        Me.txtetd.ReadOnly = True
        Me.txtetd.Size = New System.Drawing.Size(159, 20)
        Me.txtetd.TabIndex = 19
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(317, 19)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "ETD:"
        '
        'lbltripnum
        '
        Me.lbltripnum.AutoSize = True
        Me.lbltripnum.Location = New System.Drawing.Point(563, 23)
        Me.lbltripnum.Name = "lbltripnum"
        Me.lbltripnum.Size = New System.Drawing.Size(31, 13)
        Me.lbltripnum.TabIndex = 17
        Me.lbltripnum.Text = "0000"
        Me.lbltripnum.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(35, 19)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 13)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Trip No:"
        '
        'txtrems
        '
        Me.txtrems.BackColor = System.Drawing.Color.White
        Me.txtrems.Location = New System.Drawing.Point(355, 101)
        Me.txtrems.Name = "txtrems"
        Me.txtrems.ReadOnly = True
        Me.txtrems.Size = New System.Drawing.Size(357, 20)
        Me.txtrems.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(297, 104)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Remarks:"
        '
        'txtorigin
        '
        Me.txtorigin.BackColor = System.Drawing.Color.White
        Me.txtorigin.Location = New System.Drawing.Point(355, 72)
        Me.txtorigin.Name = "txtorigin"
        Me.txtorigin.ReadOnly = True
        Me.txtorigin.Size = New System.Drawing.Size(159, 20)
        Me.txtorigin.TabIndex = 13
        '
        'txtdatepick
        '
        Me.txtdatepick.BackColor = System.Drawing.Color.White
        Me.txtdatepick.Location = New System.Drawing.Point(355, 43)
        Me.txtdatepick.Name = "txtdatepick"
        Me.txtdatepick.ReadOnly = True
        Me.txtdatepick.Size = New System.Drawing.Size(159, 20)
        Me.txtdatepick.TabIndex = 12
        '
        'txtdriver
        '
        Me.txtdriver.BackColor = System.Drawing.Color.White
        Me.txtdriver.Location = New System.Drawing.Point(86, 72)
        Me.txtdriver.Name = "txtdriver"
        Me.txtdriver.ReadOnly = True
        Me.txtdriver.Size = New System.Drawing.Size(159, 20)
        Me.txtdriver.TabIndex = 11
        '
        'txtplate
        '
        Me.txtplate.BackColor = System.Drawing.Color.White
        Me.txtplate.Location = New System.Drawing.Point(86, 43)
        Me.txtplate.Name = "txtplate"
        Me.txtplate.ReadOnly = True
        Me.txtplate.Size = New System.Drawing.Size(159, 20)
        Me.txtplate.TabIndex = 10
        '
        'grd
        '
        Me.grd.AllowUserToAddRows = False
        Me.grd.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grd.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grd.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grd.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grd.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grd.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.grd.ColumnHeadersHeight = 30
        Me.grd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grd.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column4, Me.Column1, Me.Column2, Me.Column3, Me.Column5, Me.Column6, Me.Column7})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.DefaultCellStyle = DataGridViewCellStyle3
        Me.grd.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grd.EnableHeadersVisualStyles = False
        Me.grd.GridColor = System.Drawing.Color.Salmon
        Me.grd.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grd.Location = New System.Drawing.Point(6, 153)
        Me.grd.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grd.Name = "grd"
        Me.grd.ReadOnly = True
        Me.grd.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.grd.RowHeadersWidth = 10
        Me.grd.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.NullValue = Nothing
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.RowsDefaultCellStyle = DataGridViewCellStyle5
        Me.grd.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grd.Size = New System.Drawing.Size(706, 323)
        Me.grd.TabIndex = 9
        '
        'Column4
        '
        Me.Column4.HeaderText = "ID"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Visible = False
        '
        'Column1
        '
        Me.Column1.ActiveLinkColor = System.Drawing.Color.Black
        Me.Column1.HeaderText = "Transaction #"
        Me.Column1.LinkColor = System.Drawing.Color.Red
        Me.Column1.MinimumWidth = 150
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column1.Width = 150
        '
        'Column2
        '
        Me.Column2.HeaderText = "Reference #"
        Me.Column2.MinimumWidth = 150
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 150
        '
        'Column3
        '
        Me.Column3.HeaderText = "Recipient"
        Me.Column3.MinimumWidth = 180
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 180
        '
        'Column5
        '
        Me.Column5.HeaderText = "Transaction Type"
        Me.Column5.MinimumWidth = 180
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Width = 180
        '
        'Column6
        '
        Me.Column6.HeaderText = "status"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        Me.Column6.Visible = False
        '
        'Column7
        '
        Me.Column7.HeaderText = "Trucking ORO"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(295, 46)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Trip Date:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(312, 75)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Origin:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(42, 75)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 13)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Driver:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(29, 46)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Plate No:"
        '
        'btnadd
        '
        Me.btnadd.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnadd.Image = CType(resources.GetObject("btnadd.Image"), System.Drawing.Image)
        Me.btnadd.Location = New System.Drawing.Point(556, 504)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(82, 23)
        Me.btnadd.TabIndex = 3
        Me.btnadd.Text = "Confirm"
        Me.btnadd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnadd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'btncancel
        '
        Me.btncancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncancel.Image = CType(resources.GetObject("btncancel.Image"), System.Drawing.Image)
        Me.btncancel.Location = New System.Drawing.Point(644, 504)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(86, 23)
        Me.btncancel.TabIndex = 4
        Me.btncancel.Text = "Cancel"
        Me.btncancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'tripaddexisting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(742, 542)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.GroupBox2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "tripaddexisting"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Trip Confirmation"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.grd, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents grd As System.Windows.Forms.DataGridView
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents txtorigin As System.Windows.Forms.TextBox
    Friend WithEvents txtdatepick As System.Windows.Forms.TextBox
    Friend WithEvents txtdriver As System.Windows.Forms.TextBox
    Friend WithEvents txtplate As System.Windows.Forms.TextBox
    Friend WithEvents txtrems As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbltripnum As System.Windows.Forms.Label
    Friend WithEvents txtetd As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txttripnum As System.Windows.Forms.TextBox
    Friend WithEvents lbltrip As System.Windows.Forms.Label
    Friend WithEvents lbltemp As System.Windows.Forms.Label
    Friend WithEvents lblstat As System.Windows.Forms.Label
    Friend WithEvents txthelper As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblrems As System.Windows.Forms.Label
    Friend WithEvents lblvtype As System.Windows.Forms.Label
    Friend WithEvents lblplnum As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblmake As System.Windows.Forms.Label
    Friend WithEvents lbltaxi As System.Windows.Forms.Label
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
