﻿Public Class vmain
    Dim frm As Form

    Private Sub frmsetup()
        frm.TopLevel = False
        frm.TopMost = True
        frm.Parent = Panel1
        frm.Focus()
        frm.BringToFront()
        frm.Show()
    End Sub

    Private Sub VehicleTypeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleTypeToolStripMenuItem.Click
        vtypes.TopLevel = False
        vtypes.TopMost = True
        vtypes.Parent = Panel1
        vtypes.Focus()
        vtypes.BringToFront()
        vtypes.Show()
    End Sub

    Private Sub BodyTypeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BodyTypeToolStripMenuItem.Click
        bodytyp.TopLevel = False
        bodytyp.TopMost = True
        bodytyp.Parent = Panel1
        bodytyp.Focus()
        bodytyp.BringToFront()
        bodytyp.Show()
    End Sub

    Private Sub MakeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MakeToolStripMenuItem.Click
        makes.TopLevel = False
        makes.TopMost = True
        makes.Parent = Panel1
        makes.Focus()
        makes.BringToFront()
        makes.Show()
    End Sub

    Private Sub SupplierToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SupplierToolStripMenuItem.Click
        supplier.TopLevel = False
        supplier.TopMost = True
        supplier.Parent = Panel1
        supplier.Focus()
        supplier.BringToFront()
        supplier.Show()
    End Sub

    Private Sub PMServiceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PMServiceToolStripMenuItem.Click
        pms.TopLevel = False
        pms.TopMost = True
        pms.Parent = Panel1
        pms.Focus()
        pms.BringToFront()
        pms.Show()
    End Sub

    Private Sub RepairServicesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RepairServicesToolStripMenuItem.Click
        repair.TopLevel = False
        repair.TopMost = True
        repair.Parent = Panel1
        repair.Focus()
        repair.BringToFront()
        repair.Show()
    End Sub

    Private Sub ListOfPartsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfPartsToolStripMenuItem.Click
        parts.TopLevel = False
        parts.TopMost = True
        parts.Parent = Panel1
        parts.Focus()
        parts.BringToFront()
        parts.Show()
    End Sub

    Private Sub UpdateMoreVehicleDocumentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateMoreVehicleDocumentToolStripMenuItem.Click
        updatevdocs.TopLevel = False
        updatevdocs.TopMost = True
        updatevdocs.Parent = Panel1
        updatevdocs.Focus()
        updatevdocs.BringToFront()
        updatevdocs.Show()
    End Sub

    Private Sub ImportExcelToAddMoreVehiclesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportExcelToAddMoreVehiclesToolStripMenuItem.Click
        importvadd.TopLevel = False
        importvadd.TopMost = True
        importvadd.Parent = Panel1
        importvadd.Focus()
        importvadd.BringToFront()
        importvadd.Show()
    End Sub

    Private Sub ImportExcelToUpdateVehicleParametersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportExcelToUpdateVehicleParametersToolStripMenuItem.Click
        importparameters.TopLevel = False
        importparameters.TopMost = True
        importparameters.Parent = Panel1
        importparameters.Focus()
        importparameters.BringToFront()
        importparameters.Show()
    End Sub

    Private Sub VehicleGeneralInformationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleGeneralInformationToolStripMenuItem.Click
        rptgeneral.TopLevel = False
        rptgeneral.TopMost = True
        rptgeneral.Parent = Panel1
        rptgeneral.Focus()
        rptgeneral.BringToFront()
        rptgeneral.Show()
    End Sub

    Private Sub VehicleStatusToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleStatusToolStripMenuItem.Click
        rptvstatus.TopLevel = False
        rptvstatus.TopMost = True
        rptvstatus.Parent = Panel1
        rptvstatus.Focus()
        rptvstatus.BringToFront()
        rptvstatus.Show()
    End Sub

    Private Sub VehicleChangeOilToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleChangeOilToolStripMenuItem.Click
        rptchangeoil.TopLevel = False
        rptchangeoil.TopMost = True
        rptchangeoil.Parent = Panel1
        rptchangeoil.Focus()
        rptchangeoil.BringToFront()
        rptchangeoil.Show()
    End Sub

    Private Sub VehicleListToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleListToolStripMenuItem.Click
        '/frm = New vmanage
        vmanage.TopLevel = False
        vmanage.TopMost = True
        vmanage.Parent = Panel1
        vmanage.Focus()
        vmanage.BringToFront()
        vmanage.Show()
    End Sub

    Private Sub vmain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        vmanage.TopLevel = False
        vmanage.TopMost = True
        vmanage.Parent = Panel1
        vmanage.Focus()
        vmanage.BringToFront()
        vmanage.Show()
    End Sub

    Private Sub VehicleLastOdometerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleLastOdometerToolStripMenuItem.Click
        vodometer.TopLevel = False
        vodometer.TopMost = True
        vodometer.Parent = Panel1
        vodometer.Focus()
        vodometer.BringToFront()
        vodometer.Show()
    End Sub

    Private Sub PercentageOfCreateOrdersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PercentageOfCreateOrdersToolStripMenuItem.Click
        dashcreateorder.TopLevel = False
        dashcreateorder.TopMost = True
        dashcreateorder.Parent = Panel1
        dashcreateorder.Focus()
        dashcreateorder.BringToFront()
        dashcreateorder.Show()
    End Sub

    Private Sub PercentageOfToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PercentageOfToolStripMenuItem.Click
        dashpervtype.TopLevel = False
        dashpervtype.TopMost = True
        dashpervtype.Parent = Panel1
        dashpervtype.Focus()
        dashpervtype.BringToFront()
        dashpervtype.Show()
    End Sub

    Private Sub UpdateVehicleAssignedWhseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateVehicleAssignedWhseToolStripMenuItem.Click
        importupassign.TopLevel = False
        importupassign.TopMost = True
        importupassign.Parent = Panel1
        importupassign.Focus()
        importupassign.BringToFront()
        importupassign.Show()
    End Sub

    Private Sub ListOfCompanyToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfCompanyToolStripMenuItem1.Click
        rptcompany.TopLevel = False
        rptcompany.TopMost = True
        rptcompany.Parent = Panel1
        rptcompany.Focus()
        rptcompany.BringToFront()
        rptcompany.Show()
    End Sub

    Private Sub ListOfMakeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfMakeToolStripMenuItem.Click
        rptmake.TopLevel = False
        rptmake.TopMost = True
        rptmake.Parent = Panel1
        rptmake.Focus()
        rptmake.BringToFront()
        rptmake.Show()
    End Sub

    Private Sub ListOfSupplierToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfSupplierToolStripMenuItem.Click
        rptsupplier.TopLevel = False
        rptsupplier.TopMost = True
        rptsupplier.Parent = Panel1
        rptsupplier.Focus()
        rptsupplier.BringToFront()
        rptsupplier.Show()
    End Sub

    Private Sub ListOfDocumentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfDocumentToolStripMenuItem.Click
        rptdocu.TopLevel = False
        rptdocu.TopMost = True
        rptdocu.Parent = Panel1
        rptdocu.Focus()
        rptdocu.BringToFront()
        rptdocu.Show()
    End Sub

    Private Sub ListOfPMServicesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfPMServicesToolStripMenuItem.Click
        rptpms.TopLevel = False
        rptpms.TopMost = True
        rptpms.Parent = Panel1
        rptpms.Focus()
        rptpms.BringToFront()
        rptpms.Show()
    End Sub

    Private Sub VehicleNotificationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleNotificationToolStripMenuItem.Click
        rptnotifs.TopLevel = False
        rptnotifs.TopMost = True
        rptnotifs.Parent = Panel1
        rptnotifs.Focus()
        rptnotifs.BringToFront()
        rptnotifs.Show()
    End Sub

    Private Sub ListOfWarehouseToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfWarehouseToolStripMenuItem1.Click
        rptwhse.TopLevel = False
        rptwhse.TopMost = True
        rptwhse.Parent = Panel1
        rptwhse.Focus()
        rptwhse.BringToFront()
        rptwhse.Show()
    End Sub

    Private Sub ListOfBodyTypeToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfBodyTypeToolStripMenuItem1.Click
        rptbody.TopLevel = False
        rptbody.TopMost = True
        rptbody.Parent = Panel1
        rptbody.Focus()
        rptbody.BringToFront()
        rptbody.Show()
    End Sub

    Private Sub ListOfVehicleTypeToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfVehicleTypeToolStripMenuItem1.Click
        rptvtype.TopLevel = False
        rptvtype.TopMost = True
        rptvtype.Parent = Panel1
        rptvtype.Focus()
        rptvtype.BringToFront()
        rptvtype.Show()
    End Sub

    Private Sub VehicleTripsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleTripsToolStripMenuItem.Click
        vtrips.TopLevel = False
        vtrips.TopMost = True
        vtrips.Parent = Panel1
        vtrips.Focus()
        vtrips.BringToFront()
        vtrips.Show()
    End Sub
End Class