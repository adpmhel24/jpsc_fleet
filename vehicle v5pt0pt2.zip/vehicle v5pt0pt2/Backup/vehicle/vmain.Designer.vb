﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vmain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vmain))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.SetupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VehicleListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VehicleTypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BodyTypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MakeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SupplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PMServiceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RepairServicesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ListOfPartsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.UpdateMoreVehicleDocumentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ImportExcelToAddMoreVehiclesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ImportExcelToUpdateVehicleParametersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.UpdateVehicleAssignedWhseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ListOfCompanyToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ListOfVehicleTypeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ListOfBodyTypeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ListOfWarehouseToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ListOfMakeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ListOfSupplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ListOfDocumentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ListOfPMServicesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VehicleGeneralInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VehicleNotificationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VehicleStatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VehicleChangeOilToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VehicleTripsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VehicleLastOdometerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TripDashboardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PercentageOfToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PercentageOfCreateOrdersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SetupToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.ReportsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1008, 24)
        Me.MenuStrip1.TabIndex = 21
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'SetupToolStripMenuItem
        '
        Me.SetupToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VehicleListToolStripMenuItem, Me.VehicleTypeToolStripMenuItem, Me.BodyTypeToolStripMenuItem, Me.MakeToolStripMenuItem, Me.SupplierToolStripMenuItem, Me.PMServiceToolStripMenuItem, Me.RepairServicesToolStripMenuItem, Me.ListOfPartsToolStripMenuItem})
        Me.SetupToolStripMenuItem.Name = "SetupToolStripMenuItem"
        Me.SetupToolStripMenuItem.Size = New System.Drawing.Size(89, 20)
        Me.SetupToolStripMenuItem.Text = "Vehicle Setup"
        '
        'VehicleListToolStripMenuItem
        '
        Me.VehicleListToolStripMenuItem.Image = CType(resources.GetObject("VehicleListToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleListToolStripMenuItem.Name = "VehicleListToolStripMenuItem"
        Me.VehicleListToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.VehicleListToolStripMenuItem.Text = "Vehicle List"
        '
        'VehicleTypeToolStripMenuItem
        '
        Me.VehicleTypeToolStripMenuItem.Image = CType(resources.GetObject("VehicleTypeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleTypeToolStripMenuItem.Name = "VehicleTypeToolStripMenuItem"
        Me.VehicleTypeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.VehicleTypeToolStripMenuItem.Text = "Vehicle Type"
        '
        'BodyTypeToolStripMenuItem
        '
        Me.BodyTypeToolStripMenuItem.Image = CType(resources.GetObject("BodyTypeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BodyTypeToolStripMenuItem.Name = "BodyTypeToolStripMenuItem"
        Me.BodyTypeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.BodyTypeToolStripMenuItem.Text = "Body Type"
        '
        'MakeToolStripMenuItem
        '
        Me.MakeToolStripMenuItem.Image = CType(resources.GetObject("MakeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MakeToolStripMenuItem.Name = "MakeToolStripMenuItem"
        Me.MakeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.MakeToolStripMenuItem.Text = "Make"
        '
        'SupplierToolStripMenuItem
        '
        Me.SupplierToolStripMenuItem.Image = CType(resources.GetObject("SupplierToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SupplierToolStripMenuItem.Name = "SupplierToolStripMenuItem"
        Me.SupplierToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SupplierToolStripMenuItem.Text = "Supplier"
        '
        'PMServiceToolStripMenuItem
        '
        Me.PMServiceToolStripMenuItem.Image = CType(resources.GetObject("PMServiceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PMServiceToolStripMenuItem.Name = "PMServiceToolStripMenuItem"
        Me.PMServiceToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.PMServiceToolStripMenuItem.Text = "PM Service"
        '
        'RepairServicesToolStripMenuItem
        '
        Me.RepairServicesToolStripMenuItem.Image = CType(resources.GetObject("RepairServicesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RepairServicesToolStripMenuItem.Name = "RepairServicesToolStripMenuItem"
        Me.RepairServicesToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.RepairServicesToolStripMenuItem.Text = "Repair Services"
        Me.RepairServicesToolStripMenuItem.Visible = False
        '
        'ListOfPartsToolStripMenuItem
        '
        Me.ListOfPartsToolStripMenuItem.Image = CType(resources.GetObject("ListOfPartsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ListOfPartsToolStripMenuItem.Name = "ListOfPartsToolStripMenuItem"
        Me.ListOfPartsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ListOfPartsToolStripMenuItem.Text = "Vehicle Parts"
        Me.ListOfPartsToolStripMenuItem.Visible = False
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UpdateMoreVehicleDocumentToolStripMenuItem, Me.ImportExcelToAddMoreVehiclesToolStripMenuItem, Me.ImportExcelToUpdateVehicleParametersToolStripMenuItem, Me.UpdateVehicleAssignedWhseToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(100, 20)
        Me.ToolsToolStripMenuItem.Text = "Vehicle Imports"
        '
        'UpdateMoreVehicleDocumentToolStripMenuItem
        '
        Me.UpdateMoreVehicleDocumentToolStripMenuItem.Image = CType(resources.GetObject("UpdateMoreVehicleDocumentToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UpdateMoreVehicleDocumentToolStripMenuItem.Name = "UpdateMoreVehicleDocumentToolStripMenuItem"
        Me.UpdateMoreVehicleDocumentToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
        Me.UpdateMoreVehicleDocumentToolStripMenuItem.Text = "Update More Vehicle Document"
        '
        'ImportExcelToAddMoreVehiclesToolStripMenuItem
        '
        Me.ImportExcelToAddMoreVehiclesToolStripMenuItem.Image = CType(resources.GetObject("ImportExcelToAddMoreVehiclesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ImportExcelToAddMoreVehiclesToolStripMenuItem.Name = "ImportExcelToAddMoreVehiclesToolStripMenuItem"
        Me.ImportExcelToAddMoreVehiclesToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
        Me.ImportExcelToAddMoreVehiclesToolStripMenuItem.Text = "Import Excel to Add More Vehicles"
        '
        'ImportExcelToUpdateVehicleParametersToolStripMenuItem
        '
        Me.ImportExcelToUpdateVehicleParametersToolStripMenuItem.Image = CType(resources.GetObject("ImportExcelToUpdateVehicleParametersToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ImportExcelToUpdateVehicleParametersToolStripMenuItem.Name = "ImportExcelToUpdateVehicleParametersToolStripMenuItem"
        Me.ImportExcelToUpdateVehicleParametersToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
        Me.ImportExcelToUpdateVehicleParametersToolStripMenuItem.Text = "Import Excel to Update Vehicle Parameters"
        '
        'UpdateVehicleAssignedWhseToolStripMenuItem
        '
        Me.UpdateVehicleAssignedWhseToolStripMenuItem.Image = CType(resources.GetObject("UpdateVehicleAssignedWhseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UpdateVehicleAssignedWhseToolStripMenuItem.Name = "UpdateVehicleAssignedWhseToolStripMenuItem"
        Me.UpdateVehicleAssignedWhseToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
        Me.UpdateVehicleAssignedWhseToolStripMenuItem.Text = "Update Vehicle Assigned Whse"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListToolStripMenuItem, Me.VehicleGeneralInformationToolStripMenuItem, Me.VehicleNotificationToolStripMenuItem, Me.VehicleStatusToolStripMenuItem, Me.VehicleChangeOilToolStripMenuItem, Me.VehicleTripsToolStripMenuItem, Me.VehicleLastOdometerToolStripMenuItem, Me.TripDashboardToolStripMenuItem})
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(99, 20)
        Me.ReportsToolStripMenuItem.Text = "Vehicle Reports"
        '
        'ListToolStripMenuItem
        '
        Me.ListToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListOfCompanyToolStripMenuItem1, Me.ListOfVehicleTypeToolStripMenuItem1, Me.ListOfBodyTypeToolStripMenuItem1, Me.ListOfWarehouseToolStripMenuItem1, Me.ListOfMakeToolStripMenuItem, Me.ListOfSupplierToolStripMenuItem, Me.ListOfDocumentToolStripMenuItem, Me.ListOfPMServicesToolStripMenuItem})
        Me.ListToolStripMenuItem.Image = CType(resources.GetObject("ListToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ListToolStripMenuItem.Name = "ListToolStripMenuItem"
        Me.ListToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.ListToolStripMenuItem.Text = "List"
        '
        'ListOfCompanyToolStripMenuItem1
        '
        Me.ListOfCompanyToolStripMenuItem1.Name = "ListOfCompanyToolStripMenuItem1"
        Me.ListOfCompanyToolStripMenuItem1.Size = New System.Drawing.Size(173, 22)
        Me.ListOfCompanyToolStripMenuItem1.Text = "List of Company"
        '
        'ListOfVehicleTypeToolStripMenuItem1
        '
        Me.ListOfVehicleTypeToolStripMenuItem1.Name = "ListOfVehicleTypeToolStripMenuItem1"
        Me.ListOfVehicleTypeToolStripMenuItem1.Size = New System.Drawing.Size(173, 22)
        Me.ListOfVehicleTypeToolStripMenuItem1.Text = "List of Vehicle Type"
        '
        'ListOfBodyTypeToolStripMenuItem1
        '
        Me.ListOfBodyTypeToolStripMenuItem1.Name = "ListOfBodyTypeToolStripMenuItem1"
        Me.ListOfBodyTypeToolStripMenuItem1.Size = New System.Drawing.Size(173, 22)
        Me.ListOfBodyTypeToolStripMenuItem1.Text = "List of Body Type"
        '
        'ListOfWarehouseToolStripMenuItem1
        '
        Me.ListOfWarehouseToolStripMenuItem1.Name = "ListOfWarehouseToolStripMenuItem1"
        Me.ListOfWarehouseToolStripMenuItem1.Size = New System.Drawing.Size(173, 22)
        Me.ListOfWarehouseToolStripMenuItem1.Text = "List of Warehouse"
        '
        'ListOfMakeToolStripMenuItem
        '
        Me.ListOfMakeToolStripMenuItem.Name = "ListOfMakeToolStripMenuItem"
        Me.ListOfMakeToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.ListOfMakeToolStripMenuItem.Text = "List of Make"
        '
        'ListOfSupplierToolStripMenuItem
        '
        Me.ListOfSupplierToolStripMenuItem.Name = "ListOfSupplierToolStripMenuItem"
        Me.ListOfSupplierToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.ListOfSupplierToolStripMenuItem.Text = "List of Supplier"
        '
        'ListOfDocumentToolStripMenuItem
        '
        Me.ListOfDocumentToolStripMenuItem.Name = "ListOfDocumentToolStripMenuItem"
        Me.ListOfDocumentToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.ListOfDocumentToolStripMenuItem.Text = "List of Document"
        '
        'ListOfPMServicesToolStripMenuItem
        '
        Me.ListOfPMServicesToolStripMenuItem.Name = "ListOfPMServicesToolStripMenuItem"
        Me.ListOfPMServicesToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.ListOfPMServicesToolStripMenuItem.Text = "List of PM Services"
        '
        'VehicleGeneralInformationToolStripMenuItem
        '
        Me.VehicleGeneralInformationToolStripMenuItem.Image = CType(resources.GetObject("VehicleGeneralInformationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleGeneralInformationToolStripMenuItem.Name = "VehicleGeneralInformationToolStripMenuItem"
        Me.VehicleGeneralInformationToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.VehicleGeneralInformationToolStripMenuItem.Text = "Vehicle Information"
        '
        'VehicleNotificationToolStripMenuItem
        '
        Me.VehicleNotificationToolStripMenuItem.Image = CType(resources.GetObject("VehicleNotificationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleNotificationToolStripMenuItem.Name = "VehicleNotificationToolStripMenuItem"
        Me.VehicleNotificationToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.VehicleNotificationToolStripMenuItem.Text = "Vehicle Notification"
        '
        'VehicleStatusToolStripMenuItem
        '
        Me.VehicleStatusToolStripMenuItem.Image = CType(resources.GetObject("VehicleStatusToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleStatusToolStripMenuItem.Name = "VehicleStatusToolStripMenuItem"
        Me.VehicleStatusToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.VehicleStatusToolStripMenuItem.Text = "Vehicle Status"
        '
        'VehicleChangeOilToolStripMenuItem
        '
        Me.VehicleChangeOilToolStripMenuItem.Image = CType(resources.GetObject("VehicleChangeOilToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleChangeOilToolStripMenuItem.Name = "VehicleChangeOilToolStripMenuItem"
        Me.VehicleChangeOilToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.VehicleChangeOilToolStripMenuItem.Text = "Vehicle Change Oil"
        Me.VehicleChangeOilToolStripMenuItem.Visible = False
        '
        'VehicleTripsToolStripMenuItem
        '
        Me.VehicleTripsToolStripMenuItem.Name = "VehicleTripsToolStripMenuItem"
        Me.VehicleTripsToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.VehicleTripsToolStripMenuItem.Text = "Vehicle Trips"
        '
        'VehicleLastOdometerToolStripMenuItem
        '
        Me.VehicleLastOdometerToolStripMenuItem.Name = "VehicleLastOdometerToolStripMenuItem"
        Me.VehicleLastOdometerToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.VehicleLastOdometerToolStripMenuItem.Text = "Vehicle Last Odometer"
        '
        'TripDashboardToolStripMenuItem
        '
        Me.TripDashboardToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PercentageOfToolStripMenuItem, Me.PercentageOfCreateOrdersToolStripMenuItem})
        Me.TripDashboardToolStripMenuItem.Name = "TripDashboardToolStripMenuItem"
        Me.TripDashboardToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.TripDashboardToolStripMenuItem.Text = "Trip Dashboard"
        '
        'PercentageOfToolStripMenuItem
        '
        Me.PercentageOfToolStripMenuItem.Name = "PercentageOfToolStripMenuItem"
        Me.PercentageOfToolStripMenuItem.Size = New System.Drawing.Size(261, 22)
        Me.PercentageOfToolStripMenuItem.Text = "Percentage of Trips per Vehicle Type"
        '
        'PercentageOfCreateOrdersToolStripMenuItem
        '
        Me.PercentageOfCreateOrdersToolStripMenuItem.Name = "PercentageOfCreateOrdersToolStripMenuItem"
        Me.PercentageOfCreateOrdersToolStripMenuItem.Size = New System.Drawing.Size(261, 22)
        Me.PercentageOfCreateOrdersToolStripMenuItem.Text = "Percentage of Create Orders"
        '
        'Panel1
        '
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 24)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1008, 537)
        Me.Panel1.TabIndex = 22
        '
        'vmain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDark
        Me.ClientSize = New System.Drawing.Size(1008, 561)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "vmain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Vehicle"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents SetupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleTypeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BodyTypeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MakeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PMServiceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RepairServicesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfPartsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateMoreVehicleDocumentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportExcelToAddMoreVehiclesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportExcelToUpdateVehicleParametersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfCompanyToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfVehicleTypeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfBodyTypeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfWarehouseToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfMakeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfSupplierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfDocumentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfPMServicesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleGeneralInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleNotificationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleStatusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleChangeOilToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents VehicleListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleLastOdometerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripDashboardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PercentageOfToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PercentageOfCreateOrdersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateVehicleAssignedWhseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleTripsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
