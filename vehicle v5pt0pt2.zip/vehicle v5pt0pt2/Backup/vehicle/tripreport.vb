﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Windows.Forms
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.ComponentModel

Public Class tripreport
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Public sqlcondition As String = ""

    Private threadEnabled As Boolean, gridsql As String
    Private backgroundWorker As New BackgroundWorker

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub tripreport_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated

    End Sub

    Private Sub tripreport_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        
    End Sub

    Private Sub tripreport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        grdrep.Columns(6).Frozen = True
        loadplate()
        loadvtype()
        loaddriver()
        loadhelper()
        loadorigin()
        loadcustomer()
        loadpickup()
        t_chk2.Checked = True
        t_chk1.Checked = True
    End Sub

    Public Sub loadplate()
        Try
            cmbplate.Items.Clear()

            sql = "Select * from tblgeneral order by platenum"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbplate.Items.Add(dr("platenum"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbplate.Items.Count <> 0 Then
                cmbplate.Items.Add("All")
                cmbplate.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadvtype()
        Try
            cmbtype.Items.Clear()

            sql = "Select * from tblvtype order by vtype"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbtype.Items.Add(dr("vtype"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbtype.Items.Count <> 0 Then
                cmbtype.Items.Add("All")
                cmbtype.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loaddriver()
        Try
            cmbdriver.Items.Clear()

            sql = "Select * from tbldriver order by driver"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbdriver.Items.Add(dr("driver"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbdriver.Items.Count <> 0 Then
                cmbdriver.Items.Add("All")
                cmbdriver.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadhelper()
        Try
            cmbhelper.Items.Clear()

            sql = "Select * from tblhelper order by helper"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbhelper.Items.Add(dr("helper"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbhelper.Items.Count <> 0 Then
                cmbhelper.Items.Add("All")
                cmbhelper.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadorigin()
        Try
            cmborigin.Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tblwhse where status='1' order by whsename"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmborigin.Items.Add(dr1("whsename"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            If cmborigin.Items.Count <> 0 Then
                cmborigin.Items.Add("All")
                cmborigin.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadcustomer()
        Try
            cmbrec.Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tblcustomer where status='1' order by customer"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbrec.Items.Add(dr1("customer"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            If cmbrec.Items.Count <> 0 Then
                cmbrec.Items.Add("All")
                cmbrec.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadpickup()
        Try
            cmbpick.Items.Clear()
            cmbpick.Items.Add("")

            sql = "Select * from tblwhse where status='1' and (company='Atlantic Grains' or company='Supplier Warehouse') order by whsename"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbpick.Items.Add(dr("whsename").ToString.ToUpper)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        Try
            If Trim(cmbtranstype.Text) <> "" And cmbtranstype.Text.Contains("PICKUP") And Trim(cmbpick.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Select pick up from.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            viewreport()

            Exit Sub

            Dim a As String = "", b As String = ""
            For Each row As DataGridViewRow In grdrep.Rows
                Dim stat As String = ""

                sql = "Select * from tbltripitems where tripnum='" & grdrep.Rows(row.Index).Cells(1).Value & "' and transnum='" & grdrep.Rows(row.Index).Cells(6).Value & "'"
                connect()
                Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
                Dim dr1 As SqlDataReader = cmd1.ExecuteReader
                If dr1.Read Then
                    If dr1("status") = 0 Then
                        stat = "Cancelled"
                    ElseIf dr1("status") = 2 Then
                        stat = "Completed"
                    ElseIf dr1("status") = 3 Then
                        stat = "Removed"
                    ElseIf dr1("status") = 4 Then
                        stat = "Rescheduled"
                    ElseIf dr1("status") = 5 Then
                        stat = "For AR Credit Memo"
                    ElseIf dr1("status") = 1 Then
                        stat = "In Process"
                    End If

                    grdrep.Rows(row.Index).Cells(27).Value = stat
                End If
                dr1.Dispose()
                cmd1.Dispose()
                conn.Close()

                'If row.Index = 0 Then
                '    grdrep.Rows(row.Index).DefaultCellStyle.BackColor = Color.Yellow
                'Else
                '    a = grdrep.Rows(row.Index - 1).Cells(1).Value
                '    b = grdrep.Rows(row.Index).Cells(1).Value
                '    If a = b Then
                '        grdrep.Rows(row.Index).DefaultCellStyle.BackColor = grdrep.Rows(row.Index - 1).DefaultCellStyle.BackColor
                '    Else
                '        grdrep.Rows(row.Index).DefaultCellStyle.BackColor = Color.LightGreen
                '        If grdrep.Rows(row.Index - 1).DefaultCellStyle.BackColor = Color.LightGreen Then
                '            grdrep.Rows(row.Index).DefaultCellStyle.BackColor = Color.Yellow
                '        End If
                '    End If
                'End If


                sql = "Select * from tbltripsum where tripnum='" & grdrep.Rows(row.Index).Cells(1).Value & "'"
                connect()
                cmd1 = New SqlCommand(sql, conn)
                dr1 = cmd1.ExecuteReader
                If dr1.Read Then
                    If dr1("status") = 0 Then
                        stat = "Cancelled"
                    ElseIf dr1("status") = 3 Then
                        stat = "Cancelled"
                    End If

                    grdrep.Rows(row.Index).Cells(27).Value = stat
                End If
                dr1.Dispose()
                cmd1.Dispose()
                conn.Close()
            Next

            If grdrep.Rows.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("No record found.", MsgBoxStyle.Critical, "")
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub viewreport()
        Try
            gridsql = "SELECT * from tbltripsumreport"
            gridsql = gridsql & " where datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "' and whsename='" & login.whse & "'"

            If Trim(cmbplate.Text) <> "" And Trim(cmbplate.Text) <> "All" Then
                gridsql = gridsql & " and platenum='" & Trim(cmbplate.Text) & "'"
            End If

            If Trim(cmbtype.Text) <> "" And Trim(cmbtype.Text) <> "All" Then
                gridsql = gridsql & " and vtype='" & Trim(cmbtype.Text) & "'"
            End If

            If Trim(cmbdriver.Text) <> "" And Trim(cmbdriver.Text) <> "All" Then
                gridsql = gridsql & " and driver='" & Trim(cmbdriver.Text) & "'"
            End If

            If Trim(cmbhelper.Text) <> "" And Trim(cmbhelper.Text) <> "All" Then
                gridsql = gridsql & " and helper='" & Trim(cmbhelper.Text) & "'"
            End If

            If Trim(cmborigin.Text) <> "" And Trim(cmborigin.Text) <> "All" Then
                gridsql = gridsql & " and origin='" & Trim(cmborigin.Text) & "'"
            End If

            If Trim(cmbrec.Text) <> "" And Trim(cmbrec.Text) <> "All" Then
                gridsql = gridsql & " and customer='" & Trim(cmbrec.Text) & "'"
            End If

            If Trim(cmbtranstype.Text) <> "" Then
                If cmbtranstype.Text.Contains("PICKUP") Then
                    gridsql = gridsql & " and transtype='" & Trim(cmbtranstype.Text) & " FRM " & Trim(cmbpick.Text) & "'"
                Else
                    gridsql = gridsql & " and transtype='" & Trim(cmbtranstype.Text) & "'"
                End If
            End If

            Dim ostat As String = order_stat()
            If ostat <> "" Then
                gridsql = gridsql & " and (" & ostat & ")"
            End If

            Dim tstat As String = trip_stat()
            If tstat <> "" Then
                gridsql = gridsql & " and (" & tstat & ")"
            End If

            gridsql = gridsql & " order by datepick, vtype, tripnum, cusodo"

            grdrep.Rows.Clear()

            lblloading.Visible = True
            GroupBox1.Enabled = False
            GroupBox2.Enabled = False
            'ProgressBar1.Style = ProgressBarStyle.Marquee
            'ProgressBar1.Visible = True
            'ProgressBar1.Minimum = 0

            backgroundWorker = New BackgroundWorker()
            backgroundWorker.WorkerReportsProgress = True
            backgroundWorker.WorkerSupportsCancellation = True

            AddHandler backgroundWorker.DoWork, New DoWorkEventHandler(AddressOf backgroundWorker_DoWork)
            AddHandler backgroundWorker.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorker_Completed)
            AddHandler backgroundWorker.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorker_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not backgroundWorker.IsBusy Then
                backgroundWorker.WorkerReportsProgress = True
                backgroundWorker.WorkerSupportsCancellation = True
                backgroundWorker.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub backgroundWorker_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabled = True

        Dim tpnum As String = "", colortag As Integer = 1
        Dim rowcount As Integer = 0, i As Integer = 0, stat As String = ""
        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If
        cmd = New SqlCommand(gridsql, connection)
        Dim drx As SqlDataReader = cmd.ExecuteReader
        While drx.Read
            If tpnum <> drx("tripnum") Then
                tpnum = drx("tripnum")
                If colortag = 0 Then
                    colortag = 1
                Else
                    colortag = 0
                End If
            End If

            If drx("transstatus") = 0 Then
                stat = "Cancelled"
            ElseIf drx("transstatus") = 2 Then
                stat = "Completed"
            ElseIf drx("transstatus") = 3 Then
                stat = "Removed"
            ElseIf drx("transstatus") = 4 Then
                stat = "Rescheduled"
            ElseIf drx("transstatus") = 5 Then
                stat = "For AR Credit Memo"
            ElseIf drx("transstatus") = 1 Then
                stat = "In Process"
            End If

            If grdrep.InvokeRequired Then
                grdrep.Invoke(m_addRowDelegate, Format(drx("datepick"), "yyyy/MM/dd"), drx("tripnum"), drx("platenum"), drx("vtype"), drx("driver"), drx("helper"), drx("origin"), drx("odoactual"), drx("odoend"), drx("dieselactual"), drx("dieselPO"), drx("dieselend"), drx("transnum"), drx("customer"), drx("cusodo"), drx("transtype"), drx("delqty"), drx("sonum"), drx("ponum"), drx("swsnum"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), stat, drx("notes"), colortag, i)
            Else
                AddDGVRow(Format(drx("datepick"), "yyyy/MM/dd"), drx("tripnum"), drx("platenum"), drx("vtype"), drx("driver"), drx("helper"), drx("origin"), drx("odoactual"), drx("odoend"), drx("dieselactual"), drx("dieselPO"), drx("dieselend"), drx("transnum"), drx("customer"), drx("cusodo"), drx("transtype"), drx("delqty"), drx("sonum"), drx("ponum"), drx("swsnum"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), stat, drx("notes"), colortag, i)
            End If
            i += 1
            backgroundWorker.ReportProgress(i) '/ idivide kung ilan ang total
            '/System.Threading.Thread.Sleep(50)
            'If i = 3 Then
            '    threadEnabled = False
            '    Exit While
            'End If
        End While
        drx.Dispose()
        cmd.Dispose()
        connection.Close()
    End Sub

    Delegate Sub AddRowDelegate(ByVal v0 As Object, ByVal v1 As Object, ByVal v2 As Object, ByVal v3 As Object, ByVal v4 As Object, ByVal v5 As Object, ByVal v6 As Object, ByVal v7 As Object, ByVal v8 As Object, ByVal v9 As Object, ByVal v10 As Object, ByVal v11 As Object, ByVal v12 As Object, ByVal v13 As Object, ByVal v14 As Object, ByVal v15 As Object, ByVal v16 As Object, ByVal v17 As Object, ByVal v18 As Object, ByVal v19 As Object, ByVal v20 As Object, ByVal v21 As Object, ByVal v22 As Object, ByVal v23 As Object, ByVal v24 As Object, ByVal v25 As Object, ByVal v26 As Object, ByVal v27 As Object, ByVal v28 As Object, ByVal vcolor As Object, ByVal valuerowin As Object)
    Private m_addRowDelegate As AddRowDelegate

    Private Sub AddDGVRow(ByVal v0 As Object, ByVal v1 As Object, ByVal v2 As Object, ByVal v3 As Object, ByVal v4 As Object, ByVal v5 As Object, ByVal v6 As Object, ByVal v7 As Object, ByVal v8 As Object, ByVal v9 As Object, ByVal v10 As Object, ByVal v11 As Object, ByVal v12 As Object, ByVal v13 As Object, ByVal v14 As Object, ByVal v15 As Object, ByVal v16 As Object, ByVal v17 As Object, ByVal v18 As Object, ByVal v19 As Object, ByVal v20 As Object, ByVal v21 As Object, ByVal v22 As Object, ByVal v23 As Object, ByVal v24 As Object, ByVal v25 As Object, ByVal v26 As Object, ByVal v27 As Object, ByVal v28 As Object, ByVal vcolor As Object, ByVal rowin As Integer)
        If threadEnabled = True Then
            If grdrep.InvokeRequired Then
                grdrep.BeginInvoke(New AddRowDelegate(AddressOf AddDGVRow), v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23, v24, v25, v26, v27, v28, vcolor, rowin)
            Else
                grdrep.Rows.Add(v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23, v24, v25, v26, v27, v28)
                grdrep.Rows(rowin).Cells(0).Tag = vcolor
            End If
        End If
    End Sub

    Private Sub backgroundWorker_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        Me.Cursor = Cursors.Default
        'ProgressBar1.Visible = False
        'ProgressBar1.Style = ProgressBarStyle.Blocks
        lblloading.Visible = False
        GroupBox1.Enabled = True
        GroupBox2.Enabled = True
        grdrep.SuspendLayout()
        grdrep.ResumeLayout()

        If e.Error IsNot Nothing Then
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            If grdrep.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            Else
                MsgBox("Loading data completed.", MsgBoxStyle.Information, "")
            End If
        End If
    End Sub

    Private Sub backgroundWorker_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label8.Text = e.ProgressPercentage.ToString() & "% complete"
    End Sub

    Private Sub cmbplate_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbplate.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbplate_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbplate.Leave
        Try
            If Trim(cmbplate.Text) <> "" And Trim(cmbplate.Text) <> "All" And Trim(cmbplate.Text) <> "ALL" And Trim(cmbplate.Text) <> "all" Then
                sql = "Select * from tblgeneral where platenum='" & Trim(cmbplate.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbtype.Text = dr("vtype")
                Else
                    cmbplate.SelectedItem = "All"
                    cmbtype.SelectedItem = "All"
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Else
                cmbplate.SelectedItem = "All"
                cmbtype.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbtype_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbtype.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbtype_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbtype.Leave
        Try
            If Trim(cmbtype.Text) <> "" And Trim(cmbtype.Text) <> "All" And Trim(cmbtype.Text) <> "ALL" And Trim(cmbtype.Text) <> "all" Then
                sql = "Select * from tblvtype where vtype='" & Trim(cmbtype.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then

                Else
                    cmbtype.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbdriver_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbdriver.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbdriver_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbdriver.Leave
        Try
            If Trim(cmbdriver.Text) <> "" And Trim(cmbdriver.Text) <> "All" And Trim(cmbdriver.Text) <> "ALL" And Trim(cmbdriver.Text) <> "all" Then
                sql = "Select * from tbldriver where driver='" & Trim(cmbdriver.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then

                Else
                    cmbdriver.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbhelper_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbhelper.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbhelper_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbhelper.Leave
        Try
            If Trim(cmbhelper.Text) <> "" And Trim(cmbhelper.Text) <> "All" And Trim(cmbhelper.Text) <> "ALL" And Trim(cmbhelper.Text) <> "all" Then
                sql = "Select * from tblhelper where helper='" & Trim(cmbhelper.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then

                Else
                    cmbhelper.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmborigin_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmborigin.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmborigin_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmborigin.Leave
        Try
            If Trim(cmborigin.Text) <> "" And Trim(cmborigin.Text) <> "All" And Trim(cmborigin.Text) <> "ALL" And Trim(cmborigin.Text) <> "all" Then
                sql = "Select * from tblwhse where whsename='" & Trim(cmborigin.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then

                Else
                    cmborigin.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbtripstat_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbrec_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbrec.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbrec_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbrec.Leave
        Try
            If Trim(cmbrec.Text) <> "" And Trim(cmbrec.Text) <> "All" And Trim(cmbrec.Text) <> "ALL" And Trim(cmbrec.Text) <> "all" Then
                sql = "Select * from tblcustomer where customer='" & Trim(cmbrec.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbrec.Text = dr("customer")
                Else
                    cmbrec.SelectedItem = "All"
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Else
                cmbrec.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbtranstype_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbtranstype.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbtranstype_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbtranstype.Leave
        If Trim(cmbtranstype.Text) <> "" Then
            If Trim(cmbtranstype.Text).ToUpper <> "JPSC STOCK TRANSFER PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "JPSC STOCK TRANSFER WHSE TO WHSE" And Trim(cmbtranstype.Text).ToUpper <> "JPSC SALES TRANSACTION" And Trim(cmbtranstype.Text).ToUpper <> "JPSC SALES TRANSACTION PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "CUSTOMER SALES TRANSACTION WHSE" And Trim(cmbtranstype.Text).ToUpper <> "CUSTOMER SALES TRANSACTION PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "TRUCKING STOCK TRANSFER PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "TRUCKING SALES TRANSACTION PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "TRUCKING SALES TRANSACTION WHSE" Then
                MsgBox("Invalid transaction type.", MsgBoxStyle.Exclamation, "")
                cmbtranstype.Text = ""
                cmbpick.Text = ""
                cmbpick.Enabled = False
                Exit Sub
            End If
        End If

        Try
            If cmbtranstype.SelectedIndex = 0 Then
                cmbpick.Enabled = False

            Else
                If cmbtranstype.Text.ToString.Contains("PICKUP") Then
                    If cmbpick.Text = "" Then
                        cmbpick.Enabled = True

                    Else
                        cmbpick.Enabled = True
                    End If

                Else
                    cmbpick.Text = ""
                    cmbpick.Enabled = False

                    If cmbtranstype.SelectedItem = "JPSC STOCK TRANSFER WHSE TO WHSE" Then

                    ElseIf cmbtranstype.SelectedItem = "JPSC SALES TRANSACTION" Then

                    ElseIf cmbtranstype.SelectedItem = "CUSTOMER SALES TRANSACTION WHSE" Then

                    ElseIf cmbtranstype.SelectedItem = "TRUCKING SALES TRANSACTION WHSE" Then

                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmbtranstype_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbtranstype.SelectedIndexChanged
        If Trim(cmbtranstype.Text) <> "" Then
            If Trim(cmbtranstype.Text).ToUpper <> "JPSC STOCK TRANSFER PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "JPSC STOCK TRANSFER WHSE TO WHSE" And Trim(cmbtranstype.Text).ToUpper <> "JPSC SALES TRANSACTION" And Trim(cmbtranstype.Text).ToUpper <> "JPSC SALES TRANSACTION PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "CUSTOMER SALES TRANSACTION WHSE" And Trim(cmbtranstype.Text).ToUpper <> "CUSTOMER SALES TRANSACTION PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "TRUCKING STOCK TRANSFER PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "TRUCKING SALES TRANSACTION PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "TRUCKING SALES TRANSACTION WHSE" Then
                MsgBox("Invalid transaction type.", MsgBoxStyle.Exclamation, "")
                cmbtranstype.Text = ""
                cmbpick.Text = ""
                cmbpick.Enabled = False
                Exit Sub
            End If
        End If

        Try
            If cmbtranstype.SelectedIndex = 0 Then
                cmbpick.Enabled = False

            Else
                If cmbtranstype.SelectedItem.ToString.Contains("PICKUP") Then
                    If cmbpick.Text = "" Then
                        cmbpick.Enabled = True

                    Else
                        cmbpick.Enabled = True
                    End If

                Else
                    cmbpick.Text = ""
                    cmbpick.Enabled = False

                    If cmbtranstype.SelectedItem = "JPSC STOCK TRANSFER WHSE TO WHSE" Then

                    ElseIf cmbtranstype.SelectedItem = "JPSC SALES TRANSACTION" Then

                    ElseIf cmbtranstype.SelectedItem = "CUSTOMER SALES TRANSACTION WHSE" Then

                    ElseIf cmbtranstype.SelectedItem = "TRUCKING SALES TRANSACTION WHSE" Then

                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub txtrems_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    'Private Sub txtrems_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    Dim charactersDisallowed As String = "'"
    '    Dim theText As String = txtrems.Text
    '    Dim Letter As String
    '    Dim SelectionIndex As Integer = txtrems.SelectionStart
    '    Dim Change As Integer

    '    For x As Integer = 0 To txtrems.Text.Length - 1
    '        Letter = txtrems.Text.Substring(x, 1)
    '        If charactersDisallowed.Contains(Letter) Then
    '            theText = theText.Replace(Letter, String.Empty)
    '            Change = 1
    '        End If
    '    Next

    '    txtrems.Text = theText
    '    txtrems.Select(SelectionIndex - Change, 0)
    'End Sub

    Private Sub tripreport_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub grdrep_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdrep.CellContentClick

    End Sub

    Private Sub grdrep_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grdrep.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdrep.Rows(e.RowIndex)
            '<== But this is the name assigned to it in the properties of the control
            'If CDate(Format(dgvRow.Cells(1).Value, "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
            If dgvRow.Cells(0).Tag = 0 Then
                dgvRow.DefaultCellStyle.BackColor = Color.PeachPuff
            Else
                dgvRow.DefaultCellStyle.BackColor = Color.LightCyan
            End If

            If dgvRow.Cells(27).Value = "Completed" Then
                For i = 12 To 28
                    dgvRow.Cells(i).Style.BackColor = Color.Yellow
                Next
            ElseIf dgvRow.Cells(27).Value = "Rescheduled" Then
                For i = 12 To 28
                    dgvRow.Cells(i).Style.BackColor = Color.Plum
                Next
            ElseIf dgvRow.Cells(27).Value = "For AR Credit Memo" Then
                For i = 12 To 28
                    dgvRow.Cells(i).Style.BackColor = Color.Orange
                Next
            ElseIf dgvRow.Cells(27).Value = "Cancelled" Then
                For i = 12 To 28
                    dgvRow.Cells(i).Style.BackColor = Color.DeepSkyBlue
                Next
            End If
        End If

        'Dim dgvRow As DataGridViewRow = grdrep.Rows(e.RowIndex)

        'If e.RowIndex = 0 Then
        '    grdrep.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Yellow
        'Else
        '    Dim a As String = grdrep.Rows(e.RowIndex - 1).Cells(1).Value
        '    Dim b As String = grdrep.Rows(e.RowIndex).Cells(1).Value
        '    If a = b Then
        '        grdrep.Rows(e.RowIndex).DefaultCellStyle.BackColor = grdrep.Rows(e.RowIndex - 1).DefaultCellStyle.BackColor
        '    Else
        '        grdrep.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.LightGreen
        '        If grdrep.Rows(e.RowIndex - 1).DefaultCellStyle.BackColor = Color.LightGreen Then
        '            grdrep.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Yellow
        '        End If
        '    End If
        'End If
    End Sub

    Private Sub sqlquery()
        gridsql = "SELECT tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tblgeneral.vtype, tbltripsum.driver, tbltripsum.helper,"
        gridsql = gridsql & " tbltripsum.origin, tbltripsum.odoactual, tbltripsum.odoend, tbltripsum.dieselactual, Sum(tbltripsum.podiesel + tbltripsum.addpo + tbltripsum.postaddpo) as dieselPO,"
        gridsql = gridsql & " tbltripsum.dieselend, tblortrans.transnum, tblortrans.customer, tblortrans.transtype, Sum(tblorder.qty) as delqty, tblortrans.refnum, tblortrans.arnum,"
        gridsql = gridsql & " tblortrans.rdrnum, tblortrans.drnum, tblortrans.dnnum, tblortrans.itrnum, tblortrans.itnum,"
        gridsql = gridsql & " tblortrans.grponum, tbltripitems.status, tblortrans.notes"

        gridsql = gridsql & " FROM tbltripitems RIGHT OUTER JOIN tbltripsum ON tbltripitems.tripnum=tbltripsum.tripnum"
        gridsql = gridsql & " RIGHT OUTER JOIN tblortrans ON tbltripitems.transnum=tblortrans.transnum"
        gridsql = gridsql & " RIGHT OUTER JOIN tblorder ON tblortrans.transnum=tblorder.transnum"
        gridsql = gridsql & " RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
        gridsql = gridsql & " where datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "' and tbltripsum.whsename='" & login.whse & "'"

        If Trim(cmbplate.Text) <> "" And Trim(cmbplate.Text) <> "All" Then
            gridsql = gridsql & " and tbltripsum.platenum='" & Trim(cmbplate.Text) & "'"
        End If

        If Trim(cmbtype.Text) <> "" And Trim(cmbtype.Text) <> "All" Then
            gridsql = gridsql & " and tblgeneral.vtype='" & Trim(cmbtype.Text) & "'"
        End If

        If Trim(cmbdriver.Text) <> "" And Trim(cmbdriver.Text) <> "All" Then
            gridsql = gridsql & " and tbltripsum.driver='" & Trim(cmbdriver.Text) & "'"
        End If

        If Trim(cmbrec.Text) <> "" And Trim(cmbrec.Text) <> "All" Then
            gridsql = gridsql & " and tblortrans.customer='" & Trim(cmbrec.Text) & "'"
        End If

        If Trim(cmbtranstype.Text) <> "" Then
            If cmbtranstype.Text.Contains("PICKUP") Then
                gridsql = gridsql & " and tblortrans.transtype='" & Trim(cmbtranstype.Text) & " FRM " & Trim(cmbpick.Text) & "'"
            Else
                gridsql = gridsql & " and tblortrans.transtype='" & Trim(cmbtranstype.Text) & "'"
            End If
        End If

        gridsql = gridsql & " group by tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.helper, tbltripsum.origin,"
        gridsql = gridsql & " tbltripsum.odoactual, tbltripsum.odoend, tbltripsum.dieselactual,"
        gridsql = gridsql & " tbltripsum.dieselend, tbltripitems.status, tblortrans.transnum, tblortrans.customer, tblortrans.transtype, tblortrans.refnum, tblortrans.arnum, tblortrans.rdrnum,"
        gridsql = gridsql & " tblortrans.drnum, tblortrans.dnnum, tblortrans.notes, tblortrans.itrnum, tblortrans.itnum, tblortrans.grponum, tblgeneral.vtype"

        gridsql = gridsql & " order by tripnum"

        'If drx("refnum").ToString.Contains("/") Then

        '    'MsgBox(drx("refnum").ToString)
        '    inSql = drx("refnum").ToString

        '    selectStart = inSql.IndexOf("SO")
        '    fromStart = inSql.IndexOf("#") + 1
        '    selectStart = selectStart + 2
        '    firstPart = inSql.Substring(fromStart, inSql.Length - fromStart)
        '    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

        '    fields = firstPart.Split(" ")
        '    firstPart = ""

        '    sonum = fields(0).ToString

        '    inSql = lastPart
        '    selectStart = inSql.IndexOf("PO")
        '    fromStart = inSql.IndexOf("#") + 1
        '    selectStart = selectStart + 2
        '    firstPart = inSql.Substring(fromStart, inSql.Length - fromStart)
        '    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

        '    fields = firstPart.Split("#")
        '    firstPart = ""

        '    ponum = lastPart

        'ElseIf drx("refnum").ToString.Contains("SO#") And Not drx("refnum").ToString.Contains("/") Then

        '    inSql = drx("refnum").ToString

        '    selectStart = inSql.IndexOf("SO")
        '    fromStart = inSql.IndexOf("#") + 1
        '    selectStart = selectStart + 2
        '    firstPart = inSql.Substring(selectStart, (fromStart - selectStart))
        '    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

        '    'fields = firstPart.Split("")
        '    firstPart = ""

        '    'MsgBox(lastPart)
        '    sonum = lastPart

        'ElseIf drx("refnum").ToString.Contains("PO#") And Not drx("refnum").ToString.Contains("/") Then

        '    inSql = drx("refnum").ToString

        '    selectStart = inSql.IndexOf("PO")
        '    fromStart = inSql.IndexOf("#") + 1
        '    selectStart = selectStart + 2
        '    firstPart = inSql.Substring(selectStart, (fromStart - selectStart))
        '    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

        '    'fields = firstPart.Split("")
        '    firstPart = ""

        '    'MsgBox(lastPart)
        '    ponum = lastPart

        'ElseIf drx("refnum").ToString.Contains("SWS#") And Not drx("refnum").ToString.Contains("/") Then

        '    inSql = drx("refnum").ToString

        '    selectStart = inSql.IndexOf("SWS")
        '    fromStart = inSql.IndexOf("#") + 1
        '    selectStart = selectStart + 2
        '    firstPart = inSql.Substring(selectStart, (fromStart - selectStart))
        '    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

        '    'fields = firstPart.Split("")
        '    firstPart = ""

        '    'MsgBox(lastPart)
        '    swsnum = lastPart

        'End If
    End Sub

    Function order_stat()
        Dim ostat As String = ""
        For Each chk As Object In GroupBox2.Controls
            If TypeOf chk Is CheckBox Then
                If chk.Checked = True Then
                    If ostat = "" Then
                        ostat = "transstatus='" & chk.Tag & "'"
                    Else
                        ostat = ostat & " or transstatus='" & chk.Tag & "'"
                    End If
                End If
            End If
        Next

        Return ostat
    End Function

    Function trip_stat()
        Dim tstat As String = ""
        For Each chk As Object In GroupBox1.Controls
            If TypeOf chk Is CheckBox Then
                If chk.Checked = True Then
                    If tstat = "" Then
                        tstat = "tripstat='" & chk.Tag & "'"
                    Else
                        tstat = tstat & " or tripstat='" & chk.Tag & "'"
                    End If
                End If
            End If
        Next

        Return tstat
    End Function
End Class