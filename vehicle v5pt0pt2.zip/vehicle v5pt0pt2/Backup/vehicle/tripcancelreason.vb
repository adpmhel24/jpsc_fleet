﻿Public Class tripcancelreason

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Trim(txtreason.Text) <> "" Then
            tripcancel.cancelreason = Trim(txtreason.Text)
            Me.Dispose()
        Else
            MsgBox("Input reason.", MsgBoxStyle.Exclamation, "")
            txtreason.Focus()
        End If
    End Sub

    Private Sub txtreason_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtreason.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtreason_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtreason.TextChanged

    End Sub

    Private Sub tripcancelreason_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        lbltripnum.Text = ""
    End Sub

    Private Sub tripcancelreason_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lbltripnum.Text = tripcancel.lbltripnum.Text
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class