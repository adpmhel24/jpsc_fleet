﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class pms
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim stat As String
    Public pmscnf As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            If Trim(txtpms.Text) = "" Then
                grdpms.Rows.Clear()
                MsgBox("Input service name first.", MsgBoxStyle.Exclamation, "")
                txtpms.Focus()
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

            sql = "Select * from tblpms where servicename like '" & Trim(txtpms.Text) & "%'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                grdpms.Rows.Clear()
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdpms.Rows.Add(dr("pmsid"), dr("servicename"), stat)
                txtpms.Text = ""
            Else
                MsgBox("Cannot found " & Trim(txtpms.Text), MsgBoxStyle.Critical, "")
                txtpms.Text = ""
                txtpms.Focus()
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If Trim(txtpms.Text) <> "" Then
                sql = "Select * from tblpms where servicename='" & Trim(txtpms.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    MsgBox(Trim(txtpms.Text) & " is already exist", MsgBoxStyle.Information, "")
                    btnupdate.Text = "&Update"
                    txtpms.Text = ""
                    txtpms.Focus()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                pmscnf = False
                confirm.ShowDialog()
                If pmscnf = True Then
                    sql = "Insert into tblpms (servicename, datecreated, createdby, datemodified, modifiedby, status) values('" & Trim(txtpms.Text) & "',GetDate(),'" & login.cashier & "',GetDate(),'" & login.cashier & "','1')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                    btnview.PerformClick()
                End If

                txtpms.Text = ""
                txtpms.Focus()
                pmscnf = False
            Else
                MsgBox("Input service name first", MsgBoxStyle.Exclamation, "")
                txtpms.Focus()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        Try
            grdpms.Rows.Clear()
            Dim stat As String = ""

            sql = "Select * from tblpms"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdpms.Rows.Add(dr("pmsid"), dr("servicename"), stat)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If grdpms.Rows.Count = 0 Then
                btnupdate.Enabled = False
                btndeactivate.Enabled = False
            Else
                btnupdate.Enabled = True
                btndeactivate.Enabled = True
            End If

            btncancel.PerformClick()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtmake_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtpms.Leave
        txtpms.Text = StrConv(txtpms.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txttype_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtpms.TextChanged
        If Trim(txtpms.Text) <> "" Then
            btncancel.Enabled = True
        ElseIf Trim(txtpms.Text) = "" And btnupdate.Text = "&Save" Then
            btncancel.Enabled = True
        Else
            btncancel.Enabled = False
        End If

        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtpms.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtpms.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtpms.Text.Length - 1
            Letter = txtpms.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtpms.Text = theText
        txtpms.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub pms_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnview.PerformClick()
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        txtpms.Text = ""
        btnupdate.Text = "&Update"
        btnsearch.Enabled = True
        btnadd.Enabled = True
        btndeactivate.Enabled = True
        btncancel.Enabled = False
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdpms.SelectedRows.Count = 1 Or grdpms.SelectedCells.Count = 1 Then
                If btnupdate.Text = "&Update" Then
                    If grdpms.Rows(grdpms.CurrentRow.Index).Cells(2).Value = "Deactivated" Then
                        MsgBox("Cannot update deactivated service name.", MsgBoxStyle.Exclamation, "")
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    lblcat.Text = grdpms.Rows(grdpms.CurrentRow.Index).Cells(1).Value
                    txtpms.Text = grdpms.Rows(grdpms.CurrentRow.Index).Cells(1).Value
                    lblid.Text = grdpms.Rows(grdpms.CurrentRow.Index).Cells(0).Value
                    btnsearch.Enabled = False
                    btnadd.Enabled = False
                    btnupdate.Text = "&Save"
                    btncancel.Enabled = True
                    btndeactivate.Enabled = False
                Else
                    'update
                    If Trim(txtpms.Text) = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Service name should not be empty.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If

                    sql = "Select * from tblpms where servicename='" & Trim(txtpms.Text) & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox(Trim(txtpms.Text) & " is already exist", MsgBoxStyle.Information, "")
                        btnupdate.Text = "&Update"
                        btnsearch.Enabled = True
                        btnadd.Enabled = True
                        btncancel.Enabled = False
                        btndeactivate.Enabled = True
                        txtpms.Text = ""
                        txtpms.Focus()
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    pmscnf = False
                    confirm.ShowDialog()
                    If pmscnf = True Then
                        If Trim(txtpms.Text) <> Trim(lblcat.Text) Then
                            sql = "Update tblpms set servicename='" & Trim(txtpms.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where pmsid='" & lblid.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'update other tbl in database
                            sql = "Update tblgeneral set servicename='" & Trim(txtpms.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where servicename='" & lblcat.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()
                        End If

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    btnupdate.Text = "&Update"
                    btnsearch.Enabled = True
                    btnadd.Enabled = True
                    btncancel.Enabled = False
                    btndeactivate.Enabled = True
                    txtpms.Text = ""
                    txtpms.Focus()
                    pmscnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
                btnview.PerformClick()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btndeactivate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndeactivate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdpms.SelectedRows.Count = 1 Or grdpms.SelectedCells.Count = 1 Then
                lblid.Text = grdpms.Rows(grdpms.CurrentRow.Index).Cells(0).Value
                If btndeactivate.Text = "&Deactivate" Then
                    'check if theres item available status
                    sql = "Select * from tblgeneral where servicename='" & grdpms.Rows(grdpms.CurrentRow.Index).Cells(1).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox("Cannot deactivate. Service name is still in use.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    pmscnf = False
                    confirm.ShowDialog()
                    If pmscnf = True Then
                        sql = "Update tblpms set status='0', datemodified=GetDate(), modifiedby='" & login.cashier & "' where pmsid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    pmscnf = False
                Else
                    pmscnf = False
                    confirm.ShowDialog()
                    If pmscnf = True Then
                        sql = "Update tblpms set status='1', datemodified=GetDate(), modifiedby='" & login.cashier & "' where pmsid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    pmscnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdpms_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdpms.SelectionChanged
        If grdpms.Rows(grdpms.CurrentRow.Index).Cells(2).Value = "Active" Then
            btndeactivate.Text = "&Deactivate"
        Else
            btndeactivate.Text = "A&ctivate"
        End If
    End Sub
End Class