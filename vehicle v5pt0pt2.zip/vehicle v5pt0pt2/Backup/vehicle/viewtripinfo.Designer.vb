﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class viewtripinfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(viewtripinfo))
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.grddispatch = New System.Windows.Forms.DataGridView
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.grdtrans = New System.Windows.Forms.DataGridView
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column1 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column27 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column28 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column25 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column26 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column29 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column30 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lblpick = New System.Windows.Forms.Label
        Me.chkpick = New System.Windows.Forms.CheckBox
        Me.txtcanby = New System.Windows.Forms.TextBox
        Me.txtdatecan = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.txtcancel = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.txtrems = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.lbltripnum = New System.Windows.Forms.Label
        Me.txtmodify = New System.Windows.Forms.TextBox
        Me.txtdatemod = New System.Windows.Forms.TextBox
        Me.txtcreated = New System.Windows.Forms.TextBox
        Me.txtdatecr = New System.Windows.Forms.TextBox
        Me.txtetd = New System.Windows.Forms.TextBox
        Me.txtdes = New System.Windows.Forms.TextBox
        Me.txtorigin = New System.Windows.Forms.TextBox
        Me.txthelper = New System.Windows.Forms.TextBox
        Me.txtdriver = New System.Windows.Forms.TextBox
        Me.txttype = New System.Windows.Forms.TextBox
        Me.txtplate = New System.Windows.Forms.TextBox
        Me.txtdel = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblid = New System.Windows.Forms.Label
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ViewEditReferenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column20 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column21 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column24 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column22 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column23 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Panel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.grddispatch, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.grdtrans, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.GroupBox3)
        Me.Panel1.Controls.Add(Me.GroupBox2)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1018, 671)
        Me.Panel1.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.White
        Me.GroupBox3.Controls.Add(Me.grddispatch)
        Me.GroupBox3.Location = New System.Drawing.Point(3, 419)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(1003, 240)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Dispatch Summary"
        '
        'grddispatch
        '
        Me.grddispatch.AllowUserToAddRows = False
        Me.grddispatch.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grddispatch.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grddispatch.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grddispatch.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grddispatch.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grddispatch.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddispatch.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.grddispatch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grddispatch.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column19, Me.Column20, Me.Column21, Me.Column24, Me.Column22, Me.Column23})
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grddispatch.DefaultCellStyle = DataGridViewCellStyle9
        Me.grddispatch.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grddispatch.EnableHeadersVisualStyles = False
        Me.grddispatch.GridColor = System.Drawing.Color.Salmon
        Me.grddispatch.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grddispatch.Location = New System.Drawing.Point(12, 19)
        Me.grddispatch.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grddispatch.Name = "grddispatch"
        Me.grddispatch.ReadOnly = True
        Me.grddispatch.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddispatch.RowHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.grddispatch.RowHeadersWidth = 15
        Me.grddispatch.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle11.NullValue = Nothing
        Me.grddispatch.RowsDefaultCellStyle = DataGridViewCellStyle11
        Me.grddispatch.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grddispatch.Size = New System.Drawing.Size(973, 222)
        Me.grddispatch.TabIndex = 17
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.grdtrans)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 237)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(1003, 176)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Transactions"
        '
        'grdtrans
        '
        Me.grdtrans.AllowUserToAddRows = False
        Me.grdtrans.AllowUserToDeleteRows = False
        DataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdtrans.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle12
        Me.grdtrans.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdtrans.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdtrans.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdtrans.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle13.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.NullValue = Nothing
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.grdtrans.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdtrans.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column4, Me.Column13, Me.Column1, Me.Column2, Me.Column3, Me.Column5, Me.Column8, Me.Column9, Me.Column10, Me.Column12, Me.Column11, Me.Column27, Me.Column28, Me.Column7, Me.Column17, Me.Column6, Me.Column18, Me.Column14, Me.Column15, Me.Column16, Me.Column25, Me.Column26, Me.Column29, Me.Column30})
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrans.DefaultCellStyle = DataGridViewCellStyle14
        Me.grdtrans.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdtrans.EnableHeadersVisualStyles = False
        Me.grdtrans.GridColor = System.Drawing.Color.Salmon
        Me.grdtrans.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdtrans.Location = New System.Drawing.Point(12, 18)
        Me.grdtrans.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdtrans.Name = "grdtrans"
        Me.grdtrans.ReadOnly = True
        Me.grdtrans.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans.RowHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.grdtrans.RowHeadersWidth = 15
        Me.grdtrans.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle16.NullValue = Nothing
        Me.grdtrans.RowsDefaultCellStyle = DataGridViewCellStyle16
        Me.grdtrans.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrans.Size = New System.Drawing.Size(973, 146)
        Me.grdtrans.TabIndex = 16
        '
        'Column4
        '
        Me.Column4.HeaderText = "ID"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Visible = False
        '
        'Column13
        '
        Me.Column13.HeaderText = "Date Booked"
        Me.Column13.Name = "Column13"
        Me.Column13.ReadOnly = True
        '
        'Column1
        '
        Me.Column1.HeaderText = "Transaction #"
        Me.Column1.LinkColor = System.Drawing.Color.Black
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column1.VisitedLinkColor = System.Drawing.Color.Black
        Me.Column1.Width = 130
        '
        'Column2
        '
        Me.Column2.HeaderText = "Reference #"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column2.Width = 130
        '
        'Column3
        '
        Me.Column3.HeaderText = "Recipient"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 200
        '
        'Column5
        '
        Me.Column5.HeaderText = "Transaction Type"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Width = 250
        '
        'Column8
        '
        Me.Column8.HeaderText = "AR#"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'Column9
        '
        Me.Column9.HeaderText = "RDR#"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        '
        'Column10
        '
        Me.Column10.HeaderText = "DR#"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        '
        'Column12
        '
        Me.Column12.HeaderText = "DN#"
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        '
        'Column11
        '
        Me.Column11.HeaderText = "ITR#"
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        '
        'Column27
        '
        Me.Column27.HeaderText = "IT#"
        Me.Column27.Name = "Column27"
        Me.Column27.ReadOnly = True
        '
        'Column28
        '
        Me.Column28.HeaderText = "GRPO#"
        Me.Column28.Name = "Column28"
        Me.Column28.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.HeaderText = "Cancel"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Visible = False
        '
        'Column17
        '
        Me.Column17.HeaderText = "Status"
        Me.Column17.Name = "Column17"
        Me.Column17.ReadOnly = True
        '
        'Column6
        '
        Me.Column6.HeaderText = "Notes"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'Column18
        '
        Me.Column18.HeaderText = "Date Created"
        Me.Column18.Name = "Column18"
        Me.Column18.ReadOnly = True
        Me.Column18.Width = 150
        '
        'Column14
        '
        Me.Column14.HeaderText = "Created by"
        Me.Column14.Name = "Column14"
        Me.Column14.ReadOnly = True
        '
        'Column15
        '
        Me.Column15.HeaderText = "Date Modified"
        Me.Column15.Name = "Column15"
        Me.Column15.ReadOnly = True
        Me.Column15.Width = 150
        '
        'Column16
        '
        Me.Column16.HeaderText = "Modified by"
        Me.Column16.Name = "Column16"
        Me.Column16.ReadOnly = True
        '
        'Column25
        '
        Me.Column25.HeaderText = "Date Added to Trip"
        Me.Column25.Name = "Column25"
        Me.Column25.ReadOnly = True
        Me.Column25.Width = 120
        '
        'Column26
        '
        Me.Column26.HeaderText = "Added by"
        Me.Column26.Name = "Column26"
        Me.Column26.ReadOnly = True
        '
        'Column29
        '
        Me.Column29.HeaderText = "Date Recorded"
        Me.Column29.Name = "Column29"
        Me.Column29.ReadOnly = True
        Me.Column29.Width = 120
        '
        'Column30
        '
        Me.Column30.HeaderText = "Recorded by"
        Me.Column30.Name = "Column30"
        Me.Column30.ReadOnly = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.lblpick)
        Me.GroupBox1.Controls.Add(Me.chkpick)
        Me.GroupBox1.Controls.Add(Me.txtcanby)
        Me.GroupBox1.Controls.Add(Me.txtdatecan)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.txtcancel)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.txtrems)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.lbltripnum)
        Me.GroupBox1.Controls.Add(Me.txtmodify)
        Me.GroupBox1.Controls.Add(Me.txtdatemod)
        Me.GroupBox1.Controls.Add(Me.txtcreated)
        Me.GroupBox1.Controls.Add(Me.txtdatecr)
        Me.GroupBox1.Controls.Add(Me.txtetd)
        Me.GroupBox1.Controls.Add(Me.txtdes)
        Me.GroupBox1.Controls.Add(Me.txtorigin)
        Me.GroupBox1.Controls.Add(Me.txthelper)
        Me.GroupBox1.Controls.Add(Me.txtdriver)
        Me.GroupBox1.Controls.Add(Me.txttype)
        Me.GroupBox1.Controls.Add(Me.txtplate)
        Me.GroupBox1.Controls.Add(Me.txtdel)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.lblid)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1003, 228)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Trip Information"
        '
        'lblpick
        '
        Me.lblpick.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.lblpick.Font = New System.Drawing.Font("HoloLens MDL2 Assets", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpick.Location = New System.Drawing.Point(733, 201)
        Me.lblpick.Name = "lblpick"
        Me.lblpick.Size = New System.Drawing.Size(252, 23)
        Me.lblpick.TabIndex = 35
        Me.lblpick.Text = "PICKUP TRIP ONLY"
        Me.lblpick.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblpick.Visible = False
        '
        'chkpick
        '
        Me.chkpick.AutoSize = True
        Me.chkpick.Location = New System.Drawing.Point(736, 171)
        Me.chkpick.Name = "chkpick"
        Me.chkpick.Size = New System.Drawing.Size(114, 19)
        Me.chkpick.TabIndex = 34
        Me.chkpick.Text = "Pickup Trip Only"
        Me.chkpick.UseVisualStyleBackColor = True
        Me.chkpick.Visible = False
        '
        'txtcanby
        '
        Me.txtcanby.BackColor = System.Drawing.Color.White
        Me.txtcanby.Location = New System.Drawing.Point(834, 40)
        Me.txtcanby.Name = "txtcanby"
        Me.txtcanby.ReadOnly = True
        Me.txtcanby.Size = New System.Drawing.Size(151, 21)
        Me.txtcanby.TabIndex = 33
        '
        'txtdatecan
        '
        Me.txtdatecan.BackColor = System.Drawing.Color.White
        Me.txtdatecan.Location = New System.Drawing.Point(834, 14)
        Me.txtdatecan.Name = "txtdatecan"
        Me.txtdatecan.ReadOnly = True
        Me.txtdatecan.Size = New System.Drawing.Size(151, 21)
        Me.txtdatecan.TabIndex = 32
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(747, 43)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(81, 15)
        Me.Label15.TabIndex = 31
        Me.Label15.Text = "Cancelled by:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(733, 17)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(95, 15)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "Date Cancelled:"
        '
        'txtcancel
        '
        Me.txtcancel.BackColor = System.Drawing.Color.White
        Me.txtcancel.Location = New System.Drawing.Point(736, 96)
        Me.txtcancel.Multiline = True
        Me.txtcancel.Name = "txtcancel"
        Me.txtcancel.ReadOnly = True
        Me.txtcancel.Size = New System.Drawing.Size(249, 94)
        Me.txtcancel.TabIndex = 29
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(733, 69)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(122, 15)
        Me.Label14.TabIndex = 28
        Me.Label14.Text = "Reason if Cancelled:"
        '
        'txtrems
        '
        Me.txtrems.BackColor = System.Drawing.Color.White
        Me.txtrems.Location = New System.Drawing.Point(127, 201)
        Me.txtrems.Name = "txtrems"
        Me.txtrems.ReadOnly = True
        Me.txtrems.Size = New System.Drawing.Size(546, 21)
        Me.txtrems.TabIndex = 27
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(60, 204)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(61, 15)
        Me.Label13.TabIndex = 26
        Me.Label13.Text = "Remarks:"
        '
        'lbltripnum
        '
        Me.lbltripnum.AutoSize = True
        Me.lbltripnum.Location = New System.Drawing.Point(9, 69)
        Me.lbltripnum.Name = "lbltripnum"
        Me.lbltripnum.Size = New System.Drawing.Size(49, 15)
        Me.lbltripnum.TabIndex = 25
        Me.lbltripnum.Text = "tripnum"
        Me.lbltripnum.Visible = False
        '
        'txtmodify
        '
        Me.txtmodify.BackColor = System.Drawing.Color.White
        Me.txtmodify.Location = New System.Drawing.Point(522, 122)
        Me.txtmodify.Name = "txtmodify"
        Me.txtmodify.ReadOnly = True
        Me.txtmodify.Size = New System.Drawing.Size(151, 21)
        Me.txtmodify.TabIndex = 24
        '
        'txtdatemod
        '
        Me.txtdatemod.BackColor = System.Drawing.Color.White
        Me.txtdatemod.Location = New System.Drawing.Point(522, 96)
        Me.txtdatemod.Name = "txtdatemod"
        Me.txtdatemod.ReadOnly = True
        Me.txtdatemod.Size = New System.Drawing.Size(151, 21)
        Me.txtdatemod.TabIndex = 23
        '
        'txtcreated
        '
        Me.txtcreated.BackColor = System.Drawing.Color.White
        Me.txtcreated.Location = New System.Drawing.Point(522, 68)
        Me.txtcreated.Name = "txtcreated"
        Me.txtcreated.ReadOnly = True
        Me.txtcreated.Size = New System.Drawing.Size(151, 21)
        Me.txtcreated.TabIndex = 22
        '
        'txtdatecr
        '
        Me.txtdatecr.BackColor = System.Drawing.Color.White
        Me.txtdatecr.Location = New System.Drawing.Point(522, 42)
        Me.txtdatecr.Name = "txtdatecr"
        Me.txtdatecr.ReadOnly = True
        Me.txtdatecr.Size = New System.Drawing.Size(151, 21)
        Me.txtdatecr.TabIndex = 21
        '
        'txtetd
        '
        Me.txtetd.BackColor = System.Drawing.Color.White
        Me.txtetd.Location = New System.Drawing.Point(522, 16)
        Me.txtetd.Name = "txtetd"
        Me.txtetd.ReadOnly = True
        Me.txtetd.Size = New System.Drawing.Size(151, 21)
        Me.txtetd.TabIndex = 20
        '
        'txtdes
        '
        Me.txtdes.BackColor = System.Drawing.Color.White
        Me.txtdes.Location = New System.Drawing.Point(127, 174)
        Me.txtdes.Name = "txtdes"
        Me.txtdes.ReadOnly = True
        Me.txtdes.Size = New System.Drawing.Size(546, 21)
        Me.txtdes.TabIndex = 19
        '
        'txtorigin
        '
        Me.txtorigin.BackColor = System.Drawing.Color.White
        Me.txtorigin.Location = New System.Drawing.Point(127, 147)
        Me.txtorigin.Name = "txtorigin"
        Me.txtorigin.ReadOnly = True
        Me.txtorigin.Size = New System.Drawing.Size(218, 21)
        Me.txtorigin.TabIndex = 18
        '
        'txthelper
        '
        Me.txthelper.BackColor = System.Drawing.Color.White
        Me.txthelper.Location = New System.Drawing.Point(127, 121)
        Me.txthelper.Name = "txthelper"
        Me.txthelper.ReadOnly = True
        Me.txthelper.Size = New System.Drawing.Size(218, 21)
        Me.txthelper.TabIndex = 17
        '
        'txtdriver
        '
        Me.txtdriver.BackColor = System.Drawing.Color.White
        Me.txtdriver.Location = New System.Drawing.Point(127, 95)
        Me.txtdriver.Name = "txtdriver"
        Me.txtdriver.ReadOnly = True
        Me.txtdriver.Size = New System.Drawing.Size(218, 21)
        Me.txtdriver.TabIndex = 16
        '
        'txttype
        '
        Me.txttype.BackColor = System.Drawing.Color.White
        Me.txttype.Location = New System.Drawing.Point(127, 70)
        Me.txttype.Name = "txttype"
        Me.txttype.ReadOnly = True
        Me.txttype.Size = New System.Drawing.Size(218, 21)
        Me.txttype.TabIndex = 15
        '
        'txtplate
        '
        Me.txtplate.BackColor = System.Drawing.Color.White
        Me.txtplate.Location = New System.Drawing.Point(127, 43)
        Me.txtplate.Name = "txtplate"
        Me.txtplate.ReadOnly = True
        Me.txtplate.Size = New System.Drawing.Size(151, 21)
        Me.txtplate.TabIndex = 14
        '
        'txtdel
        '
        Me.txtdel.BackColor = System.Drawing.Color.White
        Me.txtdel.Location = New System.Drawing.Point(127, 16)
        Me.txtdel.Name = "txtdel"
        Me.txtdel.ReadOnly = True
        Me.txtdel.Size = New System.Drawing.Size(151, 21)
        Me.txtdel.TabIndex = 13
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(431, 101)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(85, 15)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "Date Modified:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(445, 125)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(71, 15)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "Modified by:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(447, 71)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(69, 15)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Created by:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(433, 45)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(83, 15)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Date Created:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Location = New System.Drawing.Point(482, 19)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(34, 15)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "ETD:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(48, 177)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 15)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Destination:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(78, 150)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(43, 15)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Origin:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(74, 126)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 15)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Helper:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(79, 98)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 15)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Driver:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(53, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 15)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Truck Type:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(35, 46)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Plate Number:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(61, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Trip Date:"
        '
        'lblid
        '
        Me.lblid.AutoSize = True
        Me.lblid.Location = New System.Drawing.Point(9, 17)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(22, 15)
        Me.lblid.TabIndex = 0
        Me.lblid.Text = "ID:"
        Me.lblid.Visible = False
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewEditReferenceToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(168, 26)
        '
        'ViewEditReferenceToolStripMenuItem
        '
        Me.ViewEditReferenceToolStripMenuItem.Image = CType(resources.GetObject("ViewEditReferenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewEditReferenceToolStripMenuItem.Name = "ViewEditReferenceToolStripMenuItem"
        Me.ViewEditReferenceToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.ViewEditReferenceToolStripMenuItem.Text = "View Ref# History"
        '
        'Column19
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.Column19.DefaultCellStyle = DataGridViewCellStyle3
        Me.Column19.Frozen = True
        Me.Column19.HeaderText = "Steps"
        Me.Column19.Name = "Column19"
        Me.Column19.ReadOnly = True
        Me.Column19.Width = 159
        '
        'Column20
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column20.DefaultCellStyle = DataGridViewCellStyle4
        Me.Column20.HeaderText = "Time Start"
        Me.Column20.Name = "Column20"
        Me.Column20.ReadOnly = True
        Me.Column20.Width = 160
        '
        'Column21
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column21.DefaultCellStyle = DataGridViewCellStyle5
        Me.Column21.HeaderText = "Time Finished"
        Me.Column21.Name = "Column21"
        Me.Column21.ReadOnly = True
        Me.Column21.Width = 159
        '
        'Column24
        '
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column24.DefaultCellStyle = DataGridViewCellStyle6
        Me.Column24.HeaderText = "Confirmed by"
        Me.Column24.Name = "Column24"
        Me.Column24.ReadOnly = True
        Me.Column24.Width = 159
        '
        'Column22
        '
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column22.DefaultCellStyle = DataGridViewCellStyle7
        Me.Column22.HeaderText = "Remarks"
        Me.Column22.Name = "Column22"
        Me.Column22.ReadOnly = True
        Me.Column22.Width = 160
        '
        'Column23
        '
        Me.Column23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column23.DefaultCellStyle = DataGridViewCellStyle8
        Me.Column23.HeaderText = "Logistics Comment"
        Me.Column23.Name = "Column23"
        Me.Column23.ReadOnly = True
        Me.Column23.Width = 111
        '
        'viewtripinfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1018, 671)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "viewtripinfo"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Trip Information"
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.grddispatch, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.grdtrans, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblid As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txttype As System.Windows.Forms.TextBox
    Friend WithEvents txtplate As System.Windows.Forms.TextBox
    Friend WithEvents txtdel As System.Windows.Forms.TextBox
    Friend WithEvents txtmodify As System.Windows.Forms.TextBox
    Friend WithEvents txtdatemod As System.Windows.Forms.TextBox
    Friend WithEvents txtcreated As System.Windows.Forms.TextBox
    Friend WithEvents txtdatecr As System.Windows.Forms.TextBox
    Friend WithEvents txtetd As System.Windows.Forms.TextBox
    Friend WithEvents txtdes As System.Windows.Forms.TextBox
    Friend WithEvents txtorigin As System.Windows.Forms.TextBox
    Friend WithEvents txthelper As System.Windows.Forms.TextBox
    Friend WithEvents txtdriver As System.Windows.Forms.TextBox
    Friend WithEvents grdtrans As System.Windows.Forms.DataGridView
    Friend WithEvents grddispatch As System.Windows.Forms.DataGridView
    Friend WithEvents lbltripnum As System.Windows.Forms.Label
    Friend WithEvents txtrems As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtcancel As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtcanby As System.Windows.Forms.TextBox
    Friend WithEvents txtdatecan As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ViewEditReferenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column27 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column28 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column25 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column26 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column29 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column30 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents chkpick As System.Windows.Forms.CheckBox
    Friend WithEvents lblpick As System.Windows.Forms.Label
    Friend WithEvents Column19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column24 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column23 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
