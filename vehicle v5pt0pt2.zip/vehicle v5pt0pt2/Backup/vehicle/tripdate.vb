﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class tripdate
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public datecnf As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub tripdate_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        datepick.CustomFormat = "yyyy/MM/dd"
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try
            'check if naka departure na bago isave
            'check sa db kung cancel tripsum
            sql = "Select * from tbltripsum where tripnum='" & lbltripnum.Text & "' and (status='3' or status='2')"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("status") = 3 Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip# " & lbltripnum.Text & " is already cancelled.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip# " & lbltripnum.Text & " is already completed.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            'check sa tripdispatchsum kung null pa yung timedep
            sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum.Text & "' and timedep is not Null"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum.Text & " is already dispatched.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            datecnf = False
            confirmsave.GroupBox1.Text = login.neym
            confirmsave.ShowDialog()
            If datecnf = True Then
                'change trip date
                sql = "Update tbltripsum set datepick='" & Format(datepick.Value, "yyyy/MM/dd") & "' where tripnum='" & lbltripnum.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")
                Me.Close()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class