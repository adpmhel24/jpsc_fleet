﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class whseconn
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim stat As String
    Public whsecnf As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        '/File.Create(Application.StartupPath & "\SomeFileName.txt").Dispose()
        Dim filename As String = "connectionstring" & Trim(txtcode.Text.ToLower)

        Dim fileloc As String = Application.StartupPath & "\" & filename & ".txt"

        If System.IO.File.Exists(fileloc) = True Then

            Dim objWriter As New System.IO.StreamWriter(fileloc)
            Dim content As String = "Data Source=" & Trim(txtip.Text) & ",1433;Network Library=DBMSSOCN;Initial Catalog=vehicledb;User ID=" & Trim(txtuser.Text) & ";Password=" & Trim(txtpass.Text) & ";"

            objWriter.Write(content)
            objWriter.Close()
            '/MessageBox.Show("Text updated to file")

        Else
            File.Create(Application.StartupPath & "\" & filename & ".txt").Dispose()
            Dim objWriter As New System.IO.StreamWriter(fileloc)
            Dim content As String = "Data Source=" & Trim(txtip.Text) & ",1433;Network Library=DBMSSOCN;Initial Catalog=vehicledb;User ID=" & Trim(txtuser.Text) & ";Password=" & Trim(txtpass.Text) & ";"

            objWriter.Write(content)
            objWriter.Close()
            '/MessageBox.Show("Text written to file")
        End If

    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try

        Catch ex As Exception

        End Try
    End Sub
End Class