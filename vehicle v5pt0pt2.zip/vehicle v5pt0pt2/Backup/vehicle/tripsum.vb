﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Windows.Forms
Imports CrystalDecisions.ReportSource
Imports System.Drawing.Printing
Imports System.ComponentModel
Imports Excel = Microsoft.Office.Interop.Excel

Public Class tripsum
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public clickbtn As String = ""
    Dim selectedrow As Integer, gridsql As String = ""

    Private threadEnabled As Boolean, threadEnabledsteps As Boolean, threadEnableddestin As Boolean
    Private backgroundWorker As BackgroundWorker
    Private backgroundWorkersteps As BackgroundWorker
    Private backgroundWorkerdestin As BackgroundWorker

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub tripdispatchsum_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated

    End Sub

    Private Sub tripdispatchsum_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim a As String = MsgBox("Are you sure you want to close?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            'Stop background operation
            backgroundWorker.CancelAsync()
            backgroundWorkersteps.CancelAsync()
            backgroundWorkerdestin.CancelAsync()
            '/moduless.Show()
            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub tripdispatchsum_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        datefrom.CustomFormat = "yyyy/MM/dd"
        dateto.CustomFormat = "yyyy/MM/dd"
        datefrom.MaxDate = Date.Now.AddDays(+7)
        dateto.MinDate = datefrom.Value

        grdtrip.Columns(7).Frozen = True

        lbltrip.Text = login.whsecode

        plate()
        driver()
        vtype()
        vcustomer()
        viewall()
    End Sub

    Public Sub vcustomer()
        Try
            cmbcus.Items.Clear()
            cmbcus.Items.Add("")

            sql = "Select * from tblcustomer order by customer"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbcus.Items.Add(dr1("customer"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub vtype()
        Try
            cmbtype.Items.Clear()
            cmbtype.Items.Add("")

            sql = "Select * from tblvtype order by vtype"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read

                cmbtype.Items.Add(dr1("vtype"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub plate()
        Try
            cmbplate.Items.Clear()
            cmbplate.Items.Add("")
            Dim plnum As String = ""

            sql = "Select * from tblgeneral"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                If dr1("platenum") = "" And dr1("vplate") <> "" Then
                    plnum = dr1("vplate")
                ElseIf dr1("platenum") = "" And dr1("vplate") = "" And dr1("csticker") <> "" Then
                    plnum = dr1("csticker")
                Else
                    plnum = dr1("platenum")
                End If

                cmbplate.Items.Add(plnum)
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub viewall()
        Try
            Me.Cursor = Cursors.WaitCursor
            chkhide.Checked = False

            clickbtn = "Pending"

            gridsql = "Select tbltripsum.*,"
            gridsql = gridsql & " vtype from tbltripsum RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
            gridsql = gridsql & " where tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by tbltripsum.datepick"

            grdtrip.Rows.Clear()

            backgroundWorker = New BackgroundWorker()
            backgroundWorker.WorkerSupportsCancellation = True
            backgroundWorkersteps = New BackgroundWorker()
            backgroundWorkersteps.WorkerSupportsCancellation = True
            backgroundWorkerdestin = New BackgroundWorker()
            backgroundWorkerdestin.WorkerSupportsCancellation = True

            backgroundWorker = New BackgroundWorker()
            AddHandler backgroundWorker.DoWork, New DoWorkEventHandler(AddressOf backgroundWorker_DoWork)
            AddHandler backgroundWorker.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorker_Completed)
            AddHandler backgroundWorker.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorker_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            AddHandler backgroundWorkersteps.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkersteps_DoWork)
            AddHandler backgroundWorkersteps.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkersteps_Completed)
            AddHandler backgroundWorkersteps.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorkersteps_ProgressChanged)
            m_updateRowDelegate = New UpdateRowDelegate(AddressOf UpdateDGVRow)

            AddHandler backgroundWorkerdestin.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkerdestin_DoWork)
            AddHandler backgroundWorkerdestin.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkerdestin_Completed)
            AddHandler backgroundWorkerdestin.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorkerdestin_ProgressChanged)
            m_destinRowDelegate = New destinRowDelegate(AddressOf destinDGVRow)

            If Not backgroundWorker.IsBusy Then
                backgroundWorker.WorkerReportsProgress = True
                backgroundWorker.WorkerSupportsCancellation = True
                backgroundWorker.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub backgroundWorker_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabled = True
        
        Dim rowcount As Integer = 0, i As Integer = 0
        
        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If
        cmd = New SqlCommand(gridsql, connection)
        Dim drx As SqlDataReader = cmd.ExecuteReader
        While drx.Read
            Dim actualdis As Double = drx("odoend") - drx("odoactual")
            Dim totaldis As Double = drx("diswith") + drx("diswout")
            Dim vardis As Double = actualdis - totaldis

            Dim dieselused As Double = (drx("dieselactual") + drx("podiesel") + drx("addpo") + drx("postaddpo")) - drx("dieselend")
            Dim vardiesel As Double = dieselused - drx("dshould")

            Dim tdep As String = ""
            If Not IsDBNull(drx("timedep")) = True Then
                tdep = Format(drx("timedep"), "yyyy/MM/dd HH:mm")
            End If

            Dim tarr As String = ""
            If Not IsDBNull(drx("timearr")) = True Then
                tarr = Format(drx("timearr"), "yyyy/MM/dd HH:mm")
            End If

            If grdtrip.InvokeRequired Then
                grdtrip.Invoke(m_addRowDelegate, drx("tripsumid"), drx("datepick"), drx("tripnum"), drx("platenum"), drx("vtype"), drx("driver"), drx("helper").ToString, drx("origin"), drx("etd"), tdep, tarr, drx("odostart"), drx("odoactual"), drx("odoend"), actualdis, drx("diswith"), drx("diswout"), totaldis, vardis, drx("dshould"), drx("dieselbeg"), drx("dieselactual"), drx("podiesel"), drx("addpo") + drx("postaddpo"), drx("dieselend"), dieselused, vardiesel, drx("loadscale"), drx("repair"), drx("rescue"), drx("remarks"), drx("status"), drx("datecreated"), drx("createdby"), drx("datemodified"), drx("modifiedby"), drx("status"), i)
            Else
                AddDGVRow(drx("tripsumid"), drx("datepick"), drx("tripnum"), drx("platenum"), drx("vtype"), drx("driver"), drx("helper").ToString, drx("origin"), drx("etd"), tdep, tarr, drx("odostart"), drx("odoactual"), drx("odoend"), actualdis, drx("diswith"), drx("diswout"), totaldis, vardis, drx("dshould"), drx("dieselbeg"), drx("dieselactual"), drx("podiesel"), drx("addpo") + drx("postaddpo"), drx("dieselend"), dieselused, vardiesel, drx("loadscale"), drx("repair"), drx("rescue"), drx("remarks"), drx("status"), drx("datecreated"), drx("createdby"), drx("datemodified"), drx("modifiedby"), drx("status"), i)
            End If
            i += 1
            backgroundWorker.ReportProgress(i) '/ idivide kung ilan ang total
            '/System.Threading.Thread.Sleep(50)
        End While
        drx.Dispose()
        cmd.Dispose()
        connection.Close()
    End Sub

    Delegate Sub AddRowDelegate(ByVal v0 As Object, ByVal v1 As Object, ByVal v2 As Object, ByVal v3 As Object, ByVal v4 As Object, ByVal v5 As Object, ByVal v6 As Object, ByVal v7 As Object, ByVal v8 As Object, ByVal v9 As Object, ByVal v10 As Object, ByVal v11 As Object, ByVal v12 As Object, ByVal v13 As Object, ByVal v14 As Object, ByVal v15 As Object, ByVal v16 As Object, ByVal v17 As Object, ByVal v18 As Object, ByVal v19 As Object, ByVal v20 As Object, ByVal v21 As Object, ByVal v22 As Object, ByVal v23 As Object, ByVal v24 As Object, ByVal v25 As Object, ByVal v26 As Object, ByVal v27 As Object, ByVal v28 As Object, ByVal v29 As Object, ByVal v30 As Object, ByVal v31 As Object, ByVal v32 As Object, ByVal v33 As Object, ByVal v34 As Object, ByVal v35 As Object, ByVal v36stat As Object, ByVal vrow As Object)
    Private m_addRowDelegate As AddRowDelegate

    Private Sub AddDGVRow(ByVal v0 As Object, ByVal v1 As Object, ByVal v2 As Object, ByVal v3 As Object, ByVal v4 As Object, ByVal v5 As Object, ByVal v6 As Object, ByVal v7 As Object, ByVal v8 As Object, ByVal v9 As Object, ByVal v10 As Object, ByVal v11 As Object, ByVal v12 As Object, ByVal v13 As Object, ByVal v14 As Object, ByVal v15 As Object, ByVal v16 As Object, ByVal v17 As Object, ByVal v18 As Object, ByVal v19 As Object, ByVal v20 As Object, ByVal v21 As Object, ByVal v22 As Object, ByVal v23 As Object, ByVal v24 As Object, ByVal v25 As Object, ByVal v26 As Object, ByVal v27 As Object, ByVal v28 As Object, ByVal v29 As Object, ByVal v30 As Object, ByVal v31 As Object, ByVal v32 As Object, ByVal v33 As Object, ByVal v34 As Object, ByVal v35 As Object, ByVal v36stat As Object, ByVal vrow As Integer)
        If threadEnabled = True Then
            If grdtrip.InvokeRequired Then
                grdtrip.BeginInvoke(New AddRowDelegate(AddressOf AddDGVRow), v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23, v24, v25, v26, v27, v28, v29, v30, v31, v32, v33, v34, v35, v36stat, vrow)
            Else
                grdtrip.Rows.Add(v0, v1, v2, v3, v4, v5, v6, v7, "", v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23, v24, v25, v26, v27, v28, v29, v30, v31, v32, v33, v34, v35)
                grdtrip.Rows(vrow).Cells(0).Tag = v36stat
            End If
        End If
    End Sub

    Private Sub backgroundWorker_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        '/ProgressBar1.Visible = False
        If Not backgroundWorker.IsBusy Then
            backgroundWorkersteps.WorkerReportsProgress = True
            backgroundWorkersteps.WorkerSupportsCancellation = True
            backgroundWorkersteps.RunWorkerAsync()
        End If
    End Sub

    Private Sub backgroundWorker_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label12.Text = e.ProgressPercentage.ToString() & "% complete"
        lblloading.Visible = True
        Panel1.Enabled = False
        pgb1.Style = ProgressBarStyle.Marquee
        pgb1.Visible = True
        pgb1.Minimum = 0
    End Sub

    Private Sub backgroundWorkersteps_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabledsteps = True
        '//dito ilalagay yung select statement
        For Each row As DataGridViewRow In grdtrip.Rows
            Dim whatstep As String = "ON QUEUE"
            Dim des As String = ""
            Dim savedraftorstart As String = ""

            sql = "Select * from tbldispatchsum where tripnum='" & grdtrip.Rows(row.Index).Cells(2).Value & "'"
            Dim connection As SqlConnection
            connection = New SqlConnection
            connection.ConnectionString = strconn
            If connection.State <> ConnectionState.Open Then
                connection.Open()
            End If
            Dim cmdxx As SqlCommand = New SqlCommand(sql, connection)
            Dim drxx As SqlDataReader = cmdxx.ExecuteReader
            If drxx.Read Then
                whatstep = "On Queue"

                If drxx("step1") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp1").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp1").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp1") & " ( " & drxx("datestp1").ToString & " )"
                        whatstep = "In Step 1"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp1")) = False Or IsDBNull(drxx("startpreby")) = False Or IsDBNull(drxx("startpre")) = False Then
                        whatstep = "In Step 1"
                    End If
                End If

                If drxx("step2") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp2").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp2").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp2") & " ( " & drxx("datestp2").ToString & " )"
                        whatstep = "In Step 2"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp2")) = False Or IsDBNull(drxx("startdieselby")) = False Or IsDBNull(drxx("startdiesel")) = False Then
                        whatstep = "In Step 2"
                    End If
                End If

                If drxx("step3") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp3").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp3").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp3") & " ( " & drxx("datestp3").ToString & " )"
                        whatstep = "In Step 3"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp3")) = False Or IsDBNull(drxx("startloadby")) = False Or IsDBNull(drxx("startload")) = False Then
                        whatstep = "In Step 3"
                    End If
                End If

                If drxx("step4") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp4").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp4").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp4") & " ( " & drxx("datestp4").ToString & " )"
                        whatstep = "Released Documents"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp4")) = False Or IsDBNull(drxx("startdocby")) = False Or IsDBNull(drxx("startdoc")) = False Then
                        whatstep = "Released Documents"
                    End If
                End If

                If drxx("step5") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp5").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                        If IsDBNull(drxx("timedep")) = False Then
                            whatstep = "Dispatched"
                        End If
                    ElseIf drxx("namestp5").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp5") & " ( " & drxx("datestp5").ToString & " )"
                        whatstep = "Released Petty Cash"
                        If IsDBNull(drxx("timedep")) = False Then
                            whatstep = "Dispatched"
                        End If
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp5")) = False Or IsDBNull(drxx("startcashby")) = False Or IsDBNull(drxx("startcash")) = False Then
                        whatstep = "Released Petty Cash"
                    End If
                End If

                If drxx("step6") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp6").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp6").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp6") & " ( " & drxx("datestp6").ToString & " )"
                        whatstep = "Returned to Whse"
                    End If
                End If

                If drxx("step7") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp7").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp7").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp7") & " ( " & drxx("datestp7").ToString & " )"
                        whatstep = "Returned to Whse"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp7")) = False Or IsDBNull(drxx("startreturnby")) = False Or IsDBNull(drxx("startreturn")) = False Then
                        whatstep = "Returned to Whse"
                    End If
                End If

                If drxx("step8") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp8").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp8").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp8") & " ( " & drxx("datestp8").ToString & " )"
                        whatstep = "Returned to Whse"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp8")) = False Or IsDBNull(drxx("startpostby")) = False Or IsDBNull(drxx("startpost")) = False Then
                        whatstep = "Returned to Whse"
                    End If
                End If

                If drxx("step9") = 1 Then

                    If drxx("namestp9").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp9").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp9") & " ( " & drxx("datestp9").ToString & " )"
                    Else
                        '/des = ""
                    End If

                    whatstep = "Completed"
                Else
                    If IsDBNull(drxx("sdeytstp9")) = False Or IsDBNull(drxx("startrecordby")) = False Or IsDBNull(drxx("startrecord")) = False Then
                        whatstep = "In Step 9"
                    End If
                End If

            End If
            drxx.Dispose()
            cmdxx.Dispose()
            connection.Close()

            Dim i As Integer = 0
            Dim rowin As Object = row.Index
            UpdateDGVRow(rowin, whatstep)

            backgroundWorkersteps.ReportProgress(i * 100 / 155) '/ idivide kung ilan ang total
            '/System.Threading.Thread.Sleep(100)
        Next
    End Sub

    Delegate Sub UpdateRowDelegate(ByVal valueindex As Object, ByVal value1 As Object)
    Private m_updateRowDelegate As UpdateRowDelegate

    Private Sub UpdateDGVRow(ByVal rowin As String, ByVal whatstep As String)
        If threadEnabledsteps = True Then
            If grdtrip.InvokeRequired Then
                grdtrip.BeginInvoke(New UpdateRowDelegate(AddressOf UpdateDGVRow), rowin, whatstep)
            Else
                grdtrip.Rows(rowin).Cells(32).Value = whatstep
            End If
        End If
    End Sub

    Private Sub backgroundWorkersteps_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label2.Text = e.ProgressPercentage.ToString() & "% complete"
    End Sub

    Private Sub backgroundWorkersteps_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        If Not backgroundWorkersteps.IsBusy Then
            backgroundWorkerdestin.WorkerReportsProgress = True
            backgroundWorkerdestin.WorkerSupportsCancellation = True
            backgroundWorkerdestin.RunWorkerAsync() 'start ng select query
        End If
    End Sub

    Private Sub backgroundWorkerdestin_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnableddestin = True

        'destination
        For Each row As DataGridViewRow In grdtrip.Rows
            Dim temp As String = "", temptype As String = ""
            sql = "SELECT tblortrans.customer,tblortrans.transtype FROM tbltripitems RIGHT OUTER JOIN tblortrans ON tbltripitems.transnum=tblortrans.transnum"
            sql = sql & " where tbltripitems.tripnum='" & grdtrip.Rows(row.Index).Cells(2).Value & "' and tbltripitems.status<>'0' and tbltripitems.status<>'3'"
            Dim connection As SqlConnection
            connection = New SqlConnection
            connection.ConnectionString = strconn
            If connection.State <> ConnectionState.Open Then
                connection.Open()
            End If
            cmd = New SqlCommand(sql, connection)
            Dim dr11x As SqlDataReader = cmd.ExecuteReader
            While dr11x.Read
                If temp = "" Then
                    temp = temp & dr11x("customer")
                Else
                    temp = temp & " / " & dr11x("customer")
                End If

                If dr11x("transtype").ToString.Contains("PICKUP") Then
                    Dim inSql As String = dr11x("transtype").ToString
                    Dim lastPart As String
                    Dim fromStart As Integer
                    Dim firstpart As String

                    fromStart = inSql.IndexOf("FRM ") + 4

                    firstpart = inSql.Substring(0, fromStart - 4)
                    temptype = Trim(firstpart)

                    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

                    temptype = lastPart & " "
                End If
            End While
            dr11x.Dispose()
            cmd.Dispose()
            connection.Close()

            Dim destination As String = ""
            If temp = "" Then
                temp = "Taxi"
                destination = temp
            Else
                If temptype = "" Then
                    destination = temp
                Else
                    destination = "p/up " & temptype & "/ " & temp
                End If
            End If

            Dim rowin As Object = row.Index
            If grdtrip.InvokeRequired Then
                destinDGVRow(rowin, destination)
            End If
        Next
    End Sub

    Delegate Sub destinRowDelegate(ByVal value0 As Object, ByVal value1 As Object)
    Private m_destinRowDelegate As destinRowDelegate

    Private Sub destinDGVRow(ByVal rowin As Integer, ByVal val1 As String)
        If threadEnableddestin = True Then
            If grdtrip.InvokeRequired Then
                grdtrip.BeginInvoke(New destinRowDelegate(AddressOf destinDGVRow), rowin, val1)
            Else
                grdtrip.Rows(rowin).Cells(8).Value = val1
            End If
        End If
    End Sub

    Private Sub backgroundWorkerdestin_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        Me.Cursor = Cursors.Default
        pgb1.Visible = False
        pgb1.Style = ProgressBarStyle.Blocks
        lblloading.Visible = False
        Panel1.Enabled = True
        If e.Error IsNot Nothing Then
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            If grdtrip.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            Else
                If Trim(txttrip.Text) = "" Then
                    MsgBox("Loading data completed.", MsgBoxStyle.Information, "")
                End If
            End If
        End If
    End Sub

    Private Sub backgroundWorkerdestin_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label3.Text = e.ProgressPercentage.ToString() & "% complete"
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        txttrip.Text = ""
        cmbplate.Enabled = True
        cmbtype.Enabled = True
        cmbcus.Enabled = True
        cmbdriver.Enabled = True
        datefrom.Enabled = True
        dateto.Enabled = True
        cmbplate.Text = ""
        cmbtype.Text = ""
        cmbcus.Text = ""
        cmbdriver.Text = ""
        datefrom.Value = datefrom.MaxDate
        viewall()
    End Sub

    Private Sub grdtrip_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrip.CellClick

    End Sub

    Private Sub grdtrip_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrip.CellContentClick
        Try
            Me.Cursor = Cursors.WaitCursor

            'link
            If e.ColumnIndex = 2 And e.RowIndex > -1 Then

                Dim cell As DataGridViewCell = grdtrip.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrip.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdtrip.RowCount <> 0 Then
                    If grdtrip.Item(2, grdtrip.CurrentRow.Index).Value IsNot Nothing Then
                        'if taxi
                        If grdtrip.Item(8, grdtrip.CurrentRow.Index).Value IsNot Nothing And grdtrip.Item(8, grdtrip.CurrentRow.Index).Value = "Taxi" Then
                            Me.Cursor = Cursors.Default
                            MsgBox("No Transactions. Taxi only.", MsgBoxStyle.Information, "")
                            Me.Cursor = Cursors.Default
                            Exit Sub
                        End If

                        'viewtrans.txttrans.Text = grdtrip.Item(1, grdtrip.CurrentRow.Index).Value
                        'populate grdtrans
                        viewtrans.Text = "View Transactions (" & grdtrip.Item(2, grdtrip.CurrentRow.Index).Value.ToString & ")"
                        viewtrans.lbltripnum.Text = grdtrip.Item(2, grdtrip.CurrentRow.Index).Value.ToString
                        viewtrans.grdtrans.Rows.Clear()
                        sql = "Select * from tbltripitems where tripnum='" & grdtrip.Item(2, grdtrip.CurrentRow.Index).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        While dr.Read
                            viewtrans.grdtrans.Rows.Add(dr("transnum"))
                        End While
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        viewtrans.grouptrans.Visible = True
                        viewtrans.ShowDialog()
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbplate_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbplate.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbplate_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbplate.Leave
        getdriver()
    End Sub

    Public Sub getdriver()
        Try
            If Trim(cmbplate.Text) <> "" Then
                If Not cmbplate.Items.Contains(Trim(cmbplate.Text.ToUpper)) Then
                    cmbplate.Text = ""
                    cmbtype.Text = ""
                    cmbdriver.Text = ""
                Else
                    sql = "Select * from tblgeneral where status='1'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    While dr.Read
                        Dim plnum As String = ""
                        If dr("platenum") = "" And dr("vplate") <> "" Then
                            plnum = dr("vplate")
                        ElseIf dr("platenum") = "" And dr("vplate") = "" And dr("csticker") <> "" Then
                            plnum = dr("csticker")
                        Else
                            plnum = dr("platenum")
                        End If
                        If plnum = Trim(cmbplate.Text.ToUpper) Then
                            cmbplate.SelectedItem = plnum
                            'cmbdriver.SelectedItem = dr("driver")
                            cmbtype.SelectedItem = dr("vtype")
                        End If
                    End While
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Else
                cmbdriver.SelectedItem = ""
                cmbplate.Text = ""
                cmbtype.Text = ""
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbplate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbplate.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789"
        Dim theText As String = cmbplate.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbplate.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbplate.Text.Length - 1
            Letter = cmbplate.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbplate.Text = theText
        cmbplate.Select(SelectionIndex - Change, 0)
    End Sub

    Public Sub driver()
        Try
            cmbdriver.Items.Clear()
            cmbdriver.Items.Add("")
            '/CType(Me.grdadd.Columns(5), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(5), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tbldriver order by driver"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbdriver.Items.Add(dr1("driver"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbdriver_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbdriver.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbdriver_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbdriver.Leave
        Try
            If Trim(cmbdriver.Text) <> "" Then

                sql = "Select * from tbldriver where driver='" & Trim(cmbdriver.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbdriver.SelectedItem = dr("driver")
                Else
                    cmbdriver.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

            Else
                cmbdriver.SelectedItem = ""
                cmbdriver.Text = ""
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub datefrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datefrom.ValueChanged
        dateto.MinDate = datefrom.Value
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            clickbtn = "Search"

            If Trim(txttrip.Text) <> "" Then
                sql = "Select tbltripsum.*, tblgeneral.vtype from tbltripsum RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
                sql = sql & " where tripnum='" & lbltrip.Text & txttrip.Text & "' and tbltripsum.whsename='" & login.whse & "'"
            ElseIf Trim(cmbcus.Text) <> "" Then
                sql = "SELECT tbltripsum.tripsumid, tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.helper, tbltripsum.origin, tbltripsum.etd, tbltripsum.datecreated, tbltripsum.createdby, tbltripsum.status, tbltripsum.datemodified, tbltripsum.modifiedby,tbltripsum.status,"
                sql = sql & " tbltripsum.odostart, tbltripsum.odoend, tbltripsum.odoactual, tbltripsum.diswith, tbltripsum.diswout, tbltripsum.dieselactual, tbltripsum.podiesel, tbltripsum.addpo, tbltripsum.postaddpo, tbltripsum.dieselbeg, tbltripsum.dieselend, tbltripsum.dshould, tbltripsum.timedep, tbltripsum.timearr, tblgeneral.vtype,"
                sql = sql & " tbltripsum.loadscale, tbltripsum.repair, tbltripsum.rescue, tbltripsum.remarks, tbltripsum.datecreated, tbltripsum.createdby"
                sql = sql & " FROM tbltripsum RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
                sql = sql & " RIGHT OUTER JOIN tbltripitems ON tbltripsum.tripnum=tbltripitems.tripnum"
                sql = sql & " RIGHT OUTER JOIN tblortrans ON tbltripitems.transnum=tblortrans.transnum "
                sql = sql & " where tbltripsum.datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and tbltripsum.datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "' and tbltripsum.whsename='" & login.whse & "' and tbltripitems.status<>'0' and tbltripitems.status<>'3'"
                If cmbplate.Text <> "" Then
                    sql = sql & " and tbltripsum.platenum='" & cmbplate.Text & "'"
                End If
                If cmbdriver.Text <> "" Then
                    sql = sql & " and tbltripsum.driver='" & cmbdriver.Text & "'"
                End If
                If cmbtype.Text <> "" Then
                    sql = sql & " and tblgeneral.vtype='" & cmbtype.Text & "'"
                End If
                If cmbcus.Text <> "" Then
                    sql = sql & " and tblortrans.customer='" & cmbcus.Text & "'"
                End If
                If chkhide.Checked = True Then
                    sql = sql & " and tbltripsum.status<>'3'"
                End If
                sql = sql & " Group by tbltripsum.tripsumid, tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.helper, tbltripsum.origin, tbltripsum.etd, tbltripsum.datecreated, tbltripsum.createdby, tbltripsum.status, tbltripsum.datemodified, tbltripsum.modifiedby, tbltripsum.status,"
                sql = sql & " tbltripsum.odostart, tbltripsum.odoend, tbltripsum.odoactual, tbltripsum.diswith, tbltripsum.diswout, tbltripsum.dieselactual, tbltripsum.podiesel, tbltripsum.addpo, tbltripsum.postaddpo, tbltripsum.dieselbeg, tbltripsum.dieselend, tbltripsum.dshould, tbltripsum.timedep, tbltripsum.timearr, tblgeneral.vtype,"
                sql = sql & " tbltripsum.loadscale, tbltripsum.repair, tbltripsum.rescue, tbltripsum.remarks, tbltripsum.datecreated, tbltripsum.createdby"
                sql = sql & " order by tbltripsum.datepick "
            Else
                If Trim(cmbplate.Text) = "" And Trim(cmbdriver.Text) = "" And Trim(cmbtype.Text) = "" And CDate(datefrom.Value) <> CDate(dateto.Value) Then
                    MsgBox("Invalid dates.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If

                'search with dates
                sql = "Select tbltripsum.*, vtype from tbltripsum RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
                sql = sql & " where tbltripsum.datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and tbltripsum.datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "' and tbltripsum.whsename='" & login.whse & "'"
                If cmbplate.Text <> "" Then
                    sql = sql & " and tbltripsum.platenum='" & cmbplate.Text & "'"
                End If
                If cmbdriver.Text <> "" Then
                    sql = sql & " and tbltripsum.driver='" & cmbdriver.Text & "'"
                End If
                If cmbtype.Text <> "" Then
                    sql = sql & " and tblgeneral.vtype='" & cmbtype.Text & "'"
                End If
                If chkhide.Checked = True Then
                    sql = sql & " and tbltripsum.status<>'3'"
                End If
                sql = sql & " order by tbltripsum.datepick"
            End If

            gridsql = sql

            grdtrip.Rows.Clear()

            lblloading.Visible = True
            Panel1.Enabled = False
            pgb1.Style = ProgressBarStyle.Marquee
            pgb1.Visible = True
            pgb1.Minimum = 0

            backgroundWorker = New BackgroundWorker()
            backgroundWorker.WorkerSupportsCancellation = True
            backgroundWorkersteps = New BackgroundWorker()
            backgroundWorkersteps.WorkerSupportsCancellation = True
            backgroundWorkerdestin = New BackgroundWorker()
            backgroundWorkerdestin.WorkerSupportsCancellation = True

            '/ProgressBar1.Style = ProgressBarStyle.Marquee
            AddHandler backgroundWorker.DoWork, New DoWorkEventHandler(AddressOf backgroundWorker_DoWork)
            AddHandler backgroundWorker.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorker_Completed)
            AddHandler backgroundWorker.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorker_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            AddHandler backgroundWorkersteps.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkersteps_DoWork)
            AddHandler backgroundWorkersteps.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkersteps_Completed)
            AddHandler backgroundWorkersteps.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorkersteps_ProgressChanged)
            m_updateRowDelegate = New UpdateRowDelegate(AddressOf UpdateDGVRow)

            AddHandler backgroundWorkerdestin.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkerdestin_DoWork)
            AddHandler backgroundWorkerdestin.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkerdestin_Completed)
            AddHandler backgroundWorkerdestin.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorkerdestin_ProgressChanged)
            m_destinRowDelegate = New destinRowDelegate(AddressOf destinDGVRow)

            If Not backgroundWorker.IsBusy Then
                backgroundWorker.WorkerReportsProgress = True
                backgroundWorker.WorkerSupportsCancellation = True
                backgroundWorker.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrip_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles grdtrip.CellFormatting
        If e.ColumnIndex >= 12 And e.ColumnIndex <= 19 Then
            e.CellStyle.BackColor = Color.NavajoWhite
        ElseIf e.ColumnIndex >= 20 And e.ColumnIndex <= 27 Then
            e.CellStyle.BackColor = Color.Gold
        End If
    End Sub

    Private Sub grdtrip_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdtrip.CellMouseClick
        Try
            If grdtrip.RowCount = 0 Then
                Me.Cursor = Cursors.Default
                Exit Sub
            End If
            grdtrip.BeginEdit(True)
            If e.Button = Windows.Forms.MouseButtons.Right And e.ColumnIndex > -1 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdtrip.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrip.CurrentCell = cell
                If grdtrip.SelectedCells.Count = 1 Or grdtrip.SelectedRows.Count = 1 Then
                    If login.neym = "Guard" Or login.neym = "Checker" Or login.neym = "Diesel Controller" Or login.neym = "Inspector" Then
                        If login.neym = "Inspector" And login.whse = "Milaor" And grdtrip.Rows(e.RowIndex).Cells(8).Value = "Taxi" Then

                        Else
                            Me.Cursor = Cursors.Default
                            MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                            Exit Sub
                        End If
                    End If

                    If e.ColumnIndex = 31 Then
                        ' UpdateRemarksToolStripMenuItem.Visible = True
                    Else
                        ' UpdateRemarksToolStripMenuItem.Visible = False
                    End If

                    selectedrow = e.RowIndex
                    Me.ContextMenuStrip1.Show(Cursor.Position)
                    toolstripitems()
                End If
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub toolstripitems()
        
    End Sub

    Private Sub txttrip_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttrip.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btnsearch.PerformClick()
        End If
    End Sub

    Private Sub txttrip_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttrip.TextChanged
        Dim charactersDisallowed As String = "0123456789-"
        Dim theText As String = txttrip.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txttrip.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txttrip.Text.Length - 1
            Letter = txttrip.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txttrip.Text = theText
        txttrip.Select(SelectionIndex - Change, 0)

        Dim str As String
        str = txttrip.Text
        If str.Length <> 0 Then
            Dim answer As Char
            answer = str.Substring(0, 1)
            If answer = "-" Then
                str = str.Substring(1, str.Length - 1)
                txttrip.Text = str
            End If
        End If

        If Trim(txttrip.Text) <> "" Then
            cmbplate.Enabled = False
            cmbtype.Enabled = False
            cmbcus.Enabled = False
            cmbdriver.Enabled = False
            datefrom.Enabled = False
            dateto.Enabled = False
        Else
            cmbplate.Enabled = True
            cmbtype.Enabled = True
            cmbcus.Enabled = True
            cmbdriver.Enabled = True
            datefrom.Enabled = True
            dateto.Enabled = True
        End If
    End Sub

    Private Sub EditTripToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditTripToolStripMenuItem.Click
        Try
            If login.neym = "Guard" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Completed" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already completed.", MsgBoxStyle.Information, "")
                Exit Sub
            ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Cancelled" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already cancelled.", MsgBoxStyle.Information, "")
                Exit Sub
            Else
                'check sa db kung cancel tripsum
                sql = "Select * from tbltripsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "' and status='3'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip# " & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & " is already cancelled.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                Dim whatstep As String = ""
                'status
                sql = "Select * from tbldispatchsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "'"
                connect()
                Dim cmdxx As SqlCommand = New SqlCommand(sql, conn)
                Dim drxx As SqlDataReader = cmdxx.ExecuteReader
                If drxx.Read Then
                    whatstep = "On Queue"

                    If drxx("step1") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp1").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp1").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp1") & " ( " & drxx("datestp1").ToString & " )"
                            whatstep = "In Step 1"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp1")) = False Or IsDBNull(drxx("startpreby")) = False Or IsDBNull(drxx("startpre")) = False Then
                            whatstep = "In Step 1"
                        End If
                    End If

                    If drxx("step2") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp2").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp2").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp2") & " ( " & drxx("datestp2").ToString & " )"
                            whatstep = "In Step 2"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp2")) = False Or IsDBNull(drxx("startdieselby")) = False Or IsDBNull(drxx("startdiesel")) = False Then
                            whatstep = "In Step 2"
                        End If
                    End If

                    If drxx("step3") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp3").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp3").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp3") & " ( " & drxx("datestp3").ToString & " )"
                            whatstep = "In Step 3"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp3")) = False Or IsDBNull(drxx("startloadby")) = False Or IsDBNull(drxx("startload")) = False Then
                            whatstep = "In Step 3"
                        End If
                    End If

                    If drxx("step4") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp4").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp4").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp4") & " ( " & drxx("datestp4").ToString & " )"
                            whatstep = "Released Documents"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp4")) = False Or IsDBNull(drxx("startdocby")) = False Or IsDBNull(drxx("startdoc")) = False Then
                            whatstep = "Released Documents"
                        End If
                    End If

                    If drxx("step5") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp5").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                            If IsDBNull(drxx("timedep")) = False Then
                                whatstep = "Dispatched"
                            End If
                        ElseIf drxx("namestp5").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp5") & " ( " & drxx("datestp5").ToString & " )"
                            whatstep = "Released Petty Cash"
                            If IsDBNull(drxx("timedep")) = False Then
                                whatstep = "Dispatched"
                            End If
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp5")) = False Or IsDBNull(drxx("startcashby")) = False Or IsDBNull(drxx("startcash")) = False Then
                            whatstep = "Released Petty Cash"
                        End If
                    End If

                    If drxx("step6") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp6").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp6").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp6") & " ( " & drxx("datestp6").ToString & " )"
                            whatstep = "Returned to Whse"
                        End If
                    End If

                    If drxx("step7") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp7").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp7").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp7") & " ( " & drxx("datestp7").ToString & " )"
                            whatstep = "Returned to Whse"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp7")) = False Or IsDBNull(drxx("startreturnby")) = False Or IsDBNull(drxx("startreturn")) = False Then
                            whatstep = "Returned to Whse"
                        End If
                    End If

                    If drxx("step8") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp8").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp8").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp8") & " ( " & drxx("datestp8").ToString & " )"
                            whatstep = "Returned to Whse"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp8")) = False Or IsDBNull(drxx("startpostby")) = False Or IsDBNull(drxx("startpost")) = False Then
                            whatstep = "Returned to Whse"
                        End If
                    End If

                    If drxx("step9") = 1 Then

                        If drxx("namestp9").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp9").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp9") & " ( " & drxx("datestp9").ToString & " )"
                        Else
                            '/des = ""
                        End If

                        whatstep = "Completed"
                    Else
                        If IsDBNull(drxx("sdeytstp9")) = False Or IsDBNull(drxx("startrecordby")) = False Or IsDBNull(drxx("startrecord")) = False Then
                            whatstep = "In Step 9"
                        End If
                    End If
                End If
                drxx.Dispose()
                cmdxx.Dispose()
                conn.Close()

                If whatstep = "On Queue" Then
                    tripedit.lblvtype.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(4).Value  'tinitignan kung JPSC or CUSTOMER OR TRUCKING
                    tripedit.plate()
                    tripedit.driver()
                    tripedit.helper()
                    tripedit.whse()
                    tripedit.datepick.Value = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(1).Value
                    tripedit.datepick.MinDate = tripedit.datepick.Value
                    tripedit.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                    tripedit.cmbplate.SelectedItem = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(3).Value.ToString
                    tripedit.cmbdriver.SelectedItem = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(5).Value.ToString
                    tripedit.cmbhelper.SelectedItem = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(6).Value.ToString
                    tripedit.cmbwhse.SelectedItem = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(7).Value.ToString
                    tripedit.txtetd.Text = CDate(grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(9).Value.ToString)
                    tripedit.txtrems.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(31).Value.ToString
                    'tripedit.grd.Columns(5).Visible = False
                    tripedit.ShowDialog()

                    If clickbtn = "Search" Then
                        btnsearch.PerformClick()
                    Else
                        btnview.PerformClick()
                    End If
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already " & whatstep & ".", MsgBoxStyle.Information, "")
                End If
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ChangeTripDateToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangeTripDateToolStripMenuItem.Click
        Try
            'pwede lang mag change ng trip date kapag hindi pa nadedepartue
            If login.neym = "Guard" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Completed" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already completed.", MsgBoxStyle.Information, "")
                Exit Sub
            ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Cancelled" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already cancelled.", MsgBoxStyle.Information, "")
                Exit Sub
            Else
                'check sa db kung cancel tripsum
                sql = "Select * from tbltripsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "' and (status='3' or status='2')"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    If dr("status") = 3 Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Trip# " & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & " is already cancelled.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    Else
                        Me.Cursor = Cursors.Default
                        MsgBox("Trip# " & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & " is already completed.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                'check sa tripdispatchsum kung null pa yung timedep
                sql = "Select * from tbldispatchsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "' and timedep is not Null"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip# " & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & " is already dispatched.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                'change trip date
                tripdate.lblplate.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(3).Value.ToString
                tripdate.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                Dim dcreate As Date = CDate(Format(grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(33).Value, "yyyy/MM/dd"))
                tripdate.datepick.MinDate = dcreate
                tripdate.datepick.Value = CDate(grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(1).Value)
                tripdate.ShowDialog()

                If clickbtn = "Search" Then
                    btnsearch.PerformClick()
                Else
                    btnview.PerformClick()
                End If
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub CancelTripToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelTripToolStripMenuItem.Click
        'view list of transaction select what transaction is cancel
        
        Try
            If login.neym = "Guard" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Completed" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already completed.", MsgBoxStyle.Information, "")
                Exit Sub
            ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Cancelled" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already cancelled.", MsgBoxStyle.Information, "")
                Exit Sub
            Else
                'check sa db kung cancel tripsum
                sql = "Select * from tbltripsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "' and status='3'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip# " & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & " is already cancelled.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                Dim whatstep As String = ""
                'status
                sql = "Select * from tbldispatchsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "'"
                connect()
                Dim cmdxx As SqlCommand = New SqlCommand(sql, conn)
                Dim drxx As SqlDataReader = cmdxx.ExecuteReader
                If drxx.Read Then
                    whatstep = "On Queue"

                    If drxx("step1") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp1").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp1").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp1") & " ( " & drxx("datestp1").ToString & " )"
                            whatstep = "In Step 1"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp1")) = False Or IsDBNull(drxx("startpreby")) = False Or IsDBNull(drxx("startpre")) = False Then
                            whatstep = "In Step 1"
                        End If
                    End If

                    If drxx("step2") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp2").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp2").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp2") & " ( " & drxx("datestp2").ToString & " )"
                            whatstep = "In Step 2"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp2")) = False Or IsDBNull(drxx("startdieselby")) = False Or IsDBNull(drxx("startdiesel")) = False Then
                            whatstep = "In Step 2"
                        End If
                    End If

                    If drxx("step3") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp3").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp3").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp3") & " ( " & drxx("datestp3").ToString & " )"
                            whatstep = "In Step 3"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp3")) = False Or IsDBNull(drxx("startloadby")) = False Or IsDBNull(drxx("startload")) = False Then
                            whatstep = "In Step 3"
                        End If
                    End If

                    If drxx("step4") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp4").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp4").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp4") & " ( " & drxx("datestp4").ToString & " )"
                            whatstep = "Released Documents"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp4")) = False Or IsDBNull(drxx("startdocby")) = False Or IsDBNull(drxx("startdoc")) = False Then
                            whatstep = "Released Documents"
                        End If
                    End If

                    If drxx("step5") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp5").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                            If IsDBNull(drxx("timedep")) = False Then
                                whatstep = "Dispatched"
                            End If
                        ElseIf drxx("namestp5").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp5") & " ( " & drxx("datestp5").ToString & " )"
                            whatstep = "Released Petty Cash"
                            If IsDBNull(drxx("timedep")) = False Then
                                whatstep = "Dispatched"
                            End If
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp5")) = False Or IsDBNull(drxx("startcashby")) = False Or IsDBNull(drxx("startcash")) = False Then
                            whatstep = "Released Petty Cash"
                        End If
                    End If

                    If drxx("step6") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp6").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp6").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp6") & " ( " & drxx("datestp6").ToString & " )"
                            whatstep = "Returned to Whse"
                        End If
                    End If

                    If drxx("step7") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp7").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp7").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp7") & " ( " & drxx("datestp7").ToString & " )"
                            whatstep = "Returned to Whse"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp7")) = False Or IsDBNull(drxx("startreturnby")) = False Or IsDBNull(drxx("startreturn")) = False Then
                            whatstep = "Returned to Whse"
                        End If
                    End If

                    If drxx("step8") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp8").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp8").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp8") & " ( " & drxx("datestp8").ToString & " )"
                            whatstep = "Returned to Whse"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp8")) = False Or IsDBNull(drxx("startpostby")) = False Or IsDBNull(drxx("startpost")) = False Then
                            whatstep = "Returned to Whse"
                        End If
                    End If

                    If drxx("step9") = 1 Then

                        If drxx("namestp9").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp9").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp9") & " ( " & drxx("datestp9").ToString & " )"
                        Else
                            '/des = ""
                        End If

                        whatstep = "Completed"
                    Else
                        If IsDBNull(drxx("sdeytstp9")) = False Or IsDBNull(drxx("startrecordby")) = False Or IsDBNull(drxx("startrecord")) = False Then
                            whatstep = "In Step 9"
                        End If
                    End If
                End If
                drxx.Dispose()
                cmdxx.Dispose()
                conn.Close()

                If whatstep = "Returned to Whse" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already returned to whse.", MsgBoxStyle.Information, "")
                    'pwede mag return sa whse pero cancel yung transaction
                    '/tripcancel.lblreturn.Text = "Returned"
                    '/tripcancel.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                    '/tripcancel.lblvtype.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(4).Value.ToString
                    '/tripcancel.btncanceltrip.Enabled = False
                    '/tripcancel.btnremove.Enabled = True
                    '/tripcancel.btncancel.Enabled = True
                    '/tripcancel.btnreschedule.Enabled = True
                    '/tripcancel.ShowDialog()

                    'ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "On Queue" Then
                ElseIf whatstep <> "Completed" And whatstep <> "Returned to Whse" And whatstep <> "Dispatched" And whatstep <> "In Step 9" Then
                    tripcancel.lblreturn.Text = ""
                    tripcancel.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                    tripcancel.lblvtype.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(4).Value.ToString
                    tripcancel.btncanceltrip.Enabled = True
                    tripcancel.btnremove.Enabled = True
                    tripcancel.btncancel.Enabled = False
                    tripcancel.btnreschedule.Enabled = False
                    tripcancel.grdadd.Columns(1).Visible = False
                    tripcancel.btnremove.Visible = False
                    tripcancel.btncanceltrip.Visible = True
                    tripcancel.Text = "Cancel Trip"
                    tripcancel.ShowDialog()
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already " & whatstep & ".", MsgBoxStyle.Information, "")
                End If
            End If

            If clickbtn = "Search" Then
                btnsearch.PerformClick()
            Else
                btnview.PerformClick()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub RescueToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RescueToolStripMenuItem.Click
        'view list of transaction select what transaction is transfer or other
        'rescue parang edit trip pero pdeng pumili ng transaction na i tatransfer to 
        Try
            If login.neym = "Whse Accounting Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdtrip.SelectedCells.Count = 1 Or grdtrip.SelectedRows.Count = 1 Then
                If grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(30).Value.ToString = "Yes" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already rescued.", MsgBoxStyle.Information, "")
                    Exit Sub
                ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Completed" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already completed.", MsgBoxStyle.Information, "")
                    Exit Sub
                ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Cancelled" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already cancelled.", MsgBoxStyle.Information, "")
                    Exit Sub
                ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Returned to Whse" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already returned to whse.", MsgBoxStyle.Information, "")
                    'Exit Sub

                    '/triprescue.plate()
                    '/triprescue.driver()
                    '/triprescue.whse()
                    '/triprescue.newdatepick.Value = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(1).Value.ToString
                    '/triprescue.datepick.Value = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(1).Value.ToString
                    '/triprescue.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                    '/triprescue.txtplate.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(3).Value.ToString
                    '/triprescue.txtdriver.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(5).Value.ToString
                    '/triprescue.txtorigin.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(7).Value.ToString
                    '/triprescue.txtetd.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(9).Value.ToString
                    '/triprescue.txtrems.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(30).Value.ToString
                    '/triprescue.ShowDialog()

                ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Dispatched" Then 'available or in process

                    '/triprescue.plate()
                    '/triprescue.driver()
                    '/triprescue.whse()
                    '/triprescue.newdatepick.Value = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(1).Value.ToString
                    '/triprescue.datepick.Value = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(1).Value.ToString
                    '/triprescue.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                    '/triprescue.txtplate.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(3).Value.ToString
                    '/triprescue.txtdriver.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(5).Value.ToString
                    '/triprescue.txtorigin.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(7).Value.ToString
                    '/triprescue.txtetd.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(9).Value.ToString
                    '/triprescue.txtrems.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(30).Value.ToString
                    '/triprescue.ShowDialog()

                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is not yet dispatched.", MsgBoxStyle.Information, "")
                    Exit Sub
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select Only One", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub UpdateRemarksToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateRemarksToolStripMenuItem.Click
        triprems.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
        triprems.txtrems.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(31).Value.ToString
        triprems.ShowDialog()

        If clickbtn = "Search" Then
            btnsearch.PerformClick()
        Else
            btnview.PerformClick()
        End If
    End Sub

    Private Sub btnreport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreport.Click
        Try
            If grdtrip.Rows.Count <> 0 Then
                Me.Cursor = Cursors.Default
                tripsumprev.WindowState = FormWindowState.Maximized
                tripsumprev.ShowDialog()
            Else
                Me.Cursor = Cursors.Default
                MsgBox("No record found.", MsgBoxStyle.Critical, "")
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnexport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexport.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim objExcel As New Excel.Application
            Dim bkWorkBook As Excel.Workbook
            Dim shWorkSheet As Excel.Worksheet
            Dim misValue As Object = System.Reflection.Missing.Value


            Dim oldCI As System.Globalization.CultureInfo =System.Threading.Thread.CurrentThread.CurrentCulture
            System.Threading.Thread.CurrentThread.CurrentCulture =   New System.Globalization.CultureInfo("en-US")
            objExcel.Workbooks.Add()
            System.Threading.Thread.CurrentThread.CurrentCulture = oldCI


            Dim i As Integer
            Dim j As Integer

            Dim dfrom As String = Format(datefrom.Value, "MMMMddyyyy")
            Dim dto As String = Format(dateto.Value, "MMMMddyyyy")

            Dim daterange As String = dfrom & "_TO_" & dto
            Dim sfilename As String = login.whse & " Whse " & clickbtn & " Sched from " & daterange & ".xls"

            objExcel = New Excel.Application
            bkWorkBook = objExcel.Workbooks.Add
            shWorkSheet = CType(bkWorkBook.ActiveSheet, Excel.Worksheet)

            With shWorkSheet
                .Range("A1", misValue).EntireRow.Font.Bold = True
                .Range("A1:AF1").EntireRow.WrapText = True
                .Range("A1:AF" & grdtrip.RowCount + 1).HorizontalAlignment = -4108
                .Range("A1:AF" & grdtrip.RowCount + 1).VerticalAlignment = -4108
                .Range("A1:AF" & grdtrip.RowCount + 1).Font.Size = 10
                'Set Clipboard Copy Mode     
                grdtrip.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
                grdtrip.SelectAll()
                grdtrip.RowHeadersVisible = False

                'Get the content from Grid for Clipboard     
                'Dim str As String = TryCast(grdtrip.GetClipboardContent().GetData(DataFormats.UnicodeText), String)
                Dim str As String = grdtrip.GetClipboardContent().GetData(DataFormats.UnicodeText)

                'Set the content to Clipboard     
                Clipboard.SetText(str, TextDataFormat.UnicodeText) 'TextDataFormat.UnicodeText)

                'Identify and select the range of cells in Excel to paste the clipboard data.     
                .Range("A1:AF1", misValue).Select()

                'WIDTH
                .Range("A1:A" & grdtrip.RowCount + 1).ColumnWidth = 11

                .Range("B1:B" & grdtrip.RowCount + 1).ColumnWidth = 12
                .Range("C1:C" & grdtrip.RowCount + 1).ColumnWidth = 15
                .Range("D1:D" & grdtrip.RowCount + 1).ColumnWidth = 13
                .Range("E1:E" & grdtrip.RowCount + 1).ColumnWidth = 20
                .Range("H1:H" & grdtrip.RowCount + 1).ColumnWidth = 55
                .Range("I1:AC" & grdtrip.RowCount + 1).ColumnWidth = 15
                .Range("AD1:AF" & grdtrip.RowCount + 1).ColumnWidth = 18

                'Paste the clipboard data     
                .Paste()
                Clipboard.Clear()

            End With

            'format alignment
            'shWorkSheet.Range("D2", "D" & grdtrip.RowCount + 1).HorizontalAlignment = Excel.XlHAlign.xlHAlignRight
            For i = 0 To grdtrip.RowCount - 1
                'shWorkSheet.Cells(i + 2, 1) = grd.Rows(i).Cells(1).Value
                shWorkSheet.Range("A1").EntireRow.NumberFormat = "MM/dd/yyyy"
            Next

            'lagyan ng title na red door kit tska ung date na sakop ng report
            shWorkSheet.Range("A1").EntireRow.Insert()
            shWorkSheet.Range("A2").EntireRow.Insert()
            shWorkSheet.Range("A3").EntireRow.Insert()
            shWorkSheet.Cells(1, 1) = login.whse & " Warehouse"
            shWorkSheet.Cells(2, 1) = clickbtn & " Schedule from " & daterange
            shWorkSheet.Cells(1, 1).Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red)
            shWorkSheet.Range("A4").EntireRow.WrapText = True

            Me.Cursor = Cursors.Default

            '/shWorkSheet.Shapes.AddPicture("C:\xl_pic.JPG", Microsoft.Office.Core.MsoTriState.msoFalse, Microsoft.Office.Core.MsoTriState.msoCTrue, 50, 50, 300, 45)

            objExcel.Visible = False
            'objExcel.Application.DisplayAlerts = False

            Dim password As String = "AB123"
            'objExcel.ActiveWorkbook.SaveAs(Application.StartupPath & "sample.xls", FileFormat:=51, )
            '/bkWorkBook.SaveAs(Filename:=Application.StartupPath & "\template\" & sfilename, FileFormat:=51, Password:=password, CreateBackup:=False)
            bkWorkBook.SaveAs(Filename:=Application.StartupPath & "\template\" & sfilename, FileFormat:=51, CreateBackup:=False)

            bkWorkBook.Close(True, misValue, misValue)
            objExcel.Quit()

            'objExcel = Nothing

            releaseObject(bkWorkBook)
            releaseObject(shWorkSheet)
            releaseObject(objExcel)

            MessageBox.Show("Data Successfully Exported") ' & sfilename)
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As System.Runtime.InteropServices.COMException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " + ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub grdtrip_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grdtrip.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdtrip.Rows(e.RowIndex)
            '<== But this is the name assigned to it in the properties of the control
            If dgvRow.Cells(0).Tag = 3 Then 'step1
                dgvRow.DefaultCellStyle.BackColor = Color.DeepSkyBlue
            End If
        End If
    End Sub

    Private Sub grdtrip_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdtrip.SelectionChanged
        count()
    End Sub

    Public Sub count()
        Try
            lblcount.Text = "     Selected Rows Count: " & grdtrip.SelectedRows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub EditHelperToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditHelperToolStripMenuItem.Click
        Try
            If login.neym = "Whse Accounting Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            'check sa db kung cancel tripsum
            sql = "Select * from tbltripsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "' and status='3'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & " is already cancelled.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Dim whatstep As String = ""
            'status
            sql = "Select * from tbldispatchsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "'"
            connect()
            Dim cmdxx As SqlCommand = New SqlCommand(sql, conn)
            Dim drxx As SqlDataReader = cmdxx.ExecuteReader
            If drxx.Read Then
                whatstep = "On Queue"

                If drxx("step1") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp1").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp1").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp1") & " ( " & drxx("datestp1").ToString & " )"
                        whatstep = "In Step 1"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp1")) = False Or IsDBNull(drxx("startpreby")) = False Or IsDBNull(drxx("startpre")) = False Then
                        whatstep = "In Step 1"
                    End If
                End If

                If drxx("step2") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp2").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp2").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp2") & " ( " & drxx("datestp2").ToString & " )"
                        whatstep = "In Step 2"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp2")) = False Or IsDBNull(drxx("startdieselby")) = False Or IsDBNull(drxx("startdiesel")) = False Then
                        whatstep = "In Step 2"
                    End If
                End If

                If drxx("step3") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp3").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp3").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp3") & " ( " & drxx("datestp3").ToString & " )"
                        whatstep = "In Step 3"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp3")) = False Or IsDBNull(drxx("startloadby")) = False Or IsDBNull(drxx("startload")) = False Then
                        whatstep = "In Step 3"
                    End If
                End If

                If drxx("step4") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp4").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp4").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp4") & " ( " & drxx("datestp4").ToString & " )"
                        whatstep = "Released Documents"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp4")) = False Or IsDBNull(drxx("startdocby")) = False Or IsDBNull(drxx("startdoc")) = False Then
                        whatstep = "Released Documents"
                    End If
                End If

                If drxx("step5") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp5").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                        If IsDBNull(drxx("timedep")) = False Then
                            whatstep = "Dispatched"
                        End If
                    ElseIf drxx("namestp5").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp5") & " ( " & drxx("datestp5").ToString & " )"
                        whatstep = "Released Petty Cash"
                        If IsDBNull(drxx("timedep")) = False Then
                            whatstep = "Dispatched"
                        End If
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp5")) = False Or IsDBNull(drxx("startcashby")) = False Or IsDBNull(drxx("startcash")) = False Then
                        whatstep = "Released Petty Cash"
                    End If
                End If

                If drxx("step6") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp6").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp6").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp6") & " ( " & drxx("datestp6").ToString & " )"
                        whatstep = "Returned to Whse"
                    End If
                End If

                If drxx("step7") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp7").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp7").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp7") & " ( " & drxx("datestp7").ToString & " )"
                        whatstep = "Returned to Whse"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp7")) = False Or IsDBNull(drxx("startreturnby")) = False Or IsDBNull(drxx("startreturn")) = False Then
                        whatstep = "Returned to Whse"
                    End If
                End If

                If drxx("step8") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp8").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp8").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp8") & " ( " & drxx("datestp8").ToString & " )"
                        whatstep = "Returned to Whse"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp8")) = False Or IsDBNull(drxx("startpostby")) = False Or IsDBNull(drxx("startpost")) = False Then
                        whatstep = "Returned to Whse"
                    End If
                End If

                If drxx("step9") = 1 Then

                    If drxx("namestp9").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp9").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp9") & " ( " & drxx("datestp9").ToString & " )"
                    Else
                        '/des = ""
                    End If

                    whatstep = "Completed"
                Else
                    If IsDBNull(drxx("sdeytstp9")) = False Or IsDBNull(drxx("startrecordby")) = False Or IsDBNull(drxx("startrecord")) = False Then
                        whatstep = "In Step 9"
                    End If
                End If
            End If
            drxx.Dispose()
            cmdxx.Dispose()
            conn.Close()

            If whatstep <> "Completed" And whatstep <> "" Then
                triphelper.lblvtype.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(4).Value  'tinitignan kung JPSC or CUSTOMER OR TRUCKING
                triphelper.helper()
                triphelper.lblplate.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(3).Value.ToString
                triphelper.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                triphelper.cmbhelper.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(6).Value.ToString
                triphelper.ShowDialog()

                If clickbtn = "Search" Then
                    btnsearch.PerformClick()
                Else
                    btnview.PerformClick()
                End If
            End If

            'step 9 complete
            'step 6 returned
            'timedep is not null

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ViewTripInformationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewTripInformationToolStripMenuItem.Click
        Try
            Me.Cursor = Cursors.WaitCursor

            viewtripinfo.lblid.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(0).Value.ToString
            viewtripinfo.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
            viewtripinfo.Text = "Trip Information (" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & ")"
            viewtripinfo.ShowDialog()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ChangeDriverToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangeDriverToolStripMenuItem.Click
        Try
            'check sa db kung cancel tripsum
            sql = "Select * from tbltripsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "' and status='3'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & " is already cancelled.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Dim whatstep As String = ""
            'status
            sql = "Select * from tbldispatchsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "'"
            connect()
            Dim cmdxx As SqlCommand = New SqlCommand(sql, conn)
            Dim drxx As SqlDataReader = cmdxx.ExecuteReader
            If drxx.Read Then
                whatstep = "On Queue"

                If drxx("step1") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp1").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp1").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp1") & " ( " & drxx("datestp1").ToString & " )"
                        whatstep = "In Step 1"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp1")) = False Or IsDBNull(drxx("startpreby")) = False Or IsDBNull(drxx("startpre")) = False Then
                        whatstep = "In Step 1"
                    End If
                End If

                If drxx("step2") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp2").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp2").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp2") & " ( " & drxx("datestp2").ToString & " )"
                        whatstep = "In Step 2"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp2")) = False Or IsDBNull(drxx("startdieselby")) = False Or IsDBNull(drxx("startdiesel")) = False Then
                        whatstep = "In Step 2"
                    End If
                End If

                If drxx("step3") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp3").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp3").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp3") & " ( " & drxx("datestp3").ToString & " )"
                        whatstep = "In Step 3"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp3")) = False Or IsDBNull(drxx("startloadby")) = False Or IsDBNull(drxx("startload")) = False Then
                        whatstep = "In Step 3"
                    End If
                End If

                If drxx("step4") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp4").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp4").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp4") & " ( " & drxx("datestp4").ToString & " )"
                        whatstep = "Released Documents"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp4")) = False Or IsDBNull(drxx("startdocby")) = False Or IsDBNull(drxx("startdoc")) = False Then
                        whatstep = "Released Documents"
                    End If
                End If

                If drxx("step5") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp5").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                        If IsDBNull(drxx("timedep")) = False Then
                            whatstep = "Dispatched"
                        End If
                    ElseIf drxx("namestp5").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp5") & " ( " & drxx("datestp5").ToString & " )"
                        whatstep = "Released Petty Cash"
                        If IsDBNull(drxx("timedep")) = False Then
                            whatstep = "Dispatched"
                        End If
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp5")) = False Or IsDBNull(drxx("startcashby")) = False Or IsDBNull(drxx("startcash")) = False Then
                        whatstep = "Released Petty Cash"
                    End If
                End If

                If drxx("step6") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp6").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp6").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp6") & " ( " & drxx("datestp6").ToString & " )"
                        whatstep = "Returned to Whse"
                    End If
                End If

                If drxx("step7") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp7").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp7").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp7") & " ( " & drxx("datestp7").ToString & " )"
                        whatstep = "Returned to Whse"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp7")) = False Or IsDBNull(drxx("startreturnby")) = False Or IsDBNull(drxx("startreturn")) = False Then
                        whatstep = "Returned to Whse"
                    End If
                End If

                If drxx("step8") = 1 Then

                    If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                        '/des = "RESCUE TRIP# " & drxx("rescue")
                    ElseIf drxx("namestp8").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp8").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp8") & " ( " & drxx("datestp8").ToString & " )"
                        whatstep = "Returned to Whse"
                    End If

                Else
                    If IsDBNull(drxx("sdeytstp8")) = False Or IsDBNull(drxx("startpostby")) = False Or IsDBNull(drxx("startpost")) = False Then
                        whatstep = "Returned to Whse"
                    End If
                End If

                If drxx("step9") = 1 Then

                    If drxx("namestp9").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = "SKIPPED"
                    ElseIf drxx("namestp9").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                        '/des = drxx("namestp9") & " ( " & drxx("datestp9").ToString & " )"
                    Else
                        '/des = ""
                    End If

                    whatstep = "Completed"
                Else
                    If IsDBNull(drxx("sdeytstp9")) = False Or IsDBNull(drxx("startrecordby")) = False Or IsDBNull(drxx("startrecord")) = False Then
                        whatstep = "In Step 9"
                    End If
                End If
            End If
            drxx.Dispose()
            cmdxx.Dispose()
            conn.Close()

            If whatstep <> "Completed" Then '//And whatstep <> "In Step 9" And whatstep <> "Returned to Whse" And whatstep <> "Dispatched" Then
                tripdriver.lblvtype.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(4).Value  'tinitignan kung JPSC or CUSTOMER OR TRUCKING
                tripdriver.driver()
                tripdriver.lblplate.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(3).Value.ToString
                tripdriver.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                tripdriver.cmbdriver.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(5).Value.ToString
                tripdriver.fromform = "tripsum"
                tripdriver.ShowDialog()

                If clickbtn = "Search" Then
                    btnsearch.PerformClick()
                Else
                    btnview.PerformClick()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already " & whatstep & ".", MsgBoxStyle.Information, "")
            End If
           

            'step 9 complete
            'step 6 returned
            'timedep is not null

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbtype_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbtype.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbplate_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbplate.SelectedIndexChanged

    End Sub

    Private Sub tripsum_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub cmbcus_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbcus.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbcus_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbcus.Leave
        If Trim(cmbcus.Text) <> "" Then
            Dim meron As Boolean = False
            For Each item As Object In cmbcus.Items
                If item = Trim(cmbcus.Text.ToUpper) Then
                    meron = True
                    Exit For
                End If
            Next

            If meron = False Then
                MsgBox("Invalid recipient.", MsgBoxStyle.Exclamation, "")
                cmbcus.Text = ""
                cmbcus.Focus()
            End If
        End If
    End Sub

    Private Sub cmbcus_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcus.SelectedIndexChanged

    End Sub

    Private Sub cmbtype_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbtype.Leave
        If Trim(cmbtype.Text) <> "" Then
            Dim meron As Boolean = False
            For Each item As Object In cmbtype.Items
                If item = Trim(cmbtype.Text.ToUpper) Then
                    meron = True
                    Exit For
                End If
            Next

            If meron = False Then
                MsgBox("Invalid truck type.", MsgBoxStyle.Exclamation, "")
                cmbtype.Text = ""
                cmbtype.Focus()
            End If
        End If
    End Sub

    Private Sub RemoveCustomerTransactionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveCustomerTransactionToolStripMenuItem.Click
        'view list of transaction select what transaction is cancel

        Try
            If login.neym = "Guard" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Completed" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already completed.", MsgBoxStyle.Information, "")
                Exit Sub
            ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Cancelled" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already cancelled.", MsgBoxStyle.Information, "")
                Exit Sub
            Else
                'check sa db kung cancel tripsum
                sql = "Select * from tbltripsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "' and status='3'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip# " & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & " is already cancelled.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                Dim whatstep As String = ""
                'status
                sql = "Select * from tbldispatchsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "'"
                connect()
                Dim cmdxx As SqlCommand = New SqlCommand(sql, conn)
                Dim drxx As SqlDataReader = cmdxx.ExecuteReader
                If drxx.Read Then
                    whatstep = "On Queue"

                    If drxx("step1") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp1").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp1").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp1") & " ( " & drxx("datestp1").ToString & " )"
                            whatstep = "In Step 1"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp1")) = False Or IsDBNull(drxx("startpreby")) = False Or IsDBNull(drxx("startpre")) = False Then
                            whatstep = "In Step 1"
                        End If
                    End If

                    If drxx("step2") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp2").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp2").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp2") & " ( " & drxx("datestp2").ToString & " )"
                            whatstep = "In Step 2"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp2")) = False Or IsDBNull(drxx("startdieselby")) = False Or IsDBNull(drxx("startdiesel")) = False Then
                            whatstep = "In Step 2"
                        End If
                    End If

                    If drxx("step3") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp3").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp3").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp3") & " ( " & drxx("datestp3").ToString & " )"
                            whatstep = "In Step 3"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp3")) = False Or IsDBNull(drxx("startloadby")) = False Or IsDBNull(drxx("startload")) = False Then
                            whatstep = "In Step 3"
                        End If
                    End If

                    If drxx("step4") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp4").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp4").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp4") & " ( " & drxx("datestp4").ToString & " )"
                            whatstep = "Released Documents"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp4")) = False Or IsDBNull(drxx("startdocby")) = False Or IsDBNull(drxx("startdoc")) = False Then
                            whatstep = "Released Documents"
                        End If
                    End If

                    If drxx("step5") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp5").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                            If IsDBNull(drxx("timedep")) = False Then
                                whatstep = "Dispatched"
                            End If
                        ElseIf drxx("namestp5").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp5") & " ( " & drxx("datestp5").ToString & " )"
                            whatstep = "Released Petty Cash"
                            If IsDBNull(drxx("timedep")) = False Then
                                whatstep = "Dispatched"
                            End If
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp5")) = False Or IsDBNull(drxx("startcashby")) = False Or IsDBNull(drxx("startcash")) = False Then
                            whatstep = "Released Petty Cash"
                        End If
                    End If

                    If drxx("step6") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp6").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp6").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp6") & " ( " & drxx("datestp6").ToString & " )"
                            whatstep = "Returned to Whse"
                        End If
                    End If

                    If drxx("step7") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp7").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp7").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp7") & " ( " & drxx("datestp7").ToString & " )"
                            whatstep = "Returned to Whse"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp7")) = False Or IsDBNull(drxx("startreturnby")) = False Or IsDBNull(drxx("startreturn")) = False Then
                            whatstep = "Returned to Whse"
                        End If
                    End If

                    If drxx("step8") = 1 Then

                        If drxx("rescue").ToString <> "" And drxx("rescue").ToString <> "-" Then
                            '/des = "RESCUE TRIP# " & drxx("rescue")
                        ElseIf drxx("namestp8").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp8").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp8") & " ( " & drxx("datestp8").ToString & " )"
                            whatstep = "Returned to Whse"
                        End If

                    Else
                        If IsDBNull(drxx("sdeytstp8")) = False Or IsDBNull(drxx("startpostby")) = False Or IsDBNull(drxx("startpost")) = False Then
                            whatstep = "Returned to Whse"
                        End If
                    End If

                    If drxx("step9") = 1 Then

                        If drxx("namestp9").ToString = "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = "SKIPPED"
                        ElseIf drxx("namestp9").ToString <> "" And (drxx("rescue").ToString = "" Or drxx("rescue").ToString = "-") Then
                            '/des = drxx("namestp9") & " ( " & drxx("datestp9").ToString & " )"
                        Else
                            '/des = ""
                        End If

                        whatstep = "Completed"
                    Else
                        If IsDBNull(drxx("sdeytstp9")) = False Or IsDBNull(drxx("startrecordby")) = False Or IsDBNull(drxx("startrecord")) = False Then
                            whatstep = "In Step 9"
                        End If
                    End If
                End If
                drxx.Dispose()
                cmdxx.Dispose()
                conn.Close()

                If whatstep = "Returned to Whse" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already returned to whse.", MsgBoxStyle.Information, "")
                    'pwede mag return sa whse pero cancel yung transaction
                    '/tripcancel.lblreturn.Text = "Returned"
                    '/tripcancel.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                    '/tripcancel.lblvtype.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(4).Value.ToString
                    '/tripcancel.btncanceltrip.Enabled = False
                    '/tripcancel.btnremove.Enabled = True
                    '/tripcancel.btncancel.Enabled = True
                    '/tripcancel.btnreschedule.Enabled = True
                    '/tripcancel.ShowDialog()

                    'ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "On Queue" Then
                ElseIf whatstep <> "Completed" And whatstep <> "Returned to Whse" And whatstep <> "Dispatched" And whatstep <> "In Step 9" Then
                    tripcancel.lblreturn.Text = ""
                    tripcancel.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                    tripcancel.lblvtype.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(4).Value.ToString
                    tripcancel.btncanceltrip.Enabled = True
                    tripcancel.btnremove.Enabled = True
                    tripcancel.btncancel.Enabled = False
                    tripcancel.btnreschedule.Enabled = False
                    tripcancel.grdadd.Columns(1).Visible = True
                    tripcancel.btnremove.Visible = True
                    tripcancel.btncanceltrip.Visible = False
                    tripcancel.Text = "Remove Customer Transaction"
                    tripcancel.ShowDialog()
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already " & whatstep & ".", MsgBoxStyle.Information, "")
                End If
            End If

            If clickbtn = "Search" Then
                btnsearch.PerformClick()
            Else
                btnview.PerformClick()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class