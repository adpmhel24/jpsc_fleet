﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class saveimagesteps
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub saveimage_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        txtname.Text = ""
        txtpath.Text = ""
    End Sub

    Private Sub saveimage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnbrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnbrowse.Click
        If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
            txtpath.Text = FolderBrowserDialog1.SelectedPath
        End If
    End Sub

    Private Sub btnok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        If Trim(txtname.Text) <> "" And Trim(txtpath.Text) <> "" Then
            If My.Computer.FileSystem.FileExists(txtpath.Text & "\" & Trim(txtname.Text) & ".png") Then
                MsgBox("Filename is already exist.", MsgBoxStyle.Exclamation, "")
                txtname.Text = ""
                txtname.Focus()
            Else
                Dim a As String = MsgBox("Are you sure you want to download photo?.", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
                If a = vbYes Then
                    'save photo to the specified path
                    viewstep1.imgbox1.Image.Save(txtpath.Text & "\" & Trim(txtname.Text) & ".png", System.Drawing.Imaging.ImageFormat.Png)
                    MsgBox("Successfully downloaded.", MsgBoxStyle.Information, "")
                    'imgphoto.Image.Save("C:\Users\Dell1\Documents\BACKUPJECELJPOON\jecel\vehicle\piktyur.jpg", System.Drawing.Imaging.ImageFormat.Jpeg)
                    Me.Close()
                End If
            End If
        Else
            MsgBox("Complete the fields.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub txtname_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtname.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789-_"
        Dim theText As String = txtname.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtname.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtname.Text.Length - 1
            Letter = txtname.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtname.Text = theText
        txtname.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        Me.Close()
    End Sub
End Class