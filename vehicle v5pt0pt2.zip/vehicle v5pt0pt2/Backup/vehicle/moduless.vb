﻿Imports System.Data.OleDb
Imports System.IO
Imports System.Data.SqlClient
Imports System.Security
Imports System.Security.Cryptography
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Imports System.Text

Public Class moduless
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand
    Public steps As String
    Dim hasrows7 As Boolean = False
    Dim hasrows8 As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub moduless_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        login.Show()
    End Sub

    Private Sub moduless_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        savelogout()
    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TreeView2.Nodes(0).Expand()
        TreeView2.Nodes(1).Expand()
        TreeView2.Nodes(2).Expand()
        TreeView2.Nodes(3).Collapse()

        TreeView2.Nodes(0).Nodes(0).Tag = "comps"
        TreeView2.Nodes(0).Nodes(1).Tag = "whse"
        TreeView2.Nodes(0).Nodes(2).Tag = "doc"
        TreeView2.Nodes(0).Nodes(3).Tag = "mdiform"
        TreeView2.Nodes(0).Nodes(4).Tag = "driver"
        TreeView2.Nodes(0).Nodes(5).Tag = "helper"
        TreeView2.Nodes(0).Nodes(6).Tag = "customer"
        TreeView2.Nodes(0).Nodes(7).Tag = "category"
        TreeView2.Nodes(0).Nodes(8).Tag = "newitems"

        TreeView2.Nodes(1).Nodes(0).Tag = "mainmenucreate"
        TreeView2.Nodes(1).Nodes(1).Tag = "trans"
        TreeView2.Nodes(1).Nodes(2).Tag = "tripadd"
        TreeView2.Nodes(1).Nodes(3).Tag = "tripdispatch"
        TreeView2.Nodes(1).Nodes(4).Tag = "tripdispatchsum"
        TreeView2.Nodes(1).Nodes(5).Tag = "tripsum"

        TreeView2.Nodes(2).Nodes(0).Tag = "tripreport"
        TreeView2.Nodes(2).Nodes(1).Tag = "forchangeoil"

        TreeView2.Nodes(3).Nodes(0).Tag = "users"
        '/TreeView2.Nodes(3).Nodes(1).Tag = "whseconn"
        TreeView2.Nodes(3).Nodes(1).Tag = "loginlogs"
        TreeView2.Nodes(3).Nodes(2).Tag = "version"
        TreeView2.Nodes(3).Nodes(3).Tag = "transqty"
        TreeView2.Nodes(3).Nodes(4).Tag = "dashboard"
        TreeView2.Nodes(3).Nodes(5).Tag = "rptcomment"
        TreeView2.Nodes(3).Nodes(6).Tag = "sqlqueries"

    End Sub

    Public Sub createtree()
        'create a new TreeView
        Dim TreeView1 As TreeView
        TreeView1 = New TreeView()
        TreeView1.Location = New Point(10, 10)
        TreeView1.Size = New Size(150, 150)
        Me.Controls.Add(TreeView1)
        TreeView1.Nodes.Clear()
        'Creating the root node
        Dim root = New TreeNode("Application")
        TreeView1.Nodes.Add(root)
        TreeView1.Nodes(0).Nodes.Add(New TreeNode("Project 1"))
        'Creating child nodes under the first child
        For loopindex As Integer = 1 To 4
            TreeView1.Nodes(0).Nodes(0).Nodes.Add(New  _
                TreeNode("Sub Project" & Str(loopindex)))
        Next loopindex
        ' creating child nodes under the root

        Dim root1 = New TreeNode("Application")
        TreeView1.Nodes.Add(root1)
        TreeView1.Nodes(1).Nodes.Add(New TreeNode("Project 6"))
        'creating child nodes under the created child node
        For loopindex As Integer = 1 To 3
            TreeView1.Nodes(1).Nodes(0).Nodes.Add(New  _
                   TreeNode("Project File" & Str(loopindex)))
        Next loopindex
        ' Set the caption bar text of the form.  
        Me.Text = "tutorialspoint.com"
    End Sub

    Private Sub TreeView1_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView1.AfterSelect
        Dim obj As Form
        Try
            MsgBox(e.Node.Tag.ToString)
            If e.Node.Tag IsNot Nothing Then
                obj = CType(Activator.CreateInstance(Type.GetType("vehicle." & e.Node.Tag.ToString, False)), Form)
                If obj IsNot Nothing Then
                    Using obj
                        obj.ShowDialog()
                    End Using
                End If
            End If
        Catch ex As Exception
            'handle your exception
        End Try
    End Sub

    Private Sub TreeView2_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView2.AfterSelect
        
    End Sub

    Private Sub TreeView2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TreeView2.Click

    End Sub

    Public Sub savelogout()
        Try
            Dim logid As Integer = 0

            sql = "Select TOP 1 * from tbllogin where datelogin='" & Format(Date.Now, "yyyy/MM/dd") & "' and username='" & login.cashier & "' and logout='' order by systemid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                logid = dr("systemid")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            sql = "Update tbllogin set datelogout=GetDate(), logout='" & Format(Date.Now, "HH:mm") & "' where systemid='" & logid & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim dtServerDateTime As DateTime

        connect()
        cmd = New SqlCommand("Select GetDate()", conn)
        dtServerDateTime = cmd.ExecuteScalar

        MsgBox(dtServerDateTime.ToString)
    End Sub

    Private Sub TreeView2_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TreeView2.DoubleClick
        ' Dim oAssembly As Assembly = Assembly.GetEntryAssembly()

        Dim tn As TreeNode = Me.TreeView2.SelectedNode

        If tn.Tag = "mdiform" Or tn.Tag = "mainmenucreate" Or tn.Tag = "category" Or tn.Tag = "newitems" Or tn.Tag = "customer" Or tn.Tag = "driver" Or tn.Tag = "helper" Or tn.Tag = "comps" Or tn.Tag = "whse" Or tn.Tag = "doc" Then
            If login.neym = "Guard" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If tn.Tag = "mdiform" Then
                Dim myForm As New mdiform
                mdiform.Text = mdiform.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                mdiform.Show()

            ElseIf tn.Tag = "mainmenucreate" Then
                Dim myForm As New mainmenucreate
                mainmenucreate.Text = mainmenucreate.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                mainmenucreate.Show()

            ElseIf tn.Tag = "category" Then
                Dim myForm As New category
                category.Text = category.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                category.Show()

            ElseIf tn.Tag = "newitems" Then
                Dim myForm As New newitems
                newitems.Text = newitems.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                newitems.Show()

            ElseIf tn.Tag = "customer" Then
                Dim myForm As New customer
                customer.Text = customer.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                customer.Show()

            ElseIf tn.Tag = "driver" Then
                Dim myForm As New newdriver
                newdriver.Text = newdriver.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                newdriver.Show()

            ElseIf tn.Tag = "helper" Then
                Dim myForm As New newhelper
                newhelper.Text = newhelper.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                newhelper.Show()

            ElseIf tn.Tag = "comps" Then
                Dim myForm As New comps
                comps.Text = comps.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                comps.Show()

            ElseIf tn.Tag = "whse" Then
                Dim myForm As New whse
                whse.Text = whse.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                whse.Show()

            ElseIf tn.Tag = "doc" Then
                Dim myForm As New doc
                doc.Text = doc.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                doc.Show()
            End If
            Me.Hide()

        ElseIf tn.Tag = "tripdispatch" Then
            Dim myForm As New tripdispatch
            tripdispatch.Text = tripdispatch.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
            tripdispatch.Show()
            Me.Hide()

        ElseIf tn.Tag = "tripdispatchsum" Or tn.Tag = "tripadd" Or tn.Tag = "tripsum" Or tn.Tag = "trans" Or tn.Tag = "tripdiesel" Then
            If login.neym = "Guard" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If tn.Tag = "tripdispatchsum" Then
                Dim myForm As New tripdispatchsum
                tripdispatchsum.Text = tripdispatchsum.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                tripdispatchsum.Show()
            ElseIf tn.Tag = "tripadd" Then
                If login.neym = "Guard" Or login.neym = "Checker" Or login.neym = "Diesel Controller" Or login.neym = "Inspector" Then
                    MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
                If login.neym = "Whse Accounting Staff" Then
                    MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
                Dim myForm As New tripadd
                tripadd.Text = tripadd.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                tripadd.Show()
            ElseIf tn.Tag = "tripsum" Then
                Dim myForm As New tripsum
                tripsum.Text = tripsum.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                tripsum.Show()
            ElseIf tn.Tag = "tripdiesel" Then
                Dim myForm As New tripdiesel
                tripdiesel.Text = tripdiesel.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                tripdiesel.Show()
            ElseIf tn.Tag = "trans" Then
                If login.neym = "Guard" Or login.neym = "Checker" Or login.neym = "Diesel Controller" Or login.neym = "Inspector" Then
                    MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
                Dim myForm As New trans
                trans.Text = trans.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
                trans.Show()
            End If
            Me.Hide()


        ElseIf tn.Tag = "purchase" Then
            steps = tn.Tag

            'MsgBox(steps)
            If login.neym = "Guard" Or login.neym = "Checker" Or login.neym = "Diesel Controller" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            'Dim myForm As New purchase
            'purchase.Show()
            'Me.Hide()

        ElseIf tn.Tag = "loginlogs" Then
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Dim myForm As New loginlogs
            loginlogs.Text = loginlogs.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
            loginlogs.Show()
            Me.Hide()

        ElseIf tn.Tag = "users" Then
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Dim myForm As New users
            users.Text = users.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
            users.Show()
            Me.Hide()

        ElseIf tn.Tag = "version" Then
            If login.neym <> "Administrator" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Dim myForm As New version
            version.Text = version.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
            version.Show()
            Me.Hide()

        ElseIf tn.Tag = "tripreport" Then

            Dim myForm As New tripreport
            tripreport.Text = tripreport.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
            tripreport.Show()
            Me.Hide()

        ElseIf tn.Tag = "forchangeoil" Then

            Dim myForm As New forchangeoil
            forchangeoil.Text = forchangeoil.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
            forchangeoil.Show()
            Me.Hide()

        ElseIf tn.Tag = "transqty" Then
            If login.neym <> "Administrator" And login.neym <> "Supervisor" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Dim myForm As New transqty
            transqty.Text = transqty.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
            transqty.Show()
            Me.Hide()

        ElseIf tn.Tag = "dashboard" Then
            If login.neym <> "Administrator" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Dim myForm As New dashboard
            dashboard.Text = dashboard.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
            dashboard.WindowState = FormWindowState.Maximized
            dashboard.Show()
            Me.Hide()

        ElseIf tn.Tag = "rptcomment" Then
            If login.neym <> "Administrator" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Dim myForm As New rptcomment
            rptcomment.Text = rptcomment.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
            rptcomment.Show()
            Me.Hide()

        ElseIf tn.Tag = "whseconn" Then
            If login.neym <> "Administrator" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Dim myForm As New whseconn
            whseconn.Text = whseconn.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
            whseconn.Show()
            Me.Hide()

        ElseIf tn.Tag = "sqlqueries" Then
            If login.neym <> "Administrator" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Dim myForm As New sqlqueries
            sqlqueries.Text = sqlqueries.Text & " (" & login.whse & " - " & login.cashier & " - Version: " & login.lblver.Text & ")"
            sqlqueries.Show()
            Me.Hide()

        End If


        TreeView2.CollapseAll()
        TreeView2.ExpandAll()
        TreeView2.Nodes(3).Collapse()
    End Sub

    Private Sub moduless_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        checkhasrows7()
        If hasrows7 = True Then
            pendingstep7.ShowDialog()
        End If

        checkhasrows8()
        If hasrows8 = True Then
            pendingstep8.ShowDialog()
        End If

        If login.whse <> "JP-Store" Then
            forchangeoil.view()
            If forchangeoil.grdpms.Rows.Count <> 0 Then
                forchangeoil.ShowDialog()
            End If
        End If
    End Sub

    Public Sub checkhasrows7()
        Try
            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step7<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) Then
                        hasrows7 = True
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub checkhasrows8()
        Try
            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step8<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) Then
                        hasrows8 = True
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class