﻿Imports System.IO
Imports System.Data.SqlClient
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.Windows.Forms
Imports System.ComponentModel

Public Class rptchangeoil
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim objRpt As New crnotif1, ds As New DataSet1
    Dim sqlquery As String, dscmd As SqlDataAdapter
    Public condition As String, cashr As String, ctr As Boolean = False
    Public printerneym As String

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub notifsreportprev_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        loadexp()

        Dim plnum As String = ""
        Dim ds As New DataSet1
        Dim t As DataTable = ds.Tables.Add("Items")
        t.Columns.Add("Company", Type.GetType("System.String"))
        t.Columns.Add("Warehouse", Type.GetType("System.String"))
        t.Columns.Add("Plate Number", Type.GetType("System.String"))
        t.Columns.Add("Vehicle Type", Type.GetType("System.String"))
        t.Columns.Add("Notification", Type.GetType("System.String"))
        t.Columns.Add("Interval Mileage", Type.GetType("System.String"))
        t.Columns.Add("Last Performed In", Type.GetType("System.String"))
        t.Columns.Add("Last Performed Date", Type.GetType("System.String"))
        t.Columns.Add("Last Odometer Change Oil", Type.GetType("System.String"))
        t.Columns.Add("Next Odometer for Change Oil", Type.GetType("System.String"))
        t.Columns.Add("Fleet Latest Ending Odometer", Type.GetType("System.String"))
        t.Columns.Add("Remarks", Type.GetType("System.String"))
        t.Columns.Add("Status", Type.GetType("System.String"))
        t.Columns.Add("Genid", Type.GetType("System.String"))


        Dim r As DataRow
        For Each row As DataGridViewRow In grdtemp.Rows

            If grdtemp.Rows(row.Index).Cells(1).Value = 1 And grdtemp.Rows(row.Index).Cells(5).Value.ToString <> "" And grdtemp.Rows(row.Index).Cells(4).Value.ToString <> "" And grdtemp.Rows(row.Index).Cells(3).Value.ToString <> "" Then
                r = t.NewRow()
                r("Genid") = grdtemp.Rows(row.Index).Cells(0).Value
                r("Company") = grdtemp.Rows(row.Index).Cells(5).Value
                r("Warehouse") = grdtemp.Rows(row.Index).Cells(4).Value
                If grdtemp.Rows(row.Index).Cells(2).Value = "" Then
                    sql = "Select * from tblgeneral where genid='" & grdtemp.Rows(row.Index).Cells(0).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        If dr("platenum") = "" And dr("vplate") <> "" Then
                            plnum = dr("vplate")
                        ElseIf dr("platenum") = "" And dr("vplate") = "" And dr("csticker") <> "" Then
                            plnum = dr("csticker")
                        Else
                            plnum = dr("platenum")
                        End If
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                    r("Plate Number") = plnum
                Else
                    r("Plate Number") = grdtemp.Rows(row.Index).Cells(2).Value
                End If

                r("Vehicle Type") = grdtemp.Rows(row.Index).Cells(3).Value
                r("Notification") = grdtemp.Rows(row.Index).Cells(6).Value
                r("Interval Mileage") = grdtemp.Rows(row.Index).Cells(7).Value
                r("Last Performed In") = grdtemp.Rows(row.Index).Cells(8).Value
                r("Last Performed Date") = grdtemp.Rows(row.Index).Cells(9).Value
                r("Last Odometer Change Oil") = grdtemp.Rows(row.Index).Cells(10).Value
                r("Next Odometer for Change Oil") = grdtemp.Rows(row.Index).Cells(11).Value
                r("Fleet Latest Ending Odometer") = grdtemp.Rows(row.Index).Cells(12).Value
                r("Remarks") = grdtemp.Rows(row.Index).Cells(13).Value
                r("Status") = grdtemp.Rows(row.Index).Cells(14).Value

                t.Rows.Add(r)
            End If
        Next


        'MsgBox(ds.Tables("Items").Rows.Count)
        objRpt.SetDataSource(ds.Tables("Items"))
        CrystalReportViewer1.ReportSource = objRpt
        CrystalReportViewer1.Refresh()
    End Sub

    Public Sub view()
        Try
            grdtemp.Rows.Clear()

            'tblpmssched
            sql = "Select * from tblpmssched where status='1' and (statusexp='Due Today' or statusexp='Over Due' or statusexp='Due Soon')"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grdtemp.Rows.Add(dr("genid"), 0, "", "", "", "", dr("servicename"), dr("miles"), dr("whsename"), Format(dr("datelast"), "MM/dd/yyyy"), dr("lastodo"), dr("nextodo"), dr("endodo"), dr("remarks"), dr("statusexp"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            For Each row As DataGridViewRow In grdtemp.Rows
                sql = "Select * from tblgeneral where genid='" & grdtemp.Rows(row.Index).Cells(0).Value & "'" & condition
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    grdtemp.Item(1, row.Index).Value = dr("status")
                    grdtemp.Item(2, row.Index).Value = dr("platenum")
                    grdtemp.Item(3, row.Index).Value = dr("vtype")
                    grdtemp.Item(4, row.Index).Value = dr("whsename")
                    grdtemp.Item(5, row.Index).Value = dr("company")
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Next

            grdtemp.Sort(grdtemp.Columns(3), ListSortDirection.Ascending)
            grdtemp.Sort(grdtemp.Columns(2), ListSortDirection.Ascending)
            grdtemp.Sort(grdtemp.Columns(4), ListSortDirection.Ascending)
            grdtemp.Sort(grdtemp.Columns(5), ListSortDirection.Ascending)

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadexp()
        Try
            Me.Cursor = Cursors.WaitCursor
            grdtemp.Rows.Clear()

            sql = "Select tblgeneral.genid, tblgeneral.platenum, tblpmssched.datelast, tblpmssched.lastodo, tblpmssched.miles, tblpmssched.nextodo, tblpmssched.remarks, tblpmssched.pmschid,"
            sql = sql & " tblgeneral.status, tblgeneral.vtype, tblgeneral.whsename as genwhse, tblgeneral.company, tblpmssched.whsename as pmswhse, tblpmssched.servicename"
            sql = sql & " from tblpmssched right outer join tblgeneral on tblpmssched.genid=tblgeneral.genid"
            sql = sql & " where tblpmssched.status=1 and tblgeneral.status=1 order by tblgeneral.platenum"

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grdtemp.Rows.Add(dr("genid"), dr("status"), dr("platenum"), dr("vtype"), dr("genwhse"), dr("company"), dr("servicename"), dr("miles"), dr("pmswhse"), Format(dr("datelast"), "yyyy/MM/dd"), dr("lastodo"), dr("nextodo"), 0, dr("remarks").ToString, "") ', dr("pmschid")
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            For Each row As DataGridViewRow In grdtemp.Rows
                '/Dim pmsschedid As Integer = Val(grdtemp.Rows(row.Index).Cells(9).Value)
                Dim plate As String = grdtemp.Rows(row.Index).Cells(2).Value

                sql = "Select Top 1 odoend from tbltripsum where platenum='" & plate & "' and (status='1' or status='2') and odoend<>'0' order by tripsumid DESC"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    grdtemp.Rows(row.Index).Cells(12).Value = dr("odoend")
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                Dim endingodo As Integer = Val(grdtemp.Rows(row.Index).Cells(12).Value)
                Dim nextodo As Integer = Val(grdtemp.Rows(row.Index).Cells(11).Value)
                Dim stat As String = ""

                If endingodo = nextodo Then
                    stat = "Due Today"
                ElseIf endingodo >= nextodo - 1000 And endingodo <= nextodo - 1 Then
                    stat = "Due Soon"
                ElseIf endingodo > nextodo Then
                    stat = "Over Due"
                Else
                    stat = "Updated"
                End If

                grdtemp.Rows(row.Index).Cells(14).Value = stat
            Next

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class