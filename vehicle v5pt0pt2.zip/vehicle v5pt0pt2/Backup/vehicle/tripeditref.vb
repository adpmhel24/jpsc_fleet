﻿Imports System.IO
Imports System.Data.SqlClient

Public Class tripeditref
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public oreditcnf As Boolean = False, refnum As String = "", frm As String
    Dim conslash As Boolean = False, slashso As String = "", slashpo As String = ""

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        If frm = "tripdispatch" Then
            tripdispatch.edited = False
        ElseIf frm = "viewstep1" Then
            viewstep1.edited = False
        End If

        Me.Close()
    End Sub

    Private Sub tripeditref_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        
    End Sub

    Private Sub tripeditref_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtprev.Text = ""
        txtnew.Text = ""
        viewref()
        If login.neym = "Administrator" Or login.neym = "Supervisor" Then
            Label1.Visible = True
            txttransid.Visible = True
        Else
            Label1.Visible = False
            txttransid.Visible = False
        End If
    End Sub

    Public Sub viewref()
        Try
            slashso = ""
            slashpo = ""

            sql = "Select * from tblortrans where transid='" & txttransid.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If lbl1.Text = "SO#" Then
                    If IsDBNull(dr("sonum")) = True Then
                        '//////////////////////////////
                        If dr("refnum").ToString.Contains("/") Then
                            conslash = True
                            Dim inSql As String = dr("refnum").ToString
                            Dim fromStart As Integer
                            Dim firstpart As String

                            fromStart = inSql.IndexOf("/")
                            firstpart = inSql.Substring(3, fromStart - 4)
                            txtprev.Text = Trim(firstpart)

                            Dim lastPart As String
                            Dim frompo As Integer
                            frompo = inSql.IndexOf("PO#")
                            lastPart = inSql.Substring(frompo, inSql.Length - frompo)
                            slashpo = Trim(lastPart)
                            '/MsgBox(slashpo)

                        Else 'meaning so lang
                            conslash = False
                            Dim inSql As String = dr("refnum").ToString
                            Dim fromStart As Integer
                            Dim firstpart As String

                            fromStart = inSql.IndexOf("#") + 1
                            firstpart = inSql.Substring(fromStart, inSql.Length - fromStart)
                            txtprev.Text = Trim(firstpart)
                        End If
                        '//////////////////////////////
                    Else
                        If dr("refnum").ToString.Contains("/") Then
                            conslash = True
                            Dim inSql As String = dr("refnum").ToString
                            Dim fromStart As Integer
                            Dim firstpart As String

                            fromStart = inSql.IndexOf("/")
                            firstpart = inSql.Substring(3, fromStart - 4)
                            txtprev.Text = Trim(firstpart)

                            Dim lastPart As String
                            Dim frompo As Integer
                            frompo = inSql.IndexOf("PO#")
                            lastPart = inSql.Substring(frompo, inSql.Length - frompo)
                            slashpo = Trim(lastPart)
                            '/MsgBox(slashpo)

                        Else 'meaning so lang
                            conslash = False
                            txtprev.Text = dr("sonum").ToString
                        End If
                    End If


                ElseIf lbl1.Text = "PO#" Then
                    If IsDBNull(dr("ponum")) = True Then
                        '//////////////////////////////
                        If dr("refnum").ToString.Contains("/") Then
                            conslash = True
                            Dim inSql As String = dr("refnum").ToString
                            Dim lastPart As String
                            Dim fromStart As Integer

                            fromStart = inSql.IndexOf("PO#") + 3
                            lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)
                            txtprev.Text = Trim(lastPart)

                            Dim fromso As Integer
                            Dim firstpart As String
                            fromso = inSql.IndexOf("/")
                            firstpart = inSql.Substring(0, fromso - 1)
                            slashso = Trim(firstpart)
                            '/MsgBox(slashso)

                        Else 'meaning po lang
                            conslash = False
                            Dim inSql As String = dr("refnum").ToString
                            If inSql <> "" Then
                                Dim firstpart As String
                                Dim fromStart As Integer

                                fromStart = inSql.IndexOf("#") + 1
                                firstpart = inSql.Substring(fromStart, inSql.Length - fromStart)
                                txtprev.Text = Trim(firstpart)
                            End If
                        End If
                        '//////////////////////////////
                    Else
                        If dr("refnum").ToString.Contains("/") Then
                            conslash = True
                            Dim inSql As String = dr("refnum").ToString
                            Dim lastPart As String
                            Dim fromStart As Integer

                            fromStart = inSql.IndexOf("PO#") + 3
                            lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)
                            txtprev.Text = Trim(lastPart)

                            Dim fromso As Integer
                            Dim firstpart As String
                            fromso = inSql.IndexOf("/")
                            firstpart = inSql.Substring(0, fromso - 1)
                            slashso = Trim(firstpart)
                            '/MsgBox(slashso)

                        Else 'meaning po lang
                            conslash = False
                            txtprev.Text = dr("ponum").ToString
                        End If
                    End If


                ElseIf lbl1.Text = "ITR#" Then
                        If dr("itrnum").ToString = "" Then 'meaning sa refnum nlng merong laman
                            conslash = False
                            Dim inSql As String = dr("refnum").ToString
                            If inSql <> "" Then
                                Dim firstpart As String
                                Dim fromStart As Integer

                                fromStart = inSql.IndexOf("#") + 1
                                firstpart = inSql.Substring(fromStart, inSql.Length - fromStart)
                                txtprev.Text = Trim(firstpart)
                            End If
                        Else
                            conslash = False
                            txtprev.Text = dr("itrnum").ToString
                        End If


                ElseIf lbl1.Text = "SWS#" Then
                        If IsDBNull(dr("swsnum")) = True Then
                            conslash = False
                            Dim inSql As String = dr("refnum").ToString
                            If inSql <> "" Then
                                Dim firstpart As String
                                Dim fromStart As Integer

                                fromStart = inSql.IndexOf("#") + 1
                                firstpart = inSql.Substring(fromStart, inSql.Length - fromStart)
                                txtprev.Text = Trim(firstpart)
                            End If
                        Else
                            conslash = False
                            txtprev.Text = dr("swsnum").ToString
                        End If
                    End If
                End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        Try
            If Trim(txttransid.Text) = "" Then
                MsgBox("Please refresh again.", MsgBoxStyle.Exclamation, "")
            ElseIf Trim(txtprev.Text) = "" Then
                MsgBox("Please refresh again.", MsgBoxStyle.Exclamation, "")
            ElseIf Trim(txtnew.Text) = "" Then
                MsgBox("Please input new " & lbl1.Text & ".", MsgBoxStyle.Exclamation, "")
                txtnew.Focus()
            Else
                If Trim(txtprev.Text) = Trim(txtnew.Text) Then
                    MsgBox("Please input new " & lbl1.Text & ".", MsgBoxStyle.Exclamation, "")
                    txtnew.Focus()
                ElseIf Val(Trim(txtnew.Text)) = 0 And Trim(txtnew.Text.ToUpper) <> "TO FOLLOW" Then
                    MsgBox("Please input " & lbl1.Text & ".", MsgBoxStyle.Exclamation, "")
                    txtnew.Focus()
                Else
                    'complete lahat
                    'confirm
                    oreditcnf = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()

                    If oreditcnf = True Then
                        'generate refnum
                        refnum = ""
                        If Trim(txtnew.Text.ToUpper) <> "TO FOLLOW" Then
                            txtnew.Text = Val(Trim(txtnew.Text))
                        Else
                            txtnew.Text = "TO FOLLOW"
                        End If


                        'save to tblortrans
                        If lbl1.Text = "SO#" Then '//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            If conslash = True Then
                                refnum = lbl2.Text & Trim(txtnew.Text) & " / " & slashpo
                            Else
                                refnum = lbl2.Text & Trim(txtnew.Text)
                            End If

                            sql = "Update tblortrans set refnum='" & refnum & "', sonum='" & Trim(txtnew.Text) & "' where transid='" & txttransid.Text & "'"

                        ElseIf lbl1.Text = "PO#" Then '//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            If conslash = True Then
                                refnum = slashso & " / " & lbl2.Text & Trim(txtnew.Text)
                            Else
                                refnum = lbl2.Text & Trim(txtnew.Text)
                            End If

                            sql = "Update tblortrans set refnum='" & refnum & "', ponum='" & Trim(txtnew.Text) & "' where transid='" & txttransid.Text & "'"

                        ElseIf lbl1.Text = "ITR#" Then '//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            refnum = lbl2.Text & Trim(txtnew.Text)

                            sql = "Update tblortrans set refnum='" & refnum & "', itrnum='" & Trim(txtnew.Text) & "' where transid='" & txttransid.Text & "'"

                        ElseIf lbl1.Text = "SWS#" Then '//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            refnum = lbl2.Text & Trim(txtnew.Text)

                            sql = "Update tblortrans set refnum='" & refnum & "', swsnum='" & Trim(txtnew.Text) & "' where transid='" & txttransid.Text & "'"
                        End If

                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()


                        'save to tbloredit
                        If lbl1.Text = "SO#" Then '//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            sql = "Insert into tbloredit (transid, transnum, customer, prevso, newso, prevpo, newpo, previtr, newitr, prevsws, newsws, datecreated, createdby, status) values ('" & txttransid.Text & "', '" & txttransnum.Text & "', '" & txtcus.Text & "', '" & lbl1.Text & txtprev.Text & "', '" & lbl2.Text & txtnew.Text & "', '', '', '', '', '', '', GetDate(), '" & login.cashier & "', '1')"
                        ElseIf lbl1.Text = "PO#" Then '//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            sql = "Insert into tbloredit (transid, transnum, customer, prevso, newso, prevpo, newpo, previtr, newitr, prevsws, newsws, datecreated, createdby, status) values ('" & txttransid.Text & "', '" & txttransnum.Text & "', '" & txtcus.Text & "', '', '', '" & lbl1.Text & txtprev.Text & "', '" & lbl2.Text & txtnew.Text & "', '', '', '', '', GetDate(), '" & login.cashier & "', '1')"
                        ElseIf lbl1.Text = "ITR#" Then '//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            sql = "Insert into tbloredit (transid, transnum, customer, prevso, newso, prevpo, newpo, previtr, newitr, prevsws, newsws, datecreated, createdby, status) values ('" & txttransid.Text & "', '" & txttransnum.Text & "', '" & txtcus.Text & "', '', '', '', '', '" & lbl1.Text & txtprev.Text & "', '" & lbl2.Text & txtnew.Text & "', '', '', GetDate(), '" & login.cashier & "', '1')"
                        ElseIf lbl1.Text = "SWS#" Then '//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            sql = "Insert into tbloredit (transid, transnum, customer, prevso, newso, prevpo, newpo, previtr, newitr, prevsws, newsws, datecreated, createdby, status) values ('" & txttransid.Text & "', '" & txttransnum.Text & "', '" & txtcus.Text & "', '', '', '', '', '', '', '" & lbl1.Text & txtprev.Text & "', '" & lbl2.Text & txtnew.Text & "', GetDate(), '" & login.cashier & "', '1')"
                        End If

                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()


                        MsgBox("Successfully saved.", MsgBoxStyle.Information, "")

                        If frm = "tripdispatch" Then
                            tripdispatch.edited = True
                        ElseIf frm = "viewstep1" Then
                            viewstep1.edited = True
                        End If

                        Me.Close()
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtnew_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtnew.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Trim(txtnew.Text) = "" And Asc(e.KeyChar) = 48 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btnok.PerformClick()
        End If
    End Sub

    Private Sub txtnow_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtnew.TextChanged
        Try
            Dim charactersDisallowed As String = "toflwTOFLW 1234567890"
            Dim theText As String = txtnew.Text
            Dim Letter As String
            Dim SelectionIndex As Integer = txtnew.SelectionStart
            Dim Change As Integer

            For x As Integer = 0 To txtnew.Text.Length - 1
                Letter = txtnew.Text.Substring(x, 1)
                If Not charactersDisallowed.Contains(Letter) Then
                    theText = theText.Replace(Letter, String.Empty)
                    Change = 1
                End If
            Next

            txtnew.Text = theText.ToUpper
            txtnew.Select(SelectionIndex - Change, 0)

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class