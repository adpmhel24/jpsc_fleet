﻿Imports System.IO
Imports System.Data.SqlClient

Public Class sign
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public yescnf As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub cmdSign_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        sigPlusNET1.SetTabletState(1)
    End Sub

    Private Sub cmdStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdStop.Click
        sigPlusNET1.SetTabletState(0)
    End Sub

    Private Sub cmdClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclear1.Click
        sigPlusNET1.ClearTablet()
    End Sub

    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Application.Exit()
    End Sub

    Private Sub cmdSaveImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSaveImage.Click
        'this sub shows how to create an IMAGE of your signature
        'it is important to note that an image contains no biometric info,
        'nor can be encrypted. If your goal is to store a biometric signature,
        'please look into storing either the SigString or a SIG file


        Dim fd As SaveFileDialog
        'fd = New SaveFileDialog()

        'fd.Filter = "BMP Files (*.bmp)|*.bmp|JPG Files (*.jpg)|*.jpg|TIF Files (*.tif)|*.tif"

        sigPlusNET1.SetImageXSize(255)   '255, 136
        sigPlusNET1.SetImageYSize(136)
        sigPlusNET1.SetJustifyMode(5)

        Dim myimage As Image

        'fd.FilterIndex = 1
        'fd.ShowDialog()

        'using the Save method, you can write out the image format
        'of choice...be sure to match the format in SigPlus using the
        'SetImageFileFormat() method...4=JPG, 0=BMP, 6=TIF

        'pictureBox1.Image = sigPlusNET1.GetSigImage()

        'Form1.PictureBox1.Image = pictureBox1.Image
        'Form1.ShowDialog()

        If (fd.FileName <> "") Then
            If (fd.FilterIndex = 1) Then
                myimage = sigPlusNET1.GetSigImage()
                myimage.Save(fd.FileName, System.Drawing.Imaging.ImageFormat.Bmp)
            ElseIf (fd.FilterIndex = 2) Then
                myimage = sigPlusNET1.GetSigImage()
                myimage.Save(fd.FileName, System.Drawing.Imaging.ImageFormat.Jpeg)

                'pictureBox1.Image = sigPlusNET1.GetSigImage()
            ElseIf (fd.FilterIndex = 3) Then
                myimage = sigPlusNET1.GetSigImage()
                myimage.Save(fd.FileName, System.Drawing.Imaging.ImageFormat.Tiff)
            End If
        End If

        sigPlusNET1.SetJustifyMode(0)
    End Sub

    Private Sub cmdSaveSig_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSaveSig.Click
        'this sub shows how to save an encrypted, biometric signature
        'the AutoKey() methods below are used to perform the encryption process.
        'use SetAutoKeyData() to pass in the data you wish the signature to be
        'encrypted using. Later, to retrieve the signature, the data passed in
        'must match or the signature will not be returned. This way, you can
        'insure that the signature's context is that data, and that data alone.
        'Topaz recommends you mimic a "pen and paper" application in your choice
        'of data used for encryption. What is it the signer is reading and agreeing to?
        'this is typically the choice for encryption data
        'compression is used to make the size of the signature smaller, taking up less
        'storage space

        Dim fd As SaveFileDialog
        fd = New SaveFileDialog()

        fd.Filter = "SIG Files (*.sig)|*.sig"
        fd.FilterIndex = 1
        fd.ShowDialog()

        sigPlusNET1.SetSigCompressionMode(0)
        sigPlusNET1.SetEncryptionMode(0)
        sigPlusNET1.SetKeyString("0000000000000000")

        If (fd.FileName <> "") Then
            If (cboEncryption.Text <> "0") Then
                sigPlusNET1.AutoKeyStart()
                sigPlusNET1.SetAutoKeyData("the signature will be encrypted to this data")
                sigPlusNET1.SetAutoKeyData("I can add as much as I like")
                sigPlusNET1.AutoKeyFinish()
            End If
        End If

        sigPlusNET1.SetEncryptionMode(System.Convert.ToInt32(cboEncryption.Text))
        sigPlusNET1.SetSigCompressionMode(System.Convert.ToInt32(cboCompression.Text))
        sigPlusNET1.ExportSigFile(fd.FileName)
    End Sub

    Private Sub cmdLoadSig_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLoadSig.Click
        'this sub shows how to return an encrypted, biometric signature
        'if the data passed into SetAutoKeyData() matches the data
        'used when the signature was originally encrypted, the signature
        'will be returned and automatically rendered

        Dim fd As OpenFileDialog
        fd = New OpenFileDialog()

        fd.Filter = "SIG Files (*.sig)|*.sig"
        fd.FilterIndex = 1
        fd.ShowDialog()


        If (fd.FileName <> "") Then
            sigPlusNET1.SetSigCompressionMode(0)
            sigPlusNET1.SetEncryptionMode(0)
            sigPlusNET1.SetKeyString("0000000000000000")

            If (cboEncryption.Text <> "0") Then
                sigPlusNET1.AutoKeyStart()
                sigPlusNET1.SetAutoKeyData("the signature will be encrypted to this data")
                sigPlusNET1.SetAutoKeyData("I can add as much as I like")
                sigPlusNET1.AutoKeyFinish()
            End If

            sigPlusNET1.SetEncryptionMode(System.Convert.ToInt32(cboEncryption.Text))
            sigPlusNET1.SetSigCompressionMode(System.Convert.ToInt32(cboCompression.Text))

            Try
                sigPlusNET1.ImportSigFile(fd.FileName)
            Catch
                MessageBox.Show("Please check your SigCompressionMode and EncryptionMode settings.")
            End Try

            '************************************************************
            'alternately, you can return a SigString
            'ideal for database storage, as in:

            'sigPlusNET1.SetSigString(strMySig);

            'store strMySig wherever you wish, as an ASCII hex string
            '************************************************************

            If (sigPlusNET1.NumberOfTabletPoints() > 0) Then
                'the signature was successfully returned!
            End If
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboPenWidth.SelectedIndexChanged
        'set the thickness of the ink in pixels
        sigPlusNET1.SetImagePenWidth(System.Convert.ToInt32(1))
        sigPlusNET1.SetDisplayPenWidth(System.Convert.ToInt32(5))
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        sigPlusNET1.SetTabletState(0)
        SigPlusNET2.SetTabletState(0)
        SigPlusNET3.SetTabletState(0)
        SigPlusNET4.SetTabletState(0)
        sigPlusNET1.ClearTablet()
        SigPlusNET2.ClearTablet()
        SigPlusNET3.ClearTablet()
        SigPlusNET4.ClearTablet()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Button1.Focus()

        sigPlusNET1.SetTabletState(1)
        GroupBox1.BackColor = Color.SeaGreen
        GroupBox1.ForeColor = Color.White
        btnclear1.ForeColor = Color.Black

        SigPlusNET2.SetTabletState(0)
        GroupBox2.BackColor = Color.WhiteSmoke
        GroupBox2.ForeColor = Color.Black
        btnclear2.ForeColor = Color.Black

        SigPlusNET3.SetTabletState(0)
        GroupBox3.BackColor = Color.WhiteSmoke
        GroupBox3.ForeColor = Color.Black
        btnclear3.ForeColor = Color.Black

        SigPlusNET4.SetTabletState(0)
        GroupBox4.BackColor = Color.WhiteSmoke
        GroupBox4.ForeColor = Color.Black
        btnclear4.ForeColor = Color.Black

        If tripdispatch.wctab = "tab3" Then
            GroupBox3.Text = "Checker Senior"
        Else
            GroupBox3.Text = "Other"
        End If

        If GroupBox4.Text <> "Helper ()" And GroupBox4.Text <> "Helper" Then
            GroupBox4.Enabled = True
        Else
            GroupBox4.Enabled = False
        End If

        If tripdispatch.wctab <> "tab81" And tripdispatch.wctab <> "tab2" Then
            GroupBox2.Visible = True
        Else
            GroupBox2.Visible = False
        End If
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim myimage As Image
        Dim myimage1 As Image

        sigPlusNET1.SetImageXSize(320)   '320, 136
        sigPlusNET1.SetImageYSize(136)
        sigPlusNET1.SetJustifyMode(0)

        SigPlusNET2.SetImageXSize(320)   '320, 136
        SigPlusNET2.SetImageYSize(136)
        SigPlusNET2.SetJustifyMode(0)

        SigPlusNET3.SetImageXSize(320)   '320, 136
        SigPlusNET3.SetImageYSize(136)
        SigPlusNET3.SetJustifyMode(0)

        SigPlusNET4.SetImageXSize(320)   '320, 136
        SigPlusNET4.SetImageYSize(136)
        SigPlusNET4.SetJustifyMode(0)

        If login.whse <> "Cebu" And login.whse <> "Davao" And login.whse <> "Bacolod" And login.whse <> "Tacloban" Then

            If GroupBox4.Text <> "Helper ()" And GroupBox4.Text <> "Helper" Then
                GroupBox4.Enabled = True
                If sigPlusNET1.GetNumberOfStrokes = 0 And SigPlusNET4.GetNumberOfStrokes = 0 Then
                    MsgBox("Please sign " & GroupBox1.Text & " or " & GroupBox4.Text & ".", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                ElseIf sigPlusNET1.GetNumberOfStrokes <> 0 And SigPlusNET4.GetNumberOfStrokes = 0 Then
                    myimage = sigPlusNET1.GetSigImage()
                    imgdriver.Image = myimage
                ElseIf sigPlusNET1.GetNumberOfStrokes = 0 And SigPlusNET4.GetNumberOfStrokes <> 0 Then
                    myimage1 = SigPlusNET4.GetSigImage()
                    imghelper.Image = myimage1
                ElseIf sigPlusNET1.GetNumberOfStrokes <> 0 And SigPlusNET4.GetNumberOfStrokes <> 0 Then
                    myimage = sigPlusNET1.GetSigImage()
                    imgdriver.Image = myimage
                    myimage1 = SigPlusNET4.GetSigImage()
                    imghelper.Image = myimage1
                End If
            Else
                GroupBox4.Enabled = False
                If sigPlusNET1.GetNumberOfStrokes = 0 Then
                    MsgBox("Please sign " & GroupBox1.Text & ".", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                Else
                    myimage = sigPlusNET1.GetSigImage()
                    imgdriver.Image = myimage
                End If
            End If

            If tripdispatch.wctab <> "tab81" And tripdispatch.wctab <> "tab2" Then
                GroupBox2.Visible = True
                If SigPlusNET2.GetNumberOfStrokes = 0 Then
                    MsgBox("Please sign " & GroupBox2.Text & ".", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                Else
                    myimage = SigPlusNET2.GetSigImage()
                    imgguard.Image = myimage
                End If
            End If

            If SigPlusNET3.GetNumberOfStrokes = 0 Then
                'MsgBox("Please sign (Other).", MsgBoxStyle.Exclamation, "")
                'Exit Sub
                If tripdispatch.wctab = "tab3" Then
                    MsgBox("Please sign " & GroupBox3.Text & ".", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
            Else
                myimage = SigPlusNET3.GetSigImage()
                imgother.Image = myimage
            End If
        End If

        '/MsgBox("save to db and confirm what selected tab or step")
        ExecuteConfirm(strconn)

    End Sub

    Private Sub sigPlusNET1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sigPlusNET1.Click
        sigPlusNET1.SetTabletState(1)
        GroupBox1.BackColor = Color.SeaGreen
        GroupBox1.ForeColor = Color.White
        btnclear1.ForeColor = Color.Black

        SigPlusNET2.SetTabletState(0)
        GroupBox2.BackColor = Color.WhiteSmoke
        GroupBox2.ForeColor = Color.Black
        btnclear2.ForeColor = Color.Black

        SigPlusNET3.SetTabletState(0)
        GroupBox3.BackColor = Color.WhiteSmoke
        GroupBox3.ForeColor = Color.Black
        btnclear3.ForeColor = Color.Black

        SigPlusNET4.SetTabletState(0)
        GroupBox4.BackColor = Color.WhiteSmoke
        GroupBox4.ForeColor = Color.Black
        btnclear4.ForeColor = Color.Black
    End Sub

    Private Sub SigPlusNET2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SigPlusNET2.Click
        sigPlusNET1.SetTabletState(0)
        GroupBox1.BackColor = Color.WhiteSmoke
        GroupBox1.ForeColor = Color.Black
        btnclear1.ForeColor = Color.Black

        SigPlusNET2.SetTabletState(1)
        GroupBox2.BackColor = Color.SeaGreen
        GroupBox2.ForeColor = Color.White
        btnclear2.ForeColor = Color.Black

        SigPlusNET3.SetTabletState(0)
        GroupBox3.BackColor = Color.WhiteSmoke
        GroupBox3.ForeColor = Color.Black
        btnclear3.ForeColor = Color.Black

        SigPlusNET4.SetTabletState(0)
        GroupBox4.BackColor = Color.WhiteSmoke
        GroupBox4.ForeColor = Color.Black
        btnclear4.ForeColor = Color.Black
    End Sub

    Private Sub SigPlusNET3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SigPlusNET3.Click
        sigPlusNET1.SetTabletState(0)
        GroupBox1.BackColor = Color.WhiteSmoke
        GroupBox1.ForeColor = Color.Black
        btnclear1.ForeColor = Color.Black

        SigPlusNET2.SetTabletState(0)
        GroupBox2.BackColor = Color.WhiteSmoke
        GroupBox2.ForeColor = Color.Black
        btnclear2.ForeColor = Color.Black

        SigPlusNET3.SetTabletState(1)
        GroupBox3.BackColor = Color.SeaGreen
        GroupBox3.ForeColor = Color.White
        btnclear3.ForeColor = Color.Black

        SigPlusNET4.SetTabletState(0)
        GroupBox4.BackColor = Color.WhiteSmoke
        GroupBox4.ForeColor = Color.Black
        btnclear4.ForeColor = Color.Black
    End Sub

    Private Sub SigPlusNET4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SigPlusNET4.Click
        sigPlusNET1.SetTabletState(0)
        GroupBox1.BackColor = Color.WhiteSmoke
        GroupBox1.ForeColor = Color.Black
        btnclear1.ForeColor = Color.Black

        SigPlusNET2.SetTabletState(0)
        GroupBox2.BackColor = Color.WhiteSmoke
        GroupBox2.ForeColor = Color.Black
        btnclear2.ForeColor = Color.Black

        SigPlusNET3.SetTabletState(0)
        GroupBox3.BackColor = Color.WhiteSmoke
        GroupBox3.ForeColor = Color.Black
        btnclear3.ForeColor = Color.Black

        SigPlusNET4.SetTabletState(1)
        GroupBox4.BackColor = Color.SeaGreen
        GroupBox4.ForeColor = Color.White
        btnclear4.ForeColor = Color.Black
    End Sub

    Private Sub btnclear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclear2.Click
        SigPlusNET2.ClearTablet()
    End Sub

    Public Sub savepics()
        Try
            Me.Cursor = Cursors.WaitCursor

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnclear3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclear3.Click
        SigPlusNET3.ClearTablet()
    End Sub

    Private Sub btnclear4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclear4.Click
        SigPlusNET4.ClearTablet()
    End Sub

    Private Sub ExecuteConfirm(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            ' Start a local transaction
            transaction = connection.BeginTransaction("SampleTransaction")

            ' Must assign both transaction object and connection 
            ' to Command object for a pending local transaction.
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = "Update tblusers set fullname='" & Trim(txtfull.Text) & "', username='" & Trim(txtusername.Text) & "', password='" & Encrypt(Trim(txtpass.Text)) & "', workgroup='" & Trim(cmbgroup.SelectedItem) & "', whsename='" & Trim(cmbwhse.SelectedItem) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where systemid='" & lbluserid.Text & "' "
                '/command.ExecuteNonQuery()
                'check first what step

                Dim taxitlga As Boolean = False
                Dim data As Byte()
                If tripdispatch.wctab = "tab1" Then '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    'step 1
                    'save distance and odo and diesel
                    sql = "Update tbltripsum set odostart='" & tripdispatch.txtodoend1.Text & "', odoactual='" & tripdispatch.txtodo.Text & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where tripnum='" & lbltrip.Text & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                    If imgdriver.Image IsNot Nothing Then
                        Dim ms As New MemoryStream()
                        sql = "Insert into tbldispatchstp1 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox1.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgdriver.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms.GetBuffer()
                        Dim img As New SqlParameter("@img", SqlDbType.Image)
                        img.Value = data
                        command.Parameters.Add(img)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imghelper.Image IsNot Nothing Then
                        Dim ms2 As New MemoryStream()
                        sql = "Insert into tbldispatchstp1 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox4.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imghelper.Image.Save(ms2, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms2.GetBuffer()
                        Dim img2 As New SqlParameter("@img", SqlDbType.Image)
                        img2.Value = data
                        command.Parameters.Add(img2)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imgguard.Image IsNot Nothing Then
                        Dim ms1 As New MemoryStream()
                        sql = "Insert into tbldispatchstp1 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox2.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgguard.Image.Save(ms1, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms1.GetBuffer()
                        Dim img1 As New SqlParameter("@img", SqlDbType.Image)
                        img1.Value = data
                        command.Parameters.Add(img1)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imgother.Image IsNot Nothing Then
                        Dim ms2 As New MemoryStream()
                        sql = "Insert into tbldispatchstp1 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox3.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgother.Image.Save(ms2, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms2.GetBuffer()
                        Dim img2 As New SqlParameter("@img", SqlDbType.Image)
                        img2.Value = data
                        command.Parameters.Add(img2)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    'step1
                    sql = "Update tbldispatchsum set step1='1', namestp1='" & login.cashier & "', datestp1=GetDate(), mneymstp1='" & login.cashier & "', mdeytstp1=GetDate(), remstp1='" & lblrems.Text & "' where tripnum='" & lbltrip.Text & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                ElseIf tripdispatch.wctab = "tab2" Then '///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    'step 2
                    'save distance and odo and diesel
                    sql = "Update tbltripsum set diswith='" & tripdispatch.txtdiswith.Text & "', diswout='" & tripdispatch.txtdiswout.Text & "', dshould='" & tripdispatch.txtdshould.Text & "', dieselbeg='" & tripdispatch.txtdieselbeg1.Text & "',"
                    sql = sql & " dieselactual='" & tripdispatch.txtdiesel.Text & "', podiesel='" & tripdispatch.txtpo.Text & "', addpo='" & tripdispatch.txtaddpo.Text & "', pwith='" & tripdispatch.lblpwith.Text & "', pwout='" & tripdispatch.lblpwout.Text & "', twoinch='" & tripdispatch.lblinch.Text & "', fulltank='" & tripdispatch.lblfull.Text & "', datemodified=GetDate(),modifiedby='" & login.cashier & "' where tripnum='" & lbltrip.Text & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                    If imgdriver.Image IsNot Nothing Then
                        Dim ms As New MemoryStream()
                        sql = "Insert into tbldispatchstp2 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox1.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgdriver.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms.GetBuffer()
                        Dim img As New SqlParameter("@img", SqlDbType.Image)
                        img.Value = data
                        command.Parameters.Add(img)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    'step2
                    sql = "Update tbldispatchsum set step2='1', namestp2='" & login.cashier & "', datestp2=GetDate(), mneymstp2='" & login.cashier & "', mdeytstp2=GetDate(), remstp2='" & lblrems.Text & "' where tripnum='" & lbltrip.Text & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                ElseIf tripdispatch.wctab = "tab3" Then '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    'step 3
                    'save no of labor
                    sql = "Update tbltripsum set loadscale='" & Val(tripdispatch.txtlabor.Text) & "',datemodified=GetDate(),modifiedby='" & confirmchecker.checkerneym & "' where tripnum='" & lbltrip.Text & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                    If imgdriver.Image IsNot Nothing Then
                        Dim ms As New MemoryStream()
                        sql = "Insert into tbldispatchstp3 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox1.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgdriver.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms.GetBuffer()
                        Dim img As New SqlParameter("@img", SqlDbType.Image)
                        img.Value = data
                        command.Parameters.Add(img)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imghelper.Image IsNot Nothing Then
                        Dim ms2 As New MemoryStream()
                        sql = "Insert into tbldispatchstp3 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox4.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imghelper.Image.Save(ms2, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms2.GetBuffer()
                        Dim img2 As New SqlParameter("@img", SqlDbType.Image)
                        img2.Value = data
                        command.Parameters.Add(img2)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imgguard.Image IsNot Nothing Then
                        Dim ms1 As New MemoryStream()
                        sql = "Insert into tbldispatchstp3 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox2.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgguard.Image.Save(ms1, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms1.GetBuffer()
                        Dim img1 As New SqlParameter("@img", SqlDbType.Image)
                        img1.Value = data
                        command.Parameters.Add(img1)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imgother.Image IsNot Nothing Then
                        Dim ms2 As New MemoryStream()
                        sql = "Insert into tbldispatchstp3 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox3.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgother.Image.Save(ms2, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms2.GetBuffer()
                        Dim img2 As New SqlParameter("@img", SqlDbType.Image)
                        img2.Value = data
                        command.Parameters.Add(img2)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    'step3
                    sql = "Update tbldispatchsum set step3='1', namestp3='" & confirmchecker.checkerneym & "', datestp3=GetDate(), mneymstp3='" & confirmchecker.checkerneym & "', mdeytstp3=GetDate(), remstp3='" & lblrems.Text & "' where tripnum='" & lbltrip.Text & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                    ElseIf tripdispatch.wctab = "tab4" Then '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        'step 4
                        For Each row As DataGridViewRow In tripdispatch.grdtrans4.Rows
                            Dim trn As String = tripdispatch.grdtrans4.Rows(row.Index).Cells(1).Value
                            Dim arn As String = Trim(tripdispatch.grdtrans4.Rows(row.Index).Cells(7).Value.ToString)
                            Dim rdr As String = Trim(tripdispatch.grdtrans4.Rows(row.Index).Cells(8).Value.ToString)
                            Dim drn As String = Trim(tripdispatch.grdtrans4.Rows(row.Index).Cells(9).Value.ToString)
                            Dim dnn As String = Trim(tripdispatch.grdtrans4.Rows(row.Index).Cells(10).Value.ToString)
                            Dim itr As String = Trim(tripdispatch.grdtrans4.Rows(row.Index).Cells(11).Value.ToString)
                            Dim notes As String = Trim(tripdispatch.grdtrans4.Rows(row.Index).Cells(13).Value.ToString)

                            sql = "Update tblortrans set arnum='" & arn & "', rdrnum='" & rdr & "', drnum='" & drn & "', dnnum='" & dnn & "', itrnum='" & itr & "', notes='" & notes & "', datemodified=GetDate() where transnum='" & trn & "'"
                            command.CommandText = sql
                            command.ExecuteNonQuery()
                        Next

                        If imgdriver.Image IsNot Nothing Then
                            Dim ms As New MemoryStream()
                        sql = "Insert into tbldispatchstp4 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                            command.CommandText = sql
                            command.Parameters.Clear()
                            command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                            command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox1.Text) & " Signature"))
                            command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                            imgdriver.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                            data = ms.GetBuffer()
                            Dim img As New SqlParameter("@img", SqlDbType.Image)
                            img.Value = data
                        command.Parameters.Add(img)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                            command.ExecuteNonQuery()
                        End If

                        If imghelper.Image IsNot Nothing Then
                            Dim ms2 As New MemoryStream()
                        sql = "Insert into tbldispatchstp4 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                            command.CommandText = sql
                            command.Parameters.Clear()
                            command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                            command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox4.Text) & " Signature"))
                            command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                            imghelper.Image.Save(ms2, System.Drawing.Imaging.ImageFormat.Png)
                            data = ms2.GetBuffer()
                            Dim img2 As New SqlParameter("@img", SqlDbType.Image)
                            img2.Value = data
                        command.Parameters.Add(img2)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                            command.ExecuteNonQuery()
                        End If

                    If imgguard.Image IsNot Nothing Then
                        Dim ms1 As New MemoryStream()
                        sql = "Insert into tbldispatchstp4 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox2.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgguard.Image.Save(ms1, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms1.GetBuffer()
                        Dim img1 As New SqlParameter("@img", SqlDbType.Image)
                        img1.Value = data
                        command.Parameters.Add(img1)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imgother.Image IsNot Nothing Then
                        Dim ms2 As New MemoryStream()
                        sql = "Insert into tbldispatchstp4 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox3.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgother.Image.Save(ms2, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms2.GetBuffer()
                        Dim img2 As New SqlParameter("@img", SqlDbType.Image)
                        img2.Value = data
                        command.Parameters.Add(img2)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    'step4
                    sql = "Update tbldispatchsum set step4='1', namestp4='" & login.cashier & "', datestp4=GetDate(), mneymstp4='" & login.cashier & "', mdeytstp4=GetDate(), remstp4='" & lblrems.Text & "' where tripnum='" & lbltrip.Text & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                ElseIf tripdispatch.wctab = "tab5" Then '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    'step 5
                    If imgdriver.Image IsNot Nothing Then
                        Dim ms As New MemoryStream()
                        sql = "Insert into tbldispatchstp5 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox1.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgdriver.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms.GetBuffer()
                        Dim img As New SqlParameter("@img", SqlDbType.Image)
                        img.Value = data
                        command.Parameters.Add(img)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imghelper.Image IsNot Nothing Then
                        Dim ms2 As New MemoryStream()
                        sql = "Insert into tbldispatchstp5 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox4.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imghelper.Image.Save(ms2, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms2.GetBuffer()
                        Dim img2 As New SqlParameter("@img", SqlDbType.Image)
                        img2.Value = data
                        command.Parameters.Add(img2)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imgguard.Image IsNot Nothing Then
                        Dim ms1 As New MemoryStream()
                        sql = "Insert into tbldispatchstp5 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox2.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgguard.Image.Save(ms1, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms1.GetBuffer()
                        Dim img1 As New SqlParameter("@img", SqlDbType.Image)
                        img1.Value = data
                        command.Parameters.Add(img1)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imgother.Image IsNot Nothing Then
                        Dim ms2 As New MemoryStream()
                        sql = "Insert into tbldispatchstp5 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox3.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgother.Image.Save(ms2, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms2.GetBuffer()
                        Dim img2 As New SqlParameter("@img", SqlDbType.Image)
                        img2.Value = data
                        command.Parameters.Add(img2)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    'step5
                    sql = "Update tbldispatchsum set step5='1', namestp5='" & login.cashier & "', datestp5=GetDate(), mneymstp5='" & login.cashier & "', mdeytstp5=GetDate(), remstp5='" & lblrems.Text & "' where tripnum='" & lbltrip.Text & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                ElseIf tripdispatch.wctab = "tab6" Or tripdispatch.wctab = "tab61" Then '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    'walang sign sa step6 kahit hindi guard ang mag confirm

                ElseIf tripdispatch.wctab = "tab7" Then '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    'step 7
                    For Each row As DataGridViewRow In tripdispatch.grdtrans7.Rows
                        Dim trn As String = tripdispatch.grdtrans7.Rows(row.Index).Cells(1).Value
                        Dim arn As String = Trim(tripdispatch.grdtrans7.Rows(row.Index).Cells(6).Value.ToString)
                        Dim rdr As String = Trim(tripdispatch.grdtrans7.Rows(row.Index).Cells(7).Value.ToString)
                        Dim drn As String = Trim(tripdispatch.grdtrans7.Rows(row.Index).Cells(8).Value.ToString)
                        Dim dnn As String = Trim(tripdispatch.grdtrans7.Rows(row.Index).Cells(9).Value.ToString)
                        Dim itr As String = Trim(tripdispatch.grdtrans7.Rows(row.Index).Cells(10).Value.ToString)
                        Dim it As String = Trim(tripdispatch.grdtrans7.Rows(row.Index).Cells(11).Value.ToString)
                        Dim grpo As String = Trim(tripdispatch.grdtrans7.Rows(row.Index).Cells(12).Value.ToString)
                        Dim notes As String = Trim(tripdispatch.grdtrans7.Rows(row.Index).Cells(14).Value.ToString)

                        sql = "Update tblortrans set arnum='" & arn & "', rdrnum='" & rdr & "', drnum='" & drn & "', dnnum='" & dnn & "', itrnum='" & itr & "', itnum='" & it & "', grponum='" & grpo & "', notes='" & notes & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where transnum='" & trn & "'"
                        command.CommandText = sql
                        command.ExecuteNonQuery()
                    Next

                    If imgdriver.Image IsNot Nothing Then
                        Dim ms As New MemoryStream()
                        sql = "Insert into tbldispatchstp7 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox1.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgdriver.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms.GetBuffer()
                        Dim img As New SqlParameter("@img", SqlDbType.Image)
                        img.Value = data
                        command.Parameters.Add(img)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imghelper.Image IsNot Nothing Then
                        Dim ms2 As New MemoryStream()
                        sql = "Insert into tbldispatchstp7 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox4.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imghelper.Image.Save(ms2, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms2.GetBuffer()
                        Dim img2 As New SqlParameter("@img", SqlDbType.Image)
                        img2.Value = data
                        command.Parameters.Add(img2)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imgguard.Image IsNot Nothing Then
                        Dim ms1 As New MemoryStream()
                        sql = "Insert into tbldispatchstp7 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox2.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgguard.Image.Save(ms1, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms1.GetBuffer()
                        Dim img1 As New SqlParameter("@img", SqlDbType.Image)
                        img1.Value = data
                        command.Parameters.Add(img1)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    If imgother.Image IsNot Nothing Then
                        Dim ms2 As New MemoryStream()
                        sql = "Insert into tbldispatchstp7 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.CommandText = sql
                        command.Parameters.Clear()
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox3.Text) & " Signature"))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        imgother.Image.Save(ms2, System.Drawing.Imaging.ImageFormat.Png)
                        data = ms2.GetBuffer()
                        Dim img2 As New SqlParameter("@img", SqlDbType.Image)
                        img2.Value = data
                        command.Parameters.Add(img2)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If

                    'step7 'update withpending = false
                    sql = "Update tbldispatchsum set withpending='0', step7='1', namestp7='" & login.cashier & "', datestp7=GetDate(), mneymstp7='" & login.cashier & "', mdeytstp7=GetDate(), remstp7='" & lblrems.Text & "' where tripnum='" & lbltrip.Text & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                ElseIf tripdispatch.wctab = "tab8" Or tripdispatch.wctab = "tab81" Then '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    'step 8
                    If tripdispatch.wctab = "tab81" Then 'confrim
                        sql = "Update tbltripsum set odoend='" & tripdispatch.txtodoend.Text & "', dieselend='" & tripdispatch.txtdieselend.Text & "', postaddpo='" & tripdispatch.txtpostpo.Text & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where tripnum='" & lbltrip.Text & "'"

                    ElseIf tripdispatch.wctab = "tab8" Then 'repair
                        sql = "Update tbltripsum set odoend='" & tripdispatch.txtodoend.Text & "', dieselend='" & tripdispatch.txtdieselend.Text & "', postaddpo='" & tripdispatch.txtpostpo.Text & "', repair='1', datemodified=GetDate(), modifiedby='" & login.cashier & "' where tripnum='" & lbltrip.Text & "'"
                    End If
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                    Dim genid As Integer = 0
                    sql = "Select * from tblgeneral where platenum='" & lblplate.Text & "'"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    If dr.Read Then
                        genid = dr("genid")
                    End If
                    dr.Dispose()

                    sql = "Update tblpmssched set endodo='" & tripdispatch.txtodoend.Text & "' where genid='" & genid & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                    If tripdispatch.wctab = "tab81" Then
                        If imgdriver.Image IsNot Nothing Then
                            Dim ms As New MemoryStream()
                            sql = "Insert into tbldispatchstp8 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                            command.CommandText = sql
                            command.Parameters.Clear()
                            command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                            command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox1.Text) & " Signature"))
                            command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                            imgdriver.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                            data = ms.GetBuffer()
                            Dim img As New SqlParameter("@img", SqlDbType.Image)
                            img.Value = data
                            command.Parameters.Add(img)
                            '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                            command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                            command.ExecuteNonQuery()
                        End If
                    Else
                        If imgdriver.Image IsNot Nothing Then
                            Dim ms As New MemoryStream()
                            sql = "Insert into tbldispatchstp8 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                            command.CommandText = sql
                            command.Parameters.Clear()
                            command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                            command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox1.Text) & " Signature"))
                            command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                            imgdriver.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                            data = ms.GetBuffer()
                            Dim img As New SqlParameter("@img", SqlDbType.Image)
                            img.Value = data
                            command.Parameters.Add(img)
                            '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                            command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                            command.ExecuteNonQuery()
                        End If

                        If imgguard.Image IsNot Nothing Then
                            Dim ms1 As New MemoryStream()
                            sql = "Insert into tbldispatchstp8 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                            command.CommandText = sql
                            command.Parameters.Clear()
                            command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                            command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox2.Text) & " Signature"))
                            command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                            imgguard.Image.Save(ms1, System.Drawing.Imaging.ImageFormat.Png)
                            data = ms1.GetBuffer()
                            Dim img1 As New SqlParameter("@img", SqlDbType.Image)
                            img1.Value = data
                            command.Parameters.Add(img1)
                            '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                            command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                            command.ExecuteNonQuery()
                        End If

                        If imgother.Image IsNot Nothing Then
                            Dim ms2 As New MemoryStream()
                            sql = "Insert into tbldispatchstp8 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                            command.CommandText = sql
                            command.Parameters.Clear()
                            command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                            command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox3.Text) & " Signature"))
                            command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                            imgother.Image.Save(ms2, System.Drawing.Imaging.ImageFormat.Png)
                            data = ms2.GetBuffer()
                            Dim img2 As New SqlParameter("@img", SqlDbType.Image)
                            img2.Value = data
                            command.Parameters.Add(img2)
                            '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                            command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                            command.ExecuteNonQuery()
                        End If

                        If imghelper.Image IsNot Nothing Then
                            Dim ms2 As New MemoryStream()
                            sql = "Insert into tbldispatchstp8 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                            command.CommandText = sql
                            command.Parameters.Clear()
                            command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltrip.Text))
                            command.Parameters.Add(New SqlClient.SqlParameter("name", Trim(GroupBox4.Text) & " Signature"))
                            command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                            imghelper.Image.Save(ms2, System.Drawing.Imaging.ImageFormat.Png)
                            data = ms2.GetBuffer()
                            Dim img2 As New SqlParameter("@img", SqlDbType.Image)
                            img2.Value = data
                            command.Parameters.Add(img2)
                            '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                            command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                            command.ExecuteNonQuery()
                        End If
                    End If

                    'step8
                    sql = "Update tbldispatchsum set step8='1', namestp8='" & login.cashier & "', datestp8=GetDate(), mneymstp8='" & login.cashier & "', mdeytstp8=GetDate(), remstp8='" & lblrems.Text & "' where tripnum='" & lbltrip.Text & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                    If tripdispatch.lbltaxi.Text = "Taxi" Then
                        taxitlga = True
                        'check kung walang status 1 or 2 or 4 or 5 sa tbltripitems
                        sql = "Select status from tbltripitems where tripnum='" & lbltrip.Text & "' and (status='1' or status='2' or status='4' or status='5')"
                        command.CommandText = sql
                        dr = command.ExecuteReader
                        If dr.Read Then
                            taxitlga = False
                        End If
                        dr.Dispose()

                        If taxitlga = True Then
                            'step9
                            sql = "Update tbldispatchsum set complete='1', step9='1' where tripnum='" & lbltrip.Text & "'"
                            command.CommandText = sql
                            command.ExecuteNonQuery()

                            sql = "Update tbltripsum set status='2', datemodified=GetDate(), modifiedby='" & login.cashier & "' where tripnum='" & lbltrip.Text & "'"
                            command.CommandText = sql
                            command.ExecuteNonQuery()
                        End If
                    End If

                ElseIf tripdispatch.wctab = "tab9" Then '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    'step 9
                    'puro password lang sa step9
                End If

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                imgdriver.Image = Nothing
                imgdriver.BackColor = Color.Empty
                imgdriver.Invalidate()
                imghelper.Image = Nothing
                imghelper.BackColor = Color.Empty
                imghelper.Invalidate()
                imgguard.Image = Nothing
                imgguard.BackColor = Color.Empty
                imgguard.Invalidate()
                imgother.Image = Nothing
                imgother.BackColor = Color.Empty
                imgother.Invalidate()

                yescnf = True
                If tripdispatch.wctab = "tab9" Or taxitlga = True Then
                    MsgBox("STEPS COMPLETED.", MsgBoxStyle.Information, "")
                Else
                    MsgBox("PROCCED TO NEXT STEP.", MsgBoxStyle.Information, "")
                End If
                Button1.Focus()
                Me.Close()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                '/Console.WriteLine("Commit Exception Type: {0}", ex.GetType())
                '/Console.WriteLine("  Message: {0}", ex.Message)
                '/Dim typeName = ex.GetType().Name
                MsgBox("1: " & ex.ToString, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    ' This catch block will handle any errors that may have occurred 
                    ' on the server that would cause the rollback to fail, such as 
                    ' a closed connection.
                    Me.Cursor = Cursors.Default
                    '/Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType())
                    '/Console.WriteLine("  Message: {0}", ex2.Message)
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub
End Class
