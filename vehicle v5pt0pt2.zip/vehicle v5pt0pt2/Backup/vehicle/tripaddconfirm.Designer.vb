﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class tripaddconfirm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(tripaddconfirm))
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.chkpick = New System.Windows.Forms.CheckBox
        Me.lblmake = New System.Windows.Forms.Label
        Me.lblvtype = New System.Windows.Forms.Label
        Me.txthelper = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtetd = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.lbltripnum = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtrems = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtorigin = New System.Windows.Forms.TextBox
        Me.txtdatepick = New System.Windows.Forms.TextBox
        Me.txtdriver = New System.Windows.Forms.TextBox
        Me.txtplate = New System.Windows.Forms.TextBox
        Me.grd = New System.Windows.Forms.DataGridView
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column1 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.btnadd = New System.Windows.Forms.Button
        Me.btncancel = New System.Windows.Forms.Button
        Me.lblpick = New System.Windows.Forms.Label
        Me.lblassigned = New System.Windows.Forms.Label
        Me.GroupBox2.SuspendLayout()
        CType(Me.grd, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.lblassigned)
        Me.GroupBox2.Controls.Add(Me.chkpick)
        Me.GroupBox2.Controls.Add(Me.lblmake)
        Me.GroupBox2.Controls.Add(Me.lblvtype)
        Me.GroupBox2.Controls.Add(Me.txthelper)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.txtetd)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.lbltripnum)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txtrems)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.txtorigin)
        Me.GroupBox2.Controls.Add(Me.txtdatepick)
        Me.GroupBox2.Controls.Add(Me.txtdriver)
        Me.GroupBox2.Controls.Add(Me.txtplate)
        Me.GroupBox2.Controls.Add(Me.grd)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(718, 481)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Trip"
        '
        'chkpick
        '
        Me.chkpick.AutoSize = True
        Me.chkpick.Location = New System.Drawing.Point(6, 458)
        Me.chkpick.Name = "chkpick"
        Me.chkpick.Size = New System.Drawing.Size(104, 17)
        Me.chkpick.TabIndex = 23
        Me.chkpick.Text = "Pickup Trip Only"
        Me.chkpick.UseVisualStyleBackColor = True
        Me.chkpick.Visible = False
        '
        'lblmake
        '
        Me.lblmake.AutoSize = True
        Me.lblmake.Location = New System.Drawing.Point(541, 19)
        Me.lblmake.Name = "lblmake"
        Me.lblmake.Size = New System.Drawing.Size(0, 13)
        Me.lblmake.TabIndex = 23
        Me.lblmake.Visible = False
        '
        'lblvtype
        '
        Me.lblvtype.AutoSize = True
        Me.lblvtype.Location = New System.Drawing.Point(539, 75)
        Me.lblvtype.Name = "lblvtype"
        Me.lblvtype.Size = New System.Drawing.Size(0, 13)
        Me.lblvtype.TabIndex = 22
        Me.lblvtype.Visible = False
        '
        'txthelper
        '
        Me.txthelper.BackColor = System.Drawing.Color.White
        Me.txthelper.Location = New System.Drawing.Point(86, 98)
        Me.txthelper.Name = "txthelper"
        Me.txthelper.ReadOnly = True
        Me.txthelper.Size = New System.Drawing.Size(159, 20)
        Me.txthelper.TabIndex = 21
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(39, 101)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 13)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "Helper:"
        '
        'txtetd
        '
        Me.txtetd.BackColor = System.Drawing.Color.White
        Me.txtetd.Location = New System.Drawing.Point(355, 16)
        Me.txtetd.Name = "txtetd"
        Me.txtetd.ReadOnly = True
        Me.txtetd.Size = New System.Drawing.Size(159, 20)
        Me.txtetd.TabIndex = 19
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(317, 19)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "ETD:"
        '
        'lbltripnum
        '
        Me.lbltripnum.AutoSize = True
        Me.lbltripnum.Location = New System.Drawing.Point(86, 19)
        Me.lbltripnum.Name = "lbltripnum"
        Me.lbltripnum.Size = New System.Drawing.Size(31, 13)
        Me.lbltripnum.TabIndex = 17
        Me.lbltripnum.Text = "0000"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(35, 19)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 13)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Trip No:"
        '
        'txtrems
        '
        Me.txtrems.BackColor = System.Drawing.Color.White
        Me.txtrems.Location = New System.Drawing.Point(355, 98)
        Me.txtrems.Name = "txtrems"
        Me.txtrems.ReadOnly = True
        Me.txtrems.Size = New System.Drawing.Size(357, 20)
        Me.txtrems.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(297, 101)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Remarks:"
        '
        'txtorigin
        '
        Me.txtorigin.BackColor = System.Drawing.Color.White
        Me.txtorigin.Location = New System.Drawing.Point(355, 72)
        Me.txtorigin.Name = "txtorigin"
        Me.txtorigin.ReadOnly = True
        Me.txtorigin.Size = New System.Drawing.Size(159, 20)
        Me.txtorigin.TabIndex = 13
        '
        'txtdatepick
        '
        Me.txtdatepick.BackColor = System.Drawing.Color.White
        Me.txtdatepick.Location = New System.Drawing.Point(355, 43)
        Me.txtdatepick.Name = "txtdatepick"
        Me.txtdatepick.ReadOnly = True
        Me.txtdatepick.Size = New System.Drawing.Size(159, 20)
        Me.txtdatepick.TabIndex = 12
        '
        'txtdriver
        '
        Me.txtdriver.BackColor = System.Drawing.Color.White
        Me.txtdriver.Location = New System.Drawing.Point(86, 72)
        Me.txtdriver.Name = "txtdriver"
        Me.txtdriver.ReadOnly = True
        Me.txtdriver.Size = New System.Drawing.Size(159, 20)
        Me.txtdriver.TabIndex = 11
        '
        'txtplate
        '
        Me.txtplate.BackColor = System.Drawing.Color.White
        Me.txtplate.Location = New System.Drawing.Point(86, 43)
        Me.txtplate.Name = "txtplate"
        Me.txtplate.ReadOnly = True
        Me.txtplate.Size = New System.Drawing.Size(159, 20)
        Me.txtplate.TabIndex = 10
        '
        'grd
        '
        Me.grd.AllowUserToAddRows = False
        Me.grd.AllowUserToDeleteRows = False
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grd.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle6
        Me.grd.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grd.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grd.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grd.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.NullValue = Nothing
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.grd.ColumnHeadersHeight = 30
        Me.grd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grd.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column4, Me.Column1, Me.Column2, Me.Column3, Me.Column5, Me.Column6})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.DefaultCellStyle = DataGridViewCellStyle8
        Me.grd.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grd.EnableHeadersVisualStyles = False
        Me.grd.GridColor = System.Drawing.Color.Salmon
        Me.grd.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grd.Location = New System.Drawing.Point(6, 138)
        Me.grd.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grd.Name = "grd"
        Me.grd.ReadOnly = True
        Me.grd.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.grd.RowHeadersWidth = 10
        Me.grd.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.NullValue = Nothing
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.RowsDefaultCellStyle = DataGridViewCellStyle10
        Me.grd.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grd.Size = New System.Drawing.Size(706, 338)
        Me.grd.TabIndex = 9
        '
        'Column4
        '
        Me.Column4.HeaderText = "ID"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Visible = False
        '
        'Column1
        '
        Me.Column1.ActiveLinkColor = System.Drawing.Color.Black
        Me.Column1.HeaderText = "Transaction #"
        Me.Column1.LinkColor = System.Drawing.Color.Red
        Me.Column1.MinimumWidth = 150
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column1.Width = 150
        '
        'Column2
        '
        Me.Column2.HeaderText = "Reference #"
        Me.Column2.MinimumWidth = 150
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 150
        '
        'Column3
        '
        Me.Column3.HeaderText = "Recipient"
        Me.Column3.MinimumWidth = 180
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 180
        '
        'Column5
        '
        Me.Column5.HeaderText = "Transaction Type"
        Me.Column5.MinimumWidth = 180
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Width = 180
        '
        'Column6
        '
        Me.Column6.HeaderText = "Trucking ORO"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        Me.Column6.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(295, 46)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Trip Date:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(312, 75)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Origin:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(42, 75)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 13)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Driver:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(29, 46)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Plate No:"
        '
        'btnadd
        '
        Me.btnadd.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnadd.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Image = CType(resources.GetObject("btnadd.Image"), System.Drawing.Image)
        Me.btnadd.Location = New System.Drawing.Point(544, 504)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(87, 23)
        Me.btnadd.TabIndex = 3
        Me.btnadd.Text = "Confirm"
        Me.btnadd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnadd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'btncancel
        '
        Me.btncancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncancel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.Image = CType(resources.GetObject("btncancel.Image"), System.Drawing.Image)
        Me.btncancel.Location = New System.Drawing.Point(637, 504)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(93, 23)
        Me.btncancel.TabIndex = 4
        Me.btncancel.Text = "Cancel"
        Me.btncancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'lblpick
        '
        Me.lblpick.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblpick.Font = New System.Drawing.Font("HoloLens MDL2 Assets", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpick.Location = New System.Drawing.Point(9, 504)
        Me.lblpick.Name = "lblpick"
        Me.lblpick.Size = New System.Drawing.Size(517, 23)
        Me.lblpick.TabIndex = 5
        Me.lblpick.Text = "PICKUP TRIP ONLY"
        Me.lblpick.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblpick.Visible = False
        '
        'lblassigned
        '
        Me.lblassigned.AutoSize = True
        Me.lblassigned.Location = New System.Drawing.Point(529, 46)
        Me.lblassigned.Name = "lblassigned"
        Me.lblassigned.Size = New System.Drawing.Size(0, 13)
        Me.lblassigned.TabIndex = 24
        Me.lblassigned.Visible = False
        '
        'tripaddconfirm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(742, 542)
        Me.Controls.Add(Me.lblpick)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.GroupBox2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "tripaddconfirm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Trip Confirmation"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.grd, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents grd As System.Windows.Forms.DataGridView
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents txtorigin As System.Windows.Forms.TextBox
    Friend WithEvents txtdatepick As System.Windows.Forms.TextBox
    Friend WithEvents txtdriver As System.Windows.Forms.TextBox
    Friend WithEvents txtplate As System.Windows.Forms.TextBox
    Friend WithEvents txtrems As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbltripnum As System.Windows.Forms.Label
    Friend WithEvents txtetd As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txthelper As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblvtype As System.Windows.Forms.Label
    Friend WithEvents lblmake As System.Windows.Forms.Label
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents chkpick As System.Windows.Forms.CheckBox
    Friend WithEvents lblpick As System.Windows.Forms.Label
    Friend WithEvents lblassigned As System.Windows.Forms.Label
End Class
