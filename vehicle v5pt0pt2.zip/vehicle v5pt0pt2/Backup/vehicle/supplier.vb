﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class supplier
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim stat As String
    Public supcnf As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            If Trim(txtsup.Text) = "" Then
                grdsup.Rows.Clear()
                MsgBox("Input supplier name first.", MsgBoxStyle.Exclamation, "")
                txtsup.Focus()
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

            sql = "Select * from tblsupplier where supplier like '%" & Trim(txtsup.Text) & "%'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                grdsup.Rows.Clear()
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdsup.Rows.Add(dr("supid"), dr("code"), dr("supplier"), dr("remarks"), stat)
                txtsup.Text = ""
            Else
                MsgBox("Cannot found " & Trim(txtsup.Text), MsgBoxStyle.Critical, "")
                txtsup.Text = ""
                txtsup.Focus()
            End If
            dr.Dispose()
            cmd.Dispose()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If Trim(txtsup.Text) <> "" And Trim(txtcode.Text) <> "" Then
                supcnf = False
                confirm.ShowDialog()
                If supcnf = True Then
                    sql = "Insert into tblsupplier (code, supplier, remarks, datecreated, createdby, datemodified, modifiedby, status) values('" & Trim(txtcode.Text) & "','" & Trim(txtsup.Text) & "','" & Trim(txtper.Text) & "',GetDate(),'" & login.cashier & "',GetDate(),'" & login.cashier & "','1')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()

                    MsgBox("Successfully Added.", MsgBoxStyle.Information, "")
                    btnview.PerformClick()
                End If

                txtsup.Focus()
                supcnf = False
            Else
                MsgBox("Input supplier name first", MsgBoxStyle.Exclamation, "")
                txtsup.Focus()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            grdsup.Rows.Clear()
            Dim stat As String = ""

            sql = "Select * from tblsupplier"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdsup.Rows.Add(dr("supid"), dr("code"), dr("supplier"), dr("remarks"), stat)
            End While
            dr.Dispose()
            cmd.Dispose()

            If grdsup.Rows.Count = 0 Then
                btnupdate.Enabled = False
            Else
                btnupdate.Enabled = True
            End If

            btncancel.PerformClick()
            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtsup_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtsup.Leave
        sql = "Select * from tblsupplier where supplier='" & Trim(txtsup.Text) & "'"
        connect()
        cmd = New SqlCommand(sql, conn)
        dr = cmd.ExecuteReader
        If dr.Read Then
            MsgBox(Trim(txtsup.Text) & " is already exist", MsgBoxStyle.Information, "")
            btnupdate.Text = "&Update"
            txtsup.Text = ""
            txtsup.Focus()
            Me.Cursor = Cursors.Default
            Exit Sub
        End If
        dr.Dispose()
        cmd.Dispose()
    End Sub

    Private Sub txtsup_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtsup.TextChanged
        If (Trim(txtsup.Text) <> "" Or Trim(txtcode.Text) <> "") Then
            btncancel.Enabled = True
        ElseIf (Trim(txtsup.Text) = "" And Trim(txtcode.Text) = "") And btnupdate.Text = "&Save" Then
            btncancel.Enabled = True
        Else
            btncancel.Enabled = False
        End If

        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/_&"
        Dim theText As String = txtsup.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtsup.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtsup.Text.Length - 1
            Letter = txtsup.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtsup.Text = theText
        txtsup.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtper_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtper.TextChanged
        If (Trim(txtsup.Text) <> "" Or Trim(txtper.Text) <> "") Then
            btncancel.Enabled = True
        ElseIf (Trim(txtsup.Text) = "" And Trim(txtper.Text) = "") And btnupdate.Text = "&Save" Then
            btncancel.Enabled = True
        Else
            btncancel.Enabled = False
        End If

        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtper.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtper.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtper.Text.Length - 1
            Letter = txtper.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtper.Text = theText
        txtper.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub supplier_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub supplier_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
       
    End Sub

    Private Sub supplier_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnview.PerformClick()
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        txtcode.Text = ""
        txtsup.Text = ""
        txtper.Text = ""
        btnupdate.Text = "&Update"
        btnsearch.Enabled = True
        btndeactivate.Enabled = True
        btnadd.Enabled = True
        btncancel.Enabled = False
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdsup.SelectedRows.Count = 1 Or grdsup.SelectedCells.Count = 1 Then
                If btnupdate.Text = "&Update" Then
                    If grdsup.Rows(grdsup.CurrentRow.Index).Cells(4).Value = "Deactivated" Then
                        MsgBox("Cannot update deactivated supplier.", MsgBoxStyle.Exclamation, "")
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    txtcode.Text = grdsup.Rows(grdsup.CurrentRow.Index).Cells(1).Value
                    lblcat.Text = grdsup.Rows(grdsup.CurrentRow.Index).Cells(2).Value
                    txtsup.Text = grdsup.Rows(grdsup.CurrentRow.Index).Cells(2).Value
                    txtper.Text = grdsup.Rows(grdsup.CurrentRow.Index).Cells(3).Value
                    lblid.Text = grdsup.Rows(grdsup.CurrentRow.Index).Cells(0).Value
                    btnsearch.Enabled = False
                    btnadd.Enabled = False
                    btndeactivate.Enabled = False
                    btnupdate.Text = "&Save"
                    btncancel.Enabled = True
                Else
                    'update
                    If Trim(txtsup.Text) = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Supplier name should not be empty.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If

                    supcnf = False
                    confirm.ShowDialog()
                    If supcnf = True Then
                        sql = "Update tblsupplier set code='" & Trim(txtcode.Text) & "', supplier='" & Trim(txtsup.Text) & "', remarks='" & Trim(txtper.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where supid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        If Trim(txtsup.Text) <> Trim(lblcat.Text) Then

                            'update other tbl in database
                            sql = "Update tblgeneral set supplier='" & Trim(txtsup.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where supplier='" & lblcat.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()
                        End If

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    btnupdate.Text = "&Update"
                    btnsearch.Enabled = True
                    btnadd.Enabled = True
                    btndeactivate.Enabled = True
                    btncancel.Enabled = False
                    txtcode.Text = ""
                    txtsup.Text = ""
                    txtper.Text = ""
                    txtsup.Focus()
                    supcnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
                btnview.PerformClick()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btndeactivate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndeactivate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdsup.SelectedRows.Count = 1 Or grdsup.SelectedCells.Count = 1 Then
                lblid.Text = grdsup.Rows(grdsup.CurrentRow.Index).Cells(0).Value
                If btndeactivate.Text = "&Deactivate" Then
                    'check if theres item available status
                    sql = "Select * from tblgeneral where supplier='" & grdsup.Rows(grdsup.CurrentRow.Index).Cells(2).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox("Cannot deactivate. Supplier is still in use.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    supcnf = False
                    confirm.ShowDialog()
                    If supcnf = True Then
                        sql = "Update tblsupplier set status='0', datemodified=GetDate(), modifiedby='" & login.cashier & "' where supid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    supcnf = False
                Else
                    supcnf = False
                    confirm.ShowDialog()
                    If supcnf = True Then
                        sql = "Update tblsupplier set status='1', datemodified=GetDate(), modifiedby='" & login.cashier & "' where supid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    supcnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdsup_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdsup.SelectionChanged
        If grdsup.Rows(grdsup.CurrentRow.Index).Cells(4).Value = "Active" Then
            btndeactivate.Text = "&Deactivate"
        Else
            btndeactivate.Text = "A&ctivate"
        End If
    End Sub

    Private Sub txtcode_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtcode.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtcode_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtcode.Leave
        sql = "Select * from tblsupplier where code='" & Trim(txtcode.Text) & "'"
        connect()
        cmd = New SqlCommand(sql, conn)
        dr = cmd.ExecuteReader
        If dr.Read Then
            MsgBox(Trim(txtcode.Text) & " is already exist", MsgBoxStyle.Information, "")
            btnupdate.Text = "&Update"
            txtcode.Text = ""
            txtcode.Focus()
            Me.Cursor = Cursors.Default
            Exit Sub
        End If
        dr.Dispose()
        cmd.Dispose()
        conn.Close()
    End Sub

    Private Sub txtcode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcode.TextChanged

    End Sub
End Class