﻿Imports System.IO
Imports System.Data.SqlClient
Imports Excel = Microsoft.Office.Interop.Excel

Public Class trans
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public transcnf As Boolean = False, edittrans As Boolean = False
    Dim clickbtn As String = ""

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub tripdispatchsum_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated

    End Sub

    Private Sub tripdispatchsum_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim a As String = MsgBox("Are you sure you want to close?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            '/moduless.Show()
            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub tripdispatchsum_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        cmbcus.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbcus.DropDownStyle = ComboBoxStyle.DropDown
        cmbcus.AutoCompleteSource = AutoCompleteSource.ListItems

        grdtrans.DefaultCellStyle.WrapMode = DataGridViewTriState.NotSet

        datefrom.CustomFormat = "yyyy/MM/dd"
        dateto.CustomFormat = "yyyy/MM/dd"
        datefrom.MaxDate = Date.Now
        dateto.MinDate = datefrom.Value

        grdtrans.Columns(5).Frozen = True

        If login.whse = "C3 Manila" Then
            lbltrans.Text = "O.MNL-"
        ElseIf login.whse = "Calamba" Then
            lbltrans.Text = "O.CAL-"
        ElseIf login.whse = "Pagbilao" Then
            lbltrans.Text = "O.PGB-"
        ElseIf login.whse = "Milaor" Then
            lbltrans.Text = "O.MIL-"
        ElseIf login.whse = "Lc Office" Then
            lbltrans.Text = "O.LCO-"
        ElseIf login.whse = "Cebu" Then
            lbltrans.Text = "O.CEB-"
        ElseIf login.whse = "Davao" Then
            lbltrans.Text = "O.DAV-"
        ElseIf login.whse = "Bacolod" Then
            lbltrans.Text = "O.BCD-"
        ElseIf login.whse = "Tacloban" Then
            lbltrans.Text = "O.TAC-"
        ElseIf login.whse = "JP-Store" Then
            lbltrans.Text = "O.JST-"
        End If

        customer()
        viewall()
    End Sub

    Public Sub viewall()
        Try
            clickbtn = "Pending"

            grdtrans.Rows.Clear()

            'sql = "Select * from tblortrans where tblortrans.status='1'"
            sql = "Select * from tblortrans where whsename='" & login.whse & "' and status='1' and cancel='0' order by deliverydate"
            connect()
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            While drx.Read
                Dim stat As String = "Available"

                grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
            End While
            drx.Dispose()
            cmdx.Dispose()
            conn.Close()


            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        txttrans.Text = ""
        datefrom.Enabled = True
        dateto.Enabled = True
        cmbcus.Enabled = True
        btnsearch.Enabled = True
        datefrom.Value = datefrom.MaxDate

        'txtso.Enabled = True
        'txtpo.Enabled = True
        'txtitr.Enabled = True

        txtso.Text = ""
        txtpo.Text = ""
        txtitr.Text = ""
        txtsws.Text = ""

        viewall()
    End Sub

    Private Sub grdtrans_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans.CellClick

    End Sub

    Private Sub grdtrans_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans.CellContentClick
        Try
            'link
            If e.ColumnIndex = 2 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdtrans.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrans.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdtrans.RowCount <> 0 Then
                    If grdtrans.Item(2, grdtrans.CurrentRow.Index).Value IsNot Nothing Then
                        'MsgBox(grdtrans.Item(12, ii).Value.ToString)
                        viewtrans.Text = "View Transaction"
                        viewtrans.lbltripnum.Text = ""
                        viewtrans.grouptrans.Visible = False
                        viewtrans.txttrans.Text = grdtrans.Item(2, grdtrans.CurrentRow.Index).Value
                        viewtrans.sing = True
                        viewtrans.ShowDialog()
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbcus_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbcus.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbcus_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbcus.Leave
        Try
            If Trim(cmbcus.Text) <> "" Then

                sql = "Select * from tblcustomer where customer='" & Trim(cmbcus.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbcus.SelectedItem = dr("customer")
                Else
                    cmbcus.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

            Else
                cmbcus.SelectedItem = ""
                cmbcus.Text = ""
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub datefrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datefrom.ValueChanged
        dateto.MinDate = datefrom.Value
        customer()
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            clickbtn = "Searched"

            If Trim(txttrans.Text) <> "" Then
                searchtrans()
                Exit Sub
            End If

            If Trim(txtso.Text) <> "" Or Trim(txtpo.Text) <> "" Or Trim(txtitr.Text) <> "" Or Trim(txtsws.Text) <> "" Then
                'searchrefnum()
                searchlahat()
                Exit Sub
            End If

            grdtrans.Rows.Clear()

            sql = "Select * from tblortrans where whsename='" & login.whse & "'" ' where datecreated>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and datecreated<='" & Format(dateto.Value, "yyyy/MM/dd") & "'"
            If txttrans.Text <> "" Then
                'sql = sql & " and transnum='" & txttrans.Text & "'"
            End If

            If cmbcus.Text <> "" Then
                sql = sql & " and customer='" & cmbcus.Text & "'"
            End If

            sql = sql & " order by deliverydate"

            connect()
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            While drx.Read
                If Format(drx("datecreated"), "yyyy/MM/dd") >= Format(datefrom.Value, "yyyy/MM/dd") And Format(drx("datecreated"), "yyyy/MM/dd") <= Format(dateto.Value, "yyyy/MM/dd") Then

                    Dim stat As String = ""
                    If drx("cancel") = 1 Then
                        stat = "Cancelled"
                    ElseIf drx("status") = 1 Then
                        stat = "Available"
                    ElseIf drx("status") = 0 Then
                        stat = "In Process"
                    ElseIf drx("status") = 2 Then
                        stat = "Completed"
                    End If

                    grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                    If stat = "Cancelled" Then
                        grdtrans.Rows(grdtrans.Rows.Count - 1).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                    End If
                End If
            End While
            drx.Dispose()
            cmdx.Dispose()
            conn.Close()

            For Each row As DataGridViewRow In grdtrans.Rows
                Dim stat As String = grdtrans.Rows(row.Index).Cells(14).Value
                If stat = "Completed" Then
                    sql = "Select Top 1 * from tbltripitems where transnum='" & grdtrans.Rows(row.Index).Cells(2).Value & "' order by tripid"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        If dr("status") = 3 Then
                            grdtrans.Rows(row.Index).Cells(14).Value = "Removed"
                        ElseIf dr("status") = 4 Then
                            grdtrans.Rows(row.Index).Cells(14).Value = "Rescheduled"
                        End If
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                End If
            Next


            If grdtrans.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrip_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdtrans.CellMouseClick
        Try
            If grdtrans.RowCount = 0 Then
                Exit Sub
            End If
            grdtrans.BeginEdit(True)
            If e.Button = Windows.Forms.MouseButtons.Right And e.ColumnIndex > -1 And e.RowIndex > -1 Then
                If grdtrans.SelectedCells.Count = 1 Or grdtrans.SelectedRows.Count = 1 Then
                    Dim cell As DataGridViewCell = grdtrans.Rows(e.RowIndex).Cells(e.ColumnIndex)
                    grdtrans.CurrentCell = cell
                    Me.ContextMenuStrip1.Show(Cursor.Position)

                    toolstripitems()
                End If
                
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub toolstripitems()

    End Sub

    Private Sub EditTripToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditTripToolStripMenuItem.Click
        Try
            If grdtrans.SelectedCells.Count = 1 Or grdtrans.SelectedRows.Count = 1 Then
                If grdtrans.Rows(grdtrans.CurrentRow.Index).Cells(1).Value.ToString <> "Completed" And grdtrans.Rows(grdtrans.CurrentRow.Index).Cells(1).Value.ToString <> "Cancel" Then
                    MsgBox(grdtrans.Rows(grdtrans.CurrentRow.Index).Cells(2).Value.ToString)
                End If
            Else
                MsgBox("Select Only One", , "")
                Exit Sub
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txttrans_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttrans.KeyPress
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            searchtrans()
        End If

        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Public Sub searchtrans()
        Try
            grdtrans.Rows.Clear()

            sql = "Select * from tblortrans where transnum='" & lbltrans.Text & txttrans.Text & "'"
            connect()
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            While drx.Read
                Dim stat As String = ""
                If drx("cancel") = 1 Then
                    stat = "Cancelled"
                ElseIf drx("status") = 1 Then
                    stat = "Available"
                ElseIf drx("status") = 0 Then
                    stat = "In Process"
                ElseIf drx("status") = 2 Then
                    stat = "Completed"
                End If

                grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                If stat = "Cancelled" Then
                    grdtrans.Rows(grdtrans.Rows.Count - 1).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                End If
            End While
            drx.Dispose()
            cmdx.Dispose()
            conn.Close()

            For Each row As DataGridViewRow In grdtrans.Rows
                Dim stat As String = grdtrans.Rows(row.Index).Cells(14).Value
                If stat = "Completed" Then
                    sql = "Select Top 1 * from tbltripitems where transnum='" & grdtrans.Rows(row.Index).Cells(2).Value & "' order by tripid"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        If dr("status") = 3 Then
                            grdtrans.Rows(row.Index).Cells(14).Value = "Removed"
                        ElseIf dr("status") = 4 Then
                            grdtrans.Rows(row.Index).Cells(14).Value = "Rescheduled"
                        End If
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                End If
            Next

            If grdtrans.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txttrans_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttrans.TextChanged
        Dim charactersDisallowed As String = "0123456789-"
        Dim theText As String = txttrans.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txttrans.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txttrans.Text.Length - 1
            Letter = txttrans.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txttrans.Text = theText
        txttrans.Select(SelectionIndex - Change, 0)

        If Trim(txttrans.Text) <> "" Then
            datefrom.Enabled = False
            dateto.Enabled = False
            cmbcus.Enabled = False
            txtso.Enabled = False
            txtpo.Enabled = False
            txtitr.Enabled = False
            txtsws.Enabled = False
        Else
            datefrom.Enabled = True
            dateto.Enabled = True
            cmbcus.Enabled = True
            txtso.Enabled = True
            txtpo.Enabled = True
            txtitr.Enabled = True
            txtsws.Enabled = True
            btnview.PerformClick()
        End If
    End Sub

    Public Sub customer()
        Try
            cmbcus.Items.Clear()
            cmbcus.Items.Add("")
            '/CType(Me.grdtrans.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdtrans.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tblcustomer order by customer"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbcus.Items.Add(dr1("customer"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub EditOrdersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditOrdersToolStripMenuItem.Click
        If login.neym = "Whse Accounting Staff" Then
            MsgBox("Access denied!", MsgBoxStyle.Critical, "")
            Exit Sub
        End If

        If grdtrans.RowCount <> 0 Then

            sql = "Select * from tblortrans where transid='" & grdtrans.Item(0, grdtrans.CurrentRow.Index).Value & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Dim stattrans As String = ""
                If dr("cancel") = 1 Then
                    stattrans = "Cancelled"
                    MsgBox("Transaction is already cancelled.", MsgBoxStyle.Information, "")
                    Exit Sub
                ElseIf dr("status") = 1 Then
                    stattrans = "Available"
                ElseIf dr("status") = 0 Then
                    stattrans = "In Process"
                ElseIf dr("status") = 2 Then
                    stattrans = "Completed"
                    MsgBox("Transaction is already completed.", MsgBoxStyle.Information, "")
                    Exit Sub
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            Dim added As Boolean = False, tripnumx As String = ""
            'check if wala pa sa tripitems
            sql = "Select * from tbltripitems where transnum='" & grdtrans.Item(2, grdtrans.CurrentRow.Index).Value & "' and status<>'0' and status<>'3' and status<>'4'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                added = True
                tripnumx = dr("tripnum")
            Else
                added = False
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If added = True Then
                sql = "Select * from tbltripsum where tripnum='" & tripnumx & "' and status='3'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    added = False
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

           
            'check if ung status ng tripnum na meron sa kanya if timedep is dbnull
            Dim tripnum As String = ""

            sql = "Select * from tbltripitems where transnum='" & grdtrans.Item(2, grdtrans.CurrentRow.Index).Value & "' and status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                tripnum = dr("tripnum")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            sql = "Select * from tbldispatchsum where tripnum='" & tripnum & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("step4") = 1 And IsDBNull(dr("datestp4")) = False Then
                    MsgBox("Transaction documents is already released." & vbCrLf & "Cannot edit orders.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Dim checkstep9 As Boolean = False, tripn As String = ""
            sql = "Select Top 1 * from tbltripitems where transnum='" & grdtrans.Item(2, grdtrans.CurrentRow.Index).Value & "' and status='4' order by tripid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                checkstep9 = True
                tripn = dr("tripnum")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Dim confirmedstep9 As Boolean = False
            sql = "Select * from tbldispatchsum where tripnum='" & tripn & "' and step9='0'" 'meaning di pa close ung step9 kaya baka pwedeng mali ng reschedule check
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                MsgBox("Cannot edit orders until trip#" & tripn & " step9 is confirmed.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If added = True Then
                edittrans = True
                If mainmenucreate.IsHandleCreated Then
                    mainmenucreate.Dispose()
                End If
                mainmenucreate.btnok.Text = "SAVE"
                mainmenucreate.lbltrnum.Text = grdtrans.Item(2, grdtrans.CurrentRow.Index).Value
                mainmenucreate.lbltransid.Text = grdtrans.Item(0, grdtrans.CurrentRow.Index).Value
                mainmenucreate.ShowDialog()
                mainmenucreate.btnok.Text = "OK"
                mainmenucreate.lbltransid.Text = ""
                edittrans = False
            Else
                edittrans = True
                If mainmenucreate.IsHandleCreated Then
                    mainmenucreate.Dispose()
                End If
                mainmenucreate.btnok.Text = "SAVE"
                mainmenucreate.lbltrnum.Text = grdtrans.Item(2, grdtrans.CurrentRow.Index).Value
                mainmenucreate.lbltransid.Text = grdtrans.Item(0, grdtrans.CurrentRow.Index).Value
                mainmenucreate.ShowDialog()
                mainmenucreate.btnok.Text = "OK"
                mainmenucreate.lbltransid.Text = ""
                edittrans = False
                'MsgBox("transaction is not added.")
            End If

            txttrans.Text = ""
            datefrom.Enabled = True
            dateto.Enabled = True
            cmbcus.Enabled = True
            btnsearch.Enabled = True
            '/ datefrom.Value = datefrom.MaxDate

            If clickbtn = "Searched" Then
                btnsearch.PerformClick()
            Else
                btnview.PerformClick()
            End If

        End If
    End Sub

    Private Sub CancelOrdersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelOrdersToolStripMenuItem.Click
        If login.neym = "Whse Accounting Staff" Then
            MsgBox("Access denied!", MsgBoxStyle.Critical, "")
            Exit Sub
        End If

        If grdtrans.RowCount <> 0 Then
            If grdtrans.Item(2, grdtrans.CurrentRow.Index).Value IsNot Nothing Then
                sql = "Select cancel, status from tblortrans where transid='" & grdtrans.Item(0, grdtrans.CurrentRow.Index).Value & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    Dim stattrans As String = ""
                    If dr("cancel") = 1 Then
                        stattrans = "Cancelled"
                        MsgBox("Transaction is already cancelled.", MsgBoxStyle.Information, "")
                        Exit Sub
                    ElseIf dr("status") = 1 Then
                        stattrans = "Available"
                    ElseIf dr("status") = 0 Then
                        stattrans = "In Process"
                        MsgBox("Transaction is in process. Cannot cancel directly.", MsgBoxStyle.Information, "")
                        Exit Sub
                    ElseIf dr("status") = 2 Then
                        stattrans = "Completed"
                        MsgBox("Transaction is already completed.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                Dim checkstep9 As Boolean = False, tripn As String = ""
                sql = "Select Top 1 tripnum from tbltripitems where transnum='" & grdtrans.Item(2, grdtrans.CurrentRow.Index).Value & "' and status='4' order by tripid DESC"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    checkstep9 = True
                    tripn = dr("tripnum")
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                Dim confirmedstep9 As Boolean = False
                sql = "Select tripnum from tbldispatchsum where tripnum='" & tripn & "' and step9='0'" 'meaning di pa close ung step9 kaya baka pwedeng mali ng reschedule check
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    MsgBox("Cannot cancel transaction until trip#" & tripn & " step9 is confirmed.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                If grdtrans.Item(13, grdtrans.CurrentRow.Index).Value.ToString <> "1" Then
                    transcnf = False
                    confirm.ShowDialog()
                    If transcnf = True Then

                        sql = "Update tblortrans set datecancelled=GetDate(), cancelledby='" & login.cashier & "', cancel='1' where transnum='" & grdtrans.Item(2, grdtrans.CurrentRow.Index).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        'consider as remove na to sa tripitems naka 3 yung status bago ma cancel
                        '/sql = "Update tbltripitems set status='0', cancelby='" & login.cashier & "', canceldate=GetDate() where transnum='" & grdtrans.Item(2, grdtrans.CurrentRow.Index).Value & "'"
                        '/connect()
                        '/cmd = New SqlCommand(sql, conn)
                        '/cmd.ExecuteNonQuery()
                        '/cmd.Dispose()
                        '/conn.Close()

                        MsgBox("Successfully Cancelled.", MsgBoxStyle.Information, "")
                        If clickbtn = "Searched" Then
                            btnsearch.PerformClick()
                        Else
                            btnview.PerformClick()
                        End If
                    End If
                Else
                    MsgBox("Transaction is already cancelled.", MsgBoxStyle.Information, "")
                End If
            End If
        End If
    End Sub

    Private Sub txtso_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtso.KeyPress
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            'searchrefnum()
            searchlahat()
        End If

        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtso_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtso.TextChanged
        Dim charactersDisallowed As String = "0123456789tofollow TOFOLLOW"
        Dim theText As String = txtso.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtso.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtso.Text.Length - 1
            Letter = txtso.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtso.Text = theText
        txtso.Select(SelectionIndex - Change, 0)

        If Trim(txtso.Text) <> "" Then
            datefrom.Enabled = False
            dateto.Enabled = False
            cmbcus.Enabled = False
            txtpo.Enabled = False
            txtitr.Enabled = False
            txtsws.Enabled = False
            txttrans.Enabled = False
            If txtso.ToString.Contains("TO FOLLOW") Or txtso.ToString.Contains("TOFOLLOW") Or txtso.ToString.Contains("FOLLOW") Then
                datefrom.Enabled = True
                dateto.Enabled = True
                cmbcus.Enabled = True
            End If
        Else
            'datefrom.Enabled = True
            'dateto.Enabled = True
            cmbcus.Enabled = True
            txtpo.Enabled = True
            txtitr.Enabled = True
            txtsws.Enabled = True
            txttrans.Enabled = True
            btnview.PerformClick()
        End If
    End Sub

    Private Sub txtpo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtpo.KeyPress
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            'searchrefnum()
            searchlahat()
        End If

        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtpo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtpo.TextChanged
        Dim charactersDisallowed As String = "0123456789tofollow TOFOLLOW"
        Dim theText As String = txtpo.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtpo.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtpo.Text.Length - 1
            Letter = txtpo.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtpo.Text = theText
        txtpo.Select(SelectionIndex - Change, 0)

        If Trim(txtpo.Text) <> "" Then
            datefrom.Enabled = False
            dateto.Enabled = False
            cmbcus.Enabled = False
            txtso.Enabled = False
            txtitr.Enabled = False
            txtsws.Enabled = False
            txttrans.Enabled = False

            If txtpo.ToString.Contains("TO FOLLOW") Or txtpo.ToString.Contains("TOFOLLOW") Or txtpo.ToString.Contains("FOLLOW") Then
                datefrom.Enabled = True
                dateto.Enabled = True
                cmbcus.Enabled = True
            End If
        Else
            datefrom.Enabled = True
            dateto.Enabled = True
            cmbcus.Enabled = True
            txtso.Enabled = True
            txtitr.Enabled = True
            txtsws.Enabled = True
            txttrans.Enabled = True
            btnview.PerformClick()
        End If
    End Sub

    Private Sub txtitr_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtitr.KeyPress
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            'searchrefnum()
            searchlahat()
        End If

        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtitr_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtitr.TextChanged
        Dim charactersDisallowed As String = "0123456789tofollow TOFOLLOW"
        Dim theText As String = txtitr.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtitr.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtitr.Text.Length - 1
            Letter = txtitr.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtitr.Text = theText
        txtitr.Select(SelectionIndex - Change, 0)

        If Trim(txtitr.Text) <> "" Then
            datefrom.Enabled = False
            dateto.Enabled = False
            cmbcus.Enabled = False
            txtpo.Enabled = False
            txtso.Enabled = False
            txtsws.Enabled = False
            txttrans.Enabled = False

            If txtitr.ToString.Contains("TO FOLLOW") Or txtitr.ToString.Contains("TOFOLLOW") Or txtitr.ToString.Contains("FOLLOW") Then
                datefrom.Enabled = True
                dateto.Enabled = True
                cmbcus.Enabled = True
            End If
        Else
            datefrom.Enabled = True
            dateto.Enabled = True
            cmbcus.Enabled = True
            txtpo.Enabled = True
            txtso.Enabled = True
            txtsws.Enabled = True
            txttrans.Enabled = True
            btnview.PerformClick()
        End If
    End Sub

    Public Sub searchlahat()
        Try
            grdtrans.Rows.Clear()

            sql = "Select * from tblortrans where transid<>0"

            If Trim(txtso.Text) <> "" Then
                If txtso.Text.ToString.Contains("FOLLOW") = True Then
                    sql = sql & " and refnum like '%" & "SO#" & Trim(txtso.Text) & "%'"
                Else
                    sql = sql & " and refnum='" & "SO#" & Trim(txtso.Text) & "' or refnum like '" & "SO#" & Trim(txtso.Text) & " /" & "%'"
                End If
            End If

            If Trim(txtpo.Text) <> "" Then
                If txtpo.Text.ToString.Contains("FOLLOW") = True Then
                    sql = sql & " and refnum like '%" & "PO#" & Trim(txtpo.Text) & "%'"
                Else
                    sql = sql & " and refnum='" & "PO#" & Trim(txtpo.Text) & "' or refnum like '%" & "/ " & "PO#" & Trim(txtpo.Text) & "'"
                End If
            End If

            If Trim(txtitr.Text) <> "" Then
                If txtpo.Text.ToString.Contains("FOLLOW") = True Then
                    sql = sql & " and refnum like '%" & "ITR#" & Trim(txtitr.Text) & "%'"
                Else
                    sql = sql & " and refnum='" & "ITR#" & Trim(txtitr.Text) & "'"
                End If
            End If

            If Trim(txtsws.Text) <> "" Then
                If txtpo.Text.ToString.Contains("FOLLOW") = True Then
                    sql = sql & " and refnum like '%" & "SWS#" & Trim(txtsws.Text) & "%'"
                Else
                    sql = sql & " and refnum='" & "SWS#" & Trim(txtsws.Text) & "'"
                End If
            End If

            If Trim(cmbcus.Text) <> "" Then
                sql = sql & " and customer='" & Trim(cmbcus.Text) & "'"
            End If

            If datefrom.Enabled = True And dateto.Enabled = True Then
                sql = sql & " and datecreated>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and datecreated<='" & Format(dateto.Value, "yyyy/MM/dd") & "'"
            End If

            connect()
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            While drx.Read
                '/If Format(drx("datecreated"), "yyyy/MM/dd") >= Format(datefrom.Value, "yyyy/MM/dd") And Format(drx("datecreated"), "yyyy/MM/dd") <= Format(dateto.Value, "yyyy/MM/dd") Then

                Dim stat As String = ""
                If drx("cancel") = 1 Then
                    stat = "Cancelled"
                ElseIf drx("status") = 1 Then
                    stat = "Available"
                ElseIf drx("status") = 0 Then
                    stat = "In Process"
                ElseIf drx("status") = 2 Then
                    stat = "Completed"
                End If


                '''''''start SO
                If Trim(txtso.Text) <> "" Then
                    If Trim(txtso.Text) = "TO FOLLOW" Or Trim(txtso.Text) = "TOFOLLOW" Or Trim(txtso.Text) = " TOFOLLOW" Then
                        If drx("refnum").ToString.Contains("/") Then
                            If drx("refnum").ToString.StartsWith("SO#") Then
                                Dim conc As String = drx("refnum")
                                Dim b As String() = conc.Split("/")
                                Dim b1 As String = b(0)
                                Dim b2 As String = b(1)
                                If b1.ToString.EndsWith("FOLLOW") Or b1.ToString.EndsWith("FOLLOW ") Or b1.ToString.EndsWith("follow") Or b1.ToString.EndsWith("follow ") Then
                                    grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                                End If
                            End If
                        ElseIf (drx("refnum").ToString.StartsWith("SO#") And drx("refnum").ToString.EndsWith("FOLLOW")) Or (drx("refnum").ToString.StartsWith("SO#") And drx("refnum").ToString.EndsWith("FOLLOW ")) Or (drx("refnum").ToString.StartsWith("SO#") And drx("refnum").ToString.EndsWith("follow")) Or (drx("refnum").ToString.StartsWith("SO#") And drx("refnum").ToString.EndsWith("follow ")) Then
                            grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                        End If
                    Else
                        If drx("refnum").ToString.Contains("SO#" & Trim(txtso.Text)) Then
                            grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                        End If
                    End If
                End If
                ''''''''end SO


                '''''''start PO
                If Trim(txtpo.Text) <> "" Then
                    If Trim(txtpo.Text) = "TO FOLLOW" Or Trim(txtpo.Text) = "TOFOLLOW" Or Trim(txtpo.Text) = " TOFOLLOW" Then
                        If drx("refnum").ToString.Contains("/") Then
                            If drx("refnum").ToString.StartsWith("SO#") Then
                                Dim conc As String = drx("refnum")
                                Dim s As String() = conc.Split("/")
                                Dim s1 As String = s(0)
                                Dim s2 As String = s(1)
                                If s2.ToString.EndsWith("FOLLOW") Or s2.ToString.EndsWith("FOLLOW ") Or s2.ToString.EndsWith("follow") Or s2.ToString.EndsWith("follow ") Then
                                    grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                                End If
                            End If
                        ElseIf (drx("refnum").ToString.StartsWith("PO#") And drx("refnum").ToString.EndsWith("FOLLOW")) Or (drx("refnum").ToString.StartsWith("PO#") And drx("refnum").ToString.EndsWith("FOLLOW ")) Or (drx("refnum").ToString.StartsWith("PO#") And drx("refnum").ToString.EndsWith("follow")) Or (drx("refnum").ToString.StartsWith("PO#") And drx("refnum").ToString.EndsWith("follow ")) Then
                            grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                        End If
                    Else
                        If drx("refnum").ToString.Contains("PO#" & Trim(txtpo.Text)) Then
                            grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                        End If
                    End If
                End If
                ''''''end PO


                '''''''start ITR
                If Trim(txtitr.Text) <> "" Then
                    If Trim(txtitr.Text) = "TO FOLLOW" Or Trim(txtitr.Text) = "TOFOLLOW" Or Trim(txtitr.Text) = " TOFOLLOW" Then
                        If (drx("refnum").ToString.StartsWith("ITR#") And drx("refnum").ToString.EndsWith("FOLLOW")) Or (drx("refnum").ToString.StartsWith("ITR#") And drx("refnum").ToString.EndsWith("FOLLOW ")) Or (drx("refnum").ToString.StartsWith("ITR#") And drx("refnum").ToString.EndsWith("follow")) Or (drx("refnum").ToString.StartsWith("ITR#") And drx("refnum").ToString.EndsWith("follow ")) Then
                            grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                        End If
                    Else
                        If drx("refnum").ToString.Contains("ITR#" & Trim(txtitr.Text)) Then
                            grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                        End If
                    End If
                End If
                ''''''end ITR


                ''''''start SWS
                If Trim(txtsws.Text) <> "" Then
                    If Trim(txtsws.Text) = "TO FOLLOW" Or Trim(txtsws.Text) = "TOFOLLOW" Or Trim(txtsws.Text) = " TOFOLLOW" Then
                        If (drx("refnum").ToString.StartsWith("SWS#") And drx("refnum").ToString.EndsWith("FOLLOW")) Or (drx("refnum").ToString.StartsWith("SWS#") And drx("refnum").ToString.EndsWith("FOLLOW ")) Or (drx("refnum").ToString.StartsWith("SWS#") And drx("refnum").ToString.EndsWith("follow")) Or (drx("refnum").ToString.StartsWith("SWS#") And drx("refnum").ToString.EndsWith("follow ")) Then
                            grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                        End If
                    Else
                        If drx("refnum").ToString.Contains("SWS#" & Trim(txtsws.Text)) Then
                            grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                        End If
                    End If
                End If
                '''''''End SWS

                If stat = "Cancelled" Then
                    grdtrans.Rows(grdtrans.Rows.Count - 1).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                End If
                '/ End If
            End While
            drx.Dispose()
            cmdx.Dispose()
            conn.Close()

            For Each row As DataGridViewRow In grdtrans.Rows
                Dim stat As String = grdtrans.Rows(row.Index).Cells(14).Value
                If stat = "Completed" Then
                    sql = "Select Top 1 * from tbltripitems where transnum='" & grdtrans.Rows(row.Index).Cells(2).Value & "' order by tripid"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        If dr("status") = 3 Then
                            grdtrans.Rows(row.Index).Cells(14).Value = "Removed"
                        ElseIf dr("status") = 4 Then
                            grdtrans.Rows(row.Index).Cells(14).Value = "Rescheduled"
                        End If
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                End If
            Next

            If grdtrans.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub searchrefnum()
        Try
            grdtrans.Rows.Clear()

            sql = "Select * from tblortrans"
            connect()
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            While drx.Read
                Dim stat As String = ""
                If drx("cancel") = 1 Then
                    stat = "Cancelled"
                ElseIf drx("status") = 1 Then
                    stat = "Available"
                ElseIf drx("status") = 0 Then
                    stat = "In Process"
                ElseIf drx("status") = 2 Then
                    stat = "Completed"
                End If


                If Trim(txtso.Text) <> "" Then
                    If drx("refnum").ToString.Contains("/") Then
                        If drx("refnum").ToString.Contains("SO#" & Trim(txtso.Text) & " ") Then
                            grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                        End If
                    Else
                        If drx("refnum").ToString.Contains("SO#" & Trim(txtso.Text)) Then
                            grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                        End If
                    End If

                ElseIf Trim(txtpo.Text) <> "" Then
                    If drx("refnum").ToString.Contains("PO#" & Trim(txtpo.Text)) Then
                        grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                    End If
                ElseIf Trim(txtitr.Text) <> "" Then
                    If drx("refnum").ToString.Contains("ITR#" & Trim(txtitr.Text)) Then
                        grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                    End If
                ElseIf Trim(txtsws.Text) <> "" Then
                    If drx("refnum").ToString.Contains("SWS#" & Trim(txtsws.Text)) Then
                        grdtrans.Rows.Add(drx("transid"), Format(drx("deliverydate"), "yyyy/MM/dd"), drx("transnum"), drx("refnum"), drx("customer"), drx("transtype"), drx("arnum"), drx("rdrnum"), drx("drnum"), drx("dnnum"), drx("itrnum"), drx("itnum"), drx("grponum"), drx("cancel"), stat, drx("notes"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"))
                    End If
                End If

                If stat = "Cancelled" Then
                    grdtrans.Rows(grdtrans.Rows.Count - 1).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                End If
            End While
            drx.Dispose()
            cmdx.Dispose()
            conn.Close()

            For Each row As DataGridViewRow In grdtrans.Rows
                Dim stat As String = grdtrans.Rows(row.Index).Cells(14).Value
                If stat = "Completed" Then
                    sql = "Select Top 1 * from tbltripitems where transnum='" & grdtrans.Rows(row.Index).Cells(2).Value & "' order by tripid"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        If dr("status") = 3 Then
                            grdtrans.Rows(row.Index).Cells(14).Value = "Removed"
                        ElseIf dr("status") = 4 Then
                            grdtrans.Rows(row.Index).Cells(14).Value = "Rescheduled"
                        ElseIf dr("status") = 5 Then
                            grdtrans.Rows(row.Index).Cells(14).Value = "For AR Credit Memo"
                        End If
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                End If
            Next

            If grdtrans.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprint.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim objExcel As New Excel.Application
            Dim bkWorkBook As Excel.Workbook
            Dim shWorkSheet As Excel.Worksheet
            Dim misValue As Object = System.Reflection.Missing.Value

            Dim i As Integer
            Dim j As Integer

            Dim dfrom As String = Format(datefrom.Value, "MMMMddyyyy")
            Dim dto As String = Format(dateto.Value, "MMMMddyyyy")

            Dim daterange As String = dfrom & "_TO_" & dto
            Dim sfilename As String = login.whse & " Whse " & clickbtn & " Transactions from " & daterange & ".xls"

            objExcel = New Excel.Application
            bkWorkBook = objExcel.Workbooks.Add
            shWorkSheet = CType(bkWorkBook.ActiveSheet, Excel.Worksheet)

            With shWorkSheet
                .Range("A1", misValue).EntireRow.Font.Bold = True
                .Range("A1:AD1").EntireRow.WrapText = True
                .Range("A1:AD" & grdtrans.RowCount + 1).HorizontalAlignment = -4108
                .Range("A1:AD" & grdtrans.RowCount + 1).VerticalAlignment = -4108
                .Range("A1:AD" & grdtrans.RowCount + 1).Font.Size = 10
                'Set Clipboard Copy Mode     
                grdtrans.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
                grdtrans.SelectAll()
                grdtrans.RowHeadersVisible = False

                'Get the content from Grid for Clipboard     
                'Dim str As String = TryCast(grdtrans.GetClipboardContent().GetData(DataFormats.UnicodeText), String)
                Dim str As String = grdtrans.GetClipboardContent().GetData(DataFormats.UnicodeText)

                'Set the content to Clipboard     
                Clipboard.SetText(str, TextDataFormat.UnicodeText) 'TextDataFormat.UnicodeText)

                'Identify and select the range of cells in Excel to paste the clipboard data.     
                .Range("A1:L1", misValue).Select()

                'WIDTH
                .Range("A1:A" & grdtrans.RowCount + 1).ColumnWidth = 11
                .Range("B1:B" & grdtrans.RowCount + 1).ColumnWidth = 12
                .Range("C1:C" & grdtrans.RowCount + 1).ColumnWidth = 17
                .Range("D1:D" & grdtrans.RowCount + 1).ColumnWidth = 30
                .Range("E1:E" & grdtrans.RowCount + 1).ColumnWidth = 30
                .Range("F1:K" & grdtrans.RowCount + 1).ColumnWidth = 15
                .Range("L1:L" & grdtrans.RowCount + 1).ColumnWidth = 20

                'Paste the clipboard data     
                .Paste()
                Clipboard.Clear()

            End With

            For i = 0 To grdtrans.RowCount - 1
                Exit For
                'shWorkSheet.Cells(i + 2, 1) = grdtrans.Rows(i).Cells(1).Value
                shWorkSheet.Cells(i + 2, 3).NumberFormat = "#,##0.00"   'SUBTOTAL
                shWorkSheet.Cells(i + 2, 4).NumberFormat = "#,##0.00"   'SUBPLUSPLUS
                shWorkSheet.Cells(i + 2, 5).NumberFormat = "#,##0.00"
                shWorkSheet.Cells(i + 2, 7).NumberFormat = "#,##0.00"
                shWorkSheet.Cells(i + 2, 8).NumberFormat = "#,##0.00"
                'sum
                'shWorkSheet.Cells(i + 2, 4).value = "=D" & i + 2 & & "+E" & i + 2 &
                shWorkSheet.Cells(i + 2, 4).value = "=SUMIF(F" & i + 2 & ":F" & i + 2 & ",""Special Disc"",H" & i + 2 & ":H" & i + 2 & ")+C" & i + 2 & "+E" & i + 2
                shWorkSheet.Cells(i + 2, 9).NumberFormat = "#,##0.00"
                shWorkSheet.Cells(i + 2, 10).NumberFormat = "#,##0.00"
                shWorkSheet.Cells(i + 2, 11).NumberFormat = "#,##0.00"
                shWorkSheet.Cells(i + 2, 12).NumberFormat = "#,##0.00"
                shWorkSheet.Cells(i + 2, 13).NumberFormat = "#,##0.00"
            Next
            'shWorkSheet.Range("C" & sumall).Value =


            'format alignment
            'shWorkSheet.Range("D2", "D" & grdtrans.RowCount + 1).HorizontalAlignment = Excel.XlHAlign.xlHAlignRight


            'lagyan ng title na red door kit tska ung date na sakop ng report
            shWorkSheet.Range("A1").EntireRow.Insert()
            shWorkSheet.Range("A2").EntireRow.Insert()
            shWorkSheet.Range("A3").EntireRow.Insert()
            shWorkSheet.Cells(1, 1) = login.whse & " Warehouse"
            shWorkSheet.Cells(2, 1) = clickbtn & " Transactions from " & daterange
            shWorkSheet.Cells(1, 1).Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red)
            shWorkSheet.Range("A4").EntireRow.WrapText = True

            Me.Cursor = Cursors.Default

            objExcel.Visible = False
            'objExcel.Application.DisplayAlerts = False

            Dim password As String = "AB123"
            'objExcel.ActiveWorkbook.SaveAs(Application.StartupPath & "sample.xls", FileFormat:=51, )
            '/bkWorkBook.SaveAs(Filename:=Application.StartupPath & "\template\" & sfilename, FileFormat:=51, Password:=password, CreateBackup:=False)
            bkWorkBook.SaveAs(Filename:=Application.StartupPath & "\template\" & sfilename, FileFormat:=51, CreateBackup:=False)

            bkWorkBook.Close(True, misValue, misValue)
            objExcel.Quit()

            'objExcel = Nothing

            releaseObject(bkWorkBook)
            releaseObject(shWorkSheet)
            releaseObject(objExcel)

            MessageBox.Show("Data Successfully Exported") ' & sfilename)
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As System.Runtime.InteropServices.COMException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " + ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub grdtrans_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdtrans.SelectionChanged
        count()
    End Sub

    Public Sub count()
        Try
            lblcount.Text = "     Selected Rows Count: " & grdtrans.SelectedRows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txtsws_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtsws.KeyPress
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            'searchrefnum()
            searchlahat()
        End If

        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtsws_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtsws.TextChanged
        Dim charactersDisallowed As String = "0123456789tofollow TOFOLLOW"
        Dim theText As String = txtsws.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtsws.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtsws.Text.Length - 1
            Letter = txtsws.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtsws.Text = theText
        txtsws.Select(SelectionIndex - Change, 0)

        If Trim(txtsws.Text) <> "" Then
            datefrom.Enabled = False
            dateto.Enabled = False
            cmbcus.Enabled = False
            txtpo.Enabled = False
            txtso.Enabled = False
            txtitr.Enabled = False
            txttrans.Enabled = False

            If txtsws.ToString.Contains("TO FOLLOW") Or txtsws.ToString.Contains("TOFOLLOW") Or txtsws.ToString.Contains("FOLLOW") Then
                datefrom.Enabled = True
                dateto.Enabled = True
                cmbcus.Enabled = True
            End If
        Else
            datefrom.Enabled = True
            dateto.Enabled = True
            cmbcus.Enabled = True
            txtpo.Enabled = True
            txtso.Enabled = True
            txtitr.Enabled = True
            txttrans.Enabled = True
            btnview.PerformClick()
        End If
    End Sub

    Private Sub cmbcus_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcus.SelectedIndexChanged

    End Sub

    Private Sub cmbcus_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbcus.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = cmbcus.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbcus.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbcus.Text.Length - 1
            Letter = cmbcus.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbcus.Text = theText
        cmbcus.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub trans_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ContextMenuStrip1_Opening(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles ContextMenuStrip1.Opening

    End Sub
End Class