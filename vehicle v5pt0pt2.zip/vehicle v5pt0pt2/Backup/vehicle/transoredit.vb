﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class transoredit
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Dim clickbtn As String = ""

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub transoredit_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        oredit()
    End Sub

    Private Sub oredit()
        Try
            sql = "Select * from tblortrans where transnum='" & lbltrans.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                lbldate.Text = dr("datecreated").ToString
                lblby.Text = dr("createdby").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            grd.Rows.Clear()
            sql = "Select * from tbloredit where transnum='" & lbltrans.Text & "' and status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grd.Rows.Add(dr("oreditid"), dr("transid"), dr("prevso"), dr("newso"), dr("prevpo"), dr("newpo"), dr("previtr"), dr("newitr"), dr("prevsws"), dr("newsws"), dr("createdby"), dr("datecreated"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class