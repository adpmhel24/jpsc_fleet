﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Drawing.Image
Imports System.ComponentModel
Imports System.Net.NetworkInformation

Public Class sqlqueries
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public delcnf As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub sqlqueries_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim a As String = MsgBox("Are you sure you want to close?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            '/moduless.Show()
            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub sqlqueries_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblwhse1.Text = login.whsecode
        lblwhse2.Text = login.whsecode

        datefrom.CustomFormat = "yyyy/MM/dd"
        dateto.CustomFormat = "yyyy/MM/dd"
        datefrom.MaxDate = Date.Now
        dateto.MinDate = datefrom.Value

        '/datefrom.MaxDate = Date.Now.AddMonths(-3)
        '/dateto.MaxDate = Date.Now.AddMonths(-3)
        lblcount.Text = 0
    End Sub

    Private Sub btncheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncheck.Click
        Try
            'check if complete details
            If Trim(txttable.Text) = "" Then
                MsgBox("Complete the fields.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            ElseIf rbtrip.Checked = True Then
                If Trim(txttripfrom.Text) = "" And Trim(txttripto.Text) = "" Then
                    MsgBox("Complete the fields.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
            End If

            If dateto.Value > Date.Now.AddMonths(-3) Then
                MsgBox("Date to is exceeding the maximum.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            'check if table is existing
            Dim tblexist As Boolean = False
            sql = "Select * from sys.tables where name = '" & Trim(txttable.Text) & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                tblexist = True
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If tblexist = True Then
                grdstep1.Rows.Clear()
                Dim hasRows As String = ""
                Dim tbltable As String = Trim(txttable.Text)
                If rbtrip.Checked = True Then
                    sql = "Select * from tbltripsum right outer join " & Trim(txttable.Text) & " on tbltripsum.tripnum=" & tbltable & ".tripnum where tbltripsum.tripnum>='" & lblwhse1.Text & Trim(txttripfrom.Text) & "' and tbltripsum.tripnum<='" & lblwhse2.Text & Trim(txttripfrom.Text) & "'"

                ElseIf rbdate.Checked = True Then
                    Dim datefrom1 As Date = CDate(Format(datefrom.Value, "MM/dd/yyyy"))
                    Dim dateto1 As Date = CDate(Format(dateto.Value, "MM/dd/yyyy"))
                    sql = "Select tbltripsum.tripnum, tbltripsum.datepick, " & Trim(txttable.Text) & ".*  from tbltripsum right outer join " & Trim(txttable.Text) & " on tbltripsum.tripnum=" & tbltable & ".tripnum where tbltripsum.datepick>='" & datefrom1 & "' and tbltripsum.datepick<='" & dateto1 & "'"
                End If

                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                While dr.Read
                    If dr(4).ToString.Contains("Signature") = False Then
                        grdstep1.Rows.Add(dr(2), dr("tripnum"), Format(dr("datepick"), "MM/dd/yyyy"), dr(4))
                    End If
                End While
                cmd.Dispose()
                dr.Close()
                conn.Close()

                If grdstep1.Rows.Count <> 0 Then
                    btndelete.Enabled = True
                Else
                    btndelete.Enabled = False
                End If

                lblcount.Text = grdstep1.Rows.Count
            Else
                MsgBox("Table does not exist.", MsgBoxStyle.Critical, "")
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txttripfrom_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttripfrom.TextChanged
        Dim charactersDisallowed As String = "0123456789"
        Dim theText As String = txttripfrom.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txttripfrom.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txttripfrom.Text.Length - 1
            Letter = txttripfrom.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txttripfrom.Text = theText
        txttripfrom.Select(SelectionIndex - Change, 0)

    End Sub

    Private Sub txttripto_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttripto.TextChanged
        Dim charactersDisallowed As String = "0123456789"
        Dim theText As String = txttripto.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txttripto.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txttripto.Text.Length - 1
            Letter = txttripto.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txttripto.Text = theText
        txttripto.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub rbtrip_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbtrip.CheckedChanged
        If rbtrip.Checked = True Then
            txttripfrom.Text = ""
            txttripto.Text = ""
            txttripfrom.Enabled = True
            txttripto.Enabled = True
            datefrom.Enabled = False
            dateto.Enabled = False
        ElseIf rbdate.Checked = True Then
            txttripfrom.Text = ""
            txttripto.Text = ""
            datefrom.Enabled = True
            dateto.Enabled = True
            txttripfrom.Enabled = False
            txttripto.Enabled = False
        End If
    End Sub

    Private Sub rbdate_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbdate.CheckedChanged
        If rbtrip.Checked = True Then
            txttripfrom.Text = ""
            txttripto.Text = ""
            txttripfrom.Enabled = True
            txttripto.Enabled = True
            datefrom.Enabled = False
            dateto.Enabled = False
        ElseIf rbdate.Checked = True Then
            txttripfrom.Text = ""
            txttripto.Text = ""
            datefrom.Enabled = True
            dateto.Enabled = True
            txttripfrom.Enabled = False
            txttripto.Enabled = False
        End If
    End Sub

    Private Sub datefrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datefrom.ValueChanged
        dateto.MinDate = datefrom.Value
    End Sub

    Private Sub txttable_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttable.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txttable_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttable.TextChanged

    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try
            delcnf = False
            confirm.ShowDialog()
            If delcnf = True Then
                Dim tbltable As String = Trim(txttable.Text)
                'delete data in table
                For Each row As DataGridViewRow In grdstep1.Rows
                    sql = "Delete from " & tbltable & " where tripnum='" & grdstep1.Rows(row.Index).Cells(1).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()
                Next

                'insert data in tbldeletestp
                Dim deltype As String = "", deldata As String = ""
                If rbtrip.Checked = True Then
                    deltype = rbtrip.Text
                    deldata = lblwhse1.Text & Trim(txttripfrom.Text) & " to " & lblwhse2.Text & Trim(txttripto.Text)
                ElseIf rbdate.Checked = True Then
                    deltype = rbdate.Text
                    deldata = Format(datefrom.Value, "MM/dd/yyyy") & " to " & Format(dateto.Value, "MM/dd/yyyy")
                End If

                sql = "Insert into tbldeletestp (deltable, deltype, deldata, delcount, remarks, datedeleted, deletedby) values ('" & Trim(txttable.Text) & "', '" & deltype & "', '" & deldata & "', '" & Val(lblcount.Text) & "', '" & Trim(txtrems.Text) & "', GetDate(), '" & login.cashier & "')"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Successfully deleted.", MsgBoxStyle.Information, "")
                grdstep1.Rows.Clear()
                '/btncancel.PerformClick()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        txttable.Text = ""
        txttripfrom.Text = ""
        txttripto.Text = ""
        '/datefrom.Value = datefrom.MaxDate
        grdstep1.Rows.Clear()
        txttable.Focus()
        btndelete.Enabled = False
    End Sub

    Private Sub txtrems_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtrems_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtrems.TextChanged

    End Sub

    Private Sub dateto_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dateto.ValueChanged

    End Sub
End Class