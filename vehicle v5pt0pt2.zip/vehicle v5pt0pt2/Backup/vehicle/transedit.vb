﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Globalization

Public Class transedit
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Dim ColAdd As Boolean
    Public tredit As Boolean = False
    Dim tempamt As Double

    Dim ofd As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim pic As PictureBox
    Dim meron As Boolean = False
    Dim culture As CultureInfo = Nothing

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub viewtrans_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        grouptrans.Visible = False
        GroupBox2.Location = New System.Drawing.Point(30, 451) '782, 81  'hyt ng grd 334
        GroupBox2.Height = 81
        GroupBox2.Width = 782
        'grdorders.Height = 334
        Me.Dispose()
    End Sub

    Private Sub viewtrans_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cmbcus.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbcus.DropDownStyle = ComboBoxStyle.DropDown
        cmbcus.AutoCompleteSource = AutoCompleteSource.ListItems

        ColAdd = True

        grdorders.Columns(2).ReadOnly = True
        grdorders.Columns(3).ReadOnly = True
        grdorders.Columns(4).ReadOnly = True
        grdorders.Columns(5).ReadOnly = True

        Dim dgvcCheckBox As New DataGridViewCheckBoxColumn()
        dgvcCheckBox.HeaderText = "Free"
        dgvcCheckBox.Width = 40
        grdorders.Columns.Add(dgvcCheckBox)
        'grdorders.Columns(6).Visible = False

        grdorders.Columns.Add("code", "Item code")
        grdorders.Columns(7).Visible = False

        grdorders.Columns.Add("cat", "Category")
        grdorders.Columns(8).Visible = False

        customer()
        view()
        refimg()

        grdorders.Rows.Add()
    End Sub

    Public Sub customer()
        Try
            cmbcus.Items.Clear()
            cmbcus.Items.Add("")
            '/CType(Me.grdtrans.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdtrans.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tblcustomer where status='1' order by customer"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbcus.Items.Add(dr1("customer"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub view()
        Try
            fillcombo()

            grdorders.Rows.Clear()

            sql = "Select * from tblortrans where transnum='" & txttrans.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                txtref.Text = dr("refnum")
                txttype.Text = dr("transtype")
                txtdes.Text = dr("customer")
                cmbcus.SelectedItem = dr("customer")
                If dr("status") = 1 Then
                    txtstatus.Text = "Available"
                ElseIf dr("status") = 0 Then
                    txtstatus.Text = "In Process"
                ElseIf dr("status") = 2 Then
                    txtstatus.Text = "Completed"
                End If
                txtdatecreated.Text = dr("datecreated")
                txtcreate.Text = dr("createdby")
                txtnotes.Text = dr("notes")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            sql = "Select * from tblorder where transnum='" & txttrans.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grdorders.Rows.Add(dr("itemname"), dr("qty"), dr("price"), dr("dscnt"), dr("totalprice"), dr("request"), True, "", dr("category"))

                Dim checkCell As DataGridViewCheckBoxCell = CType(grdorders.Rows(grdorders.RowCount - 1).Cells(6), DataGridViewCheckBoxCell)
                If dr("free") <> 0 Then
                    checkCell.Value = True
                Else
                    checkCell.Value = False
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub refimg()
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meron = False
            imgpanel1.Visible = False
            imgpanel1.Controls.Clear()
            imgpanel1.Visible = True

            Dim ctr As Integer = 0
            sql = "Select * from tblorimage where transnum='" & txttrans.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                meron = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 3
                row = temp / 3

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                pic = New PictureBox
                pic.Image = Image.FromStream(ms)
                pic.SizeMode = PictureBoxSizeMode.Zoom
                pic.SetBounds(wid, y, 85, 87)
                'pic.BackColor = Color.AliceBlue
                pic.Tag = dr("imgid")
                pic.BorderStyle = BorderStyle.FixedSingle
                wid += 92

                lbl = New Label
                lbl.Text = dr("name")
                lbl.AutoSize = False
                lbl.AutoEllipsis = True
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(85, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 93 + y)
                widlbl += 92

                AddHandler pic.Click, AddressOf convertPic
                imgpanel1.Controls.Add(pic)
                imgpanel1.Controls.Add(lbl)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            txtimg1.Text = ""
            'lblimgid.Text = ""

            Me.Cursor = Cursors.Default

            If meron = False Then
                btnimgrename1.Enabled = False
                btnimgcancel1.Enabled = False
            Else
                imgcancelfalse1()
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrans_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdtrans.SelectionChanged
        'txttrans.Text = grdtrans.Rows(grdtrans.CurrentRow.Index).Cells(1).Value
        view()
    End Sub

    Public Sub fillcombo()
        Try
            connect()
            'For rowIndex As Integer = 0 To grdorders.Rows.Count - 1
            sql = "Select * from tbloritems where discontinued='0' order by itemname"
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read

                CType(Me.grdorders.Columns(0), DataGridViewComboBoxColumn).Items.Add(dr("itemname"))

            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            'Next
            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdorders_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdorders.CellEndEdit
        Try
            Dim ii As Integer = grdorders.CurrentRow.Index

            If e.ColumnIndex = 0 Then
                If grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value.ToString.Contains("'") Then
                    grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value = grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value.ToString.Replace("'", "")
                End If

                grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value = grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value.ToString.ToUpper()

                'input yung price sa cells 3
                sql = "Select * from tbloritems where itemname='" & grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value.ToString & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    grdorders.Rows(grdorders.CurrentRow.Index).Cells(2).Value = dr("price")
                    grdorders.Rows(grdorders.CurrentRow.Index).Cells(8).Value = dr("category")
                    grdorders.Rows(grdorders.CurrentRow.Index).Cells(7).Value = ""
                    amount()
                Else
                    MsgBox("Cannot found " & grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value.ToString, MsgBoxStyle.Critical, "")
                    grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value = Nothing
                    grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value = Nothing
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

            If e.ColumnIndex = 1 Then

                If grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value.ToString IsNot Nothing And Val(grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value) = 0 Then
                    MsgBox("Input must be a non zero number", MsgBoxStyle.Exclamation, "")
                    amount()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                ElseIf grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value.ToString IsNot Nothing And Val(grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value) < 0 Then
                    MsgBox("Invalid input", MsgBoxStyle.Exclamation, "")
                    grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value = 0
                    amount()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                Else
                    'computeamt()
                    'grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value = CInt(Val(grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value))
                    amount()
                    'check if stocks are enough to purchase the quantity of orders

                End If
            End If

            If grdorders.Rows(ii).Cells(0).Value IsNot Nothing And grdorders.Rows(ii).Cells(1).Value IsNot Nothing Then

                If grdorders.RowCount = ii + 1 Then
                    grdorders.Rows.Add()
                End If
                grdorders.Rows(ii).ErrorText = ""
            Else
                grdorders.Rows(ii).ErrorText = "Complete the required fields"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdorders_CellValidating(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellValidatingEventArgs) Handles grdorders.CellValidating
        If ColAdd Then
            Dim comboBoxColumn As DataGridViewComboBoxColumn = CType(grdorders.Columns(0), DataGridViewComboBoxColumn)
            If (e.ColumnIndex = comboBoxColumn.DisplayIndex) Then
                If (Not comboBoxColumn.Items.Contains(e.FormattedValue)) Then
                    comboBoxColumn.Items.Add(e.FormattedValue)
                    grdorders.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = comboBoxColumn.Items(comboBoxColumn.Items.Count - 1)
                End If
            End If
        End If
    End Sub

    Private Sub grdorders_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles grdorders.EditingControlShowing
        Dim comboBoxColumn As DataGridViewComboBoxColumn = grdorders.Columns(0)
        If (grdorders.CurrentCellAddress.X = comboBoxColumn.DisplayIndex) Then
            Dim cb As ComboBox = e.Control
            If (cb IsNot Nothing) Then
                cb.DropDownStyle = ComboBoxStyle.DropDown
                cb.AutoCompleteMode = AutoCompleteMode.SuggestAppend
            End If
        End If
    End Sub

    Private Sub grdorders_DataError(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles grdorders.DataError
        If (e.Context = DataGridViewDataErrorContexts.LeaveControl) Then
            MessageBox.Show("leave control error")
        End If
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try
            'tanggalin ung mga rows na nde kumpleto then
            'check if grd has orders
            Dim meronpa As Boolean = True
            If grdorders.RowCount <> 0 Then
                For irow As Integer = 0 To grdorders.RowCount - 1
                    Try
                        While (grdorders.Rows(irow).Cells(1).Value Is Nothing Or Val(grdorders.Rows(irow).Cells(1).Value) = 0)
                            grdorders.Rows.Remove(grdorders.Rows(irow))
                            grdorders.Refresh()
                            If grdorders.Rows.Count = 0 Then
                                MsgBox("No orders entered. Please check entries.", MsgBoxStyle.Exclamation, "")
                                grdorders.Rows.Clear()
                                grdorders.Rows.Add()
                                Exit Sub
                            End If
                        End While
                    Catch ex As Exception
                        Me.Cursor = Cursors.Default
                        'MsgBox(ex.Message, MsgBoxStyle.Information)
                        If grdorders.RowCount = 0 Then
                            Exit Sub
                        End If
                    End Try
                Next
            Else
                MsgBox("No orders entered. Please check entries.", MsgBoxStyle.Exclamation, "")
                grdorders.Rows.Clear()
                grdorders.Rows.Add()
                Exit Sub
            End If

            If cmbcus.SelectedItem = "" Then
                MsgBox("Select Customer.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            tredit = False
            If login.neym = "Encoder" Then
                confirmencoder.ShowDialog()
            Else
                confirm.ShowDialog()
            End If

            If tredit = True Then
                'bawasan ng row na kulang ung info.. like sa mainmenu

                'delete yung previous na orders
                'then saka i add yung tblorders i insert
                sql = "Update tblortrans set customer='" & cmbcus.SelectedItem & "',notes='" & txtnotes.Text & "' where transnum='" & txttrans.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()


                sql = "Delete from tblorder where transnum='" & txttrans.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                'insert new orders
                'save tblorder
                'tblorder
                Dim dsc(grdorders.Rows.Count - 1) As String
                Dim marks As String = ""
                Dim totalfree As Double = 0

                For Each row As DataGridViewRow In grdorders.Rows
                    Me.Cursor = Cursors.WaitCursor
                    Dim iname As String = grdorders.Rows(row.Index).Cells(0).Value
                    Dim iqty As Double = Val(grdorders.Rows(row.Index).Cells(1).Value.ToString)
                    Dim iprice As Double = Val(grdorders.Rows(row.Index).Cells(2).Value.ToString)
                    Dim idscnt As Double = Val(grdorders.Rows(row.Index).Cells(3).Value.ToString)
                    Dim itotalprice As Double = Val(grdorders.Rows(row.Index).Cells(4).Value.ToString)
                    Dim ireq As String = ""
                    Dim icat As String = grdorders.Rows(row.Index).Cells(8).Value.ToString
                    Dim ifree As Double = 0

                    Dim dscntprice As Double = iprice - ((idscnt / 100) * iprice)

                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdorders.Rows(row.Index).Cells(6), DataGridViewCheckBoxCell)
                    If checkCell.Value = True Then
                        'MsgBox("true")
                        sql = "Select * from tblitems where itemcode='" & grdorders.Rows(row.Index).Cells(7).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            tempamt = Val(dr(5)) * grdorders.Rows(row.Index).Cells(1).Value
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        ifree = tempamt
                        totalfree += ifree
                    Else
                        'MsgBox("false")
                        ifree = 0
                    End If

                    Dim idisc As Integer = 0

                    sql = "Insert into tblorder (transnum, category, itemname, qty, price, totalprice, dscnt, free, request, status, discprice, disctrans)values('" & txttrans.Text & "','" & icat & "','" & iname & "','" & iqty & "','" & iprice & "','" & itotalprice & "','" & idscnt & "','" & ifree & "','" & ireq & "','1','" & dscntprice & "','" & idisc & "')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()
                Next

                MsgBox("Sucessfully Saved Transaction.", MsgBoxStyle.Information, "")
            End If


            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub amount()
        Try
            Dim checkCell As DataGridViewCheckBoxCell = CType(grdorders.Rows(grdorders.CurrentRow.Index).Cells(6), DataGridViewCheckBoxCell)
            If grdorders.RowCount <> 0 And checkCell.Value = False Then
                If (grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value IsNot Nothing) Or (grdorders.Rows(grdorders.CurrentRow.Index).Cells(3).Value IsNot Nothing) Then
                    Dim bd As Double = CDbl(Val(grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value))
                    Dim db As Double = CDbl(Val(grdorders.Rows(grdorders.CurrentRow.Index).Cells(3).Value))
                    Dim isnm As Boolean = IsNumeric(bd)
                    Dim isnm1 As Boolean = IsNumeric(db)
                    If isnm = True And isnm1 = True Then
                        grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value = Val(grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value)
                        grdorders.Rows(grdorders.CurrentRow.Index).Cells(3).Value = Val(grdorders.Rows(grdorders.CurrentRow.Index).Cells(3).Value)
                        Dim q As Double = CDbl(grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value)
                        Dim p As Double
                        sql = "Select * from tbloritems where itemname='" & grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value.ToString & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            p = Val(dr("price"))
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()
                        '////Dim p As Double = CDbl(grdorders.Rows(grdorders.CurrentRow.Index).Cells(3).Value)
                        Dim d As Double = (q * p) * (CDbl(grdorders.Rows(grdorders.CurrentRow.Index).Cells(3).Value / 100))
                        Dim amt As Double = (q * p) - d

                        grdorders.Rows(grdorders.CurrentRow.Index).Cells(2).Value = p
                        grdorders.Rows(grdorders.CurrentRow.Index).Cells(4).Value = amt
                        grdorders.Columns(1).DefaultCellStyle.Format = "n3"
                        grdorders.Columns(3).DefaultCellStyle.Format = "n2"
                        grdorders.Columns(4).DefaultCellStyle.Format = "n2"
                    End If
                End If
            ElseIf grdorders.RowCount <> 0 And checkCell.Value = True Then
                grdorders.Rows(grdorders.CurrentRow.Index).Cells(2).Value = "0.00"
                grdorders.Rows(grdorders.CurrentRow.Index).Cells(3).Value = "0.00"
                grdorders.Rows(grdorders.CurrentRow.Index).Cells(4).Value = "0.00"
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information) '////////
        End Try
    End Sub

    Sub convertPic(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            pic = CType(sender, PictureBox)
            imgbox.Image = pic.Image
            lblimgid.Text = pic.Tag

            sql = "Select * from tblorimage where imgid='" & lblimgid.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                txtimg1.Text = dr("name")
            End If
            dr.Dispose() '
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgadd1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgadd1.Click
        Try
            If btnimgadd1.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox.Image = Image.FromFile(ofd.FileName.ToUpper)
                    txtimg1.Text = ofd.SafeFileName
                    txtimg1.Enabled = True
                    txtimg1.Focus()
                    imgcanceltrue1()
                    imgpanel1.Enabled = False
                    btnimgadd1.Enabled = True
                    btnimgadd1.Text = "Add"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(txtimg1.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    txtimg1.Focus()
                    Exit Sub
                End If

                If txtimg1.Text.ToLower.Contains("signature") Then
                    MsgBox("Invalid photoname.", MsgBoxStyle.Exclamation, "")
                    txtimg1.Text = ""
                    txtimg1.Focus()
                    Exit Sub
                End If

                Dim ms As New MemoryStream()
                Dim filename As String = Trim(txtimg1.Text)

                connect()
                cmd = New SqlCommand("Insert into tblorimage values(@transnum,@name,@img)", conn)
                cmd.Parameters.Add(New SqlClient.SqlParameter("transnum", txttrans.Text))
                cmd.Parameters.Add(New SqlClient.SqlParameter("name", filename))
                imgbox.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                Dim data As Byte() = ms.GetBuffer()
                Dim img As New SqlParameter("@img", SqlDbType.Image)
                img.Value = data
                cmd.Parameters.Add(img)
                cmd.ExecuteNonQuery()
                conn.Close()

                'MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                'imgbox.Image = Nothing
                imgbox.BackColor = Color.Empty
                imgbox.Invalidate()
                Me.Cursor = Cursors.Default

                btnimgadd1.Text = "Add Photo"
                imgpanel1.Enabled = True
                Me.Cursor = Cursors.Default

                imgcancelfalse1()
                refimg()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub imgcancelfalse1()
        txtimg1.Text = ""
        btnimgadd1.Text = "Add Photo"
        btnimgrename1.Text = "Rename"
        btnimgadd1.Enabled = True
        btnimgrename1.Enabled = True
        btnimgcancel1.Enabled = False
    End Sub

    Public Sub imgcanceltrue1()
        btnimgadd1.Enabled = False
        btnimgrename1.Enabled = False
        btnimgcancel1.Enabled = True
    End Sub

    Private Sub btnimgcancel1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel1.Click
        imgpanel1.Enabled = True
        imgbox.Image = Nothing
        txtimg1.Text = ""
        'lblimgid1.Text = ""
        imgcancelfalse1()

        If meron = False Then
            btnimgrename1.Enabled = False
            btnimgcancel1.Enabled = False
        Else
            imgcancelfalse1()
        End If
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        Me.Close()
    End Sub

    Private Sub cmbcus_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbcus.Leave
        Try
            If Trim(cmbcus.Text) <> "" Then

                sql = "Select * from tblcustomer where customer='" & Trim(cmbcus.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbcus.SelectedItem = dr("customer")
                Else
                    cmbcus.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

            Else
                cmbcus.SelectedItem = ""
                cmbcus.Text = ""
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbcus_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcus.SelectedIndexChanged

    End Sub

    Private Sub imgbox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles imgbox.Click
        If imgbox.Image IsNot Nothing Then
            viewimage.lblimgname.Text = ""
            viewimage.imgbox.Image = imgbox.Image
            viewimage.ShowDialog()
        End If
    End Sub

    Private Sub grdorders_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdorders.CellContentClick

    End Sub
End Class