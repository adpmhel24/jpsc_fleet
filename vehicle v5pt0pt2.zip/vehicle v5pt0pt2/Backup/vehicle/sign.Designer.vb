﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class sign
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(sign))
        Me.sigPlusNET1 = New Topaz.SigPlusNET
        Me.label1 = New System.Windows.Forms.Label
        Me.cboEncryption = New System.Windows.Forms.ComboBox
        Me.cboPenWidth = New System.Windows.Forms.ComboBox
        Me.cmdLoadSig = New System.Windows.Forms.Button
        Me.cmdSaveSig = New System.Windows.Forms.Button
        Me.cmdSaveImage = New System.Windows.Forms.Button
        Me.groupBox6 = New System.Windows.Forms.GroupBox
        Me.cboCompression = New System.Windows.Forms.ComboBox
        Me.cmdClose = New System.Windows.Forms.Button
        Me.btnclear1 = New System.Windows.Forms.Button
        Me.cmdStop = New System.Windows.Forms.Button
        Me.btnsave = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btnclear2 = New System.Windows.Forms.Button
        Me.SigPlusNET2 = New Topaz.SigPlusNET
        Me.imgdriver = New System.Windows.Forms.PictureBox
        Me.imgguard = New System.Windows.Forms.PictureBox
        Me.lbltrip = New System.Windows.Forms.Label
        Me.lblrems = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.btnclear3 = New System.Windows.Forms.Button
        Me.SigPlusNET3 = New Topaz.SigPlusNET
        Me.imgother = New System.Windows.Forms.PictureBox
        Me.lblplate = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.SigPlusNET4 = New Topaz.SigPlusNET
        Me.btnclear4 = New System.Windows.Forms.Button
        Me.imghelper = New System.Windows.Forms.PictureBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.groupBox6.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.imgdriver, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgguard, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.imgother, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.imghelper, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'sigPlusNET1
        '
        Me.sigPlusNET1.BackColor = System.Drawing.Color.White
        Me.sigPlusNET1.ForeColor = System.Drawing.Color.Black
        Me.sigPlusNET1.Location = New System.Drawing.Point(11, 21)
        Me.sigPlusNET1.Name = "sigPlusNET1"
        Me.sigPlusNET1.Size = New System.Drawing.Size(320, 136)
        Me.sigPlusNET1.TabIndex = 23
        Me.sigPlusNET1.Text = "sigPlusNET1"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(42, 585)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(57, 13)
        Me.label1.TabIndex = 22
        Me.label1.Text = "Pen Width"
        '
        'cboEncryption
        '
        Me.cboEncryption.FormattingEnabled = True
        Me.cboEncryption.Items.AddRange(New Object() {"0", "1", "2"})
        Me.cboEncryption.Location = New System.Drawing.Point(83, 19)
        Me.cboEncryption.Name = "cboEncryption"
        Me.cboEncryption.Size = New System.Drawing.Size(58, 21)
        Me.cboEncryption.TabIndex = 6
        Me.cboEncryption.Text = "0"
        '
        'cboPenWidth
        '
        Me.cboPenWidth.FormattingEnabled = True
        Me.cboPenWidth.Items.AddRange(New Object() {"5", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"})
        Me.cboPenWidth.Location = New System.Drawing.Point(45, 601)
        Me.cboPenWidth.Name = "cboPenWidth"
        Me.cboPenWidth.Size = New System.Drawing.Size(58, 21)
        Me.cboPenWidth.TabIndex = 21
        Me.cboPenWidth.Text = "1"
        '
        'cmdLoadSig
        '
        Me.cmdLoadSig.Location = New System.Drawing.Point(109, 599)
        Me.cmdLoadSig.Name = "cmdLoadSig"
        Me.cmdLoadSig.Size = New System.Drawing.Size(60, 23)
        Me.cmdLoadSig.TabIndex = 20
        Me.cmdLoadSig.Text = "Load Sig"
        Me.cmdLoadSig.UseVisualStyleBackColor = True
        '
        'cmdSaveSig
        '
        Me.cmdSaveSig.Location = New System.Drawing.Point(175, 599)
        Me.cmdSaveSig.Name = "cmdSaveSig"
        Me.cmdSaveSig.Size = New System.Drawing.Size(61, 23)
        Me.cmdSaveSig.TabIndex = 19
        Me.cmdSaveSig.Text = "Save Sig"
        Me.cmdSaveSig.UseVisualStyleBackColor = True
        '
        'cmdSaveImage
        '
        Me.cmdSaveImage.Location = New System.Drawing.Point(109, 539)
        Me.cmdSaveImage.Name = "cmdSaveImage"
        Me.cmdSaveImage.Size = New System.Drawing.Size(75, 23)
        Me.cmdSaveImage.TabIndex = 18
        Me.cmdSaveImage.Text = "Save Image"
        Me.cmdSaveImage.UseVisualStyleBackColor = True
        '
        'groupBox6
        '
        Me.groupBox6.Controls.Add(Me.cboEncryption)
        Me.groupBox6.Controls.Add(Me.cboCompression)
        Me.groupBox6.Location = New System.Drawing.Point(196, 539)
        Me.groupBox6.Name = "groupBox6"
        Me.groupBox6.Size = New System.Drawing.Size(147, 49)
        Me.groupBox6.TabIndex = 17
        Me.groupBox6.TabStop = False
        Me.groupBox6.Text = "Compression / Encryption"
        '
        'cboCompression
        '
        Me.cboCompression.FormattingEnabled = True
        Me.cboCompression.Items.AddRange(New Object() {"0", "1", "2"})
        Me.cboCompression.Location = New System.Drawing.Point(6, 19)
        Me.cboCompression.Name = "cboCompression"
        Me.cboCompression.Size = New System.Drawing.Size(58, 21)
        Me.cboCompression.TabIndex = 6
        Me.cboCompression.Text = "0"
        '
        'cmdClose
        '
        Me.cmdClose.Location = New System.Drawing.Point(242, 599)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(75, 23)
        Me.cmdClose.TabIndex = 16
        Me.cmdClose.Text = "Close"
        Me.cmdClose.UseVisualStyleBackColor = True
        '
        'btnclear1
        '
        Me.btnclear1.Location = New System.Drawing.Point(256, 167)
        Me.btnclear1.Name = "btnclear1"
        Me.btnclear1.Size = New System.Drawing.Size(75, 23)
        Me.btnclear1.TabIndex = 15
        Me.btnclear1.Text = "Clear"
        Me.btnclear1.UseVisualStyleBackColor = True
        '
        'cmdStop
        '
        Me.cmdStop.Location = New System.Drawing.Point(109, 573)
        Me.cmdStop.Name = "cmdStop"
        Me.cmdStop.Size = New System.Drawing.Size(75, 23)
        Me.cmdStop.TabIndex = 14
        Me.cmdStop.Text = "Stop"
        Me.cmdStop.UseVisualStyleBackColor = True
        '
        'btnsave
        '
        Me.btnsave.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnsave.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Image = CType(resources.GetObject("btnsave.Image"), System.Drawing.Image)
        Me.btnsave.Location = New System.Drawing.Point(12, 475)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(703, 40)
        Me.btnsave.TabIndex = 25
        Me.btnsave.Text = "Ok"
        Me.btnsave.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnsave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox1.Controls.Add(Me.sigPlusNET1)
        Me.GroupBox1.Controls.Add(Me.btnclear1)
        Me.GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.GroupBox1.Location = New System.Drawing.Point(12, 60)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(342, 196)
        Me.GroupBox1.TabIndex = 26
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Driver"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox2.Controls.Add(Me.btnclear2)
        Me.GroupBox2.Controls.Add(Me.SigPlusNET2)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 262)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(342, 196)
        Me.GroupBox2.TabIndex = 27
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Guard"
        '
        'btnclear2
        '
        Me.btnclear2.ForeColor = System.Drawing.Color.Black
        Me.btnclear2.Location = New System.Drawing.Point(256, 167)
        Me.btnclear2.Name = "btnclear2"
        Me.btnclear2.Size = New System.Drawing.Size(75, 23)
        Me.btnclear2.TabIndex = 28
        Me.btnclear2.Text = "Clear"
        Me.btnclear2.UseVisualStyleBackColor = True
        '
        'SigPlusNET2
        '
        Me.SigPlusNET2.BackColor = System.Drawing.Color.White
        Me.SigPlusNET2.ForeColor = System.Drawing.Color.Black
        Me.SigPlusNET2.Location = New System.Drawing.Point(11, 21)
        Me.SigPlusNET2.Name = "SigPlusNET2"
        Me.SigPlusNET2.Size = New System.Drawing.Size(320, 136)
        Me.SigPlusNET2.TabIndex = 23
        Me.SigPlusNET2.Text = "SigPlusNET2"
        '
        'imgdriver
        '
        Me.imgdriver.Location = New System.Drawing.Point(742, 159)
        Me.imgdriver.Name = "imgdriver"
        Me.imgdriver.Size = New System.Drawing.Size(136, 91)
        Me.imgdriver.TabIndex = 28
        Me.imgdriver.TabStop = False
        '
        'imgguard
        '
        Me.imgguard.Location = New System.Drawing.Point(742, 60)
        Me.imgguard.Name = "imgguard"
        Me.imgguard.Size = New System.Drawing.Size(136, 91)
        Me.imgguard.TabIndex = 29
        Me.imgguard.TabStop = False
        '
        'lbltrip
        '
        Me.lbltrip.AutoSize = True
        Me.lbltrip.Location = New System.Drawing.Point(9, 539)
        Me.lbltrip.Name = "lbltrip"
        Me.lbltrip.Size = New System.Drawing.Size(28, 13)
        Me.lbltrip.TabIndex = 30
        Me.lbltrip.Text = "trip#"
        '
        'lblrems
        '
        Me.lblrems.AutoSize = True
        Me.lblrems.Location = New System.Drawing.Point(12, 558)
        Me.lblrems.Name = "lblrems"
        Me.lblrems.Size = New System.Drawing.Size(46, 13)
        Me.lblrems.TabIndex = 31
        Me.lblrems.Text = "trip rems"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox3.Controls.Add(Me.btnclear3)
        Me.GroupBox3.Controls.Add(Me.SigPlusNET3)
        Me.GroupBox3.Location = New System.Drawing.Point(373, 262)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(342, 196)
        Me.GroupBox3.TabIndex = 32
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Other"
        '
        'btnclear3
        '
        Me.btnclear3.ForeColor = System.Drawing.Color.Black
        Me.btnclear3.Location = New System.Drawing.Point(256, 167)
        Me.btnclear3.Name = "btnclear3"
        Me.btnclear3.Size = New System.Drawing.Size(75, 23)
        Me.btnclear3.TabIndex = 28
        Me.btnclear3.Text = "Clear"
        Me.btnclear3.UseVisualStyleBackColor = True
        '
        'SigPlusNET3
        '
        Me.SigPlusNET3.BackColor = System.Drawing.Color.White
        Me.SigPlusNET3.ForeColor = System.Drawing.Color.Black
        Me.SigPlusNET3.Location = New System.Drawing.Point(11, 21)
        Me.SigPlusNET3.Name = "SigPlusNET3"
        Me.SigPlusNET3.Size = New System.Drawing.Size(320, 136)
        Me.SigPlusNET3.TabIndex = 23
        Me.SigPlusNET3.Text = "SigPlusNET3"
        '
        'imgother
        '
        Me.imgother.Location = New System.Drawing.Point(884, 60)
        Me.imgother.Name = "imgother"
        Me.imgother.Size = New System.Drawing.Size(136, 93)
        Me.imgother.TabIndex = 33
        Me.imgother.TabStop = False
        '
        'lblplate
        '
        Me.lblplate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblplate.BackColor = System.Drawing.Color.Transparent
        Me.lblplate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate.Location = New System.Drawing.Point(12, 9)
        Me.lblplate.Name = "lblplate"
        Me.lblplate.Size = New System.Drawing.Size(703, 38)
        Me.lblplate.TabIndex = 70
        Me.lblplate.Text = "Label2"
        Me.lblplate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox4.Controls.Add(Me.SigPlusNET4)
        Me.GroupBox4.Controls.Add(Me.btnclear4)
        Me.GroupBox4.ForeColor = System.Drawing.Color.Black
        Me.GroupBox4.Location = New System.Drawing.Point(373, 60)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(342, 196)
        Me.GroupBox4.TabIndex = 27
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Helper"
        '
        'SigPlusNET4
        '
        Me.SigPlusNET4.BackColor = System.Drawing.Color.White
        Me.SigPlusNET4.ForeColor = System.Drawing.Color.Black
        Me.SigPlusNET4.Location = New System.Drawing.Point(11, 21)
        Me.SigPlusNET4.Name = "SigPlusNET4"
        Me.SigPlusNET4.Size = New System.Drawing.Size(320, 136)
        Me.SigPlusNET4.TabIndex = 23
        Me.SigPlusNET4.Text = "SigPlusNET4"
        '
        'btnclear4
        '
        Me.btnclear4.Location = New System.Drawing.Point(256, 167)
        Me.btnclear4.Name = "btnclear4"
        Me.btnclear4.Size = New System.Drawing.Size(75, 23)
        Me.btnclear4.TabIndex = 15
        Me.btnclear4.Text = "Clear"
        Me.btnclear4.UseVisualStyleBackColor = True
        '
        'imghelper
        '
        Me.imghelper.Location = New System.Drawing.Point(884, 159)
        Me.imghelper.Name = "imghelper"
        Me.imghelper.Size = New System.Drawing.Size(136, 91)
        Me.imghelper.TabIndex = 71
        Me.imghelper.TabStop = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(740, 253)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 72
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'sign
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(727, 527)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.imghelper)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.lblplate)
        Me.Controls.Add(Me.imgother)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.lblrems)
        Me.Controls.Add(Me.lbltrip)
        Me.Controls.Add(Me.imgguard)
        Me.Controls.Add(Me.imgdriver)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.cboPenWidth)
        Me.Controls.Add(Me.cmdLoadSig)
        Me.Controls.Add(Me.cmdSaveSig)
        Me.Controls.Add(Me.cmdSaveImage)
        Me.Controls.Add(Me.groupBox6)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.cmdStop)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "sign"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Signature"
        Me.groupBox6.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.imgdriver, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgguard, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.imgother, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.imghelper, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents sigPlusNET1 As Topaz.SigPlusNET
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents cboEncryption As System.Windows.Forms.ComboBox
    Private WithEvents cboPenWidth As System.Windows.Forms.ComboBox
    Private WithEvents cmdLoadSig As System.Windows.Forms.Button
    Private WithEvents cmdSaveSig As System.Windows.Forms.Button
    Private WithEvents cmdSaveImage As System.Windows.Forms.Button
    Private WithEvents groupBox6 As System.Windows.Forms.GroupBox
    Private WithEvents cboCompression As System.Windows.Forms.ComboBox
    Private WithEvents cmdClose As System.Windows.Forms.Button
    Private WithEvents btnclear1 As System.Windows.Forms.Button
    Private WithEvents cmdStop As System.Windows.Forms.Button
    Private WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Private WithEvents btnclear2 As System.Windows.Forms.Button
    Private WithEvents SigPlusNET2 As Topaz.SigPlusNET
    Friend WithEvents imgdriver As System.Windows.Forms.PictureBox
    Friend WithEvents imgguard As System.Windows.Forms.PictureBox
    Friend WithEvents lbltrip As System.Windows.Forms.Label
    Friend WithEvents lblrems As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Private WithEvents btnclear3 As System.Windows.Forms.Button
    Private WithEvents SigPlusNET3 As Topaz.SigPlusNET
    Friend WithEvents imgother As System.Windows.Forms.PictureBox
    Friend WithEvents lblplate As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Private WithEvents SigPlusNET4 As Topaz.SigPlusNET
    Private WithEvents btnclear4 As System.Windows.Forms.Button
    Friend WithEvents imghelper As System.Windows.Forms.PictureBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
