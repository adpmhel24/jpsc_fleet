﻿Imports System.IO
Imports System.Data.SqlClient

Public Class tripaddconfirm
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        grd.Rows.Clear()
        txtdatepick.Text = ""
        txtdriver.Text = ""
        txthelper.Text = ""
        txtplate.Text = ""
        lblvtype.Text = ""
        lblmake.Text = ""
        txtrems.Text = ""
        txtorigin.Text = ""
        txtetd.Text = ""
        Me.Close()
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            'CHECK FIELDS

            'insert to tbltripsum
            loadtripnum()
            'check muna kung may trip# na na ganun para di na umulet
            sql = "Select * from tbltripsum where tripnum='" & lbltripnum.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Me.Cursor = Cursors.Default
                MsgBox("System connection error." & vbCrLf & "Please close the system first.", MsgBoxStyle.Critical, "")
                Exit Sub
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If lbltripnum.Text = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("System connection error." & vbCrLf & "Please close the system first.", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Executeadd(strconn)
            tripadd.chkpick.Checked = False
            
            Me.Close()
            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub Executeadd(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            ' Start a local transaction
            transaction = connection.BeginTransaction("AddTripTransaction")

            ' Must assign both transaction object and connection 
            ' to Command object for a pending local transaction.
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                'icheck kung may trip na ung mga nasa datagridview
                For Each row As DataGridViewRow In grd.Rows
                    Dim trans As String = grd.Rows(row.Index).Cells(1).Value
                    sql = "Select * from tbltripitems where transnum='" & trans & "' and (status='1' or status='2')"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    If dr.Read Then
                        'may tripnumber na createdby
                        MsgBox("Transaction# " & trans & " is already included in trip# " & dr("tripnum") & " createdby " & dr("createdby") & ".", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                    dr.Dispose()
                Next

                Dim trnum As String = "1", temp As String = ""
                'check kung pang ilang tripnum NA SA YEAR NA 2018 na
                sql = "Select Count(tripsumid) from tbltripsum where tripyear=Year(GetDate()) and whsename='" & login.whse & "'"
                command.CommandText = sql
                trnum = command.ExecuteScalar + 1

                Dim prefix As String = ""
                If login.whse = "C3 Manila" Then
                    prefix = "MNL"
                ElseIf login.whse = "Calamba" Then
                    prefix = "CAL"
                ElseIf login.whse = "Pagbilao" Then
                    prefix = "PGB"
                ElseIf login.whse = "Lucena" Then
                    prefix = "LUC"
                ElseIf login.whse = "Milaor" Then
                    prefix = "MIL"
                ElseIf login.whse = "Lc Office" Then
                    prefix = "LCO"
                ElseIf login.whse = "Cebu" Then
                    prefix = "CEB"
                ElseIf login.whse = "Davao" Then
                    prefix = "DAV"
                ElseIf login.whse = "Bacolod" Then
                    prefix = "BCD"
                ElseIf login.whse = "Tacloban" Then
                    prefix = "TAC"
                ElseIf login.whse = "JP-Store" Then
                    prefix = "JST"
                End If

                If trnum < 1000000 Then
                    For vv As Integer = 1 To 6 - trnum.Length
                        temp += "0"
                    Next
                End If

                lbltripnum.Text = "T." & prefix & "-" & Format(Date.Now, "yy") & "-" & temp & trnum
                Dim reppick As Integer = 0
                If chkpick.Checked = True Then
                    reppick = 1
                End If
                command.CommandText = "Insert into tbltripsum (tripyear, whsename, tripnum, platenum, driver, helper, origin, datepick, etd, remarks, odostart, odoactual, odoend, diswith, diswout, dshould, dieselbeg, dieselactual, podiesel, addpo, postaddpo, dieselend, taxi, loadscale, repair, rescue, datecreated, createdby, datemodified, modifiedby, status, assigned) values (Year(GetDate()), '" & login.whse & "', '" & lbltripnum.Text & "', '" & txtplate.Text & "', '" & txtdriver.Text & "', '" & Trim(txthelper.Text) & "', '" & txtorigin.Text & "', '" & CDate(txtdatepick.Text) & "', '" & CDate(Trim(txtetd.Text)) & "', '" & Trim(txtrems.Text) & "', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '" & reppick & "', '-', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1', '" & lblassigned.Text & "')"
                command.ExecuteNonQuery()

                If lblvtype.Text = "CUSTOMER TRUCK" Then
                    Dim cuswhse As Boolean = False, cupier As Boolean = False
                    For Each row As DataGridViewRow In grd.Rows
                        If grd.Rows(row.Index).Cells(4).Value = "CUSTOMER SALES TRANSACTION WHSE" Then
                            cuswhse = True
                            Exit For
                        ElseIf grd.Rows(row.Index).Cells(4).Value.ToString.Contains("CUSTOMER SALES TRANSACTION PICKUP FRM ") Then '/And Not grd.Rows(row.Index).Cells(4).Value.ToString.Contains("AGI") Then
                            cupier = True
                        End If
                    Next

                    If cuswhse = True Then
                        'customer pickup from whse may loading
                        'customer pickup from whse may loading STEP 3, 4, 6, 7, 9 LANG
                        sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '1','', '1','', '0','', '0','', '1','', '0','', '0', '', '1', '', '0', '', '', '0', '', '" & login.whse & "')"
                    ElseIf cupier = True Then
                        'CUSTOMER DIRECT PICKUP FRM PIER STEP7 AND 9 LANG
                        sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '1','', '1','', '1','', '1','', '1','', '1','', '0', '', '1', '', '0', '', '', '0', '', '" & login.whse & "')"
                    Else
                        'customer pickup from agi WLNG LOADING
                        'customer pickup from agi WLNG LOADING STEP 4, 6, 7, 9 LANG si logistics panggabi gawa dr then agi nagbbigay resibo
                        sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '1','', '1','', '1','', '0','', '1','', '0','', '0', '', '1', '', '0', '', '', '0', '', '" & login.whse & "')"
                    End If

                ElseIf lblvtype.Text = "TRUCKING TRUCK" Then

                    Dim trwhse As Boolean = False, tragipier As Boolean = False
                    For Each row As DataGridViewRow In grd.Rows
                        If grd.Rows(row.Index).Cells(4).Value = "TRUCKING SALES TRANSACTION WHSE" Or grd.Rows(row.Index).Cells(4).Value = "TRUCKING STOCK TRANSFER WHSE TO WHSE" Then
                            trwhse = True
                            Exit For
                        ElseIf (grd.Rows(row.Index).Cells(4).Value.ToString.Contains("TRUCKING SALES TRANSACTION PICKUP FRM ") Or grd.Rows(row.Index).Cells(4).Value.ToString.Contains("TRUCKING STOCK TRANSFER PICKUP FRM ")) And (grd.Rows(row.Index).Cells(4).Value.ToString.Contains("AGI") Or grd.Rows(row.Index).Cells(4).Value.ToString.Contains("PIER")) Then
                            tragipier = True
                        End If
                    Next

                    If trwhse = True Then
                        'TRUCKING SALES TRANSACTION WHSE 3, 4, 6, 7, 9 LANG
                        sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '1','', '1','', '0','', '0','', '1','', '0','', '0', '', '1', '', '0', '', '', '0', '', '" & login.whse & "')"
                    ElseIf tragipier = True Then
                        'STEP 4, 6, 7, 9 LANG
                        sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '1','', '1','', '1','', '0','', '1','', '0','', '0', '', '1', '', '0', '', '', '0', '', '" & login.whse & "')"
                    Else
                        'STEP 7, 9 LANG
                        sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '1','', '1','', '1','', '1','', '1','', '1','', '0', '', '1', '', '0', '', '', '0', '', '" & login.whse & "')"
                    End If

                Else
                    'ALL JPOON OR AGI TRUCKS AND SERVICES
                    Dim allpickup As Boolean = False, stocksupp As Boolean = False, withpupagic3 As Boolean = False
                    For Each row As DataGridViewRow In grd.Rows
                        If grd.Rows(row.Index).Cells(4).Value.ToString.Contains("PICKUP") = True Then
                            allpickup = True

                            If (grd.Rows(row.Index).Cells(4).Value.ToString.Contains("FRM AGI") = True Or grd.Rows(row.Index).Cells(4).Value.ToString.Contains("FRM LUDO LUYM") = True) And login.whse = "C3 Manila" Then
                                withpupagic3 = True
                            End If
                        Else
                            allpickup = False
                            Exit For
                        End If
                    Next

                    Dim chkoro As Boolean = True
                    For Each row As DataGridViewRow In grd.Rows
                        If Val(grd.Rows(row.Index).Cells(5).Value.ToString) <> 3 Then
                            chkoro = False
                            Exit For
                        End If
                    Next
                    '/MsgBox(chkoro)

                    If lblmake.Text = "Service" Then
                        If allpickup = False Then
                            If chkoro = True Then
                                'STEP 1,2,3,5,6,7,9
                                sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '0','', '0','', '0','', '1','', '0','', '0','', '0', '', '1', '', '0', '', '', '0', '', '" & login.whse & "')"
                            Else
                                'STEP 1,2,3,4,5,6,7,9
                                sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '0','', '0','', '0','', '0','', '0','', '0','', '0', '', '1', '', '0', '', '', '0', '', '" & login.whse & "')"
                            End If

                        ElseIf allpickup = True Then
                            'ITO YUNG MGA PUP AGI OR PIER WLANG STEP3
                            If withpupagic3 = True Then     'FOR C3ONLY WLNG STEP4
                                'STEP 1,2,5,6,7,9
                                sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '0','', '0','', '1','', '1','', '0','', '0','', '0', '', '1', '', '0', '', '', '0', '', '" & login.whse & "')"

                            ElseIf withpupagic3 = False Then
                                If chkoro = True Then
                                    'STEP 1,2,5,6,7,9
                                    sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '0','', '0','', '1','', '1','', '0','', '0','', '0', '', '1', '', '0', '', '', '0', '', '" & login.whse & "')"
                                Else
                                    'STEP 1,2,4,5,6,7,9
                                    sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '0','', '0','', '1','', '0','', '0','', '0','', '0', '', '1', '', '0', '', '', '0', '', '" & login.whse & "')"
                                End If
                            End If
                        End If

                    ElseIf lblmake.Text = "Truck" Then
                        If allpickup = False Then
                            If chkoro = True Then
                                'STEP 1,2,3,5,6,7,8,9
                                sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '0','', '0','', '0','', '1','', '0','', '0','', '0', '', '0', '', '0', '', '', '0', '', '" & login.whse & "')"
                            Else
                                'STEP 1,2,3,4,5,6,7,8,9
                                sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '0','', '0','', '0','', '0','', '0','', '0','', '0', '', '0', '', '0', '', '', '0', '', '" & login.whse & "')"
                            End If

                        ElseIf allpickup = True Then
                            'ITO YUNG MGA PUP AGI OR PIER WLANG STEP3
                            If withpupagic3 = True Then     'FOR C3ONLY WLNG STEP4
                                'STEP 1,2,5,6,7,8,9
                                sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '0','', '0','', '1','', '1','', '0','', '0','', '0', '', '0', '', '0', '', '', '0', '', '" & login.whse & "')"

                            ElseIf withpupagic3 = False Then
                                If chkoro = True Then
                                    'STEP 1,2,5,6,7,8,9
                                    sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '0','', '0','', '1','', '1','', '0','', '0','', '0', '', '0', '', '0', '', '', '0', '', '" & login.whse & "')"
                                Else
                                    'STEP 1,2,4,5,6,7,8,9
                                    sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '0','', '0','', '1','', '0','', '0','', '0','', '0', '', '0', '', '0', '', '', '0', '', '" & login.whse & "')"
                                End If
                            End If
                        End If
                    End If
                End If

                command.CommandText = sql
                command.ExecuteNonQuery()

                'insert to tbltripitems
                For Each row As DataGridViewRow In grd.Rows
                    Dim cus As String = grd.Rows(row.Index).Cells(3).Value
                    command.CommandText = "Insert into tbltripitems (tripnum, transnum, transtype, datecreated, createdby, datemodified, modifiedby, alreadydisp, status, record)"
                    command.CommandText = command.CommandText & " values ('" & lbltripnum.Text & "','" & grd.Rows(row.Index).Cells(1).Value & "','" & grd.Rows(row.Index).Cells(4).Value & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '0', '1',"
                    command.CommandText = command.CommandText & "(Select record from tblcustomer where customer='" & cus & "' and status='1'))"
                    command.ExecuteNonQuery()
                Next

                'update status ng so In Process na sya 
                For Each row As DataGridViewRow In grd.Rows
                    command.CommandText = "Update tblortrans set status='0', datemodified=GetDate(), modifiedby='" & login.cashier & "' where transnum='" & grd.Rows(row.Index).Cells(1).Value & "'"
                    command.ExecuteNonQuery()

                    If grd.Rows(row.Index).Cells(2).Value.ToString.Contains("SWS#") Then
                        Dim data As Byte(), imgname As String = ""
                        command.CommandText = "Select * from tblorimage where transnum='" & grd.Rows(row.Index).Cells(1).Value & "'"
                        dr = command.ExecuteReader
                        If dr.Read Then
                            imgname = dr("name")
                            data = DirectCast(dr("img"), Byte())
                            'isang picture lang yung massave kada transnum
                        End If
                        dr.Dispose()
                        '/cmd.Dispose()
                        '/conn.Close()

                        command.Parameters.Clear()
                        command.CommandText = "Insert into tbldispatchstp4 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltripnum.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", imgname))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        Dim img As New SqlParameter("@img", SqlDbType.Image)
                        img.Value = data
                        command.Parameters.Add(img)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()

                    ElseIf grd.Rows(row.Index).Cells(2).Value.ToString.Contains("FOLLOW") Then
                        Dim data As Byte(), imgname As String = ""
                        command.CommandText = "Select * from tblorimage where transnum='" & grd.Rows(row.Index).Cells(1).Value & "'"
                        dr = command.ExecuteReader
                        If dr.Read Then
                            imgname = dr("name")
                            data = DirectCast(dr("img"), Byte())
                            'isang picture lang yung massave kada transnum
                        End If
                        dr.Dispose()
                        '/cmd.Dispose()
                        '/conn.Close()
                        command.Parameters.Clear()
                        command.CommandText = "Insert into tbldispatchstp4 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltripnum.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", imgname))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        Dim img As New SqlParameter("@img", SqlDbType.Image)
                        img.Value = data
                        command.Parameters.Add(img)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If
                Next

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default                '/MsgBox("Both records are written to database.")
                MsgBox("Successfully Added Trip", MsgBoxStyle.Information, "")
                btncancel.PerformClick()
                tripadd.cmbplate.Text = ""
                tripadd.cmbdriver.Text = ""
                tripadd.cmbhelper.Text = ""
                tripadd.txtrems.Text = ""
                tripadd.cmbwhse.Text = ""
                tripadd.txtetd.Text = ""
                tripadd.defaultload()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                '/Console.WriteLine("Commit Exception Type: {0}", ex.GetType())
                '/Console.WriteLine("  Message: {0}", ex.Message)
                '/Dim typeName = ex.GetType().Name
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    ' This catch block will handle any errors that may have occurred 
                    ' on the server that would cause the rollback to fail, such as 
                    ' a closed connection.
                    Me.Cursor = Cursors.Default
                    '/Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType())
                    '/Console.WriteLine("  Message: {0}", ex2.Message)
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Click Confirm again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub tripaddconfirm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            lbltripnum.Text = ""
            loadtripnum()

            sql = "Select * from tblgeneral where platenum='" & txtplate.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                lblvtype.Text = dr("vtype")
                lblmake.Text = dr("makename")
                lblassigned.Text = dr("whsename")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub loadtripnum()
        Try
            Dim trnum As String = "1", temp As String = ""
            sql = "Select Top 1 * from tbltripsum order by tripsumid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                '/trnum = Val(dr("tripsumid")) + 1
            End If
            cmd.Dispose()
            dr.Dispose()
            conn.Close()

            'check kung pang ilang tripnum NA SA YEAR NA 2018 na
            sql = "Select Count(tripsumid) from tbltripsum where tripyear=Year(GetDate()) and whsename='" & login.whse & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            trnum = cmd.ExecuteScalar + 1
            cmd.Dispose()
            conn.Close()

            Dim prefix As String = ""
            If login.whse = "C3 Manila" Then
                prefix = "MNL"
            ElseIf login.whse = "Calamba" Then
                prefix = "CAL"
            ElseIf login.whse = "Pagbilao" Then
                prefix = "PGB"
            ElseIf login.whse = "Lucena" Then
                prefix = "LUC"
            ElseIf login.whse = "Milaor" Then
                prefix = "MIL"
            ElseIf login.whse = "Lc Office" Then
                prefix = "LCO"
            ElseIf login.whse = "Cebu" Then
                prefix = "CEB"
            ElseIf login.whse = "Davao" Then
                prefix = "DAV"
            ElseIf login.whse = "Bacolod" Then
                prefix = "BCD"
            ElseIf login.whse = "Tacloban" Then
                prefix = "TAC"
            ElseIf login.whse = "JP-Store" Then
                prefix = "JST"
            End If

            If trnum < 1000000 Then
                For vv As Integer = 1 To 6 - trnum.Length
                    temp += "0"
                Next
                'lbltripnum.Text = Date.Now.Year & "-" & Format(Date.Now, "MM") & Format(Date.Now, "dd") & temp & trnum
            End If

            lbltripnum.Text = "T." & prefix & "-" & Format(Date.Now, "yy") & "-" & temp & trnum

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grd_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grd.CellContentClick
        'link
        If e.ColumnIndex = 1 And e.RowIndex > -1 Then
            Dim cell As DataGridViewCell = grd.Rows(e.RowIndex).Cells(e.ColumnIndex)
            grd.CurrentCell = cell
            ' Me.ContextMenuStrip2.Show(Cursor.Position)
            If grd.RowCount <> 0 Then
                If grd.Item(1, grd.CurrentRow.Index).Value IsNot Nothing Then
                    'MsgBox(grd.Item(12, ii).Value.ToString)
                    viewtrans.Text = "View Transaction"
                    viewtrans.lbltripnum.Text = ""
                    viewtrans.grouptrans.Visible = False
                    viewtrans.txttrans.Text = grd.Item(1, grd.CurrentRow.Index).Value
                    viewtrans.sing = True
                    viewtrans.ShowDialog()
                End If
            End If
        End If
    End Sub

    Private Sub chkpick_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkpick.CheckedChanged
        If chkpick.Checked = True Then
            lblpick.Visible = True
        Else
            lblpick.Visible = False
        End If
    End Sub
End Class