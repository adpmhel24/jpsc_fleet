﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Drawing.Image
Imports System.ComponentModel
Imports System.Net.NetworkInformation
Imports System.Globalization

Public Class vmanage
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Public vmcnf As Boolean = False
    Public dreason As String = "", dfinish As Date
    Dim wctab As String = "tab1"

    Dim ofd As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim pic As PictureBox
    Dim meron As Boolean = False
    Dim culture As CultureInfo = Nothing

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub vmanage_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated

    End Sub

    Private Sub vmanager_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = True
    End Sub

    Private Sub vmanager_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        updatestatusexp()
        updatepmsstatexp()
        forchangeoil.updatetblpmssched()

        loaddoc()
        loadpms()
        loadcompsch()
        loadtypesch()
        loadbody()
        loadmake()
        loadsupplier()
        loaddriver()

        btnok.PerformClick()

        datelastrenew.MaxDate = Date.Now    '/// nag eerrror na lumalagpas kc sya sa maximum date
        dateexpired.MinDate = datelastrenew.Value

        datelastpms.MaxDate = Date.Now    '/// nag eerrror na lumalagpas kc sya sa maximum date

        datelastrenew.CustomFormat = "yyyy/MM/dd"
        dateexpired.CustomFormat = "yyyy/MM/dd"
        datelastpms.CustomFormat = "yyyy/MM/dd"
        datestart.CustomFormat = "yyyy/MM/dd"

        txtmodel.Maximum = Val(Format(Date.Now, "yyyy"))

        datestart.MaxDate = Date.Now
        'datefinish.MinDate = datestart.Value

        grdrepair.Columns(5).ReadOnly = False

        cmbdriver.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbdriver.DropDownStyle = ComboBoxStyle.DropDown
        cmbdriver.AutoCompleteSource = AutoCompleteSource.ListItems
    End Sub

    Private Sub TabControl1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TabControl1.MouseClick
        If TabControl1.SelectedTab Is tab1 Then
            wctab = "tab1"
        ElseIf TabControl1.SelectedTab Is tab2 Then
            wctab = "tab2"
            If lblplatebig.Text = "" Then
                GroupBox6.Enabled = False
            Else
                GroupBox6.Enabled = True
                btnviewalldoc.PerformClick()
                If btnupdatedoc.Text = "Update" Then
                    chkuse.Checked = False
                    chkuse.Checked = True
                End If
            End If
        ElseIf TabControl1.SelectedTab Is tab3 Then
            wctab = "tab3"
            If lblplatebig.Text = "" Then
                GroupBox8.Enabled = False
            Else
                GroupBox8.Enabled = True
                btnpmsview.PerformClick()
            End If
        ElseIf TabControl1.SelectedTab Is tab4 Then
            wctab = "tab4"
            If lblplatebig.Text = "" Then
                GroupBox5.Enabled = False
            Else
                GroupBox5.Enabled = True
                btnimgrefresh.PerformClick()
            End If
        ElseIf TabControl1.SelectedTab Is tab5 Then
            wctab = "tab5"
            If lblplatebig.Text = "" Then
                GroupBox10.Enabled = False
            Else
                GroupBox10.Enabled = True
                btnreprefresh.PerformClick()
            End If
        End If
    End Sub

    Private Sub TabControl1_TabIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl1.TabIndexChanged
        If TabControl1.SelectedTab Is tab1 Then
            wctab = "tab1"
        ElseIf TabControl1.SelectedTab Is tab2 Then
            wctab = "tab2"
        ElseIf TabControl1.SelectedTab Is tab3 Then
            wctab = "tab3"
        ElseIf TabControl1.SelectedTab Is tab4 Then
            wctab = "tab4"
        ElseIf TabControl1.SelectedTab Is tab5 Then
            wctab = "tab5"
        End If
    End Sub

    Public Sub loaddriver()
        Try
            cmbdriver.Items.Clear()
            cmbdriver.Items.Add("")

            sql = "Select * from tbldriver where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbdriver.Items.Add(dr("driver"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadcompsch()
        Try
            cmbcompsch.Items.Clear()

            cmbcompany.Items.Clear()
            cmbcompany.Items.Add("")

            sql = "Select * from tblcompany where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbcompsch.Items.Add(dr("company"))
                cmbcompany.Items.Add(dr("company"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbcompsch.Items.Count <> 0 Then
                cmbcompsch.Items.Add("All")
                cmbcompsch.SelectedIndex = 0
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadtypesch()
        Try
            cmbtypesch.Items.Clear()

            cmbtype.Items.Clear()
            cmbtype.Items.Add("")

            sql = "Select * from tblvtype where status='1' order by vtype"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbtypesch.Items.Add(dr("vtype"))
                cmbtype.Items.Add(dr("vtype"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbtypesch.Items.Count <> 0 Then
                cmbtypesch.Items.Add("All")
                cmbtypesch.SelectedItem = "All"
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadwhsesch()
        Try
            cmbwhsesch.Items.Clear()

            If cmbcompsch.SelectedItem <> "All" Then
                sql = "Select * from tblwhse where status='1' and company='" & cmbcompsch.SelectedItem & "'"
            Else
                sql = "Select * from tblwhse where status='1'"
            End If

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbwhsesch.Items.Add(dr("whsename"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbwhsesch.Items.Count <> 0 Then
                cmbwhsesch.Items.Add("All")
                cmbwhsesch.SelectedIndex = 0
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadwhse()
        Try
            cmbwhse.Items.Clear()
            cmbwhse.Items.Add("")
            cmbpmswhse.Items.Clear()
            cmbpmswhse.Items.Add("")

            sql = "Select * from tblwhse where status='1' and company='" & cmbcompany.SelectedItem & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbwhse.Items.Add(dr("whsename"))
                cmbpmswhse.Items.Add(dr("whsename"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadmake()
        Try
            cmbmake.Items.Clear()
            cmbmake.Items.Add("")

            sql = "Select * from tblmake where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbmake.Items.Add(dr("makename"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadbody()
        Try
            cmbbody.Items.Clear()
            cmbbody.Items.Add("")

            sql = "Select * from tblbody where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbbody.Items.Add(dr("bodytype"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadsupplier()
        Try

            cmbsupplier.Items.Clear()
            cmbsupplier.Items.Add("")

            sql = "Select * from tblsupplier where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbsupplier.Items.Add(dr("supplier"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnrefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrefresh.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            grdplate.Rows.Clear()
            Dim plnum As String = ""

            'sql = sql & " order by vplate, platenum"
            sql = lbllastsearch.Text
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                If dr1("platenum") = "" And dr1("vplate") <> "" Then
                    plnum = dr1("vplate")
                ElseIf dr1("platenum") = "" And dr1("vplate") = "" And dr1("csticker") <> "" Then
                    plnum = dr1("csticker")
                Else
                    plnum = dr1("platenum")
                End If

                grdplate.Rows.Add(dr1("genid"), plnum, dr1("vtype"), "", dr1("status"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            'lblselect.Text = cmbwhsesch.SelectedItem
            'grdplate.Sort(grdplate.Columns(2), ListSortDirection.Ascending)
            'grdplate.Sort(grdplate.Columns(1), ListSortDirection.Ascending)

            loaddoc()
            loadpms()
            loadcompsch()
            loadtypesch()
            loadbody()
            loadmake()
            loadsupplier()

            If grdplate.Rows.Count = 0 Then
                btnvdeac.Enabled = False
                TabControl1.Enabled = False
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            Else
                btnvdeac.Enabled = True
                TabControl1.Enabled = True
                'checknotifdocu and rms
                checknotifgrd()
                grdplate.Enabled = True
                btnupdategen.Enabled = True
                selectionchnge()
            End If

            btnvadd.Text = "Add Vehicle"
            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub updatestatusexp()
        Try
            Me.Cursor = Cursors.WaitCursor
            'update in the frm load
            Dim dnow As Date = CDate(Format(Date.Now, "yyyy/MM/dd"))
            Dim dexp As Date
            Dim db4 As Date
            Dim tempstat As String, odostat As String, pmsstat As String

            sql = "Select * from tbldocexp"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                dexp = CDate(Format(dr("dateexpired"), "yyyy/MM/dd"))
                db4 = CDate(Format(dr("dateexpired").AddDays(-14), "yyyy/MM/dd"))

                If dnow >= dexp Then
                    '    MsgBox("Expired")
                    tempstat = "Expired"
                ElseIf dnow >= db4 And dnow < dexp Then
                    '    MsgBox("Soon to expire")
                    tempstat = "Soon to expire"
                Else
                    '    MsgBox("Updated")
                    tempstat = "Updated"
                End If

                If tempstat <> dr("statusexp").ToString Then
                    sql = "Update tbldocexp set statusexp='" & tempstat & "', datemodified=GetDate() where docid='" & dr("docid") & "'"
                    connect()
                    Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
                    cmd1.ExecuteNonQuery()
                    cmd1.Dispose()
                End If

            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checknotifgrd()
        Try
            For Each row As DataGridViewRow In grdplate.Rows
                Dim temp As Integer = 0

                'tbldocexp
                sql = "Select * from tbldocexp where genid='" & grdplate.Rows(row.Index).Cells(0).Value & "' and status='1' and (statusexp='Soon to expire' or statusexp='Expired')"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                While dr.Read
                    temp = temp + 1
                    ' MsgBox(dr("genid").ToString & " " & dr("docname").ToString)
                    ' If Not listgenid.Items.Contains(dr("genid").ToString) Then
                    ' listgenid.Items.Add(dr("genid").ToString)
                    ' End If
                End While
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                'tblpmssched
                sql = "Select * from tblpmssched where genid='" & grdplate.Rows(row.Index).Cells(0).Value & "' and status='1' and (statusexp='Due Soon' or statusexp='Due Today' or statusexp='Over Due')"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                While dr.Read
                    temp = temp + 1
                    ' MsgBox(dr("genid").ToString & " " & dr("docname").ToString)
                    ' If Not listgenid.Items.Contains(dr("genid").ToString) Then
                    ' listgenid.Items.Add(dr("genid").ToString)
                    ' End If
                End While
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                grdplate.Rows(row.Index).Cells(3).Value = temp

                If temp <> 0 Then
                    grdplate.Rows(row.Index).DefaultCellStyle.BackColor = Color.PeachPuff
                Else
                    grdplate.Rows(row.Index).DefaultCellStyle.BackColor = Color.White
                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnvadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnvadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If btnvadd.Text = "Add Vehicle" Then
                TabControl1.Enabled = True
                'ireset ung mga laman ng tab1
                readonlyfalse()
                lblplatebig.Text = ""
                lblid.Text = ""
                txtplatenum.Text = ""
                txtvplate.Text = ""
                txtsticker.Text = ""
                cmbtype.SelectedItem = ""
                cmbmake.SelectedItem = ""
                cmbbody.SelectedItem = ""
                cmbwhse.SelectedItem = ""
                cmbcompany.SelectedItem = ""
                cmbdriver.Text = ""
                txtdriver.Text = ""
                txtmodel.Text = ""
                txtmotor.Text = ""
                txtchasis.Text = ""
                txtcolor.Text = ""
                cmbsupplier.SelectedItem = ""
                txtnote.Text = ""
                listbox.Items.Clear()
                imgphoto.Image = Nothing
                txtrems.Text = ""
                lblprimary.Text = ""

                txttank.Text = ""
                txtliter.Text = 0
                txtinches.Text = 0
                txtfull.Text = 0
                txtbal.Text = 0
                txtwith.Text = 0
                txtwout.Text = 0

                enabletab1only()

                btnvdeac.Enabled = False
                btnupdategen.Enabled = False
                grdplate.Enabled = False
                btncanceladd.Enabled = True
                GroupBox9.Enabled = False
                btnvadd.Text = "Add"

                If cmbwhsesch.SelectedItem <> "" And cmbwhsesch.SelectedItem <> "All" Then
                    cmbwhse.SelectedItem = cmbwhsesch.SelectedItem
                End If

                genid()
            Else
                'insert in database
                'If (Trim(txtplatenum.Text) <> "" Or Trim(txtvplate.Text) <> "" Or Trim(txtsticker.Text) <> "") And cmbtype.SelectedItem <> "" And cmbmake.SelectedItem <> "" And cmbwhse.SelectedItem <> "" And cmbcompany.SelectedItem <> "" Then
                If Trim(txtplatenum.Text) <> "" And cmbtype.SelectedItem <> "" And cmbmake.SelectedItem <> "" And cmbwhse.SelectedItem <> "" And cmbcompany.SelectedItem <> "" Then
                    'check if already exist
                    Dim exist As Boolean = False
                    If Trim(txtplatenum.Text) = "" And Trim(txtvplate.Text) <> "" Then
                        sql = "Select * from tblgeneral where vplate='" & Trim(txtvplate.Text) & "'"
                    ElseIf Trim(txtplatenum.Text) = "" And Trim(txtvplate.Text) = "" And Trim(txtsticker.Text) <> "" Then
                        sql = "Select * from tblgeneral where csticker='" & Trim(txtsticker.Text) & "'"
                    Else
                        sql = "Select * from tblgeneral where platenum='" & Trim(txtplatenum.Text) & "'"
                    End If

                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        exist = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    If exist = False Then
                        vmcnf = False
                        confirm.ShowDialog()
                        If vmcnf = True Then
                            sql = "Insert into tblgeneral (platenum, vplate, csticker, vtype, makename, bodytype, whsename, company, driver, model, motorno, chasisno, color, supplier, note, remarks, dreason, datecreated, createdby, datemodified, modifiedby, status) values ('" & Trim(txtplatenum.Text) & "', '" & Trim(txtvplate.Text) & "', '" & Trim(txtsticker.Text) & "', '" & cmbtype.SelectedItem & "', '" & cmbmake.SelectedItem & "', '" & cmbbody.SelectedItem & "', '" & cmbwhse.SelectedItem & "', '" & cmbcompany.SelectedItem & "', '" & Trim(txtdriver.Text) & "', '" & Trim(txtmodel.Text) & "', '" & Trim(txtmotor.Text) & "', '" & Trim(txtchasis.Text) & "', '" & Trim(txtcolor.Text) & "', '" & cmbsupplier.SelectedItem & "', '" & Trim(txtnote.Text) & "', '" & Trim(txtrems.Text) & "', '', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            sql = "Insert into tbldiesel (genid, tanksize, liter, fulltank, inches, twoinch, pwith, pwout, datemodified, modifiedby) values ('" & lblid.Text & "', '" & Trim(txttank.Text) & "', '" & Trim(txtliter.Text) & "', '" & Trim(txtfull.Text) & "', '" & Trim(txtinches.Text) & "', '" & Trim(txtbal.Text) & "', '" & Trim(txtwith.Text) & "', '" & Trim(txtwout.Text) & "', GetDate(), '" & login.cashier & "')"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            MsgBox("Successfully Added.", MsgBoxStyle.Information, "")
                        End If
                    End If
                Else
                    MsgBox("You must fill-up the required fields.", MsgBoxStyle.Exclamation, "")
                    txtplatenum.Focus()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If

                vmcnf = False
                btnvdeac.Enabled = True
                btnupdategen.Enabled = True
                btnupdatedoc.Enabled = True
                grdplate.Enabled = True
                btncanceladd.Enabled = True
                GroupBox9.Enabled = True
                btncanceladd.PerformClick()
                btnvadd.Text = "Add Vehicle"

                enableall()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncancelfilter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancelfilter.Click
        txtsearch.Text = ""
    End Sub

    Private Sub btnupdategen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdategen.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If btnupdategen.Text = "Update" And grdplate.Rows(grdplate.CurrentRow.Index).Cells(4).Value = 1 Then
                enabletab1only()
                GroupBox9.Enabled = False
                btnvadd.Enabled = False
                btnvdeac.Enabled = False
                grdplate.Enabled = False
                btncancelupdate.Enabled = True
                btnupdategen.Text = "Save"

                readonlyfalse()

            Else
                'check for required if not null
                If Trim(txtplatenum.Text) <> "" And cmbtype.SelectedItem <> "" And cmbmake.SelectedItem <> "" And cmbwhse.SelectedItem <> "" And cmbcompany.SelectedItem <> "" Then

                    'check if already exist
                    Dim exist As Boolean = False
                    If Trim(txtplatenum.Text) = "" And Trim(txtvplate.Text) <> "" Then
                        sql = "Select * from tblgeneral where vplate='" & Trim(txtvplate.Text) & "' and genid<>'" & lblid.Text & "'"
                    ElseIf Trim(txtplatenum.Text) = "" And Trim(txtvplate.Text) = "" And Trim(txtsticker.Text) <> "" Then
                        sql = "Select * from tblgeneral where csticker='" & Trim(txtsticker.Text) & "' and genid<>'" & lblid.Text & "'"
                    Else
                        sql = "Select * from tblgeneral where platenum='" & Trim(txtplatenum.Text) & "' and genid<>'" & lblid.Text & "'"
                    End If

                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        exist = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    If exist = False Then
                        vmcnf = False
                        confirm.ShowDialog()
                        If vmcnf = True Then
                            'save
                            sql = "Update tblgeneral set platenum='" & Trim(txtplatenum.Text) & "', vplate='" & Trim(txtvplate.Text) & "', csticker='" & Trim(txtsticker.Text) & "', vtype='" & cmbtype.SelectedItem & "', makename='" & cmbmake.SelectedItem & "', bodytype='" & cmbbody.SelectedItem & "', whsename='" & cmbwhse.SelectedItem & "', company='" & cmbcompany.SelectedItem & "', driver='" & Trim(txtdriver.Text) & "', model='" & Trim(txtmodel.Text) & "', motorno='" & Trim(txtmotor.Text) & "', chasisno='" & Trim(txtchasis.Text) & "', color='" & Trim(txtcolor.Text) & "', supplier='" & cmbsupplier.SelectedItem & "', note='" & Trim(txtnote.Text) & "', remarks='" & Trim(txtrems.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where genid='" & lblid.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            sql = "Update tbldiesel set tanksize='" & Trim(txttank.Text) & "', liter='" & Trim(txtliter.Text) & "', fulltank='" & Trim(txtfull.Text) & "', inches='" & Trim(txtinches.Text) & "', twoinch='" & Trim(txtbal.Text) & "', pwith='" & Trim(txtwith.Text) & "', pwout='" & Trim(txtwout.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where genid='" & lblid.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'check platenum
                            sql = "Update tbltripsum set platenum='" & Trim(txtplatenum.Text) & "' where platenum='" & lblplatebig.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")
                        End If
                    End If

                    btncancelupdate.PerformClick()
                Else
                    MsgBox("You must fill-up the required fields.", MsgBoxStyle.Exclamation, "")
                    txtplatenum.Focus()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If

                vmcnf = False

            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncancelupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancelupdate.Click
        GroupBox9.Enabled = True
        btnvadd.Enabled = True
        btnvdeac.Enabled = True
        grdplate.Enabled = True
        btnupdategen.Text = "Update"
        enableall()

        readonlytrue()
        btnrefresh.PerformClick()
        btncancelupdate.Enabled = False
    End Sub

    Public Sub selectionchnge()
        Try
            Me.Cursor = Cursors.WaitCursor

            If grdplate.Rows.Count <> 0 Then

                'lahat ng controls sa tab dpt read only lng
                readonlytrue()
                '//  MsgBox(grdplate.Rows(grdplate.CurrentRow.Index).Cells(1).Value.ToString)
                ' If wctab = "tab1"  Then
                Dim cmd As SqlCommand
                Dim dr As SqlDataReader
                If btnvadd.Text <> "Add" Then
                    Dim plnum As String = ""

                    sql = "Select * from tblgeneral RIGHT OUTER JOIN tbldiesel ON tblgeneral.genid=tbldiesel.genid where tblgeneral.platenum='" & grdplate.Rows(grdplate.CurrentRow.Index).Cells(1).Value & "' or tblgeneral.vplate='" & grdplate.Rows(grdplate.CurrentRow.Index).Cells(1).Value & "' or tblgeneral.csticker='" & grdplate.Rows(grdplate.CurrentRow.Index).Cells(1).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        If dr("platenum") = "" And dr("vplate") <> "" Then
                            plnum = dr("vplate")
                        ElseIf dr("platenum") = "" And dr("vplate") = "" And dr("csticker") <> "" Then
                            plnum = dr("csticker")
                        Else
                            plnum = dr("platenum")
                        End If

                        lblplatebig.Text = plnum
                        lblid.Text = dr("genid")
                        txtplatenum.Text = dr("platenum").ToString
                        txtvplate.Text = dr("vplate").ToString
                        txtsticker.Text = dr("csticker").ToString
                        cmbtype.SelectedItem = dr("vtype").ToString
                        cmbmake.SelectedItem = dr("makename").ToString
                        cmbbody.SelectedItem = dr("bodytype").ToString
                        cmbcompany.SelectedItem = dr("company").ToString
                        cmbwhse.SelectedItem = dr("whsename").ToString
                        cmbdriver.SelectedItem = dr("driver").ToString
                        txtdriver.Text = dr("driver").ToString
                        txtmodel.Text = dr("model").ToString
                        txtmotor.Text = dr("motorno").ToString
                        txtchasis.Text = dr("chasisno").ToString
                        txtcolor.Text = dr("color").ToString

                        cmbsupplier.SelectedItem = dr("supplier").ToString
                        txtnote.Text = dr("note")
                        '////listbox.Items.Clear()
                        '////imgphoto.Image = Nothing
                        txtrems.Text = dr("remarks").ToString
                        If dr("status") = 0 Then
                            lbldreason.Visible = True
                            lbldreason.Text = "Deactivated status: " & dr("dreason").ToString
                        Else
                            lbldreason.Visible = False
                        End If
                        lblprimary.Text = dr("imgid").ToString

                        txttank.Text = dr("tanksize")
                        txtliter.Text = dr("liter")
                        txtinches.Text = dr("inches")
                        txtfull.Text = dr("fulltank")
                        txtbal.Text = dr("twoinch")
                        txtwith.Text = dr("pwith")
                        txtwout.Text = dr("pwout")

                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    imgphoto.Image = Nothing
                    If lblprimary.Text <> "" Then
                        sql = "Select * from tblimage where imgid='" & lblprimary.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            'MsgBox(dr("name").ToString)
                            Dim data As Byte() = DirectCast(dr("img"), Byte())
                            Dim ms As New MemoryStream(data)

                            imgphoto.Image = Image.FromStream(ms)
                            imgphoto.SizeMode = PictureBoxSizeMode.Zoom
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()
                    End If


                    If wctab = "tab2" Then
                        viewalldoc()
                    ElseIf wctab = "tab3" Then
                        'viewallpms()
                        btnpmsview.PerformClick()
                    ElseIf wctab = "tab4" Then
                        btnimgrefresh.PerformClick()
                    ElseIf wctab = "tab5" Then
                        btnreprefresh.PerformClick()
                    End If


                    listbox.Items.Clear()

                    'tbldocexp
                    sql = "Select * from tbldocexp where genid='" & grdplate.Rows(grdplate.CurrentRow.Index).Cells(0).Value & "' and status='1' and (statusexp='Soon to expire' or statusexp='Expired')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    While dr.Read
                        Me.Cursor = Cursors.WaitCursor
                        listbox.Items.Add(dr("docname").ToString & " - " & dr("statusexp").ToString)
                    End While
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    'tblpmssched
                    sql = "Select * from tblpmssched where genid='" & grdplate.Rows(grdplate.CurrentRow.Index).Cells(0).Value & "' and status='1' and (statusexp='Due Soon' or statusexp='Due Today' or statusexp='Over Due')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    While dr.Read
                        Me.Cursor = Cursors.WaitCursor
                        listbox.Items.Add(dr("servicename").ToString & " - " & dr("statusexp").ToString)
                    End While
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If

                Me.Cursor = Cursors.Default

                If grdplate.Rows(grdplate.CurrentRow.Index).Cells(4).Value = 1 Then
                    btnvdeac.Text = "Deactivate"
                    btnupdategen.Enabled = True
                Else
                    btnvdeac.Text = "Activate"
                    btnupdategen.Enabled = False
                End If

                If lblplatebig.Text <> "" Then
                    enableall()
                End If

                checknotifgrd()
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdplate_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdplate.CellClick
        'selectionchnge()
    End Sub

    Private Sub grdplate_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdplate.SelectionChanged
        selectionchnge()
    End Sub

    Public Sub readonlytrue()
        txtplatenum.ReadOnly = True
        txtplatenum.BackColor = Color.White
        txtvplate.ReadOnly = True
        txtvplate.BackColor = Color.White
        txtsticker.ReadOnly = True
        txtsticker.BackColor = Color.White
        cmbtype.Enabled = False
        txtmodel.Enabled = False
        txtmodel.BackColor = Color.White
        cmbmake.Enabled = False
        txtcolor.ReadOnly = True
        txtcolor.BackColor = Color.White
        cmbwhse.Enabled = False
        cmbsupplier.Enabled = False
        txtnote.ReadOnly = True
        txtnote.BackColor = Color.White
        listbox.Enabled = True
        txtrems.ReadOnly = True
        txtrems.BackColor = Color.White

        cmbbody.Enabled = False
        cmbcompany.Enabled = False
        cmbdriver.Enabled = False
        txtdriver.ReadOnly = True
        txtdriver.BackColor = Color.White
        txtmotor.ReadOnly = True
        txtmotor.BackColor = Color.White
        txtchasis.ReadOnly = True
        txtchasis.BackColor = Color.White

        txttank.ReadOnly = True
        txtliter.ReadOnly = True
        txtinches.ReadOnly = True
        txtfull.ReadOnly = True
        txtwith.ReadOnly = True
        txtwout.ReadOnly = True
    End Sub

    Public Sub readonlyfalse()
        txtplatenum.ReadOnly = False
        txtvplate.ReadOnly = False
        txtsticker.ReadOnly = False
        cmbtype.Enabled = True
        txtmodel.Enabled = True
        cmbmake.Enabled = True
        txtcolor.ReadOnly = False
        cmbwhse.Enabled = True
        cmbsupplier.Enabled = True
        txtnote.ReadOnly = False
        listbox.Enabled = True
        txtrems.ReadOnly = False
        cmbbody.Enabled = True
        cmbcompany.Enabled = True
        cmbdriver.Enabled = True
        txtdriver.ReadOnly = False
        txtmotor.ReadOnly = False
        txtchasis.ReadOnly = False

        txttank.ReadOnly = False
        txtliter.ReadOnly = False
        txtinches.ReadOnly = False
        txtfull.ReadOnly = False
        txtwith.ReadOnly = False
        txtwout.ReadOnly = False
    End Sub

    Private Sub btncanceladd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncanceladd.Click
        Try
            Me.Cursor = Cursors.WaitCursor

            enableall()

            GroupBox9.Enabled = True
            btnrefresh.PerformClick()
            btncanceladd.Enabled = False
            GroupBox6.Enabled = True

            selectionchnge()

            Me.Cursor = Cursors.Default
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub btnok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            grdplate.Rows.Clear()
            Dim plnum As String = ""

            If chkdeac.Checked = False Then
                sql = "Select * from tblgeneral where status='1'"
            Else
                sql = "Select * from tblgeneral where status='0'"
            End If

            If Trim(txtsearch.Text) <> "" Then
                sql = sql & " and (platenum like '%" & Trim(txtsearch.Text) & "%' or vplate like '%" & Trim(txtsearch.Text) & "%' or csticker like '%" & Trim(txtsearch.Text) & "%')"
            End If

            If cmbtypesch.SelectedItem <> "" And cmbtypesch.SelectedItem <> "All" Then
                sql = sql & " and vtype ='" & cmbtypesch.SelectedItem & "'"
            End If

            If cmbwhsesch.SelectedItem <> "" And cmbwhsesch.SelectedItem <> "All" Then
                sql = sql & " and whsename ='" & cmbwhsesch.SelectedItem & "'"
            End If

            If cmbcompsch.SelectedItem <> "" And cmbcompsch.SelectedItem <> "All" Then
                sql = sql & " and company ='" & cmbcompsch.SelectedItem & "'"
            End If

            sql = sql & " order by vplate, platenum"

            lbllastsearch.Text = sql
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                If dr1("platenum") = "" And dr1("vplate") <> "" Then
                    plnum = dr1("vplate")
                ElseIf dr1("platenum") = "" And dr1("vplate") = "" And dr1("csticker") <> "" Then
                    plnum = dr1("csticker")
                Else
                    plnum = dr1("platenum")
                End If

                grdplate.Rows.Add(dr1("genid"), plnum, dr1("vtype"), "", dr1("status"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            lblselect.Text = cmbwhsesch.SelectedItem
            'grdplate.Sort(grdplate.Columns(2), ListSortDirection.Ascending)

            loaddoc()
            loadpms()
            loadcompsch()
            loadtypesch()
            loadbody()
            loadmake()
            loadsupplier()

            If grdplate.Rows.Count = 0 Then
                btnvdeac.Enabled = False
                TabControl1.Enabled = False
                Me.Cursor = Cursors.Default
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            Else
                btnvdeac.Enabled = True
                TabControl1.Enabled = True
                'checknotifdocu and rms
                checknotifgrd()
                grdplate.Enabled = True
                btnupdategen.Enabled = True
                selectionchnge()
            End If

            btnvadd.Text = "Add Vehicle"
            txtsearch.Text = ""

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loaddoc()
        Try
            cmbdocname.Items.Clear()
            cmbdocname.Items.Add("")

            sql = "Select * from tbldoc where status='1' order by docname"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbdocname.Items.Add(dr("docname"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadddoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadddoc.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            'check first if complete
            If cmbdocname.SelectedItem <> "" Then
                If chkuse.Checked = True Then
                    If cmbinterval.SelectedItem = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Select tracking interval.", MsgBoxStyle.Exclamation, "")
                        cmbinterval.Focus()
                        Exit Sub
                    End If
                End If

                'check muna if nsa list na.. if wla pde i add.. 
                Dim chkmeronna As Boolean = False
                For Each row As DataGridViewRow In grddoc.Rows
                    If grddoc.Rows(row.Index).Cells(1).Value.ToString.Contains(cmbdocname.SelectedItem) Then
                        chkmeronna = True
                    End If
                Next

                If chkmeronna = False Then
                    'add
                    vmcnf = False
                    confirm.ShowDialog()
                    If vmcnf = True Then
                        statusofexp()

                        sql = "Insert into tbldocexp (genid, docname, datelast, num, interval, dateexpired, datecreated, createdby, datemodified, modifiedby, statusexp, status) values ('" & lblid.Text & "','" & cmbdocname.SelectedItem & "', '" & Format(datelastrenew.Value, "yyyy/MM/dd") & "', '" & num.Value & "', '" & cmbinterval.SelectedItem & "', '" & Format(dateexpired.Value, "yyyy/MM/dd") & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '" & lblexp.Text & "', '1')"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        Me.Cursor = Cursors.Default
                        MsgBox("Successfully added.", MsgBoxStyle.Information, "")
                        btnviewalldoc.PerformClick()
                    End If
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox(cmbdocname.SelectedItem & " is already added.", MsgBoxStyle.Exclamation, "")
                    cmbdocname.Focus()
                    Exit Sub
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select Document name.", MsgBoxStyle.Exclamation, "")
                cmbdocname.Focus()
                Exit Sub
            End If

            vmcnf = False
            btncanceldoc.PerformClick()
            btnviewalldoc.PerformClick()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnvdeac_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnvdeac.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdplate.SelectedCells.Count = 1 Or grdplate.SelectedRows.Count = 1 Then
                If btnvdeac.Text = "Deactivate" Then
                    vmcnf = False
                    Dim a As String = MsgBox("Are you sure you want to deactivate vehicle?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                    If a = vbYes Then
                        grdplate.Enabled = False
                        'lalabas yung pag lalagyan ng reason why
                        reason.ShowDialog()
                        If dreason <> "" Then
                            vmcnf = False
                            confirmsave.GroupBox1.Text = login.neym
                            confirmsave.ShowDialog()
                            If vmcnf = True Then
                                sql = "Update tblgeneral set modifiedby='" & login.cashier & "',datemodified=GetDate(), status='0', dreason='" & dreason & "' where genid='" & grdplate.Rows(grdplate.CurrentRow.Index).Cells(0).Value & "'"
                                connect()
                                cmd = New SqlCommand(sql, conn)
                                cmd.ExecuteNonQuery()
                                cmd.Dispose()
                                conn.Close()

                                Me.Cursor = Cursors.Default
                                MsgBox("Successfully deactivated.", MsgBoxStyle.Information, "")
                                btnrefresh.PerformClick()
                            Else
                                Me.Cursor = Cursors.Default
                                MsgBox("Deactivation Cancelled.", MsgBoxStyle.Information, "")
                            End If
                        Else
                            Me.Cursor = Cursors.Default
                            MsgBox("Deactivation Cancelled.", MsgBoxStyle.Information, "")
                        End If
                    End If
                    dreason = ""
                    vmcnf = False
                    grdplate.Enabled = True

                Else
                    'activate vehicle
                    vmcnf = False
                    Dim a As String = MsgBox("Are you sure you want to activate vehicle?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                    If a = vbYes Then
                        grdplate.Enabled = False
                        vmcnf = False
                        confirm.ShowDialog()
                        If vmcnf = True Then
                            sql = "Update tblgeneral set modifiedby='" & login.cashier & "',datemodified=GetDate(), status='1', dreason='' where genid='" & grdplate.Rows(grdplate.CurrentRow.Index).Cells(0).Value & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            Me.Cursor = Cursors.Default
                            MsgBox("Successfully activated.", MsgBoxStyle.Information, "")
                            btnrefresh.PerformClick()
                        Else
                            Me.Cursor = Cursors.Default
                            MsgBox("Deactivation Cancelled.", MsgBoxStyle.Information, "")
                        End If
                    End If
                    dreason = ""
                    vmcnf = False
                    grdplate.Enabled = True
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select only one.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbinterval_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbinterval.SelectedIndexChanged
        checkdateexp()
    End Sub

    Private Sub num_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles num.ValueChanged
        checkdateexp()
    End Sub

    Public Sub checkdateexp()
        If num.Value <> 0 Then
            Dim last As Date = CDate(Format(datelastrenew.Value, "yyyy/MM/dd"))
            If cmbinterval.SelectedIndex = 1 Then
                ' dateexpired.Value = datelastrenew.Value.AddYears(+num.Value)
                dateexpired.Value = last.AddYears(+num.Value)
            ElseIf cmbinterval.SelectedIndex = 2 Then
                dateexpired.Value = last.AddMonths(+num.Value)
            ElseIf cmbinterval.SelectedIndex = 3 Then
                dateexpired.Value = last.AddDays(+num.Value)
            End If
        Else
            If btnupdatedoc.Text = "Update" Then
                cmbinterval.SelectedIndex = 0
                dateexpired.Value = datelastrenew.Value
            End If
        End If
    End Sub

    Private Sub chkuse_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkuse.CheckedChanged
        If chkuse.Checked = True Then
            num.Enabled = True
            cmbinterval.Enabled = True
            dateexpired.Enabled = False
        Else
            num.Enabled = False
            cmbinterval.Enabled = False
            dateexpired.Enabled = True
            num.Value = 0
            cmbinterval.SelectedItem = ""
        End If
    End Sub

    Private Sub btnviewalldoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnviewalldoc.Click
        loaddoc()
        viewalldoc()
    End Sub

    Public Sub viewalldoc()
        Try
            Me.Cursor = Cursors.WaitCursor
            grddoc.Rows.Clear()
            Dim statexp As String = ""

            sql = "Select * from tbldocexp where status='1' and genid='" & lblid.Text & "' order by docname"
            connect()
            Dim cmd2 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr2 As SqlDataReader = cmd2.ExecuteReader
            While dr2.Read
                grddoc.Rows.Add(dr2("docid"), dr2("docname"), Format(dr2("datelast"), "yyyy/MM/dd"), dr2("num") & " " & dr2("interval"), Format(dr2("dateexpired"), "yyyy/MM/dd"), dr2("statusexp"))
            End While
            dr2.Dispose()
            cmd2.Dispose()
            conn.Close()

            If grddoc.Rows.Count = 0 Then
                btnupdatedoc.Enabled = False
                btnremovedoc.Enabled = False
            Else
                btnupdatedoc.Enabled = True
                btnremovedoc.Enabled = True
                If btnupdatedoc.Text = "Save" Then
                    btnremovedoc.Enabled = False
                End If
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnupdatedoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdatedoc.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grddoc.Rows.Count <> 0 Then
                If grddoc.SelectedCells.Count = 1 Or grddoc.SelectedRows.Count = 1 Then
                    grddoc.Enabled = False
                    GroupBox9.Enabled = False
                    btnvadd.Enabled = False
                    btnvdeac.Enabled = False
                    grdplate.Enabled = False

                    enabletab2only()

                    If btnupdatedoc.Text = "Update" Then
                        chkuse.Checked = False
                        Dim nm As String = grddoc.Rows(grddoc.CurrentRow.Index).Cells(3).Value.ToString

                        Dim TestString As String = nm
                        Dim TestArray() As String = nm.ToString.Split(" ")
                        Dim LastNonEmpty As Integer = -1
                        For i As Integer = 0 To TestArray.Length - 1
                            If TestArray(i) <> " " Then
                                LastNonEmpty += 1
                                TestArray(LastNonEmpty) = TestArray(i)
                            End If
                        Next
                        ReDim Preserve TestArray(LastNonEmpty)
                        ' TestArray now holds {"apple", "pear", "banana"}
                        ' MsgBox(TestArray(0))
                        num.Value = TestArray(0)
                        If LastNonEmpty = 1 And TestArray(1) <> "" Then
                            cmbinterval.SelectedItem = TestArray(1)
                        End If


                        lbldocid.Text = grddoc.Rows(grddoc.CurrentRow.Index).Cells(0).Value
                        cmbdocname.SelectedItem = grddoc.Rows(grddoc.CurrentRow.Index).Cells(1).Value
                        datelastrenew.Value = grddoc.Rows(grddoc.CurrentRow.Index).Cells(2).Value
                        dateexpired.Value = grddoc.Rows(grddoc.CurrentRow.Index).Cells(4).Value


                        If cmbinterval.SelectedItem <> "" Then
                            chkuse.Checked = True
                        End If

                        btnupdatedoc.Enabled = True
                        btnadddoc.Enabled = False
                        btnremovedoc.Enabled = False
                        btnviewalldoc.Enabled = False
                        btncanceldoc.Enabled = True
                        btnupdatedoc.Text = "Save"
                    Else
                        'check if complete then confirm
                        If cmbdocname.SelectedItem <> "" Then
                            'check if already exist ehere docid <> lbldocid.text
                            Me.Cursor = Cursors.Default
                            For Each row As DataGridViewRow In grddoc.Rows
                                If grddoc.Rows(row.Index).Cells(1).Value = cmbdocname.SelectedItem And grddoc.Rows(row.Index).Cells(0).Value <> lbldocid.Text Then
                                    MsgBox(cmbdocname.SelectedItem & " is already exist.", MsgBoxStyle.Exclamation, "")
                                    cmbdocname.SelectedItem = grddoc.Rows(grddoc.CurrentRow.Index).Cells(1).Value
                                    Me.Cursor = Cursors.Default
                                    Exit Sub
                                End If
                            Next

                            If chkuse.Checked = True Then
                                If cmbinterval.SelectedItem = "" Then
                                    Me.Cursor = Cursors.Default
                                    MsgBox("Select tracking interval.", MsgBoxStyle.Exclamation, "")
                                    Exit Sub
                                End If
                            End If

                            vmcnf = False
                            confirm.ShowDialog()
                            If vmcnf = True Then
                                'save
                                statusofexp()

                                sql = "Update tbldocexp set docname='" & cmbdocname.SelectedItem & "', datelast='" & Format(datelastrenew.Value, "yyyy/MM/dd") & "', num='" & num.Value & "', interval='" & cmbinterval.SelectedItem & "', dateexpired='" & Format(dateexpired.Value, "yyyy/MM/dd") & "', datemodified=GetDate(), modifiedby='" & login.cashier & "', statusexp='" & lblexp.Text & "' where docid='" & lbldocid.Text & "'"
                                connect()
                                cmd = New SqlCommand(sql, conn)
                                cmd.ExecuteNonQuery()
                                cmd.Dispose()
                                conn.Close()

                                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                                vmcnf = False
                                btncanceldoc.PerformClick()
                                btnviewalldoc.PerformClick()
                                'btnrefresh.PerformClick()
                            End If
                        Else
                            MsgBox("Select document name.", MsgBoxStyle.Exclamation, "")
                        End If
                    End If
                Else
                    MsgBox("Select only one.", MsgBoxStyle.Exclamation, "")
                End If
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncanceldoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncanceldoc.Click
        grddoc.Enabled = True
        lbldocid.Text = ""
        cmbdocname.SelectedItem = ""
        datelastrenew.Value = datelastrenew.MaxDate
        dateexpired.Value = dateexpired.MinDate
        num.Value = 0
        cmbinterval.SelectedItem = ""

        chkuse.Checked = True
        btnupdatedoc.Text = "Update"
        btnupdatedoc.Enabled = True
        btnadddoc.Enabled = True
        btnremovedoc.Enabled = True
        btnviewalldoc.Enabled = True
        btncanceldoc.Enabled = False
        btnviewalldoc.PerformClick()

        GroupBox9.Enabled = True
        btnvadd.Enabled = True
        btnvdeac.Enabled = True
        grdplate.Enabled = True
        enableall()
    End Sub

    Public Sub enabletab1only()
        TabControl1.TabPages(1).Enabled = False 'tab2
        TabControl1.TabPages(2).Enabled = False 'tab3
        TabControl1.TabPages(3).Enabled = False 'tab4
        TabControl1.TabPages(4).Enabled = False 'tab5
    End Sub

    Public Sub enabletab2only()
        TabControl1.TabPages(0).Enabled = False 'tab1
        TabControl1.TabPages(2).Enabled = False 'tab3
        TabControl1.TabPages(3).Enabled = False 'tab4
        TabControl1.TabPages(4).Enabled = False 'tab5
    End Sub

    Public Sub enabletab3only()
        TabControl1.TabPages(0).Enabled = False 'tab1
        TabControl1.TabPages(1).Enabled = False 'tab2
        TabControl1.TabPages(3).Enabled = False 'tab4
        TabControl1.TabPages(4).Enabled = False 'tab5
    End Sub

    Public Sub enabletab4only()
        TabControl1.TabPages(0).Enabled = False 'tab1
        TabControl1.TabPages(1).Enabled = False 'tab2
        TabControl1.TabPages(2).Enabled = False 'tab3
        TabControl1.TabPages(4).Enabled = False 'tab5
    End Sub

    Public Sub enabletab5only()
        TabControl1.TabPages(0).Enabled = False 'tab1
        TabControl1.TabPages(1).Enabled = False 'tab2
        TabControl1.TabPages(2).Enabled = False 'tab3
        TabControl1.TabPages(3).Enabled = False 'tab4
    End Sub

    Public Sub enabletab6only()
        TabControl1.TabPages(0).Enabled = False 'tab1
        TabControl1.TabPages(1).Enabled = False 'tab2
        TabControl1.TabPages(2).Enabled = False 'tab3
        TabControl1.TabPages(3).Enabled = False 'tab4
        TabControl1.TabPages(4).Enabled = False 'tab5
    End Sub

    Public Sub enableall()
        TabControl1.TabPages(0).Enabled = True 'tab1
        TabControl1.TabPages(1).Enabled = True 'tab2
        TabControl1.TabPages(2).Enabled = True 'tab3
        TabControl1.TabPages(3).Enabled = True 'tab4
        TabControl1.TabPages(4).Enabled = True 'tab5
    End Sub

    Private Sub cmbdocname_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbdocname.SelectedIndexChanged
        If cmbdocname.SelectedItem <> "" Then
            btncanceldoc.Enabled = True
            If btnupdatedoc.Text = "Update" Then
                btnupdatedoc.Enabled = False
                btnremovedoc.Enabled = False
                btnviewalldoc.Enabled = False
            End If
        End If
    End Sub

    Private Sub btnremovedoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnremovedoc.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grddoc.SelectedCells.Count = 1 Or grddoc.SelectedRows.Count = 1 Then
                Dim a As String = MsgBox("Are you sure you want to remove?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                If a = vbYes Then
                    vmcnf = False
                    confirm.ShowDialog()
                    If vmcnf = True Then
                        ' sql = "Update tbldocexp set status='0' where docid='" & grddoc.Rows(grddoc.CurrentRow.Index).Cells(0).Value & "'"
                        sql = "Delete from tbldocexp where docid='" & grddoc.Rows(grddoc.CurrentRow.Index).Cells(0).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully remove.", MsgBoxStyle.Information, "")
                    End If
                    vmcnf = False
                    btnviewalldoc.PerformClick()
                End If
            Else
                MsgBox("Select only one.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub statusofexp()
        Try
            Dim dnow As Date = CDate(Format(Date.Now, "yyyy/MM/dd"))
            Dim dexp As Date = CDate(Format(dateexpired.Value, "yyyy/MM/dd"))
            Dim db4 As Date = CDate(Format(dateexpired.Value.AddDays(-14), "yyyy/MM/dd"))

            If dnow >= dexp Then
                ' MsgBox("Expired")
                lblexp.Text = "Expired"
            ElseIf dnow = dexp Then
                ' MsgBox("Expired")
                lblexp.Text = "Expired"
            ElseIf dnow >= db4 And dnow < dexp Then
                ' MsgBox("Soon to expire")
                lblexp.Text = "Soon to expire"
            Else
                ' MsgBox("Updated")
                lblexp.Text = "Updated"
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtplatenum_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtplatenum.Leave
        Try
            If Trim(txtplatenum.Text) <> "" And txtplatenum.ReadOnly = False Then
                If btnvadd.Text = "Add" Then
                    sql = "Select platenum from tblgeneral where platenum='" & Trim(txtplatenum.Text) & "'"
                ElseIf btnupdategen.Text = "Save" Then
                    sql = "Select platenum from tblgeneral where platenum='" & Trim(txtplatenum.Text) & "' and genid<>'" & lblid.Text & "'"
                End If

                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    Me.Cursor = Cursors.Default
                    MsgBox(Trim(txtplatenum.Text) & " is already exist.", MsgBoxStyle.Exclamation, "")
                    txtplatenum.Text = ""
                    txtplatenum.Focus()
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtvplate_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtvplate.Leave
        Try
            If Trim(txtvplate.Text) <> "" And txtvplate.ReadOnly = False Then
                If btnvadd.Text = "Add" Then
                    sql = "Select vplate from tblgeneral where vplate='" & Trim(txtvplate.Text) & "'"
                ElseIf btnupdategen.Text = "Save" Then
                    sql = "Select vplate from tblgeneral where vplate='" & Trim(txtvplate.Text) & "' and genid<>'" & lblid.Text & "'"
                End If

                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    Me.Cursor = Cursors.Default
                    MsgBox(Trim(txtvplate.Text) & " is already exist.", MsgBoxStyle.Exclamation, "")
                    txtvplate.Text = ""
                    txtvplate.Focus()
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtsticker_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtsticker.Leave
        Try
            If Trim(txtsticker.Text) <> "" And txtsticker.ReadOnly = False Then
                If btnvadd.Text = "Add" Then
                    sql = "Select csticker from tblgeneral where csticker='" & Trim(txtsticker.Text) & "'"
                ElseIf btnupdategen.Text = "Save" Then
                    sql = "Select csticker from tblgeneral where csticker='" & Trim(txtsticker.Text) & "' and genid<>'" & lblid.Text & "'"
                End If

                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    Me.Cursor = Cursors.Default
                    MsgBox(Trim(txtsticker.Text) & " is already exist.", MsgBoxStyle.Exclamation, "")
                    txtsticker.Text = ""
                    txtsticker.Focus()
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbtype_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbtype.Click
        loadtypesch()
    End Sub

    Private Sub cmbmake_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbmake.Click
        loadmake()
    End Sub

    Private Sub cmbsupplier_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbsupplier.Click
        loadsupplier()
    End Sub

    Private Sub cmbcompany_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbcompany.Click
        loadcompsch()
    End Sub

    Private Sub cmbwhse_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbwhse.Click
        loadwhse()
    End Sub

    Private Sub cmbbody_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbbody.Click
        loadbody()
    End Sub

    Private Sub txtdriver_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtdriver.Leave
        txtdriver.Text = StrConv(txtdriver.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub datelastrenew_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datelastrenew.ValueChanged
        dateexpired.MinDate = datelastrenew.Value
        If chkuse.Checked = True Then
            checkdateexp()
        End If
    End Sub

    Public Sub notifs()
        Try


        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtcolor_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcolor.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtcolor.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtcolor.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtcolor.Text.Length - 1
            Letter = txtcolor.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtcolor.Text = theText
        txtcolor.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtnote_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtnote.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtnote.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtnote.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtnote.Text.Length - 1
            Letter = txtnote.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtnote.Text = theText
        txtnote.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtmotor_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtmotor.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtmotor.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtmotor.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtmotor.Text.Length - 1
            Letter = txtmotor.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtmotor.Text = theText
        txtmotor.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtsearch_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtsearch.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btnok.PerformClick()
        End If
    End Sub

    Private Sub txtsearch_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtsearch.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtsearch.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtsearch.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtsearch.Text.Length - 1
            Letter = txtsearch.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtsearch.Text = theText
        txtsearch.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtrems_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtchasis_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtchasis.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtchasis.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtchasis.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtchasis.Text.Length - 1
            Letter = txtchasis.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtchasis.Text = theText
        txtchasis.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtsticker_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtsticker.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789-/"
        Dim theText As String = txtsticker.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtsticker.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtsticker.Text.Length - 1
            Letter = txtsticker.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtsticker.Text = theText
        txtsticker.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtvplate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtvplate.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789-/"
        Dim theText As String = txtvplate.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtvplate.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtvplate.Text.Length - 1
            Letter = txtvplate.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtvplate.Text = theText
        txtvplate.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtplatenum_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtplatenum.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789"
        Dim theText As String = txtplatenum.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtplatenum.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtplatenum.Text.Length - 1
            Letter = txtplatenum.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtplatenum.Text = theText
        txtplatenum.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtdriver_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdriver.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtdriver.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtdriver.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtdriver.Text.Length - 1
            Letter = txtdriver.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtdriver.Text = theText
        txtdriver.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub cmbcompsch_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcompsch.SelectedIndexChanged
        loadwhsesch()
    End Sub

    Private Sub cmbcompany_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcompany.SelectedIndexChanged
        loadwhse()
    End Sub

    Public Sub loadpms()
        Try
            cmbpms.Items.Clear()
            cmbpms.Items.Add("")

            sql = "Select * from tblpms where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbpms.Items.Add(dr("servicename"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnpmsview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpmsview.Click
        loadpms()
        updatepmsstatexp()
        viewallpms()
        'btnrefresh.PerformClick()
    End Sub

    Public Sub updatepmsstatexp()
        Try
            Dim endingodo As Double = 0
            sql = "Select TOP 1 * from tbltripsum where platenum='" & lblplatebig.Text & "' and odoend<>'0' order by tripsumid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                endingodo = dr("odoend")
            End If
            dr.Read()
            cmd.Dispose()
            conn.Close()

            Dim lastodo As Double = 0, mileage As Double = 0, nextodo As Double = 0
            sql = "Select * from tblpmssched where genid='" & lblid.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                lastodo = dr("lastodo")
                mileage = dr("miles")
                nextodo = dr("nextodo")
            End If
            dr.Read()
            cmd.Dispose()
            conn.Close()

            If endingodo = nextodo Then
                lblpmsexp.Text = "Due Today"
            ElseIf endingodo >= nextodo - 500 And endingodo <= nextodo - 1 Then
                lblpmsexp.Text = "Due Soon"
            ElseIf endingodo > nextodo Then
                lblpmsexp.Text = "Over Due"
            Else
                lblpmsexp.Text = "Updated"
            End If

            sql = "Update tblpmssched set endodo='" & endingodo & "',statusexp='" & lblpmsexp.Text & "' where genid='" & lblid.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub viewallpms()
        Try
            Me.Cursor = Cursors.WaitCursor
            grdpms.Rows.Clear()
            Dim statexp As String = ""
            Dim idchoil As Integer = 0

            sql = "Select * from tblpmssched where status='1' and genid='" & lblid.Text & "' order by servicename"
            connect()
            Dim cmd3 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr3 As SqlDataReader = cmd3.ExecuteReader
            While dr3.Read
                grdpms.Rows.Add(dr3("pmschid"), dr3("servicename"), dr3("miles").ToString, dr3("whsename").ToString, Format(dr3("datelast"), "yyyy/MM/dd"), Val(dr3("lastodo").ToString), Val(dr3("nextodo").ToString), Val(dr3("endodo").ToString), dr3("remarks").ToString, dr3("statusexp"))

                If dr3("servicename").ToString.Contains("Change Oil") Then
                    idchoil = dr3("pmschid")
                End If
            End While
            dr3.Dispose()
            cmd3.Dispose()
            conn.Close()

            If grdpms.Rows.Count = 0 Then
                btnpmsupdate.Enabled = False
                btnpmsremove.Enabled = False
            Else
                btnpmsupdate.Enabled = True
                btnpmsremove.Enabled = True
                If btnpmsupdate.Text = "Save" Then
                    btnpmsremove.Enabled = False
                End If
            End If
            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbpms_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbpms.SelectedIndexChanged
        If cmbpms.SelectedItem <> "" Then
            btnpmscancel.Enabled = True
            If btnpmsupdate.Text = "Update" Then
                btnpmsupdate.Enabled = False
                btnpmsremove.Enabled = False
                btnpmsview.Enabled = False
                btnpmsodo.Enabled = False
            Else
                btnpmsupdate.Enabled = True
                btnpmsremove.Enabled = True
                btnpmsview.Enabled = True
                btnpmsodo.Enabled = True
            End If
        End If
    End Sub

    Private Sub datelastpms_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datelastpms.ValueChanged
        
    End Sub

    Private Sub btnpmsadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpmsadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            'check first if complete
            If cmbpms.SelectedItem <> "" Then

                'check muna if nsa list na.. if wla pde i add.. 
                Dim chkmeronna As Boolean = False
                For Each row As DataGridViewRow In grdpms.Rows
                    If grdpms.Rows(row.Index).Cells(1).Value.ToString.Contains(cmbpms.SelectedItem) Then
                        chkmeronna = True
                    End If
                Next

                'check if may odo
                If Trim(txtlastodo.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input odometer reading.", MsgBoxStyle.Exclamation, "")
                    txtlastodo.Focus()
                    Exit Sub
                End If

                'check interval
                If Trim(txtmiles.Text) = "" Or Val(txtmiles.Text) = 0 Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input interval mileage.", MsgBoxStyle.Exclamation, "")
                    txtmiles.Focus()
                    Exit Sub
                End If

                'check whse
                If cmbpmswhse.SelectedItem = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Select warehouse.", MsgBoxStyle.Exclamation, "")
                    cmbpmswhse.Focus()
                    Exit Sub
                End If

                If chkmeronna = False Then
                    'add
                    vmcnf = False
                    confirm.ShowDialog()
                    If vmcnf = True Then
                        statusofexppms()

                        sql = "Insert into tblpmssched (genid, servicename, datelast, whsename, miles, lastodo, nextodo, datecreated, createdby, datemodified, modifiedby, remarks, statusexp, status) values ('" & lblid.Text & "','" & cmbpms.SelectedItem & "', '" & Format(datelastpms.Value, "yyyy/MM/dd") & "','" & cmbpmswhse.SelectedItem & "','" & Val(txtmiles.Text) & "','" & Val(txtlastodo.Text) & "','" & Val(txtnextodo.Text) & "',GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '" & Trim(txtpmsrems.Text) & "', '" & lblpmsexp.Text & "', '1')"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully added.", MsgBoxStyle.Information, "")
                    End If
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox(cmbpms.SelectedItem & " is already added.", MsgBoxStyle.Exclamation, "")
                    cmbpms.Focus()
                    Exit Sub
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select service name.", MsgBoxStyle.Exclamation, "")
                cmbpms.Focus()
                Exit Sub
            End If

            vmcnf = False
            btnpmscancel.PerformClick()
            btnpmsview.PerformClick()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnpmscancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpmscancel.Click
        grdpms.Enabled = True
        lblpmsid.Text = ""
        cmbpms.SelectedItem = ""
        cmbpmswhse.SelectedItem = ""
        datelastpms.Value = datelastpms.MaxDate
        txtlastodo.Text = ""
        txtmiles.Text = ""
        txtnextodo.Text = ""
        txtpmsrems.Text = ""

        btnpmsupdate.Text = "Update"
        btnpmsupdate.Enabled = True
        btnpmsadd.Enabled = True
        btnpmsremove.Enabled = True
        btnpmsview.Enabled = True
        btnpmscancel.Enabled = False
        btnpmsodo.Enabled = True
        btnpmsview.PerformClick()

        GroupBox9.Enabled = True
        btnvadd.Enabled = True
        btnvdeac.Enabled = True
        grdplate.Enabled = True
        enableall()
    End Sub

    Private Sub btnpmsremove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpmsremove.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdpms.SelectedCells.Count = 1 Or grdpms.SelectedRows.Count = 1 Then
                Dim a As String = MsgBox("Are you sure you want to remove?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                If a = vbYes Then
                    vmcnf = False
                    confirm.ShowDialog()
                    If vmcnf = True Then
                        ' sql = "Update tbldocexp set status='0' where docid='" & grddoc.Rows(grddoc.CurrentRow.Index).Cells(0).Value & "'"
                        sql = "Delete from tblpmssched where pmschid='" & grdpms.Rows(grdpms.CurrentRow.Index).Cells(0).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully remove.", MsgBoxStyle.Information, "")
                    End If
                    vmcnf = False
                    btnpmsview.PerformClick()
                End If
            Else
                MsgBox("Select only one.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnpmsupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpmsupdate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdpms.Rows.Count <> 0 Then
                If grdpms.SelectedCells.Count = 1 Or grdpms.SelectedRows.Count = 1 Then
                    grdpms.Enabled = False
                    GroupBox9.Enabled = False
                    btnvadd.Enabled = False
                    btnvdeac.Enabled = False
                    grdplate.Enabled = False

                    enabletab3only()

                    If btnpmsupdate.Text = "Update" Then
                        
                        lblpmsid.Text = grdpms.Rows(grdpms.CurrentRow.Index).Cells(0).Value
                        cmbpms.SelectedItem = grdpms.Rows(grdpms.CurrentRow.Index).Cells(1).Value
                        txtmiles.Text = grdpms.Rows(grdpms.CurrentRow.Index).Cells(2).Value
                        cmbpmswhse.SelectedItem = grdpms.Rows(grdpms.CurrentRow.Index).Cells(3).Value
                        datelastpms.Value = grdpms.Rows(grdpms.CurrentRow.Index).Cells(4).Value
                        txtlastodo.Text = grdpms.Rows(grdpms.CurrentRow.Index).Cells(5).Value
                        txtnextodo.Text = grdpms.Rows(grdpms.CurrentRow.Index).Cells(6).Value
                        txtpmsrems.Text = grdpms.Rows(grdpms.CurrentRow.Index).Cells(8).Value

                        btnpmsupdate.Enabled = True
                        btnpmsadd.Enabled = False
                        btnpmsremove.Enabled = False
                        btnpmsview.Enabled = False
                        btnpmsodo.Enabled = False
                        btnpmscancel.Enabled = True
                        btnpmsupdate.Text = "Save"
                    Else
                        'check if complete then confirm
                        If cmbpms.SelectedItem <> "" Then
                            'check if already exist ehere docid <> lblpmsid.text

                            For Each row As DataGridViewRow In grdpms.Rows
                                If grdpms.Rows(row.Index).Cells(1).Value = cmbpms.SelectedItem And grdpms.Rows(row.Index).Cells(0).Value <> lblpmsid.Text Then
                                    Me.Cursor = Cursors.Default
                                    MsgBox(cmbpms.SelectedItem & " is already exist.", MsgBoxStyle.Exclamation, "")
                                    cmbpms.SelectedItem = grdpms.Rows(grdpms.CurrentRow.Index).Cells(1).Value
                                    Exit Sub
                                End If
                            Next

                            vmcnf = False
                            confirm.ShowDialog()
                            If vmcnf = True Then
                                'save
                                statusofexppms()

                                sql = "Update tblpmssched set servicename='" & cmbpms.SelectedItem & "', whsename='" & cmbpmswhse.SelectedItem & "', datelast='" & Format(datelastpms.Value, "yyyy/MM/dd") & "',miles='" & Trim(txtmiles.Text) & "',lastodo='" & Trim(txtlastodo.Text) & "',nextodo='" & Trim(txtnextodo.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "', statusexp='" & lblpmsexp.Text & "', remarks='" & Trim(txtpmsrems.Text) & "' where pmschid='" & lblpmsid.Text & "'"
                                connect()
                                cmd = New SqlCommand(sql, conn)
                                cmd.ExecuteNonQuery()
                                cmd.Dispose()
                                conn.Close()

                                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                                vmcnf = False
                                btnpmscancel.PerformClick()
                                btnpmsview.PerformClick()
                                'btnrefresh.PerformClick()
                            End If
                        Else
                            MsgBox("Select service name.", MsgBoxStyle.Exclamation, "")
                        End If
                    End If
                Else
                    MsgBox("Select only one.", MsgBoxStyle.Exclamation, "")
                End If
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub statusofexppms()
        Try
            'if based sa odometer

            sql = "Select TOP 1 * from tbltripsum where platenum='" & lblplatebig.Text & "' and odoend<>'0' order by tripsumid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                'last trip na ang odo is not zero
                '/MsgBox(dr("tripnum").ToString)
            End If
            dr.Read()
            cmd.Dispose()
            conn.Close()

            Dim endingodo As Double = 0
            sql = "Select TOP 1 * from tbltripsum where platenum='" & lblplatebig.Text & "' and odoend<>'0' order by tripsumid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                endingodo = dr("odoend").ToString
            End If
            dr.Read()
            cmd.Dispose()
            conn.Close()

            Dim lastodo As Double = 0, mileage As Double = 0, nextodo As Double = 0
            sql = "Select * from tblpmssched where genid='" & lblid.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                lastodo = dr("lastodo").ToString
                mileage = dr("miles").ToString
                nextodo = dr("nextodo").ToString
            End If
            dr.Read()
            cmd.Dispose()
            conn.Close()

            sql = "Update tblpmssched set endodo='" & endingodo & "' where genid='" & lblid.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            conn.Close()

            If endingodo = nextodo Then
                lblpmsexp.Text = "Due Today"
            ElseIf endingodo >= nextodo - 500 And endingodo <= nextodo - 1 Then
                lblpmsexp.Text = "Due Soon"
            ElseIf endingodo > nextodo Then
                lblpmsexp.Text = "Over Due"
            Else
                lblpmsexp.Text = "Updated"
            End If


            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgadd.Click
        Try
            If btnimgadd.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox.Image = Image.FromFile(ofd.FileName.ToUpper)
                    txtimg.Text = ofd.SafeFileName
                    txtimg.ReadOnly = False
                    txtimg.Focus()

                    imgpanel.Enabled = False
                    GroupBox9.Enabled = False
                    btnvadd.Enabled = False
                    btnvdeac.Enabled = False
                    grdplate.Enabled = False
                    enabletab4only()
                    imgcanceltrue()
                    btnimgadd.Enabled = True
                    btnimgadd.Text = "Add"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(txtimg.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    txtimg.Focus()
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to add photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
                If a = vbYes Then
                    Me.Cursor = Cursors.WaitCursor
                    'insert photo in tblimg
                    Dim ms As New MemoryStream()
                    'search image name if existing
                    connect()
                    cmd = New SqlCommand("Select * from tblimage where genid='" & lblid.Text & "' and name='" & Trim(txtimg.Text) & "'", conn)
                    dr = cmd.ExecuteReader()
                    If dr.Read = True Then
                        Me.Cursor = Cursors.Default
                        MessageBox.Show("Image " & Trim(txtimg.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        'save record in database
                        connect()
                        cmd = New SqlCommand("Insert into tblimage values(@genid,@driverid,@name,@img)", conn)
                        cmd.Parameters.Add(New SqlClient.SqlParameter("genid", lblid.Text))
                        cmd.Parameters.Add(New SqlClient.SqlParameter("driverid", ""))
                        cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(txtimg.Text)))
                        imgbox.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                        Dim data As Byte() = ms.GetBuffer()
                        Dim img As New SqlParameter("@img", SqlDbType.Image)
                        img.Value = data
                        cmd.Parameters.Add(img)
                        cmd.ExecuteNonQuery()
                        MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        imgbox.Image = Nothing
                        imgbox.BackColor = Color.Empty
                        imgbox.Invalidate()
                        Me.Cursor = Cursors.Default
                    End If
                    conn.Close()
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If

                btnimgadd.Text = "Add Photo"
                imgcancelfalse()
                imgpanel.Enabled = True
                GroupBox9.Enabled = True
                btnvadd.Enabled = True
                btnvdeac.Enabled = True
                grdplate.Enabled = True
                enableall()
                btnimgrefresh.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Sub convertPic(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            pic = CType(sender, PictureBox)
            imgbox.Image = pic.Image
            lblimgid.Text = pic.Tag

            sql = "Select * from tblimage where imgid='" & lblimgid.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                txtimg.Text = dr("name")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub imgcanceltrue()
        btnimgadd.Enabled = False
        btnimgrename.Enabled = False
        btnimgremove.Enabled = False
        btnimgcancel.Enabled = True
        btnimgset.Enabled = False
        btnimgupdate.Enabled = False
        btnimgdl.Enabled = False
        btnimgfull.Enabled = False
        btnimgrefresh.Enabled = False
    End Sub

    Public Sub imgcancelfalse()
        txtimg.ReadOnly = True
        txtimg.Text = ""
        btnimgadd.Text = "Add Photo"
        btnimgrename.Text = "Rename"
        btnimgupdate.Text = "Update Photo"
        btnimgadd.Enabled = True
        btnimgrename.Enabled = True
        btnimgremove.Enabled = True
        btnimgcancel.Enabled = False
        btnimgset.Enabled = True
        btnimgupdate.Enabled = True
        btnimgdl.Enabled = True
        btnimgfull.Enabled = True
        btnimgrefresh.Enabled = True
    End Sub

    Private Sub txtimg_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtimg.Leave
        'tignan kung valid ung filename ng picture
        If txtimg.Text.ToString.Contains("'") Then
            txtimg.Text = Trim(txtimg.Text.ToString.Replace("'", ""))
        End If
    End Sub

    Private Sub btnimgcancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel.Click
        imgpanel.Enabled = True
        GroupBox9.Enabled = True
        btnvadd.Enabled = True
        btnvdeac.Enabled = True
        grdplate.Enabled = True
        enableall()
        imgbox.Image = Nothing
        txtimg.Text = ""
        lblimgid.Text = ""
        imgcancelfalse()

        If meron = False Then
            btnimgrename.Enabled = False
            btnimgremove.Enabled = False
            btnimgcancel.Enabled = False
            btnimgset.Enabled = False
            btnimgupdate.Enabled = False
            btnimgdl.Enabled = False
            btnimgfull.Enabled = False
        Else
            imgcancelfalse()
        End If
    End Sub

    Private Sub btnimgrefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrefresh.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meron = False
            imgpanel.Visible = False
            imgpanel.Controls.Clear()
            imgpanel.Visible = True

            Dim ctr As Integer = 0
            sql = "Select * from tblimage where genid='" & lblid.Text & "'"
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                meron = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr1("img"), Byte())
                Dim ms As New MemoryStream(data)

                pic = New PictureBox
                pic.Image = Image.FromStream(ms)
                pic.SizeMode = PictureBoxSizeMode.Zoom
                pic.SetBounds(wid, y, 104, 100)
                'pic.BackColor = Color.AliceBlue
                pic.Tag = dr1("imgid")
                pic.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr1("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler pic.Click, AddressOf convertPic
                imgpanel.Controls.Add(pic)
                imgpanel.Controls.Add(lbl)
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            imgbox.Image = Nothing
            txtimg.Text = ""
            lblimgid.Text = ""

            Me.Cursor = Cursors.Default

            If meron = False Then
                btnimgrename.Enabled = False
                btnimgremove.Enabled = False
                btnimgcancel.Enabled = False
                btnimgset.Enabled = False
                btnimgupdate.Enabled = False
                btnimgdl.Enabled = False
                btnimgfull.Enabled = False
            Else
                imgcancelfalse()
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgrename_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrename.Click
        Try
            If btnimgrename.Text = "Rename" Then
                If Trim(txtimg.Text) <> "" And imgbox.Image IsNot Nothing Then
                    txtimg.ReadOnly = False
                    txtimg.Focus()
                ElseIf Trim(txtimg.Text) = "" And imgbox.Image IsNot Nothing Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    txtimg.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    txtimg.Focus()
                    Exit Sub
                End If

                imgpanel.Enabled = False
                GroupBox9.Enabled = False
                btnvadd.Enabled = False
                btnvdeac.Enabled = False
                grdplate.Enabled = False
                enabletab4only()
                imgcanceltrue()
                btnimgrename.Enabled = True
                btnimgrename.Text = "Save"
            Else
                vmcnf = False
                confirm.ShowDialog()
                If vmcnf = True Then
                    'irename.. update yung name lng where imgid = lblimgid.text
                    sql = "Update tblimage set name='" & Trim(txtimg.Text) & "' where imgid='" & lblimgid.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                    btnimgrename.Text = "Rename"
                    imgcancelfalse()
                    imgpanel.Enabled = True
                    GroupBox9.Enabled = True
                    btnvadd.Enabled = True
                    btnvdeac.Enabled = True
                    grdplate.Enabled = True
                    enableall()
                    btnimgrefresh.PerformClick()
                    Me.Cursor = Cursors.Default
                End If
                vmcnf = False
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgremove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgremove.Click
        Try
            If Trim(txtimg.Text) <> "" And imgbox.Image IsNot Nothing Then
                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                If a = vbYes Then
                    vmcnf = False
                    confirm.ShowDialog()
                    If vmcnf = True Then
                        'delete image where imgid=lblimgid.text
                        sql = "Delete from tblimage where imgid='" & lblimgid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully remove.", MsgBoxStyle.Information, "")

                        vmcnf = False
                        imgcancelfalse()
                        imgpanel.Enabled = True
                        GroupBox9.Enabled = True
                        btnvadd.Enabled = True
                        btnvdeac.Enabled = True
                        grdplate.Enabled = True
                        enableall()
                        btnimgrefresh.PerformClick()
                    End If
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                txtimg.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgfull_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgfull.Click
        If lblimgid.Text <> "" Then
            viewimage.lblimgid.Text = lblimgid.Text
            viewimage.lblimgname.Text = txtimg.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub btnimgupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgupdate.Click
        Try
            'browse muna then saka update
            If btnimgupdate.Text = "Update Photo" Then
                If lblimgid.Text <> "" Then
                    If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
                        imgbox.Image = Image.FromFile(ofd.FileName.ToUpper)
                        ' txtimg.Text = ofd.SafeFileName
                        ' txtimg.ReadOnly = False
                        txtimg.Focus()

                        imgpanel.Enabled = False
                        GroupBox9.Enabled = False
                        btnvadd.Enabled = False
                        btnvdeac.Enabled = False
                        grdplate.Enabled = False
                        enabletab4only()
                        imgcanceltrue()
                        btnimgupdate.Enabled = True
                        btnimgupdate.Text = "Save Photo"
                    Else
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If

            Else
                If Trim(txtimg.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    txtimg.Focus()
                    Exit Sub
                End If

                vmcnf = False
                confirm.ShowDialog()
                If vmcnf = True Then
                    Me.Cursor = Cursors.WaitCursor

                    Dim ms As New MemoryStream()
                    connect()
                    cmd = New SqlCommand("Update tblimage set img=@img where imgid=@imgid", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("imgid", Trim(lblimgid.Text)))
                    imgbox.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    cmd.ExecuteNonQuery()
                    vmcnf = False
                    conn.Close()
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If

                btnimgupdate.Text = "Update Photo"
                imgcancelfalse()
                imgpanel.Enabled = True
                GroupBox9.Enabled = True
                btnvadd.Enabled = True
                btnvdeac.Enabled = True
                grdplate.Enabled = True
                enableall()
                btnimgrefresh.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgset.Click
        Try
            If lblimgid.Text <> "" Then
                Dim a As String = MsgBox("Are you sure you want to set the photo as primary photo?.", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
                If a = vbYes Then
                    vmcnf = False
                    confirm.ShowDialog()
                    If vmcnf = True Then
                        'update tblgeneral
                        sql = "Update tblgeneral set imgid='" & lblimgid.Text & "' where genid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")
                    End If
                End If
            Else
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub GetIPAddress()

        Dim strHostName As String

        Dim strIPAddress As String



        strHostName = System.Net.Dns.GetHostName()

        strIPAddress = System.Net.Dns.GetHostEntry(strHostName).AddressList(0).ToString()


        MessageBox.Show("Host Name: " & strHostName & "; IP Address: " & strIPAddress)

    End Sub

    Private Function GetIPv4Address() As String
        GetIPv4Address = String.Empty
        Dim strHostName As String = System.Net.Dns.GetHostName()
        Dim iphe As System.Net.IPHostEntry = System.Net.Dns.GetHostEntry(strHostName)

        For Each ipheal As System.Net.IPAddress In iphe.AddressList
            If ipheal.AddressFamily = System.Net.Sockets.AddressFamily.InterNetwork Then
                GetIPv4Address = ipheal.ToString()
            End If
        Next

        MsgBox(GetIPv4Address)
    End Function

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        GetIPv4Address()
        GetIPAddress()


        'to save picture
        'ilagay muna ung pic dun sa picture box then gamitin ung code below para magsave yey
        'imgbox.Image.Save("C:\Users\Dell1\Documents\BACKUPJECELJPOON\jecel\vehicle\piktyur.jpg", System.Drawing.Imaging.ImageFormat.Jpeg)
        MsgBox(getMacAddress().ToString)
    End Sub

    Function getMacAddress()
        Dim nics() As NetworkInterface = NetworkInterface.GetAllNetworkInterfaces
        Return nics(0).GetPhysicalAddress.ToString
    End Function

    Private Sub btnimgdl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgdl.Click
        Try
            If lblimgid.Text <> "" Then
                saveimage.ShowDialog()
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnreprefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreprefresh.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            grdrepair.Rows.Clear()

            sql = "Select * from tblrm where finish='0' and status='1' and genid='" & lblid.Text & "'"
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                Dim finish As Boolean = False
                If dr1("finish") = 1 Then
                    finish = True
                Else
                    finish = False
                End If

                If IsDBNull(dr1("datefinish")) = True Then
                    grdrepair.Rows.Add(dr1("rmid"), dr1("rmtype"), dr1("description"), dr1("reason"), Format(dr1("datestart"), "yyyy/MM/dd"), finish, dr1("datefinish").ToString, dr1("mechanic").ToString)
                Else
                    grdrepair.Rows.Add(dr1("rmid"), dr1("rmtype"), dr1("description"), dr1("reason"), Format(dr1("datestart"), "yyyy/MM/dd"), finish, Format(dr1("datefinish"), "yyyy/MM/dd"), dr1("mechanic").ToString)
                End If
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            If grdrepair.Rows.Count <> 0 Then
                btnrepparts.Enabled = True
                btnrepedit.Enabled = True
            Else
                btnrepparts.Enabled = False
                btnrepedit.Enabled = False
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnrepadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrepadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" And login.neym <> "Inspector" And login.neym <> "Whse Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If (rbcheck.Checked = True Or rbrepair.Checked = True Or rbothers.Checked = True) And Trim(txtdesc.Text) <> "" And Trim(txtreason.Text) <> "" Then
                'if repair ba laging may pyesang kelangan or nde nmn lahat kelanagn so pwedeng wlang entry sa parts needed
                If rbothers.Checked = True And Trim(txtothers.Text) = "" Then
                    MsgBox("Other type: Please specify.", MsgBoxStyle.Critical, "")
                    txtothers.Focus()
                    Exit Sub
                End If
                'insert into database

                vmcnf = False
                confirm.ShowDialog()
                If vmcnf = True Then
                    Dim type As String
                    If rbcheck.Checked = True Then
                        type = rbcheck.Text
                    ElseIf rbrepair.Checked = True Then
                        type = rbrepair.Text
                    Else
                        If Trim(txtothers.Text) = "" Then
                            Me.Cursor = Cursors.Default
                            MsgBox("Other type: Please specify.", MsgBoxStyle.Critical, "")
                            Exit Sub
                        Else
                            type = Trim(txtothers.Text)
                        End If
                    End If


                    ' If chkfinish.Checked = True Then
                    'sql = "Insert into tblrm (genid,rmtype,datestart,description,reason,finish,datefinish,mechanic,remarks,datecreated,createdby,datemodified,modifiedby,status) values ('" & lblid.Text & "','" & type & "','" & Format(datestart.Value, "yyyy/MM/dd") & "','" & trim(txtdesc.text) & "','" & Trim(txtreason.Text) & "','1','" & Format(datefinish.Value, "yyyy/MM/dd") & "','" & Trim(txtmechanic.Text) & "','',GetDate(),'" & login.cashier & "',GetDate(),'" & login.cashier & "','1')"
                    'Else
                    sql = "Insert into tblrm (genid,rmtype,datestart,description,reason,finish,mechanic,remarks,datecreated,createdby,datemodified,modifiedby,status) values ('" & lblid.Text & "','" & type & "','" & Format(datestart.Value, "yyyy/MM/dd") & "','" & Trim(txtdesc.Text) & "','" & Trim(txtreason.Text) & "','0','" & Trim(txtmechanic.Text) & "','',GetDate(),'" & login.cashier & "',GetDate(),'" & login.cashier & "','1')"
                    ' End If
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Added.", MsgBoxStyle.Information, "")
                    vmcnf = False
                    btnrepcancel.PerformClick()
                    btnreprefresh.PerformClick()
                End If
            Else
                MsgBox("Complete the fields.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub datestart_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datestart.ValueChanged
        'datefinish.MinDate = datestart.Value
    End Sub

    Private Sub btnrepcancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrepcancel.Click
        grdrepair.Enabled = True
        lblrmid.Text = ""
        txtdesc.Text = ""
        txtreason.Text = ""
        txtmechanic.Text = ""
        txtothers.Text = ""
        rbrepair.Checked = False
        rbcheck.Checked = False
        rbothers.Checked = False
        datestart.Value = datestart.MaxDate
        'datefinish.Value = Date.Now
        'chkfinish.Checked = False

        btnrepedit.Text = "Edit"
        btnrepedit.Enabled = True
        btnrepadd.Enabled = True
        btnreprefresh.Enabled = True
        btnrepcancel.Enabled = False
        btnreprefresh.PerformClick()

        GroupBox9.Enabled = True
        btnvadd.Enabled = True
        btnvdeac.Enabled = True
        grdplate.Enabled = True
        enableall()
        txtdesc.Focus()
    End Sub

    Private Sub btnrepedit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrepedit.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" And login.neym <> "Inspector" And login.neym <> "Whse Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdrepair.Rows.Count <> 0 Then
                If grdrepair.SelectedCells.Count = 1 Or grdrepair.SelectedRows.Count = 1 Then
                    grdrepair.Enabled = False
                    GroupBox9.Enabled = False
                    btnvadd.Enabled = False
                    btnvdeac.Enabled = False
                    grdplate.Enabled = False

                    enabletab5only()

                    If btnrepedit.Text = "Edit" Then
                        'get the values in datagridview to controls
                        lblrmid.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(0).Value
                        If rbcheck.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(1).Value Then
                            rbcheck.Checked = True
                        ElseIf rbrepair.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(1).Value Then
                            rbrepair.Checked = True
                        Else
                            rbothers.Checked = True
                            txtothers.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(1).Value
                        End If
                        txtdesc.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(2).Value
                        txtreason.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(3).Value
                        datestart.Value = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(4).Value
                        Dim checkCell As DataGridViewCheckBoxCell = CType(grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(5), DataGridViewCheckBoxCell)
                        'chkfinish.Checked = checkCell.Value
                        'If checkCell.Value = True Then
                        'End If
                        If grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(6).Value.ToString <> "" Then
                            '   datefinish.Value = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(6).Value
                        End If
                        txtmechanic.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(7).Value

                        btnrepedit.Enabled = True
                        btnrepparts.Enabled = False
                        btnrepadd.Enabled = False
                        btnreprefresh.Enabled = False
                        btnrepcancel.Enabled = True
                        btnrepedit.Text = "Save"
                    Else
                        'check if complete then confirm
                        If (rbcheck.Checked = True Or rbrepair.Checked = True Or rbothers.Checked = True) And Trim(txtdesc.Text) <> "" And Trim(txtreason.Text) <> "" Then
                            If rbothers.Checked = True And Trim(txtothers.Text) = "" Then
                                Me.Cursor = Cursors.Default
                                MsgBox("Other type: Please specify.", MsgBoxStyle.Critical, "")
                                txtothers.Focus()
                                Exit Sub
                            End If

                            'confirm
                            vmcnf = False
                            confirm.ShowDialog()
                            If vmcnf = True Then
                                'then save
                                Dim type As String
                                If rbcheck.Checked = True Then
                                    type = rbcheck.Text
                                ElseIf rbrepair.Checked = True Then
                                    type = rbrepair.Text
                                Else
                                    If Trim(txtothers.Text) = "" Then
                                        Me.Cursor = Cursors.Default
                                        MsgBox("Other type: Please specify.", MsgBoxStyle.Critical, "")
                                        Exit Sub
                                    Else
                                        type = Trim(txtothers.Text)
                                    End If
                                End If


                                ' If chkfinish.Checked = True Then
                                'sql = "Update tblrm set rmtype='" & type & "',datestart='" & Format(datestart.Value, "yyyy/MM/dd") & "',description='" & trim(txtdesc.text) & "',reason='" & Trim(txtreason.Text) & "',finish='1',datefinish='" & Format(datefinish.Value, "yyyy/MM/dd") & "',mechanic='" & Trim(txtmechanic.Text) & "',remarks='',datemodified=GetDate(),modifiedby='" & login.cashier & "' where rmid='" & lblrmid.Text & "'"
                                ' Else
                                sql = "Update tblrm set rmtype='" & type & "',datestart='" & Format(datestart.Value, "yyyy/MM/dd") & "',description='" & Trim(txtdesc.Text) & "',reason='" & Trim(txtreason.Text) & "',finish='0',datefinish=null " & ",mechanic='" & Trim(txtmechanic.Text) & "',remarks='',datemodified=GetDate(),modifiedby='" & login.cashier & "' where rmid='" & lblrmid.Text & "'"
                                ' End If
                                connect()
                                cmd = New SqlCommand(sql, conn)
                                cmd.ExecuteNonQuery()
                                cmd.Dispose()
                                conn.Close()


                                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                                vmcnf = False
                                btnrepcancel.PerformClick()
                                btnreprefresh.PerformClick()
                            End If
                        Else
                            MsgBox("Complete the fields.", MsgBoxStyle.Exclamation, "")
                        End If
                    End If
                Else
                    MsgBox("Select only one.", MsgBoxStyle.Exclamation, "")
                End If
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub rbothers_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbothers.CheckedChanged
        If rbothers.Checked = True Then
            txtothers.ReadOnly = False
            txtothers.Focus()
        Else
            txtothers.ReadOnly = True
        End If
    End Sub

    Private Sub txtreason_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtreason.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/()"
        Dim theText As String = txtreason.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtreason.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtreason.Text.Length - 1
            Letter = txtreason.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtreason.Text = theText
        txtreason.Select(SelectionIndex - Change, 0)

        If Trim(txtreason.Text) <> "" Then
            btnrepcancel.Enabled = True
            If btnrepedit.Text = "Edit" Then
                btnrepparts.Enabled = False
                btnrepedit.Enabled = False
                btnreprefresh.Enabled = False
            End If
        End If
    End Sub

    Private Sub txtmechanic_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtmechanic.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/()"
        Dim theText As String = txtmechanic.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtmechanic.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtmechanic.Text.Length - 1
            Letter = txtmechanic.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtmechanic.Text = theText
        txtmechanic.Select(SelectionIndex - Change, 0)

        If Trim(txtmechanic.Text) <> "" Then
            btnrepcancel.Enabled = True
            If btnrepedit.Text = "Edit" Then
                btnrepparts.Enabled = False
                btnrepedit.Enabled = False
                btnreprefresh.Enabled = False
            End If
        End If
    End Sub

    Private Sub linkhistory_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles linkhistory.LinkClicked
        rephistory.Text = "Repair History (" & lblplatebig.Text & ")"
        'rephistory.viewall()
        rephistory.ShowDialog()
    End Sub

    Private Sub grdrepair_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdrepair.CellContentClick
        Try
            If grdrepair.CurrentCell.ColumnIndex = 5 Then
                If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" And login.neym <> "Inspector" And login.neym <> "Whse Logistics Staff" Then
                    MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                Dim checkCell As DataGridViewCheckBoxCell = CType(grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(5), DataGridViewCheckBoxCell)
                Button1.PerformClick()
                'MsgBox(checkCell.Value)
                If checkCell.Value = False Then
                    'form kung saan yung datetime picker i seset yung datefinished
                    'dito ung may confirmation
                    dfinish = Nothing
                    finish.lblrmid.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(0).Value
                    finish.ShowDialog()

                    If finish.cncel = False Then
                        checkCell.Value = True
                    Else
                        checkCell.Value = False
                    End If
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub grdrepair_CellValueChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdrepair.CellValueChanged
        Try
            If grdrepair.Columns(e.ColumnIndex).HeaderText = "Finished" And grdrepair.RowCount <> 0 And grdrepair.CurrentCell.ColumnIndex = 5 Then
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdrepair.Rows(e.RowIndex).Cells(5), DataGridViewCheckBoxCell)
                Button1.PerformClick()
                If checkCell.Value = True Then
                    'MsgBox("true")

                    'update finished and datefinished datemodif and modif by
                    sql = "Update tblrm set finish='1', datefinish='" & Format(dfinish, "yyyy/MM/dd") & "' where rmid='" & grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(0).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    Dim typ As String = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(1).Value
                    Dim desc As String = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(2).Value
                    Me.Cursor = Cursors.Default
                    MsgBox(typ & ": " & desc & " - FINISHED.", MsgBoxStyle.Information, "")

                    btnreprefresh.PerformClick()
                Else
                    'MsgBox("false")
                End If
                grdrepair.Invalidate()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnrepparts_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrepparts.Click
        If grdrepair.SelectedRows.Count = 1 Then
            partsneeded.lblrmid.Text = grdrepair.Rows(grdrepair.CurrentRow.Index).Cells(0).Value
            partsneeded.ShowDialog()
        Else
            Me.Cursor = Cursors.Default
            MsgBox("Select only one.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub btnpmsodo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpmsodo.Click
        Try
            If grdpms.Rows.Count <> 0 Then
                If grdpms.Rows(grdpms.CurrentRow.Index).Cells(1).Value.ToString.Contains("Change Oil") Then
                    odometer.lblgenid.Text = lblid.Text
                    odometer.lblpmschid.Text = grdpms.Rows(grdpms.CurrentRow.Index).Cells(0).Value
                    odometer.ShowDialog()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("No PMS.", MsgBoxStyle.Exclamation, "")
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtlastodo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtlastodo.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Your code here
            SendKeys.Send("{TAB}")
            e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txtlastodo.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txtlastodo.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txtlastodo.Paste()
        End If
    End Sub

    Private Sub txtlastodo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtlastodo.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                nextodoforchoil()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 47 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtlastodo.Text) <> "" And txtlastodo.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtlastodo.Text) <> "" And txtlastodo.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtlastodo_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtlastodo.Leave
        txtlastodo.Text = Val(txtlastodo.Text)
        nextodoforchoil()
    End Sub

    Public Sub nextodoforchoil()
        If Val(txtmiles.Text) <> 0 Then
            culture = CultureInfo.CreateSpecificCulture("en-US")
            Dim last As Double = Double.Parse(txtlastodo.Text, culture)
            Dim mile As Double = Double.Parse(txtmiles.Text, culture)
            txtnextodo.Text = last + mile
        Else
            txtnextodo.Text = ""
        End If
    End Sub

    Private Sub txtlastodo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtlastodo.TextChanged
        Dim charactersDisallowed As String = "0123456789."
        Dim theText As String = txtlastodo.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtlastodo.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtlastodo.Text.Length - 1
            Letter = txtlastodo.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtlastodo.Text = theText
        txtlastodo.Select(SelectionIndex - Change, 0)

        If Trim(txtlastodo.Text) <> "" Then
            btnpmscancel.Enabled = True
            If btnpmsupdate.Text = "Update" Then
                btnpmsupdate.Enabled = False
                btnpmsremove.Enabled = False
                btnpmsview.Enabled = False
                btnpmsodo.Enabled = False
            Else
                btnpmsupdate.Enabled = True
                btnpmsremove.Enabled = True
                btnpmsview.Enabled = True
                btnpmsodo.Enabled = True
            End If
        End If
    End Sub

    Private Sub cmbdriver_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbdriver.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbdriver_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbdriver.Leave
        Try
            If Trim(cmbdriver.Text) <> "" Then

                sql = "Select * from tbldriver where status='1' and driver='" & Trim(cmbdriver.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbdriver.SelectedItem = dr("driver")
                    txtdriver.Text = cmbdriver.SelectedItem
                Else
                    cmbdriver.Text = ""
                    txtdriver.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

            Else
                cmbdriver.SelectedItem = ""
                cmbdriver.Text = ""
                txtdriver.Text = ""
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub genid()
        Try
            Dim gnum As String = "1", temp As String = ""
            sql = "Select Top 1 * from tblgeneral order by genid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                gnum = Val(dr("genid")) + 1
            End If
            cmd.Dispose()
            dr.Dispose()
            conn.Close()

            lblid.Text = gnum

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtliter_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtliter.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Your code here
            SendKeys.Send("{TAB}")
            e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txtliter.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txtliter.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txtliter.Paste()
        End If
    End Sub

    Private Sub txtliter_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtliter.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                'cmp()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtliter.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            e.Handled = True
                        Else
                            txtliter.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtliter.Text) <> "" And txtliter.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtliter.Text) <> "" And txtliter.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtliter_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtliter.Leave
        If txtliter.ReadOnly = False Then
            If Trim(txtliter.Text) = "" Then
                txtliter.Text = "0.00"
                txtbal.Text = "0.00"
            Else
                txtliter.Text = Val(txtliter.Text)
            End If

            culture = CultureInfo.CreateSpecificCulture("en-US")
            Dim num As Double = Double.Parse(txtliter.Text, culture)
            Dim times As Double = Double.Parse(txtinches.Text, culture)
            Dim bal As Double = num * times
            txtbal.Text = bal
        End If
    End Sub

    Private Sub txtwith_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtwith.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                'cmp()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtwith.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            e.Handled = True
                        Else
                            txtwith.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtwith.Text) <> "" And txtwith.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtwith.Text) <> "" And txtwith.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtwout_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtwout.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                'cmp()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtwout.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            e.Handled = True
                        Else
                            txtwout.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtwout.Text) <> "" And txtwout.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtwout.Text) <> "" And txtwout.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtfull_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtfull.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                'cmp()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtfull.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            e.Handled = True
                        Else
                            txtfull.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtfull.Text) <> "" And txtfull.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtfull.Text) <> "" And txtfull.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtinches_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtinches.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                'cmp()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtinches.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            e.Handled = True
                        Else
                            txtinches.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtinches.Text) <> "" And txtinches.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtinches.Text) <> "" And txtinches.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtinches_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtinches.Leave
        If txtinches.ReadOnly = False Then
            If Trim(txtinches.Text) = "" Then
                txtinches.Text = "0.00"
                txtbal.Text = "0.00"
            Else
                txtinches.Text = Val(txtinches.Text)
            End If

            culture = CultureInfo.CreateSpecificCulture("en-US")
            Dim num As Double = Double.Parse(txtliter.Text, culture)
            Dim times As Double = Double.Parse(txtinches.Text, culture)
            Dim bal As Double = num * times
            txtbal.Text = bal
        End If
    End Sub

    Private Sub txtmiles_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtmiles.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                'cmp()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtmiles.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            e.Handled = True
                        Else
                            txtmiles.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtmiles.Text) <> "" And txtmiles.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtmiles.Text) <> "" And txtmiles.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtmiles_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtmiles.Leave
        txtlastodo.Text = Val(txtlastodo.Text)
        nextodoforchoil()
    End Sub

    Private Sub txttank_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txttank.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Your code here
            SendKeys.Send("{TAB}")
            e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txttank.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txttank.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txttank.Paste()
        End If
    End Sub

    Private Sub txttank_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttank.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txttank_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttank.TextChanged
        Dim charactersDisallowed As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789."
        Dim theText As String = txttank.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txttank.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txttank.Text.Length - 1
            Letter = txttank.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txttank.Text = theText
        txttank.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtliter_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtliter.TextChanged
        Dim charactersDisallowed As String = "0123456789."
        Dim theText As String = txtliter.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtliter.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtliter.Text.Length - 1
            Letter = txtliter.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtliter.Text = theText
        txtliter.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtpmsrems_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtpmsrems.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtpmsrems_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtpmsrems.TextChanged

    End Sub

    Private Sub cmbdriver_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbdriver.SelectedIndexChanged

    End Sub

    Private Sub txtdesc_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtdesc.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtdesc_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdesc.TextChanged

    End Sub

    Private Sub txtothers_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtothers.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtothers_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtothers.TextChanged

    End Sub

    Private Sub vmanage_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub txtinches_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtinches.TextChanged

    End Sub

    Private Sub grdplate_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdplate.CellContentClick

    End Sub

    Private Sub txtwith_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtwith.TextChanged

    End Sub
End Class