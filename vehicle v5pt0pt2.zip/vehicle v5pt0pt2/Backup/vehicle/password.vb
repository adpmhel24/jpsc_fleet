﻿Imports System.Data.OleDb
Imports System.IO
Imports System.Data.SqlClient

Imports System.Security
Imports System.Security.Cryptography
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Imports System.Text

Public Class password
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand
    Dim a As String

    Public Sub connect()
        conn = New SqlConnection 'New OleDb.OleDbConnection
        conn.connectionstring = Strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection 'New OleDb.OleDbConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Trim(txtuser.Text) = "" Or Trim(txtold.Text) = "" Or Trim(txtnew.Text) = "" Or Trim(txtconfirm.Text) = "" Then
            MsgBox("Incomplete Fields!", MsgBoxStyle.Exclamation, "")
            txtuser.Focus()
            Exit Sub
        Else
            Try
                sql = "SELECT * from tblusers"
                connect()
                cmd = New SqlCommand(sql, conn) 'New OleDbCommand(sql, conn)
                dr = cmd.ExecuteReader
                While dr.Read
                    If txtuser.Text = dr("username").ToString And txtold.Text = Decrypt(dr("password").ToString) Then
                        If dr("status").ToString = "0" Then
                            MsgBox("Account Deactivated", MsgBoxStyle.Exclamation, "Status")
                            txtuser.Text = ""
                            txtold.Text = ""
                            txtuser.Focus()
                            Exit Sub
                        Else
                            Dim a As String
                            a = MsgBox("Are you sure you want to change password?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
                            If a <> vbYes Then
                                Exit Sub
                            End If
                            'update password
                            sql = "Update tblusers set password='" & Encrypt(Trim(txtnew.Text)) & "' where username ='" & Trim(txtuser.Text) & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn) 'New OleDbCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            MsgBox("Successfully changed password", MsgBoxStyle.Information, "")

                            login.txtusername.Focus()
                            Me.Dispose()
                        End If
                        Exit Sub
                    End If
                End While
                dr.Close()
                cmd.Dispose()
                conn.Close()

                MsgBox("Invalid Username or Old Password", MsgBoxStyle.Critical, "Invalid")
                txtuser.Text = ""
                txtold.Text = ""
                txtnew.Text = ""
                txtconfirm.Text = ""
                txtconfirm.Enabled = False
                txtuser.Focus()
            Catch ex As System.FormatException
                MsgBox("Invalid Username or Old Password", MsgBoxStyle.Critical, "Invalid")
                txtuser.Text = ""
                txtold.Text = ""
                txtnew.Text = ""
                txtconfirm.Text = ""
                txtconfirm.Enabled = False
                txtuser.Focus()
            Catch ex As Exception
                MsgBox(ex.ToString)
            Finally
                disconnect()
            End Try
        End If
    End Sub

    Private Sub txtnew_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtnew.Leave
        If Trim(txtnew.Text) <> "" Then
            If Trim(txtnew.Text) = Trim(txtold.Text) Then
                MsgBox("New password is similar to old password. Try another password.", MsgBoxStyle.Exclamation, "")
                txtnew.Text = ""
                txtnew.Focus()
                Exit Sub
            End If
            txtconfirm.Enabled = True
            txtconfirm.Focus()
        Else
            txtconfirm.Enabled = False
        End If
    End Sub

    Private Sub txtconfirm_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtconfirm.Leave
        If Trim(txtnew.Text) <> Trim(txtconfirm.Text) Then
            MsgBox("Password not match", MsgBoxStyle.Critical, "")
            txtnew.Text = ""
            txtconfirm.Text = ""
            txtnew.Focus()
            txtconfirm.Enabled = False
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim a As String
        a = MsgBox("Are you sure you want to cancel?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            login.txtusername.Focus()
            Me.Dispose()
        End If
    End Sub

    Public Function Encrypt(ByVal plainText As String) As String

        Dim passPhrase As String = "minePassPhrase"
        Dim saltValue As String = "mySaltValue"
        Dim hashAlgorithm As String = "SHA1"

        Dim passwordIterations As Integer = 2
        Dim initVector As String = "@1B2c3D4e5F6g7H8"
        Dim keySize As Integer = 256

        Dim initVectorBytes As Byte() = Encoding.ASCII.GetBytes(initVector)
        Dim saltValueBytes As Byte() = Encoding.ASCII.GetBytes(saltValue)

        Dim plainTextBytes As Byte() = Encoding.UTF8.GetBytes(plainText)


        Dim password As New PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations)

        Dim keyBytes As Byte() = password.GetBytes(keySize \ 8)
        Dim symmetricKey As New RijndaelManaged()

        symmetricKey.Mode = CipherMode.CBC

        Dim encryptor As ICryptoTransform = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes)

        Dim memoryStream As New MemoryStream()
        Dim cryptoStream As New CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write)

        cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length)
        cryptoStream.FlushFinalBlock()
        Dim cipherTextBytes As Byte() = memoryStream.ToArray()
        memoryStream.Close()
        cryptoStream.Close()
        Dim cipherText As String = Convert.ToBase64String(cipherTextBytes)
        Return cipherText
    End Function

    Public Function Decrypt(ByVal cipherText As String) As String
        Dim passPhrase As String = "minePassPhrase"
        Dim saltValue As String = "mySaltValue"
        Dim hashAlgorithm As String = "SHA1"

        Dim passwordIterations As Integer = 2
        Dim initVector As String = "@1B2c3D4e5F6g7H8"
        Dim keySize As Integer = 256
        ' Convert strings defining encryption key characteristics into byte
        ' arrays. Let us assume that strings only contain ASCII codes.
        ' If strings include Unicode characters, use Unicode, UTF7, or UTF8
        ' encoding.
        Dim initVectorBytes As Byte() = Encoding.ASCII.GetBytes(initVector)
        Dim saltValueBytes As Byte() = Encoding.ASCII.GetBytes(saltValue)

        ' Convert our ciphertext into a byte array.
        Dim cipherTextBytes As Byte() = Convert.FromBase64String(cipherText)

        ' First, we must create a password, from which the key will be 
        ' derived. This password will be generated from the specified 
        ' passphrase and salt value. The password will be created using
        ' the specified hash algorithm. Password creation can be done in
        ' several iterations.
        Dim password As New PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations)

        ' Use the password to generate pseudo-random bytes for the encryption
        ' key. Specify the size of the key in bytes (instead of bits).
        Dim keyBytes As Byte() = password.GetBytes(keySize \ 8)

        ' Create uninitialized Rijndael encryption object.
        Dim symmetricKey As New RijndaelManaged()

        ' It is reasonable to set encryption mode to Cipher Block Chaining
        ' (CBC). Use default options for other symmetric key parameters.
        symmetricKey.Mode = CipherMode.CBC

        ' Generate decryptor from the existing key bytes and initialization 
        ' vector. Key size will be defined based on the number of the key 
        ' bytes.
        Dim decryptor As ICryptoTransform = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes)

        ' Define memory stream which will be used to hold encrypted data.
        Dim memoryStream As New MemoryStream(cipherTextBytes)

        ' Define cryptographic stream (always use Read mode for encryption).
        Dim cryptoStream As New CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read)

        ' Since at this point we don't know what the size of decrypted data
        ' will be, allocate the buffer long enough to hold ciphertext;
        ' plaintext is never longer than ciphertext.
        Dim plainTextBytes As Byte() = New Byte(cipherTextBytes.Length - 1) {}

        ' Start decrypting.
        Dim decryptedByteCount As Integer = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length)

        ' Close both streams.
        memoryStream.Close()
        cryptoStream.Close()

        ' Convert decrypted data into a string. 
        ' Let us assume that the original plaintext string was UTF8-encoded.
        Dim plainText As String = Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount)

        ' Return decrypted string.   
        Return plainText
    End Function

    Private Sub password_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class