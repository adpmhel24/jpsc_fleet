﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class tripsumedit
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public tayp As String

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub transoredit_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sumedit()
    End Sub

    Private Sub sumedit()
        Try
            lbltripnum.Text = viewstep1.lbltripnum1.Text

            grd.Rows.Clear()

            sql = "Select * from tbltripsumedit where tayp = '" & tayp & "' and whsename='" & login.whse & "' and tripnum='" & lbltripnum.Text & "' and status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grd.Rows.Add(dr("taypid"), dr("prev_value"), dr("new_value"), dr("createdby"), dr("datecreated"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class