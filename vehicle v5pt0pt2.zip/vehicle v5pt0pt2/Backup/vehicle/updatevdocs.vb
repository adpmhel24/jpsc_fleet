﻿Imports System.IO
Imports System.Data.SqlClient

Public Class updatevdocs
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Public vdoccnf As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub updatevdocs_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        datelastrenew.MaxDate = Date.Now
        dateexpired.MinDate = datelastrenew.Value
        datelastrenew.CustomFormat = "yyyy/MM/dd"
        dateexpired.CustomFormat = "yyyy/MM/dd"

        loaddoc()
        loadcompsch()

        chkuse.Checked = False
        chkuse.Checked = True

        grddoc.Columns(0).ReadOnly = True
        grddoc.Columns(1).ReadOnly = True
        grddoc.Columns(2).ReadOnly = True
    End Sub

    Public Sub loaddoc()
        Try
            cmbdocname.Items.Clear()
            cmbdocname.Items.Add("")

            sql = "Select * from tbldoc where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbdocname.Items.Add(dr("docname"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadcompsch()
        Try
            cmbcompany.Items.Clear()

            sql = "Select * from tblcompany where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbcompany.Items.Add(dr("company"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbcompany.Items.Count <> 0 Then
                cmbcompany.Items.Add("All")
                cmbcompany.SelectedIndex = 0
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadwhsesch()
        Try
            cmbwhse.Items.Clear()
            cmbwhse.Items.Add("")

            sql = "Select * from tblwhse where status='1' and company='" & cmbcompany.SelectedItem & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbwhse.Items.Add(dr("whsename"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbwhse.Items.Count <> 0 Then
                cmbwhse.Items.Add("All")
                cmbwhse.SelectedIndex = 0
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub viewplate()
        Try
            grddoc.Rows.Clear()

            Dim plnum As String = ""

            If cmbcompany.SelectedItem <> "" And cmbwhse.SelectedItem <> "" Then
                sql = "Select * from tblgeneral where status='1'"
                If cmbcompany.SelectedItem <> "All" Then
                    sql = sql & " and company='" & cmbcompany.SelectedItem & "'"
                End If

                If cmbwhse.SelectedItem <> "All" Then
                    sql = sql & " and whsename='" & cmbwhse.SelectedItem & "'"
                End If

                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                While dr.Read
                    If dr("platenum") = "" And dr("vplate") <> "" Then
                        plnum = dr("vplate")
                    ElseIf dr("platenum") = "" And dr("vplate") = "" And dr("csticker") <> "" Then
                        plnum = dr("csticker")
                    Else
                        plnum = dr("platenum")
                    End If
                    grddoc.Rows.Add(dr("genid"), plnum, dr("vtype"), True)
                End While
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbcompany_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcompany.SelectedIndexChanged
        loadwhsesch()
        viewplate()
        checkcomplete()
    End Sub

    Private Sub cmbwhse_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbwhse.SelectedIndexChanged
        viewplate()
        checkcomplete()
    End Sub

    Private Sub datelastrenew_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datelastrenew.ValueChanged
        dateexpired.MinDate = datelastrenew.Value
        If chkuse.Checked = True Then
            checkdateexp()
        End If
    End Sub

    Public Sub checkdateexp()
        If num.Value <> 0 Then
            Dim last As Date = CDate(Format(datelastrenew.Value, "yyyy/MM/dd"))
            If cmbinterval.SelectedIndex = 1 Then
                ' dateexpired.Value = datelastrenew.Value.AddYears(+num.Value)
                dateexpired.Value = last.AddYears(+num.Value)
            ElseIf cmbinterval.SelectedIndex = 2 Then
                dateexpired.Value = last.AddMonths(+num.Value)
            ElseIf cmbinterval.SelectedIndex = 3 Then
                dateexpired.Value = last.AddDays(+num.Value)
            End If
        Else
            cmbinterval.SelectedIndex = 0
            dateexpired.Value = datelastrenew.Value
        End If
    End Sub

    Private Sub num_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles num.ValueChanged
        checkdateexp()
        checkcomplete()
    End Sub

    Private Sub cmbinterval_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbinterval.SelectedIndexChanged
        checkdateexp()
        checkcomplete()
    End Sub

    Private Sub chkuse_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkuse.CheckedChanged
        If chkuse.Checked = True Then
            num.Enabled = True
            cmbinterval.Enabled = True
            dateexpired.Enabled = False
        Else
            num.Enabled = False
            cmbinterval.Enabled = False
            dateexpired.Enabled = True
            num.Value = 0
            cmbinterval.SelectedItem = ""
        End If

        checkcomplete()
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            vdoccnf = False
            confirm.ShowDialog()
            If vdoccnf = True Then


                For Each row As DataGridViewRow In grddoc.Rows
                    If grddoc.Rows(row.Index).Cells(3).Value = True Then
                        sql = "Select * from tbldocexp where genid='" & grddoc.Rows(row.Index).Cells(0).Value & "' and docname='" & cmbdocname.SelectedItem & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            'Update(docu)
                            lbldocid.Text = dr("docid")
                            'save
                            statusofexp()

                            dr.Dispose()
                            cmd.Dispose()

                            sql = "Update tbldocexp set docname='" & cmbdocname.SelectedItem & "', datelast='" & Format(datelastrenew.Value, "yyyy/MM/dd") & "', num='" & num.Value & "', interval='" & cmbinterval.SelectedItem & "', dateexpired='" & Format(dateexpired.Value, "yyyy/MM/dd") & "', datemodified=GetDate(), modifiedby='" & login.cashier & "', statusexp='" & lblexp.Text & "' where docid='" & lbldocid.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            'MsgBox(grddoc.Rows(row.Index).Cells(0).Value.ToString)
                        Else
                            'add docu
                            statusofexp()

                            sql = "Insert into tbldocexp (genid, docname, datelast, num, interval, dateexpired, datecreated, createdby, datemodified, modifiedby, statusexp, status) values ('" & grddoc.Rows(row.Index).Cells(0).Value & "','" & cmbdocname.SelectedItem & "', '" & Format(datelastrenew.Value, "yyyy/MM/dd") & "', '" & num.Value & "', '" & cmbinterval.SelectedItem & "', '" & Format(dateexpired.Value, "yyyy/MM/dd") & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '" & lblexp.Text & "', '1')"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            'MsgBox(grddoc.Rows(row.Index).Cells(0).Value.ToString)
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()
                    End If
                Next

                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")
                btncancel.PerformClick()
            End If

            vdoccnf = False

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checkcomplete()
        If cmbdocname.SelectedItem <> "" And cmbcompany.SelectedItem <> "" And cmbwhse.SelectedItem <> "" And grddoc.Rows.Count <> 0 Then
            If chkuse.Checked = True Then
                If num.Value <> 0 And cmbinterval.SelectedItem <> "" Then
                    btnupdate.Enabled = True
                Else
                    btnupdate.Enabled = False
                End If
            Else
                btnupdate.Enabled = True
            End If
        Else
            btnupdate.Enabled = False
        End If
    End Sub

    Private Sub cmbdocname_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbdocname.SelectedIndexChanged
        checkcomplete()
    End Sub

    Public Sub statusofexp()
        Try
            Dim dnow As Date = CDate(Format(Date.Now, "yyyy/MM/dd"))
            Dim dexp As Date = CDate(Format(dateexpired.Value, "yyyy/MM/dd"))
            Dim db4 As Date = CDate(Format(dateexpired.Value.AddDays(-14), "yyyy/MM/dd"))

            If dnow >= dexp Then
                ' MsgBox("Expired")
                lblexp.Text = "Expired"
            ElseIf dnow >= db4 And dnow < dexp Then
                ' MsgBox("Soon to expire")
                lblexp.Text = "Soon to expire"
            Else
                ' MsgBox("Updated")
                lblexp.Text = "Updated"
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        cmbdocname.SelectedItem = ""
        cmbcompany.SelectedItem = ""
        cmbinterval.SelectedItem = ""
        cmbwhse.SelectedItem = ""
        num.Value = 0
        grddoc.Rows.Clear()
    End Sub

    Private Sub grddoc_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grddoc.CellClick
        grddoc.BeginEdit(True)
    End Sub

    Private Sub grddoc_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grddoc.CellContentClick
        Try
            If grddoc.CurrentCell.ColumnIndex = 3 Then
                Dim checkCell As DataGridViewCheckBoxCell = CType(grddoc.Rows(grddoc.CurrentRow.Index).Cells(3), DataGridViewCheckBoxCell)
                '/Button1.PerformClick()
                If checkCell.Value = False Then
                    checkCell.Value = True
                Else
                    checkCell.Value = False
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub grddoc_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grddoc.CellMouseClick
        Try
            If grddoc.CurrentCell.ColumnIndex = 3 Then
                Dim checkCell As DataGridViewCheckBoxCell = CType(grddoc.Rows(grddoc.CurrentRow.Index).Cells(3), DataGridViewCheckBoxCell)
                Button1.PerformClick()
                If checkCell.Value = False Then
                    checkCell.Value = True
                Else
                    checkCell.Value = False
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        End Try
    End Sub
End Class