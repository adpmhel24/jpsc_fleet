﻿Imports System.IO
Imports System.Data.SqlClient

Public Class odometer
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Public odocnf As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btnaddodo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnaddodo.Click
        Try
            'check first if complete
            If Trim(txtodoloc.Text) <> "" And Trim(txtodoread.Text) <> "" Then
                'check if date is already added where pmsid = lblpmsid
                sql = "Select * from tblodometer where pmschid='" & Val(lblpmschid.Text) & "' and ododate='" & CDate(Format(dateodo.Value, "MM/dd/yyyy")) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    MsgBox("There is already odometer reading added on " & Format(dateodo.Value, "MM/dd/yyyy"), MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                'add
                confirm.ShowDialog()
                If odocnf = True Then
                    sql = "Insert into tblodometer (pmschid, genid, ododate, location, odometer, remarks, datecreated, createdby, datemodified, modifiedby) values ('" & lblpmschid.Text & "','" & lblgenid.Text & "','" & Format(dateodo.Value, "MM/dd/yyyy") & "','" & Trim(txtodoloc.Text) & "','" & Trim(txtodoread.Text) & "','" & Trim(txtodorems.Text) & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    Me.Cursor = Cursors.Default
                    MsgBox("Successfully added.", MsgBoxStyle.Information, "")
                    btnviewodo.PerformClick()
                Else
                    Exit Sub
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Complete the required fields.", MsgBoxStyle.Exclamation, "")
                txtodoloc.Focus()
                Exit Sub
            End If

            odocnf = False
            btncancelodo.PerformClick()
            btnviewodo.PerformClick()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btneditodo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btneditodo.Click
        Try
            If btneditodo.Text = "Edit" Then
                If grdodo.SelectedCells.Count = 1 Or grdodo.SelectedRows.Count = 1 Then
                    lblodoid.Text = grdodo.Rows(grdodo.CurrentRow.Index).Cells(0).Value
                    dateodo.Value = grdodo.Rows(grdodo.CurrentRow.Index).Cells(1).Value
                    txtodoloc.Text = grdodo.Rows(grdodo.CurrentRow.Index).Cells(2).Value
                    txtodoread.Text = grdodo.Rows(grdodo.CurrentRow.Index).Cells(3).Value
                    txtodorems.Text = grdodo.Rows(grdodo.CurrentRow.Index).Cells(4).Value

                    grdodo.Enabled = False

                    btneditodo.Enabled = True
                    btnaddodo.Enabled = False
                    btnremodo.Enabled = False
                    btnviewodo.Enabled = False
                    btncancelodo.Enabled = True
                    btneditodo.Text = "Save"
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select Only One.", MsgBoxStyle.Exclamation, "")
                End If
            Else
                'check if complete
                If Trim(txtodoloc.Text) <> "" And Trim(txtodoread.Text) <> "" Then
                    'check if date is not already added where id is not equal to dis id
                    sql = "Select * from tblodometer where odoid<>'" & Val(lblodoid.Text) & "' and pmschid='" & Val(lblpmschid.Text) & "' and ododate='" & CDate(Format(dateodo.Value, "MM/dd/yyyy")) & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox("There is already odometer reading added on " & Format(dateodo.Value, "MM/dd/yyyy"), MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    confirm.ShowDialog()
                    If odocnf = True Then
                        'save
                        sql = "Update tblodometer set ododate='" & Format(dateodo.Value, "MM/dd/yyyy") & "', location='" & Trim(txtodoloc.Text) & "', odometer='" & Trim(txtodoread.Text) & "', remarks='" & Trim(txtodorems.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where odoid='" & lblodoid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")
                        checklatest()

                        odocnf = False
                        btncancelodo.PerformClick()
                        btnviewodo.PerformClick()
                    End If
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Complete the required fields.", MsgBoxStyle.Exclamation, "")
                End If
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncancelodo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancelodo.Click
        grdodo.Enabled = True
        lblodoid.Text = ""
        txtodoloc.Text = ""
        txtodoread.Text = ""
        dateodo.Value = dateodo.MaxDate

        btneditodo.Text = "Edit"
        btneditodo.Enabled = True
        btnaddodo.Enabled = True
        btnremodo.Enabled = True
        btnviewodo.Enabled = True
        btncancelodo.Enabled = False
        btnviewodo.PerformClick()
    End Sub

    Private Sub btnremodo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnremodo.Click
        Try
            If grdodo.SelectedCells.Count = 1 Or grdodo.SelectedRows.Count = 1 Then
                Dim a As String = MsgBox("Are you sure you want to remove?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                If a = vbYes Then
                    confirm.ShowDialog()
                    If odocnf = True Then
                        sql = "Delete from tblodometer where odoid='" & grdodo.Rows(grdodo.CurrentRow.Index).Cells(0).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully remove.", MsgBoxStyle.Information, "")
                    End If
                    odocnf = False
                    btnviewodo.PerformClick()
                End If
            Else
                MsgBox("Select only one.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnviewodo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnviewodo.Click
        Try
            grdodo.Rows.Clear()

            Me.Cursor = Cursors.WaitCursor
            sql = "Select * from tblodometer where ododate>='" & Format(datefromodo.Value, "MM/dd/yyyy") & "' and ododate<='" & Format(datetoodo.Value, "MM/dd/yyyy") & "' and pmschid='" & lblpmschid.Text & "' order by ododate"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grdodo.Rows.Add(dr("odoid"), Format(dr("ododate"), "MM/dd/yyyy"), dr("location"), dr("odometer"), dr("remarks"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()
            Me.Cursor = Cursors.Default

            If grdodo.Rows.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("No Found Record.", MsgBoxStyle.Critical, "")
            Else
                checklatest()
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub datefromodo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datefromodo.ValueChanged
        datetoodo.MinDate = datefromodo.Value
    End Sub

    Private Sub txtodoloc_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtodoloc.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789._/-()"
        Dim theText As String = txtodoloc.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtodoloc.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtodoloc.Text.Length - 1
            Letter = txtodoloc.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtodoloc.Text = theText
        txtodoloc.Select(SelectionIndex - Change, 0)

        If (Trim(txtodoloc.Text) <> "" Or Trim(txtodoread.Text) <> "" Or Trim(txtodorems.Text) <> "") Then
            btncancelodo.Enabled = True
            If btneditodo.Text = "Edit" Then
                btneditodo.Enabled = False
                btnremodo.Enabled = False
                btnviewodo.Enabled = False
            End If
        End If
    End Sub

    Private Sub txtodoread_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtodoread.TextChanged
        Dim charactersDisallowed As String = "0123456789."
        Dim theText As String = txtodoread.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtodoread.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtodoread.Text.Length - 1
            Letter = txtodoread.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtodoread.Text = theText
        txtodoread.Select(SelectionIndex - Change, 0)

        If (Trim(txtodoloc.Text) <> "" Or Trim(txtodoread.Text) <> "" Or Trim(txtodorems.Text) <> "") Then
            btncancelodo.Enabled = True
            If btneditodo.Text = "Edit" Then
                btneditodo.Enabled = False
                btnremodo.Enabled = False
                btnviewodo.Enabled = False
            End If
        End If
    End Sub

    Private Sub txtodorems_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtodorems.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789._/-()"
        Dim theText As String = txtodorems.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtodorems.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtodorems.Text.Length - 1
            Letter = txtodorems.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtodorems.Text = theText
        txtodorems.Select(SelectionIndex - Change, 0)

        If (Trim(txtodoloc.Text) <> "" Or Trim(txtodoread.Text) <> "" Or Trim(txtodorems.Text) <> "") Then
            btncancelodo.Enabled = True
            If btneditodo.Text = "Edit" Then
                btneditodo.Enabled = False
                btnremodo.Enabled = False
                btnviewodo.Enabled = False
            End If
        End If
    End Sub

    Private Sub odometer_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        vmanage.btnpmsview.PerformClick()
        grdodo.Rows.Clear()
        Me.Dispose()
    End Sub

    Private Sub odometer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dateodo.MaxDate = Date.Now
        datefromodo.MaxDate = Date.Now    '/// nag eerrror na lumalagpas kc sya sa maximum date
        datetoodo.MinDate = datefromodo.Value
        datetoodo.MaxDate = Date.Now
        btnviewodo.PerformClick()
    End Sub

    Public Sub checklatest()
        Try
            Dim lastodo As Double = 0

            sql = "Select TOP 1 * from tblodometer where genid='" & lblgenid.Text & "' order by ododate DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                lastodo = dr("odometer")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            sql = "Update tblpmssched set latestodo='" & lastodo & "' where pmschid='" & lblpmschid.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class