﻿Imports System.IO
Imports System.Data.SqlClient

Public Class partsneeded
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Public pused As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub partsneeded_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        loaddesc()
        view()
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            If Trim(txtprnum.Text) <> "" And Trim(txtqty.Text) <> "" And cmbdes.SelectedItem <> "" Then
                'confirm.ShowDialog()
                'If pused = True Then
                sql = "Insert into tblpartsused (partid,rmid,qty,datecreatd,createdby,datemodified,modifiedby,status) values ('" & lblpartid.Text & "','" & lblrmid.Text & "','" & Trim(txtqty.Text) & "',GetDate(),'" & login.cashier & "',GetDate(),'" & login.cashier & "','1')"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                view()

                txtprnum.Text = ""
                cmbdes.SelectedItem = ""
                txtqty.Text = ""
            Else
                MsgBox("Complete the fields.", MsgBoxStyle.Exclamation, "")
            End If

            If grdparts.Rows.Count <> 0 Then
                btnremove.Enabled = True
            Else
                btnremove.Enabled = False
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information, "")
        End Try
    End Sub

    Public Sub loaddesc()
        Try
            cmbdes.Items.Clear()
            cmbdes.Items.Add("")

            sql = "Select * from tblparts where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbdes.Items.Add(dr("description"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbdes_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbdes.SelectedIndexChanged
        If cmbdes.SelectedItem <> "" Then
            sql = "Select * from tblparts where description='" & cmbdes.SelectedItem & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                txtprnum.Text = dr("partnum")
                lblpartid.Text = dr("partid")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()
            txtqty.Focus()
        Else
            txtprnum.Text = ""
        End If
    End Sub

    Private Sub txtprnum_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtprnum.KeyPress
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            chkprnum()
        End If
    End Sub

    Private Sub txtprnum_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtprnum.Leave
        chkprnum()
    End Sub

    Private Sub txtprnum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtprnum.TextChanged
        'restrict inputs into numbers only
        Dim charactersDisallowed As String = "0123456789"
        Dim theText As String = txtprnum.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtprnum.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtprnum.Text.Length - 1
            Letter = txtprnum.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtprnum.Text = theText
        txtprnum.Select(SelectionIndex - Change, 0)
    End Sub

    Public Sub chkprnum()
        Try
            If Trim(txtprnum.Text) <> "" Then
                sql = "Select * from tblparts where partnum='" & Trim(txtprnum.Text) & "' and status='1'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbdes.SelectedItem = dr("description")
                    lblpartid.Text = dr("partid")
                Else
                    MsgBox("Invalid part number " & Trim(txtprnum.Text), MsgBoxStyle.Exclamation, "")
                    txtprnum.Text = ""
                    txtprnum.Focus()
                    cmbdes.SelectedItem = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Else
                cmbdes.SelectedItem = ""
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtqty_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtqty.TextChanged
        'restrict inputs into numbers only
        Dim charactersDisallowed As String = "0123456789"
        Dim theText As String = txtqty.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtqty.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtqty.Text.Length - 1
            Letter = txtqty.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtqty.Text = theText
        txtqty.Select(SelectionIndex - Change, 0)
    End Sub

    Public Sub view()
        Try
            grdparts.Rows.Clear()

            sql = "Select * from tblpartsused where rmid='" & lblrmid.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grdparts.Rows.Add(dr("prusedid"), dr("partid"), "", dr("qty"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            For Each row As DataGridViewRow In grdparts.Rows
                sql = "Select * from tblparts where partid='" & grdparts.Rows(row.Index).Cells(1).Value & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    grdparts.Item(1, row.Index).Value = dr("partnum")
                    grdparts.Item(2, row.Index).Value = dr("description")
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Next

            If grdparts.Rows.Count = 0 Then
                btnremove.Enabled = False
            Else
                btnremove.Enabled = True
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnremove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnremove.Click
        Try
            Dim a As String = MsgBox("Are you sure you want to remove?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
            If a = vbYes Then
                sql = "Delete from tblpartsused where prusedid='" & grdparts.Rows(grdparts.CurrentRow.Index).Cells(0).Value & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                view()
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class