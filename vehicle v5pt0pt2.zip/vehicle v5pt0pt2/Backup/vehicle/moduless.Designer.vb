﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class moduless
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Company")
        Dim TreeNode2 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Warehouse")
        Dim TreeNode3 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Documents")
        Dim TreeNode4 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Vehicle")
        Dim TreeNode5 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Driver")
        Dim TreeNode6 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Helper")
        Dim TreeNode7 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Customer")
        Dim TreeNode8 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Category")
        Dim TreeNode9 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Items")
        Dim TreeNode10 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("General", New System.Windows.Forms.TreeNode() {TreeNode1, TreeNode2, TreeNode3, TreeNode4, TreeNode5, TreeNode6, TreeNode7, TreeNode8, TreeNode9})
        Dim TreeNode11 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Create Order")
        Dim TreeNode12 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Order Transactions")
        Dim TreeNode13 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Trip Scheduling")
        Dim TreeNode14 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Trip Dispatching")
        Dim TreeNode15 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Trip Dispatch Summary")
        Dim TreeNode16 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Trip Summary")
        Dim TreeNode17 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Vehicle Trip", New System.Windows.Forms.TreeNode() {TreeNode11, TreeNode12, TreeNode13, TreeNode14, TreeNode15, TreeNode16})
        Dim TreeNode18 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Trip Schedule Report")
        Dim TreeNode19 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("For Change Oil")
        Dim TreeNode20 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Reports", New System.Windows.Forms.TreeNode() {TreeNode18, TreeNode19})
        Dim TreeNode21 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Users")
        Dim TreeNode22 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Login Logs")
        Dim TreeNode23 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Version")
        Dim TreeNode24 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Adjust Qty")
        Dim TreeNode25 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Insert into Dashboard")
        Dim TreeNode26 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Restore Comment")
        Dim TreeNode27 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Delete Previous Attachments")
        Dim TreeNode28 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Administrator", New System.Windows.Forms.TreeNode() {TreeNode21, TreeNode22, TreeNode23, TreeNode24, TreeNode25, TreeNode26, TreeNode27})
        Me.TreeView1 = New System.Windows.Forms.TreeView
        Me.TreeView2 = New System.Windows.Forms.TreeView
        Me.Button2 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'TreeView1
        '
        Me.TreeView1.Location = New System.Drawing.Point(236, 216)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.Size = New System.Drawing.Size(48, 43)
        Me.TreeView1.TabIndex = 0
        Me.TreeView1.Visible = False
        '
        'TreeView2
        '
        Me.TreeView2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TreeView2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView2.HideSelection = False
        Me.TreeView2.Location = New System.Drawing.Point(12, 12)
        Me.TreeView2.Name = "TreeView2"
        TreeNode1.Name = "Node0"
        TreeNode1.Text = "Company"
        TreeNode2.Name = "Node1"
        TreeNode2.Text = "Warehouse"
        TreeNode3.Name = "Node2"
        TreeNode3.Text = "Documents"
        TreeNode4.Name = "Node6"
        TreeNode4.Tag = "mdiform"
        TreeNode4.Text = "Vehicle"
        TreeNode5.Name = "Node8"
        TreeNode5.Text = "Driver"
        TreeNode6.Name = "Node0"
        TreeNode6.Text = "Helper"
        TreeNode7.Name = "Node9"
        TreeNode7.Text = "Customer"
        TreeNode8.Name = "Node5"
        TreeNode8.Text = "Category"
        TreeNode9.Name = "Node6"
        TreeNode9.Text = "Items"
        TreeNode10.Name = "Node0"
        TreeNode10.Text = "General"
        TreeNode11.Name = "Node7"
        TreeNode11.Text = "Create Order"
        TreeNode12.Name = "Node0"
        TreeNode12.Text = "Order Transactions"
        TreeNode13.Name = "Node3"
        TreeNode13.Tag = "tripadd"
        TreeNode13.Text = "Trip Scheduling"
        TreeNode14.Name = "Node4"
        TreeNode14.Tag = "tripdispatch"
        TreeNode14.Text = "Trip Dispatching"
        TreeNode15.Name = "Node5"
        TreeNode15.Tag = "tripdispatchsum"
        TreeNode15.Text = "Trip Dispatch Summary"
        TreeNode16.Name = "Node0"
        TreeNode16.Text = "Trip Summary"
        TreeNode17.Name = "Node1"
        TreeNode17.Text = "Vehicle Trip"
        TreeNode18.Name = "Node0"
        TreeNode18.Tag = "tripreport"
        TreeNode18.Text = "Trip Schedule Report"
        TreeNode19.Name = "Node0"
        TreeNode19.Tag = "forchangeoil"
        TreeNode19.Text = "For Change Oil"
        TreeNode20.Name = "Node0"
        TreeNode20.Text = "Reports"
        TreeNode21.Name = "Node0"
        TreeNode21.Text = "Users"
        TreeNode22.Name = "Node1"
        TreeNode22.Tag = "loginlogs"
        TreeNode22.Text = "Login Logs"
        TreeNode23.Name = "Node0"
        TreeNode23.Tag = "version"
        TreeNode23.Text = "Version"
        TreeNode24.Name = "Node0"
        TreeNode24.Text = "Adjust Qty"
        TreeNode25.Name = "Node0"
        TreeNode25.Text = "Insert into Dashboard"
        TreeNode26.Name = "Node0"
        TreeNode26.Text = "Restore Comment"
        TreeNode27.Name = "Node0"
        TreeNode27.Text = "Delete Previous Attachments"
        TreeNode28.Name = "Node0"
        TreeNode28.Text = "Administrator"
        Me.TreeView2.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode10, TreeNode17, TreeNode20, TreeNode28})
        Me.TreeView2.Size = New System.Drawing.Size(337, 507)
        Me.TreeView2.TabIndex = 1
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(273, 13)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 34
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'moduless
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(363, 531)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TreeView2)
        Me.Controls.Add(Me.TreeView1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "moduless"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Modules"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents TreeView2 As System.Windows.Forms.TreeView
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
