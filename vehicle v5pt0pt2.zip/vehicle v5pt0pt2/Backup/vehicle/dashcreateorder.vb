﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Windows.Forms.DataVisualization.Charting

Public Class dashcreateorder
    Dim lines1 = System.IO.File.ReadAllLines("connectionstringmnl.txt")  'manila  
    Dim strconn1 As String = lines1(0) 'manila    
    Dim lines2 = System.IO.File.ReadAllLines("connectionstringcal.txt") 'calamba
    Dim strconn2 As String = lines2(0) 'calamba
    Dim lines3 = System.IO.File.ReadAllLines("connectionstringpgb.txt") 'lucena
    Dim strconn3 As String = lines3(0) 'lucena
    Dim lines4 = System.IO.File.ReadAllLines("connectionstringmil.txt") 'milaor
    Dim strconn4 As String = lines4(0) 'milaor
    Dim lines5 = System.IO.File.ReadAllLines("connectionstring.txt") 'Lc Office
    Dim strconn5 As String = lines5(0) 'Lc Office
    Dim lines6 = System.IO.File.ReadAllLines("connectionstringceb.txt") 'cebu
    Dim strconn6 As String = lines6(0) 'cebu
    Dim lines7 = System.IO.File.ReadAllLines("connectionstringdav.txt") 'davao
    Dim strconn7 As String = lines7(0) 'davao
    Dim lines8 = System.IO.File.ReadAllLines("connectionstringbcd.txt") 'bacolod
    Dim strconn8 As String = lines8(0) 'bacolod
    Dim lines9 = System.IO.File.ReadAllLines("connectionstringtac.txt") 'tacloban
    Dim strconn9 As String = lines9(0) 'tacloban

    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Private da As SqlDataAdapter
    Private ds As DataSet1

    Public Sub connectmnl()
        conn = New SqlConnection 'New OleDb.OleDbConnection
        conn.ConnectionString = strconn1
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub connectcal()
        conn = New SqlConnection
        conn.ConnectionString = strconn2
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub connectpgb()
        conn = New SqlConnection
        conn.ConnectionString = strconn3
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub connectmil()
        conn = New SqlConnection
        conn.ConnectionString = strconn4
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub connectcbcd()
        conn = New SqlConnection
        conn.ConnectionString = strconn8
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub connectctac()
        conn = New SqlConnection
        conn.ConnectionString = strconn9
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnectmnl()
        conn = New SqlConnection 'New OleDb.OleDbConnection
        conn.ConnectionString = strconn1
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Public Sub disconnectcal()
        conn = New SqlConnection
        conn.ConnectionString = strconn2
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Public Sub disconnectpgb()
        conn = New SqlConnection
        conn.ConnectionString = strconn3
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Public Sub disconnectmil()
        conn = New SqlConnection
        conn.ConnectionString = strconn4
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Public Sub disconnectcbcd()
        conn = New SqlConnection
        conn.ConnectionString = strconn8
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Public Sub disconnectctac()
        conn = New SqlConnection
        conn.ConnectionString = strconn9
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub tripdashboard_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub vwhse()
        Try
            sql = "Select * from tblwhse where status='1'"
            connectcal()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read

            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim dt As DataTable = vehicletype_dashboard()
        Chart1.DataSource = dt
        Chart1.Series("Series1").XValueMember = "Stat"
        Chart1.Series("Series1").YValueMembers = "No"
        Chart1.DataBind()
    End Sub

    Private Function DummyTable() As DataTable
        Dim dt As New DataTable("Employees")
        dt.Columns.Add("id", Type.GetType("System.Int32"))
        dt.Columns.Add("Salary", Type.GetType("System.Int32"))
        Dim dr As DataRow
        Dim x As Integer
        For x = 1 To 10
            dr = dt.NewRow
            dr("id") = x
            dr("Salary") = 100 * x
            dt.Rows.Add(dr)
        Next
        Return dt
    End Function

    Private Function vehicletype_dashboard() As DataTable
        Dim dt As New DataTable("Create_Order")
        dt.Columns.Add("No", GetType(Integer))
        dt.Columns.Add("Stat", GetType(String))
        Dim drow As DataRow

        sql = "Select Count(transid) as num, status, cancel from tblortrans"
        sql = sql & " where datecreated>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and datecreated<='" & Format(dateto.Value, "yyyy/MM/dd") & "' and whsename='" & login.whse & "'"
        sql = sql & " GROUP BY status, cancel"
        connectmnl()
        cmd = New SqlCommand(sql, conn)
        dr = cmd.ExecuteReader
        While dr.Read
            drow = dt.NewRow
            If dr("status") = 0 Then
                drow("Stat") = "In Process"
            ElseIf dr("status") = 1 Then
                drow("Stat") = "Available"
            ElseIf dr("status") = 2 Then
                drow("Stat") = "Completed"
            End If

            If dr("cancel") = 1 Then
                drow("Stat") = "Cancelled"
            End If

            drow("No") = dr("num")
            dt.Rows.Add(drow)
        End While
        dr.Dispose()
        cmd.Dispose()
        conn.Close()

        Return dt
    End Function
End Class