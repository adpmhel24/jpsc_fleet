﻿Imports System.IO
Imports System.Data.SqlClient

Public Class tripadd
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public addcnf As Boolean = False
    Dim hasrows7 As Boolean = False
    Dim hasrows8 As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub tripadd_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated

    End Sub

    Private Sub tripadd_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim a As String = MsgBox("Are you sure you want to close?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            '/moduless.Show()
            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub tripadd_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        datefrom.CustomFormat = "yyyy/MM/dd"
        dateto.CustomFormat = "yyyy/MM/dd"
        datepick.CustomFormat = "yyyy/MM/dd"

        frmload()
        plate()
        whse()
        driver()
        helper()
        vwhse()
        vcustomer()
        loadtripnum()
        transtype()

        cmbtranstype.Items.Clear()
        btnview.PerformClick()

        '/ CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("AAA")
    End Sub

    Public Sub transtype()
        Try
            cmbvtype.Items.Clear()
            cmbvtype.Items.Add("")

            sql = "Select * from tblortrans where cancel='0' and status='1'"
            If cmbvwhse.SelectedItem <> "" Then
                sql = sql & " and whsename='" & cmbvwhse.SelectedItem & "'"
            End If
            sql = sql & " order by deliverydate"

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If Format(dr("datecreated"), "yyyy/MM/dd") >= Format(datefrom.Value, "yyyy/MM/dd") And Format(dr("datecreated"), "yyyy/MM/dd") <= Format(dateto.Value, "yyyy/MM/dd") Then
                    If Not cmbvtype.Items.Contains(dr("transtype").ToString) Then
                        cmbvtype.Items.Add(dr("transtype").ToString)
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub frmload()
        chkpick.Checked = False

        If login.whse = "Calamba" Then
            chkpick.Visible = True
        Else
            chkpick.Visible = False
        End If

        datefrom.MaxDate = Date.Now
        datepick.MinDate = Date.Now

        For ctr As Integer = 2 To 8
            grdadd.Columns(ctr).ReadOnly = True
        Next
    End Sub

    Public Sub plate()
        Try
            cmbplate.Items.Clear()
            Dim plnum As String = ""
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tblgeneral where status='1'"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                If dr1("platenum") = "" And dr1("vplate") <> "" Then
                    plnum = dr1("vplate")
                ElseIf dr1("platenum") = "" And dr1("vplate") = "" And dr1("csticker") <> "" Then
                    plnum = dr1("csticker")
                Else
                    plnum = dr1("platenum")
                End If

                cmbplate.Items.Add(plnum)
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub driver()
        Try
            cmbdriver.Items.Clear()
            cmbdriver.Items.Add("")
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tbldriver where status='1' order by driver"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbdriver.Items.Add(dr1("driver"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub helper()
        Try
            cmbhelper.Items.Clear()
            cmbhelper.Items.Add("")
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tblhelper where status='1' order by helper"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbhelper.Items.Add(dr1("helper"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub whse()
        Try
            cmbwhse.Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tblwhse where status='1' order by whsename"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbwhse.Items.Add(dr1("whsename"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub vwhse()
        Try
            cmbvwhse.Items.Clear()
            cmbvwhse.Items.Add("")
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tblwhse where (company='J. Poon & Sons' or company='Atlantic Grains') order by whsename"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbvwhse.Items.Add(dr1("whsename"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            If cmbvwhse.Items.Count <> 0 Then
                cmbvwhse.SelectedItem = login.whse
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub vcustomer()
        Try
            cmbvcus.Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")
            Dim dbook As Date = CDate(Format(datefrom.Value, "yyyy/MM/dd"))

            sql = "Select * from tblcustomer order by customer"

            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbvcus.Items.Add(dr1("customer"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            If Trim(lblvtype.Text) = "CUSTOMER TRUCK" Then
                For Each row As DataGridViewRow In grdadd.Rows
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                    If checkCell.Value = True Then
                        If grdadd.Rows(row.Index).Cells(6).Value.ToString.Contains("CUSTOMER") = False Then
                            MsgBox("Invalid selection of transaction or plate number.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If
                    End If
                Next
            ElseIf Trim(lblvtype.Text) = "TRUCKING TRUCK" Then
                For Each row As DataGridViewRow In grdadd.Rows
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                    If checkCell.Value = True Then
                        If grdadd.Rows(row.Index).Cells(6).Value.ToString.Contains("TRUCKING") = False Then
                            MsgBox("Invalid selection of transaction or plate number.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If
                    End If
                Next
            Else
                For Each row As DataGridViewRow In grdadd.Rows
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                    If checkCell.Value = True Then
                        If grdadd.Rows(row.Index).Cells(6).Value.ToString.Contains("CUSTOMER") = True Or grdadd.Rows(row.Index).Cells(6).Value.ToString.Contains("TRUCKING") = True Then
                            MsgBox("Invalid selection of transaction or plate number.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If
                    End If
                Next
            End If

            'check fields
            tripaddconfirm.grd.Rows.Clear()
            tripaddconfirm.txtdatepick.Text = ""
            tripaddconfirm.txtdriver.Text = ""
            tripaddconfirm.txthelper.Text = ""
            tripaddconfirm.txtplate.Text = ""
            tripaddconfirm.txtrems.Text = ""
            tripaddconfirm.txtetd.Text = ""

            'ipakita muna ung lahat ng sinelect or pdeng naka grd din
            tripaddconfirm.txtplate.Text = cmbplate.Text
            tripaddconfirm.txtdriver.Text = cmbdriver.Text
            tripaddconfirm.txthelper.Text = cmbhelper.Text
            tripaddconfirm.txtdatepick.Text = Format(datepick.Value, "yyyy/MM/dd")
            tripaddconfirm.txtorigin.Text = cmbwhse.Text
            tripaddconfirm.txtrems.Text = txtrems.Text
            tripaddconfirm.txtetd.Text = Format(datepick.Value, "yyyy/MM/dd") & " " & txtetd.Text

            'loop lahat ng nkaselect.. then copy to confirmed
            Dim meron As Boolean = False, pup As Boolean = False
            For Each row As DataGridViewRow In grdadd.Rows
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                If checkCell.Value = True Then
                    meron = True
                    tripaddconfirm.grd.Rows.Add(grdadd.Rows(row.Index).Cells(0).Value, grdadd.Rows(row.Index).Cells(2).Value, grdadd.Rows(row.Index).Cells(3).Value, grdadd.Rows(row.Index).Cells(5).Value, grdadd.Rows(row.Index).Cells(6).Value, grdadd.Rows(row.Index).Cells(9).Value)
                    If Trim(lblvtype.Text) = "CUSTOMER TRUCK" Then
                        tripaddconfirm.txtrems.Text = tripaddconfirm.txtrems.Text & ", " & grdadd.Rows(row.Index).Cells(8).Value
                    End If

                    If chkpick.Checked = True Then
                        'check if may pup sa mga nakachecked
                        If grdadd.Rows(row.Index).Cells(6).Value.ToString.Contains("PICKUP") = True Then
                            pup = True
                        End If
                    End If
                End If
            Next

            If (Trim(lblvtype.Text) = "CUSTOMER TRUCK") And Trim(txtrems.Text) = "" Then   'Or Trim(lblvtype.Text) = "TRUCKING TRUCK"
                MsgBox("License # and Driver name.", MsgBoxStyle.Exclamation, "")
                txtrems.Focus()
                Exit Sub
            End If

            If Trim(cmbplate.Text) = "" Or Trim(cmbdriver.Text) = "" Or Trim(cmbwhse.Text) = "" Or meron = False Or Trim(txtetd.Text) = "" Then
                MsgBox("Complete the required fields.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If chkpick.Checked = True And pup = True Then
                tripaddconfirm.chkpick.Checked = True
            Else
                tripaddconfirm.chkpick.Checked = False
            End If

            'then dun plng i-add kung confirmed na
            tripaddconfirm.ShowDialog()
            btnview.PerformClick()
            datepick.Value = Date.Now

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        Try
            grdadd.Rows.Clear()

            chkhide.Checked = True

            Dim ctr As Integer = 0

            sql = "Select * from tblortrans where cancel='0' and status='1'"
            '/If cmbvwhse.SelectedItem <> "" Then
            sql = sql & " and whsename='" & login.whse & "'"
            '/End If
            sql = sql & " order by deliverydate"

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                Dim stat As String = ""
                If dr("status") = 1 Then
                    stat = "Available"
                ElseIf dr("status") = 0 Then
                    stat = "In Process"
                ElseIf dr("status") = 2 Then
                    stat = "Completed"
                End If

                grdadd.Rows.Add(dr("transid"), False, dr("transnum"), dr("refnum"), Format(dr("deliverydate"), "yyyy/MM/dd"), dr("customer"), dr("transtype"), stat, dr("notes"), dr("chktype").ToString)
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(ctr).Cells(1), DataGridViewCheckBoxCell)
                checkCell.Value = False
                ctr += 1
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        Try
            grdadd.Rows.Clear()
            Dim ctr As Integer = 0

            sql = "Select * from tblortrans where cancel='0'"
            If cmbvcus.SelectedItem <> "" Then
                sql = sql & " and customer='" & cmbvcus.SelectedItem & "'"
            End If
            '/If cmbvwhse.SelectedItem <> "" Then
            sql = sql & " and whsename='" & login.whse & "'"
            '/End If
            If cmbvtype.SelectedItem <> "" Then
                sql = sql & " and transtype='" & cmbvtype.SelectedItem & "'"
            End If
            If chkhide.Checked = True Then
                sql = sql & " and status<>'0'"
            End If
            sql = sql & " order by deliverydate"

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If Format(dr("datecreated"), "yyyy/MM/dd") >= Format(datefrom.Value, "yyyy/MM/dd") And Format(dr("datecreated"), "yyyy/MM/dd") <= Format(dateto.Value, "yyyy/MM/dd") Then

                    Dim stat As String = ""
                    If dr("status") = 1 Then
                        stat = "Available"
                    ElseIf dr("status") = 0 Then
                        stat = "In Process"
                    ElseIf dr("status") = 2 Then
                        stat = "Completed"
                    End If

                    grdadd.Rows.Add(dr("transid"), False, dr("transnum"), dr("refnum"), Format(dr("deliverydate"), "yyyy/MM/dd"), dr("customer"), dr("transtype"), stat, dr("notes"))
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(ctr).Cells(1), DataGridViewCheckBoxCell)
                    checkCell.Value = False
                    ctr += 1
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnvcancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnvcancel.Click
        cmbvwhse.Text = ""
        cmbvcus.Text = ""
        cmbvtype.SelectedItem = ""
    End Sub

    Private Sub cmbvwhse_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbvwhse.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbvwhse_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbvwhse.Leave
        If Trim(cmbvwhse.Text) <> "" Then
            sql = "Select * from tblwhse where status='1' and whsename='" & Trim(cmbvwhse.Text) & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbvwhse.SelectedItem = Trim(cmbvwhse.Text)
            Else
                cmbvwhse.Text = ""
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()
        End If
    End Sub

    Private Sub cmbvcus_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbvcus.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbvcus_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbvcus.Leave
        If Trim(cmbvcus.Text) <> "" Then
            sql = "Select * from tblcustomer where status='1' and customer='" & Trim(cmbvcus.Text) & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbvcus.SelectedItem = Trim(cmbvcus.Text)
            Else
                cmbvcus.Text = ""
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()
        End If
    End Sub

    Private Sub cmbplate_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbplate.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbplate_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbplate.Leave
        Try
            getdriver()

            sql = "Select * from tblgeneral where platenum='" & cmbplate.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                lblvtype.Text = dr("vtype")
                lblmake.Text = dr("makename")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            If cmbdriver.Text <> "Customer Driver" And Trim(cmbdriver.Text) <> "" And lblvtype.Text = "CUSTOMER TRUCK" Then
                MsgBox("Invalid driver.", MsgBoxStyle.Exclamation, "")
                cmbdriver.Text = ""
            End If
            If cmbdriver.Text = "Customer Driver" And Trim(cmbplate.Text) <> "" And lblvtype.Text <> "CUSTOMER TRUCK" Then
                MsgBox("Invalid plate number.", MsgBoxStyle.Exclamation, "")
                cmbplate.Text = ""
                Exit Sub
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub getdriver()
        Try
            If Trim(cmbplate.Text) <> "" Then
                If Not cmbplate.Items.Contains(Trim(cmbplate.Text.ToUpper)) Then
                    cmbplate.Text = ""
                    cmbdriver.Text = ""
                Else
                    sql = "Select * from tblgeneral where status='1'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    While dr.Read
                        Dim plnum As String = dr("platenum")

                        If plnum = Trim(cmbplate.Text.ToUpper) Then
                            cmbplate.SelectedItem = plnum
                            If dr("driver").ToString <> "" Then
                                cmbdriver.SelectedItem = dr("driver")
                            End If
                        End If
                    End While
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Else
                cmbdriver.SelectedItem = ""
                cmbplate.Text = ""
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbplate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbplate.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789"
        Dim theText As String = cmbplate.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbplate.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbplate.Text.Length - 1
            Letter = cmbplate.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbplate.Text = theText
        cmbplate.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub cmbdriver_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbdriver.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbwhse_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbwhse.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtrems_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbdriver_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbdriver.Leave
        Try
            If Trim(cmbdriver.Text) <> "" Then

                sql = "Select * from tbldriver where status='1' and driver='" & Trim(cmbdriver.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbdriver.SelectedItem = dr("driver")
                    If cmbdriver.Text = "Customer Driver" And Trim(cmbplate.Text) <> "" And lblvtype.Text <> "CUSTOMER TRUCK" Then
                        MsgBox("Invalid plate number.", MsgBoxStyle.Exclamation, "")
                        cmbplate.Text = ""
                    End If
                    If cmbdriver.Text <> "Customer Driver" And Trim(cmbdriver.Text) <> "" And lblvtype.Text = "CUSTOMER TRUCK" Then
                        MsgBox("Invalid driver.", MsgBoxStyle.Exclamation, "")
                        cmbdriver.Text = ""
                    End If

                    If cmbdriver.Text <> "Trucking Driver" And Trim(cmbdriver.Text) <> "" And lblvtype.Text = "TRUCKING TRUCK" Then
                        '/MsgBox("Invalid driver.", MsgBoxStyle.Exclamation, "")
                        '/ cmbdriver.Text = ""
                    End If
                    If cmbdriver.Text = "Trucking Driver" And Trim(cmbplate.Text) <> "" And lblvtype.Text <> "TRUCKING TRUCK" Then
                        '/ MsgBox("Invalid plate number.", MsgBoxStyle.Exclamation, "")
                        '/cmbplate.Text = ""
                    End If
                Else
                    cmbdriver.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()


                For Each item As Object In list1.Items
                    If item = Trim(cmbdriver.Text) Then
                        MsgBox("Cannot select " & Trim(cmbdriver.Text) & " because he has a pending receipt.", MsgBoxStyle.Exclamation, "")
                        cmbdriver.Text = ""
                        cmbdriver.Focus()
                        Exit Sub
                    End If
                Next

            Else
                cmbdriver.SelectedItem = ""
                cmbdriver.Text = ""
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbwhse_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbwhse.Leave
        Try
            If Trim(cmbwhse.Text) <> "" Then

                sql = "Select * from tblwhse where status='1' and whsename='" & Trim(cmbwhse.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbwhse.SelectedItem = dr("whsename")
                Else
                    cmbwhse.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

            Else
                cmbwhse.SelectedItem = ""
                cmbwhse.Text = ""
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        defaultload()
    End Sub

    Private Sub txtetd_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtetd.KeyPress
        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 Then
            If Asc(e.KeyChar) = 39 Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtetd_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtetd.Leave
        If Trim(txtetd.Text) <> "" Then
            Dim etd As Date
            Dim timeCheck As Boolean
            timeCheck = IsDate(Trim(txtetd.Text))
            If timeCheck = True Then
                'MsgBox(Trim(txtetd.Text) & timeCheck)
                etd = CDate(Trim(txtetd.Text))
                txtetd.Text = Format(etd, "hh:mm tt")

                'check if hindi late sa oras ngayon
                Dim tripdeyt As Date = CDate(Format(datepick.Value, "MM/dd/yyyy") & " " & etd)

                If Date.Now.AddHours(-8) > tripdeyt Then
                    MsgBox("Invalid Date or Time", MsgBoxStyle.Exclamation, "")
                    txtetd.Text = ""
                    txtetd.Focus()
                End If
            Else
                MsgBox("Invalid Time", MsgBoxStyle.Exclamation, "")
                txtetd.Text = ""
                txtetd.Focus()
            End If
        End If
    End Sub

    Private Sub btnexisting_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexisting.Click
        Try
            If Trim(lblvtype.Text) = "CUSTOMER TRUCK" Then
                For Each row As DataGridViewRow In grdadd.Rows
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                    If checkCell.Value = True Then
                        If grdadd.Rows(row.Index).Cells(6).Value.ToString.Contains("CUSTOMER") = False Then
                            MsgBox("Invalid selection of transaction or plate number.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If
                    End If
                Next
            ElseIf Trim(lblvtype.Text) = "TRUCKING TRUCK" Then
                For Each row As DataGridViewRow In grdadd.Rows
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                    If checkCell.Value = True Then
                        If grdadd.Rows(row.Index).Cells(6).Value.ToString.Contains("TRUCKING") = False Then
                            MsgBox("Invalid selection of transaction or plate number.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If
                    End If
                Next
            Else
                For Each row As DataGridViewRow In grdadd.Rows
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                    If checkCell.Value = True Then
                        If grdadd.Rows(row.Index).Cells(6).Value.ToString.Contains("CUSTOMER") = True Or grdadd.Rows(row.Index).Cells(6).Value.ToString.Contains("TRUCKING") = True Then
                            MsgBox("Invalid selection of transaction or plate number.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If
                    End If
                Next
            End If


            'loop lahat ng nkaselect.. then copy to confirmed
            Dim meron As Boolean = False
            For Each row As DataGridViewRow In grdadd.Rows
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                If checkCell.Value = True Then
                    meron = True
                    If Trim(lblvtype.Text) = "CUSTOMER TRUCK" Then
                        tripaddexisting.lbltemp.Text = "CUSTOMER TRUCK"
                        tripaddexisting.lblrems.Text = tripaddexisting.lblrems.Text & ", " & grdadd.Rows(row.Index).Cells(8).Value
                    End If
                    If Trim(lblvtype.Text) = "TRUCKING TRUCK" Then
                        tripaddexisting.lbltemp.Text = "TRUCKING TRUCK"
                    End If
                    tripaddexisting.lblplnum.Text = Trim(cmbplate.Text)
                    tripaddexisting.grd.Rows.Add(grdadd.Rows(row.Index).Cells(0).Value, grdadd.Rows(row.Index).Cells(2).Value, grdadd.Rows(row.Index).Cells(3).Value, grdadd.Rows(row.Index).Cells(5).Value, grdadd.Rows(row.Index).Cells(6).Value, "0", grdadd.Rows(row.Index).Cells(9).Value)
                End If
            Next

            If meron = False Then
                MsgBox("Select transactions.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            'then dun plng i-add kung confirmed na
            tripaddexisting.ShowDialog()

            datepick.Value = Date.Now

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try

    End Sub

    Private Sub btntaxi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntaxi.Click
        Try
            If Trim(lblvtype.Text) = "CUSTOMER TRUCK" Or Trim(lblvtype.Text) = "TRUCKING TRUCK" Then
                MsgBox("Invalid plate number.", MsgBoxStyle.Exclamation, "")
                cmbplate.Text = ""
                cmbdriver.Text = ""
            Else
                If Trim(cmbplate.Text) = "" Or Trim(cmbdriver.Text) = "" Or Trim(cmbwhse.Text) = "" Or Trim(txtetd.Text) = "" Or Trim(txtrems.Text) = "" Then
                    MsgBox("Complete the required fields.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If

                addcnf = False
                If login.whse = "Milaor" Then
                    confirmlogistics.ShowDialog()
                Else
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()
                End If

                If addcnf = True Then
                    'then dun plng i-add kung confirmed na
                    'add as taxi
                    loadtripnum()

                    'check muna kung may trip# na na ganun para di na umulet
                    sql = "Select * from tbltripsum where tripnum='" & lbltripnum.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        Me.Cursor = Cursors.Default
                        MsgBox("System connection error." & vbCrLf & "Please close the system first.", MsgBoxStyle.Critical, "")
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    sql = "Insert into tbltripsum (tripyear, whsename, tripnum, platenum, driver, helper, origin, datepick, etd, remarks, odostart, odoactual, odoend, diswith, diswout, dshould, dieselbeg, dieselactual, podiesel, addpo, postaddpo, dieselend, taxi, loadscale, repair, rescue, datecreated, createdby, datemodified, modifiedby, status) values (Year(GetDate()), '" & login.whse & "', '" & lbltripnum.Text & "', '" & cmbplate.Text & "', '" & cmbdriver.Text & "', '" & Trim(cmbhelper.Text) & "', '" & cmbwhse.Text & "', '" & Format(datepick.Value, "yyyy/MM/dd") & "', '" & CDate(Format(datepick.Value, "yyyy/MM/dd") & " " & txtetd.Text) & "', '" & Trim(txtrems.Text) & "', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '-', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    If lblmake.Text = "Truck" Then
                        sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '0','', '0','', '1','', '1','', '0','', '0','', '1', '', '0', '', '0', '', '', '0', '', '" & login.whse & "')"
                    ElseIf lblmake.Text = "Service" Then
                        sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks, whsename9) values ('" & lbltripnum.Text & "', '0','', '0','', '1','', '1','', '0','', '0','', '1', '', '1', '', '0', '', '', '0', '', '" & login.whse & "')"
                    End If
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully added trip# " & lbltripnum.Text & ".", MsgBoxStyle.Information, "")
                    defaultload()
                    btnview.PerformClick()
                    datepick.Value = Date.Now
                End If
            End If

            datepick.Value = Date.Now

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadtripnum()
        Try
            Dim trnum As String = "1", temp As String = ""
            sql = "Select Top 1 * from tbltripsum order by tripsumid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                '/trnum = Val(dr("tripsumid")) + 1
            End If
            cmd.Dispose()
            dr.Dispose()
            conn.Close()

            'check kung pang ilang LOGSHEET NA SA YEAR NA 2018 na
            sql = "Select Count(tripsumid) from tbltripsum where tripyear=Year(GetDate()) and whsename='" & login.whse & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            trnum = cmd.ExecuteScalar + 1
            cmd.Dispose()
            conn.Close()

            Dim prefix As String = ""
            If login.whse = "C3 Manila" Then
                prefix = "MNL"
            ElseIf login.whse = "Calamba" Then
                prefix = "CAL"
            ElseIf login.whse = "Pagbilao" Then
                prefix = "PGB"
            ElseIf login.whse = "Lucena" Then
                prefix = "LUC"
            ElseIf login.whse = "Milaor" Then
                prefix = "MIL"
            ElseIf login.whse = "Lc Office" Then
                prefix = "LCO"
            ElseIf login.whse = "Cebu" Then
                prefix = "CEB"
            ElseIf login.whse = "Davao" Then
                prefix = "DAV"
            ElseIf login.whse = "Bacolod" Then
                prefix = "BCD"
            ElseIf login.whse = "Tacloban" Then
                prefix = "TAC"
            ElseIf login.whse = "JP-Store" Then
                prefix = "JST"
            End If

            If trnum < 1000000 Then
                For vv As Integer = 1 To 6 - trnum.Length
                    temp += "0"
                Next
                'lbltripnum.Text = Date.Now.Year & "-" & Format(Date.Now, "MM") & Format(Date.Now, "dd") & temp & trnum
            End If

            lbltripnum.Text = "T." & prefix & "-" & Format(Date.Now, "yy") & "-" & temp & trnum

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txthelper_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        
    End Sub

    Public Sub defaultload()
        cmbplate.Text = ""
        cmbdriver.Text = ""
        cmbhelper.Text = ""
        txtrems.Text = ""
        cmbwhse.Text = ""
        txtetd.Text = ""
        cmbtranstype.Items.Clear()
        lblvtype.Text = ""
        lblmake.Text = ""
    End Sub

    Private Sub datefrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datefrom.ValueChanged
        transtype()
    End Sub

    Private Sub dateto_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dateto.ValueChanged
        transtype()
    End Sub

    Private Sub cmbvtype_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles cmbvtype.MouseClick
        Dim senderComboBox = DirectCast(sender, ComboBox)
        Dim width As Integer = senderComboBox.DropDownWidth
        Dim g As Graphics = senderComboBox.CreateGraphics()
        Dim font As Font = senderComboBox.Font

        Dim vertScrollBarWidth As Integer = If((senderComboBox.Items.Count > senderComboBox.MaxDropDownItems), SystemInformation.VerticalScrollBarWidth, 0)

        Dim newWidth As Integer
        For Each s As String In DirectCast(sender, ComboBox).Items
            newWidth = CInt(g.MeasureString(s, font).Width) + vertScrollBarWidth
            If width < newWidth Then
                width = newWidth
            End If
        Next

        senderComboBox.DropDownWidth = width
    End Sub

    Private Sub cmbhelper_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbhelper.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbhelper_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbhelper.Leave
        Try
            If Trim(cmbhelper.Text) <> "" Then

                sql = "Select * from tblhelper where status='1' and helper='" & Trim(cmbhelper.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbhelper.SelectedItem = dr("helper")
                Else
                    'MsgBox("Cannot found helper " & cmbhelper.Text, MsgBoxStyle.Critical, "")
                    'cmbhelper.Text = ""
                    'Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                cmbhelper.Text = StrConv(Trim(cmbhelper.Text), VbStrConv.ProperCase)
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbhelper_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbhelper.SelectedIndexChanged

    End Sub

    Private Sub cmbdriver_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbdriver.SelectedIndexChanged

    End Sub

    Private Sub cmbplate_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbplate.SelectedIndexChanged

    End Sub

    Private Sub cmbvtype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbvtype.SelectedIndexChanged

    End Sub

    Private Sub tripadd_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Exit Sub
        Me.WindowState = FormWindowState.Maximized

        checkdriverpending()
        checkhasrows7()
        If hasrows7 = True Then
            pendingstep7.ShowDialog()
        End If

        checkhasrows8()
        If hasrows8 = True Then
            pendingstep8.ShowDialog()
        End If
    End Sub

    Public Sub checkdriverpending()
        Try
            list1.Items.Clear()

            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbldispatchsum.datestp6, tbldispatchsum.withpending from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step7<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False And IsDBNull(dr("withpending")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) And dr("withpending") = 1 Then
                        Dim meron As Boolean = False
                        For Each item As Object In list1.Items
                            If item = dr("driver") Then
                                meron = True
                            End If
                        Next

                        If meron = False Then
                            list1.Items.Add(dr("driver"))
                        End If
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub checkhasrows7()
        Try
            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step7<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) Then
                        hasrows7 = True
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub checkhasrows8()
        Try
            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step8<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) Then
                        hasrows8 = True
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub txtetd_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtetd.TextChanged

    End Sub

    Private Sub grdadd_CellContentClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdadd.CellContentClick
        Try
            'check kung may chineck nga sa grdadd then ska lng sya pde i enabled

            'checkbox
            If grdadd.CurrentCell.ColumnIndex = 1 Then
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(grdadd.CurrentRow.Index).Cells(1), DataGridViewCheckBoxCell)
                Button1.PerformClick()
                If Trim(cmbplate.Text) <> "" Then

                    If checkCell.Value = True And grdadd.Rows(grdadd.CurrentRow.Index).Cells(7).Value = "In Process" Then
                        MsgBox("Cannot select transaction with in process status.", MsgBoxStyle.Exclamation, "")
                        checkCell.Value = False
                    ElseIf checkCell.Value = True And grdadd.Rows(grdadd.CurrentRow.Index).Cells(7).Value = "Completed" Then
                        MsgBox("Cannot select transaction with completed status.", MsgBoxStyle.Exclamation, "")
                        checkCell.Value = False
                    ElseIf checkCell.Value = True And grdadd.Rows(grdadd.CurrentRow.Index).Cells(7).Value = "Available" Then
                        If Trim(lblvtype.Text) = "CUSTOMER TRUCK" Then
                            If grdadd.Rows(grdadd.CurrentRow.Index).Cells(6).Value = "CUSTOMER SALES TRANSACTION PICKUP FRM AGI CALAMBA" Then
                                cmbwhse.SelectedItem = "Agi Calamba"
                                checkCell.Value = True
                                If Trim(txtrems.Text) = "" Then
                                    txtrems.Text = "-"
                                End If
                            ElseIf grdadd.Rows(grdadd.CurrentRow.Index).Cells(6).Value = "CUSTOMER SALES TRANSACTION PICKUP FRM AGI CALACA" Then
                                cmbwhse.SelectedItem = "Agi Calaca"
                                checkCell.Value = True
                                If Trim(txtrems.Text) = "" Then
                                    txtrems.Text = "-"
                                End If
                            ElseIf grdadd.Rows(grdadd.CurrentRow.Index).Cells(6).Value = "CUSTOMER SALES TRANSACTION WHSE" Then
                                cmbwhse.SelectedItem = login.whse
                                checkCell.Value = True
                                If Trim(txtrems.Text) = "" Then
                                    txtrems.Text = "-"
                                End If
                            Else
                                If grdadd.Rows(grdadd.CurrentRow.Index).Cells(6).Value.ToString.Contains("CUSTOMER") = True Then
                                    checkCell.Value = True
                                    If Trim(txtrems.Text) = "" Then
                                        txtrems.Text = "-"
                                    End If
                                Else
                                    MsgBox("Invalid transaction type for CUSTOMER TRUCK.", MsgBoxStyle.Exclamation, "")
                                    checkCell.Value = False
                                End If
                            End If
                        ElseIf Trim(lblvtype.Text) = "TRUCKING TRUCK" Then
                            If grdadd.Rows(grdadd.CurrentRow.Index).Cells(6).Value.ToString.Contains("TRUCKING") = True Then
                                checkCell.Value = True
                            Else
                                MsgBox("Invalid transaction type for TRUCKING TRUCK.", MsgBoxStyle.Exclamation, "")
                                checkCell.Value = False
                            End If
                        Else
                            If grdadd.Rows(grdadd.CurrentRow.Index).Cells(6).Value.ToString.Contains("TRUCKING") = True Or grdadd.Rows(grdadd.CurrentRow.Index).Cells(6).Value.ToString.Contains("CUSTOMER") = True Then
                                MsgBox("Invalid transaction type for JPSC TRUCK.", MsgBoxStyle.Exclamation, "")
                                checkCell.Value = False
                            Else
                                If grdadd.Rows(grdadd.CurrentRow.Index).Cells(6).Value = "JPSC SALES TRANSACTION PICKUP FRM AGI CALAMBA" Or grdadd.Rows(grdadd.CurrentRow.Index).Cells(6).Value = "JPSC SALES TRANSACTION PICKUP FRM AGI CALACA" Then
                                    cmbwhse.SelectedItem = login.whse
                                End If
                                checkCell.Value = True
                            End If
                        End If
                    End If
                Else
                    MsgBox("Select Plate number first.", MsgBoxStyle.Exclamation, "")
                    checkCell.Value = False
                End If

                'check yung mga transactions if may kasama yung customer direct pickup frm pier
                cmbtranstype.Items.Clear()
                For Each row As DataGridViewRow In grdadd.Rows
                    Dim checkCellx As DataGridViewCheckBoxCell = CType(grdadd.Rows(row.Index).Cells(1), DataGridViewCheckBoxCell)
                    If checkCellx.Value = True And Not cmbtranstype.Items.Contains(grdadd.Rows(row.Index).Cells(6).Value) Then
                        If cmbtranstype.Items.Count > 0 And grdadd.Rows(row.Index).Cells(6).Value = "CUSTOMER SALES TRANSACTION PICKUP FRM PIER" Then
                            'anung warning na nde dapat magkaroon ng kasama si cus pick pier
                        Else
                            cmbtranstype.Items.Add(grdadd.Rows(row.Index).Cells(6).Value)
                        End If
                    End If
                Next
            End If

            'link
            If e.ColumnIndex = 2 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdadd.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdadd.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdadd.RowCount <> 0 Then
                    If grdadd.Item(2, grdadd.CurrentRow.Index).Value IsNot Nothing Then
                        viewtrans.Text = "View Transaction"
                        viewtrans.lbltripnum.Text = ""
                        viewtrans.grouptrans.Visible = False
                        viewtrans.txttrans.Text = grdadd.Item(2, grdadd.CurrentRow.Index).Value
                        viewtrans.sing = True
                        viewtrans.ShowDialog()
                    End If
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub grdadd_CellValueChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdadd.CellValueChanged
        Try
            Exit Sub
            If grdadd.Columns(e.ColumnIndex).HeaderText = "Select" And grdadd.RowCount <> 0 And grdadd.CurrentCell.ColumnIndex = 1 Then
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdadd.Rows(e.RowIndex).Cells(1), DataGridViewCheckBoxCell)
                Button1.PerformClick()
                If checkCell.Value = True Then
                    'MsgBox("true")
                    'update tblitems discontinue status
                    sql = "Update tblitems set discontinued='1' where itemcode='" & grdadd.Rows(grdadd.CurrentRow.Index).Cells(1).Value.ToString & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn) 'New OleDbCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()
                Else
                    'MsgBox("false")
                    sql = "Update tblitems set discontinued='0' where itemcode='" & grdadd.Rows(grdadd.CurrentRow.Index).Cells(1).Value.ToString & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn) 'New OleDbCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()
                End If
                grdadd.Invalidate()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class