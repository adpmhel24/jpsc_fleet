﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class tripreport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(tripreport))
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.t_chk3 = New System.Windows.Forms.CheckBox
        Me.t_chk1 = New System.Windows.Forms.CheckBox
        Me.t_chk2 = New System.Windows.Forms.CheckBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.cmborigin = New System.Windows.Forms.ComboBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.cmbhelper = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.cmbtype = New System.Windows.Forms.ComboBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.cmbdriver = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.dateto = New System.Windows.Forms.DateTimePicker
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.cmbplate = New System.Windows.Forms.ComboBox
        Me.datefrom = New System.Windows.Forms.DateTimePicker
        Me.Label9 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.o_chk5 = New System.Windows.Forms.CheckBox
        Me.o_chk4 = New System.Windows.Forms.CheckBox
        Me.o_chk0 = New System.Windows.Forms.CheckBox
        Me.o_chk1 = New System.Windows.Forms.CheckBox
        Me.o_chk2 = New System.Windows.Forms.CheckBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.cmbpick = New System.Windows.Forms.ComboBox
        Me.cmbtranstype = New System.Windows.Forms.ComboBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.cmbrec = New System.Windows.Forms.ComboBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.btncancel = New System.Windows.Forms.Button
        Me.btnok = New System.Windows.Forms.Button
        Me.grdrep = New System.Windows.Forms.DataGridView
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar
        Me.lblloading = New System.Windows.Forms.Label
        Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column1 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column23 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column24 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column25 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column26 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column27 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column28 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column29 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column22 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column20 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column21 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Label13 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.grdrep, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.t_chk3)
        Me.GroupBox1.Controls.Add(Me.t_chk1)
        Me.GroupBox1.Controls.Add(Me.t_chk2)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.cmborigin)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.cmbhelper)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.cmbtype)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.cmbdriver)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.dateto)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.cmbplate)
        Me.GroupBox1.Controls.Add(Me.datefrom)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(448, 339)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Trip Information"
        '
        't_chk3
        '
        Me.t_chk3.AutoSize = True
        Me.t_chk3.Location = New System.Drawing.Point(142, 286)
        Me.t_chk3.Name = "t_chk3"
        Me.t_chk3.Size = New System.Drawing.Size(73, 17)
        Me.t_chk3.TabIndex = 56
        Me.t_chk3.Tag = "3"
        Me.t_chk3.Text = "Cancelled"
        Me.t_chk3.UseVisualStyleBackColor = True
        '
        't_chk1
        '
        Me.t_chk1.AutoSize = True
        Me.t_chk1.Location = New System.Drawing.Point(142, 263)
        Me.t_chk1.Name = "t_chk1"
        Me.t_chk1.Size = New System.Drawing.Size(76, 17)
        Me.t_chk1.TabIndex = 55
        Me.t_chk1.Tag = "1"
        Me.t_chk1.Text = "In Process"
        Me.t_chk1.UseVisualStyleBackColor = True
        '
        't_chk2
        '
        Me.t_chk2.AutoSize = True
        Me.t_chk2.Location = New System.Drawing.Point(142, 240)
        Me.t_chk2.Name = "t_chk2"
        Me.t_chk2.Size = New System.Drawing.Size(76, 17)
        Me.t_chk2.TabIndex = 54
        Me.t_chk2.Tag = "2"
        Me.t_chk2.Text = "Completed"
        Me.t_chk2.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label15.Location = New System.Drawing.Point(66, 240)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(69, 15)
        Me.Label15.TabIndex = 53
        Me.Label15.Text = "Trip Status:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label8.Location = New System.Drawing.Point(39, 339)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 15)
        Me.Label8.TabIndex = 45
        '
        'cmborigin
        '
        Me.cmborigin.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmborigin.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmborigin.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmborigin.FormattingEnabled = True
        Me.cmborigin.Location = New System.Drawing.Point(142, 208)
        Me.cmborigin.Name = "cmborigin"
        Me.cmborigin.Size = New System.Drawing.Size(279, 23)
        Me.cmborigin.TabIndex = 38
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label4.Location = New System.Drawing.Point(93, 211)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 15)
        Me.Label4.TabIndex = 37
        Me.Label4.Text = "Origin:"
        '
        'cmbhelper
        '
        Me.cmbhelper.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbhelper.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbhelper.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbhelper.FormattingEnabled = True
        Me.cmbhelper.Location = New System.Drawing.Point(142, 176)
        Me.cmbhelper.Name = "cmbhelper"
        Me.cmbhelper.Size = New System.Drawing.Size(279, 23)
        Me.cmbhelper.TabIndex = 36
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label3.Location = New System.Drawing.Point(89, 179)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 15)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "Helper:"
        '
        'cmbtype
        '
        Me.cmbtype.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbtype.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbtype.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbtype.FormattingEnabled = True
        Me.cmbtype.Location = New System.Drawing.Point(142, 112)
        Me.cmbtype.Name = "cmbtype"
        Me.cmbtype.Size = New System.Drawing.Size(202, 23)
        Me.cmbtype.TabIndex = 32
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label7.Location = New System.Drawing.Point(68, 115)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 15)
        Me.Label7.TabIndex = 34
        Me.Label7.Text = "Truck Type:"
        '
        'cmbdriver
        '
        Me.cmbdriver.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbdriver.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbdriver.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbdriver.FormattingEnabled = True
        Me.cmbdriver.Location = New System.Drawing.Point(142, 144)
        Me.cmbdriver.Name = "cmbdriver"
        Me.cmbdriver.Size = New System.Drawing.Size(279, 23)
        Me.cmbdriver.TabIndex = 33
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label6.Location = New System.Drawing.Point(94, 147)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(42, 15)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "Driver:"
        '
        'dateto
        '
        Me.dateto.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.dateto.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dateto.Location = New System.Drawing.Point(142, 49)
        Me.dateto.Name = "dateto"
        Me.dateto.Size = New System.Drawing.Size(119, 21)
        Me.dateto.TabIndex = 23
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(113, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(23, 15)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "To:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(43, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 15)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "Trip Date From:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label5.Location = New System.Drawing.Point(79, 83)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 15)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Plate No:"
        '
        'cmbplate
        '
        Me.cmbplate.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbplate.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbplate.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbplate.FormattingEnabled = True
        Me.cmbplate.Location = New System.Drawing.Point(142, 80)
        Me.cmbplate.Name = "cmbplate"
        Me.cmbplate.Size = New System.Drawing.Size(202, 23)
        Me.cmbplate.Sorted = True
        Me.cmbplate.TabIndex = 24
        '
        'datefrom
        '
        Me.datefrom.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.datefrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datefrom.Location = New System.Drawing.Point(142, 22)
        Me.datefrom.Name = "datefrom"
        Me.datefrom.Size = New System.Drawing.Size(119, 21)
        Me.datefrom.TabIndex = 22
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label9.Location = New System.Drawing.Point(57, 124)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 15)
        Me.Label9.TabIndex = 41
        Me.Label9.Text = "Order Status:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.o_chk5)
        Me.GroupBox2.Controls.Add(Me.o_chk4)
        Me.GroupBox2.Controls.Add(Me.o_chk0)
        Me.GroupBox2.Controls.Add(Me.o_chk1)
        Me.GroupBox2.Controls.Add(Me.o_chk2)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.cmbpick)
        Me.GroupBox2.Controls.Add(Me.cmbtranstype)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.cmbrec)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 348)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(448, 219)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Order Transaction Information"
        '
        'o_chk5
        '
        Me.o_chk5.AutoSize = True
        Me.o_chk5.Location = New System.Drawing.Point(236, 147)
        Me.o_chk5.Name = "o_chk5"
        Me.o_chk5.Size = New System.Drawing.Size(121, 17)
        Me.o_chk5.TabIndex = 52
        Me.o_chk5.Tag = "5"
        Me.o_chk5.Text = "For AR Credit Memo"
        Me.o_chk5.UseVisualStyleBackColor = True
        '
        'o_chk4
        '
        Me.o_chk4.AutoSize = True
        Me.o_chk4.Location = New System.Drawing.Point(236, 124)
        Me.o_chk4.Name = "o_chk4"
        Me.o_chk4.Size = New System.Drawing.Size(89, 17)
        Me.o_chk4.TabIndex = 51
        Me.o_chk4.Tag = "4"
        Me.o_chk4.Text = "Rescheduled"
        Me.o_chk4.UseVisualStyleBackColor = True
        '
        'o_chk0
        '
        Me.o_chk0.AutoSize = True
        Me.o_chk0.Location = New System.Drawing.Point(141, 170)
        Me.o_chk0.Name = "o_chk0"
        Me.o_chk0.Size = New System.Drawing.Size(73, 17)
        Me.o_chk0.TabIndex = 50
        Me.o_chk0.Tag = "0"
        Me.o_chk0.Text = "Cancelled"
        Me.o_chk0.UseVisualStyleBackColor = True
        Me.o_chk0.Visible = False
        '
        'o_chk1
        '
        Me.o_chk1.AutoSize = True
        Me.o_chk1.Location = New System.Drawing.Point(141, 147)
        Me.o_chk1.Name = "o_chk1"
        Me.o_chk1.Size = New System.Drawing.Size(76, 17)
        Me.o_chk1.TabIndex = 49
        Me.o_chk1.Tag = "1"
        Me.o_chk1.Text = "In Process"
        Me.o_chk1.UseVisualStyleBackColor = True
        '
        'o_chk2
        '
        Me.o_chk2.AutoSize = True
        Me.o_chk2.Location = New System.Drawing.Point(141, 124)
        Me.o_chk2.Name = "o_chk2"
        Me.o_chk2.Size = New System.Drawing.Size(76, 17)
        Me.o_chk2.TabIndex = 48
        Me.o_chk2.Tag = "2"
        Me.o_chk2.Text = "Completed"
        Me.o_chk2.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label12.Location = New System.Drawing.Point(60, 93)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(75, 15)
        Me.Label12.TabIndex = 43
        Me.Label12.Text = "Pickup from:"
        '
        'cmbpick
        '
        Me.cmbpick.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbpick.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbpick.Enabled = False
        Me.cmbpick.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbpick.FormattingEnabled = True
        Me.cmbpick.Location = New System.Drawing.Point(141, 90)
        Me.cmbpick.Name = "cmbpick"
        Me.cmbpick.Size = New System.Drawing.Size(281, 23)
        Me.cmbpick.TabIndex = 47
        '
        'cmbtranstype
        '
        Me.cmbtranstype.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbtranstype.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbtranstype.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbtranstype.FormattingEnabled = True
        Me.cmbtranstype.Items.AddRange(New Object() {"", "JPSC STOCK TRANSFER PICKUP", "JPSC STOCK TRANSFER WHSE TO WHSE", "JPSC SALES TRANSACTION", "JPSC SALES TRANSACTION PICKUP", "CUSTOMER SALES TRANSACTION WHSE", "CUSTOMER SALES TRANSACTION PICKUP", "TRUCKING STOCK TRANSFER PICKUP", "TRUCKING SALES TRANSACTION WHSE", "TRUCKING SALES TRANSACTION PICKUP"})
        Me.cmbtranstype.Location = New System.Drawing.Point(141, 58)
        Me.cmbtranstype.Name = "cmbtranstype"
        Me.cmbtranstype.Size = New System.Drawing.Size(281, 23)
        Me.cmbtranstype.TabIndex = 46
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label10.Location = New System.Drawing.Point(32, 61)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(103, 15)
        Me.Label10.TabIndex = 45
        Me.Label10.Text = "Transaction Type:"
        '
        'cmbrec
        '
        Me.cmbrec.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbrec.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbrec.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbrec.FormattingEnabled = True
        Me.cmbrec.Location = New System.Drawing.Point(141, 26)
        Me.cmbrec.Name = "cmbrec"
        Me.cmbrec.Size = New System.Drawing.Size(281, 23)
        Me.cmbrec.TabIndex = 44
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label11.Location = New System.Drawing.Point(73, 29)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(62, 15)
        Me.Label11.TabIndex = 43
        Me.Label11.Text = "Recipient:"
        '
        'btncancel
        '
        Me.btncancel.BackColor = System.Drawing.Color.Gainsboro
        Me.btncancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.Image = CType(resources.GetObject("btncancel.Image"), System.Drawing.Image)
        Me.btncancel.Location = New System.Drawing.Point(346, 573)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(90, 32)
        Me.btncancel.TabIndex = 9
        Me.btncancel.Text = "Cancel"
        Me.btncancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancel.UseVisualStyleBackColor = False
        '
        'btnok
        '
        Me.btnok.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnok.Image = CType(resources.GetObject("btnok.Image"), System.Drawing.Image)
        Me.btnok.Location = New System.Drawing.Point(250, 573)
        Me.btnok.Name = "btnok"
        Me.btnok.Size = New System.Drawing.Size(90, 32)
        Me.btnok.TabIndex = 49
        Me.btnok.Text = "Ok"
        Me.btnok.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnok.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnok.UseVisualStyleBackColor = True
        '
        'grdrep
        '
        Me.grdrep.AllowUserToAddRows = False
        Me.grdrep.AllowUserToDeleteRows = False
        Me.grdrep.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grdrep.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdrep.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.grdrep.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdrep.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column18, Me.Column1, Me.Column14, Me.Column15, Me.Column2, Me.Column16, Me.Column23, Me.Column24, Me.Column25, Me.Column26, Me.Column27, Me.Column28, Me.Column17, Me.Column3, Me.Column29, Me.Column13, Me.Column22, Me.Column4, Me.Column5, Me.Column12, Me.Column6, Me.Column7, Me.Column8, Me.Column9, Me.Column10, Me.Column20, Me.Column21, Me.Column11, Me.Column19})
        Me.grdrep.Location = New System.Drawing.Point(457, 3)
        Me.grdrep.Name = "grdrep"
        Me.grdrep.ReadOnly = True
        Me.grdrep.RowHeadersWidth = 10
        Me.grdrep.Size = New System.Drawing.Size(1240, 517)
        Me.grdrep.TabIndex = 50
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.AutoScroll = True
        Me.Panel1.Controls.Add(Me.ProgressBar1)
        Me.Panel1.Controls.Add(Me.lblloading)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Controls.Add(Me.GroupBox2)
        Me.Panel1.Controls.Add(Me.btnok)
        Me.Panel1.Controls.Add(Me.grdrep)
        Me.Panel1.Controls.Add(Me.btncancel)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1270, 637)
        Me.Panel1.TabIndex = 52
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProgressBar1.Location = New System.Drawing.Point(457, 521)
        Me.ProgressBar1.MarqueeAnimationSpeed = 50
        Me.ProgressBar1.Maximum = 10
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(1240, 23)
        Me.ProgressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee
        Me.ProgressBar1.TabIndex = 98
        Me.ProgressBar1.Visible = False
        '
        'lblloading
        '
        Me.lblloading.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblloading.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblloading.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblloading.Location = New System.Drawing.Point(459, 39)
        Me.lblloading.Name = "lblloading"
        Me.lblloading.Size = New System.Drawing.Size(1240, 476)
        Me.lblloading.TabIndex = 99
        Me.lblloading.Text = "Loading..."
        Me.lblloading.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblloading.Visible = False
        '
        'Column18
        '
        Me.Column18.HeaderText = "Trip Date"
        Me.Column18.Name = "Column18"
        Me.Column18.ReadOnly = True
        Me.Column18.Width = 80
        '
        'Column1
        '
        Me.Column1.HeaderText = "Tripnum"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'Column14
        '
        Me.Column14.HeaderText = "Plate #"
        Me.Column14.Name = "Column14"
        Me.Column14.ReadOnly = True
        '
        'Column15
        '
        Me.Column15.HeaderText = "Truck Type"
        Me.Column15.Name = "Column15"
        Me.Column15.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.HeaderText = "Driver"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'Column16
        '
        Me.Column16.HeaderText = "Helper"
        Me.Column16.Name = "Column16"
        Me.Column16.ReadOnly = True
        '
        'Column23
        '
        Me.Column23.HeaderText = "Origin"
        Me.Column23.Name = "Column23"
        Me.Column23.ReadOnly = True
        '
        'Column24
        '
        Me.Column24.HeaderText = "Odometer Beginning"
        Me.Column24.Name = "Column24"
        Me.Column24.ReadOnly = True
        '
        'Column25
        '
        Me.Column25.HeaderText = "Odometer Ending"
        Me.Column25.Name = "Column25"
        Me.Column25.ReadOnly = True
        '
        'Column26
        '
        Me.Column26.HeaderText = "Diesel Beginning"
        Me.Column26.Name = "Column26"
        Me.Column26.ReadOnly = True
        '
        'Column27
        '
        Me.Column27.HeaderText = "Total Diesel PO"
        Me.Column27.Name = "Column27"
        Me.Column27.ReadOnly = True
        '
        'Column28
        '
        Me.Column28.HeaderText = "Diesel Ending"
        Me.Column28.Name = "Column28"
        Me.Column28.ReadOnly = True
        '
        'Column17
        '
        Me.Column17.HeaderText = "Transaction #"
        Me.Column17.Name = "Column17"
        Me.Column17.ReadOnly = True
        Me.Column17.Width = 120
        '
        'Column3
        '
        Me.Column3.HeaderText = "Destination"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 150
        '
        'Column29
        '
        Me.Column29.HeaderText = "Odometer"
        Me.Column29.Name = "Column29"
        Me.Column29.ReadOnly = True
        '
        'Column13
        '
        Me.Column13.HeaderText = "Transaction Type"
        Me.Column13.Name = "Column13"
        Me.Column13.ReadOnly = True
        Me.Column13.Width = 200
        '
        'Column22
        '
        Me.Column22.HeaderText = "Total Qty"
        Me.Column22.Name = "Column22"
        Me.Column22.ReadOnly = True
        '
        'Column4
        '
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column4.DefaultCellStyle = DataGridViewCellStyle12
        Me.Column4.HeaderText = "SO"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'Column5
        '
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column5.DefaultCellStyle = DataGridViewCellStyle13
        Me.Column5.HeaderText = "PO"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        '
        'Column12
        '
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column12.DefaultCellStyle = DataGridViewCellStyle14
        Me.Column12.HeaderText = "SWS"
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        '
        'Column6
        '
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column6.DefaultCellStyle = DataGridViewCellStyle15
        Me.Column6.HeaderText = "AR"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'Column7
        '
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column7.DefaultCellStyle = DataGridViewCellStyle16
        Me.Column7.HeaderText = "RDR"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        '
        'Column8
        '
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column8.DefaultCellStyle = DataGridViewCellStyle17
        Me.Column8.HeaderText = "DR"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'Column9
        '
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column9.DefaultCellStyle = DataGridViewCellStyle18
        Me.Column9.HeaderText = "DN"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        '
        'Column10
        '
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column10.DefaultCellStyle = DataGridViewCellStyle19
        Me.Column10.HeaderText = "ITR"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        '
        'Column20
        '
        Me.Column20.HeaderText = "IT"
        Me.Column20.Name = "Column20"
        Me.Column20.ReadOnly = True
        '
        'Column21
        '
        Me.Column21.HeaderText = "GRPO"
        Me.Column21.Name = "Column21"
        Me.Column21.ReadOnly = True
        '
        'Column11
        '
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column11.DefaultCellStyle = DataGridViewCellStyle20
        Me.Column11.HeaderText = "Status"
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        '
        'Column19
        '
        Me.Column19.HeaderText = "Note"
        Me.Column19.Name = "Column19"
        Me.Column19.ReadOnly = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(321, 36)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(45, 13)
        Me.Label13.TabIndex = 57
        Me.Label13.Text = "Label13"
        Me.Label13.Visible = False
        '
        'tripreport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1294, 653)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "tripreport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Trip Report"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.grdrep, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dateto As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cmbplate As System.Windows.Forms.ComboBox
    Friend WithEvents datefrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents cmbtype As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cmbdriver As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cmbhelper As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cmborigin As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbtranstype As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cmbrec As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btnok As System.Windows.Forms.Button
    Friend WithEvents grdrep As System.Windows.Forms.DataGridView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents cmbpick As System.Windows.Forms.ComboBox
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents lblloading As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents o_chk5 As System.Windows.Forms.CheckBox
    Friend WithEvents o_chk4 As System.Windows.Forms.CheckBox
    Friend WithEvents o_chk0 As System.Windows.Forms.CheckBox
    Friend WithEvents o_chk1 As System.Windows.Forms.CheckBox
    Friend WithEvents o_chk2 As System.Windows.Forms.CheckBox
    Friend WithEvents t_chk3 As System.Windows.Forms.CheckBox
    Friend WithEvents t_chk1 As System.Windows.Forms.CheckBox
    Friend WithEvents t_chk2 As System.Windows.Forms.CheckBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Column18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents Column14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column24 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column25 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column26 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column27 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column28 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column29 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label13 As System.Windows.Forms.Label
End Class
