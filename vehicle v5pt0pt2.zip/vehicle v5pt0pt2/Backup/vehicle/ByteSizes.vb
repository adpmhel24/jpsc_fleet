Module ByteSizes
    Private Const ONE_KB As Double = 1024
    Private Const ONE_MB As Double = ONE_KB * 1024
    Private Const ONE_GB As Double = ONE_MB * 1024
    Private Const ONE_TB As Double = ONE_GB * 1024
    Private Const ONE_PB As Double = ONE_TB * 1024
    Private Const ONE_EB As Double = ONE_PB * 1024
    Private Const ONE_ZB As Double = ONE_EB * 1024
    Private Const ONE_YB As Double = ONE_ZB * 1024

    ' Return a formatted string representing
    ' the number of bytes.
    Public Function FormatBytes(ByVal num_bytes As Double) As String
        ' See how big the value is.
        If num_bytes <= 1023 Then
            ' Format in bytes.
            Return Format$(num_bytes, "0") & " bytes"
        ElseIf num_bytes <= ONE_KB * 1023 Then
            ' Format in KB.
            Return ThreeNonZeroDigits(num_bytes / ONE_KB) & " " & "KB"
        ElseIf num_bytes <= ONE_MB * 1023 Then
            ' Format in MB.
            Return ThreeNonZeroDigits(num_bytes / ONE_MB) & " " & "MB"
        ElseIf num_bytes <= ONE_GB * 1023 Then
            ' Format in GB.
            Return ThreeNonZeroDigits(num_bytes / ONE_GB) & " " & "GB"
        ElseIf num_bytes <= ONE_TB * 1023 Then
            ' Format in TB.
            Return ThreeNonZeroDigits(num_bytes / ONE_TB) & " " & "TB"
        ElseIf num_bytes <= ONE_PB * 1023 Then
            ' Format in PB.
            Return ThreeNonZeroDigits(num_bytes / ONE_PB) & " " & "PB"
        ElseIf num_bytes <= ONE_EB * 1023 Then
            ' Format in EB.
            Return ThreeNonZeroDigits(num_bytes / ONE_EB) & " " & "EB"
        ElseIf num_bytes <= ONE_ZB * 1023 Then
            ' Format in ZB.
            Return ThreeNonZeroDigits(num_bytes / ONE_ZB) & " " & "ZB"
        Else
            ' Format in YB.
            Return ThreeNonZeroDigits(num_bytes / ONE_YB) & " " & "YB"
        End If
    End Function

    ' Return the value formatted to include at most three
    ' non-zero digits and at most two digits after the
    ' decimal point. Examples:
    '         1
    '       123
    '        12.3
    '         1.23
    '         0.12
    Private Function ThreeNonZeroDigits(ByVal value As Double) As String
        If value >= 100 Then
            ' No digits after the decimal.
            Return Format$(CInt(value))
        ElseIf value >= 10 Then
            ' One digit after the decimal.
            Return Format$(value, "0.0")
        Else
            ' Two digits after the decimal.
            Return Format$(value, "0.00")
        End If
    End Function

    ' Convert a formatted string such as "1.34 MB" into bytes.
    Public Function FormattedBytesToBytes(ByVal txt As String) As Double
        Dim base_value As Double = Val(txt)
        Dim ending As String = txt.Trim(New Char() {"0"c, "1"c, "2"c, "3"c, "4"c, "5"c, "6"c, "7"c, "8"c, "9"c, "."c, " "c})
        ending = ending.Trim().ToLower()

        Select Case ending
            Case "bytes", "byte", "b"
                Return base_value
            Case "kb"
                Return base_value * ONE_KB
            Case "mb"
                Return base_value * ONE_MB
            Case "gb"
                Return base_value * ONE_GB
            Case "tb"
                Return base_value * ONE_TB
            Case "pb"
                Return base_value * ONE_PB
            Case "eb"
                Return base_value * ONE_EB
            Case "zb"
                Return base_value * ONE_ZB
            Case "yb"
                Return base_value * ONE_YB
            Case Else
                Throw New ArgumentException("Invalid size " & txt)
        End Select
    End Function
End Module
