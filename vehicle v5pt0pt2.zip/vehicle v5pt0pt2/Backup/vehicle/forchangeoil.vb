﻿Imports System.IO
Imports System.Data.SqlClient

Public Class forchangeoil
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub forchangeoil_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        
    End Sub

    Private Sub forchangeoil_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        view()

        Dim dtServerDateTime As DateTime

        connect()
        cmd = New SqlCommand("Select GetDate()", conn)
        dtServerDateTime = cmd.ExecuteScalar

        Label1.Text = "As of " & dtServerDateTime.ToString
    End Sub

    Public Sub view()
        Try
            Me.Cursor = Cursors.WaitCursor
            grdtemp.Rows.Clear()

            sql = "Select tblgeneral.genid, tblgeneral.platenum, tblpmssched.datelast, tblpmssched.lastodo, tblpmssched.miles, tblpmssched.nextodo, tblpmssched.remarks, tblpmssched.pmschid"
            sql = sql & " from tblpmssched right outer join tblgeneral on tblpmssched.genid=tblgeneral.genid"
            sql = sql & " where tblpmssched.status=1 and tblgeneral.status=1 order by tblgeneral.platenum"

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grdtemp.Rows.Add(dr("genid"), dr("platenum"), Format(dr("datelast"), "yyyy/MM/dd"), dr("lastodo"), dr("miles"), dr("nextodo"), 0, dr("remarks").ToString, "", dr("pmschid"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            For Each row As DataGridViewRow In grdtemp.Rows
                Dim pmsschedid As Integer = Val(grdtemp.Rows(row.Index).Cells(9).Value)
                Dim plate As String = grdtemp.Rows(row.Index).Cells(1).Value

                sql = "Select Top 1 odoend from tbltripsum where platenum='" & plate & "' and (status='1' or status='2') and odoend<>'0' order by tripsumid DESC"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    grdtemp.Rows(row.Index).Cells(6).Value = dr("odoend")
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                Dim endingodo As Integer = Val(grdtemp.Rows(row.Index).Cells(6).Value)
                Dim nextodo As Integer = Val(grdtemp.Rows(row.Index).Cells(5).Value)
                Dim stat As String = ""

                If endingodo = nextodo Then
                    stat = "Due Today"
                ElseIf endingodo >= nextodo - 500 And endingodo <= nextodo - 1 Then
                    stat = "Due Soon"
                ElseIf endingodo > nextodo Then
                    stat = "Over Due"
                Else
                    stat = "Updated"
                End If

                grdtemp.Rows(row.Index).Cells(8).Value = stat
            Next

            grdpms.Rows.Clear()
            For Each row As DataGridViewRow In grdtemp.Rows
                Dim col0 As Integer = Val(grdtemp.Rows(row.Index).Cells(0).Value)
                Dim col1 As String = grdtemp.Rows(row.Index).Cells(1).Value
                Dim col2 As String = grdtemp.Rows(row.Index).Cells(2).Value
                Dim col3 As Integer = Val(grdtemp.Rows(row.Index).Cells(3).Value)
                Dim col4 As Integer = Val(grdtemp.Rows(row.Index).Cells(4).Value)
                Dim col5 As Integer = Val(grdtemp.Rows(row.Index).Cells(5).Value)
                Dim col6 As Integer = Val(grdtemp.Rows(row.Index).Cells(6).Value)
                Dim col7 As String = grdtemp.Rows(row.Index).Cells(7).Value
                Dim col8 As String = grdtemp.Rows(row.Index).Cells(8).Value
                Dim col9 As Integer = Val(grdtemp.Rows(row.Index).Cells(9).Value)

                If col8 = "Due Today" Or col8 = "Due Soon" Or col8 = "Over Due" Then
                    grdpms.Rows.Add(col0, col1, col2, col3, col4, col5, col6, col7, col8, col9)
                End If
            Next

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub updatetblpmssched()
        Try
            Me.Cursor = Cursors.WaitCursor
            grdtemp.Rows.Clear()

            sql = "Select tblgeneral.genid, tblgeneral.platenum, tblpmssched.datelast, tblpmssched.lastodo, tblpmssched.miles, tblpmssched.nextodo, tblpmssched.remarks, tblpmssched.pmschid"
            sql = sql & " from tblpmssched right outer join tblgeneral on tblpmssched.genid=tblgeneral.genid"
            sql = sql & " where tblpmssched.status=1 and tblgeneral.status=1 order by tblgeneral.platenum"

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grdtemp.Rows.Add(dr("genid"), dr("platenum"), Format(dr("datelast"), "yyyy/MM/dd"), dr("lastodo"), dr("miles"), dr("nextodo"), 0, dr("remarks").ToString, "", dr("pmschid"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            For Each row As DataGridViewRow In grdtemp.Rows
                Dim pmsschedid As Integer = Val(grdtemp.Rows(row.Index).Cells(9).Value)
                Dim plate As String = grdtemp.Rows(row.Index).Cells(1).Value

                sql = "Select Top 1 odoend from tbltripsum where platenum='" & plate & "' and (status='1' or status='2') and odoend<>'0' order by tripsumid DESC"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    grdtemp.Rows(row.Index).Cells(6).Value = dr("odoend")
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                Dim endingodo As Integer = Val(grdtemp.Rows(row.Index).Cells(6).Value)
                Dim nextodo As Integer = Val(grdtemp.Rows(row.Index).Cells(5).Value)
                Dim stat As String = ""

                If endingodo = nextodo Then
                    stat = "Due Today"
                ElseIf endingodo >= nextodo - 500 And endingodo <= nextodo - 1 Then
                    stat = "Due Soon"
                ElseIf endingodo > nextodo Then
                    stat = "Over Due"
                Else
                    stat = "Updated"
                End If

                grdtemp.Rows(row.Index).Cells(8).Value = stat

                sql = "Update tblpmssched set endodo='" & endingodo & "', statusexp='" & stat & "', datemodified=Getdate(), modifiedby='" & login.cashier & "' where pmschid='" & pmsschedid & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()
            Next

            grdpms.Rows.Clear()
            For Each row As DataGridViewRow In grdtemp.Rows
                Dim col0 As Integer = Val(grdtemp.Rows(row.Index).Cells(0).Value)
                Dim col1 As String = grdtemp.Rows(row.Index).Cells(1).Value
                Dim col2 As String = grdtemp.Rows(row.Index).Cells(2).Value
                Dim col3 As Integer = Val(grdtemp.Rows(row.Index).Cells(3).Value)
                Dim col4 As Integer = Val(grdtemp.Rows(row.Index).Cells(4).Value)
                Dim col5 As Integer = Val(grdtemp.Rows(row.Index).Cells(5).Value)
                Dim col6 As Integer = Val(grdtemp.Rows(row.Index).Cells(6).Value)
                Dim col7 As String = grdtemp.Rows(row.Index).Cells(7).Value
                Dim col8 As String = grdtemp.Rows(row.Index).Cells(8).Value
                Dim col9 As Integer = Val(grdtemp.Rows(row.Index).Cells(9).Value)

                If col8 = "Due Today" Or col8 = "Due Soon" Or col8 = "Over Due" Then
                    grdpms.Rows.Add(col0, col1, col2, col3, col4, col5, col6, col7, col8, col9)
                End If
            Next

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class