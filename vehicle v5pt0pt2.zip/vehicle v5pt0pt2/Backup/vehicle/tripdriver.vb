﻿Imports System.iio
Imports System.Data.SqlClient
Imports System.Drawing

Public Class tripdriver
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand
    Public fromform As String


    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try
            If Trim(cmbdriver.Text) = "" Then
                MsgBox("No driver.", MsgBoxStyle.Information, "")
            End If

            Dim a As String = MsgBox("Are you sure you want to save updated driver.", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
            If a = vbYes Then
                'save
                sql = "Update tbltripsum set driver='" & Trim(cmbdriver.Text) & "' where tripnum='" & lbltripnum.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                If fromform = "tripdispatchsum" Then
                    sql = "Insert tbltripds (tripnum, dsprev, dsnew, datecreated, createdby, status) values ('" & lbltripnum.Text & "', '" & tripdispatchsum.grddispatch.Rows(tripdispatchsum.grddispatch.CurrentRow.Index).Cells(5).Value.ToString & "', '" & Trim(cmbdriver.Text) & "', GetDate(), '" & login.cashier & "', '1')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()
                End If

                MsgBox("Sucessfully Saved.", MsgBoxStyle.Information, "")
                Me.Close()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        If Trim(cmbdriver.Text) = "" Then
            MsgBox("Cancel change driver.", MsgBoxStyle.Information, "")
        End If
        Me.Close()

    End Sub

    Private Sub triprems_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cmbdriver.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbdriver.DropDownStyle = ComboBoxStyle.DropDown
        cmbdriver.AutoCompleteSource = AutoCompleteSource.ListItems

        If Trim(lblplate.Text) = "CUSTOMER TRUCK" Then
            cmbdriver.Enabled = False
        Else
            cmbdriver.Enabled = True
        End If
    End Sub

    Private Sub cmbdriver_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbdriver.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbdriver_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbdriver.Leave
        Try
            If Trim(cmbdriver.Text) <> "" Then
                sql = "Select * from tbldriver where status='1' and driver='" & Trim(cmbdriver.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbdriver.SelectedItem = dr("driver")
                Else
                    MsgBox("Cannot found " & Trim(cmbdriver.Text), MsgBoxStyle.Critical, "")
                    cmbdriver.Text = ""
                    cmbdriver.Focus()
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                For Each item As Object In list1.Items
                    If item = Trim(cmbdriver.Text) Then
                        MsgBox("Cannot select " & Trim(cmbdriver.Text) & " because he has a pending receipt.", MsgBoxStyle.Exclamation, "")
                        cmbdriver.Text = ""
                        cmbdriver.Focus()
                        Exit Sub
                    End If
                Next
            Else
                cmbdriver.SelectedItem = ""
                cmbdriver.Text = ""
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub driver()
        Try
            cmbdriver.Items.Clear()
            cmbdriver.Items.Add("")
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tbldriver where status='1' order by driver"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read

                If dr1("company").ToString = "Customer" And Trim(lblvtype.Text) = "CUSTOMER TRUCK" Then
                    cmbdriver.Items.Add(dr1("driver"))

                ElseIf dr1("company").ToString = "Trucking" And Trim(lblvtype.Text) = "TRUCKING TRUCK" Then
                    cmbdriver.Items.Add(dr1("driver"))

                ElseIf dr1("company").ToString <> "Customer" And Trim(lblvtype.Text) = "CUSTOMER TRUCK" Then

                ElseIf dr1("company").ToString <> "Trucking" And Trim(lblvtype.Text) = "TRUCKING TRUCK" Then

                ElseIf dr1("company").ToString <> "Trucking" And dr1("company").ToString <> "Customer" Then
                    cmbdriver.Items.Add(dr1("driver"))

                End If

            End While
            dr1.Dispose()
            cmd1.Dispose()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbdriver_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbdriver.SelectedIndexChanged

    End Sub

    Private Sub tripdriver_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        checkhasrows7()
    End Sub

    Public Sub checkhasrows7()
        Try
            list1.Items.Clear()

            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbldispatchsum.datestp6, tbldispatchsum.withpending from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step7<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False And IsDBNull(dr("withpending")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) And dr("withpending") = 1 Then
                        Dim meron As Boolean = False
                        For Each item As Object In list1.Items
                            If item = dr("driver") Then
                                meron = True
                            End If
                        Next

                        If meron = False Then
                            list1.Items.Add(dr("driver"))
                        End If
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class