﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class parts
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim stat As String
    Public prcnf As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            If txtpr.Visible = False Then
                txtdesc.Focus()
                txtpr.Visible = True
                txtdesc.Text = ""
                btncancel.Enabled = True
                btnadd.Enabled = False
                btnupdate.Enabled = False
                btnview.Enabled = False
                btndeactivate.Enabled = False

                btnsearch.Text = "Ok"
            Else
                If Trim(txtdesc.Text) = "" And Trim(txtpr.Text) = "" Then
                    MsgBox("Input part number or part description first.", MsgBoxStyle.Exclamation, "")
                    txtdesc.Focus()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If

                Dim condition As String = ""
                If Trim(txtpr.Text) <> "" And Trim(txtdesc.Text) <> "" Then
                    condition = "partnum='" & Trim(txtpr.Text) & "' and description='" & Trim(txtdesc.Text) & "'"
                ElseIf Trim(txtpr.Text) <> "" And Trim(txtdesc.Text) = "" Then
                    condition = "partnum='" & Trim(txtpr.Text) & "'"
                ElseIf Trim(txtpr.Text) = "" And Trim(txtdesc.Text) <> "" Then
                    condition = "description='" & Trim(txtdesc.Text) & "'"
                End If

                btncancel.PerformClick()

                sql = "Select * from tblparts where " & condition
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    grdparts.Rows.Clear()
                    If dr("status") = 1 Then
                        stat = "Active"
                    Else
                        stat = "Deactivated"
                    End If
                    grdparts.Rows.Add(dr("partid"), dr("partnum"), dr("description"), stat)
                    txtdesc.Text = ""
                    lblprnum.Text = ""
                Else
                    MsgBox("Cannot found " & Trim(txtdesc.Text), MsgBoxStyle.Critical, "")
                    txtdesc.Text = ""
                    txtpr.Text = ""
                    lblprnum.Text = ""
                    txtdesc.Focus()
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()


            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If Trim(txtdesc.Text) <> "" Then
                loadprnum()

                sql = "Select * from tblparts where description='" & Trim(txtdesc.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    MsgBox(Trim(txtdesc.Text) & " is already exist", MsgBoxStyle.Information, "")
                    btnupdate.Text = "&Update"
                    txtdesc.Text = ""
                    txtdesc.Focus()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                prcnf = False
                confirm.ShowDialog()
                If prcnf = True Then
                    sql = "Insert into tblparts (partnum,description, datecreated, createdby, datemodified, modifiedby, status) values('" & Trim(lblprnum.Text) & "','" & Trim(txtdesc.Text) & "',GetDate(),'" & login.cashier & "',GetDate(),'" & login.cashier & "','1')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                    btnview.PerformClick()
                End If

                txtdesc.Text = ""
                lblprnum.Text = ""
                txtdesc.Focus()
                prcnf = False
            Else
                MsgBox("Input part description first", MsgBoxStyle.Exclamation, "")
                txtdesc.Focus()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        Try
            grdparts.Rows.Clear()
            Dim stat As String = ""

            sql = "Select * from tblparts"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdparts.Rows.Add(dr("partid"), dr("partnum"), dr("description"), stat)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If grdparts.Rows.Count = 0 Then
                btnupdate.Enabled = False
                btndeactivate.Enabled = False
            Else
                btnupdate.Enabled = True
                btndeactivate.Enabled = True
            End If

            btncancel.PerformClick()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtdesc_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtdesc.Leave
        txtdesc.Text = StrConv(txtdesc.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txttype_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdesc.TextChanged
        If Trim(txtdesc.Text) <> "" Then
            btncancel.Enabled = True
        ElseIf Trim(txtdesc.Text) = "" And btnupdate.Text = "&Save" Then
            btncancel.Enabled = True
        Else
            btncancel.Enabled = False
        End If

        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/()"
        Dim theText As String = txtdesc.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtdesc.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtdesc.Text.Length - 1
            Letter = txtdesc.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtdesc.Text = theText
        txtdesc.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub parts_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnview.PerformClick()
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        txtdesc.Text = ""
        lblprnum.Text = ""
        btnupdate.Text = "&Update"
        btnsearch.Enabled = True
        btnadd.Enabled = True
        btndeactivate.Enabled = True
        btncancel.Enabled = False
        btnupdate.Enabled = True
        btnview.Enabled = True
        txtpr.Visible = False
        btnsearch.Text = "Search"
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdparts.SelectedRows.Count = 1 Or grdparts.SelectedCells.Count = 1 Then
                If btnupdate.Text = "&Update" Then
                    If grdparts.Rows(grdparts.CurrentRow.Index).Cells(3).Value = "Deactivated" Then
                        MsgBox("Cannot update deactivated part description.", MsgBoxStyle.Exclamation, "")
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    lblid.Text = grdparts.Rows(grdparts.CurrentRow.Index).Cells(0).Value
                    lblprnum.Text = grdparts.Rows(grdparts.CurrentRow.Index).Cells(1).Value
                    lblpr.Text = grdparts.Rows(grdparts.CurrentRow.Index).Cells(2).Value
                    txtdesc.Text = grdparts.Rows(grdparts.CurrentRow.Index).Cells(2).Value
                    btnsearch.Enabled = False
                    btnadd.Enabled = False
                    btnupdate.Text = "&Save"
                    btncancel.Enabled = True
                    btndeactivate.Enabled = False
                Else
                    'update
                    If Trim(txtdesc.Text) = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Make should not be empty.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If

                    sql = "Select * from tblparts where description='" & Trim(txtdesc.Text) & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        txtdesc.Focus()
                        MsgBox(Trim(txtdesc.Text) & " is already exist", MsgBoxStyle.Information, "")
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    prcnf = False
                    confirm.ShowDialog()
                    If prcnf = True Then
                        If Trim(txtdesc.Text) <> Trim(lblpr.Text) Then
                            sql = "Update tblparts set description='" & Trim(txtdesc.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where partid='" & lblid.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'update other tbl in database

                        End If

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    btnupdate.Text = "&Update"
                    btnsearch.Enabled = True
                    btnadd.Enabled = True
                    btncancel.Enabled = False
                    btndeactivate.Enabled = True
                    txtdesc.Text = ""
                    lblprnum.Text = ""
                    txtdesc.Focus()
                    prcnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
                btnview.PerformClick()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btndeactivate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndeactivate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdparts.SelectedRows.Count = 1 Or grdparts.SelectedCells.Count = 1 Then
                lblid.Text = grdparts.Rows(grdparts.CurrentRow.Index).Cells(0).Value
                If btndeactivate.Text = "&Deactivate" Then
                    'check if theres item available status
                    sql = "Select * from tblpartsused where partid='" & lblid.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox("Cannot deactivate. Part description is still in use.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    prcnf = False
                    confirm.ShowDialog()
                    If prcnf = True Then
                        sql = "Update tblparts set status='0', datemodified=GetDate(), modifiedby='" & login.cashier & "' where partid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    prcnf = False
                Else
                    prcnf = False
                    confirm.ShowDialog()
                    If prcnf = True Then
                        sql = "Update tblparts set status='1', datemodified=GetDate(), modifiedby='" & login.cashier & "' where partid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    prcnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdmake_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdparts.SelectionChanged
        If grdparts.Rows(grdparts.CurrentRow.Index).Cells(3).Value = "Active" Then
            btndeactivate.Text = "&Deactivate"
        Else
            btndeactivate.Text = "A&ctivate"
        End If
    End Sub

    Public Sub loadprnum()
        Try
            Dim trnum As String = "1", temp As String = ""
            sql = "Select Top 1 * from tblparts order by partid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                trnum = Val(dr("partid")) + 1
            End If
            cmd.Dispose()
            dr.Dispose()
            conn.Close()

            If trnum < 1000000 Then
                For vv As Integer = 1 To 6 - trnum.Length
                    temp += "0"
                Next
                lblprnum.Text = temp & trnum
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtpr_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtpr.TextChanged
        'restrict inputs into numbers only
        Dim charactersDisallowed As String = "0123456789"
        Dim theText As String = txtpr.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtpr.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtpr.Text.Length - 1
            Letter = txtpr.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtpr.Text = theText
        txtpr.Select(SelectionIndex - Change, 0)
    End Sub
End Class