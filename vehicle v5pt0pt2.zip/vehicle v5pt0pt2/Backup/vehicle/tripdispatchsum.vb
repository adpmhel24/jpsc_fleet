﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.ComponentModel
Imports Excel = Microsoft.Office.Interop.Excel

Public Class tripdispatchsum
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Dim clickbtn As String = "", gridsql As String = ""
    Public tip As String

    Dim errorinfo As Boolean = False
    Dim hasrows7 As Boolean = False
    Dim hasrows8 As Boolean = False

    Private threadEnabled As Boolean, threadEnabledsteps As Boolean, threadEnableddestin As Boolean
    Private backgroundWorker As BackgroundWorker
    Private backgroundWorkersteps As BackgroundWorker
    Private backgroundWorkerdestin As BackgroundWorker

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub tripdispatchsum_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated

    End Sub

    Private Sub tripdispatchsum_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim a As String = MsgBox("Are you sure you want to close?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            'Stop background operation
            backgroundWorker.CancelAsync()
            backgroundWorkersteps.CancelAsync()
            backgroundWorkerdestin.CancelAsync()
            '/moduless.Show()
            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub tripdispatchsum_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cmbplate.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbplate.DropDownStyle = ComboBoxStyle.DropDown
        cmbplate.AutoCompleteSource = AutoCompleteSource.ListItems

        cmbdriver.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbdriver.DropDownStyle = ComboBoxStyle.DropDown
        cmbdriver.AutoCompleteSource = AutoCompleteSource.ListItems

        cmbtype.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbtype.DropDownStyle = ComboBoxStyle.DropDown
        cmbtype.AutoCompleteSource = AutoCompleteSource.ListItems

        cmbcus.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbcus.DropDownStyle = ComboBoxStyle.DropDown
        cmbcus.AutoCompleteSource = AutoCompleteSource.ListItems

        datefrom.CustomFormat = "yyyy/MM/dd"
        dateto.CustomFormat = "yyyy/MM/dd"
        datefrom.MaxDate = Date.Now.AddDays(+7)
        dateto.MinDate = datefrom.Value

        grddispatch.Columns(7).Frozen = True

        lbltrip.Text = login.whsecode

        plate()
        vtype()
        driver()
        vcustomer()
        viewall()
    End Sub

    Public Sub vcustomer()
        Try
            cmbcus.Items.Clear()
            cmbcus.Items.Add("")

            sql = "Select * from tblcustomer order by customer"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbcus.Items.Add(dr1("customer"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub vtype()
        Try
            cmbtype.Items.Clear()
            cmbtype.Items.Add("")

            sql = "Select * from tblvtype order by vtype"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbtype.Items.Add(dr1("vtype"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub plate()
        Try
            cmbplate.Items.Clear()
            cmbplate.Items.Add("")
            Dim plnum As String = ""

            sql = "Select * from tblgeneral"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                If dr1("platenum") = "" And dr1("vplate") <> "" Then
                    plnum = dr1("vplate")
                ElseIf dr1("platenum") = "" And dr1("vplate") = "" And dr1("csticker") <> "" Then
                    plnum = dr1("csticker")
                Else
                    plnum = dr1("platenum")
                End If

                cmbplate.Items.Add(plnum)
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub viewall()
        Try
            Me.Cursor = Cursors.WaitCursor

            clickbtn = "Pending"

            txttrip.Text = ""
            txtref.Text = ""
            cmbdriver.Text = ""
            cmbplate.Text = ""
            cmbtype.Text = ""
            cmbcus.Text = ""
            cmbref.SelectedItem = ""

            gridsql = "Select tbltripsum.tripsumid, tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.etd, tbltripsum.datecreated, tbltripsum.createdby, tbltripsum.datemodified, tbltripsum.modifiedby,tbltripsum.status,tbltripsum.repair,"
            gridsql = gridsql & " vtype from tbltripsum RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
            gridsql = gridsql & " where tbltripsum.status<'2' and tbltripsum.whsename='" & login.whse & "' order by tbltripsum.datepick"

            grddispatch.Rows.Clear()

            lblloading.Visible = True
            Panel1.Enabled = False
            ProgressBar1.Style = ProgressBarStyle.Marquee
            ProgressBar1.Visible = True
            ProgressBar1.Minimum = 0

            backgroundWorker = New BackgroundWorker()
            backgroundWorker.WorkerSupportsCancellation = True
            backgroundWorkersteps = New BackgroundWorker()
            backgroundWorkersteps.WorkerSupportsCancellation = True
            backgroundWorkerdestin = New BackgroundWorker()
            backgroundWorkerdestin.WorkerSupportsCancellation = True

            '/ProgressBar1.Style = ProgressBarStyle.Marquee
            AddHandler backgroundWorker.DoWork, New DoWorkEventHandler(AddressOf backgroundWorker_DoWork)
            AddHandler backgroundWorker.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorker_Completed)
            AddHandler backgroundWorker.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorker_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            AddHandler backgroundWorkersteps.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkersteps_DoWork)
            AddHandler backgroundWorkersteps.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkersteps_Completed)
            AddHandler backgroundWorkersteps.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorkersteps_ProgressChanged)
            m_updateRowDelegate = New UpdateRowDelegate(AddressOf UpdateDGVRow)

            AddHandler backgroundWorkerdestin.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkerdestin_DoWork)
            AddHandler backgroundWorkerdestin.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkerdestin_Completed)
            AddHandler backgroundWorkerdestin.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorkerdestin_ProgressChanged)
            m_destinRowDelegate = New destinRowDelegate(AddressOf destinDGVRow)

            If Not backgroundWorker.IsBusy Then
                backgroundWorker.WorkerReportsProgress = True
                backgroundWorker.WorkerSupportsCancellation = True
                backgroundWorker.RunWorkerAsync() 'start ng select query
            End If

            If Not backgroundWorkersteps.IsBusy Then
                '/MsgBox("View all pending.", MsgBoxStyle.Information, "")
                '/backgroundWorkersteps.WorkerReportsProgress = True
                '/backgroundWorkersteps.WorkerSupportsCancellation = True
                '/backgroundWorkersteps.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub backgroundWorker_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabled = True
        '/Me.Invoke(New updateProgressDelegate(AddressOf updateProgressBar))
        '//dito ilalagay yung select statement
        '/For i As Integer = 1 To 100
        '/backgroundWorker.ReportProgress(i)
        '/System.Threading.Thread.Sleep(100)
        '/Next
        Dim rowcount As Integer = 0, i As Integer = 0
        '/sql = "Select tbltripsum.tripsumid, tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.etd, tbltripsum.datecreated, tbltripsum.createdby, tbltripsum.datemodified, tbltripsum.modifiedby,tbltripsum.status,"
        '/sql = sql & " vtype from tbltripsum RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
        '/sql = sql & " where tbltripsum.status<'2' and tbltripsum.whsename='"& login.whse &"' order by tbltripsum.datepick"
        '/connect()
        '/cmd = New SqlCommand(gridsql, conn)
        '/rowcount = cmd.ExecuteScalar
        '/cmd.Dispose()
        '/conn.Close()

        '/sql = "Select tbltripsum.tripsumid, tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.etd, tbltripsum.datecreated, tbltripsum.createdby, tbltripsum.datemodified, tbltripsum.modifiedby,tbltripsum.status,"
        '/sql = sql & " vtype from tbltripsum RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
        '/sql = sql & " where tbltripsum.status<'2' and tbltripsum.whsename='"& login.whse &"' order by tbltripsum.datepick"
        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If
        cmd = New SqlCommand(gridsql, connection)
        Dim drx As SqlDataReader = cmd.ExecuteReader
        While drx.Read
            If grddispatch.InvokeRequired Then
                grddispatch.Invoke(m_addRowDelegate, drx("tripsumid"), Format(drx("datepick"), "yyyy/MM/dd"), drx("tripnum"), drx("platenum"), drx("vtype"), drx("driver"), "", Format(drx("etd"), "yyyy/MM/dd HH:mm"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"), drx("status"), drx("repair"), i)
            Else
                AddDGVRow(drx("tripsumid"), Format(drx("datepick"), "yyyy/MM/dd"), drx("tripnum"), drx("platenum"), drx("vtype"), drx("driver"), "", Format(drx("etd"), "yyyy/MM/dd HH:mm"), Format(drx("datecreated"), "yyyy/MM/dd HH:mm"), drx("createdby"), Format(drx("datemodified"), "yyyy/MM/dd HH:mm"), drx("modifiedby"), drx("status"), drx("repair"), i)
            End If
            i += 1
            backgroundWorker.ReportProgress(i) '/ idivide kung ilan ang total
            '/System.Threading.Thread.Sleep(50)
        End While
        drx.Dispose()
        cmd.Dispose()
        connection.Close()
    End Sub

    Delegate Sub AddRowDelegate(ByVal value0 As Object, ByVal value1 As Object, ByVal value2 As Object, ByVal value3 As Object, ByVal value4 As Object, ByVal value5 As Object, ByVal value6 As Object, ByVal value7 As Object, ByVal value8 As Object, ByVal value9 As Object, ByVal value23 As Object, ByVal value24 As Object, ByVal valuecancel As Object, ByVal vpup As Object, ByVal valuerowin As Object)
    Private m_addRowDelegate As AddRowDelegate

    Private Sub AddDGVRow(ByVal val0 As Integer, ByVal val1 As Date, ByVal val2 As String, ByVal val3 As String, ByVal val4 As String, ByVal val5 As String, ByVal val6 As String, ByVal val7 As Date, ByVal val8 As String, ByVal val9 As String, ByVal val23 As String, ByVal val24 As String, ByVal valcancel As Integer, ByVal vpup As Integer, ByVal rowin As Integer)
        If threadEnabled = True Then
            If grddispatch.InvokeRequired Then
                grddispatch.BeginInvoke(New AddRowDelegate(AddressOf AddDGVRow), val0, val1, val2, val3, val4, val5, val6, val7, val8, val9, val23, val24, valcancel, rowin)
            Else
                grddispatch.Rows.Add(val0, val1, val2, val3, val4, val5, val6, val7, val8, val9, "", "", "", "", "", "", "", "", "", "", "", "", "", val23, val24)
                grddispatch.Rows(rowin).Cells(0).Tag = valcancel
                If vpup = 1 Then
                    grddispatch.Rows(rowin).Cells(6).ErrorText = "   Pickup Trip Only"
                End If
            End If
        End If
    End Sub

    Private Sub backgroundWorker_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        '/ProgressBar1.Visible = False
        If Not backgroundWorker.IsBusy Then
            backgroundWorkersteps.WorkerReportsProgress = True
            backgroundWorkersteps.WorkerSupportsCancellation = True
            backgroundWorkersteps.RunWorkerAsync()
        End If
    End Sub

    Private Sub backgroundWorker_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label12.Text = e.ProgressPercentage.ToString() & "% complete"
    End Sub

    Private Sub backgroundWorkersteps_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabledsteps = True
        Me.Invoke(New updateProgressDelegate(AddressOf updateProgressBar))
        '//dito ilalagay yung select statement
        For Each row As DataGridViewRow In grddispatch.Rows
            Dim stp1 As String = "", stp2 As String = "", stp3 As String = "", stp4 As String = "", stp5 As String = "", stp6 As String = "", stp7 As String = "", stp8 As String = "", stp9 As String = ""
            Dim warn1 As String = "", warn2 As String = "", warn3 As String = "", warn4 As String = "", warn5 As String = "", warn6 As String = "", warn7 As String = "", warn8 As String = "", warn9 As String = ""
            Dim log1 As Boolean = False, log2 As Boolean = False, log3 As Boolean = False, log4 As Boolean = False, log5 As Boolean = False, log6 As Boolean = False, log7 As Boolean = False, log8 As Boolean = False, log9 As Boolean = False
            Dim whatstep As String = "ON QUEUE"
            Dim des As String = ""
            Dim savedraftorstart As String = ""

            sql = "Select * from tbldispatchsum where tripnum='" & grddispatch.Rows(row.Index).Cells(2).Value & "'"
            Dim connection As SqlConnection
            connection = New SqlConnection
            connection.ConnectionString = strconn
            If connection.State <> ConnectionState.Open Then
                connection.Open()
            End If
            cmd = New SqlCommand(sql, connection)
            Dim drx1 As SqlDataReader = cmd.ExecuteReader
            If drx1.Read Then
                If drx1("step1") = 1 Then

                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                    ElseIf drx1("namestp1").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                    ElseIf drx1("namestp1").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp1") & " ( " & drx1("datestp1").ToString & " )"
                        whatstep = "STEP 1"
                    End If

                    stp1 = des

                    If IsDBNull(drx1("cstatstp1")) = False Then
                        log1 = True                        '/grddispatch.Item(10, row.Index).Style.BackColor = Color.Yellow
                        If drx1("cstatstp1") = 0 Then
                            warn1 = drx1("comstp1")
                        End If
                    End If
                Else
                    If IsDBNull(drx1("sdeytstp1")) = False Then
                        savedraftorstart = "SAVE AS DRAFT" & vbCrLf & drx1("sneymstp1").ToString & " ( " & drx1("sdeytstp1").ToString & " )"
                        stp1 = savedraftorstart
                        whatstep = "STEP 1"
                    ElseIf IsDBNull(drx1("startpreby")) = False Or IsDBNull(drx1("startpre")) = False Then
                        savedraftorstart = "TIME START" & vbCrLf & drx1("startpreby").ToString & " ( " & drx1("startpre").ToString & " )"
                        stp1 = savedraftorstart
                        whatstep = "STEP 1"
                    Else
                        stp1 = ""
                    End If
                End If

                If drx1("step2") = 1 Then

                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                    ElseIf drx1("namestp2").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                    ElseIf drx1("namestp2").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp2") & " ( " & drx1("datestp2").ToString & " )"
                        whatstep = "STEP 2"
                    End If

                    stp2 = des

                    If IsDBNull(drx1("cstatstp2")) = False Then
                        log2 = True                        '/grddispatch.Item(11, row.Index).Style.BackColor = Color.Yellow
                        If drx1("cstatstp2") = 0 Then
                            warn2 = drx1("comstp2")
                        End If
                    End If
                Else
                    If IsDBNull(drx1("sdeytstp2")) = False Then
                        savedraftorstart = "SAVE AS DRAFT" & vbCrLf & drx1("sneymstp2").ToString & " ( " & drx1("sdeytstp2").ToString & " )"
                        stp2 = savedraftorstart
                        whatstep = "STEP 2"
                    ElseIf IsDBNull(drx1("startdieselby")) = False Or IsDBNull(drx1("startdiesel")) = False Then
                        savedraftorstart = "TIME START" & vbCrLf & drx1("startdieselby").ToString & " ( " & drx1("startdiesel").ToString & " )"
                        stp2 = savedraftorstart
                        whatstep = "STEP 2"
                    Else
                        stp2 = ""
                    End If
                End If

                If drx1("step3") = 1 Then

                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                    ElseIf drx1("namestp3").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                    ElseIf drx1("namestp3").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp3") & " ( " & drx1("datestp3").ToString & " )"
                        whatstep = "STEP 3"
                    End If

                    stp3 = des

                    If IsDBNull(drx1("cstatstp3")) = False Then
                        log3 = True                        '/grddispatch.Item(12, row.Index).Style.BackColor = Color.Yellow
                        If drx1("cstatstp3") = 0 Then
                            warn3 = drx1("comstp3")
                        End If
                    End If
                Else
                    If IsDBNull(drx1("sdeytstp3")) = False Then
                        savedraftorstart = "SAVE AS DRAFT" & vbCrLf & drx1("sneymstp3").ToString & " ( " & drx1("sdeytstp3").ToString & " )"
                        stp3 = savedraftorstart
                        whatstep = "STEP 3"
                    ElseIf IsDBNull(drx1("startloadby")) = False Or IsDBNull(drx1("startload")) = False Then
                        savedraftorstart = "TIME START" & vbCrLf & drx1("startloadby").ToString & " ( " & drx1("startload").ToString & " )"
                        stp3 = savedraftorstart
                        whatstep = "STEP 3"
                    Else
                        stp3 = ""
                    End If
                End If

                If drx1("step4") = 1 Then

                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                    ElseIf drx1("namestp4").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                    ElseIf drx1("namestp4").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp4") & " ( " & drx1("datestp4").ToString & " )"
                        whatstep = "STEP 4"
                    End If

                    stp4 = des

                    If IsDBNull(drx1("cstatstp4")) = False Then
                        log4 = True                        '/grddispatch.Item(14, row.Index).Style.BackColor = Color.Yellow
                        If drx1("cstatstp4") = 0 Then
                            warn4 = drx1("comstp4")
                        End If
                    End If
                Else
                    If IsDBNull(drx1("sdeytstp4")) = False Then
                        savedraftorstart = "SAVE AS DRAFT" & vbCrLf & drx1("sneymstp4").ToString & " ( " & drx1("sdeytstp4").ToString & " )"
                        stp4 = savedraftorstart
                        whatstep = "STEP 4"
                    ElseIf IsDBNull(drx1("startdocby")) = False Or IsDBNull(drx1("startdoc")) = False Then
                        savedraftorstart = "TIME START" & vbCrLf & drx1("startdocby").ToString & " ( " & drx1("startdoc").ToString & " )"
                        stp4 = savedraftorstart
                        whatstep = "STEP 4"
                    Else
                        stp4 = ""
                    End If
                End If

                If drx1("step5") = 1 Then

                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                    ElseIf drx1("namestp5").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                        If IsDBNull(drx1("timedep")) = False Then
                            whatstep = "DISPATCHED"
                            stp6 = "Time Departure: " & drx1("timedep")
                        End If
                    ElseIf drx1("namestp5").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp5") & " ( " & drx1("datestp5").ToString & " )"
                        whatstep = "STEP 5"
                        If IsDBNull(drx1("timedep")) = False Then
                            whatstep = "DISPATCHED"
                            stp6 = "Time Departure: " & drx1("timedep")
                        End If
                    End If

                    stp5 = des

                    If IsDBNull(drx1("cstatstp5")) = False Then
                        log5 = True                        '/grddispatch.Item(15, row.Index).Style.BackColor = Color.Yellow
                        If drx1("cstatstp5") = 0 Then
                            warn5 = drx1("comstp5")
                        End If
                    End If
                Else
                    If IsDBNull(drx1("sdeytstp5")) = False Then
                        savedraftorstart = "SAVE AS DRAFT" & vbCrLf & drx1("sneymstp5").ToString & " ( " & drx1("sdeytstp5").ToString & " )"
                        stp5 = savedraftorstart
                        whatstep = "STEP 5"
                    ElseIf IsDBNull(drx1("startcashby")) = False Or IsDBNull(drx1("startcash")) = False Then
                        savedraftorstart = "TIME START" & vbCrLf & drx1("startcashby").ToString & " ( " & drx1("startcash").ToString & " )"
                        stp5 = savedraftorstart
                        whatstep = "STEP 5"
                    Else
                        stp5 = ""
                    End If
                End If

                If drx1("step6") = 1 Then

                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                    ElseIf drx1("namestp6").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                    ElseIf drx1("namestp6").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp6") & " ( " & drx1("datestp6").ToString & " )"
                        whatstep = "STEP 6"
                    End If

                    stp6 = des

                    If IsDBNull(drx1("cstatstp6")) = False Then
                        log6 = True                        '/grddispatch.Item(16, row.Index).Style.BackColor = Color.Yellow
                        If drx1("cstatstp6") = 0 Then
                            warn6 = drx1("comstp6")
                        End If
                    End If
                Else
                    If IsDBNull(drx1("sdeytstp6")) = False Then
                        savedraftorstart = "SAVE AS DRAFT" & vbCrLf & drx1("sneymstp6").ToString & " ( " & drx1("sdeytstp6").ToString & " )"
                        stp6 = savedraftorstart
                    End If

                    If IsDBNull(drx1("cstatstp6")) = False Then
                        If drx1("cstatstp6") = 0 Then
                            warn6 = drx1("comstp6")
                        End If
                    End If
                End If

                If drx1("step7") = 1 Then

                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                    ElseIf drx1("namestp7").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                    ElseIf drx1("namestp7").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp7") & " ( " & drx1("datestp7").ToString & " )"
                        whatstep = "STEP 7"
                    End If

                    stp7 = des

                    If IsDBNull(drx1("cstatstp7")) = False Then
                        log7 = True                        '/grddispatch.Item(17, row.Index).Style.BackColor = Color.Yellow
                        If drx1("cstatstp7") = 0 Then
                            warn7 = drx1("comstp7")
                        End If
                    End If
                Else
                    If IsDBNull(drx1("sdeytstp7")) = False Then
                        savedraftorstart = "SAVE AS DRAFT" & vbCrLf & drx1("sneymstp7").ToString & " ( " & drx1("sdeytstp7").ToString & " )"
                        stp7 = savedraftorstart
                        whatstep = "STEP 7"
                    ElseIf IsDBNull(drx1("startreturnby")) = False Or IsDBNull(drx1("startreturn")) = False Then
                        savedraftorstart = "TIME START" & vbCrLf & drx1("startreturnby").ToString & " ( " & drx1("startreturn").ToString & " )"
                        stp7 = savedraftorstart
                        whatstep = "STEP 7"
                    Else
                        stp7 = ""
                    End If
                End If

                If drx1("step8") = 1 Then

                    If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                        des = "RESCUE TRIP# " & drx1("rescue")
                    ElseIf drx1("namestp8").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                    ElseIf drx1("namestp8").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp8") & " ( " & drx1("datestp8").ToString & " )"
                        whatstep = "STEP 8"
                    End If

                    stp8 = des

                    If IsDBNull(drx1("cstatstp8")) = False Then
                        log8 = True                        '/grddispatch.Item(18, row.Index).Style.BackColor = Color.Yellow
                        If drx1("cstatstp8") = 0 Then
                            warn8 = drx1("comstp8")
                        End If
                    End If
                Else
                    If IsDBNull(drx1("sdeytstp8")) = False Then
                        savedraftorstart = "SAVE AS DRAFT" & vbCrLf & drx1("sneymstp8").ToString & " ( " & drx1("sdeytstp8").ToString & " )"
                        stp8 = savedraftorstart
                        whatstep = "STEP 8"
                    ElseIf IsDBNull(drx1("startpostby")) = False Or IsDBNull(drx1("startpost")) = False Then
                        savedraftorstart = "TIME START" & vbCrLf & drx1("startpostby").ToString & " ( " & drx1("startpost").ToString & " )"
                        stp8 = savedraftorstart
                        whatstep = "STEP 8"
                    Else
                        stp8 = ""
                    End If
                End If

                If drx1("step9") = 1 Then

                    If drx1("namestp9").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = "SKIPPED"
                    ElseIf drx1("namestp9").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                        des = drx1("namestp9") & " ( " & drx1("datestp9").ToString & " )"
                    Else
                        des = ""
                    End If

                    stp9 = des

                    If IsDBNull(drx1("cstatstp9")) = False Then
                        log9 = True                        '/grddispatch.Item(21, row.Index).Style.BackColor = Color.Yellow
                        If drx1("cstatstp9") = 0 Then
                            warn9 = drx1("comstp9")
                        End If
                    End If

                    whatstep = "COMPLETED"
                Else
                    If IsDBNull(drx1("sdeytstp9")) = False Then
                        savedraftorstart = "SAVE AS DRAFT" & vbCrLf & drx1("sneymstp9").ToString & " ( " & drx1("sdeytstp9").ToString & " )"
                        stp9 = savedraftorstart
                        whatstep = "STEP 9"
                    ElseIf IsDBNull(drx1("startrecordby")) = False Or IsDBNull(drx1("startrecord")) = False Then
                        savedraftorstart = "TIME START" & vbCrLf & drx1("startrecordby").ToString & " ( " & drx1("startrecord").ToString & " )"
                        stp9 = savedraftorstart
                        whatstep = "STEP 9"
                    Else
                        stp9 = ""
                    End If
                End If
                '/grddispatch.Item(22, row.Index).Value = whatstep
            End If
            drx1.Dispose()
            cmd.Dispose()
            connection.Close()

            Dim i As Integer = 0
            Dim rowin As Object = row.Index
            UpdateDGVRow(rowin, stp1, stp2, stp3, stp4, stp5, stp6, stp7, stp8, stp9, whatstep)
            CommentDGVRow(rowin, log1, log2, log3, log4, log5, log6, log7, log8, log9)
            ErrorDGVRow(rowin, warn1, warn2, warn3, warn4, warn5, warn6, warn7, warn8, warn9)
            backgroundWorkersteps.ReportProgress(i * 100 / 155) '/ idivide kung ilan ang total
            '/System.Threading.Thread.Sleep(100)
        Next
    End Sub

    Delegate Sub UpdateRowDelegate(ByVal valueindex As Object, ByVal value1 As Object, ByVal value2 As Object, ByVal value3 As Object, ByVal value4 As Object, ByVal value5 As Object, ByVal value6 As Object, ByVal value7 As Object, ByVal value8 As Object, ByVal value9 As Object, ByVal value10 As Object)
    Private m_updateRowDelegate As UpdateRowDelegate

    Private Sub UpdateDGVRow(ByVal rowin As String, ByVal val1 As String, ByVal val2 As String, ByVal val3 As String, ByVal val4 As String, ByVal val5 As String, ByVal val6 As String, ByVal val7 As String, ByVal val8 As String, ByVal val9 As String, ByVal valstat As String)
        If threadEnabledsteps = True Then
            If grddispatch.InvokeRequired Then
                grddispatch.BeginInvoke(New UpdateRowDelegate(AddressOf UpdateDGVRow), rowin, val1, val2, val3, val4, val5, val6, val7, val8, val9, valstat)
            Else
                grddispatch.Rows(rowin).Cells(10).Value = val1
                grddispatch.Rows(rowin).Cells(11).Value = val2
                grddispatch.Rows(rowin).Cells(12).Value = val3
                grddispatch.Rows(rowin).Cells(14).Value = val4
                grddispatch.Rows(rowin).Cells(15).Value = val5
                grddispatch.Rows(rowin).Cells(16).Value = val6
                grddispatch.Rows(rowin).Cells(17).Value = val7
                grddispatch.Rows(rowin).Cells(18).Value = val8
                grddispatch.Rows(rowin).Cells(21).Value = val9
                grddispatch.Rows(rowin).Cells(22).Value = valstat
            End If
        End If
    End Sub

    Delegate Sub CommentRowDelegate(ByVal valueindex As Object, ByVal value1 As Object, ByVal value2 As Object, ByVal value3 As Object, ByVal value4 As Object, ByVal value5 As Object, ByVal value6 As Object, ByVal value7 As Object, ByVal value8 As Object, ByVal value9 As Object)
    Private m_CommentRowDelegate As CommentRowDelegate

    Private Sub CommentDGVRow(ByVal rowin As String, ByVal val1 As Boolean, ByVal val2 As Boolean, ByVal val3 As Boolean, ByVal val4 As Boolean, ByVal val5 As Boolean, ByVal val6 As Boolean, ByVal val7 As Boolean, ByVal val8 As Boolean, ByVal val9 As Boolean)
        If threadEnabledsteps = True Then
            If grddispatch.InvokeRequired Then
                grddispatch.BeginInvoke(New CommentRowDelegate(AddressOf CommentDGVRow), rowin, val1, val2, val3, val4, val5, val6, val7, val8, val9)
            Else
                grddispatch.Rows(rowin).Cells(10).Tag = val1
                grddispatch.Rows(rowin).Cells(11).Tag = val2
                grddispatch.Rows(rowin).Cells(12).Tag = val3
                grddispatch.Rows(rowin).Cells(14).Tag = val4
                grddispatch.Rows(rowin).Cells(15).Tag = val5
                grddispatch.Rows(rowin).Cells(16).Tag = val6
                grddispatch.Rows(rowin).Cells(17).Tag = val7
                grddispatch.Rows(rowin).Cells(18).Tag = val8
                grddispatch.Rows(rowin).Cells(21).Tag = val9
            End If
        End If
    End Sub

    Delegate Sub ErrorRowDelegate(ByVal valueindex As Object, ByVal value1 As Object, ByVal value2 As Object, ByVal value3 As Object, ByVal value4 As Object, ByVal value5 As Object, ByVal value6 As Object, ByVal value7 As Object, ByVal value8 As Object, ByVal value9 As Object)
    Private m_ErrorRowDelegate As ErrorRowDelegate

    Private Sub ErrorDGVRow(ByVal rowin As String, ByVal val1 As String, ByVal val2 As String, ByVal val3 As String, ByVal val4 As String, ByVal val5 As String, ByVal val6 As String, ByVal val7 As String, ByVal val8 As String, ByVal val9 As String)
        If threadEnabledsteps = True Then
            If grddispatch.InvokeRequired Then
                grddispatch.BeginInvoke(New ErrorRowDelegate(AddressOf ErrorDGVRow), rowin, val1, val2, val3, val4, val5, val6, val7, val8, val9)
            Else
                grddispatch.Rows(rowin).Cells(10).ErrorText = val1
                grddispatch.Rows(rowin).Cells(11).ErrorText = val2
                grddispatch.Rows(rowin).Cells(12).ErrorText = val3
                grddispatch.Rows(rowin).Cells(14).ErrorText = val4
                grddispatch.Rows(rowin).Cells(15).ErrorText = val5
                grddispatch.Rows(rowin).Cells(16).ErrorText = val6
                grddispatch.Rows(rowin).Cells(17).ErrorText = val7
                grddispatch.Rows(rowin).Cells(18).ErrorText = val8
                grddispatch.Rows(rowin).Cells(21).ErrorText = val9
            End If
        End If
    End Sub

    Private Sub backgroundWorkerdestin_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnableddestin = True
        Me.Invoke(New updateProgressDelegate(AddressOf updateProgressBar))
        '//dito ilalagay yung select statement
        '/For i As Integer = 1 To 100
        '/backgroundWorker.ReportProgress(i)
        '/System.Threading.Thread.Sleep(100)
        '/Next

        'destination
        For Each row As DataGridViewRow In grddispatch.Rows
            Dim temp As String = "", temptype As String = ""
            sql = "SELECT tblortrans.customer,tblortrans.transtype FROM tbltripitems RIGHT OUTER JOIN tblortrans ON tbltripitems.transnum=tblortrans.transnum"
            sql = sql & " where tbltripitems.tripnum='" & grddispatch.Rows(row.Index).Cells(2).Value & "' and tbltripitems.status<>'3'" 'and tbltripitems.status<>'0'
            Dim connection As SqlConnection
            connection = New SqlConnection
            connection.ConnectionString = strconn
            If connection.State <> ConnectionState.Open Then
                connection.Open()
            End If
            cmd = New SqlCommand(sql, connection)
            Dim dr11x As SqlDataReader = cmd.ExecuteReader
            While dr11x.Read
                If temp = "" Then
                    temp = temp & dr11x("customer")
                Else
                    temp = temp & " / " & dr11x("customer")
                End If

                If dr11x("transtype").ToString.Contains("PICKUP") Then
                    Dim inSql As String = dr11x("transtype").ToString
                    Dim lastPart As String
                    Dim fromStart As Integer
                    Dim firstpart As String

                    fromStart = inSql.IndexOf("FRM ") + 4

                    firstpart = inSql.Substring(0, fromStart - 4)
                    temptype = Trim(firstpart)

                    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

                    temptype = lastPart & " "
                End If
            End While
            dr11x.Dispose()
            cmd.Dispose()
            connection.Close()

            Dim destination As String = ""
            If temp = "" Then
                temp = "Taxi"
                destination = temp
            Else
                If temptype = "" Then
                    destination = temp
                Else
                    destination = "p/up " & temptype & "/ " & temp
                End If
            End If

            Dim rowin As Object = row.Index
            If grddispatch.InvokeRequired Then
                destinDGVRow(rowin, destination)
            End If
        Next
    End Sub

    Delegate Sub destinRowDelegate(ByVal value0 As Object, ByVal value1 As Object)
    Private m_destinRowDelegate As destinRowDelegate

    Private Sub destinDGVRow(ByVal rowin As Integer, ByVal val1 As String)
        If threadEnableddestin = True Then
            If grddispatch.InvokeRequired Then
                grddispatch.BeginInvoke(New destinRowDelegate(AddressOf destinDGVRow), rowin, val1)
            Else
                grddispatch.Rows(rowin).Cells(6).Value = val1
            End If
        End If
    End Sub

    Private Delegate Sub updateProgressDelegate()

    Private Sub updateProgressBar()
        '/ProgressBar1.Visible = True
        '/ProgressBar1.Value = ProgressBar1.Maximum        '/ProgressBar1.Value=
    End Sub

    Private Sub backgroundWorkersteps_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        If Not backgroundWorkersteps.IsBusy Then
            backgroundWorkerdestin.WorkerReportsProgress = True
            backgroundWorkerdestin.WorkerSupportsCancellation = True
            backgroundWorkerdestin.RunWorkerAsync() 'start ng select query
        End If
    End Sub

    Private Sub backgroundWorkerdestin_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        Me.Cursor = Cursors.Default
        ProgressBar1.Visible = False
        ProgressBar1.Style = ProgressBarStyle.Blocks
        lblloading.Visible = False
        Panel1.Enabled = True
        If e.Error IsNot Nothing Then
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            If grddispatch.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            Else
                If Trim(txttrip.Text) = "" And Trim(txtref.Text) = "" Then
                    MsgBox("Loading data completed.", MsgBoxStyle.Information, "")
                End If
            End If
        End If
    End Sub

    Private Sub backgroundWorkersteps_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label2.Text = e.ProgressPercentage.ToString() & "% complete"
    End Sub

    Private Sub backgroundWorkerdestin_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label3.Text = e.ProgressPercentage.ToString() & "% complete"
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        txtref.Text = ""
        txttrip.Text = ""
        cmbref.SelectedItem = ""
        cmbplate.Enabled = True
        cmbtype.Enabled = True
        cmbcus.Enabled = True
        cmbdriver.Enabled = True
        datefrom.Enabled = True
        dateto.Enabled = True
        '/datefrom.Value = Date.Now
        viewall()
    End Sub

    Private Sub grddispatch_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grddispatch.CellClick
        
    End Sub

    Private Sub grddispatch_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grddispatch.CellContentClick
        Try
            'link
            If e.ColumnIndex = 2 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grddispatch.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grddispatch.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grddispatch.RowCount <> 0 Then
                    If grddispatch.Item(2, grddispatch.CurrentRow.Index).Value IsNot Nothing Then
                        'if taxi
                        If grddispatch.Item(6, grddispatch.CurrentRow.Index).Value IsNot Nothing And grddispatch.Item(6, grddispatch.CurrentRow.Index).Value = "Taxi" Then
                            Me.Cursor = Cursors.Default
                            MsgBox("No Transactions. Taxi only.", MsgBoxStyle.Information, "")
                            Exit Sub
                        End If

                        'viewtrans.txttrans.Text = grddispatch.Item(2, grddispatch.CurrentRow.Index).Value
                        'populate grdtrans
                        '/Dim myForm As New viewtrans
                        viewtrans.Text = "View Transactions (" & grddispatch.Item(2, grddispatch.CurrentRow.Index).Value.ToString & ")"
                        viewtrans.lbltripnum.Text = grddispatch.Item(2, grddispatch.CurrentRow.Index).Value.ToString
                        viewtrans.grouptrans.Visible = True
                        viewtrans.grdtrans.Rows.Clear()
                        sql = "Select * from tbltripitems where tripnum='" & grddispatch.Item(2, grddispatch.CurrentRow.Index).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        While dr.Read
                            viewtrans.grdtrans.Rows.Add(dr("transnum"))
                        End While
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        viewtrans.ShowDialog()
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grddispatch_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grddispatch.CellDoubleClick
        Try
            'check if selected cell=1 and what column index
            Dim done As Boolean = True
            If grddispatch.SelectedCells.Count = 1 Then
                If e.ColumnIndex = 10 And e.RowIndex > -1 Then
                    If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(10).Value IsNot Nothing And grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(10).Value <> "" Then
                        If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(10).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(10).Value.ToString.Contains("RESCUE TRIP#") Then
                            If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(10).Value.ToString.Contains("SAVE AS DRAFT") Or grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(10).Value.ToString.Contains("TIME START") Then
                                done = False
                                viewstep1.notfinish()
                            Else
                                viewstep1.finish()
                            End If

                            viewstep1.lblstep.Text = "1"
                            viewstep1.Text = "View Step1 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                            viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                            viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                            viewstep1.lbltype1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(4).Value
                            viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                            viewstep1.ShowDialog()

                            If done = True Then
                                If viewstep1.comstat <> 2 Then
                                    grddispatch.Item(10, grddispatch.CurrentRow.Index).Style.BackColor = Color.Yellow
                                Else 'if ung stat is null
                                    grddispatch.Item(10, grddispatch.CurrentRow.Index).Style.BackColor = Color.FromArgb(255, 255, 170)
                                End If
                            End If
                        End If
                    End If
                ElseIf e.ColumnIndex = 11 And e.RowIndex > -1 Then
                    If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(11).Value IsNot Nothing And grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(11).Value <> "" Then
                        If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(11).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(11).Value.ToString.Contains("RESCUE TRIP#") Then
                            If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(11).Value.ToString.Contains("SAVE AS DRAFT") Or grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(11).Value.ToString.Contains("TIME START") Then
                                done = False
                                viewstep1.notfinish()
                            Else
                                viewstep1.finish()
                            End If

                            viewstep1.lblstep.Text = "2"
                            viewstep1.Text = "View Step2 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                            viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                            viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                            viewstep1.lbltype1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(4).Value
                            viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                            viewstep1.ShowDialog()

                            If done = True Then
                                If viewstep1.comstat <> 2 Then
                                    grddispatch.Item(11, grddispatch.CurrentRow.Index).Style.BackColor = Color.Yellow
                                Else 'if ung stat is null
                                    grddispatch.Item(11, grddispatch.CurrentRow.Index).Style.BackColor = Color.FromArgb(255, 255, 170)
                                End If
                            End If
                        End If
                    End If
                ElseIf e.ColumnIndex = 12 And e.RowIndex > -1 Then
                    If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(12).Value IsNot Nothing And grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(12).Value <> "" Then
                        If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(12).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(12).Value.ToString.Contains("RESCUE TRIP#") Then
                            If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(12).Value.ToString.Contains("SAVE AS DRAFT") Or grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(12).Value.ToString.Contains("TIME START") Then
                                done = False
                                viewstep1.notfinish()
                            Else
                                viewstep1.finish()
                            End If

                            viewstep1.lblstep.Text = "3"
                            viewstep1.Text = "View Step3 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                            viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                            viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                            viewstep1.lbltype1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(4).Value
                            viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                            viewstep1.ShowDialog()

                            If done = True Then
                                If viewstep1.comstat <> 2 Then
                                    grddispatch.Item(12, grddispatch.CurrentRow.Index).Style.BackColor = Color.Yellow
                                Else 'if ung stat is null
                                    grddispatch.Item(12, grddispatch.CurrentRow.Index).Style.BackColor = Color.FromArgb(255, 255, 170)
                                End If
                            End If
                        End If
                    End If

                ElseIf e.ColumnIndex = 14 And e.RowIndex > -1 Then
                    If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(14).Value IsNot Nothing And grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(14).Value <> "" Then
                        If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(14).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(14).Value.ToString.Contains("RESCUE TRIP#") Then
                            If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(14).Value.ToString.Contains("SAVE AS DRAFT") Or grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(14).Value.ToString.Contains("TIME START") Then
                                done = False
                                viewstep1.notfinish()
                            Else
                                viewstep1.finish()
                            End If

                            viewstep1.lblstep.Text = "4"
                            viewstep1.Text = "View Step4 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                            viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                            viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                            viewstep1.lbltype1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(4).Value
                            viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                            viewstep1.ShowDialog()

                            If done = True Then
                                If viewstep1.comstat <> 2 Then
                                    grddispatch.Item(14, grddispatch.CurrentRow.Index).Style.BackColor = Color.Yellow
                                Else 'if ung stat is null
                                    grddispatch.Item(14, grddispatch.CurrentRow.Index).Style.BackColor = Color.FromArgb(255, 255, 170)
                                End If
                            End If
                        End If
                    End If
                ElseIf e.ColumnIndex = 15 And e.RowIndex > -1 Then
                    If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(15).Value IsNot Nothing And grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(15).Value <> "" Then
                        If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(15).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(15).Value.ToString.Contains("RESCUE TRIP#") Then
                            If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(15).Value.ToString.Contains("SAVE AS DRAFT") Or grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(15).Value.ToString.Contains("TIME START") Then
                                done = False
                                viewstep1.notfinish()
                            Else
                                viewstep1.finish()
                            End If

                            viewstep1.lblstep.Text = "5"
                            viewstep1.Text = "View Step5 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                            viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                            viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                            viewstep1.lbltype1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(4).Value
                            viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                            viewstep1.ShowDialog()

                            If done = True Then
                                If viewstep1.comstat <> 2 Then
                                    grddispatch.Item(15, grddispatch.CurrentRow.Index).Style.BackColor = Color.Yellow
                                Else 'if ung stat is null
                                    grddispatch.Item(15, grddispatch.CurrentRow.Index).Style.BackColor = Color.FromArgb(255, 255, 170)
                                End If
                            End If
                        End If
                    End If
                ElseIf e.ColumnIndex = 16 And e.RowIndex > -1 Then
                    If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(16).Value IsNot Nothing And grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(16).Value <> "" Then
                        If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(16).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(16).Value.ToString.Contains("RESCUE TRIP#") Then
                            If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(16).Value.ToString.Contains("SAVE AS DRAFT") Or grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(16).Value.ToString.Contains("TIME START") Then
                                done = False
                                viewstep1.notfinish()
                            Else
                                viewstep1.finish()
                            End If

                            viewstep1.lblstep.Text = "6"
                            viewstep1.Text = "View Step6 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                            viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                            viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                            viewstep1.lbltype1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(4).Value
                            viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                            viewstep1.ShowDialog()

                            If done = True Then
                                If viewstep1.comstat <> 2 Then
                                    If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(16).Value.ToString.Contains("Time Departure") = True Then
                                        grddispatch.Item(16, grddispatch.CurrentRow.Index).Style.BackColor = Nothing
                                    Else
                                        grddispatch.Item(16, grddispatch.CurrentRow.Index).Style.BackColor = Color.Yellow
                                    End If
                                Else 'if ung stat is null
                                    grddispatch.Item(16, grddispatch.CurrentRow.Index).Style.BackColor = Color.FromArgb(255, 255, 170)
                                End If
                            End If
                        End If
                    End If
                ElseIf e.ColumnIndex = 17 And e.RowIndex > -1 Then
                    If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(17).Value IsNot Nothing And grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(17).Value <> "" Then
                        If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(17).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(17).Value.ToString.Contains("RESCUE TRIP#") Then
                            If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(17).Value.ToString.Contains("SAVE AS DRAFT") Or grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(17).Value.ToString.Contains("TIME START") Then
                                done = False
                                viewstep1.notfinish()
                            Else
                                viewstep1.finish()
                            End If

                            viewstep1.lblstep.Text = "7"
                            viewstep1.Text = "View Step7 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                            viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                            viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                            viewstep1.lbltype1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(4).Value
                            viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                            viewstep1.ShowDialog()

                            If done = True Then
                                If viewstep1.comstat <> 2 Then
                                    grddispatch.Item(17, grddispatch.CurrentRow.Index).Style.BackColor = Color.Yellow
                                Else 'if ung stat is null
                                    grddispatch.Item(17, grddispatch.CurrentRow.Index).Style.BackColor = Color.FromArgb(255, 255, 170)
                                End If
                            End If
                        End If
                    End If
                ElseIf e.ColumnIndex = 18 And e.RowIndex > -1 Then
                    If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(18).Value IsNot Nothing And grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(18).Value <> "" Then
                        If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(18).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(18).Value.ToString.Contains("RESCUE TRIP#") Then
                            If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(18).Value.ToString.Contains("SAVE AS DRAFT") Or grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(18).Value.ToString.Contains("TIME START") Then
                                done = False
                                viewstep1.notfinish()
                            Else
                                viewstep1.finish()
                            End If

                            viewstep1.lblstep.Text = "8"
                            viewstep1.Text = "View Step8 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                            viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                            viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                            viewstep1.lbltype1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(4).Value
                            viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                            viewstep1.ShowDialog()

                            If done = True Then
                                If viewstep1.comstat <> 2 Then
                                    grddispatch.Item(18, grddispatch.CurrentRow.Index).Style.BackColor = Color.Yellow
                                Else 'if ung stat is null
                                    grddispatch.Item(18, grddispatch.CurrentRow.Index).Style.BackColor = Color.FromArgb(255, 255, 170)
                                End If
                            End If
                        End If
                    End If
                ElseIf e.ColumnIndex = 21 And e.RowIndex > -1 Then
                    If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(21).Value IsNot Nothing And grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(21).Value <> "" Then
                        If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(21).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(21).Value.ToString.Contains("RESCUE TRIP#") Then
                            If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(21).Value.ToString.Contains("SAVE AS DRAFT") Or grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(21).Value.ToString.Contains("TIME START") Then
                                done = False
                                viewstep1.notfinish()
                            Else
                                viewstep1.finish()
                            End If

                            viewstep1.lblstep.Text = "9"
                            viewstep1.Text = "View Step9 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                            viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                            viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                            viewstep1.lbltype1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(4).Value
                            viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                            viewstep1.ShowDialog()

                            If done = True Then
                                If viewstep1.comstat <> 2 Then
                                    grddispatch.Item(21, grddispatch.CurrentRow.Index).Style.BackColor = Color.Yellow
                                Else 'if ung stat is null
                                    grddispatch.Item(21, grddispatch.CurrentRow.Index).Style.BackColor = Color.FromArgb(255, 255, 170)
                                End If
                            End If
                        End If
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbplate_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbplate.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbplate_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbplate.Leave
        getdriver()
    End Sub

    Public Sub getdriver()
        Try
            Me.Cursor = Cursors.WaitCursor

            If Trim(cmbplate.Text) <> "" Then
                If Not cmbplate.Items.Contains(Trim(cmbplate.Text.ToUpper)) Then
                    cmbplate.Text = ""
                    cmbtype.Text = ""
                    cmbdriver.Text = ""
                Else
                    sql = "Select * from tblgeneral where status='1'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    While dr.Read
                        Dim plnum As String = ""
                        If dr("platenum") = "" And dr("vplate") <> "" Then
                            plnum = dr("vplate")
                        ElseIf dr("platenum") = "" And dr("vplate") = "" And dr("csticker") <> "" Then
                            plnum = dr("csticker")
                        Else
                            plnum = dr("platenum")
                        End If
                        If plnum = Trim(cmbplate.Text.ToUpper) Then
                            cmbplate.SelectedItem = plnum
                            'cmbdriver.SelectedItem = dr("driver")
                            cmbtype.SelectedItem = dr("vtype")
                        End If
                    End While
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Else
                cmbdriver.SelectedItem = ""
                cmbplate.Text = ""
                cmbtype.Text = ""
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbplate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbplate.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789"
        Dim theText As String = cmbplate.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbplate.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbplate.Text.Length - 1
            Letter = cmbplate.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbplate.Text = theText
        cmbplate.Select(SelectionIndex - Change, 0)
    End Sub

    Public Sub driver()
        Try
            cmbdriver.Items.Clear()
            cmbdriver.Items.Add("")
            '/CType(Me.grdadd.Columns(10), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(10), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tbldriver order by driver"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbdriver.Items.Add(dr1("driver"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbdriver_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbdriver.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbdriver_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbdriver.Leave
        Try
            If Trim(cmbdriver.Text) <> "" Then

                sql = "Select * from tbldriver where driver='" & Trim(cmbdriver.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbdriver.SelectedItem = dr("driver")
                Else
                    cmbdriver.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

            Else
                cmbdriver.SelectedItem = ""
                cmbdriver.Text = ""
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub datefrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datefrom.ValueChanged
        dateto.MinDate = datefrom.Value
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            clickbtn = "Search"

            If Trim(txttrip.Text) <> "" Then
                sql = "Select tbltripsum.tripsumid, tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.etd, tbltripsum.datecreated, tbltripsum.createdby, tbltripsum.datemodified, tbltripsum.modifiedby,tbltripsum.status,tbltripsum.repair,"
                sql = sql & " vtype from tbltripsum RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
                sql = sql & " where tbltripsum.tripnum='" & lbltrip.Text & txttrip.Text & "' and tbltripsum.whsename='" & login.whse & "'"
            ElseIf Trim(txtref.Text) <> "" Then
                If cmbref.SelectedItem <> "" Then
                    sql = "SELECT tbltripsum.tripsumid, tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.etd, tbltripsum.datecreated, tbltripsum.createdby, tbltripsum.status, tbltripsum.datemodified, tbltripsum.modifiedby,tbltripsum.repair,"
                    sql = sql & " vtype FROM tbltripsum RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
                    sql = sql & " RIGHT OUTER JOIN tbltripitems ON tbltripsum.tripnum=tbltripitems.tripnum"
                    sql = sql & " RIGHT OUTER JOIN tblortrans ON tbltripitems.transnum=tblortrans.transnum "
                    sql = sql & " where tbltripsum.whsename='" & login.whse & "'"
                    sql = sql & " and tblortrans." & Trim(cmbref.Text) & "num='" & Trim(txtref.Text) & "'"
                    'If Trim(txtref.Text).Length >= 6 Then 'like
                    '    sql = sql & " and tblortrans." & Trim(cmbref.Text) & "num like '%" & Trim(txtref.Text) & "%'"
                    'ElseIf Trim(txtref.Text).Length = 3 Then 'equal
                    '    sql = sql & " and tblortrans." & Trim(cmbref.Text) & "num='" & Trim(txtref.Text) & "'"
                    'Else
                    '    sql = sql & " and tblortrans." & Trim(cmbref.Text) & "num='" & Trim(txtref.Text) & "'"
                    '    MsgBox("Invalid reference #.", MsgBoxStyle.Exclamation, "")
                    '    txtref.Focus()
                    '    Exit Sub
                    'End If
                Else
                    MsgBox("Select reference.", MsgBoxStyle.Exclamation, "")
                    cmbref.Focus()
                    Exit Sub
                End If
                If Trim(txtref.Text) = "TO FOLLOW" Then
                    sql = sql & " and (tbltripitems.status='1' or tbltripitems.status='2')"
                End If
                If chkhide.Checked = True Then
                    sql = sql & " and tbltripsum.status<>'3'"
                End If
                sql = sql & " Group by tbltripsum.tripsumid, tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.etd, tbltripsum.datecreated, tbltripsum.createdby, tbltripsum.status, tbltripsum.datemodified, tbltripsum.modifiedby, tbltripsum.repair, vtype"
                sql = sql & " order by tbltripsum.datepick"
                
            ElseIf Trim(cmbcus.Text) <> "" Then
                sql = "SELECT tbltripsum.tripsumid, tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.etd, tbltripsum.datecreated, tbltripsum.createdby, tbltripsum.status, tbltripsum.datemodified, tbltripsum.modifiedby,tbltripsum.repair,"
                sql = sql & " vtype FROM tbltripsum RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
                sql = sql & " RIGHT OUTER JOIN tbltripitems ON tbltripsum.tripnum=tbltripitems.tripnum"
                sql = sql & " RIGHT OUTER JOIN tblortrans ON tbltripitems.transnum=tblortrans.transnum "
                sql = sql & " where tbltripsum.datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and tbltripsum.datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "' and tbltripsum.whsename='" & login.whse & "' and tbltripitems.status<>'3'" 'and tbltripitems.status<>'0'
                If cmbplate.Text <> "" Then
                    sql = sql & " and tbltripsum.platenum='" & Trim(cmbplate.Text) & "'"
                End If
                If cmbdriver.Text <> "" Then
                    sql = sql & " and tbltripsum.driver='" & Trim(cmbdriver.Text) & "'"
                End If
                If cmbtype.Text <> "" Then
                    sql = sql & " and tblgeneral.vtype='" & Trim(cmbtype.Text) & "'"
                End If
                If cmbcus.Text <> "" Then
                    sql = sql & " and tblortrans.customer='" & Trim(cmbcus.Text) & "'"
                End If
                If chkhide.Checked = True Then
                    sql = sql & " and tbltripsum.status<>'3'"
                End If
                sql = sql & " Group by tbltripsum.tripsumid, tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.etd, tbltripsum.datecreated, tbltripsum.createdby, tbltripsum.status, tbltripsum.datemodified, tbltripsum.modifiedby, tbltripsum.repair, vtype"
                sql = sql & " order by tbltripsum.datepick"
            Else
                If Trim(cmbplate.Text) = "" And Trim(cmbdriver.Text) = "" And Trim(cmbtype.Text) = "" And Trim(cmbcus.Text) = "" And CDate(datefrom.Value) <> CDate(dateto.Value) Then
                    MsgBox("Invalid dates.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If

                'search with dates
                sql = "Select tbltripsum.tripsumid, tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.etd, tbltripsum.datecreated, tbltripsum.createdby, tbltripsum.datemodified, tbltripsum.modifiedby,tbltripsum.status, tbltripsum.repair,"
                sql = sql & " vtype from tbltripsum RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
                sql = sql & " where tbltripsum.datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and tbltripsum.datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "' and tbltripsum.whsename='" & login.whse & "'"
                If cmbplate.Text <> "" Then
                    sql = sql & " and tbltripsum.platenum='" & Trim(cmbplate.Text) & "'"
                End If
                If cmbdriver.Text <> "" Then
                    sql = sql & " and tbltripsum.driver='" & Trim(cmbdriver.Text) & "'"
                End If
                If cmbtype.Text <> "" Then
                    sql = sql & " and tblgeneral.vtype='" & Trim(cmbtype.Text) & "'"
                End If
                If chkhide.Checked = True Then
                    sql = sql & " and tbltripsum.status<>'3'"
                End If
                sql = sql & " order by tbltripsum.datepick"
            End If
            gridsql = sql

            grddispatch.Rows.Clear()

            lblloading.Visible = True
            Panel1.Enabled = False
            ProgressBar1.Style = ProgressBarStyle.Marquee
            ProgressBar1.Visible = True
            ProgressBar1.Minimum = 0

            backgroundWorker = New BackgroundWorker()
            backgroundWorker.WorkerSupportsCancellation = True
            backgroundWorkersteps = New BackgroundWorker()
            backgroundWorkersteps.WorkerSupportsCancellation = True
            backgroundWorkerdestin = New BackgroundWorker()
            backgroundWorkerdestin.WorkerSupportsCancellation = True

            '/ProgressBar1.Style = ProgressBarStyle.Marquee
            AddHandler backgroundWorker.DoWork, New DoWorkEventHandler(AddressOf backgroundWorker_DoWork)
            AddHandler backgroundWorker.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorker_Completed)
            AddHandler backgroundWorker.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorker_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            AddHandler backgroundWorkersteps.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkersteps_DoWork)
            AddHandler backgroundWorkersteps.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkersteps_Completed)
            AddHandler backgroundWorkersteps.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorkersteps_ProgressChanged)
            m_updateRowDelegate = New UpdateRowDelegate(AddressOf UpdateDGVRow)

            AddHandler backgroundWorkerdestin.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkerdestin_DoWork)
            AddHandler backgroundWorkerdestin.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkerdestin_Completed)
            AddHandler backgroundWorkerdestin.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorkerdestin_ProgressChanged)
            m_destinRowDelegate = New destinRowDelegate(AddressOf destinDGVRow)

            If Not backgroundWorker.IsBusy Then
                backgroundWorker.WorkerReportsProgress = True
                backgroundWorker.WorkerSupportsCancellation = True
                backgroundWorker.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txttrip_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttrip.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btnsearch.PerformClick()
        End If
    End Sub

    Private Sub txttrip_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttrip.TextChanged
        Dim charactersDisallowed As String = "0123456789-"
        Dim theText As String = txttrip.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txttrip.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txttrip.Text.Length - 1
            Letter = txttrip.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txttrip.Text = theText
        txttrip.Select(SelectionIndex - Change, 0)

        Dim str As String
        str = txttrip.Text
        If str.Length <> 0 Then
            Dim answer As Char
            answer = str.Substring(0, 1)
            If answer = "-" Then
                str = str.Substring(1, str.Length - 1)
                txttrip.Text = str
            End If
        End If

        If Trim(txttrip.Text) <> "" Then
            cmbplate.Enabled = False
            cmbtype.Enabled = False
            cmbcus.Enabled = False
            cmbdriver.Enabled = False
            datefrom.Enabled = False
            dateto.Enabled = False
            txtref.Enabled = False
            cmbref.Enabled = False
        Else
            cmbplate.Enabled = True
            cmbtype.Enabled = True
            cmbcus.Enabled = True
            cmbdriver.Enabled = True
            datefrom.Enabled = True
            dateto.Enabled = True
            txtref.Enabled = True
            cmbref.Enabled = True
        End If
    End Sub

    Private Sub btnprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub grddispatch_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles grddispatch.CellFormatting

    End Sub

    Private Sub grddispatch_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grddispatch.CellMouseClick
        Try
            If grddispatch.RowCount = 0 Then
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

            grddispatch.BeginEdit(True)
            If e.Button = Windows.Forms.MouseButtons.Right And e.ColumnIndex > -1 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grddispatch.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grddispatch.CurrentCell = cell
                If grddispatch.SelectedCells.Count = 1 Or grddispatch.SelectedRows.Count = 1 Then
                    If login.neym = "Guard" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                        Exit Sub
                    End If

                    If (e.ColumnIndex = 10 Or e.ColumnIndex = 11 Or e.ColumnIndex = 12 Or e.ColumnIndex = 14 Or e.ColumnIndex = 15 Or e.ColumnIndex = 16 Or e.ColumnIndex = 17 Or e.ColumnIndex = 18 Or e.ColumnIndex = 21) And grddispatch.SelectedCells.Count = 1 Then
                        CommentToolStripMenuItem.Visible = False
                        If Trim(grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(e.ColumnIndex).Value.ToString) <> "" Then
                            '                            CommentToolStripMenuItem.Visible = True
                            If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(e.ColumnIndex).Value.ToString.Contains("SKIPPED") Or grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(e.ColumnIndex).Value.ToString.Contains("RESCUE TRIP#") Then
                                CommentToolStripMenuItem.Visible = False
                            End If
                        End If

                    Else
                        CommentToolStripMenuItem.Visible = False
                    End If

                    AdvanceOpenStep9ToolStripMenuItem.Visible = False
                    AdjustDriverToolStripMenuItem.Visible = False
                    AdjustTimeDepartureToolStripMenuItem.Visible = False
                    SkipStepsToolStripMenuItem.Visible = False

                    If login.neym = "Administrator" Or login.neym = "Supervisor" Or login.neym = "Logistics Staff" Then
                        AdvanceOpenStep9ToolStripMenuItem.Visible = True
                        AdjustDriverToolStripMenuItem.Visible = True
                        AdjustTimeDepartureToolStripMenuItem.Visible = True
                        SkipStepsToolStripMenuItem.Visible = True
                    End If
                    Me.ContextMenuStrip1.Show(Cursor.Position)
                    'toolstripitems()
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grddispatch_CellPainting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles grddispatch.CellPainting
        If e.Handled Then
            Me.Cursor = Cursors.Default
            Exit Sub 'Already handled.
        End If

        Me.Cursor = Cursors.Default
        Exit Sub

        'Paint everything except the ErrorIcon the standard way.
        e.Paint(e.ClipBounds, e.PaintParts And Not DataGridViewPaintParts.ErrorIcon)

        'Paint the ErrorIcon, if necessary, the custom way.
        If (e.PaintParts And DataGridViewPaintParts.ErrorIcon) = DataGridViewPaintParts.ErrorIcon Then
            If e.ErrorText <> "" And (e.ColumnIndex >= 10 And e.ColumnIndex <= 21) Then

                With e.Graphics
                    Dim gstate As Drawing2D.GraphicsState = .Save()
                    Dim iconRect As Rectangle = New Rectangle(e.CellBounds.Right - 20, e.CellBounds.Top + e.CellBounds.Height \ 2 - 8, 16, 16)
                    Dim backColor As Color
                    If (e.State And DataGridViewElementStates.Selected) = DataGridViewElementStates.Selected Then
                        backColor = e.CellStyle.SelectionBackColor
                    Else
                        backColor = e.CellStyle.BackColor
                    End If

                    'Restrict drawing within cell boundaries.
                    .SetClip(e.CellBounds)
                    'Clear background area behind the icon.
                    Using brush As New SolidBrush(backColor)
                        .FillRectangle(brush, iconRect)
                    End Using
                    'Draw the icon.

                    .DrawIcon(SystemIcons.Information, iconRect)

                    .Restore(gstate)
                End With
            End If
        End If

        e.Handled = True
    End Sub

    Private Sub grddispatch_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grddispatch.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grddispatch.Rows(e.RowIndex)
            '<== But this is the name assigned to it in the properties of the control
            'If CDate(Format(dgvRow.Cells(1).Value, "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
            If dgvRow.Cells(0).Tag = 3 Then 'step1
                dgvRow.DefaultCellStyle.BackColor = Color.DeepSkyBlue
            ElseIf dgvRow.Cells(0).Tag = 1 Then
                If dgvRow.Cells(1).Value <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
                    dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
                End If

                If Date.Now >= CDate(Format(Date.Now, "yyyy/MM/dd 17:00")) And dgvRow.Cells(1).Value = CDate(Format(Date.Now, "yyyy/MM/dd")) And dgvRow.Cells(8).Value <= CDate(Format(Date.Now, "yyyy/MM/dd 17:00")) Then
                    dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
                End If
            End If

            If dgvRow.Cells(10).Tag = "True" Then 'step1
                dgvRow.Cells(10).Style.BackColor = Color.Yellow
            Else
                If Not dgvRow.Cells(10).Value.ToString.Contains("SAVE AS DRAFT") And Not dgvRow.Cells(10).Value.ToString.Contains("TIME START") And Not dgvRow.Cells(10).Value.ToString = "" Then
                    dgvRow.Cells(10).Style.BackColor = Color.FromArgb(255, 255, 170)
                End If
            End If

            If dgvRow.Cells(11).Tag = "True" Then 'step2
                dgvRow.Cells(11).Style.BackColor = Color.Yellow
            Else
                If Not dgvRow.Cells(11).Value.ToString.Contains("SAVE AS DRAFT") And Not dgvRow.Cells(11).Value.ToString.Contains("TIME START") And Not dgvRow.Cells(11).Value.ToString = "" Then
                    dgvRow.Cells(11).Style.BackColor = Color.FromArgb(255, 255, 170)
                End If
            End If

            If dgvRow.Cells(12).Tag = "True" Then 'step3
                dgvRow.Cells(12).Style.BackColor = Color.Yellow
            Else
                If Not dgvRow.Cells(12).Value.ToString.Contains("SAVE AS DRAFT") And Not dgvRow.Cells(12).Value.ToString.Contains("TIME START") And Not dgvRow.Cells(12).Value.ToString = "" Then
                    dgvRow.Cells(12).Style.BackColor = Color.FromArgb(255, 255, 170)
                End If
            End If

            If dgvRow.Cells(14).Tag = "True" Then 'step4
                dgvRow.Cells(14).Style.BackColor = Color.Yellow
            Else
                If Not dgvRow.Cells(14).Value.ToString.Contains("SAVE AS DRAFT") And Not dgvRow.Cells(14).Value.ToString.Contains("TIME START") And Not dgvRow.Cells(14).Value.ToString = "" Then
                    dgvRow.Cells(14).Style.BackColor = Color.FromArgb(255, 255, 170)
                End If
            End If

            If dgvRow.Cells(15).Tag = "True" Then 'step5
                dgvRow.Cells(15).Style.BackColor = Color.Yellow
            Else
                If Not dgvRow.Cells(15).Value.ToString.Contains("SAVE AS DRAFT") And Not dgvRow.Cells(15).Value.ToString.Contains("TIME START") And Not dgvRow.Cells(15).Value.ToString = "" Then
                    dgvRow.Cells(15).Style.BackColor = Color.FromArgb(255, 255, 170)
                End If
            End If

            If dgvRow.Cells(16).Tag = "True" Then 'step6
                dgvRow.Cells(16).Style.BackColor = Color.Yellow
            Else
                If Not dgvRow.Cells(16).Value.ToString.Contains("SAVE AS DRAFT") And Not dgvRow.Cells(16).Value.ToString.Contains("TIME START") And Not dgvRow.Cells(16).Value.ToString.Contains("Time Departure") And Not dgvRow.Cells(16).Value.ToString = "" Then
                    dgvRow.Cells(16).Style.BackColor = Color.FromArgb(255, 255, 170)
                End If
            End If

            If dgvRow.Cells(17).Tag = "True" Then 'step7
                dgvRow.Cells(17).Style.BackColor = Color.Yellow
            Else
                If Not dgvRow.Cells(17).Value.ToString.Contains("SAVE AS DRAFT") And Not dgvRow.Cells(17).Value.ToString.Contains("TIME START") And Not dgvRow.Cells(17).Value.ToString = "" Then
                    dgvRow.Cells(17).Style.BackColor = Color.FromArgb(255, 255, 170)
                End If
            End If

            If dgvRow.Cells(18).Tag = "True" Then 'step8
                dgvRow.Cells(18).Style.BackColor = Color.Yellow
            Else
                If Not dgvRow.Cells(18).Value.ToString.Contains("SAVE AS DRAFT") And Not dgvRow.Cells(18).Value.ToString.Contains("TIME START") And Not dgvRow.Cells(18).Value.ToString = "" Then
                    dgvRow.Cells(18).Style.BackColor = Color.FromArgb(255, 255, 170)
                End If
            End If

            If dgvRow.Cells(21).Tag = "True" Then 'step9
                dgvRow.Cells(21).Style.BackColor = Color.Yellow
            Else
                If Not dgvRow.Cells(21).Value.ToString.Contains("SAVE AS DRAFT") And Not dgvRow.Cells(21).Value.ToString.Contains("TIME START") And Not dgvRow.Cells(21).Value.ToString = "" Then
                    dgvRow.Cells(21).Style.BackColor = Color.FromArgb(255, 255, 170)
                End If
            End If
        End If
    End Sub

    Private Sub grddispatch_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grddispatch.SelectionChanged
        count()
    End Sub

    Public Sub count()
        Try
            lblcount.Text = "     Selected Rows Count: " & grddispatch.SelectedRows.Count
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnexport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexport.Click
        Try
            If grddispatch.Rows.Count <> 0 Then

                grdtemp.Rows.Clear()

                'Adding the Rows.
                For Each row As DataGridViewRow In grddispatch.Rows
                    grdtemp.Rows.Add()
                    For Each cell As DataGridViewCell In row.Cells
                        If cell.Value.ToString.Contains("SAVE AS DRAFT") = True Or cell.Value.ToString.Contains("TIME START") = True Then
                            grdtemp.Rows(grdtemp.Rows.Count - 1).Cells(cell.ColumnIndex).Value = ""
                        ElseIf cell.Value.ToString.Contains("(") = True Then
                            Dim f As Font = New Font("WingDings", 9, FontStyle.Bold, GraphicsUnit.Point)
                            grdtemp.Rows(grdtemp.Rows.Count - 1).Cells(cell.ColumnIndex).Style.Font = f
                            grdtemp.Rows(grdtemp.Rows.Count - 1).Cells(cell.ColumnIndex).Value = Convert.ToChar(&HF0FC)
                        Else
                            grdtemp.Rows(grdtemp.Rows.Count - 1).Cells(cell.ColumnIndex).Value = cell.Value
                        End If
                    Next
                Next
            End If

            Me.Cursor = Cursors.WaitCursor
            Dim objExcel As New Excel.Application
            Dim bkWorkBook As Excel.Workbook
            Dim shWorkSheet As Excel.Worksheet
            Dim misValue As Object = System.Reflection.Missing.Value

            Dim i As Integer
            Dim j As Integer

            Dim dfrom As String = Format(datefrom.Value, "MMMMddyyyy")
            Dim dto As String = Format(dateto.Value, "MMMMddyyyy")

            Dim daterange As String = dfrom & "_TO_" & dto
            Dim sfilename As String = login.whse & " Whse " & clickbtn & " Dispatch Sum from " & daterange & ".xls"

            objExcel = New Excel.Application
            bkWorkBook = objExcel.Workbooks.Add
            shWorkSheet = CType(bkWorkBook.ActiveSheet, Excel.Worksheet)

            With shWorkSheet
                .Range("A1", misValue).EntireRow.Font.Bold = True

                .Range("A1:T" & grdtemp.RowCount + 1).HorizontalAlignment = -4108
                .Range("A1:T" & grdtemp.RowCount + 1).VerticalAlignment = -4108
                .Range("A1:T" & grdtemp.RowCount + 1).Font.Size = 10
                'Set Clipboard Copy Mode     
                grdtemp.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
                grdtemp.SelectAll()
                grdtemp.RowHeadersVisible = False

                'Get the content from Grid for Clipboard     
                'Dim str As String = TryCast(grdtemp.GetClipboardContent().GetData(DataFormats.UnicodeText), String)
                Dim str As String = grdtemp.GetClipboardContent().GetData(DataFormats.UnicodeText)

                'Set the content to Clipboard     
                Clipboard.SetText(str, TextDataFormat.UnicodeText) 'TextDataFormat.UnicodeText)

                'Identify and select the range of cells in Excel to paste the clipboard data.     
                .Range("A1:T1", misValue).Select()

                'WIDTH
                .Range("A1:A" & grdtemp.RowCount + 1).ColumnWidth = 11
                .Range("B1:B" & grdtemp.RowCount + 1).ColumnWidth = 12
                .Range("C1:C" & grdtemp.RowCount + 1).ColumnWidth = 15
                .Range("D1:D" & grdtemp.RowCount + 1).ColumnWidth = 10
                .Range("E1:E" & grdtemp.RowCount + 1).ColumnWidth = 15
                .Range("G1:F" & grdtemp.RowCount + 1).ColumnWidth = 13
                .Range("H1:T" & grdtemp.RowCount + 1).ColumnWidth = 16

                'Paste the clipboard data     
                .Paste()
                Clipboard.Clear()

            End With

            'format alignment
            'shWorkSheet.Range("D2", "D" & grdtemp.RowCount + 1).HorizontalAlignment = Excel.XlHAlign.xlHAlignRight
            For i = 0 To grdtemp.RowCount + 4
                'shWorkSheet.Cells(i + 2, 1) = grd.Rows(i).Cells(1).Value
                shWorkSheet.Range("A1").EntireRow.NumberFormat = "MM/dd/yyyy"
            Next

            shWorkSheet.Range("A1:T" & grdtemp.RowCount + 1).WrapText = True

            'lagyan ng title na red door kit tska ung date na sakop ng report
            shWorkSheet.Range("A1").EntireRow.Insert()
            shWorkSheet.Range("A2").EntireRow.Insert()
            shWorkSheet.Range("A3").EntireRow.Insert()
            shWorkSheet.Cells(1, 1) = login.whse & " Warehouse"
            shWorkSheet.Cells(2, 1) = clickbtn & " Dispatch Sum from " & daterange
            shWorkSheet.Cells(1, 1).Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red)
            'shWorkSheet.Range("A1:Z" & grdtemp.RowCount + 1).WrapText = True

            Me.Cursor = Cursors.Default

            objExcel.Visible = False
            'objExcel.Application.DisplayAlerts = False

            Dim password As String = "AB123"
            'objExcel.ActiveWorkbook.SaveAs(Application.StartupPath & "sample.xls", FileFormat:=51, )
            '/bkWorkBook.SaveAs(Filename:=Application.StartupPath & "\template\" & sfilename, FileFormat:=51, Password:=password, CreateBackup:=False)
            bkWorkBook.SaveAs(Filename:=Application.StartupPath & "\template\" & sfilename, FileFormat:=51, CreateBackup:=False)

            bkWorkBook.Close(True, misValue, misValue)
            objExcel.Quit()

            'objExcel = Nothing

            releaseObject(bkWorkBook)
            releaseObject(shWorkSheet)
            releaseObject(objExcel)

            MessageBox.Show("Data Successfully Exported") ' & sfilename)
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As System.Runtime.InteropServices.COMException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " + ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub ViewTripInformationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewTripInformationToolStripMenuItem.Click
        Try
            Me.Cursor = Cursors.WaitCursor

            viewtripinfo.lblid.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(0).Value.ToString
            viewtripinfo.lbltripnum.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString
            viewtripinfo.Text = "Trip Information (" & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString & ")"
            viewtripinfo.ShowDialog()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub CommentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommentToolStripMenuItem.Click
        If grddispatch.SelectedCells.Count <> 1 Then
            Me.Cursor = Cursors.Default
            MsgBox("Select Only One", , "")
            Exit Sub
        End If


        If (grddispatch.CurrentCell.ColumnIndex = 10 Or grddispatch.CurrentCell.ColumnIndex = 11 Or grddispatch.CurrentCell.ColumnIndex = 12 Or grddispatch.CurrentCell.ColumnIndex = 14 Or grddispatch.CurrentCell.ColumnIndex = 15 Or grddispatch.CurrentCell.ColumnIndex = 16 Or grddispatch.CurrentCell.ColumnIndex = 17 Or grddispatch.CurrentCell.ColumnIndex = 18 Or grddispatch.CurrentCell.ColumnIndex = 21) And grddispatch.SelectedCells.Count = 1 Then
            tip = grddispatch.CurrentCell.ErrorText
            inputcomment.box.Text = tip
            inputcomment.box.Focus()
            inputcomment.ShowDialog()

            If inputcomment.cncel = False Then
                Dim cell As DataGridViewCell = grddispatch.CurrentCell
                cell.ErrorText = tip

                Try
                    If grddispatch.CurrentCell.ColumnIndex = 10 Then
                        sql = "Update tbldispatchsum set cneymstp1='" & login.cashier & "',cdeytstp1=GetDate(),comstp1='" & tip & "' where tripnum ='" & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & "'"

                    ElseIf grddispatch.CurrentCell.ColumnIndex = 11 Then
                        sql = "Update tbldispatchsum set cneymstp2='" & login.cashier & "',cdeytstp2=GetDate(),comstp2='" & tip & "' where tripnum ='" & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & "'"

                    ElseIf grddispatch.CurrentCell.ColumnIndex = 12 Then
                        sql = "Update tbldispatchsum set cneymstp3='" & login.cashier & "',cdeytstp3=GetDate(),comstp3='" & tip & "' where tripnum ='" & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & "'"

                    ElseIf grddispatch.CurrentCell.ColumnIndex = 14 Then
                        sql = "Update tbldispatchsum set cneymstp4='" & login.cashier & "',cdeytstp4=GetDate(),comstp4='" & tip & "' where tripnum ='" & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & "'"

                    ElseIf grddispatch.CurrentCell.ColumnIndex = 15 Then
                        sql = "Update tbldispatchsum set cneymstp5='" & login.cashier & "',cdeytstp5=GetDate(),comstp5='" & tip & "' where tripnum ='" & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & "'"

                    ElseIf grddispatch.CurrentCell.ColumnIndex = 16 Then
                        sql = "Update tbldispatchsum set cneymstp6='" & login.cashier & "',cdeytstp6=GetDate(),comstp6='" & tip & "' where tripnum ='" & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & "'"

                    ElseIf grddispatch.CurrentCell.ColumnIndex = 17 Then
                        sql = "Update tbldispatchsum set cneymstp7='" & login.cashier & "',cdeytstp7=GetDate(),comstp7='" & tip & "' where tripnum ='" & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & "'"

                    ElseIf grddispatch.CurrentCell.ColumnIndex = 18 Then
                        sql = "Update tbldispatchsum set cneymstp8='" & login.cashier & "',cdeytstp8=GetDate(),comstp8='" & tip & "' where tripnum ='" & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & "'"

                    ElseIf grddispatch.CurrentCell.ColumnIndex = 21 Then
                        sql = "Update tbldispatchsum set cneymstp9='" & login.cashier & "',cdeytstp9=GetDate(),comstp9='" & tip & "' where tripnum ='" & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & "'"
                    Else
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If

                    connect()
                    cmd = New SqlCommand(sql, conn) 'New OleDbCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    Me.Cursor = Cursors.Default
                Catch ex As System.InvalidOperationException
                    Me.Cursor = Cursors.Default
                    MsgBox(ex.Message, MsgBoxStyle.Critical, "")
                Catch ex As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox(ex.ToString, MsgBoxStyle.Information)
                Finally
                    disconnect()
                End Try
            End If
        End If
    End Sub

    Private Sub cmbtype_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbtype.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub tripdispatchsum_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.WindowState = FormWindowState.Maximized

        '/checkhasrows7()
        If hasrows7 = True Then
            '/pendingstep7.ShowDialog()
        End If

        '/checkhasrows8()
        If hasrows8 = True Then
            '/pendingstep8.ShowDialog()
        End If
    End Sub

    Public Sub checkhasrows7()
        Try
            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum INNER join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step7<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) Then
                        hasrows7 = True
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub checkhasrows8()
        Try
            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum INNER join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step8<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) Then
                        hasrows8 = True
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmbcus_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbcus.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbtype_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbtype.Leave
        If Trim(cmbtype.Text) <> "" Then
            Dim meron As Boolean = False
            For Each item As Object In cmbtype.Items
                If item = Trim(cmbtype.Text.ToUpper) Then
                    meron = True
                    Exit For
                End If
            Next

            If meron = False Then
                MsgBox("Invalid truck type.", MsgBoxStyle.Exclamation, "")
                cmbtype.Text = ""
                cmbtype.Focus()
            End If
        End If
    End Sub

    Private Sub cmbcus_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbcus.Leave
        If Trim(cmbcus.Text) <> "" Then
            Dim meron As Boolean = False
            For Each item As Object In cmbcus.Items
                If item = Trim(cmbcus.Text.ToUpper) Then
                    meron = True
                    Exit For
                End If
            Next

            If meron = False Then
                MsgBox("Invalid recipient.", MsgBoxStyle.Exclamation, "")
                cmbcus.Text = ""
                cmbcus.Focus()
            End If
        End If
    End Sub

    Private Sub cmbcus_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcus.SelectedIndexChanged

    End Sub

    Private Sub txtref_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtref.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btnsearch.PerformClick()
        End If
    End Sub

    Private Sub txtref_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtref.TextChanged
        Dim charactersDisallowed As String = "0123456789" ' if allowed ung to follow "toflwTOFLW1234567890 "
        Dim theText As String = txtref.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtref.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtref.Text.Length - 1
            Letter = txtref.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtref.Text = theText
        txtref.Select(SelectionIndex - Change, 0)

        If Trim(txtref.Text) <> "" Then
            cmbplate.Enabled = False
            cmbtype.Enabled = False
            cmbcus.Enabled = False
            cmbdriver.Enabled = False
            datefrom.Enabled = False
            dateto.Enabled = False
            txttrip.Enabled = False
        Else
            cmbplate.Enabled = True
            cmbtype.Enabled = True
            cmbcus.Enabled = True
            cmbdriver.Enabled = True
            datefrom.Enabled = True
            dateto.Enabled = True
            txttrip.Enabled = True
        End If
    End Sub

    Private Sub AdvanceOpenStep9ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AdvanceOpenStep9ToolStripMenuItem.Click
        Try
            Me.Cursor = Cursors.WaitCursor

            Dim aa9 As Boolean = False

            sql = "Select tripnum from tbldispatchsum where tripnum='" & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString & "' and complete=0 and step6=1"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                aa9 = True
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If aa9 = True Then
                Dim aa As String = MsgBox(grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString & "-Are you sure you want to advance open Step9?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                If aa = vbYes Then
                    sql = "Update tbldispatchsum set a9=1 where tripnum='" & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString & "' and complete=0"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully saved.", MsgBoxStyle.Information, "")
                End If
            Else
                MsgBox("Cannot advance open step 9.", MsgBoxStyle.Exclamation, "")
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub AdjustDriverToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AdjustDriverToolStripMenuItem.Click
        Try
            tripdriver.lblvtype.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(4).Value  'tinitignan kung JPSC or CUSTOMER OR TRUCKING
            tripdriver.driver()
            tripdriver.lblplate.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value.ToString
            tripdriver.lbltripnum.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value.ToString
            tripdriver.cmbdriver.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(5).Value.ToString
            tripdriver.fromform = "tripdispatchsum"
            tripdriver.ShowDialog()

            If clickbtn = "Search" Then
                btnsearch.PerformClick()
            Else
                btnview.PerformClick()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class