﻿Imports System.IO
Imports System.Data.SqlClient
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.Windows.Forms
Imports System.ComponentModel

Public Class rptvstatusprev
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim objRpt As New crvstatus, ds As New DataSet1
    Dim sqlquery As String, dscmd As SqlDataAdapter
    Public condition As String, cashr As String, ctr As Boolean = False
    Public printerneym As String

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub rptvstatusprev_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        loadexp()

        Dim plnum As String = ""
        Dim ds As New DataSet1
        Dim t As DataTable = ds.Tables.Add("Items")
        t.Columns.Add("Genid", Type.GetType("System.String"))
        t.Columns.Add("Company", Type.GetType("System.String"))
        t.Columns.Add("Warehouse", Type.GetType("System.String"))
        t.Columns.Add("Plate Number", Type.GetType("System.String"))
        t.Columns.Add("Vehicle Type", Type.GetType("System.String"))
        t.Columns.Add("Driver", Type.GetType("System.String"))
        t.Columns.Add("Description", Type.GetType("System.String"))
        t.Columns.Add("Status", Type.GetType("System.String"))
        t.Columns.Add("With Trip", Type.GetType("System.String"))


        Dim r As DataRow
        For Each row As DataGridViewRow In grdrm.Rows

            r = t.NewRow()
            r("Genid") = grdrm.Rows(row.Index).Cells(0).Value
            r("Company") = grdrm.Rows(row.Index).Cells(1).Value
            r("Warehouse") = grdrm.Rows(row.Index).Cells(2).Value
            If grdrm.Rows(row.Index).Cells(3).Value = "" Then
                sql = "Select * from tblgeneral where genid='" & grdrm.Rows(row.Index).Cells(0).Value & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    If dr("platenum") = "" And dr("vplate") <> "" Then
                        plnum = dr("vplate")
                    ElseIf dr("platenum") = "" And dr("vplate") = "" And dr("csticker") <> "" Then
                        plnum = dr("csticker")
                    Else
                        plnum = dr("platenum")
                    End If
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
                r("Plate Number") = plnum
            Else
                r("Plate Number") = grdrm.Rows(row.Index).Cells(3).Value
            End If

            r("Vehicle Type") = grdrm.Rows(row.Index).Cells(4).Value
            r("Driver") = grdrm.Rows(row.Index).Cells(5).Value
            r("Description") = grdrm.Rows(row.Index).Cells(6).Value
            r("Status") = grdrm.Rows(row.Index).Cells(7).Value
            r("With Trip") = grdrm.Rows(row.Index).Cells(8).Value

            t.Rows.Add(r)
        Next


        'MsgBox(ds.Tables("Items").Rows.Count)
        objRpt.SetDataSource(ds.Tables("Items"))
        CrystalReportViewer1.ReportSource = objRpt
        CrystalReportViewer1.Refresh()
    End Sub

    Public Sub loadexp()
        Try
            grdrm.Rows.Clear()

            'tblgeneral
            sql = "Select * from tblgeneral where status='1'" & condition
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                Dim plnum As String = ""
                If dr("platenum") = "" And dr("vplate") <> "" Then
                    plnum = dr("vplate")
                ElseIf dr("platenum") = "" And dr("vplate") = "" And dr("csticker") <> "" Then
                    plnum = dr("csticker")
                Else
                    plnum = dr("platenum")
                End If
                grdrm.Rows.Add(dr("genid"), dr("company"), dr("whsename"), plnum, dr("vtype"), dr("driver"), "")
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            For Each row As DataGridViewRow In grdrm.Rows
                Dim temp As String = ""
                sql = "Select * from tblrm where genid='" & grdrm.Rows(row.Index).Cells(0).Value & "' and finish='0'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                While dr.Read
                    If temp = "" Then
                        temp = dr("description")
                    Else
                        temp = temp & ", " & dr("description")
                    End If
                End While
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                grdrm.Item(6, row.Index).Value = temp
                If temp <> "" Then
                    grdrm.Item(7, row.Index).Value = "Under Repair"
                Else
                    grdrm.Item(7, row.Index).Value = "Good Condition"
                    grdrm.Item(6, row.Index).Value = "Running"
                End If

                Dim withsched As Boolean = False, withschedrems As String = ""
                sql = "Select * from tbltripsum where platenum='" & grdrm.Rows(row.Index).Cells(3).Value & "' and datepick='" & Format(datefrom.Value, "yyyy/MM/dd") & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    If dr("status") = 3 Then
                        withsched = True
                        withschedrems = ", but some transactions are cancelled."
                    Else
                        withsched = True
                    End If
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                If withsched = True Then
                    grdrm.Item(8, row.Index).Value = "Yes" & withschedrems
                Else
                    grdrm.Item(8, row.Index).Value = "None"
                End If
            Next

            'grdrm.Sort(grdrm.Columns(5), ListSortDirection.Ascending)

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class