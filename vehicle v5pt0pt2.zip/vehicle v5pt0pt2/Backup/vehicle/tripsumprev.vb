﻿Imports System.IO
Imports System.Data
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Windows.Forms

Public Class tripsumprev
    Dim objRpt As New crtripsum
    Dim ds As New DataSet

    Private Sub tripsumprev_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim mytext As TextObject = CType(objRpt.ReportDefinition.ReportObjects("Text116"), TextObject)
        mytext.Text = login.whse & " Warehouse"

        Dim mytext1 As TextObject = CType(objRpt.ReportDefinition.ReportObjects("Text113"), TextObject)
        mytext1.Text = tripsum.clickbtn & " Schedule from " & "Date: " & Format(CDate(tripsum.grdtrip.Rows(0).Cells(1).Value.ToString), "MM/dd/yyyy") & " - " & Format(tripsum.dateto.Value, "MM/dd/yyyy")

        Dim ds As New DataSet1
        Dim t As DataTable = ds.Tables.Add("Items")
        t.Columns.Add("Trip Date", Type.GetType("System.String"))
        t.Columns.Add("Trip No", Type.GetType("System.String"))
        t.Columns.Add("Plate No", Type.GetType("System.String"))
        t.Columns.Add("Driver", Type.GetType("System.String"))
        t.Columns.Add("Origin", Type.GetType("System.String"))
        t.Columns.Add("Destination", Type.GetType("System.String"))
        t.Columns.Add("ETD", Type.GetType("System.String"))
        t.Columns.Add("Time Departure", Type.GetType("System.String"))
        t.Columns.Add("Time Arrival", Type.GetType("System.String"))

        't.Columns.Add("Odometer (Previous)", Type.GetType("System.String"))
        't.Columns.Add("Actual Odometer (Start)", Type.GetType("System.String"))
        't.Columns.Add("Odometer (End)", Type.GetType("System.Double"))
        't.Columns.Add("Actual Distance", Type.GetType("System.Double"))
        't.Columns.Add("Distance w/ Load", Type.GetType("System.Double"))
        't.Columns.Add("Distance w/o Load", Type.GetType("System.Double"))
        't.Columns.Add("Total Distance", Type.GetType("System.Double"))
        't.Columns.Add("Variance (Actual Distance - Total Distance)", Type.GetType("System.Double"))

        't.Columns.Add("Diesel Should be", Type.GetType("System.Double"))
        't.Columns.Add("Diesel (Previous)", Type.GetType("System.Double"))
        't.Columns.Add("Actual Diesel (Beg)", Type.GetType("System.Double"))
        't.Columns.Add("PO Diesel", Type.GetType("System.Double"))
        't.Columns.Add("Add'l PO", Type.GetType("System.Double"))
        't.Columns.Add("Diesel (End)", Type.GetType("System.Double"))

        't.Columns.Add("Actual Diesel Used", Type.GetType("System.String"))
        't.Columns.Add("Variance (Actual Diesel - Diesel Should be)", Type.GetType("System.String"))
        't.Columns.Add("Load Scale", Type.GetType("System.Double"))

        t.Columns.Add("For Repair", Type.GetType("System.String"))
        't.Columns.Add("Rescued by", Type.GetType("System.String"))
        t.Columns.Add("Remarks", Type.GetType("System.String"))
        t.Columns.Add("Status", Type.GetType("System.String"))

        Dim r As DataRow
        For Each row As DataGridViewRow In tripsum.grdtrip.Rows
            r = t.NewRow()
            ' MsgBox(tripsum.grdtrip.Rows(row.Index).Cells(1).Value.ToString)
            r("Trip Date") = tripsum.grdtrip.Rows(row.Index).Cells(1).Value.ToString
            r("Trip No") = tripsum.grdtrip.Rows(row.Index).Cells(2).Value
            r("Plate No") = tripsum.grdtrip.Rows(row.Index).Cells(3).Value
            r("Driver") = tripsum.grdtrip.Rows(row.Index).Cells(5).Value
            r("Origin") = tripsum.grdtrip.Rows(row.Index).Cells(7).Value
            r("Destination") = tripsum.grdtrip.Rows(row.Index).Cells(8).Value
            r("ETD") = tripsum.grdtrip.Rows(row.Index).Cells(9).Value
            r("Time Departure") = tripsum.grdtrip.Rows(row.Index).Cells(10).Value
            r("Time Arrival") = tripsum.grdtrip.Rows(row.Index).Cells(11).Value

            r("For Repair") = tripsum.grdtrip.Rows(row.Index).Cells(29).Value
            r("Remarks") = tripsum.grdtrip.Rows(row.Index).Cells(31).Value
            r("Status") = tripsum.grdtrip.Rows(row.Index).Cells(32).Value
            t.Rows.Add(r)
        Next

        'MsgBox(ds.Tables("Items").Rows.Count)
        objRpt.SetDataSource(ds.Tables("Items"))
        CrystalReportViewer1.ReportSource = objRpt
        CrystalReportViewer1.Refresh()
    End Sub
End Class