﻿Imports System.IO
Imports System.Data.SqlClient

Public Class tripaddexisting
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public existingcnf As Boolean = False
    Dim alljpscpickup As Boolean = True, alreadydisp As Integer = 0

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        grd.Rows.Clear()
        lbltemp.Text = ""
        txtdatepick.Text = ""
        txtdriver.Text = ""
        txthelper.Text = ""
        txtplate.Text = ""
        lblvtype.Text = ""
        txtrems.Text = ""
        lblrems.Text = ""
        txtorigin.Text = ""
        txtetd.Text = ""
        Me.Close()
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            'CHECK FIELDS

            'insert to tbltripsum
            '/loadtripnum()
            alreadydisp = 0
            If Trim(txttripnum.Text) = "" Then
                MsgBox("Input existing trip number.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            'load tbltripsum
            sql = "Select * from tbltripitems right outer join tblortrans on tbltripitems.transnum=tblortrans.transnum where tbltripitems.tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "' and tbltripitems.status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                'check kung meron na sa grd
                Dim meronyellow As Boolean = False
                For Each row As DataGridViewRow In grd.Rows
                    If grd.Rows(row.Index).Cells(0).Value = dr("transid") Then
                        meronyellow = True
                        Exit For
                    End If
                Next

                If meronyellow = False Then
                    grd.Rows.Add(dr("transid"), dr("transnum"), dr("refnum"), dr("customer"), dr("transtype"), "1")
                    grd.Rows(grd.Rows.Count - 1).DefaultCellStyle.BackColor = Color.Yellow
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            'check kung nasaang steps na
            If lblstat.Text = "On Queue" Or lblstat.Text = "In Step 1" Or lblstat.Text = "In Step 2" Or lblstat.Text = "In Step 3" Or lblstat.Text = "Released Documents" Or lblstat.Text = "Released Petty Cash" Then
                Executeupdatestep1to5(strconn)
                tripadd.btnview.PerformClick()
                Me.Close()

            Else
                'if nakalabas na yung truck tapos pinasched habang nasa byahe
                If lblstat.Text = "Dispatched" Or lblstat.Text = "Returned to Whse" Then
                    If lblvtype.Text = "TRUCKING TRUCK" Or lblvtype.Text = "CUSTOMER TRUCK" Then
                        '/Exit Sub
                    End If

                    Dim a As String
                    If lblstat.Text = "Dispatched" Then
                        a = MsgBox("Trip is already dispatched. Do you want to add existing trip?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                    ElseIf lblstat.Text = "Returned to Whse" Then
                        a = MsgBox("Trip is already returned to whse. Do you want to add existing trip?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                    End If

                    If a = vbYes Then
                        'check if all transaction type is contains JPSC and PICKUP 
                        alljpscpickup = True
                        For Each row As DataGridViewRow In grd.Rows
                            If grd.Rows(row.Index).Cells(4).Value.ToString.Contains("JPSC") = False Or grd.Rows(row.Index).Cells(4).Value.ToString.Contains("PICKUP") = False Then
                                alljpscpickup = False
                                Exit For
                            End If
                        Next

                        existingcnf = False
                        confirmsave.GroupBox1.Text = login.neym
                        confirmsave.ShowDialog()
                        If existingcnf = True Then
                            ExecuteupdateStep6to9(strconn)
                            tripadd.btnview.PerformClick()
                            Me.Close()
                        Else
                            Exit Sub
                        End If
                    Else
                        txtplate.Text = ""
                        lblvtype.Text = ""
                        txtdriver.Text = ""
                        txthelper.Text = ""
                        txtetd.Text = ""
                        txtdatepick.Text = ""
                        txtorigin.Text = ""
                        txttripnum.Text = ""
                        txttripnum.Focus()
                        Exit Sub
                    End If
                Else
                    MsgBox("Cannot add transaction to existing trip.", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub Executeupdatestep1to5(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            ' Start a local transaction
            transaction = connection.BeginTransaction("AddToExistingTransaction")

            ' Must assign both transaction object and connection 
            ' to Command object for a pending local transaction.
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                'icheck kung may trip na ung mga nasa datagridview
                For Each row As DataGridViewRow In grd.Rows
                    If grd.Rows(row.Index).Cells(5).Value = "0" Then
                        Dim trans As String = grd.Rows(row.Index).Cells(1).Value
                        sql = "Select * from tbltripitems where transnum='" & trans & "' and (status='1' or status='2')"
                        command.CommandText = sql
                        dr = command.ExecuteReader
                        If dr.Read Then
                            'may tripnumber na createdby
                            MsgBox("Transaction# " & trans & " is already included in trip# " & dr("tripnum") & " createdby " & dr("createdby") & ".", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If
                        dr.Dispose()
                    End If
                Next
                
                'check yung transaction type
                If lblvtype.Text = "CUSTOMER TRUCK" Then
                    Dim cuswhse As Boolean = False, cupier As Boolean = False
                    For Each row As DataGridViewRow In grd.Rows
                        If grd.Rows(row.Index).Cells(4).Value.ToString.Contains("CUSTOMER SALES TRANSACTION PICKUP FRM ") Then '/And Not grd.Rows(row.Index).Cells(4).Value.ToString.Contains("AGI") Then
                            cupier = True
                            Exit For
                        End If
                        If grd.Rows(row.Index).Cells(4).Value = "CUSTOMER SALES TRANSACTION WHSE" Then
                            cuswhse = True
                            Exit For
                        End If
                    Next

                    If cupier = True Then
                        'CUSTOMER DIRECT PICKUP FRM PIER STEP7 AND 9 LANG
                        '/sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks) values ('" & lbltripnum.Text & "', '1','', '1','', '1','', '1','', '1','', '1','', '0', '', '1', '', '0', '', '', '0', '')"
                        sql = "Update tbldispatchsum set step7='0',step9='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
                    Else
                        If cuswhse = True Then
                            'customer pickup from whse may loading STEP 3, 4, 6, 7, 9 LANG
                            '/sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks) values ('" & lbltripnum.Text & "', '1','', '1','', '0','', '0','', '1','', '0','', '0', '', '1', '', '0', '', '', '0', '')"
                            sql = "Update tbldispatchsum set step3='0',step4='0',step6='0',step7='0',step9='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"

                        Else
                            'customer pickup from agi WLNG LOADING STEP 4, 6, 7, 9 LANG
                            '/sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks) values ('" & lbltripnum.Text & "', '1','', '1','', '1','', '0','', '1','', '0','', '0', '', '1', '', '0', '', '', '0', '')"
                            sql = "Update tbldispatchsum set step4='0',step6='0',step7='0',step9='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"

                        End If
                    End If

                ElseIf lblvtype.Text = "TRUCKING TRUCK" Then

                    Dim trwhse As Boolean = False, tragipier As Boolean = False
                    For Each row As DataGridViewRow In grd.Rows
                        If grd.Rows(row.Index).Cells(4).Value = "TRUCKING SALES TRANSACTION WHSE" Or grd.Rows(row.Index).Cells(4).Value = "TRUCKING STOCK TRANSFER WHSE TO WHSE" Then
                            trwhse = True
                            Exit For
                        End If
                        If (grd.Rows(row.Index).Cells(4).Value.ToString.Contains("TRUCKING SALES TRANSACTION PICKUP FRM ") Or grd.Rows(row.Index).Cells(4).Value.ToString.Contains("TRUCKING STOCK TRANSFER PICKUP FRM ")) And (grd.Rows(row.Index).Cells(4).Value.ToString.Contains("AGI") Or grd.Rows(row.Index).Cells(4).Value.ToString.Contains("PIER")) Then
                            tragipier = True
                            Exit For
                        End If
                    Next

                    If trwhse = True Then
                        'TRUCKING SALES TRANSACTION WHSE 3, 4, 6, 7, 9 LANG
                        '/sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks) values ('" & lbltripnum.Text & "', '1','', '1','', '0','', '0','', '1','', '0','', '0', '', '1', '', '0', '', '', '0', '')"
                        sql = "Update tbldispatchsum set step3='0',step4='0',step6='0',step7='0',step9='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"

                    Else
                        If tragipier = True Then
                            'STEP 4, 6, 7, 9 LANG
                            '/sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks) values ('" & lbltripnum.Text & "', '1','', '1','', '1','', '0','', '1','', '0','', '0', '', '1', '', '0', '', '', '0', '')"
                            sql = "Update tbldispatchsum set step4='0',step6='0',step7='0',step9='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"

                        Else
                            'STEP 7, 9 LANG
                            '/sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks) values ('" & lbltripnum.Text & "', '1','', '1','', '1','', '1','', '1','', '1','', '0', '', '1', '', '0', '', '', '0', '')"
                            sql = "Update tbldispatchsum set step7='0',step9='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
                        End If
                    End If

                Else
                    '/sql = "Insert into tbldispatchsum (tripnum, step1, namestp1, step2, namestp2, step3, namestp3, step4, namestp4, step5, namestp5, step6, namestp6, step7, namestp7, step8, namestp8, step9, namestp9, rescue, complete, remarks) values ('" & lbltripnum.Text & "', '0','', '0','', '0','', '0','', '0','', '0','', '0', '', '0', '', '0', '', '', '0', '')"
                    Dim allpickup As Boolean = False, withpupagic3 As Boolean = False
                    For Each row As DataGridViewRow In grd.Rows
                        If grd.Rows(row.Index).Cells(4).Value.ToString.Contains("PICKUP") = True Then
                            allpickup = True
                            If (grd.Rows(row.Index).Cells(4).Value.ToString.Contains("FRM AGI") = True Or grd.Rows(row.Index).Cells(4).Value.ToString.Contains("FRM LUDO LUYM") = True) And login.whse = "C3 Manila" Then
                                withpupagic3 = True
                            End If
                        Else
                            allpickup = False
                            Exit For
                        End If
                    Next

                    Dim addtlallpickup As Boolean = False, addtlwithpupagic3 As Boolean = False
                    For Each row As DataGridViewRow In grd.Rows
                        Dim stat As String = grd.Rows(row.Index).Cells(5).Value
                        If stat = 0 Then
                            If grd.Rows(row.Index).Cells(4).Value.ToString.Contains("PICKUP") = True Then
                                addtlallpickup = True
                                If (grd.Rows(row.Index).Cells(4).Value.ToString.Contains("FRM AGI") = True Or grd.Rows(row.Index).Cells(4).Value.ToString.Contains("FRM LUDO LUYM") = True) And login.whse = "C3 Manila" Then
                                    addtlwithpupagic3 = True
                                End If
                            Else
                                addtlallpickup = False
                                Exit For
                            End If
                        End If
                    Next


                    If lbltaxi.Text = "" Then
                        If allpickup = False Then
                            If addtlallpickup = True Then
                                'meaning yung mga idadagdag is allpickp

                                If addtlwithpupagic3 = False Then
                                    'no need to open step3 kasi yung mga i aadd is all pup          2, 4 lang
                                    '/MsgBox("no need to open step3")
                                    sql = "Update tbldispatchsum set step2='0',step4='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"

                                ElseIf addtlwithpupagic3 = True Then
                                    'no need to open step3 kasi yung mga i aadd is all pup          2  lang
                                    '/MsgBox("no need to open step3 and step4 kung c3")
                                    sql = "Update tbldispatchsum set step2='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
                                End If

                            ElseIf addtlallpickup = False Then
                                'open step3 kasi may mga i aadd na sales transaction         2, 3, 4 lang
                                '/MsgBox("open step3")
                                sql = "Update tbldispatchsum set step2='0',step3='0',step4='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
                            End If

                        Else  'ETO UNG MGA PICKUP AGI OR PIER WALANG STEP3 DUN KASI WALA NMNG LOADING
                            If addtlwithpupagic3 = False Then
                                '/MsgBox("open step4")
                                sql = "Update tbldispatchsum set step2='0',step4='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"

                            ElseIf addtlwithpupagic3 = True Then
                                '/MsgBox("no need to open step4 kung c3")
                                sql = "Update tbldispatchsum set step2='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
                            End If

                        End If


                        '//////////////////////////////////////////////////
                    ElseIf lbltaxi.Text = "Taxi" Then
                        'DERETSO NA SA CHECKING KUNG ADDTLALLPICKUP OR NOT KASI PURO ADDTL LNG DIN UNG NASA GRD SINCE TAXI NGA SYA BEFORE

                        If addtlallpickup = True Then
                            'meaning yung mga idadagdag is allpickp

                            If addtlwithpupagic3 = False Then
                                'no need to open step3 kasi yung mga i aadd is all pup          2, 4, 5, 7 lang
                                '/MsgBox("no need to open step3 ---   2, 4, 5, 7 lang")
                                sql = "Update tbldispatchsum set step2='0',step4='0',step5='0',step7='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"

                            ElseIf addtlwithpupagic3 = True Then
                                'no need to open step3 kasi yung mga i aadd is all pup          2, 5, 7  lang
                                '/MsgBox("no need to open step3 and step4 kung c3  -----  2, 5, 7  lang")
                                sql = "Update tbldispatchsum set step2='0',step5='0',step7='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
                            End If

                        ElseIf addtlallpickup = False Then
                            'open step3 kasi may mga i aadd na sales transaction         2, 3, 4, 5, 7 lang
                            '/MsgBox("open step3 ---- 2, 3, 4, 5, 7 lang")
                            sql = "Update tbldispatchsum set step2='0',step3='0',step4='0',step5='0',step7='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
                        End If
                    End If
                End If

                command.CommandText = sql
                command.ExecuteNonQuery()

                '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                'insert to tbltripitems
                For Each row As DataGridViewRow In grd.Rows
                    Dim stat As String = grd.Rows(row.Index).Cells(5).Value
                    If stat = 0 Then
                        'sql = "Insert into tbltripitems (tripnum, transnum, transtype, datecreated, createdby, datemodified, modifiedby, alreadydisp, status) values ('" & lbltrip.Text & Trim(txttripnum.Text) & "','" & grd.Rows(row.Index).Cells(1).Value & "','" & grd.Rows(row.Index).Cells(4).Value & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "','" & alreadydisp & "','1')"
                        'command.CommandText = sql
                        'command.ExecuteNonQuery()
                        Dim cus As String = grd.Rows(row.Index).Cells(3).Value
                        sql = "Insert into tbltripitems (tripnum, transnum, transtype, datecreated, createdby, datemodified, modifiedby, alreadydisp, status, record)"
                        sql = sql & " values ('" & lbltrip.Text & Trim(txttripnum.Text) & "','" & grd.Rows(row.Index).Cells(1).Value & "','" & grd.Rows(row.Index).Cells(4).Value & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "','" & alreadydisp & "','1',"
                        sql = sql & "(Select record from tblcustomer where customer='" & cus & "' and status='1'))"
                        command.CommandText = sql
                        command.ExecuteNonQuery()
                    End If
                Next


                'update status ng so In Process na sya 
                For Each row As DataGridViewRow In grd.Rows
                    sql = "Update tblortrans set status='0', datemodified=GetDate(), modifiedby='" & login.cashier & "' where transnum='" & grd.Rows(row.Index).Cells(1).Value & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                    If grd.Rows(row.Index).Cells(2).Value.ToString.Contains("SWS#") Then
                        Dim data As Byte(), imgname As String = ""
                        command.CommandText = "Select * from tblorimage where transnum='" & grd.Rows(row.Index).Cells(1).Value & "'"
                        dr = command.ExecuteReader
                        If dr.Read Then
                            imgname = dr("name")
                            data = DirectCast(dr("img"), Byte())
                            'isang picture lang yung massave kada transnum
                        End If
                        dr.Dispose()
                        '/cmd.Dispose()
                        '/conn.Close()

                        command.Parameters.Clear()
                        command.CommandText = "Insert into tbldispatchstp4 values(@tripnum,@name,@img,@status,GetDate(),@createdby)"
                        command.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltripnum.Text))
                        command.Parameters.Add(New SqlClient.SqlParameter("name", imgname))
                        command.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                        Dim img As New SqlParameter("@img", SqlDbType.Image)
                        img.Value = data
                        command.Parameters.Add(img)
                        '/command.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                        command.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                        command.ExecuteNonQuery()
                    End If
                Next

                sql = "Update tbltripsum set taxi='0', remarks='" & txtrems.Text & "' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()
                

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully Added Trip", MsgBoxStyle.Information, "")
                btncancel.PerformClick()
                tripadd.cmbplate.Text = ""
                tripadd.cmbdriver.Text = ""
                tripadd.txtrems.Text = ""
                tripadd.cmbwhse.Text = ""
                tripadd.txtetd.Text = ""
                tripadd.defaultload()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                '/Console.WriteLine("Commit Exception Type: {0}", ex.GetType())
                '/Console.WriteLine("  Message: {0}", ex.Message)
                '/Dim typeName = ex.GetType().Name
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    ' This catch block will handle any errors that may have occurred 
                    ' on the server that would cause the rollback to fail, such as 
                    ' a closed connection.
                    Me.Cursor = Cursors.Default
                    '/Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType())
                    '/Console.WriteLine("  Message: {0}", ex2.Message)
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Click Confirm again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub ExecuteupdateStep6to9(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            ' Start a local transaction
            transaction = connection.BeginTransaction("SampleTransaction")

            ' Must assign both transaction object and connection 
            ' to Command object for a pending local transaction.
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                'icheck kung may trip na ung mga nasa datagridview
                For Each row As DataGridViewRow In grd.Rows
                    If grd.Rows(row.Index).Cells(5).Value = "0" Then
                        Dim trans As String = grd.Rows(row.Index).Cells(1).Value
                        sql = "Select * from tbltripitems where transnum='" & trans & "' and (status='1' or status='2')"
                        command.CommandText = sql
                        dr = command.ExecuteReader
                        If dr.Read Then
                            'may tripnumber na createdby
                            MsgBox("Transaction# " & trans & " is already included in trip# " & dr("tripnum") & " createdby " & dr("createdby") & ".", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If
                        dr.Dispose()
                    End If
                Next
                
                If lblstat.Text = "Dispatched" Then
                    alreadydisp = 1
                ElseIf lblstat.Text = "Returned to Whse" Then
                    alreadydisp = 2
                End If

                'MsgBox("confirm add to existing")
                'if taxi dapat i-open yung step7
                If lbltaxi.Text = "Taxi" Then
                    sql = "Update tbldispatchsum set step7='0' where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                End If

                '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                'insert to tbltripitems
                For Each row As DataGridViewRow In grd.Rows
                    Dim stat As String = grd.Rows(row.Index).Cells(5).Value
                    If stat = 0 Then
                        'sql = "Insert into tbltripitems (tripnum, transnum, transtype, datecreated, createdby, datemodified, modifiedby, alreadydisp, status) values ('" & lbltrip.Text & Trim(txttripnum.Text) & "','" & grd.Rows(row.Index).Cells(1).Value & "','" & grd.Rows(row.Index).Cells(4).Value & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "','" & alreadydisp & "','1')"
                        'command.CommandText = sql
                        'command.ExecuteNonQuery()

                        Dim cus As String = grd.Rows(row.Index).Cells(3).Value
                        sql = "Insert into tbltripitems (tripnum, transnum, transtype, datecreated, createdby, datemodified, modifiedby, alreadydisp, status, record)"
                        sql = sql & " values ('" & lbltrip.Text & Trim(txttripnum.Text) & "','" & grd.Rows(row.Index).Cells(1).Value & "','" & grd.Rows(row.Index).Cells(4).Value & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "','" & alreadydisp & "','1',"
                        sql = sql & "(Select record from tblcustomer where customer='" & cus & "' and status='1'))"
                        command.CommandText = sql
                        command.ExecuteNonQuery()
                    End If
                Next


                'update status ng so In Process na sya 
                For Each row As DataGridViewRow In grd.Rows
                    Dim stat As String = grd.Rows(row.Index).Cells(5).Value
                    If stat = 0 Then
                        sql = "Update tblortrans set status='0', datemodified=GetDate(), modifiedby='" & login.cashier & "' where transnum='" & grd.Rows(row.Index).Cells(1).Value & "'"
                        command.CommandText = sql
                        command.ExecuteNonQuery()
                    End If
                Next

                sql = "Update tbltripsum set remarks='" & txtrems.Text & "'  where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully Added Trip", MsgBoxStyle.Information, "")
                btncancel.PerformClick()
                tripadd.cmbplate.Text = ""
                tripadd.cmbdriver.Text = ""
                tripadd.txtrems.Text = ""
                tripadd.cmbwhse.Text = ""
                tripadd.txtetd.Text = ""
                tripadd.defaultload()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                '/Console.WriteLine("Commit Exception Type: {0}", ex.GetType())
                '/Console.WriteLine("  Message: {0}", ex.Message)
                '/Dim typeName = ex.GetType().Name
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    ' This catch block will handle any errors that may have occurred on the server that would cause the rollback to fail, such as a closed connection.
                    Me.Cursor = Cursors.Default
                    '/Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType())
                    '/Console.WriteLine("  Message: {0}", ex2.Message)
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Click Confirm again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub tripaddexisting_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        grd.Rows.Clear()
        lbltemp.Text = ""
        txtdatepick.Text = ""
        txtdriver.Text = ""
        txthelper.Text = ""
        txtplate.Text = ""
        lblvtype.Text = ""
        txtrems.Text = ""
        lblrems.Text = ""
        txtorigin.Text = ""
        txtetd.Text = ""
        txttripnum.Text = ""
    End Sub

    Private Sub tripaddconfirm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '/loadtripnum()

        lbltrip.Text = login.whsecode

    End Sub

    Public Sub loadtripnum()
        Try
            Dim trnum As String = "1", temp As String = ""
            sql = "Select Top 1 * from tbltripsum order by tripsumid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                '/trnum = Val(dr("tripsumid")) + 1
            End If
            cmd.Dispose()
            dr.Dispose()
            conn.Close()

            'check kung pang ilang LOGSHEET NA SA YEAR NA 2018 na
            sql = "Select Count(tripsumid) from tbltripsum where tripyear=Year(GetDate()) and whsename='" & login.whse & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            trnum = cmd.ExecuteScalar + 1
            cmd.Dispose()
            conn.Close()

            Dim prefix As String = ""
            If login.whse = "C3 Manila" Then
                prefix = "MNL"
            ElseIf login.whse = "Calamba" Then
                prefix = "CAL"
            ElseIf login.whse = "Pagbilao" Then
                prefix = "PGB"
            ElseIf login.whse = "Lucena" Then
                prefix = "LUC"
            ElseIf login.whse = "Milaor" Then
                prefix = "MIL"
            ElseIf login.whse = "Lc Office" Then
                prefix = "LCO"
            ElseIf login.whse = "Cebu" Then
                prefix = "CEB"
            ElseIf login.whse = "Davao" Then
                prefix = "DAV"
            ElseIf login.whse = "Bacolod" Then
                prefix = "BCD"
            ElseIf login.whse = "Tacloban" Then
                prefix = "TAC"
            ElseIf login.whse = "JP-Store" Then
                prefix = "JST"
            End If

            If trnum < 1000000 Then
                For vv As Integer = 1 To 6 - trnum.Length
                    temp += "0"
                Next
                'lbltripnum.Text = Date.Now.Year & "-" & Format(Date.Now, "MM") & Format(Date.Now, "dd") & temp & trnum
            End If

            lbltripnum.Text = "T." & prefix & "-" & Format(Date.Now, "yy") & "-" & temp & trnum

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grd_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grd.CellContentClick
        'link
        If e.ColumnIndex = 1 And e.RowIndex > -1 Then
            Dim cell As DataGridViewCell = grd.Rows(e.RowIndex).Cells(e.ColumnIndex)
            grd.CurrentCell = cell
            ' Me.ContextMenuStrip2.Show(Cursor.Position)
            If grd.RowCount <> 0 Then
                If grd.Item(1, grd.CurrentRow.Index).Value IsNot Nothing Then
                    'MsgBox(grd.Item(12, ii).Value.ToString)
                    viewtrans.txttrans.Text = grd.Item(1, grd.CurrentRow.Index).Value
                    viewtrans.ShowDialog()
                End If
            End If
        End If
    End Sub

    Private Sub txttripnum_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttripnum.KeyPress
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            searchtrip()
        End If
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txttripnum_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txttripnum.Leave
        searchtrip()
    End Sub

    Private Sub txttripnum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttripnum.TextChanged
        Dim charactersDisallowed As String = "0123456789-"
        Dim theText As String = txttripnum.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txttripnum.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txttripnum.Text.Length - 1
            Letter = txttripnum.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txttripnum.Text = theText
        txttripnum.Select(SelectionIndex - Change, 0)
    End Sub

    Public Sub searchtrip()
        Try
            sql = "Select * from tbltripsum where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("status") = 1 Then
                    If dr("platenum").ToString <> lblplnum.Text Then
                        MsgBox("Plate number did not match.", MsgBoxStyle.Critical, "")
                        txttripnum.Text = ""
                        Exit Sub
                    End If

                    txtplate.Text = dr("platenum")
                    txtdriver.Text = dr("driver")
                    txthelper.Text = dr("helper").ToString
                    txtetd.Text = Format(dr("etd"), "yyyy/MM/dd HH:mm")
                    txtdatepick.Text = Format(dr("datepick"), "yyyy/MM/dd")
                    txtorigin.Text = dr("origin")
                    txtrems.Text = dr("remarks") + " " + lblrems.Text

                ElseIf dr("status") = 2 Then
                    MsgBox("Trip number " & Trim(txttripnum.Text) & " is already completed.", MsgBoxStyle.Critical, "")
                    cancel()
                    Exit Sub

                ElseIf dr("status") = 3 Then
                    MsgBox("Trip number " & Trim(txttripnum.Text) & " is already cancelled.", MsgBoxStyle.Critical, "")
                    cancel()
                    Exit Sub

                End If

            Else
                MsgBox("Cannot found trip number " & Trim(txttripnum.Text) & ".", MsgBoxStyle.Critical, "")
                cancel()
                Exit Sub
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            'vehicle type
            sql = "Select * from tblgeneral where platenum='" & txtplate.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                lblvtype.Text = dr("vtype")
                lblmake.Text = dr("makename")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            sql = "Select * from tbltripsum where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("status") = 1 Then
                    If Format(dr("datepick"), "yyyy/MM/dd") < Format(Date.Now, "yyyy/MM/dd") Then
                        '/MsgBox("Invalid date.", MsgBoxStyle.Exclamation, "")
                        '/txtplate.Text = ""
                        '/lblvtype.Text = ""
                        '/txtdriver.Text = ""
                        '/txthelper.Text = ""
                        '/txtetd.Text = ""
                        '/txtdatepick.Text = ""
                        '/txtorigin.Text = ""
                        '/txttripnum.Text = ""
                        '/txttripnum.Focus()
                        '/Exit Sub
                    End If

                    If lbltemp.Text = "CUSTOMER TRUCK" And lblvtype.Text <> "CUSTOMER TRUCK" Then
                        MsgBox("Invalid plate number.", MsgBoxStyle.Exclamation, "")
                        txtplate.Text = ""
                        lblvtype.Text = ""
                        txtdriver.Text = ""
                        txthelper.Text = ""
                        txtetd.Text = ""
                        txtdatepick.Text = ""
                        txtorigin.Text = ""
                        txttripnum.Text = ""
                        txttripnum.Focus()
                        Exit Sub
                    ElseIf lbltemp.Text = "TRUCKING TRUCK" And lblvtype.Text <> "TRUCKING TRUCK" Then
                        MsgBox("Invalid plate number.", MsgBoxStyle.Exclamation, "")
                        txtplate.Text = ""
                        lblvtype.Text = ""
                        txtdriver.Text = ""
                        txthelper.Text = ""
                        txtetd.Text = ""
                        txtdatepick.Text = ""
                        txtorigin.Text = ""
                        txttripnum.Text = ""
                        txttripnum.Focus()
                        Exit Sub
                    End If

                ElseIf dr("status") = 2 Then
                    MsgBox("Trip number " & Trim(txttripnum.Text) & " is already completed.", MsgBoxStyle.Critical, "")
                    cancel()
                    Exit Sub

                ElseIf dr("status") = 3 Then
                    MsgBox("Trip number " & Trim(txttripnum.Text) & " is already cancelled.", MsgBoxStyle.Critical, "")
                    cancel()
                    Exit Sub
                End If
            Else
                MsgBox("Cannot found trip number " & Trim(txttripnum.Text) & ".", MsgBoxStyle.Critical, "")
                cancel()
                Exit Sub
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            'status
            connect()
            sql = "Select * from tbldispatchsum where tripnum='" & lbltrip.Text & Trim(txttripnum.Text) & "'"
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Dim whatstep As String = "On Queue"

                If dr("step1") = 1 Then
                    If dr("rescue").ToString <> "" And dr("rescue").ToString <> "-" Then
                    ElseIf dr("namestp1").ToString = "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                    ElseIf dr("namestp1").ToString <> "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                        whatstep = "In Step 1"
                    End If
                End If
                If dr("step2") = 1 Then
                    If dr("rescue").ToString <> "" And dr("rescue").ToString <> "-" Then
                    ElseIf dr("namestp2").ToString = "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                    ElseIf dr("namestp2").ToString <> "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                        whatstep = "In Step 2"
                    End If
                End If
                If dr("step3") = 1 Then
                    If dr("rescue").ToString <> "" And dr("rescue").ToString <> "-" Then
                    ElseIf dr("namestp3").ToString = "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                    ElseIf dr("namestp3").ToString <> "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                        whatstep = "In Step 3"
                    End If
                End If
                If dr("step4") = 1 Then
                    If dr("rescue").ToString <> "" And dr("rescue").ToString <> "-" Then
                    ElseIf dr("namestp4").ToString = "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                    ElseIf dr("namestp4").ToString <> "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                        whatstep = "Released Documents"
                    End If
                End If
                If dr("step5") = 1 Then
                    If dr("rescue").ToString <> "" And dr("rescue").ToString <> "-" Then
                    ElseIf dr("namestp5").ToString = "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                    ElseIf dr("namestp5").ToString <> "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                        whatstep = "Released Petty Cash"
                        If IsDBNull(dr("timedep")) = False Then
                            whatstep = "Dispatched"
                        End If
                    End If
                End If
                If dr("step6") = 1 Then
                    If dr("rescue").ToString <> "" And dr("rescue").ToString <> "-" Then
                    ElseIf dr("namestp6").ToString = "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                    ElseIf dr("namestp6").ToString <> "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                        whatstep = "Returned to Whse"
                    End If
                End If
                If dr("step7") = 1 Then
                    If dr("rescue").ToString <> "" And dr("rescue").ToString <> "-" Then
                    ElseIf dr("namestp7").ToString = "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                    ElseIf dr("namestp7").ToString <> "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                        whatstep = "Returned to Whse"
                    End If

                    If IsDBNull(dr("startreturn")) = True Then
                        lbltaxi.Text = "Taxi"
                    Else
                        lbltaxi.Text = ""
                    End If

                End If
                If dr("step8") = 1 Then
                    If dr("rescue").ToString <> "" And dr("rescue").ToString <> "-" Then
                    ElseIf dr("namestp8").ToString = "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                    ElseIf dr("namestp8").ToString <> "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                        whatstep = "Returned to Whse"
                    End If
                End If
                If dr("step9") = 1 Then
                    If dr("namestp9").ToString = "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                    ElseIf dr("namestp9").ToString <> "" And (dr("rescue").ToString = "" Or dr("rescue").ToString = "-") Then
                    Else
                    End If

                    whatstep = "Completed"

                End If

                lblstat.Text = whatstep

            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            'check if tripnum in tbldispatchsum is not yet dispatched
            If lblstat.Text = "Completed" Then
                MsgBox("Trip is already completed.", MsgBoxStyle.Information, "")
                txtplate.Text = ""
                lblvtype.Text = ""
                txtdriver.Text = ""
                txthelper.Text = ""
                txtetd.Text = ""
                txtdatepick.Text = ""
                txtorigin.Text = ""
                txttripnum.Text = ""
                txttripnum.Focus()
                Exit Sub

            ElseIf lblstat.Text = "Dispatched" Or lblstat.Text = "Returned to Whse" Then

                'check if all transaction type is contains JPSC and PICKUP 
                alljpscpickup = True
                For Each row As DataGridViewRow In grd.Rows
                    If grd.Rows(row.Index).Cells(4).Value.ToString.Contains("JPSC") = False Or grd.Rows(row.Index).Cells(4).Value.ToString.Contains("PICKUP") = False Then
                        alljpscpickup = False
                        Exit For
                    End If
                Next

                If alljpscpickup = False Then

                Else
                    '/ confirmsave.ShowDialog()
                End If

            End If


        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub cancel()
        txtplate.Text = ""
        lblvtype.Text = ""
        txtdriver.Text = ""
        txthelper.Text = ""
        txtetd.Text = ""
        txtdatepick.Text = ""
        txtorigin.Text = ""
        lblmake.Text = ""
        txttripnum.Text = ""
        txttripnum.Focus()
    End Sub

    Private Sub tripaddexisting_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        
    End Sub
End Class