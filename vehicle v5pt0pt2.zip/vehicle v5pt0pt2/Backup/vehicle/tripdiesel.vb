﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Windows.Forms
Imports CrystalDecisions.ReportSource
Imports System.Drawing.Printing
Imports Excel = Microsoft.Office.Interop.Excel

Public Class tripdiesel
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public clickbtn As String = ""

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub tripdispatchsum_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated

    End Sub

    Private Sub tripdispatchsum_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim a As String = MsgBox("Are you sure you want to close?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            '/moduless.Show()
            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub tripdispatchsum_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cmbplate.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbplate.DropDownStyle = ComboBoxStyle.DropDown
        cmbplate.AutoCompleteSource = AutoCompleteSource.ListItems

        cmbdriver.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbdriver.DropDownStyle = ComboBoxStyle.DropDown
        cmbdriver.AutoCompleteSource = AutoCompleteSource.ListItems

        cmbtype.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbtype.DropDownStyle = ComboBoxStyle.DropDown
        cmbtype.AutoCompleteSource = AutoCompleteSource.ListItems

        datefrom.CustomFormat = "yyyy/MM/dd"
        dateto.CustomFormat = "yyyy/MM/dd"
        datefrom.MaxDate = Date.Now
        dateto.MinDate = datefrom.Value

        grdtrip.Columns(4).Frozen = True

        lbltrip.Text = login.whsecode

        plate()
        driver()
        vtype()
        viewall()
    End Sub

    Public Sub vtype()
        Try
            cmbtype.Items.Clear()
            cmbtype.Items.Add("")

            sql = "Select * from tblvtype order by vtype"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read

                cmbtype.Items.Add(dr1("vtype"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub plate()
        Try
            cmbplate.Items.Clear()
            cmbplate.Items.Add("")
            Dim plnum As String = ""

            sql = "Select * from tblgeneral"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                If dr1("platenum") = "" And dr1("vplate") <> "" Then
                    plnum = dr1("vplate")
                ElseIf dr1("platenum") = "" And dr1("vplate") = "" And dr1("csticker") <> "" Then
                    plnum = dr1("csticker")
                Else
                    plnum = dr1("platenum")
                End If

                cmbplate.Items.Add(plnum)
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub viewall()
        Try
            Me.Cursor = Cursors.WaitCursor

            clickbtn = "Pending"

            grdtrip.Rows.Clear()

            'sql = "Select * from tbltripsum where tbltripsum.status='1'"
            sql = "Select * from tbltripsum where status='1' and whsename='" & login.whse & "' order by datepick"
            connect()
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            While drx.Read
                Dim stat As String = "On Queue"

                Dim actualdis As Double = drx("odoend") - drx("odoactual")
                Dim totaldis As Double = drx("diswith") + drx("diswout")
                Dim vardis As Double = actualdis - totaldis

                Dim dieselused As Double = (drx("dieselactual") + drx("podiesel") + drx("addpo") + drx("postaddpo")) - drx("dieselend")
                Dim vardiesel As Double = dieselused - drx("dshould")

                Dim tdep As String = ""
                If Not IsDBNull(drx("timedep")) = True Then
                    tdep = Format(drx("timedep"), "yyyy/MM/dd HH:mm")
                End If

                Dim tarr As String = ""
                If Not IsDBNull(drx("timearr")) = True Then
                    tarr = Format(drx("timearr"), "yyyy/MM/dd HH:mm")
                End If

                grdtrip.Rows.Add(drx("tripsumid"), Format(drx("datepick"), "yyyy/MM/dd"), drx("tripnum"), drx("platenum"), "", drx("driver"), drx("helper").ToString, drx("origin"), "", drx("odostart"), drx("odoactual"), drx("odoend"), actualdis, drx("diswith"), drx("diswout"), totaldis, vardis, drx("dshould"), drx("dieselbeg"), drx("dieselactual"), drx("podiesel"), drx("addpo") + drx("postaddpo"), drx("dieselend"), dieselused, vardiesel, drx("remarks"), "", "", "", "")
                grdtrip.Item(9, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(10, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(11, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(12, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(13, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(14, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(15, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(16, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite

                grdtrip.Item(17, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(18, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(19, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(20, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(21, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(22, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(23, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(24, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold

                If drx("status") = 3 Then
                    grdtrip.Rows(grdtrip.Rows.Count - 1).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                End If
            End While
            drx.Dispose()
            cmdx.Dispose()
            conn.Close()

            destin()
            grdcolor()
            viewdispatch()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub destin()
        Try
            'truck type
            For Each row As DataGridViewRow In grdtrip.Rows
                sql = "Select * from tblgeneral where platenum='" & grdtrip.Rows(row.Index).Cells(3).Value & "' or vplate='" & grdtrip.Rows(row.Index).Cells(3).Value & "' or csticker='" & grdtrip.Rows(row.Index).Cells(3).Value & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    grdtrip.Item(4, row.Index).Value = dr("vtype")
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Next

            'destination
            Dim temp As String = "", temptype As String = ""
            For Each row As DataGridViewRow In grdtrip.Rows
                temp = ""
                temptype = ""
                sql = "SELECT * FROM tbltripitems RIGHT OUTER JOIN tblortrans ON tbltripitems.transnum=tblortrans.transnum where tbltripitems.tripnum='" & grdtrip.Rows(row.Index).Cells(2).Value & "' and tbltripitems.status<>'0' and tbltripitems.status<>'3'"
                connect()
                Dim cmd1x As SqlCommand = New SqlCommand(sql, conn)
                Dim dr1x As SqlDataReader = cmd1x.ExecuteReader
                While dr1x.Read
                    If temp = "" Then
                        temp = temp & dr1x("customer")
                    Else
                        temp = temp & " / " & dr1x("customer")
                    End If

                    If dr1x("transtype").ToString.Contains("PICKUP") Then
                        Dim inSql As String = dr1x("transtype").ToString
                        Dim lastPart As String
                        Dim fromStart As Integer
                        Dim firstpart As String

                        fromStart = inSql.IndexOf("FRM ") + 4

                        firstpart = inSql.Substring(0, fromStart - 4)
                        temptype = Trim(firstpart)

                        lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

                        temptype = lastPart & " "

                    End If

                End While
                dr1x.Dispose()
                cmd1x.Dispose()
                conn.Close()

                If temp = "" Then
                    temp = "Taxi"
                    grdtrip.Item(8, row.Index).Value = temp
                Else
                    If temptype = "" Then
                        grdtrip.Item(8, row.Index).Value = temp
                    Else
                        grdtrip.Item(8, row.Index).Value = "p/up " & temptype & "/ " & temp
                    End If
                End If

            Next

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        txttrip.Text = ""
        cmbplate.Enabled = True
        cmbtype.Enabled = True
        cmbdriver.Enabled = True
        datefrom.Enabled = True
        dateto.Enabled = True
        cmbplate.Text = ""
        cmbtype.Text = ""
        cmbdriver.Text = ""
        datefrom.Value = datefrom.MaxDate
        viewall()
    End Sub

    Private Sub grddispatch_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrip.CellClick

    End Sub

    Private Sub grddispatch_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrip.CellContentClick
        Try
            Me.Cursor = Cursors.WaitCursor

            'link
            If e.ColumnIndex = 2 And e.RowIndex > -1 Then

                Dim cell As DataGridViewCell = grdtrip.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrip.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdtrip.RowCount <> 0 Then
                    If grdtrip.Item(2, grdtrip.CurrentRow.Index).Value IsNot Nothing Then
                        'if taxi
                        If grdtrip.Item(8, grdtrip.CurrentRow.Index).Value IsNot Nothing And grdtrip.Item(8, grdtrip.CurrentRow.Index).Value = "Taxi" Then
                            Me.Cursor = Cursors.Default
                            MsgBox("No Transactions. Taxi only.", MsgBoxStyle.Information, "")
                            Me.Cursor = Cursors.Default
                            Exit Sub
                        End If

                        'viewtrans.txttrans.Text = grddispatch.Item(1, grddispatch.CurrentRow.Index).Value
                        'populate grdtrans
                        viewtrans.Text = "View Transactions (" & grdtrip.Item(2, grdtrip.CurrentRow.Index).Value.ToString & ")"
                        viewtrans.lbltripnum.Text = grdtrip.Item(2, grdtrip.CurrentRow.Index).Value.ToString
                        viewtrans.grdtrans.Rows.Clear()
                        sql = "Select * from tbltripitems where tripnum='" & grdtrip.Item(2, grdtrip.CurrentRow.Index).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        While dr.Read
                            viewtrans.grdtrans.Rows.Add(dr("transnum"))
                        End While
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        viewtrans.grouptrans.Visible = True
                        viewtrans.ShowDialog()
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbplate_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbplate.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbplate_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbplate.Leave
        getdriver()
    End Sub

    Public Sub getdriver()
        Try
            If Trim(cmbplate.Text) <> "" Then
                If Not cmbplate.Items.Contains(Trim(cmbplate.Text.ToUpper)) Then
                    cmbplate.Text = ""
                    cmbtype.Text = ""
                    cmbdriver.Text = ""
                Else
                    sql = "Select * from tblgeneral where status='1'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    While dr.Read
                        Dim plnum As String = ""
                        If dr("platenum") = "" And dr("vplate") <> "" Then
                            plnum = dr("vplate")
                        ElseIf dr("platenum") = "" And dr("vplate") = "" And dr("csticker") <> "" Then
                            plnum = dr("csticker")
                        Else
                            plnum = dr("platenum")
                        End If
                        If plnum = Trim(cmbplate.Text.ToUpper) Then
                            cmbplate.SelectedItem = plnum
                            'cmbdriver.SelectedItem = dr("driver")
                            cmbtype.SelectedItem = dr("vtype")
                        End If
                    End While
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Else
                cmbdriver.SelectedItem = ""
                cmbplate.Text = ""
                cmbtype.Text = ""
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbplate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbplate.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789"
        Dim theText As String = cmbplate.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbplate.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbplate.Text.Length - 1
            Letter = cmbplate.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbplate.Text = theText
        cmbplate.Select(SelectionIndex - Change, 0)
    End Sub

    Public Sub driver()
        Try
            cmbdriver.Items.Clear()
            cmbdriver.Items.Add("")
            '/CType(Me.grdadd.Columns(5), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(5), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tbldriver order by driver"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbdriver.Items.Add(dr1("driver"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbdriver_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbdriver.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbdriver_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbdriver.Leave
        Try
            If Trim(cmbdriver.Text) <> "" Then

                sql = "Select * from tbldriver where driver='" & Trim(cmbdriver.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbdriver.SelectedItem = dr("driver")
                Else
                    cmbdriver.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

            Else
                cmbdriver.SelectedItem = ""
                cmbdriver.Text = ""
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub datefrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datefrom.ValueChanged
        dateto.MinDate = datefrom.Value
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            Me.Cursor = Cursors.WaitCursor

            If Trim(txttrip.Text) <> "" Then
                tripsearch()
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

            grdtrip.Rows.Clear()

            clickbtn = "Search"

            '/sql = "Select * from tbltripsum where datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "' and whsename='" & login.whse & "'"
            sql = "SELECT * FROM tbltripsum RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum where tbltripsum.datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and tbltripsum.datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "' and tbltripsum.whsename='" & login.whse & "'"

            If cmbplate.Text <> "" Then
                sql = sql & " and tbltripsum.platenum='" & cmbplate.Text & "'"
            End If

            If cmbdriver.Text <> "" Then
                sql = sql & " and tbltripsum.driver='" & cmbdriver.Text & "'"
            End If

            If cmbtype.Text <> "" Then
                sql = sql & " and tblgeneral.vtype='" & cmbtype.Text & "'"
            End If

            sql = sql & " order by tbltripsum.datepick"

            connect()
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            While drx.Read
                Dim stat As String = ""
                If drx("status") = 1 Then
                    stat = "On Queue"
                ElseIf drx("status") = 0 Then
                    stat = "In Process"
                ElseIf drx("status") = 2 Then
                    stat = "Completed"
                ElseIf drx("status") = 3 Then
                    stat = "Cancelled"
                End If

                Dim actualdis As Double = drx("odoend") - drx("odoactual")
                Dim totaldis As Double = drx("diswith") + drx("diswout")
                Dim vardis As Double = actualdis - totaldis

                Dim dieselused As Double = (drx("dieselactual") + drx("podiesel") + drx("addpo") + drx("postaddpo")) - drx("dieselend")
                Dim vardiesel As Double = dieselused - drx("dshould")

                Dim tdep As String = ""
                If Not IsDBNull(drx("timedep")) = True Then
                    tdep = Format(drx("timedep"), "yyyy/MM/dd HH:mm")
                End If

                Dim tarr As String = ""
                If Not IsDBNull(drx("timearr")) = True Then
                    tarr = Format(drx("timearr"), "yyyy/MM/dd HH:mm")
                End If

                grdtrip.Rows.Add(drx("tripsumid"), Format(drx("datepick"), "yyyy/MM/dd"), drx("tripnum"), drx("platenum"), "", drx("driver"), drx("helper").ToString, drx("origin"), "", Format(drx("etd"), "HH:mm"), tdep, tarr, drx("odostart"), drx("odoactual"), drx("odoend"), actualdis, drx("diswith"), drx("diswout"), totaldis, vardis, drx("dshould"), drx("dieselbeg"), drx("dieselactual"), drx("podiesel"), drx("addpo") + drx("postaddpo"), drx("dieselend"), dieselused, vardiesel, drx("loadscale"), drx("repair"), drx("rescue"), drx("remarks"), stat, drx("datecreated"), drx("createdby"), drx("datemodified"), drx("modifiedby"))
                grdtrip.Item(12, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(13, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(14, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(15, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(16, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(17, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(18, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(19, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite

                grdtrip.Item(20, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(21, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(22, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(23, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(24, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(25, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(26, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(27, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold

                If drx("status") = 3 Then
                    grdtrip.Rows(grdtrip.Rows.Count - 1).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                End If
            End While
            drx.Dispose()
            cmdx.Dispose()
            conn.Close()


            destin()

            'status
            For Each row As DataGridViewRow In grdtrip.Rows
                sql = "Select * from tbldispatchsum where tripnum='" & grdtrip.Rows(row.Index).Cells(2).Value & "'"
                connect()
                cmdx = New SqlCommand(sql, conn)
                drx = cmdx.ExecuteReader
                If drx.Read Then
                    Dim whatstep As String = "On Queue"

                    If grdtrip.Item(32, row.Index).Value.ToString <> "Cancelled" Then
                        If drx("step1") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp1").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp1").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "In Step 1"
                            End If
                        End If
                        If drx("step2") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp2").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp2").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "In Step 2"
                            End If
                        End If
                        If drx("step3") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp3").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp3").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "In Step 3"
                            End If
                        End If
                        If drx("step4") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp4").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp4").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "Released Documents"
                            End If
                        End If
                        If drx("step5") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp5").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp5").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "Released Petty Cash"
                                If IsDBNull(drx("timedep")) = False Then
                                    whatstep = "Dispatched"
                                End If
                            End If
                        End If
                        If drx("step6") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp6").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp6").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "Returned to Whse"
                            End If
                        End If
                        If drx("step7") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp7").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp7").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "Returned to Whse"
                            End If
                        End If
                        If drx("step8") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp8").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp8").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "Returned to Whse"
                            End If
                        End If
                        If drx("step9") = 1 Then
                            If drx("namestp9").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp9").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            Else
                            End If

                            whatstep = "Completed"

                        End If

                        grdtrip.Item(32, row.Index).Value = whatstep

                    End If


                    If grdtrip.Rows(row.Index).Cells(29).Value.ToString = 1 Then
                        grdtrip.Rows(row.Index).Cells(29).Value = drx("remstp8")
                        grdtrip.Item(29, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                    End If
                End If
                drx.Dispose()
                cmdx.Dispose()
                conn.Close()
            Next


            grdcolor()

            viewdispatch()

            Me.Cursor = Cursors.Default

            If grdtrip.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrip_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdtrip.CellMouseClick
        Try
            If grdtrip.RowCount = 0 Then
                Me.Cursor = Cursors.Default
                Exit Sub
            End If
            grdtrip.BeginEdit(True)
            If e.Button = Windows.Forms.MouseButtons.Right And e.ColumnIndex > -1 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdtrip.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrip.CurrentCell = cell
                If grdtrip.SelectedCells.Count = 1 Or grdtrip.SelectedRows.Count = 1 Then
                    If login.neym = "Guard" Or login.neym = "Checker" Or login.neym = "Diesel Controller" Or login.neym = "Inspector" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                        Exit Sub
                    End If

                    If e.ColumnIndex = 31 Then
                        ' UpdateRemarksToolStripMenuItem.Visible = True
                    Else
                        ' UpdateRemarksToolStripMenuItem.Visible = False
                    End If
                    Me.ContextMenuStrip1.Show(Cursor.Position)
                    toolstripitems()
                End If
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub toolstripitems()

    End Sub

    Private Sub txttrip_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttrip.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            tripsearch()
        End If
    End Sub

    Private Sub txttrip_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttrip.TextChanged
        Dim charactersDisallowed As String = "0123456789"
        Dim theText As String = txttrip.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txttrip.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txttrip.Text.Length - 1
            Letter = txttrip.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txttrip.Text = theText
        txttrip.Select(SelectionIndex - Change, 0)

        If Trim(txttrip.Text) <> "" Then
            cmbplate.Enabled = False
            cmbtype.Enabled = False
            cmbdriver.Enabled = False
            datefrom.Enabled = False
            dateto.Enabled = False
        Else
            cmbplate.Enabled = True
            cmbtype.Enabled = True
            cmbdriver.Enabled = True
            datefrom.Enabled = True
            dateto.Enabled = True
            btnview.PerformClick()
        End If
    End Sub

    Public Sub tripsearch()
        Try
            Me.Cursor = Cursors.WaitCursor

            grdtrip.Rows.Clear()

            clickbtn = "Search"

            sql = "Select * from tbltripsum where tripnum='" & lbltrip.Text & txttrip.Text & "' and whsename='" & login.whse & "'"
            connect()
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            While drx.Read
                Dim stat As String = ""
                If drx("status") = 1 Then
                    stat = "On Queue"
                ElseIf drx("status") = 0 Then
                    stat = "In Process"
                ElseIf drx("status") = 2 Then
                    stat = "Completed"
                ElseIf drx("status") = 3 Then
                    stat = "Cancelled"
                End If

                Dim actualdis As Double = drx("odoend") - drx("odoactual")
                Dim totaldis As Double = drx("diswith") + drx("diswout")
                Dim vardis As Double = actualdis - totaldis

                Dim dieselused As Double = (drx("dieselactual") + drx("podiesel") + drx("addpo") + drx("postaddpo")) - drx("dieselend")
                Dim vardiesel As Double = dieselused - drx("dshould")

                Dim tdep As String = ""
                If Not IsDBNull(drx("timedep")) = True Then
                    tdep = Format(drx("timedep"), "yyyy/MM/dd HH:mm")
                End If

                Dim tarr As String = ""
                If Not IsDBNull(drx("timearr")) = True Then
                    tarr = Format(drx("timearr"), "yyyy/MM/dd HH:mm")
                End If

                grdtrip.Rows.Add(drx("tripsumid"), Format(drx("datepick"), "yyyy/MM/dd"), drx("tripnum"), drx("platenum"), "", drx("driver"), drx("helper").ToString, drx("origin"), "", Format(drx("etd"), "HH:mm"), tdep, tarr, drx("odostart"), drx("odoactual"), drx("odoend"), actualdis, drx("diswith"), drx("diswout"), totaldis, vardis, drx("dshould"), drx("dieselbeg"), drx("dieselactual"), drx("podiesel"), drx("addpo") + drx("postaddpo"), drx("dieselend"), dieselused, vardiesel, drx("loadscale"), drx("repair"), drx("rescue"), drx("remarks"), stat, drx("datecreated"), drx("createdby"), drx("datemodified"), drx("modifiedby"))
                grdtrip.Item(12, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(13, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(14, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(15, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(16, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(17, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(18, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite
                grdtrip.Item(19, grdtrip.Rows.Count - 1).Style.BackColor = Color.NavajoWhite

                grdtrip.Item(20, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(21, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(22, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(23, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(24, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(25, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(26, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold
                grdtrip.Item(27, grdtrip.Rows.Count - 1).Style.BackColor = Color.Gold

                If drx("status") = 3 Then
                    grdtrip.Rows(grdtrip.Rows.Count - 1).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                End If
            End While
            drx.Dispose()
            cmdx.Dispose()
            conn.Close()

            destin()

            'status
            For Each row As DataGridViewRow In grdtrip.Rows
                sql = "Select * from tbldispatchsum where tripnum='" & grdtrip.Rows(row.Index).Cells(2).Value & "'"
                connect()
                cmdx = New SqlCommand(sql, conn)
                drx = cmdx.ExecuteReader
                If drx.Read Then
                    Dim whatstep As String = "On Queue"

                    If grdtrip.Item(32, row.Index).Value.ToString <> "Cancelled" Then
                        If drx("step1") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp1").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp1").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "In Step 1"
                            End If
                        End If
                        If drx("step2") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp2").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp2").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "In Step 2"
                            End If
                        End If
                        If drx("step3") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp3").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp3").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "In Step 3"
                            End If
                        End If
                        If drx("step4") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp4").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp4").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "Released Documents"
                            End If
                        End If
                        If drx("step5") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp5").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp5").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "Released Petty Cash"
                                If IsDBNull(drx("timedep")) = False Then
                                    whatstep = "Dispatched"
                                End If
                            End If
                        End If
                        If drx("step6") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp6").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp6").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "Returned to Whse"
                            End If
                        End If
                        If drx("step7") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp7").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp7").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "Returned to Whse"
                            End If
                        End If
                        If drx("step8") = 1 Then
                            If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                            ElseIf drx("namestp8").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp8").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                                whatstep = "Returned to Whse"
                            End If
                        End If
                        If drx("step9") = 1 Then
                            If drx("namestp9").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            ElseIf drx("namestp9").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            Else
                            End If

                            whatstep = "Completed"

                        End If

                        grdtrip.Item(32, row.Index).Value = whatstep

                    End If


                    If grdtrip.Rows(row.Index).Cells(29).Value.ToString = 1 Then
                        grdtrip.Rows(row.Index).Cells(29).Value = drx("remstp8")
                        grdtrip.Item(29, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                    End If
                End If
                drx.Dispose()
                cmdx.Dispose()
                conn.Close()
            Next

            grdcolor()

            viewdispatch()

            Me.Cursor = Cursors.Default
            If grdtrip.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub grdcolor()
        Try
            For Each row As DataGridViewRow In grdtrip.Rows
                If grdtrip.Rows(row.Index).Cells(16).Value.ToString IsNot Nothing And grdtrip.Rows(row.Index).Cells(16).Value >= 5 Then
                    grdtrip.Item(16, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                End If

                If grdtrip.Rows(row.Index).Cells(24).Value.ToString IsNot Nothing And grdtrip.Rows(row.Index).Cells(24).Value >= 5 Then
                    grdtrip.Item(24, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                End If
            Next
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub EditTripToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditTripToolStripMenuItem.Click
        Try
            If login.neym = "Whse Accounting Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Completed" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already completed.", MsgBoxStyle.Information, "")
                Exit Sub
            ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Cancelled" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already cancelled.", MsgBoxStyle.Information, "")
                Exit Sub
            ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "On Queue" Then
                tripedit.lblvtype.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(4).Value  'tinitignan kung JPSC or CUSTOMER OR TRUCKING
                tripedit.plate()
                tripedit.driver()
                tripedit.helper()
                tripedit.whse()
                tripedit.datepick.Value = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(1).Value
                tripedit.datepick.MinDate = tripedit.datepick.Value
                tripedit.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                tripedit.cmbplate.SelectedItem = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(3).Value.ToString
                tripedit.cmbdriver.SelectedItem = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(5).Value.ToString
                tripedit.cmbhelper.SelectedItem = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(6).Value.ToString
                tripedit.cmbwhse.SelectedItem = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(7).Value.ToString
                tripedit.txtetd.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(9).Value.ToString
                tripedit.txtrems.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(31).Value.ToString
                'tripedit.grd.Columns(5).Visible = False
                tripedit.ShowDialog()

            Else
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already " & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString & ".", MsgBoxStyle.Information, "")

            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub CancelTripToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelTripToolStripMenuItem.Click
        'view list of transaction select what transaction is cancel

        Try
            If login.neym = "Whse Accounting Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Completed" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already completed.", MsgBoxStyle.Information, "")
                Exit Sub
            ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Cancelled" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already cancelled.", MsgBoxStyle.Information, "")
                Exit Sub
            ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Returned to Whse" Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip is already returned to whse.", MsgBoxStyle.Information, "")
                'pwede mag return sa whse pero cancel yung transaction
                tripcancel.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                tripcancel.btncanceltrip.Enabled = False
                tripcancel.btnremove.Enabled = False
                tripcancel.btncancel.Enabled = True
                tripcancel.btnreschedule.Enabled = True
                tripcancel.ShowDialog()

                viewall()

                'ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "On Queue" Then
            Else
                tripcancel.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                tripcancel.btncanceltrip.Enabled = True
                tripcancel.btnremove.Enabled = True
                tripcancel.btncancel.Enabled = False
                tripcancel.btnreschedule.Enabled = False
                tripcancel.ShowDialog()

                viewall()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub RescueToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RescueToolStripMenuItem.Click
        'view list of transaction select what transaction is transfer or other
        'rescue parang edit trip pero pdeng pumili ng transaction na i tatransfer to 
        Try
            If login.neym = "Whse Accounting Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdtrip.SelectedCells.Count = 1 Or grdtrip.SelectedRows.Count = 1 Then
                If grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(30).Value.ToString = "Yes" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already rescued.", MsgBoxStyle.Information, "")
                    Exit Sub
                ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Completed" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already completed.", MsgBoxStyle.Information, "")
                    Exit Sub
                ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Cancelled" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already cancelled.", MsgBoxStyle.Information, "")
                    Exit Sub
                ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Returned to Whse" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is already returned to whse.", MsgBoxStyle.Information, "")
                    'Exit Sub

                    '/triprescue.plate()
                    '/triprescue.driver()
                    '/triprescue.whse()
                    '/triprescue.newdatepick.Value = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(1).Value.ToString
                    '/triprescue.datepick.Value = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(1).Value.ToString
                    '/triprescue.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                    '/triprescue.txtplate.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(3).Value.ToString
                    '/triprescue.txtdriver.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(5).Value.ToString
                    '/triprescue.txtorigin.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(7).Value.ToString
                    '/triprescue.txtetd.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(9).Value.ToString
                    '/triprescue.txtrems.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(30).Value.ToString
                    '/triprescue.ShowDialog()

                ElseIf grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString = "Dispatched" Then 'available or in process

                    '/triprescue.plate()
                    '/triprescue.driver()
                    '/triprescue.whse()
                    '/triprescue.newdatepick.Value = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(1).Value.ToString
                    '/triprescue.datepick.Value = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(1).Value.ToString
                    '/triprescue.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                    '/triprescue.txtplate.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(3).Value.ToString
                    '/triprescue.txtdriver.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(5).Value.ToString
                    '/triprescue.txtorigin.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(7).Value.ToString
                    '/triprescue.txtetd.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(9).Value.ToString
                    '/triprescue.txtrems.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(30).Value.ToString
                    '/triprescue.ShowDialog()

                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Trip is not yet dispatched.", MsgBoxStyle.Information, "")
                    Exit Sub
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select Only One", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub UpdateRemarksToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateRemarksToolStripMenuItem.Click
        triprems.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
        triprems.txtrems.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(31).Value.ToString
        triprems.ShowDialog()
    End Sub

    Private Sub btnreport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreport.Click
        Try
            If grdtrip.Rows.Count <> 0 Then
                Me.Cursor = Cursors.Default
                '/tripsumprev.WindowState = FormWindowState.Maximized
                '/tripsumprev.ShowDialog()
            Else
                Me.Cursor = Cursors.Default
                MsgBox("No record found.", MsgBoxStyle.Critical, "")
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnexport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexport.Click
        Try
            Me.Cursor = Cursors.WaitCursor

            Dim objExcel As New Excel.Application
            Dim bkWorkBook As Excel.Workbook
            Dim shWorkSheet As Excel.Worksheet
            Dim misValue As Object = System.Reflection.Missing.Value

            Dim oldCI As System.Globalization.CultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture
            System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
            objExcel.Workbooks.Add()
            System.Threading.Thread.CurrentThread.CurrentCulture = oldCI

            Dim i As Integer
            Dim j As Integer

            Dim dfrom As String = Format(datefrom.Value, "MMMMddyyyy")
            Dim dto As String = Format(dateto.Value, "MMMMddyyyy")

            Dim daterange As String = dfrom & "_TO_" & dto
            Dim sfilename As String = login.whse & " Whse " & clickbtn & " Diesel Sched from " & daterange & ".xls"

            objExcel = New Excel.Application
            bkWorkBook = objExcel.Workbooks.Add
            shWorkSheet = CType(bkWorkBook.ActiveSheet, Excel.Worksheet)

            With shWorkSheet
                .Range("A1", misValue).EntireRow.Font.Bold = True
                .Range("A1:AB1").EntireRow.WrapText = True
                .Range("A1:AB" & grdtrip.RowCount + 1).HorizontalAlignment = -4108
                .Range("A1:AB" & grdtrip.RowCount + 1).VerticalAlignment = -4108
                .Range("A1:AB" & grdtrip.RowCount + 1).Font.Size = 10
                'Set Clipboard Copy Mode     
                grdtrip.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
                grdtrip.SelectAll()
                grdtrip.RowHeadersVisible = False

                'Get the content from Grid for Clipboard     
                'Dim str As String = TryCast(grdtrip.GetClipboardContent().GetData(DataFormats.UnicodeText), String)
                Dim str As String = grdtrip.GetClipboardContent().GetData(DataFormats.UnicodeText)

                'Set the content to Clipboard     
                Clipboard.SetText(str, TextDataFormat.UnicodeText) 'TextDataFormat.UnicodeText)

                'Identify and select the range of cells in Excel to paste the clipboard data.     
                .Range("A1:AB1", misValue).Select()

                'WIDTH
                .Range("A1:A" & grdtrip.RowCount + 1).ColumnWidth = 11

                .Range("B1:B" & grdtrip.RowCount + 1).ColumnWidth = 12
                .Range("C1:C" & grdtrip.RowCount + 1).ColumnWidth = 15
                .Range("D1:D" & grdtrip.RowCount + 1).ColumnWidth = 13
                .Range("E1:E" & grdtrip.RowCount + 1).ColumnWidth = 20
                .Range("H1:H" & grdtrip.RowCount + 1).ColumnWidth = 55
                .Range("I1:AA" & grdtrip.RowCount + 1).ColumnWidth = 15
                .Range("AB1:AB" & grdtrip.RowCount + 1).ColumnWidth = 18

                'Paste the clipboard data     
                .Paste()
                Clipboard.Clear()
            End With

            'format alignment
            'shWorkSheet.Range("D2", "D" & grdtrip.RowCount + 1).HorizontalAlignment = Excel.XlHAlign.xlHAlignRight
            For i = 0 To grdtrip.RowCount - 1
                'shWorkSheet.Cells(i + 2, 1) = grd.Rows(i).Cells(1).Value
                shWorkSheet.Range("A1").EntireRow.NumberFormat = "MM/dd/yyyy"
            Next

            'lagyan ng title na red door kit tska ung date na sakop ng report
            shWorkSheet.Range("A1").EntireRow.Insert()
            shWorkSheet.Range("A2").EntireRow.Insert()
            shWorkSheet.Range("A3").EntireRow.Insert()
            shWorkSheet.Cells(1, 1) = login.whse & " Warehouse"
            shWorkSheet.Cells(2, 1) = clickbtn & " Schedule from " & daterange & " (Diesel Report)"
            shWorkSheet.Cells(1, 1).Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red)
            shWorkSheet.Range("A4").EntireRow.WrapText = True

            Me.Cursor = Cursors.Default

            '/shWorkSheet.Shapes.AddPicture("C:\xl_pic.JPG", Microsoft.Office.Core.MsoTriState.msoFalse, Microsoft.Office.Core.MsoTriState.msoCTrue, 50, 50, 300, 45)

            objExcel.Visible = False
            'objExcel.Application.DisplayAlerts = False

            Dim password As String = "AB123"
            'objExcel.ActiveWorkbook.SaveAs(Application.StartupPath & "sample.xls", FileFormat:=51, )
            '/bkWorkBook.SaveAs(Filename:=Application.StartupPath & "\template\" & sfilename, FileFormat:=51, Password:=password, CreateBackup:=False)
            bkWorkBook.SaveAs(Filename:=Application.StartupPath & "\template\" & sfilename, FileFormat:=51, CreateBackup:=False)

            bkWorkBook.Close(True, misValue, misValue)
            objExcel.Quit()

            'objExcel = Nothing

            releaseObject(bkWorkBook)
            releaseObject(shWorkSheet)
            releaseObject(objExcel)

            MsgBox("Data Successfully Exported.", MsgBoxStyle.Information, "")

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As System.Runtime.InteropServices.COMException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " + ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub

    Public Sub viewdispatch()
        For Each row As DataGridViewRow In grdtrip.Rows
            sql = "SELECT * from tbldispatchsum where tripnum='" & grdtrip.Rows(row.Index).Cells(2).Value & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("step2") = 1 And dr("namestp2").ToString = "" Then
                    grdtrip.Item(26, row.Index).Value = "SKIPPED"
                    grdtrip.Item(27, row.Index).Value = "-"
                Else
                    grdtrip.Item(26, row.Index).Value = dr("remstp2").ToString & " (" & dr("namestp2").ToString & ")"
                    If dr("cneymstp2").ToString <> "" Then
                        grdtrip.Item(27, row.Index).Value = dr("comstp2").ToString & " (" & dr("cneymstp2").ToString & ")"
                    Else
                        grdtrip.Item(27, row.Index).Value = "-"
                    End If
                End If

                If dr("step8") = 1 And dr("namestp8").ToString = "" Then
                    grdtrip.Item(28, row.Index).Value = "SKIPPED"
                    grdtrip.Item(29, row.Index).Value = "-"
                Else
                    grdtrip.Item(29, row.Index).Value = dr("remstp8").ToString & " (" & dr("namestp8").ToString & ")"
                    If dr("cneymstp8").ToString <> "" Then
                        grdtrip.Item(29, row.Index).Value = dr("comstp8").ToString & " (" & dr("cneymstp8").ToString & ")"
                    Else
                        grdtrip.Item(29, row.Index).Value = "-"
                    End If
                End If
            End If
            dr.Close()
            cmd.Dispose()
            conn.Close()
        Next
    End Sub

    Private Sub grdtrip_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdtrip.SelectionChanged
        count()
    End Sub

    Public Sub count()
        Try
            lblcount.Text = "     Selected Rows Count: " & grdtrip.SelectedRows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub EditHelperToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditHelperToolStripMenuItem.Click
        Try
            If login.neym = "Whse Accounting Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Dim stat As String = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString
            Dim whatstep As String = ""
            'status
            connect()
            sql = "Select * from tbldispatchsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "'"
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            If drx.Read Then
                whatstep = "On Queue"

                If grdtrip.Item(32, grdtrip.CurrentRow.Index).Value.ToString <> "Cancelled" Then
                    If drx("step1") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp1").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp1").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "In Step 1"
                        End If
                    End If
                    If drx("step2") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp2").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp2").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "In Step 2"
                        End If
                    End If
                    If drx("step3") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp3").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp3").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "In Step 3"
                        End If
                    End If
                    If drx("step4") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp4").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp4").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "Released Documents"
                        End If
                    End If
                    If drx("step5") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp5").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp5").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "Released Petty Cash"
                            If IsDBNull(drx("timedep")) = False Then
                                whatstep = "Dispatched"
                            End If
                        End If
                    End If
                    If drx("step6") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp6").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp6").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "Returned to Whse"
                        End If
                    End If
                    If drx("step7") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp7").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp7").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "Returned to Whse"
                        End If
                    End If
                    If drx("step8") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp8").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp8").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "Returned to Whse"
                        End If
                    End If
                    If drx("step9") = 1 Then
                        If drx("namestp9").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp9").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        Else
                        End If

                        whatstep = "Completed"

                    End If

                End If

            End If
            drx.Dispose()
            cmdx.Dispose()
            conn.Close()

            If whatstep <> "Completed" And whatstep <> "Returned to Whse" And whatstep <> "Dispatched" And whatstep <> "" Then
                triphelper.lblvtype.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(4).Value  'tinitignan kung JPSC or CUSTOMER OR TRUCKING
                triphelper.helper()
                triphelper.lblplate.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(3).Value.ToString
                triphelper.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                triphelper.cmbhelper.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(6).Value.ToString
                triphelper.ShowDialog()
            End If

            'step 9 complete
            'step 6 returned
            'timedep is not null

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ViewTripInformationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewTripInformationToolStripMenuItem.Click
        Try
            Me.Cursor = Cursors.WaitCursor

            viewtripinfo.lblid.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(0).Value.ToString
            viewtripinfo.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
            viewtripinfo.Text = "Trip Information (" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & ")"
            viewtripinfo.ShowDialog()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ChangeDriverToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangeDriverToolStripMenuItem.Click
        Try
            If login.neym = "Whse Accounting Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Dim stat As String = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(32).Value.ToString
            Dim whatstep As String = ""
            'status
            connect()
            sql = "Select * from tbldispatchsum where tripnum='" & grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString & "'"
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            If drx.Read Then
                whatstep = "On Queue"

                If grdtrip.Item(32, grdtrip.CurrentRow.Index).Value.ToString <> "Cancelled" Then
                    If drx("step1") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp1").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp1").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "In Step 1"
                        End If
                    End If
                    If drx("step2") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp2").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp2").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "In Step 2"
                        End If
                    End If
                    If drx("step3") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp3").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp3").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "In Step 3"
                        End If
                    End If
                    If drx("step4") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp4").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp4").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "Released Documents"
                        End If
                    End If
                    If drx("step5") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp5").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp5").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "Released Petty Cash"
                            If IsDBNull(drx("timedep")) = False Then
                                whatstep = "Dispatched"
                            End If
                        End If
                    End If
                    If drx("step6") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp6").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp6").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "Returned to Whse"
                        End If
                    End If
                    If drx("step7") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp7").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp7").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "Returned to Whse"
                        End If
                    End If
                    If drx("step8") = 1 Then
                        If drx("rescue").ToString <> "" And drx("rescue").ToString <> "-" Then
                        ElseIf drx("namestp8").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp8").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                            whatstep = "Returned to Whse"
                        End If
                    End If
                    If drx("step9") = 1 Then
                        If drx("namestp9").ToString = "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        ElseIf drx("namestp9").ToString <> "" And (drx("rescue").ToString = "" Or drx("rescue").ToString = "-") Then
                        Else
                        End If

                        whatstep = "Completed"

                    End If

                End If

            End If
            drx.Dispose()
            cmdx.Dispose()
            conn.Close()

            If whatstep <> "Completed" And whatstep <> "Returned to Whse" And whatstep <> "Dispatched" And whatstep <> "" Then
                tripdriver.lblvtype.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(4).Value  'tinitignan kung JPSC or CUSTOMER OR TRUCKING
                tripdriver.driver()
                tripdriver.lblplate.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(3).Value.ToString
                tripdriver.lbltripnum.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(2).Value.ToString
                tripdriver.cmbdriver.Text = grdtrip.Rows(grdtrip.CurrentRow.Index).Cells(5).Value.ToString
                tripdriver.ShowDialog()
            End If


            'step 9 complete
            'step 6 returned
            'timedep is not null

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbtype_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbtype.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbplate_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbplate.SelectedIndexChanged

    End Sub

    Private Sub tripdiesel_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.WindowState = FormWindowState.Maximized
    End Sub
End Class