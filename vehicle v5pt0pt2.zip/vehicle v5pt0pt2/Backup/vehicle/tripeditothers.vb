﻿Imports System.IO
Imports System.Data.SqlClient

Public Class tripeditothers
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public editcnf As Boolean = False, tayp As String
    Dim setcolumn As String = ""

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        Me.Dispose()
    End Sub

    Private Sub tripeditref_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

    End Sub

    Private Sub tripeditref_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtprev.Text = ""
        txtnew.Text = ""

        If tayp = "Odometer Beginning" Then '//////////////////////////////////////////////////////////////////////////////////////////////////////////////
            setcolumn = "odoactual"
        ElseIf tayp = "Odometer Ending" Then '//////////////////////////////////////////////////////////////////////////////////////////////////////////////
            setcolumn = "odoend"
        End If

        viewref()
    End Sub

    Public Sub viewref()
        Try
            sql = "Select " & setcolumn & " from tbltripsum where tripnum='" & txttripnum.Text & "' and whsename='" & login.whse & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                txtprev.Text = dr(setcolumn)
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        Try
            If Trim(txttripnum.Text) = "" Then
                MsgBox("Please refresh again.", MsgBoxStyle.Exclamation, "")
            ElseIf Trim(txtprev.Text) = "" Then
                MsgBox("Please refresh again.", MsgBoxStyle.Exclamation, "")
            ElseIf Trim(txtnew.Text) = "" Then
                MsgBox("Please input new " & tayp & ".", MsgBoxStyle.Exclamation, "")
                txtnew.Focus()
            Else
                If Trim(txtprev.Text) = Trim(txtnew.Text) Then
                    MsgBox("Please input new " & tayp & ".", MsgBoxStyle.Exclamation, "")
                    txtnew.Focus()
                ElseIf Val(Trim(txtnew.Text)) = 0 Then
                    MsgBox("Please input " & tayp & ".", MsgBoxStyle.Exclamation, "")
                    txtnew.Focus()
                Else
                    'complete lahat
                    'confirm
                    editcnf = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()
                    If editcnf = True Then
                        ExecuteSave(strconn)
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteSave(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                'tbltripsum
                sql = "Update tbltripsum set " & setcolumn & "='" & Trim(txtnew.Text) & "' where tripnum='" & txttripnum.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                'tbltripsumedit
                sql = "Insert into tbltripsumedit (tripnum, tayp, prev_value, new_value, whsename, datecreated, createdby, status)"
                sql = sql & " values ('" & txttripnum.Text & "', '" & tayp & "', '" & Trim(txtprev.Text) & "', '" & Trim(txtnew.Text) & "', '" & login.whse & "', GetDate(), '" & login.cashier & "', '1')"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully saved.", MsgBoxStyle.Information, "")

                If tayp = "Odometer Beginning" Then
                    viewstep1.txt4.Text = Trim(txtnew.Text)
                ElseIf tayp = "Odometer Ending" Then
                    viewstep1.txt12.Text = Trim(txtnew.Text)
                End If

                Me.Dispose()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub txtnew_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtnew.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Trim(txtnew.Text) = "" And Asc(e.KeyChar) = 48 Then
            e.Handled = True
        ElseIf Trim(txtnew.Text) <> "" And Trim(txtnew.Text.ToString.Contains(".")) = True And Asc(e.KeyChar) = 46 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btnok.PerformClick()
        End If
    End Sub

    Private Sub txtnow_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtnew.TextChanged
        Try
            Dim charactersDisallowed As String = "1234567890."
            Dim theText As String = txtnew.Text
            Dim Letter As String
            Dim SelectionIndex As Integer = txtnew.SelectionStart
            Dim Change As Integer

            For x As Integer = 0 To txtnew.Text.Length - 1
                Letter = txtnew.Text.Substring(x, 1)
                If Not charactersDisallowed.Contains(Letter) Then
                    theText = theText.Replace(Letter, String.Empty)
                    Change = 1
                End If
            Next

            txtnew.Text = theText.ToUpper
            txtnew.Select(SelectionIndex - Change, 0)

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class