﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class odometer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(odometer))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.GroupBox11 = New System.Windows.Forms.GroupBox
        Me.lblpmschid = New System.Windows.Forms.Label
        Me.Label55 = New System.Windows.Forms.Label
        Me.datetoodo = New System.Windows.Forms.DateTimePicker
        Me.Label50 = New System.Windows.Forms.Label
        Me.datefromodo = New System.Windows.Forms.DateTimePicker
        Me.txtodorems = New System.Windows.Forms.TextBox
        Me.Label53 = New System.Windows.Forms.Label
        Me.txtodoread = New System.Windows.Forms.TextBox
        Me.Label51 = New System.Windows.Forms.Label
        Me.lblgenid = New System.Windows.Forms.Label
        Me.btnremodo = New System.Windows.Forms.Button
        Me.lblodoid = New System.Windows.Forms.Label
        Me.btnaddodo = New System.Windows.Forms.Button
        Me.dateodo = New System.Windows.Forms.DateTimePicker
        Me.txtodoloc = New System.Windows.Forms.TextBox
        Me.Label52 = New System.Windows.Forms.Label
        Me.Label54 = New System.Windows.Forms.Label
        Me.grdodo = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn24 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.btncancelodo = New System.Windows.Forms.Button
        Me.btnviewodo = New System.Windows.Forms.Button
        Me.btneditodo = New System.Windows.Forms.Button
        Me.GroupBox11.SuspendLayout()
        CType(Me.grdodo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox11
        '
        Me.GroupBox11.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox11.Controls.Add(Me.lblpmschid)
        Me.GroupBox11.Controls.Add(Me.Label55)
        Me.GroupBox11.Controls.Add(Me.datetoodo)
        Me.GroupBox11.Controls.Add(Me.Label50)
        Me.GroupBox11.Controls.Add(Me.datefromodo)
        Me.GroupBox11.Controls.Add(Me.txtodorems)
        Me.GroupBox11.Controls.Add(Me.Label53)
        Me.GroupBox11.Controls.Add(Me.txtodoread)
        Me.GroupBox11.Controls.Add(Me.Label51)
        Me.GroupBox11.Controls.Add(Me.lblgenid)
        Me.GroupBox11.Controls.Add(Me.btnremodo)
        Me.GroupBox11.Controls.Add(Me.lblodoid)
        Me.GroupBox11.Controls.Add(Me.btnaddodo)
        Me.GroupBox11.Controls.Add(Me.dateodo)
        Me.GroupBox11.Controls.Add(Me.txtodoloc)
        Me.GroupBox11.Controls.Add(Me.Label52)
        Me.GroupBox11.Controls.Add(Me.Label54)
        Me.GroupBox11.Controls.Add(Me.grdodo)
        Me.GroupBox11.Controls.Add(Me.btncancelodo)
        Me.GroupBox11.Controls.Add(Me.btnviewodo)
        Me.GroupBox11.Controls.Add(Me.btneditodo)
        Me.GroupBox11.Location = New System.Drawing.Point(12, 10)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(768, 527)
        Me.GroupBox11.TabIndex = 9
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Odometer Reading"
        '
        'lblpmschid
        '
        Me.lblpmschid.AutoSize = True
        Me.lblpmschid.Location = New System.Drawing.Point(469, 14)
        Me.lblpmschid.Name = "lblpmschid"
        Me.lblpmschid.Size = New System.Drawing.Size(55, 15)
        Me.lblpmschid.TabIndex = 103
        Me.lblpmschid.Text = "pmschid"
        Me.lblpmschid.Visible = False
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(242, 199)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(23, 15)
        Me.Label55.TabIndex = 102
        Me.Label55.Text = "To:"
        '
        'datetoodo
        '
        Me.datetoodo.CustomFormat = ""
        Me.datetoodo.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datetoodo.Location = New System.Drawing.Point(271, 196)
        Me.datetoodo.Name = "datetoodo"
        Me.datetoodo.Size = New System.Drawing.Size(159, 21)
        Me.datetoodo.TabIndex = 101
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(13, 199)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(39, 15)
        Me.Label50.TabIndex = 100
        Me.Label50.Text = "From:"
        '
        'datefromodo
        '
        Me.datefromodo.CustomFormat = ""
        Me.datefromodo.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datefromodo.Location = New System.Drawing.Point(58, 196)
        Me.datefromodo.MinDate = New Date(2015, 1, 1, 0, 0, 0, 0)
        Me.datefromodo.Name = "datefromodo"
        Me.datefromodo.Size = New System.Drawing.Size(159, 21)
        Me.datefromodo.TabIndex = 99
        '
        'txtodorems
        '
        Me.txtodorems.Location = New System.Drawing.Point(180, 115)
        Me.txtodorems.Name = "txtodorems"
        Me.txtodorems.Size = New System.Drawing.Size(426, 21)
        Me.txtodorems.TabIndex = 92
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(13, 122)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(61, 15)
        Me.Label53.TabIndex = 43
        Me.Label53.Text = "Remarks:"
        '
        'txtodoread
        '
        Me.txtodoread.Location = New System.Drawing.Point(180, 88)
        Me.txtodoread.Name = "txtodoread"
        Me.txtodoread.Size = New System.Drawing.Size(244, 21)
        Me.txtodoread.TabIndex = 91
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(13, 95)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(115, 15)
        Me.Label51.TabIndex = 41
        Me.Label51.Text = "Odometer Reading:"
        '
        'lblgenid
        '
        Me.lblgenid.AutoSize = True
        Me.lblgenid.Location = New System.Drawing.Point(333, 14)
        Me.lblgenid.Name = "lblgenid"
        Me.lblgenid.Size = New System.Drawing.Size(38, 15)
        Me.lblgenid.TabIndex = 40
        Me.lblgenid.Text = "genid"
        Me.lblgenid.Visible = False
        '
        'btnremodo
        '
        Me.btnremodo.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnremodo.Image = CType(resources.GetObject("btnremodo.Image"), System.Drawing.Image)
        Me.btnremodo.Location = New System.Drawing.Point(455, 142)
        Me.btnremodo.Name = "btnremodo"
        Me.btnremodo.Size = New System.Drawing.Size(101, 30)
        Me.btnremodo.TabIndex = 96
        Me.btnremodo.Text = "Remove"
        Me.btnremodo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnremodo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnremodo.UseVisualStyleBackColor = True
        '
        'lblodoid
        '
        Me.lblodoid.AutoSize = True
        Me.lblodoid.Location = New System.Drawing.Point(177, 14)
        Me.lblodoid.Name = "lblodoid"
        Me.lblodoid.Size = New System.Drawing.Size(40, 15)
        Me.lblodoid.TabIndex = 38
        Me.lblodoid.Text = "Odoid"
        Me.lblodoid.Visible = False
        '
        'btnaddodo
        '
        Me.btnaddodo.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnaddodo.Image = CType(resources.GetObject("btnaddodo.Image"), System.Drawing.Image)
        Me.btnaddodo.Location = New System.Drawing.Point(148, 142)
        Me.btnaddodo.Name = "btnaddodo"
        Me.btnaddodo.Size = New System.Drawing.Size(94, 30)
        Me.btnaddodo.TabIndex = 93
        Me.btnaddodo.Text = "Add"
        Me.btnaddodo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnaddodo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnaddodo.UseVisualStyleBackColor = True
        '
        'dateodo
        '
        Me.dateodo.CustomFormat = ""
        Me.dateodo.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dateodo.Location = New System.Drawing.Point(180, 34)
        Me.dateodo.Name = "dateodo"
        Me.dateodo.Size = New System.Drawing.Size(152, 21)
        Me.dateodo.TabIndex = 89
        '
        'txtodoloc
        '
        Me.txtodoloc.Location = New System.Drawing.Point(180, 61)
        Me.txtodoloc.Name = "txtodoloc"
        Me.txtodoloc.Size = New System.Drawing.Size(344, 21)
        Me.txtodoloc.TabIndex = 90
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(13, 68)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(57, 15)
        Me.Label52.TabIndex = 18
        Me.Label52.Text = "Location:"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(13, 40)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(36, 15)
        Me.Label54.TabIndex = 16
        Me.Label54.Text = "Date:"
        '
        'grdodo
        '
        Me.grdodo.AllowUserToAddRows = False
        Me.grdodo.AllowUserToDeleteRows = False
        Me.grdodo.AllowUserToResizeRows = False
        Me.grdodo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdodo.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grdodo.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdodo.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grdodo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdodo.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn21, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23, Me.DataGridViewTextBoxColumn24})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdodo.DefaultCellStyle = DataGridViewCellStyle2
        Me.grdodo.Location = New System.Drawing.Point(11, 223)
        Me.grdodo.MultiSelect = False
        Me.grdodo.Name = "grdodo"
        Me.grdodo.ReadOnly = True
        Me.grdodo.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdodo.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.grdodo.RowHeadersWidth = 10
        Me.grdodo.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdodo.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.grdodo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdodo.Size = New System.Drawing.Size(746, 286)
        Me.grdodo.TabIndex = 98
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.HeaderText = "id"
        Me.DataGridViewTextBoxColumn20.MinimumWidth = 190
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.ReadOnly = True
        Me.DataGridViewTextBoxColumn20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn20.Visible = False
        Me.DataGridViewTextBoxColumn20.Width = 190
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn21.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.ReadOnly = True
        Me.DataGridViewTextBoxColumn21.Width = 120
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.HeaderText = "Location"
        Me.DataGridViewTextBoxColumn22.MinimumWidth = 220
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.ReadOnly = True
        Me.DataGridViewTextBoxColumn22.Width = 220
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.HeaderText = "Odometer Reading"
        Me.DataGridViewTextBoxColumn23.MinimumWidth = 180
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.ReadOnly = True
        Me.DataGridViewTextBoxColumn23.Width = 180
        '
        'DataGridViewTextBoxColumn24
        '
        Me.DataGridViewTextBoxColumn24.HeaderText = "Remarks"
        Me.DataGridViewTextBoxColumn24.MinimumWidth = 180
        Me.DataGridViewTextBoxColumn24.Name = "DataGridViewTextBoxColumn24"
        Me.DataGridViewTextBoxColumn24.ReadOnly = True
        Me.DataGridViewTextBoxColumn24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn24.Width = 180
        '
        'btncancelodo
        '
        Me.btncancelodo.Enabled = False
        Me.btncancelodo.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancelodo.Image = CType(resources.GetObject("btncancelodo.Image"), System.Drawing.Image)
        Me.btncancelodo.Location = New System.Drawing.Point(355, 142)
        Me.btncancelodo.Name = "btncancelodo"
        Me.btncancelodo.Size = New System.Drawing.Size(94, 30)
        Me.btncancelodo.TabIndex = 95
        Me.btncancelodo.Text = "Cancel"
        Me.btncancelodo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancelodo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancelodo.UseVisualStyleBackColor = True
        '
        'btnviewodo
        '
        Me.btnviewodo.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnviewodo.Image = CType(resources.GetObject("btnviewodo.Image"), System.Drawing.Image)
        Me.btnviewodo.Location = New System.Drawing.Point(562, 142)
        Me.btnviewodo.Name = "btnviewodo"
        Me.btnviewodo.Size = New System.Drawing.Size(101, 30)
        Me.btnviewodo.TabIndex = 97
        Me.btnviewodo.Text = "Refresh"
        Me.btnviewodo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnviewodo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnviewodo.UseVisualStyleBackColor = True
        '
        'btneditodo
        '
        Me.btneditodo.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btneditodo.Image = CType(resources.GetObject("btneditodo.Image"), System.Drawing.Image)
        Me.btneditodo.Location = New System.Drawing.Point(248, 142)
        Me.btneditodo.Name = "btneditodo"
        Me.btneditodo.Size = New System.Drawing.Size(101, 30)
        Me.btneditodo.TabIndex = 94
        Me.btneditodo.Text = "Edit"
        Me.btneditodo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btneditodo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btneditodo.UseVisualStyleBackColor = True
        '
        'odometer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(792, 549)
        Me.Controls.Add(Me.GroupBox11)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "odometer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Latest Odometer"
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        CType(Me.grdodo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents datetoodo As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents datefromodo As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtodorems As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents txtodoread As System.Windows.Forms.TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents lblgenid As System.Windows.Forms.Label
    Friend WithEvents btnremodo As System.Windows.Forms.Button
    Friend WithEvents lblodoid As System.Windows.Forms.Label
    Friend WithEvents btnaddodo As System.Windows.Forms.Button
    Friend WithEvents dateodo As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtodoloc As System.Windows.Forms.TextBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents grdodo As System.Windows.Forms.DataGridView
    Friend WithEvents btncancelodo As System.Windows.Forms.Button
    Friend WithEvents btnviewodo As System.Windows.Forms.Button
    Friend WithEvents btneditodo As System.Windows.Forms.Button
    Friend WithEvents DataGridViewTextBoxColumn20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn24 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lblpmschid As System.Windows.Forms.Label
End Class
