﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.ComponentModel
Imports Excel = Microsoft.Office.Interop.Excel

Public Class vodometer
    Dim lines1 = System.IO.File.ReadAllLines("connectionstringmnl.txt")  'manila  
    Dim strconn1 As String = lines1(0) 'manila    
    Dim lines2 = System.IO.File.ReadAllLines("connectionstringcal.txt") 'calamba
    Dim strconn2 As String = lines2(0) 'calamba
    Dim lines3 = System.IO.File.ReadAllLines("connectionstringpgb.txt") 'lucena
    Dim strconn3 As String = lines3(0) 'lucena
    Dim lines4 = System.IO.File.ReadAllLines("connectionstringmil.txt") 'milaor
    Dim strconn4 As String = lines4(0) 'milaor
    Dim lines5 = System.IO.File.ReadAllLines("connectionstring.txt") 'Lc Office
    Dim strconn5 As String = lines5(0) 'Lc Office
    Dim lines6 = System.IO.File.ReadAllLines("connectionstringceb.txt") 'cebu
    Dim strconn6 As String = lines6(0) 'cebu
    Dim lines7 = System.IO.File.ReadAllLines("connectionstringdav.txt") 'davao
    Dim strconn7 As String = lines7(0) 'davao
    Dim lines8 = System.IO.File.ReadAllLines("connectionstringbcd.txt") 'bacolod
    Dim strconn8 As String = lines8(0) 'bacolod
    Dim lines9 = System.IO.File.ReadAllLines("connectionstringtac.txt") 'tacloban
    Dim strconn9 As String = lines9(0) 'tacloban

    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Private da As SqlDataAdapter
    Private ds As DataSet1

    Public Sub connectmnl()
        conn = New SqlConnection 'New OleDb.OleDbConnection
        conn.ConnectionString = strconn1
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub connectcal()
        conn = New SqlConnection
        conn.ConnectionString = strconn2
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub connectpgb()
        conn = New SqlConnection
        conn.ConnectionString = strconn3
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub connectmil()
        conn = New SqlConnection
        conn.ConnectionString = strconn4
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub connectcbcd()
        conn = New SqlConnection
        conn.ConnectionString = strconn8
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub connectctac()
        conn = New SqlConnection
        conn.ConnectionString = strconn9
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnectmnl()
        conn = New SqlConnection 'New OleDb.OleDbConnection
        conn.ConnectionString = strconn1
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Public Sub disconnectcal()
        conn = New SqlConnection
        conn.ConnectionString = strconn2
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Public Sub disconnectpgb()
        conn = New SqlConnection
        conn.ConnectionString = strconn3
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Public Sub disconnectmil()
        conn = New SqlConnection
        conn.ConnectionString = strconn4
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Public Sub disconnectcbcd()
        conn = New SqlConnection
        conn.ConnectionString = strconn8
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Public Sub disconnectctac()
        conn = New SqlConnection
        conn.ConnectionString = strconn9
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub vodometer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub viewodo()
        grdtemp.Columns.Clear()

        ds = New DataSet1
        sql = "Select tblgeneral.platenum, tbltripsum.odoend, tbltripsum.datepick, tbltripsum.tripsumid, tbltripsum.tripnum FROM tbltripsum"
        sql = sql & " left join tblgeneral on tbltripsum.platenum=tblgeneral.platenum"
        sql = sql & " where tbltripsum.tripsumid in (select max(tripsumid) from tbltripsum where status<>'3' and odoend<>'0' group by platenum)"
        sql = sql & " and tblgeneral.status='1' and tblgeneral.company='J. Poon & Sons' order by tblgeneral.platenum"

        Try
            connectmnl()
            da = New SqlDataAdapter(sql, conn)
            da.Fill(ds.DataTable12)
            conn.Close()

        Catch ex As Exception
            MsgBox("C3 Manila: " & vbCrLf & ex.Message)
        End Try


        Try
            connectcal()
            da = New SqlDataAdapter(sql, conn)
            da.Fill(ds.DataTable12)
            conn.Close()
        Catch ex As Exception
            MsgBox("Calamba: " & vbCrLf & ex.Message)
        End Try


        Try
            connectpgb()
            da = New SqlDataAdapter(sql, conn)
            da.Fill(ds.DataTable12)
            conn.Close()
        Catch ex As Exception
            MsgBox("Pagbilao: " & vbCrLf & ex.Message)
        End Try


        Try
            connectmil()
            da = New SqlDataAdapter(sql, conn)
            da.Fill(ds.DataTable12)
            conn.Close()
        Catch ex As Exception
            MsgBox("Milaor: " & vbCrLf & ex.Message)
        End Try


        '' Get players above 230 size with "m" sex.
        'Dim result() As DataRow = ds.Tables("DataTable12").Select("datepick > 10/31/2019")

        '' Loop and display.
        'For Each row As DataRow In result
        '    Console.WriteLine("{0}, {1}", row(0), row(1))
        'Next

        For rowtemp = 0 To ds.Tables("DataTable12").Rows.Count - 1
            Dim temp_plnum As String = ds.Tables("DataTable12").Rows(rowtemp).Item(0)
            Dim temp_odo As String = ds.Tables("DataTable12").Rows(rowtemp).Item(1)
            Dim temp_dpick As Date = ds.Tables("DataTable12").Rows(rowtemp).Item(2)
            Dim temp_trip As String = ds.Tables("DataTable12").Rows(rowtemp).Item(4)

            Dim exists As Boolean = False
            For Each row As DataGridViewRow In grd.Rows
                Dim plnum As String = grd.Rows(row.Index).Cells(0).Value
                Dim dpick As Date = grd.Rows(row.Index).Cells(2).Value

                If plnum = temp_plnum Then
                    exists = True
                    'compare dates
                    Dim result As Integer = DateTime.Compare(CDate(dpick), CDate(temp_dpick))
                    Dim relationship As String

                    If result < 0 Then
                        relationship = "is earlier than"
                        grd.Rows(row.Index).Cells(1).Value = temp_odo
                        grd.Rows(row.Index).Cells(2).Value = temp_dpick
                        grd.Rows(row.Index).Cells(3).Value = temp_trip
                    ElseIf result = 0 Then
                        relationship = "is the same time as"
                    Else
                        relationship = "is later than"
                    End If

                    '/MsgBox(relationship)
                End If
            Next

            If exists = False Then
                'add
                grd.Rows.Add(temp_plnum, temp_odo, temp_dpick, temp_trip)
            End If
        Next


        grdtemp.DataSource = ds.Tables("DataTable12")
        grd.Sort(grd.Columns(0), ListSortDirection.Ascending)
    End Sub

    Private Sub btnrefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrefresh.Click
        viewodo()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            Dim xlApp As Excel.Application
            Dim xlWorkBook As Excel.Workbook
            Dim xlWorkSheet As Excel.Worksheet
            Dim misValue As Object = System.Reflection.Missing.Value

            Dim i As Int16, j As Int16

            xlApp = New Excel.ApplicationClass
            xlWorkBook = xlApp.Workbooks.Add(misValue)
            xlWorkSheet = xlWorkBook.Sheets("Sheet1")


            'For i = 0 To grd.RowCount - 2
            '    For j = 0 To grd.ColumnCount - 1
            '        xlWorkSheet.Cells(i + 1, j + 1) = grd(j, i).Value
            '    Next
            'Next

            With xlWorkSheet
                .Range("A1", misValue).EntireRow.Font.Bold = True
                .Range("A1:AD1").EntireRow.WrapText = True
                .Range("A1:AD" & grd.RowCount + 1).HorizontalAlignment = -4108
                .Range("A1:AD" & grd.RowCount + 1).VerticalAlignment = -4108
                .Range("A1:AD" & grd.RowCount + 1).Font.Size = 10
                'Set Clipboard Copy Mode     
                grd.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
                grd.SelectAll()
                grd.RowHeadersVisible = False

                'Get the content from Grid for Clipboard     
                'Dim str As String = TryCast(grd.GetClipboardContent().GetData(DataFormats.UnicodeText), String)
                Dim str As String = grd.GetClipboardContent().GetData(DataFormats.UnicodeText)

                'Set the content to Clipboard     
                Clipboard.SetText(str, TextDataFormat.UnicodeText) 'TextDataFormat.UnicodeText)

                'Identify and select the range of cells in Excel to paste the clipboard data.     
                .Range("A1:AD1", misValue).Select()

                'WIDTH
                .Range("A1:A" & grd.RowCount + 1).ColumnWidth = 11

                .Range("B1:B" & grd.RowCount + 1).ColumnWidth = 12
                .Range("C1:C" & grd.RowCount + 1).ColumnWidth = 15
                .Range("D1:D" & grd.RowCount + 1).ColumnWidth = 20

                'Paste the clipboard data     
                .Paste()
                Clipboard.Clear()

            End With

            xlApp.Visible = False
            Dim sfilename As String = "Vehicle Last Odometer as of " & Format(CDate(login.Label4.Text), "MMMddyyyy") & ".xls"
            xlWorkBook.SaveAs(Filename:=Application.StartupPath & "\template\" & sfilename, FileFormat:=51, CreateBackup:=False)
            xlWorkBook.Close(True, misValue, misValue)
            xlApp.Quit()

            releaseObject(xlWorkSheet)
            releaseObject(xlWorkBook)
            releaseObject(xlApp)

            '/ MessageBox.Show("Over")
            MessageBox.Show("Data Successfully Exported")

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As System.Runtime.InteropServices.COMException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnectmnl()
        End Try
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " + ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub
End Class