﻿Imports System.IO
Imports System.Data.SqlClient

Public Class rptnotifs
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub notifsreport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        loadcomp()
    End Sub

    Public Sub loadcomp()
        Try
            cmbcomp.Items.Clear()

            sql = "Select * from tblcompany where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbcomp.Items.Add(dr("company"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbcomp.Items.Count <> 0 Then
                cmbcomp.Items.Add("All")
                cmbcomp.SelectedItem = "All"
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbcomp_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcomp.SelectedIndexChanged
        Try
            cmbwhse.Items.Clear()

            If cmbcomp.SelectedItem = "All" Then
                sql = "Select * from tblwhse where status='1'"
            Else
                sql = "Select * from tblwhse where company='" & cmbcomp.SelectedItem & "' and status='1'"
            End If
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbwhse.Items.Add(dr("whsename"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbwhse.Items.Count <> 0 Then
                cmbwhse.Items.Add("All")
                cmbwhse.SelectedItem = "All"
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbwhse_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbwhse.SelectedIndexChanged
        Try
            cmbvtype.Items.Clear()

            sql = "Select * from tblvtype where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbvtype.Items.Add(dr("vtype"))
            End While
            dr.Read()
            cmd.Dispose()
            conn.Close()

            If cmbvtype.Items.Count <> 0 Then
                cmbvtype.Items.Add("All")
                cmbvtype.SelectedItem = "All"
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        Try
            If cmbcomp.SelectedItem <> "" And cmbvtype.SelectedItem <> "" And cmbwhse.SelectedItem <> "" Then
                rptnotifsprev.Close()
                rptnotifsprev1.Close()
                Dim tempgenid As Integer = 0

                sql = "Select * from tblgeneral where status='1'"

                If cmbcomp.SelectedItem <> "All" Then
                    sql = sql & " and company='" & cmbcomp.SelectedItem & "'"
                    rptnotifsprev.condition = rptnotifsprev.condition & " and company='" & cmbcomp.SelectedItem & "'"
                    rptnotifsprev1.condition = rptnotifsprev1.condition & " and company='" & cmbcomp.SelectedItem & "'"
                End If

                If cmbwhse.SelectedItem <> "All" Then
                    sql = sql & " and whsename='" & cmbwhse.SelectedItem & "'"
                    rptnotifsprev.condition = rptnotifsprev.condition & " and whsename='" & cmbwhse.SelectedItem & "'"
                    rptnotifsprev1.condition = rptnotifsprev1.condition & " and whsename='" & cmbwhse.SelectedItem & "'"
                End If

                If cmbvtype.SelectedItem <> "All" Then
                    sql = sql & " and vtype='" & cmbvtype.SelectedItem & "'"
                    rptnotifsprev.condition = rptnotifsprev.condition & " and vtype='" & cmbvtype.SelectedItem & "'"
                    rptnotifsprev1.condition = rptnotifsprev1.condition & " and vtype='" & cmbvtype.SelectedItem & "'"
                End If

                'MsgBox(rptnotifsprev.condition)

                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    tempgenid = 6
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                If rbdocs.Checked = True Then
                    'tbldocexp
                    sql = "Select * from tbldocexp where status='1' and (statusexp='Soon to expire' or statusexp='Expired')" 'genid='" & tempgenid & "' and
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        '/rptnotifsprev.MdiParent = mdiform
                        rptnotifsprev.WindowState = FormWindowState.Maximized
                        rptnotifsprev.ShowDialog()
                        Exit Sub
                    Else
                        MsgBox("No documents notifications.", MsgBoxStyle.Information, "")
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If

                If rboil.Checked = True Then
                    'tblpmssched
                    sql = "Select * from tblpmssched where status='1' and (statusexp='Due Today' or statusexp='Over Due' or statusexp='Due Soon')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        '/rptnotifsprev1.MdiParent = mdiform
                        rptnotifsprev1.WindowState = FormWindowState.Maximized
                        rptnotifsprev1.ShowDialog()
                        Exit Sub
                    Else
                        MsgBox("No pms notifications.", MsgBoxStyle.Information, "")
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If

            Else
                MsgBox("Complete the fields.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class