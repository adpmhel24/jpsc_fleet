﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class viewimage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(viewimage))
        Me.imgbox = New System.Windows.Forms.PictureBox
        Me.lblimgname = New System.Windows.Forms.Label
        Me.lblimgid = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.txtx = New System.Windows.Forms.TextBox
        Me.btnzout = New System.Windows.Forms.Button
        Me.btnzin = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.btnprev = New System.Windows.Forms.Button
        Me.btnnext = New System.Windows.Forms.Button
        CType(Me.imgbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'imgbox
        '
        Me.imgbox.Location = New System.Drawing.Point(11, 11)
        Me.imgbox.Name = "imgbox"
        Me.imgbox.Size = New System.Drawing.Size(1350, 650)
        Me.imgbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox.TabIndex = 0
        Me.imgbox.TabStop = False
        '
        'lblimgname
        '
        Me.lblimgname.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblimgname.AutoSize = True
        Me.lblimgname.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblimgname.Location = New System.Drawing.Point(9, 544)
        Me.lblimgname.Name = "lblimgname"
        Me.lblimgname.Size = New System.Drawing.Size(0, 15)
        Me.lblimgname.TabIndex = 1
        '
        'lblimgid
        '
        Me.lblimgid.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblimgid.AutoSize = True
        Me.lblimgid.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblimgid.Location = New System.Drawing.Point(748, 547)
        Me.lblimgid.Name = "lblimgid"
        Me.lblimgid.Size = New System.Drawing.Size(0, 15)
        Me.lblimgid.TabIndex = 2
        Me.lblimgid.Visible = False
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.Location = New System.Drawing.Point(893, 539)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(89, 23)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Print"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button1.UseVisualStyleBackColor = True
        '
        'PrintDialog1
        '
        Me.PrintDialog1.UseEXDialog = True
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.AutoScroll = True
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.txtx)
        Me.Panel1.Controls.Add(Me.imgbox)
        Me.Panel1.Location = New System.Drawing.Point(1, 1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(991, 532)
        Me.Panel1.TabIndex = 4
        '
        'txtx
        '
        Me.txtx.Location = New System.Drawing.Point(11, 11)
        Me.txtx.Name = "txtx"
        Me.txtx.Size = New System.Drawing.Size(100, 20)
        Me.txtx.TabIndex = 1
        Me.txtx.Visible = False
        '
        'btnzout
        '
        Me.btnzout.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnzout.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnzout.Image = CType(resources.GetObject("btnzout.Image"), System.Drawing.Image)
        Me.btnzout.Location = New System.Drawing.Point(608, 539)
        Me.btnzout.Name = "btnzout"
        Me.btnzout.Size = New System.Drawing.Size(89, 23)
        Me.btnzout.TabIndex = 5
        Me.btnzout.Text = "Zoom Out"
        Me.btnzout.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnzout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnzout.UseVisualStyleBackColor = True
        '
        'btnzin
        '
        Me.btnzin.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnzin.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnzin.Image = CType(resources.GetObject("btnzin.Image"), System.Drawing.Image)
        Me.btnzin.Location = New System.Drawing.Point(513, 539)
        Me.btnzin.Name = "btnzin"
        Me.btnzin.Size = New System.Drawing.Size(89, 23)
        Me.btnzin.TabIndex = 6
        Me.btnzin.Text = "Zoom In"
        Me.btnzin.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnzin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnzin.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(703, 539)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(89, 23)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Rotate"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.Location = New System.Drawing.Point(798, 539)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(89, 23)
        Me.Button3.TabIndex = 8
        Me.Button3.Text = "Flip"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btnprev
        '
        Me.btnprev.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnprev.Image = CType(resources.GetObject("btnprev.Image"), System.Drawing.Image)
        Me.btnprev.Location = New System.Drawing.Point(323, 539)
        Me.btnprev.Name = "btnprev"
        Me.btnprev.Size = New System.Drawing.Size(89, 23)
        Me.btnprev.TabIndex = 2
        Me.btnprev.Text = "Previous"
        Me.btnprev.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnprev.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnprev.UseVisualStyleBackColor = True
        Me.btnprev.Visible = False
        '
        'btnnext
        '
        Me.btnnext.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnnext.Image = CType(resources.GetObject("btnnext.Image"), System.Drawing.Image)
        Me.btnnext.Location = New System.Drawing.Point(418, 539)
        Me.btnnext.Name = "btnnext"
        Me.btnnext.Size = New System.Drawing.Size(89, 23)
        Me.btnnext.TabIndex = 3
        Me.btnnext.Text = "Next"
        Me.btnnext.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnnext.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnnext.UseVisualStyleBackColor = True
        Me.btnnext.Visible = False
        '
        'viewimage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(994, 571)
        Me.Controls.Add(Me.btnnext)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.btnprev)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnzin)
        Me.Controls.Add(Me.btnzout)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblimgid)
        Me.Controls.Add(Me.lblimgname)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MinimizeBox = False
        Me.Name = "viewimage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "View Larger Image"
        CType(Me.imgbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents imgbox As System.Windows.Forms.PictureBox
    Friend WithEvents lblimgname As System.Windows.Forms.Label
    Friend WithEvents lblimgid As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnzout As System.Windows.Forms.Button
    Friend WithEvents btnzin As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents txtx As System.Windows.Forms.TextBox
    Friend WithEvents btnnext As System.Windows.Forms.Button
    Friend WithEvents btnprev As System.Windows.Forms.Button
End Class
