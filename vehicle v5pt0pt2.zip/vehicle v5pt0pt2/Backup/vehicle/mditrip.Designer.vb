﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mditrip
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mditrip))
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.logouttool = New System.Windows.Forms.ToolStripMenuItem
        Me.GeneralToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CompanyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.WarehouseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DocumentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VehicleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DriverToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelperToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CategoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ItemsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VehicleTripToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CreateOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OrderTransactionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TripSchedulingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TripDispatchingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TripDispatchSummaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TripSummaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TripScheduleReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ForChangeOilToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AdministratorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.UsersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LoginLogsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VersionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AdjustQtyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.InsertIntoDashboardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RestoreCommentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeletePreviousAttachmentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BackupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.GeneralToolStripMenuItem, Me.VehicleTripToolStripMenuItem, Me.ReportsToolStripMenuItem, Me.AdministratorToolStripMenuItem})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(1269, 24)
        Me.MenuStrip2.TabIndex = 20
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.logouttool})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'logouttool
        '
        Me.logouttool.Image = CType(resources.GetObject("logouttool.Image"), System.Drawing.Image)
        Me.logouttool.Name = "logouttool"
        Me.logouttool.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.F4), System.Windows.Forms.Keys)
        Me.logouttool.Size = New System.Drawing.Size(154, 22)
        Me.logouttool.Text = "Logout"
        '
        'GeneralToolStripMenuItem
        '
        Me.GeneralToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CompanyToolStripMenuItem, Me.WarehouseToolStripMenuItem, Me.DocumentsToolStripMenuItem, Me.VehicleToolStripMenuItem, Me.DriverToolStripMenuItem, Me.HelperToolStripMenuItem, Me.CustomerToolStripMenuItem, Me.CategoryToolStripMenuItem, Me.ItemsToolStripMenuItem})
        Me.GeneralToolStripMenuItem.Name = "GeneralToolStripMenuItem"
        Me.GeneralToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.GeneralToolStripMenuItem.Text = "General"
        '
        'CompanyToolStripMenuItem
        '
        Me.CompanyToolStripMenuItem.Image = CType(resources.GetObject("CompanyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CompanyToolStripMenuItem.Name = "CompanyToolStripMenuItem"
        Me.CompanyToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.CompanyToolStripMenuItem.Text = "Company"
        '
        'WarehouseToolStripMenuItem
        '
        Me.WarehouseToolStripMenuItem.Image = CType(resources.GetObject("WarehouseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.WarehouseToolStripMenuItem.Name = "WarehouseToolStripMenuItem"
        Me.WarehouseToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.WarehouseToolStripMenuItem.Text = "Warehouse"
        '
        'DocumentsToolStripMenuItem
        '
        Me.DocumentsToolStripMenuItem.Image = CType(resources.GetObject("DocumentsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DocumentsToolStripMenuItem.Name = "DocumentsToolStripMenuItem"
        Me.DocumentsToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.DocumentsToolStripMenuItem.Text = "Documents"
        '
        'VehicleToolStripMenuItem
        '
        Me.VehicleToolStripMenuItem.Image = CType(resources.GetObject("VehicleToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleToolStripMenuItem.Name = "VehicleToolStripMenuItem"
        Me.VehicleToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.VehicleToolStripMenuItem.Text = "Vehicle"
        '
        'DriverToolStripMenuItem
        '
        Me.DriverToolStripMenuItem.Image = CType(resources.GetObject("DriverToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DriverToolStripMenuItem.Name = "DriverToolStripMenuItem"
        Me.DriverToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.DriverToolStripMenuItem.Text = "Driver"
        '
        'HelperToolStripMenuItem
        '
        Me.HelperToolStripMenuItem.Image = CType(resources.GetObject("HelperToolStripMenuItem.Image"), System.Drawing.Image)
        Me.HelperToolStripMenuItem.Name = "HelperToolStripMenuItem"
        Me.HelperToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.HelperToolStripMenuItem.Text = "Helper"
        '
        'CustomerToolStripMenuItem
        '
        Me.CustomerToolStripMenuItem.Image = CType(resources.GetObject("CustomerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CustomerToolStripMenuItem.Name = "CustomerToolStripMenuItem"
        Me.CustomerToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.CustomerToolStripMenuItem.Text = "Customer"
        '
        'CategoryToolStripMenuItem
        '
        Me.CategoryToolStripMenuItem.Image = CType(resources.GetObject("CategoryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CategoryToolStripMenuItem.Name = "CategoryToolStripMenuItem"
        Me.CategoryToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.CategoryToolStripMenuItem.Text = "Category"
        '
        'ItemsToolStripMenuItem
        '
        Me.ItemsToolStripMenuItem.Image = CType(resources.GetObject("ItemsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ItemsToolStripMenuItem.Name = "ItemsToolStripMenuItem"
        Me.ItemsToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.ItemsToolStripMenuItem.Text = "Items"
        '
        'VehicleTripToolStripMenuItem
        '
        Me.VehicleTripToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreateOrderToolStripMenuItem, Me.OrderTransactionsToolStripMenuItem, Me.TripSchedulingToolStripMenuItem, Me.TripDispatchingToolStripMenuItem, Me.TripDispatchSummaryToolStripMenuItem, Me.TripSummaryToolStripMenuItem})
        Me.VehicleTripToolStripMenuItem.Name = "VehicleTripToolStripMenuItem"
        Me.VehicleTripToolStripMenuItem.Size = New System.Drawing.Size(78, 20)
        Me.VehicleTripToolStripMenuItem.Text = "Vehicle Trip"
        '
        'CreateOrderToolStripMenuItem
        '
        Me.CreateOrderToolStripMenuItem.Image = CType(resources.GetObject("CreateOrderToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CreateOrderToolStripMenuItem.Name = "CreateOrderToolStripMenuItem"
        Me.CreateOrderToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.CreateOrderToolStripMenuItem.Text = "Create Order"
        '
        'OrderTransactionsToolStripMenuItem
        '
        Me.OrderTransactionsToolStripMenuItem.Image = CType(resources.GetObject("OrderTransactionsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OrderTransactionsToolStripMenuItem.Name = "OrderTransactionsToolStripMenuItem"
        Me.OrderTransactionsToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.OrderTransactionsToolStripMenuItem.Text = "Order Transactions"
        '
        'TripSchedulingToolStripMenuItem
        '
        Me.TripSchedulingToolStripMenuItem.Image = CType(resources.GetObject("TripSchedulingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TripSchedulingToolStripMenuItem.Name = "TripSchedulingToolStripMenuItem"
        Me.TripSchedulingToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.TripSchedulingToolStripMenuItem.Text = "Trip Scheduling"
        '
        'TripDispatchingToolStripMenuItem
        '
        Me.TripDispatchingToolStripMenuItem.Image = CType(resources.GetObject("TripDispatchingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TripDispatchingToolStripMenuItem.Name = "TripDispatchingToolStripMenuItem"
        Me.TripDispatchingToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.TripDispatchingToolStripMenuItem.Text = "Trip Dispatching"
        '
        'TripDispatchSummaryToolStripMenuItem
        '
        Me.TripDispatchSummaryToolStripMenuItem.Image = CType(resources.GetObject("TripDispatchSummaryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TripDispatchSummaryToolStripMenuItem.Name = "TripDispatchSummaryToolStripMenuItem"
        Me.TripDispatchSummaryToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.TripDispatchSummaryToolStripMenuItem.Text = "Trip Dispatch Summary"
        '
        'TripSummaryToolStripMenuItem
        '
        Me.TripSummaryToolStripMenuItem.Image = CType(resources.GetObject("TripSummaryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TripSummaryToolStripMenuItem.Name = "TripSummaryToolStripMenuItem"
        Me.TripSummaryToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.TripSummaryToolStripMenuItem.Text = "Trip Summary"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TripScheduleReportToolStripMenuItem, Me.ForChangeOilToolStripMenuItem})
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.ReportsToolStripMenuItem.Text = "Reports"
        '
        'TripScheduleReportToolStripMenuItem
        '
        Me.TripScheduleReportToolStripMenuItem.Image = CType(resources.GetObject("TripScheduleReportToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TripScheduleReportToolStripMenuItem.Name = "TripScheduleReportToolStripMenuItem"
        Me.TripScheduleReportToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.TripScheduleReportToolStripMenuItem.Text = "Trip Schedule Report"
        '
        'ForChangeOilToolStripMenuItem
        '
        Me.ForChangeOilToolStripMenuItem.Image = CType(resources.GetObject("ForChangeOilToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ForChangeOilToolStripMenuItem.Name = "ForChangeOilToolStripMenuItem"
        Me.ForChangeOilToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.ForChangeOilToolStripMenuItem.Text = "For Change Oil"
        '
        'AdministratorToolStripMenuItem
        '
        Me.AdministratorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UsersToolStripMenuItem, Me.LoginLogsToolStripMenuItem, Me.VersionToolStripMenuItem, Me.AdjustQtyToolStripMenuItem, Me.InsertIntoDashboardToolStripMenuItem, Me.RestoreCommentToolStripMenuItem, Me.DeletePreviousAttachmentsToolStripMenuItem, Me.BackupToolStripMenuItem})
        Me.AdministratorToolStripMenuItem.Name = "AdministratorToolStripMenuItem"
        Me.AdministratorToolStripMenuItem.Size = New System.Drawing.Size(92, 20)
        Me.AdministratorToolStripMenuItem.Text = "Administrator"
        '
        'UsersToolStripMenuItem
        '
        Me.UsersToolStripMenuItem.Image = CType(resources.GetObject("UsersToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UsersToolStripMenuItem.Name = "UsersToolStripMenuItem"
        Me.UsersToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.UsersToolStripMenuItem.Text = "Users"
        '
        'LoginLogsToolStripMenuItem
        '
        Me.LoginLogsToolStripMenuItem.Image = CType(resources.GetObject("LoginLogsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LoginLogsToolStripMenuItem.Name = "LoginLogsToolStripMenuItem"
        Me.LoginLogsToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.LoginLogsToolStripMenuItem.Text = "Login Logs"
        '
        'VersionToolStripMenuItem
        '
        Me.VersionToolStripMenuItem.Image = CType(resources.GetObject("VersionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VersionToolStripMenuItem.Name = "VersionToolStripMenuItem"
        Me.VersionToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.VersionToolStripMenuItem.Text = "Version"
        '
        'AdjustQtyToolStripMenuItem
        '
        Me.AdjustQtyToolStripMenuItem.Image = CType(resources.GetObject("AdjustQtyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AdjustQtyToolStripMenuItem.Name = "AdjustQtyToolStripMenuItem"
        Me.AdjustQtyToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.AdjustQtyToolStripMenuItem.Text = "Adjust Qty"
        '
        'InsertIntoDashboardToolStripMenuItem
        '
        Me.InsertIntoDashboardToolStripMenuItem.Image = CType(resources.GetObject("InsertIntoDashboardToolStripMenuItem.Image"), System.Drawing.Image)
        Me.InsertIntoDashboardToolStripMenuItem.Name = "InsertIntoDashboardToolStripMenuItem"
        Me.InsertIntoDashboardToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.InsertIntoDashboardToolStripMenuItem.Text = "Insert into Dashboard"
        '
        'RestoreCommentToolStripMenuItem
        '
        Me.RestoreCommentToolStripMenuItem.Image = CType(resources.GetObject("RestoreCommentToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RestoreCommentToolStripMenuItem.Name = "RestoreCommentToolStripMenuItem"
        Me.RestoreCommentToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.RestoreCommentToolStripMenuItem.Text = "Restore Comment"
        '
        'DeletePreviousAttachmentsToolStripMenuItem
        '
        Me.DeletePreviousAttachmentsToolStripMenuItem.Image = CType(resources.GetObject("DeletePreviousAttachmentsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DeletePreviousAttachmentsToolStripMenuItem.Name = "DeletePreviousAttachmentsToolStripMenuItem"
        Me.DeletePreviousAttachmentsToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.DeletePreviousAttachmentsToolStripMenuItem.Text = "Delete Previous Attachments"
        '
        'BackupToolStripMenuItem
        '
        Me.BackupToolStripMenuItem.Image = CType(resources.GetObject("BackupToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BackupToolStripMenuItem.Name = "BackupToolStripMenuItem"
        Me.BackupToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.BackupToolStripMenuItem.Text = "Backup"
        '
        'mditrip
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(1269, 701)
        Me.Controls.Add(Me.MenuStrip2)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip2
        Me.Name = "mditrip"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Fleet Management System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip2 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents logouttool As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GeneralToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleTripToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AdministratorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CompanyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WarehouseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DocumentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DriverToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelperToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CategoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ItemsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreateOrderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OrderTransactionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripSchedulingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripDispatchingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripDispatchSummaryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripSummaryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripScheduleReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ForChangeOilToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UsersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoginLogsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VersionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AdjustQtyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InsertIntoDashboardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestoreCommentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeletePreviousAttachmentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
