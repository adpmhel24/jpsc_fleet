﻿Public Class reason

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If Trim(txtreason.Text) <> "" Then
            vmanage.dreason = Trim(txtreason.Text)
            newdriver.dreason = Trim(txtreason.Text)
            newhelper.dreason = Trim(txtreason.Text)
            txtreason.Text = ""
            Me.Dispose()
        Else
            MsgBox("Reason should not be empty.", MsgBoxStyle.Information, "")
        End If
    End Sub

    Private Sub reason_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        txtreason.Text = ""
    End Sub

    Private Sub reason_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txtreason_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtreason.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtreason.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtreason.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtreason.Text.Length - 1
            Letter = txtreason.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtreason.Text = theText
        txtreason.Select(SelectionIndex - Change, 0)
    End Sub
End Class