﻿Imports System.IO
Imports System.Data.SqlClient
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.Windows.Forms
Imports System.ComponentModel

Public Class rptrephistoryprev
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim objRpt As New crrephistory, ds As New DataSet1
    Dim sqlquery As String, dscmd As SqlDataAdapter
    Public condition As String, cashr As String, ctr As Boolean = False
    Public printerneym As String

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub notifsreportprev_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'loadexp()


        Dim ds As New DataSet1
        Dim t As DataTable = ds.Tables.Add("Items")
        t.Columns.Add("Type", Type.GetType("System.String"))
        t.Columns.Add("Description", Type.GetType("System.String"))
        t.Columns.Add("Reason", Type.GetType("System.String"))
        t.Columns.Add("Date Started", Type.GetType("System.String"))
        t.Columns.Add("Date Finished", Type.GetType("System.String"))
        t.Columns.Add("Mechanic Name", Type.GetType("System.String"))
        t.Columns.Add("Remarks", Type.GetType("System.String"))


        Dim r As DataRow
        For Each row As DataGridViewRow In rephistory.grdrepair.Rows
            r = t.NewRow()
            r("Type") = rephistory.grdrepair.Rows(row.Index).Cells(1).Value
            r("Description") = rephistory.grdrepair.Rows(row.Index).Cells(2).Value
            r("Reason") = rephistory.grdrepair.Rows(row.Index).Cells(3).Value
            r("Date Started") = rephistory.grdrepair.Rows(row.Index).Cells(4).Value
            r("Date Finished") = rephistory.grdrepair.Rows(row.Index).Cells(6).Value
            r("Mechanic Name") = rephistory.grdrepair.Rows(row.Index).Cells(7).Value
            t.Rows.Add(r)
        Next

        Dim mytext As TextObject = CType(objRpt.ReportDefinition.ReportObjects("Text8"), TextObject)
        mytext.Text = "Date: " & Format(rephistory.datefrom.Value, "yyyy/MM/dd") & " - " & Format(rephistory.dateto.Value, "yyyy/MM/dd")
        Dim mytext1 As TextObject = CType(objRpt.ReportDefinition.ReportObjects("Text9"), TextObject)
        mytext1.Text = vmanage.lblplatebig.Text


        'MsgBox(ds.Tables("Items").Rows.Count)
        objRpt.SetDataSource(ds.Tables("Items"))
        CrystalReportViewer1.ReportSource = objRpt
        CrystalReportViewer1.Refresh()
    End Sub
End Class