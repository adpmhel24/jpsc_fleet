﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class updatevdocs
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(updatevdocs))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lblexp = New System.Windows.Forms.Label
        Me.chkuse = New System.Windows.Forms.CheckBox
        Me.lbldocid = New System.Windows.Forms.Label
        Me.cmbinterval = New System.Windows.Forms.ComboBox
        Me.num = New System.Windows.Forms.NumericUpDown
        Me.dateexpired = New System.Windows.Forms.DateTimePicker
        Me.Label20 = New System.Windows.Forms.Label
        Me.cmbdocname = New System.Windows.Forms.ComboBox
        Me.datelastrenew = New System.Windows.Forms.DateTimePicker
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.cmbcompany = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.cmbwhse = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.grddoc = New System.Windows.Forms.DataGridView
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column4 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.btnupdate = New System.Windows.Forms.Button
        Me.btncancel = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        CType(Me.num, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.grddoc, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblexp)
        Me.GroupBox1.Controls.Add(Me.chkuse)
        Me.GroupBox1.Controls.Add(Me.lbldocid)
        Me.GroupBox1.Controls.Add(Me.cmbinterval)
        Me.GroupBox1.Controls.Add(Me.num)
        Me.GroupBox1.Controls.Add(Me.dateexpired)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.cmbdocname)
        Me.GroupBox1.Controls.Add(Me.datelastrenew)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Location = New System.Drawing.Point(14, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(575, 134)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Document"
        '
        'lblexp
        '
        Me.lblexp.AutoSize = True
        Me.lblexp.Location = New System.Drawing.Point(512, 109)
        Me.lblexp.Name = "lblexp"
        Me.lblexp.Size = New System.Drawing.Size(26, 15)
        Me.lblexp.TabIndex = 51
        Me.lblexp.Text = "exp"
        Me.lblexp.Visible = False
        '
        'chkuse
        '
        Me.chkuse.AutoSize = True
        Me.chkuse.Checked = True
        Me.chkuse.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkuse.Location = New System.Drawing.Point(29, 77)
        Me.chkuse.Name = "chkuse"
        Me.chkuse.Size = New System.Drawing.Size(141, 19)
        Me.chkuse.TabIndex = 50
        Me.chkuse.Text = "Use Tracking Interval"
        Me.chkuse.UseVisualStyleBackColor = True
        '
        'lbldocid
        '
        Me.lbldocid.AutoSize = True
        Me.lbldocid.Location = New System.Drawing.Point(499, 54)
        Me.lbldocid.Name = "lbldocid"
        Me.lbldocid.Size = New System.Drawing.Size(39, 15)
        Me.lbldocid.TabIndex = 49
        Me.lbldocid.Text = "Docid"
        Me.lbldocid.Visible = False
        '
        'cmbinterval
        '
        Me.cmbinterval.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbinterval.Enabled = False
        Me.cmbinterval.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmbinterval.FormattingEnabled = True
        Me.cmbinterval.Items.AddRange(New Object() {"", "Year(s)", "Month(s)", "Day(s)"})
        Me.cmbinterval.Location = New System.Drawing.Point(290, 71)
        Me.cmbinterval.Name = "cmbinterval"
        Me.cmbinterval.Size = New System.Drawing.Size(143, 23)
        Me.cmbinterval.TabIndex = 47
        '
        'num
        '
        Me.num.Enabled = False
        Me.num.Location = New System.Drawing.Point(220, 72)
        Me.num.Maximum = New Decimal(New Integer() {31, 0, 0, 0})
        Me.num.Name = "num"
        Me.num.Size = New System.Drawing.Size(63, 21)
        Me.num.TabIndex = 46
        '
        'dateexpired
        '
        Me.dateexpired.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dateexpired.Location = New System.Drawing.Point(220, 100)
        Me.dateexpired.Name = "dateexpired"
        Me.dateexpired.Size = New System.Drawing.Size(254, 21)
        Me.dateexpired.TabIndex = 48
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(25, 107)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(93, 15)
        Me.Label20.TabIndex = 44
        Me.Label20.Text = "Expiration Date:"
        '
        'cmbdocname
        '
        Me.cmbdocname.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbdocname.FormattingEnabled = True
        Me.cmbdocname.Location = New System.Drawing.Point(220, 14)
        Me.cmbdocname.Name = "cmbdocname"
        Me.cmbdocname.Size = New System.Drawing.Size(312, 23)
        Me.cmbdocname.TabIndex = 43
        '
        'datelastrenew
        '
        Me.datelastrenew.CustomFormat = ""
        Me.datelastrenew.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datelastrenew.Location = New System.Drawing.Point(220, 44)
        Me.datelastrenew.Name = "datelastrenew"
        Me.datelastrenew.Size = New System.Drawing.Size(254, 21)
        Me.datelastrenew.TabIndex = 45
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(25, 51)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(115, 15)
        Me.Label16.TabIndex = 42
        Me.Label16.Text = "Last Renewal Date:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(25, 24)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(104, 15)
        Me.Label15.TabIndex = 41
        Me.Label15.Text = "Document Name:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.cmbcompany)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.cmbwhse)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.grddoc)
        Me.GroupBox2.Location = New System.Drawing.Point(14, 144)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(575, 432)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Vehicle"
        '
        'cmbcompany
        '
        Me.cmbcompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcompany.FormattingEnabled = True
        Me.cmbcompany.Location = New System.Drawing.Point(109, 24)
        Me.cmbcompany.Name = "cmbcompany"
        Me.cmbcompany.Size = New System.Drawing.Size(149, 23)
        Me.cmbcompany.TabIndex = 55
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(26, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 15)
        Me.Label2.TabIndex = 54
        Me.Label2.Text = "Company:"
        '
        'cmbwhse
        '
        Me.cmbwhse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbwhse.FormattingEnabled = True
        Me.cmbwhse.Location = New System.Drawing.Point(383, 21)
        Me.cmbwhse.Name = "cmbwhse"
        Me.cmbwhse.Size = New System.Drawing.Size(149, 23)
        Me.cmbwhse.TabIndex = 53
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(300, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 15)
        Me.Label1.TabIndex = 52
        Me.Label1.Text = "Warehouse:"
        '
        'grddoc
        '
        Me.grddoc.AllowUserToAddRows = False
        Me.grddoc.AllowUserToDeleteRows = False
        Me.grddoc.AllowUserToResizeRows = False
        Me.grddoc.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grddoc.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grddoc.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddoc.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grddoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grddoc.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.DataGridViewTextBoxColumn2, Me.Column2, Me.Column4})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddoc.DefaultCellStyle = DataGridViewCellStyle2
        Me.grddoc.Location = New System.Drawing.Point(7, 62)
        Me.grddoc.Name = "grddoc"
        Me.grddoc.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddoc.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.grddoc.RowHeadersWidth = 10
        Me.grddoc.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddoc.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.grddoc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.grddoc.Size = New System.Drawing.Size(561, 362)
        Me.grddoc.TabIndex = 39
        '
        'Column1
        '
        Me.Column1.HeaderText = "ID"
        Me.Column1.Name = "Column1"
        Me.Column1.Visible = False
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Plate Number*"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 200
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 200
        '
        'Column2
        '
        Me.Column2.HeaderText = "Vehicle Type"
        Me.Column2.MinimumWidth = 160
        Me.Column2.Name = "Column2"
        Me.Column2.Width = 160
        '
        'Column4
        '
        Me.Column4.HeaderText = "Select"
        Me.Column4.MinimumWidth = 130
        Me.Column4.Name = "Column4"
        Me.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column4.Width = 130
        '
        'btnupdate
        '
        Me.btnupdate.Enabled = False
        Me.btnupdate.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdate.Image = CType(resources.GetObject("btnupdate.Image"), System.Drawing.Image)
        Me.btnupdate.Location = New System.Drawing.Point(346, 582)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(118, 34)
        Me.btnupdate.TabIndex = 35
        Me.btnupdate.Text = "Update"
        Me.btnupdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnupdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnupdate.UseVisualStyleBackColor = True
        '
        'btncancel
        '
        Me.btncancel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.Image = CType(resources.GetObject("btncancel.Image"), System.Drawing.Image)
        Me.btncancel.Location = New System.Drawing.Point(472, 582)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(110, 34)
        Me.btncancel.TabIndex = 37
        Me.btncancel.Text = "Cancel"
        Me.btncancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(651, 150)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(87, 27)
        Me.Button1.TabIndex = 38
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(645, 144)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(110, 61)
        Me.Label3.TabIndex = 39
        '
        'updatevdocs
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(606, 625)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "updatevdocs"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Vehicle Documents"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.num, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.grddoc, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblexp As System.Windows.Forms.Label
    Friend WithEvents chkuse As System.Windows.Forms.CheckBox
    Friend WithEvents lbldocid As System.Windows.Forms.Label
    Friend WithEvents cmbinterval As System.Windows.Forms.ComboBox
    Friend WithEvents num As System.Windows.Forms.NumericUpDown
    Friend WithEvents dateexpired As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents cmbdocname As System.Windows.Forms.ComboBox
    Friend WithEvents datelastrenew As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents grddoc As System.Windows.Forms.DataGridView
    Friend WithEvents cmbwhse As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbcompany As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnupdate As System.Windows.Forms.Button
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewCheckBoxColumn
End Class
