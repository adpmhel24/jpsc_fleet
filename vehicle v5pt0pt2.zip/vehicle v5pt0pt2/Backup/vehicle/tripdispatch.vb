﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Drawing.Image
Imports System.Drawing.Imaging
Imports System.ComponentModel
Imports System.Net.NetworkInformation

Public Class tripdispatch
    Public wctab As String = ""

    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Dim ofdstp1 As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim picstp1 As PictureBox, meronstp1 As Boolean = False
    Dim ofdstp2 As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim picstp2 As PictureBox, meronstp2 As Boolean = False
    Dim ofdstp3 As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim picstp3 As PictureBox, meronstp3 As Boolean = False
    Dim ofdstp4 As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim picstp4 As PictureBox, meronstp4 As Boolean = False
    Dim ofdstp5 As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim picstp5 As PictureBox, meronstp5 As Boolean = False
    Dim ofdstp6 As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim picstp6 As PictureBox, meronstp6 As Boolean = False
    Dim ofdstp7 As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim picstp7 As PictureBox, meronstp7 As Boolean = False
    Dim ofdstp8 As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim picstp8 As PictureBox, meronstp8 As Boolean = False
    Dim ofdstp9 As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim picstp9 As PictureBox, meronstp9 As Boolean = False

    Public dispatchitems As Boolean, pass As Boolean = False, edited As Boolean = False, arrwhse As String = ""

    Dim hasrows7 As Boolean = False
    Dim hasrows8 As Boolean = False
    Dim selectedrow As Integer, editstep As Integer, toberecord As Integer = 0
    Dim doneload1 As Boolean = False, cancelledtrip As Boolean = False, completedstep As Boolean = False
    Private bgw As BackgroundWorker, threadEnabled As Boolean = False, grdsql As String, whatstep As Integer
    Dim triplink7 As Boolean = False, triplink8 As Boolean = False, triplink9 As Boolean = False
    Dim row9 As Integer = -1, cnf9 As Boolean = False
    Dim row7 As Integer = -1, cnf7 As Boolean = False

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub tripdispatch_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated

    End Sub

    Private Sub tripdispatch_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim a As String = MsgBox("Are you sure you want to close?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            'Stop background operation
            bgw.CancelAsync()
            '/moduless.Show()
            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub tripsched_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lbls7.Text = login.whsecode
        lbls9.Text = login.whsecode

        If login.userwhse = "All" Or login.userwhse = login.whse Then
            If login.neym = "LC Accounting Staff" Or login.neym = "AGI Accounting Staff" Then
                cmbwhse9.SelectedItem = login.neym
            Else
                cmbwhse9.SelectedItem = "All"
            End If
        Else
            cmbwhse9.SelectedItem = login.userwhse
        End If

        grdtrans4.Columns(1).ReadOnly = True
        grdtrans4.Columns(2).ReadOnly = True
        grdtrans4.Columns(3).ReadOnly = True
        grdtrans4.Columns(12).ReadOnly = True

        grdtrans3.ReadOnly = True
        grdtrans5.ReadOnly = True

        grdtrans7.Columns(3).Frozen = True
        grdtrans7.ReadOnly = False
        grdtrans7.Columns(1).ReadOnly = True
        grdtrans7.Columns(2).ReadOnly = True
        grdtrans7.Columns(3).ReadOnly = True
        grdtrans7.Columns(13).ReadOnly = True
        grdtrans7.Columns(14).ReadOnly = True

        grdtrans9.Columns(3).Frozen = True
        If login.neym = "LC Accounting Staff" Or login.neym = "AGI Accounting Staff" Then
            grdtrans9.ReadOnly = True
        Else
            grdtrans9.ReadOnly = False
            grdtrans9.Columns(1).ReadOnly = True
            grdtrans9.Columns(2).ReadOnly = True
            grdtrans9.Columns(3).ReadOnly = True
            grdtrans9.Columns(13).ReadOnly = True
            grdtrans9.Columns(14).ReadOnly = True
            grdtrans9.Columns(15).ReadOnly = True
            grdtrans9.Columns(16).ReadOnly = True
            grdtrans9.Columns(18).ReadOnly = True
            grdtrans9.Columns(19).ReadOnly = True
        End If

        If login.neym = "Guard" Then
            tripstep6()
        ElseIf login.neym = "Inspector" Then
            tripstep1()
        ElseIf login.neym = "Motorpool Inspector" Then
            tripstep8()
        ElseIf login.neym = "Whse Logistics Staff" Then
            tripstep1()
        ElseIf login.neym = "Diesel Controller" Then
            tripstep8()
        ElseIf login.neym = "Checker" Then
            tripstep3()
        ElseIf login.neym = "Manager" Then
            tripstep4()
        ElseIf login.neym = "Encoder" Then
            tripstep4()
        ElseIf login.neym = "Whse Accounting Staff" Then
            If login.userwhse <> "All" And login.userwhse <> login.whse Then
                tripstep9()
            Else
                tripstep5()
            End If
        ElseIf login.neym = "LC Accounting Staff" Or login.neym = "AGI Accounting Staff" Then
            tripstep9()
        Else
            tripstep1()
        End If
    End Sub

    Private Sub TabControl1_DrawItem(ByVal sender As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) Handles TabControl1.DrawItem
        Dim tabContas As TabControl = DirectCast(sender, TabControl)
        Dim sTexto As String = tabContas.TabPages(e.Index).Text
        Dim g As Graphics = e.Graphics
        Dim fonte As Font = tabContas.Font
        Dim format = New System.Drawing.StringFormat
        'CHANGES HERE...
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center
        Dim pincel As New SolidBrush(Color.Black)
        'RENEMED VARIEBLE HERE...
        Dim retangulo As RectangleF = RectangleF.op_Implicit(tabContas.GetTabRect(e.Index))
        If tabContas.SelectedIndex = e.Index Then
            fonte = New Font(fonte, FontStyle.Bold)
            pincel = New SolidBrush(Color.Black)
            'CHANGED BACKGROUN COLOR HERE...
            g.FillRectangle(Brushes.Azure, retangulo)
        End If
        g.DrawString(sTexto, fonte, pincel, retangulo, format)
    End Sub

    Private Sub TabControl1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TabControl1.MouseClick
        'If TabControl1.SelectedTab Is tab1 Then
        If TabControl1.SelectedIndex = 0 Then
            wctab = "tab1"
            If grdstep1.Rows.Count = 0 Then
                tripstep1()
            End If
        ElseIf TabControl1.SelectedIndex = 1 Then
            wctab = "tab2"
            If grdstep2.Rows.Count = 0 Then
                tripstep2()
            End If
        ElseIf TabControl1.SelectedIndex = 2 Then
            wctab = "tab3"
            If grdstep3.Rows.Count = 0 Then
                tripstep3()
            End If
        ElseIf TabControl1.SelectedIndex = 3 Then
            wctab = "tab4"
            If grdstep4.Rows.Count = 0 Then
                tripstep4()
            End If
        ElseIf TabControl1.SelectedIndex = 4 Then
            wctab = "tab5"
            If grdstep5.Rows.Count = 0 Then
                tripstep5()
            End If
        ElseIf TabControl1.SelectedIndex = 5 Then
            wctab = "tab6"
            If grdstep6.Rows.Count = 0 Then
                tripstep6()
            End If
        ElseIf TabControl1.SelectedIndex = 6 Then
            wctab = "tab7"
            If grdstep7.Rows.Count = 0 Then
                tripstep7()
            End If
        ElseIf TabControl1.SelectedIndex = 7 Then
            wctab = "tab8"
            If grdstep8.Rows.Count = 0 Then
                tripstep8()
            End If
        ElseIf TabControl1.SelectedIndex = 8 Then
            wctab = "tab9"
            If grdstep9.Rows.Count = 0 Then
                tripstep9()
                '/MsgBox(row9)
            End If
        End If
    End Sub

    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl1.SelectedIndexChanged
        ' Check Credentials Here 
        panelstp1.Visible = False
        panelstp2.Visible = False
        panelstp3.Visible = False
        panelstp4.Visible = False
        panelstp5.Visible = False
        panelstp6.Visible = False
        panelstp7.Visible = False
        panelstp8.Visible = False
        panelstp9.Visible = False

        If TabControl1.SelectedTab Is tab1 Then 'truck checking
            If login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Guard" And login.neym <> "Manager" And login.neym <> "Whse Logistics Staff" And login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                access()
            Else
                panelstp1.Visible = True
                TabControl1.SelectedTab = tab1
                wctab = "tab1"
            End If

        ElseIf TabControl1.SelectedTab Is tab2 Then  'diesel
            If login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Manager" And login.neym <> "Whse Logistics Staff" And login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                access()
            Else
                panelstp2.Visible = True
                TabControl1.SelectedTab = tab2
                wctab = "tab2"
            End If

        ElseIf TabControl1.SelectedTab Is tab3 Then 'loading
            If login.neym <> "Checker" And login.neym <> "Manager" And login.neym <> "Whse Logistics Staff" And login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                access()
            Else
                panelstp3.Visible = True
                TabControl1.SelectedTab = tab3
                wctab = "tab3"
            End If

        ElseIf TabControl1.SelectedTab Is tab4 Then 'release
            If login.neym <> "Encoder" And login.neym <> "Manager" And login.neym <> "Whse Logistics Staff" And login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                If (login.neym = "Inspector" Or login.neym = "Diesel Controller" Or login.neym = "Checker") And (login.whse = "C3 Manila" Or login.whse = "Calamba") Then

                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    access()
                    Exit Sub
                End If
            End If

            panelstp4.Visible = True
            TabControl1.SelectedTab = tab4
            wctab = "tab4"

            grdtrans4.Columns(4).ReadOnly = False
            grdtrans4.Columns(5).ReadOnly = False
            grdtrans4.Columns(7).ReadOnly = False
            grdtrans4.Columns(8).ReadOnly = False
            grdtrans4.Columns(9).ReadOnly = False
            grdtrans4.Columns(10).ReadOnly = False
            grdtrans4.Columns(11).ReadOnly = False
            grdtrans4.Columns(13).ReadOnly = False

        ElseIf TabControl1.SelectedTab Is tab5 Then 'petty
            If login.neym <> "Manager" And login.neym <> "Whse Logistics Staff" And login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Whse Accounting Staff" And login.neym <> "Logistics Staff" Then
                If (login.neym = "Inspector" Or login.neym = "Diesel Controller" Or login.neym = "Checker") And (login.whse = "C3 Manila" Or login.whse = "Calamba") Then

                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    access()
                    Exit Sub
                End If
            End If

            If login.neym = "Whse Accounting Staff" And login.userwhse <> "All" And login.userwhse <> login.whse Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                access()
                Exit Sub
            End If

            panelstp5.Visible = True
            TabControl1.SelectedTab = tab5
            wctab = "tab5"

        ElseIf TabControl1.SelectedTab Is tab6 Then
            If login.neym <> "Guard" And login.neym <> "Manager" And login.neym <> "Whse Logistics Staff" And login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Diesel Controller" And login.neym <> "Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                access()
            Else
                panelstp6.Visible = True
                TabControl1.SelectedTab = tab6
                wctab = "tab6"
            End If

        ElseIf TabControl1.SelectedTab Is tab7 Then
            If login.neym <> "Manager" And login.neym <> "Whse Logistics Staff" And login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Whse Accounting Staff" And login.neym <> "Logistics Staff" And login.neym <> "Encoder" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                access()
                Exit Sub
            End If

            If login.neym = "Whse Accounting Staff" And login.userwhse <> "All" And login.userwhse <> login.whse Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                access()
                Exit Sub
            End If

            panelstp7.Visible = True
            TabControl1.SelectedTab = tab7
            wctab = "tab7"

        ElseIf TabControl1.SelectedTab Is tab8 Then  'diesel
            If login.neym <> "Motorpool Inspector" And login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Manager" And login.neym <> "Whse Logistics Staff" And login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                access()
            Else
                panelstp8.Visible = True
                TabControl1.SelectedTab = tab8
                wctab = "tab8"
            End If

        ElseIf TabControl1.SelectedTab Is tab9 Then  'record
            If login.neym <> "Manager" And login.neym <> "Whse Logistics Staff" And login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Whse Accounting Staff" And login.neym <> "Logistics Staff" And login.neym <> "Encoder" And login.neym <> "LC Accounting Staff" And login.neym <> "AGI Accounting Staff" Then
                If login.neym = "Diesel Controller" And login.whse = "Calamba" Then

                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    access()
                    Exit Sub
                End If
            End If

            panelstp9.Visible = True
            TabControl1.SelectedTab = tab9
            wctab = "tab9"

            If login.neym = "LC Accounting Staff" Or login.neym = "AGI Accounting Staff" Then
                grdtrans9.ReadOnly = True
            Else
                grdtrans9.ReadOnly = False
                grdtrans9.Columns(1).ReadOnly = True
                grdtrans9.Columns(2).ReadOnly = True
                grdtrans9.Columns(3).ReadOnly = True
                grdtrans9.Columns(13).ReadOnly = True
                grdtrans9.Columns(14).ReadOnly = True
                grdtrans9.Columns(15).ReadOnly = True
                grdtrans9.Columns(16).ReadOnly = True
                grdtrans9.Columns(18).ReadOnly = True
                grdtrans9.Columns(19).ReadOnly = True
            End If
        End If

    End Sub

    Public Sub access()
        If login.neym = "Guard" Then
            TabControl1.SelectedTab = tab6
        ElseIf login.neym = "Inspector" Then
            TabControl1.SelectedTab = tab1
        ElseIf login.neym = "Motorpool Inspector" Then
            TabControl1.SelectedTab = tab8
        ElseIf login.neym = "Whse Logistics Staff" Then
            TabControl1.SelectedTab = tab1
        ElseIf login.neym = "Diesel Controller" Then
            TabControl1.SelectedTab = tab8
        ElseIf login.neym = "Checker" Then
            TabControl1.SelectedTab = tab3
        ElseIf login.neym = "Manager" Then
            TabControl1.SelectedTab = tab4
        ElseIf login.neym = "Encoder" Then
            TabControl1.SelectedTab = tab4
        ElseIf login.neym = "Whse Accounting Staff" Then
            If login.userwhse <> "All" And login.userwhse <> login.whse Then
                TabControl1.SelectedTab = tab9
            Else
                TabControl1.SelectedTab = tab5
            End If
        ElseIf login.neym = "LC Accounting Staff" Or login.neym = "AGI Accounting Staff" Then
            TabControl1.SelectedTab = tab9
        End If
    End Sub

    Private Sub TabControl1_TabIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl1.TabIndexChanged
        If TabControl1.SelectedTab Is tab1 Then
            wctab = "tab1"

            If login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Guard" Then
                If login.neym = "Manager" Or login.neym = "Whse Logistics Staff" Then
                    panelstp4.Visible = True
                    'TabControl1.SelectedTab = tab5
                    Me.Cursor = Cursors.Default
                    Exit Sub

                ElseIf login.neym = "Administrator" Or login.neym = "Supervisor" Or login.neym = "Logistics Staff" Then

                Else
                    ' MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    access()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            End If

            If login.neym = "Guard" Then
                panelstp6.Visible = True
                TabControl1.SelectedTab = tab6
                wctab = "tab6"
            Else
                panelstp1.Visible = True
                TabControl1.SelectedTab = tab1
                wctab = "tab1"
            End If

        ElseIf TabControl1.SelectedTab Is tab2 Then
            wctab = "tab2"
        ElseIf TabControl1.SelectedTab Is tab3 Then
            wctab = "tab3"
        ElseIf TabControl1.SelectedTab Is tab4 Then
            wctab = "tab4"
        ElseIf TabControl1.SelectedTab Is tab5 Then
            wctab = "tab5"
        ElseIf TabControl1.SelectedTab Is tab6 Then
            wctab = "tab6"
        ElseIf TabControl1.SelectedTab Is tab7 Then
            wctab = "tab7"
        ElseIf TabControl1.SelectedTab Is tab8 Then
            wctab = "tab8"
        ElseIf TabControl1.SelectedTab Is tab9 Then
            wctab = "tab9"
        End If
    End Sub

    Public Sub tripstep1()
        Try
            Me.Cursor = Cursors.WaitCursor
            grp1.Enabled = True
            grdstep1.Rows.Clear()

            sql = "SELECT tbltripsum.tripsumid,tbltripsum.tripnum,tbltripsum.platenum,tbltripsum.driver,tbltripsum.helper,tbltripsum.datepick,tbldispatchsum.whsename9,tbldispatchsum.timedep"
            sql = sql & " FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum"
            sql = sql & " where tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' and tbldispatchsum.step1='0' order by datepick"   ' and tbltripsum.datepick<='" & Format(Date.Now, "MM/dd/yyyy") & "''////   
            grdsql = sql
            whatstep = 1

            bgw = New BackgroundWorker()

            AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
            AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
            AddHandler bgw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not bgw.IsBusy Then
                lblload1.Visible = True
                bgw.WorkerReportsProgress = True
                bgw.WorkerSupportsCancellation = True
                bgw.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub zero1()
        lblplate1.Text = ""
        lbltype1.Text = ""
        lbltripnum1.Text = ""
        lblconfirm1.Text = 0
        txtrems1.Text = ""
        txtodo.Text = 0
        txtodoend1.Text = 0
        btnstartpre.Text = "TIME START PRE-INSPECTION"

        imgpanel1.Visible = False
        imgpanel1.Controls.Clear()
        imgpanel1.Visible = True
    End Sub

    Private Sub grdstep1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep1.CellClick
        Try
            zero1()
            Me.Cursor = Cursors.WaitCursor

            lbltripnum1.Tag = grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(0).Value
            lbltripnum1.Text = grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(1).Value
            lblplate1.Text = grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(2).Value

            SelectStep1(strconn)

            btnimgrefresh1.PerformClick()

            If grdstep1.Rows.Count <> 0 Then
                grp1.Text = lbltripnum1.Text & "     -     " & grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(5).Value
            Else
                grp1.Text = "Photos"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdstep1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep1.CellContentClick

    End Sub

    Private Sub grdstep1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdstep1.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Up Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Down Then
            e.Handled = True
        End If
    End Sub

    Private Sub grdstep1_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grdstep1.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdstep1.Rows(e.RowIndex)
            '<== But this is the name assigned to it in the properties of the control
            'If CDate(Format(dgvRow.Cells(1).Value, "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
            If dgvRow.Cells(5).Value <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
                dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
            End If
        End If
    End Sub

    Private Sub grdstep1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdstep1.SelectionChanged
        
    End Sub

    Private Sub SelectStep1(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim drstep As SqlDataReader
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Select vtype from tblgeneral where platenum='" & lblplate1.Text & "' or vplate='" & lblplate1.Text & "' or csticker='" & lblplate1.Text & "'"
                command.CommandText = sql
                drstep = command.ExecuteReader
                If drstep.Read Then
                    lbltype1.Text = drstep("vtype")
                End If
                drstep.Dispose()


                'sql = "Select TOP 1 odoend from tbltripsum where status<>'3' and platenum='" & lblplate1.Text & "' and tripsumid<'" & grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(0).Value & "' order by tripsumid DESC"
                'command.CommandText = sql
                'drstep = command.ExecuteReader
                'If drstep.Read Then
                '    txtodoend1.Text = drstep("odoend")
                'Else
                '    txtodoend1.Text = 0
                'End If
                'drstep.Dispose()


                btnodo.Visible = False
                btnodo.Tag = 1
                sql = "Select TOP 1 cstatstp8, odoend from tbldispatchsum inner join tbltripsum on tbltripsum.tripnum=tbldispatchsum.tripnum"
                sql = sql & " where status<>'3' and platenum='" & lblplate1.Text & "' and tripsumid<'" & grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(0).Value & "' order by tripsumid DESC"
                command.CommandText = sql
                drstep = command.ExecuteReader
                If drstep.Read Then
                    txtodoend1.Text = drstep("odoend")
                    If IsDBNull(drstep("cstatstp8")) = False Then
                        If drstep("cstatstp8") = 0 Then
                            btnodo.Visible = True
                            btnodo.Tag = 0
                        Else
                            btnodo.Visible = False
                        End If
                    Else
                        btnodo.Visible = False
                    End If
                Else
                    txtodoend1.Text = 0
                End If
                drstep.Dispose()


                sql = "Select odoactual from tbltripsum where tripnum='" & lbltripnum1.Text & "'"
                command.CommandText = sql
                drstep = command.ExecuteReader
                If drstep.Read Then
                    txtodo.Text = drstep("odoactual")
                End If
                drstep.Dispose()

                btnstartpre.Text = "TIME START PRE-INSPECTION"
                sql = "Select step1,startpre,remstp1 from tbldispatchsum where tripnum='" & lbltripnum1.Text & "'"
                command.CommandText = sql
                drstep = command.ExecuteReader
                If drstep.Read Then
                    If drstep("step1") = 1 Then
                        lblconfirm1.Text = 1
                    End If

                    If drstep("startpre").ToString <> "" Then
                        Dim starttime As Date
                        Dim timeCheck As Boolean
                        timeCheck = IsDate(drstep("startpre").ToString)
                        If timeCheck = True Then
                            'MsgBox(Trim(txttime.Text) & timeCheck)
                            starttime = CDate(drstep("startpre").ToString)
                            btnstartpre.Text = "TIME START PRE-INSPECTION: " & Format(starttime, "HH:mm")
                            txtrems1.Text = drstep("remstp1").ToString
                            startprefalse()
                            btnimgadd1.Enabled = True
                            btnexempt1.Enabled = True
                            btnconfirm1.Enabled = True
                        End If
                    Else
                        btnstartpre.Enabled = True
                        txtodo.Enabled = False
                        btnodo.Enabled = False
                        txtrems1.Enabled = False
                        txtrems1.Text = ""
                        tripinfo1.Enabled = True
                        btnimgadd1.Enabled = False
                        btnexempt1.Enabled = False
                    End If
                End If
                drstep.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.ToString, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.ToString & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btnrefstep1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrefstep1.Click
        tripstep1()
    End Sub

    Private Sub btnimgadd1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgadd1.Click
        Try
            If login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Guard" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum1.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum1.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum1.Text, "step1")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 1 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgadd1.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofdstp1.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox1.Image = Nothing
                    Dim bmp As New Bitmap(ofdstp1.FileName)
                    imgbox1.Image = bmp

                    '/imgbox1.Image = LoadImage(ofdstp1.FileName)
                    cmbimg1.Text = ofdstp1.SafeFileName.ToString.Replace("'", "")
                    cmbimg1.Enabled = True
                    cmbimg1.Focus()

                    lblCompressionLevel.Text = ""

                    ' Display the file's size.
                    Dim file_info As New FileInfo(ofdstp1.FileName)
                    lblOriginalSize.Text = FormatBytes(file_info.Length)
                    If Microsoft.VisualBasic.Right(ofdstp1.FileName.ToString, 3) = "png" Then
                        lblDesiredSize.Text = FormatBytes(file_info.Length * 0.3)
                    Else
                        lblDesiredSize.Text = "1.10 MB" 'FormatBytes(file_info.Length * 0.4)
                    End If
                    lblCompressedSize.Text = ""
                    lblCompressionLevel.Text = ""

                    Me.Cursor = Cursors.Default
                    imgpanel1.Enabled = False
                    '/enabletab4only()
                    imgcanceltrue1()
                    btnimgadd1.Enabled = True
                    btnimgadd1.Text = "Add"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(cmbimg1.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg1.Focus()
                    Exit Sub
                End If

                If cmbimg1.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photoname.", MsgBoxStyle.Exclamation, "")
                    cmbimg1.Text = ""
                    cmbimg1.Focus()
                    Exit Sub
                End If

                Dim origsize As String = lblOriginalSize.Text
                If Val(origsize.Substring(0, origsize.Length - 2)) > 1 And Microsoft.VisualBasic.Right(origsize, 2) = "MB" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Image exceeds the maximum file size 1MB." & vbCrLf & "Compressing image. Please wait.", MsgBoxStyle.Information)

                    Button3.PerformClick()
                    pgbar1.Visible = True

                    If BackgroundWorker1.IsBusy = False Then
                        BackgroundWorker1.RunWorkerAsync()
                    End If

                    'COMPRESS IMAGE THEN REPLACE IMGBOX1.IMAGE NG COMPRESSED NA IMAGE
                    imgbox1.Image = compressimage(imgbox1.Image, Trim(cmbimg1.Text))
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.WaitCursor
                'insert photo in tblimg
                'search image name if existing
                conn.Open()
                '/connect()
                cmd = New SqlCommand("Select * from tbldispatchstp1 where tripnum='" & lbltripnum1.Text & "' and name='" & Trim(cmbimg1.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg1.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg1.Focus()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar1.Value = 0
                    pgbar1.Visible = False
                    Exit Sub
                Else
                    Dim ms As New MemoryStream()

                    'save record in database
                    connect()
                    '/cmd = New SqlCommand("Insert into tbldispatchstp1 values(@tripnum,@name,@img,@status,@datecreated,@createdby)", conn)
                    cmd = New SqlCommand("Insert into tbldispatchstp1 values(@tripnum,@name,@img,@status,GetDate(),@createdby)", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltripnum1.Text))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(cmbimg1.Text)))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                    imgbox1.Image.Save(ms, Imaging.ImageFormat.Jpeg)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    '/cmd.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                    cmd.ExecuteNonQuery()
                    conn.Close()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar1.Value = 0
                    pgbar1.Visible = False

                    MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    pgbar1.Value = 0
                    imgbox1.Image = Nothing
                    imgbox1.BackColor = Color.Empty
                    imgbox1.Invalidate()
                    ms.Close()
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.Default
                btnimgadd1.Text = "Add Photo"
                imgcancelfalse1()
                imgpanel1.Enabled = True
                '/enableall()
                btnimgrefresh1.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Function GetEncoder(ByVal format As ImageFormat) As ImageCodecInfo
        Dim codecs As ImageCodecInfo() = ImageCodecInfo.GetImageDecoders()

        For Each codec As ImageCodecInfo In codecs

            If codec.FormatID = format.Guid Then
                Return codec
            End If
        Next

        Return Nothing
    End Function

    ' Load a bitmap so it's not locked.
    Private Function LoadImage(ByVal file_name As String) As Bitmap
        Using bm As New Bitmap(file_name)
            Dim bm2 As New Bitmap(bm)
            Return bm2
        End Using
    End Function

    Private Function compressimage(ByVal picimage As Image, ByVal picname As String)

        Me.Cursor = Cursors.WaitCursor
        Dim desired_size As Double = FormattedBytesToBytes(lblDesiredSize.Text)
        '/MsgBox(desired_size)
        If desired_size > 10 Then
            lblCompressionLevel.Text = ""
            lblCompressedSize.Text = ""

            Dim file_name As String = picname
            Dim file_size As Long
            For compression_level As Integer = 100 To 10 Step -1
                ' Save the file into a memory stream.
                Dim memory_stream As MemoryStream = SaveJpegIntoStream(picimage, compression_level)

                ' See how big it is.
                file_size = memory_stream.Length
                If file_size <= desired_size Then
                    ' Display the final size and image.
                    ' Save the file.
                    '/My.Computer.FileSystem.WriteAllBytes(file_name, memory_stream.ToArray(), False)
                    Dim ms As New MemoryStream(memory_stream.ToArray())
                    picimage = Image.FromStream(ms)
                    '/picNew.Image = LoadImage(file_name)
                    lblCompressionLevel.Text = compression_level
                    lblCompressedSize.Text = FormatBytes(file_size)
                    Exit For
                End If
            Next
            Me.Cursor = Cursors.Default
        End If

        Return picimage

        If desired_size < 10 Then
            MessageBox.Show("Invalid desired size.", "Invalid Size", MessageBoxButtons.OK, MessageBoxIcon.Error)
            lblDesiredSize.Focus()
        End If

    End Function

    Public Sub imgcanceltrue1()
        btnimgadd1.Enabled = False
        btnimgrename1.Enabled = False
        btnimgremove1.Enabled = False
        btnimgcancel1.Enabled = True
        btnimgdl1.Enabled = False
        btnimgfull1.Enabled = True
        btnimgrefresh1.Enabled = False
    End Sub

    Public Sub imgcancelfalse1()
        cmbimg1.Text = ""
        lblimgdate1.Text = ""
        lblimgname1.Text = ""
        btnimgadd1.Text = "Add Photo"
        btnimgrename1.Text = "Rename"
        btnimgadd1.Enabled = True
        btnimgrename1.Enabled = True
        btnimgremove1.Enabled = True
        btnimgcancel1.Enabled = False
        btnimgdl1.Enabled = True
        btnimgfull1.Enabled = True
        btnimgrefresh1.Enabled = True
        btnexempt1.Enabled = True
        btnconfirm1.Enabled = True
    End Sub

    Private Sub btnimgrefresh1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrefresh1.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meronstp1 = False
            imgpanel1.Visible = False
            imgpanel1.Controls.Clear()
            imgpanel1.Visible = True

            Dim ctr As Integer = 0
            conn.Close()
            sql = "Select * from tbldispatchstp1 where tripnum='" & lbltripnum1.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                meronstp1 = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                picstp1 = New PictureBox
                picstp1.Image = Image.FromStream(ms)
                ms.Dispose()
                picstp1.SizeMode = PictureBoxSizeMode.Zoom
                picstp1.SetBounds(wid, y, 104, 100)
                'picstp1.BackColor = Color.AliceBlue
                picstp1.Tag = dr("stp1imgid")
                picstp1.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler picstp1.Click, AddressOf convertPic1
                imgpanel1.Controls.Add(picstp1)
                imgpanel1.Controls.Add(lbl)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            imgbox1.Image = Nothing
            cmbimg1.Text = ""
            lblimgid1.Text = ""
            lblimgdate1.Text = ""
            lblimgname1.Text = ""

            Me.Cursor = Cursors.Default

            If meronstp1 = False Then
                btnimgrename1.Enabled = False
                btnimgremove1.Enabled = False
                btnimgcancel1.Enabled = False
                btnimgdl1.Enabled = False
                btnimgfull1.Enabled = False
                btnconfirm1.Enabled = False
                If login.whse = "Cebu" Or login.whse = "Davao" Or login.whse = "Bacolod" Or login.whse = "Tacloban" Then
                    btnconfirm1.Enabled = True
                End If
            Else
                imgcancelfalse1()
            End If

            If grdstep1.Rows.Count = 0 Then
                grp1.Enabled = False
            Else
                grp1.Enabled = True
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Sub convertPic1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            picstp1 = CType(sender, PictureBox)
            imgbox1.Image = picstp1.Image
            lblimgid1.Text = picstp1.Tag

            sql = "Select name,datecreated,createdby from tbldispatchstp1 where stp1imgid='" & lblimgid1.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbimg1.Text = dr("name")
                If IsDBNull(dr("datecreated")) = False Then
                    lblimgdate1.Text = Format(dr("datecreated"), "MM/dd/yyyy h:mm tt")
                Else
                    lblimgdate1.Text = ""
                End If
                lblimgname1.Text = dr("createdby").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgfull1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgfull1.Click
        If lblimgid1.Text <> "" Or imgbox1.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox1.Image
            viewimage.lblimgname.Text = cmbimg1.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub btnconfirm1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnconfirm1.Click
        Try
            If login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Guard" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum1.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum1.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum1.Text, "step1")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 1 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL1 HAS CONTROLS
            If imgpanel1.Controls.Count = 0 And login.whse <> "Cebu" And login.whse <> "Davao" And login.whse <> "Bacolod" And login.whse <> "Tacloban" Then
                Me.Cursor = Cursors.Default
                MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Val(txtodo.Text) < Val(txtodoend1.Text) And Trim(txtrems1.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Actual start Odometer is less than the Previous Ending Odometer. Add Remarks.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Val(txtodo.Text) - Val(txtodoend1.Text) >= 5 And Trim(txtrems1.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Actual start Odometer is greater than the Previous Ending Odometer. Add Remarks.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If btnodo.Tag = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("Click the warn icon on Previous Ending Odometer to check the error on the previous trip (Step 8).", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Val(Trim(txtodo.Text)) <> 0 Then
                wctab = "tab1"

                sign.Width = 733
                sign.lblplate.Text = lblplate1.Text
                sign.GroupBox1.Text = "Driver (" & grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(3).Value & ")"
                sign.GroupBox4.Text = "Helper (" & grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(4).Value & ")"
                sign.GroupBox2.Text = login.neym & " (" & login.fullneym & ")"
                sign.lbltrip.Text = lbltripnum1.Text
                sign.lblrems.Text = txtrems1.Text 'para dun ndin isang save nlng

                sign.yescnf = False
                sign.ShowDialog()

                If sign.yescnf = True Then
                    zero1()
                    tripstep1()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Input actual odometer.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgrename1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrename1.Click
        Try
            If login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Guard" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum1.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum1.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum1.Text, "step1")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 1 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgrename1.Text = "Rename" Then
                If Trim(cmbimg1.Text) <> "" And imgbox1.Image IsNot Nothing Then
                    Dim tempname As String = Trim(cmbimg1.Text)
                    If tempname.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Cannot rename photo.", MsgBoxStyle.Exclamation, "")
                        cmbimg1.Focus()
                        Exit Sub
                    End If
                    cmbimg1.Enabled = True
                    cmbimg1.Focus()
                ElseIf Trim(cmbimg1.Text) = "" And imgbox1.Image IsNot Nothing Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg1.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    cmbimg1.Focus()
                    Exit Sub
                End If

                imgpanel1.Enabled = False
                imgcanceltrue1()
                btnimgrename1.Enabled = True
                btnimgrename1.Text = "Save"
            Else
                'search image name if existing
                connect()
                cmd = New SqlCommand("Select * from tbldispatchstp1 where tripnum='" & lbltripnum1.Text & "' and name='" & Trim(cmbimg1.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg1.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg1.Focus()
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()


                Me.Cursor = Cursors.Default

                If cmbimg1.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photo name.", MsgBoxStyle.Exclamation, "")
                    cmbimg1.Text = ""
                    cmbimg1.Focus()
                    Exit Sub
                End If

                'irename.. update yung name lng where imgid = lblimgid.text
                sql = "Update tbldispatchstp1 set name='" & Trim(cmbimg1.Text) & "' where stp1imgid='" & lblimgid1.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                btnimgrename1.Text = "Rename"
                imgcancelfalse1()
                imgpanel1.Enabled = True
                btnimgrefresh1.PerformClick()
                Me.Cursor = Cursors.Default
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgremove1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgremove1.Click
        Try
            If login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Guard" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum1.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum1.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum1.Text, "step1")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 1 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(cmbimg1.Text) <> "" And imgbox1.Image IsNot Nothing Then
                Me.Cursor = Cursors.Default

                If cmbimg1.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot delete signature", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2)
                If a = vbYes Then
                    'delete image where imgid=lblimgid.text
                    sql = "Delete from tbldispatchstp1 where stp1imgid='" & lblimgid1.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully remove.", MsgBoxStyle.Information, "")

                    imgcancelfalse1()
                    imgpanel1.Enabled = True
                    btnimgrefresh1.PerformClick()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                cmbimg1.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgcancel1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel1.Click
        Try
            imgpanel1.Enabled = True
            imgbox1.Image = Nothing
            cmbimg1.Text = ""
            lblimgid1.Text = ""
            imgcancelfalse1()

            If meronstp1 = False Then
                btnimgrename1.Enabled = False
                btnimgremove1.Enabled = False
                btnimgcancel1.Enabled = False
                btnimgdl1.Enabled = False
                btnimgfull1.Enabled = False
            Else
                imgcancelfalse1()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnexempt1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexempt1.Click
        Try
            If login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Guard" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum1.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum1.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum1.Text, "step1")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 1 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL1 HAS CONTROLS
            If imgpanel1.Controls.Count = 0 Then
                'MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
            End If

            pass = False
            confirmsave.GroupBox1.Text = login.neym
            confirmsave.ShowDialog()

            If pass = True Then
                Me.Cursor = Cursors.Default
                ExecuteSaveStep1(strconn)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteSaveStep1(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            transaction = connection.BeginTransaction("SampleTransaction")

            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                'save odo
                sql = "Update tbltripsum set odostart='" & txtodoend1.Text & "', odoactual='" & txtodo.Text & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where tripnum='" & lbltripnum1.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                'save remarks
                sql = "Update tbldispatchsum set sneymstp1='" & login.cashier & "', sdeytstp1=GetDate(), remstp1='" & txtrems1.Text & "' where tripnum='" & lbltripnum1.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox(lblplate1.Text & " STEP 1 Saved as draft.", MsgBoxStyle.Information, "")

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub cmbimg1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbimg1.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtrems1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems1.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Public Sub tripstep2()
        Try
            Me.Cursor = Cursors.WaitCursor

            grp2.Enabled = True
            grdstep2.Rows.Clear()

            sql = "SELECT tbltripsum.tripsumid,tbltripsum.tripnum,tbltripsum.platenum,tbltripsum.driver,tbltripsum.helper,tbltripsum.datepick,tbldispatchsum.whsename9,tbldispatchsum.timedep"
            sql = sql & " FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum"
            sql = sql & " where tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' and tbldispatchsum.step2='0' order by datepick"
            grdsql = sql
            whatstep = 2

            bgw = New BackgroundWorker()

            AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
            AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
            AddHandler bgw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not bgw.IsBusy Then
                lblload2.Visible = True
                gstep2.Enabled = False
                bgw.WorkerReportsProgress = True
                bgw.WorkerSupportsCancellation = True
                bgw.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub zero2()
        lblplate2.Text = ""
        lbltype2.Text = ""
        lblmake2.Text = ""
        lbltripnum2.Text = ""
        lblconfirm2.Text = 0
        txtrems2.Text = ""

        txtdestin.Text = "Destination:"
        txtdiswith.Text = 0
        txtdiswout.Text = 0
        txtdshould.Text = 0
        txtdieselbeg1.Text = 0
        txtdiesel.Text = 0
        txtpo.Text = 0
        txtaddpo.Text = 0

        lblpwith.Text = 0
        lblpwout.Text = 0
        lblinch.Text = 0
        lblfull.Text = 0
        btnstartdiesel.Text = "TIME START DIESEL"

        txtinch2.Text = ""
        Panelinch2.Visible = False

        imgpanel2.Visible = False
        imgpanel2.Controls.Clear()
        imgpanel2.Visible = True
    End Sub

    Private Sub grdstep2_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep2.CellClick
        Try
            If Panelinch2.Visible = True Then
                MsgBox("Close the converter first.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            zero2()
            Me.Cursor = Cursors.WaitCursor

            lbltripnum2.Tag = grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(0).Value
            lbltripnum2.Text = grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(1).Value
            lblplate2.Text = grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(2).Value

            SelectStep2(strconn)
            destin()

            btnimgrefresh2.PerformClick()

            computedshould()

            If grdstep2.Rows.Count <> 0 Then
                grp2.Text = lbltripnum2.Text & "     -     " & grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(5).Value
            Else
                grp2.Text = "Photos"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub SelectStep2(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                Dim genid As Integer
                sql = "Select genid,vtype,makename from tblgeneral where platenum='" & lblplate2.Text & "' or vplate='" & lblplate2.Text & "' or csticker='" & lblplate2.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    genid = dr("genid")
                    lbltype2.Text = dr("vtype")
                    lblmake2.Text = dr("makename")
                End If
                dr.Dispose()

                sql = "Select pwith,pwout,twoinch,fulltank from tbldiesel where genid='" & genid & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    lblpwith.Text = dr("pwith")
                    lblpwout.Text = dr("pwout")
                    lblinch.Text = Val(dr("twoinch")).ToString("n2")
                    lblfull.Text = Val(dr("fulltank")).ToString("n2")
                End If
                dr.Dispose()

                btndis.Visible = False
                btndis.Tag = 1
                sql = "Select TOP 1 cstatstp8, dieselend from tbldispatchsum inner join tbltripsum on tbltripsum.tripnum=tbldispatchsum.tripnum"
                sql = sql & " where tbltripsum.status<>'3' and platenum='" & lblplate2.Text & "' and tripsumid<'" & grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(0).Value & "' order by tripsumid DESC"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    txtdieselbeg1.Text = dr("dieselend")
                    If IsDBNull(dr("cstatstp8")) = False Then
                        If dr("cstatstp8") = 0 Then
                            btndis.Visible = True
                            btndis.Tag = 0
                        Else
                            btndis.Visible = False
                        End If
                    Else
                        btndis.Visible = False
                    End If
                Else
                    txtdieselbeg1.Text = 0
                End If
                dr.Dispose()

                sql = "Select diswith,diswout,dieselactual,addpo from tbltripsum where tripnum='" & lbltripnum2.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    txtdiswith.Text = dr("diswith")
                    txtdiswout.Text = dr("diswout")
                    txtdiesel.Text = dr("dieselactual")
                    txtaddpo.Text = dr("addpo")
                End If
                dr.Dispose()

                btnstartdiesel.Text = "TIME START DIESEL"
                sql = "Select step2,startdiesel,remstp2 from tbldispatchsum where tripnum='" & lbltripnum2.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    If dr("step2") = 1 Then
                        lblconfirm2.Text = 1
                    End If

                    If dr("startdiesel").ToString <> "" Then
                        Dim starttime As Date
                        Dim timeCheck As Boolean
                        timeCheck = IsDate(dr("startdiesel").ToString)
                        If timeCheck = True Then
                            'MsgBox(Trim(txttime.Text) & timeCheck)
                            starttime = CDate(dr("startdiesel").ToString)
                            btnstartdiesel.Text = "TIME START DIESEL: " & Format(starttime, "HH:mm")
                            txtrems2.Text = dr("remstp2").ToString
                            startdieselfalse()
                            btnimgadd2.Enabled = True
                            btnconfirm2.Enabled = True
                            btnexempt2.Enabled = True
                        End If
                    Else
                        btnstartdiesel.Enabled = True
                        btnpo.Enabled = False
                        btndis.Enabled = False
                        txtdiswith.Enabled = False
                        txtdiswout.Enabled = False
                        txtdiesel.Enabled = False
                        btninch2.Enabled = False
                        txtrems2.Enabled = False
                        txtrems2.Text = ""
                        tripinfo2.Enabled = False
                        txtaddpo.Enabled = False
                        btnimgadd2.Enabled = False
                        btnconfirm2.Enabled = False
                        btnexempt2.Enabled = False
                    End If
                End If
                dr.Dispose()


                If Val(txtaddpo.Text) > 10 Then
                    btnpo.Image = ImageList1.Images(1)
                    btnpo.Tag = "NOT"
                    'check sa database yung last dapat same diesel if 0 not approved if 1 approved
                    sql = "Select TOP 1 * from tbladdpo where tripnum='" & lbltripnum2.Text & "' order by adpoid DESC"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    If dr.Read Then
                        If dr("status") = 1 Then
                            If Val(txtaddpo.Text) = dr("addpo") Then
                                btnpo.Image = ImageList1.Images(0)
                                btnpo.Tag = "OK"
                            End If
                        End If
                    End If
                    dr.Dispose()
                Else
                    btnpo.Image = ImageList1.Images(0)
                    btnpo.Tag = "OK"
                End If


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Public Sub destin()
        Try
            If lbltripnum2.Text <> "" Then
                Dim origin As String = "", taxi As Integer = 0

                sql = "SELECT origin,taxi from tbltripsum where tripnum='" & lbltripnum2.Text & "'"
                connect()
                Dim cmdxx As SqlCommand = New SqlCommand(sql, conn)
                Dim drxx As SqlDataReader = cmdxx.ExecuteReader
                If drxx.Read Then
                    origin = drxx("origin")
                    taxi = drxx("taxi")
                End If
                drxx.Dispose()
                cmdxx.Dispose()
                conn.Close()

                cmbtrans2.Items.Clear()

                sql = "SELECT transnum from tbltripitems where tripnum='" & lbltripnum2.Text & "' and status<>'0' and status<>'3'"
                conn.Open()
                '/connect()
                cmdxx = New SqlCommand(sql, conn)
                drxx = cmdxx.ExecuteReader
                While drxx.Read
                    cmbtrans2.Items.Add(drxx("transnum"))
                End While
                drxx.Dispose()
                cmdxx.Dispose()
                conn.Close()

                Dim temp As String = "", temptype As String = ""
                For i = 0 To cmbtrans2.Items.Count - 1
                    cmbtrans2.SelectedIndex = i
                    sql = "Select customer,transtype from tblortrans where transnum='" & cmbtrans2.SelectedItem & "'"
                    conn.Open()
                    '/connect()
                    Dim cmdx1x As SqlCommand = New SqlCommand(sql, conn)
                    Dim drx1x As SqlDataReader = cmdx1x.ExecuteReader
                    While drx1x.Read
                        temp = temp & (drx1x("customer")) & " / "

                        If drx1x("transtype").ToString.Contains("PICKUP") Then
                            Dim inSql As String = drx1x("transtype").ToString
                            Dim lastPart As String
                            Dim fromStart As Integer
                            Dim firstpart As String

                            fromStart = inSql.IndexOf("FRM ") + 4

                            firstpart = inSql.Substring(0, fromStart - 4)
                            temptype = Trim(firstpart)

                            lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

                            temptype = lastPart & " "

                        End If
                    End While
                    drx1x.Dispose()
                    cmdx1x.Dispose()
                    conn.Close()
                Next

                If taxi = 1 Then
                    temp = "Taxi"
                    txtdestin.Text = "Destination: " & origin & " - " & temp
                Else
                    If temptype = "" Then
                        txtdestin.Text = "Destination: " & origin & " - " & temp
                    Else
                        txtdestin.Text = "Destination: " & "p/up " & temptype & "/ " & temp
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdstep2_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep2.CellContentClick

    End Sub

    Private Sub grdstep2_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdstep2.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Up Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Down Then
            e.Handled = True
        End If
    End Sub

    Private Sub grdstep2_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grdstep2.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdstep2.Rows(e.RowIndex)
            '<== But this is the name assigned to it in the properties of the control
            'If CDate(Format(dgvRow.Cells(1).Value, "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
            If dgvRow.Cells(5).Value <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
                dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
            End If
        End If
    End Sub

    Private Sub grdstep2_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdstep2.SelectionChanged
        
    End Sub

    Private Sub btnrefstep2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrefstep2.Click
        tripstep2()
    End Sub

    Private Sub btnimgadd2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgadd2.Click
        Try
            If login.neym <> "Inspector" And login.neym <> "Whse Logistics Staff" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum2.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum2.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum2.Text, "step2")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 2 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgadd2.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofdstp2.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox2.Image = Nothing
                    Dim bmp As New Bitmap(ofdstp2.FileName)
                    imgbox2.Image = bmp
                    '/imgbox2.Image = LoadImage(ofdstp2.FileName)
                    cmbimg2.Text = ofdstp2.SafeFileName.ToString.Replace("'", "")
                    cmbimg2.Enabled = True
                    cmbimg2.Focus()

                    lblCompressionLevel.Text = ""

                    ' Display the file's size.
                    Dim file_info As New FileInfo(ofdstp2.FileName)
                    lblOriginalSize.Text = FormatBytes(file_info.Length)
                    If Microsoft.VisualBasic.Right(ofdstp2.FileName.ToString, 3) = "png" Then
                        lblDesiredSize.Text = FormatBytes(file_info.Length * 0.3)
                    Else
                        lblDesiredSize.Text = "1.10 MB" 'FormatBytes(file_info.Length * 0.4)
                    End If
                    lblCompressedSize.Text = ""
                    lblCompressionLevel.Text = ""

                    Me.Cursor = Cursors.Default
                    imgpanel2.Enabled = False
                    '/enabletab4only()
                    imgcanceltrue2()
                    btnimgadd2.Enabled = True
                    btnimgadd2.Text = "Add"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(cmbimg2.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg2.Focus()
                    Exit Sub
                End If

                If cmbimg2.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photoname.", MsgBoxStyle.Exclamation, "")
                    cmbimg2.Text = ""
                    cmbimg2.Focus()
                    Exit Sub
                End If

                Dim origsize As String = lblOriginalSize.Text
                If Val(origsize.Substring(0, origsize.Length - 2)) > 1 And Microsoft.VisualBasic.Right(origsize, 2) = "MB" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Image exceeds the maximum file size 1MB." & vbCrLf & "Compressing image. Please wait.", MsgBoxStyle.Information)

                    Button3.PerformClick()
                    pgbar2.Visible = True

                    If BackgroundWorker1.IsBusy = False Then
                        BackgroundWorker1.RunWorkerAsync()
                    End If

                    'COMPRESS IMAGE THEN REPLACE IMGBOX2.IMAGE NG COMPRESSED NA IMAGE
                    imgbox2.Image = compressimage(imgbox2.Image, Trim(cmbimg2.Text))
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.WaitCursor
                'insert photo in tblimg
                Dim ms As New MemoryStream()
                'search image name if existing
                conn.Open()
                '/connect()
                cmd = New SqlCommand("Select * from tbldispatchstp2 where tripnum='" & lbltripnum2.Text & "' and name='" & Trim(cmbimg2.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg2.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg2.Focus()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar2.Value = 0
                    pgbar2.Visible = False
                    Exit Sub
                Else
                    'save record in database
                    conn.Close()
                    conn.Open()
                    '/connect()
                    cmd = New SqlCommand("Insert into tbldispatchstp2 values(@tripnum,@name,@img,@status,GetDate(),@createdby)", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltripnum2.Text))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(cmbimg2.Text)))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                    imgbox2.Image.Save(ms, Imaging.ImageFormat.Jpeg)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    '/cmd.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                    cmd.ExecuteNonQuery()
                    conn.Close()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar2.Value = 0
                    pgbar2.Visible = False

                    MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    pgbar2.Value = 0
                    imgbox2.Image = Nothing
                    imgbox2.BackColor = Color.Empty
                    imgbox2.Invalidate()
                    ms.Close()
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.Default
                btnimgadd2.Text = "Add Photo"
                imgcancelfalse2()
                imgpanel2.Enabled = True
                '/enableall()
                btnimgrefresh2.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub imgcanceltrue2()
        btnimgadd2.Enabled = False
        btnimgrename2.Enabled = False
        btnimgremove2.Enabled = False
        btnimgcancel2.Enabled = True
        btnimgdl2.Enabled = False
        btnimgfull2.Enabled = True
        btnimgrefresh2.Enabled = False
        'btnexempt2.Enabled = False
    End Sub

    Public Sub imgcancelfalse2()
        cmbimg2.Text = ""
        lblimgdate2.Text = ""
        lblimgname2.Text = ""
        btnimgadd2.Text = "Add Photo"
        btnimgrename2.Text = "Rename"
        btnimgadd2.Enabled = True
        btnimgrename2.Enabled = True
        btnimgremove2.Enabled = True
        btnimgcancel2.Enabled = False
        btnimgdl2.Enabled = True
        btnimgfull2.Enabled = True
        btnimgrefresh2.Enabled = True
        btnexempt2.Enabled = True
        btnconfirm2.Enabled = True
    End Sub

    Private Sub btnimgrefresh2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrefresh2.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meronstp2 = False
            imgpanel2.Visible = False
            imgpanel2.Controls.Clear()
            imgpanel2.Visible = True

            Dim ctr As Integer = 0
            sql = "Select * from tbldispatchstp2 where tripnum='" & lbltripnum2.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                meronstp2 = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                picstp2 = New PictureBox
                picstp2.Image = Image.FromStream(ms)
                ms.Dispose()
                picstp2.SizeMode = PictureBoxSizeMode.Zoom
                picstp2.SetBounds(wid, y, 104, 100)
                'picstp2.BackColor = Color.AliceBlue
                picstp2.Tag = dr("stp2imgid")
                picstp2.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler picstp2.Click, AddressOf convertPic2
                imgpanel2.Controls.Add(picstp2)
                imgpanel2.Controls.Add(lbl)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            imgbox2.Image = Nothing
            cmbimg2.Text = ""
            lblimgid2.Text = ""
            lblimgdate2.Text = ""
            lblimgname2.Text = ""

            Me.Cursor = Cursors.Default

            If meronstp2 = False Then
                btnimgrename2.Enabled = False
                btnimgremove2.Enabled = False
                btnimgcancel2.Enabled = False
                btnimgdl2.Enabled = False
                btnimgfull2.Enabled = False
                'btnexempt2.Enabled = False
                'btnconfirm2.Enabled = False
                If login.whse = "Cebu" Or login.whse = "Davao" Or login.whse = "Bacolod" Or login.whse = "Tacloban" Then
                    btnconfirm2.Enabled = True
                End If
            Else
                imgcancelfalse2()
            End If

            If grdstep2.Rows.Count = 0 Then
                grp2.Enabled = False
            Else
                grp2.Enabled = True
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Sub convertPic2(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            picstp2 = CType(sender, PictureBox)
            imgbox2.Image = picstp2.Image
            lblimgid2.Text = picstp2.Tag

            sql = "Select name,datecreated,createdby from tbldispatchstp2 where stp2imgid='" & lblimgid2.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbimg2.Text = dr("name")
                If IsDBNull(dr("datecreated")) = False Then
                    lblimgdate2.Text = Format(dr("datecreated"), "MM/dd/yyyy h:mm tt")
                Else
                    lblimgdate2.Text = ""
                End If
                lblimgname2.Text = dr("createdby").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgfull2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgfull2.Click
        If lblimgid2.Text <> "" Or imgbox2.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox2.Image
            viewimage.lblimgname.Text = cmbimg2.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub btnconfirm2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnconfirm2.Click
        Try
            If login.neym <> "Inspector" And login.neym <> "Whse Logistics Staff" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum2.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum2.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum2.Text, "step2")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 2 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL2 HAS CONTROLS
            If imgpanel2.Controls.Count = 0 And login.whse <> "Cebu" And login.whse <> "Davao" And login.whse <> "Bacolod" And login.whse <> "Tacloban" Then
                If Val(txtpo.Text) <> 0 Or Val(txtaddpo.Text) <> 0 Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Attach withdrawal slip or diesel PO.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
                Me.Cursor = Cursors.Default
                MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
                'Exit Sub
            End If

            If btndis.Tag = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("Click the warn icon on Previous Diesel Ending to check the error on the previous trip (Step 8).", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Val(txtdiswith.Text) = 0 And Val(txtdiswout.Text) = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("Input total distance with load and total distance without load.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Val(txtaddpo.Text) <> 0 And Trim(txtrems2.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Add reason why you need to add diesel.", MsgBoxStyle.Information, "")
                txtrems2.Focus()
                Exit Sub
            End If

            If Val(Trim(txtdiesel.Text)) < Trim(txtdieselbeg1.Text) And Trim(txtrems2.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Beginning Actual Diesel is less than the Previous Diesel. Add Remarks.", MsgBoxStyle.Exclamation, "")
                txtrems2.Focus()
                Exit Sub
            End If

            If Val(Trim(txtdiesel.Text)) > Trim(txtdieselbeg1.Text) And Trim(txtrems2.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Beginning Actual Diesel is greater than the Previous Diesel. Add Remarks.", MsgBoxStyle.Exclamation, "")
                txtrems2.Focus()
                Exit Sub
            End If

            If Val(txtaddpo.Text) > 10 Then
                btnpo.Image = ImageList1.Images(1)
                btnpo.Tag = "NOT"
                'check sa database yung last dapat same diesel if 0 not approved if 1 approved
                '=sql = "Select TOP 1 * from tbladdpo where tripnum='" & lbltripnum2.Text & "' order by adpoid DESC"
                '=connect()
                '=cmd = New SqlCommand(sql, conn)
                '=dr = cmd.ExecuteReader
                '=If dr.Read Then
                '=If dr("status") = 1 Then
                '=If Val(txtaddpo.Text) <> dr("addpo") Then
                '=Me.Cursor = Cursors.Default
                '=MsgBox("Your additional diesel amount is not the same as the approved additional diesel amount.", MsgBoxStyle.Exclamation, "")
                '=txtaddpo.Focus()
                '=Exit Sub
                '=Else
                '=btnpo.Image = ImageList1.Images(0)
                '=btnpo.Tag = "OK"
                '=End If
                '=Else
                '=Me.Cursor = Cursors.Default
                '=MsgBox("Your additional diesel amount is not yet approved.", MsgBoxStyle.Exclamation, "")
                '=Exit Sub
                '=End If
                '=Else
                '=Me.Cursor = Cursors.Default
                '=MsgBox("Your additional diesel amount is not yet approved.", MsgBoxStyle.Exclamation, "")
                '=Exit Sub
                '=End If
                '=dr.Dispose()
                '=cmd.Dispose()
                '=conn.Close()

            Else
                btnpo.Image = ImageList1.Images(0)
                btnpo.Tag = "OK"
            End If

            If Val(Trim(txtdiesel.Text)) <> 0 Then
                wctab = "tab2"

                sign.Width = 373
                sign.lblplate.Text = lblplate2.Text
                sign.GroupBox1.Text = login.neym & " (" & login.fullneym & ")"
                'sign.GroupBox1.Text = "Driver (" & grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(3).Value & ")"
                'sign.GroupBox4.Text = "Helper (" & grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(4).Value & ")"
                'sign.GroupBox2.Text = login.neym & " (" & login.fullneym & ")"
                sign.lbltrip.Text = lbltripnum2.Text
                sign.lblrems.Text = txtrems2.Text 'para dun ndin isang save nlng

                sign.yescnf = False
                sign.ShowDialog()

                If sign.yescnf = True Then
                    zero2()
                    tripstep2()
                End If

            ElseIf Val(Trim(txtdiesel.Text)) = 0 And lblmake2.Text = "Service" Then
                wctab = "tab2"

                sign.Width = 373
                sign.lblplate.Text = lblplate2.Text
                sign.GroupBox1.Text = login.neym & " (" & login.fullneym & ")"
                'sign.GroupBox1.Text = "Driver (" & grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(3).Value & ")"
                'sign.GroupBox4.Text = "Helper (" & grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(4).Value & ")"
                'sign.GroupBox2.Text = login.neym & " (" & login.fullneym & ")"
                sign.lbltrip.Text = lbltripnum2.Text
                sign.lblrems.Text = txtrems2.Text 'para dun ndin isang save nlng

                sign.yescnf = False
                sign.ShowDialog()

                If sign.yescnf = True Then
                    zero2()
                    tripstep2()
                End If
            ElseIf Val(Trim(txtdiesel.Text)) = 0 And txtdiesel.Enabled = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Input Actual Diesel Beginning.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgrename2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrename2.Click
        Try
            If login.neym <> "Inspector" And login.neym <> "Whse Logistics Staff" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum2.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum2.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum2.Text, "step2")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 2 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgrename2.Text = "Rename" Then
                If Trim(cmbimg2.Text) <> "" And imgbox2.Image IsNot Nothing Then
                    Dim tempname As String = Trim(cmbimg2.Text)
                    If tempname.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Cannot rename photo.", MsgBoxStyle.Exclamation, "")
                        cmbimg2.Focus()
                        Exit Sub
                    End If
                    cmbimg2.Enabled = True
                    cmbimg2.Focus()
                ElseIf Trim(cmbimg2.Text) = "" And imgbox2.Image IsNot Nothing Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg2.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    cmbimg2.Focus()
                    Exit Sub
                End If

                imgpanel2.Enabled = False
                imgcanceltrue2()
                btnimgrename2.Enabled = True
                btnimgrename2.Text = "Save"
            Else
                'search image name if existing
                connect()
                cmd = New SqlCommand("Select * from tbldispatchstp2 where tripnum='" & lbltripnum2.Text & "' and name='" & Trim(cmbimg2.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg2.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg2.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default

                    If cmbimg2.Text.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Invalid photo name.", MsgBoxStyle.Exclamation, "")
                        cmbimg2.Text = ""
                        cmbimg2.Focus()
                        Exit Sub
                    End If

                    'irename.. update yung name lng where imgid = lblimgid.text
                    sql = "Update tbldispatchstp2 set name='" & Trim(cmbimg2.Text) & "' where stp2imgid='" & lblimgid2.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                    btnimgrename2.Text = "Rename"
                    imgcancelfalse2()
                    imgpanel2.Enabled = True
                    btnimgrefresh2.PerformClick()
                    Me.Cursor = Cursors.Default
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgremove2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgremove2.Click
        Try
            If login.neym <> "Inspector" And login.neym <> "Whse Logistics Staff" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum2.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum2.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum2.Text, "step2")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 2 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(cmbimg2.Text) <> "" And imgbox2.Image IsNot Nothing Then
                Me.Cursor = Cursors.Default

                If cmbimg2.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot delete signature", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2)
                If a = vbYes Then
                    'delete image where imgid=lblimgid.text
                    sql = "Delete from tbldispatchstp2 where stp2imgid='" & lblimgid2.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully remove.", MsgBoxStyle.Information, "")

                    imgcancelfalse2()
                    imgpanel2.Enabled = True
                    btnimgrefresh2.PerformClick()
                End If
                
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                cmbimg2.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgcancel2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel2.Click
        imgpanel2.Enabled = True
        imgbox2.Image = Nothing
        cmbimg2.Text = ""
        lblimgid2.Text = ""
        imgcancelfalse2()

        If meronstp2 = False Then
            btnimgrename2.Enabled = False
            btnimgremove2.Enabled = False
            btnimgcancel2.Enabled = False
            btnimgdl2.Enabled = False
            btnimgfull2.Enabled = False
        Else
            imgcancelfalse2()
        End If
    End Sub

    Private Sub btnexempt2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexempt2.Click
        Try
            If login.neym <> "Inspector" And login.neym <> "Whse Logistics Staff" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum2.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum2.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum2.Text, "step2")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 2 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL2 HAS CONTROLS
            If imgpanel2.Controls.Count = 0 Then
                'MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
                'Exit Sub
            End If

            pass = False
            confirmsave.GroupBox1.Text = login.neym
            confirmsave.ShowDialog()

            If pass = True Then
                Me.Cursor = Cursors.Default
                ExecuteSaveStep2(strconn)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteSaveStep2(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            transaction = connection.BeginTransaction("SampleTransaction")

            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                'save distance and odo and diesel
                sql = "Update tbltripsum set diswith='" & txtdiswith.Text & "', diswout='" & txtdiswout.Text & "', dshould='" & txtdshould.Text & "', dieselbeg='" & txtdieselbeg1.Text & "', dieselactual='" & txtdiesel.Text & "', podiesel='" & txtpo.Text & "', addpo='" & txtaddpo.Text & "', pwith='" & lblpwith.Text & "', pwout='" & lblpwout.Text & "', twoinch='" & lblinch.Text & "', fulltank='" & lblfull.Text & "', datemodified=GetDate(),modifiedby='" & login.cashier & "' where tripnum='" & lbltripnum2.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                'save remarks
                sql = "Update tbldispatchsum set sneymstp2='" & login.cashier & "', sdeytstp2=GetDate(), remstp2='" & txtrems2.Text & "' where tripnum='" & lbltripnum2.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox(lblplate2.Text & " STEP 2 Saved as draft.", MsgBoxStyle.Information, "")

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub cmbimg2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbimg2.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtrems2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems2.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Public Sub tripstep3()
        Try
            Me.Cursor = Cursors.WaitCursor

            grp3.Enabled = True
            grdstep3.Rows.Clear()

            'sql = "Select * from tbltripsum where tbltripsum.status='1'"
            sql = "SELECT tbltripsum.tripsumid,tbltripsum.tripnum,tbltripsum.platenum,tbltripsum.driver,tbltripsum.helper,tbltripsum.datepick,tbldispatchsum.whsename9,tbldispatchsum.timedep"
            sql = sql & " FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum"
            sql = sql & " where tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' and tbldispatchsum.step1='1' and tbldispatchsum.step3='0' order by datepick"
            grdsql = sql
            whatstep = 3

            bgw = New BackgroundWorker()

            AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
            AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
            AddHandler bgw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not bgw.IsBusy Then
                lblload3.Visible = True
                gstep3.Enabled = False
                bgw.WorkerReportsProgress = True
                bgw.WorkerSupportsCancellation = True
                bgw.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub zero3()
        lblplate3.Text = ""
        lbltype3.Text = ""
        lbltripnum3.Text = ""
        lblconfirm3.Text = 0
        txtrems3.Text = ""

        txtlabor.Text = ""
        grdtrans3.Rows.Clear()
        btnstartload.Text = "TIME START LOADING"

        imgpanel3.Visible = False
        imgpanel3.Controls.Clear()
        imgpanel3.Visible = True
    End Sub

    Private Sub grdstep3_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grdstep3.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdstep3.Rows(e.RowIndex)
            '<== But this is the name assigned to it in the properties of the control
            'If CDate(Format(dgvRow.Cells(1).Value, "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
            If dgvRow.Cells(5).Value <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
                dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
            End If
        End If
    End Sub

    Private Sub grdstep3_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep3.CellClick
        Try
            zero3()
            Me.Cursor = Cursors.WaitCursor

            lbltripnum3.Tag = grdstep3.Rows(grdstep3.CurrentRow.Index).Cells(0).Value
            lbltripnum3.Text = grdstep3.Rows(grdstep3.CurrentRow.Index).Cells(1).Value
            lblplate3.Text = grdstep3.Rows(grdstep3.CurrentRow.Index).Cells(2).Value

            SelectStep3(strconn)
            '/items()

            If imgpanel3.Controls.Count = 0 Then
                btnconfirm3.Enabled = False
            End If

            btnimgrefresh3.PerformClick()

            If grdstep3.Rows.Count <> 0 Then
                grp3.Text = lbltripnum3.Text & "     -     " & grdstep3.Rows(grdstep3.CurrentRow.Index).Cells(5).Value
            Else
                grp3.Text = "Photos"
            End If

            If grdtrans3.Rows.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("You cancelled all order transactions under trip# " & lbltripnum3.Text & ". Add transaction to existing trip first.", MsgBoxStyle.Critical)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub SelectStep3(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                sql = "Select vtype from tblgeneral where platenum='" & lblplate3.Text & "' or vplate='" & lblplate3.Text & "' or csticker='" & lblplate3.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    lbltype3.Text = dr("vtype")
                End If
                dr.Dispose()

                grdtrans3.Rows.Clear()
                sql = "SELECT tblortrans.* FROM tblortrans RIGHT OUTER JOIN tbltripitems ON tblortrans.transnum=tbltripitems.transnum"
                sql = sql & " where tbltripitems.tripnum='" & lbltripnum3.Text & "' and tbltripitems.status<>'0' and tbltripitems.status<>'3'"
                command.CommandText = sql
                dr = command.ExecuteReader
                While dr.Read
                    grdtrans3.Rows.Add(dr("transid"), dr("transnum"), dr("refnum"), dr("customer"), dr("arnum"), dr("rdrnum"), dr("drnum"), dr("dnnum"), dr("itrnum"), dr("itnum"), dr("grponum"), dr("transtype"), dr("notes"))
                End While
                dr.Dispose()

                sql = "Select loadscale from tbltripsum where tripnum='" & lbltripnum3.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    txtlabor.Text = dr("loadscale")
                End If
                dr.Dispose()

                btnstartload.Text = "TIME START LOADING"
                sql = "Select step3,startload,remstp3 from tbldispatchsum where tripnum='" & lbltripnum3.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    If dr("step3") = 1 Then
                        lblconfirm3.Text = 1
                    End If

                    If dr("startload").ToString <> "" Then
                        Dim starttime As Date
                        Dim timeCheck As Boolean
                        timeCheck = IsDate(dr("startload").ToString)
                        If timeCheck = True Then
                            'MsgBox(Trim(txttime.Text) & timeCheck)
                            starttime = CDate(dr("startload").ToString)
                            btnstartload.Text = "TIME START LOADING: " & Format(starttime, "HH:mm")
                            txtrems3.Text = dr("remstp3").ToString
                            startloadfalse()
                            btnexempt3.Enabled = True
                        End If
                    Else
                        btnstartload.Enabled = True
                        btnimgadd3.Enabled = False
                        txtrems3.Enabled = False
                        txtrems3.Text = ""
                        tripinfo3.Enabled = False
                        txtlabor.Enabled = False
                        btnexempt3.Enabled = False
                    End If
                End If
                dr.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub startloadfalse()
        btnstartload.Enabled = False
        btnimgadd3.Enabled = True
        txtrems3.Enabled = True
        tripinfo3.Enabled = True
        txtlabor.Enabled = True
    End Sub

    Private Sub grdstep3_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep3.CellContentClick

    End Sub

    Private Sub grdstep3_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdstep3.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Up Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Down Then
            e.Handled = True
        End If
    End Sub

    Private Sub grdstep3_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdstep3.SelectionChanged
        
    End Sub

    Private Sub grdtrans3_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans3.CellContentClick
        Try
            'link
            If e.ColumnIndex = 1 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdtrans3.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrans3.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdtrans3.RowCount <> 0 Then
                    If grdtrans3.Item(1, grdtrans3.CurrentRow.Index).Value IsNot Nothing Then
                        viewtrans.Text = "View Transaction"
                        viewtrans.grouptrans.Visible = False
                        viewtrans.lbltripnum.Text = lbltripnum3.Text
                        viewtrans.txttrans.Text = grdtrans3.Item(1, grdtrans3.CurrentRow.Index).Value
                        viewtrans.sing = True
                        viewtrans.ShowDialog()
                    End If
                End If

            ElseIf e.ColumnIndex = 2 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdtrans3.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrans3.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdtrans3.RowCount <> 0 Then
                    If grdtrans3.Item(2, grdtrans3.CurrentRow.Index).Value IsNot Nothing And grdtrans3.Item(2, grdtrans3.CurrentRow.Index).Value <> "0000" Then
                        transoredit.lbltrans.Text = grdtrans3.Item(1, grdtrans3.CurrentRow.Index).Value
                        transoredit.lblcus.Text = grdtrans3.Item(3, grdtrans3.CurrentRow.Index).Value
                        transoredit.ShowDialog()
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrans3_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdtrans3.CellMouseClick
        Try
            If e.Button = Windows.Forms.MouseButtons.Right And e.RowIndex > -1 Then
                If e.ColumnIndex = 2 Then
                    If grdtrans3.Rows(e.RowIndex).DefaultCellStyle.BackColor <> Color.DeepSkyBlue Then
                        grdtrans3.ClearSelection()
                        grdtrans3.Rows(e.RowIndex).Cells(2).Selected = True

                        selectedrow = e.RowIndex

                        Dim refnum As String = grdtrans3.Rows(e.RowIndex).Cells(2).Value

                        If refnum = "0000" Then
                            Exit Sub
                        End If

                        If btnstartload.Text = "TIME START LOADING" Then
                            MsgBox("Time start loading first.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If

                        Me.ContextMenuStrip1.Show(Cursor.Position)
                        editstep = 3
                        EditSOToolStripMenuItem.Visible = False
                        EditPOToolStripMenuItem.Visible = False
                        EditITRToolStripMenuItem.Visible = False
                        EditSWSToolStripMenuItem.Visible = False
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnrefstep3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrefstep3.Click
        tripstep3()
    End Sub

    Private Sub btnimgadd3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgadd3.Click
        Try
            If login.neym <> "Checker" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum3.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum3.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum3.Text, "step3")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 3 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgadd3.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofdstp3.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox3.Image = Nothing
                    Dim bmp As New Bitmap(ofdstp3.FileName)
                    imgbox3.Image = bmp
                    '/imgbox3.Image = LoadImage(ofdstp3.FileName)
                    cmbimg3.Text = ofdstp3.SafeFileName.ToString.Replace("'", "")
                    cmbimg3.Enabled = True
                    cmbimg3.Focus()

                    lblCompressionLevel.Text = ""

                    ' Display the file's size.
                    Dim file_info As New FileInfo(ofdstp3.FileName)
                    lblOriginalSize.Text = FormatBytes(file_info.Length)
                    If Microsoft.VisualBasic.Right(ofdstp3.FileName.ToString, 3) = "png" Then
                        lblDesiredSize.Text = FormatBytes(file_info.Length * 0.3)
                    Else
                        lblDesiredSize.Text = "1.10 MB" 'FormatBytes(file_info.Length * 0.4)
                    End If
                    lblCompressedSize.Text = ""
                    lblCompressionLevel.Text = ""

                    Me.Cursor = Cursors.Default
                    imgpanel3.Enabled = False
                    '/enabletab4only()
                    imgcanceltrue3()
                    btnimgadd3.Enabled = True
                    btnimgadd3.Text = "Add"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(cmbimg3.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg3.Focus()
                    Exit Sub
                End If

                If cmbimg3.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photoname.", MsgBoxStyle.Exclamation, "")
                    cmbimg3.Text = ""
                    cmbimg3.Focus()
                    Exit Sub
                End If

                Dim origsize As String = lblOriginalSize.Text
                If Val(origsize.Substring(0, origsize.Length - 2)) > 1 And Microsoft.VisualBasic.Right(origsize, 2) = "MB" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Image exceeds the maximum file size 1MB." & vbCrLf & "Compressing image. Please wait.", MsgBoxStyle.Information)

                    Button3.PerformClick()
                    pgbar3.Visible = True

                    If BackgroundWorker1.IsBusy = False Then
                        BackgroundWorker1.RunWorkerAsync()
                    End If

                    'COMPRESS IMAGE THEN REPLACE IMGBOX3.IMAGE NG COMPRESSED NA IMAGE
                    imgbox3.Image = compressimage(imgbox3.Image, Trim(cmbimg3.Text))
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.WaitCursor
                'insert photo in tblimg
                Dim ms As New MemoryStream()
                'search image name if existing
                conn.Open()
                '/connect()
                cmd = New SqlCommand("Select * from tbldispatchstp3 where tripnum='" & lbltripnum3.Text & "' and name='" & Trim(cmbimg3.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg3.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg3.Focus()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar3.Value = 0
                    pgbar3.Visible = False
                    Exit Sub
                Else
                    'save record in database
                    conn.Close()
                    conn.Open()
                    '/connect()
                    cmd = New SqlCommand("Insert into tbldispatchstp3 values(@tripnum,@name,@img,@status,GetDate(),@createdby)", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltripnum3.Text))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(cmbimg3.Text)))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                    imgbox3.Image.Save(ms, Imaging.ImageFormat.Jpeg)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    '/cmd.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                    cmd.ExecuteNonQuery()
                    conn.Close()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar3.Value = 0
                    pgbar3.Visible = False

                    MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    pgbar3.Value = 0
                    imgbox3.Image = Nothing
                    imgbox3.BackColor = Color.Empty
                    imgbox3.Invalidate()
                    ms.Close()
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.Default
                btnimgadd3.Text = "Add Photo"
                imgcancelfalse3()
                imgpanel3.Enabled = True
                '/enableall()
                btnimgrefresh3.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub imgcanceltrue3()
        btnimgadd3.Enabled = False
        btnimgrename3.Enabled = False
        btnimgremove3.Enabled = False
        btnimgcancel3.Enabled = True
        btnimgdl3.Enabled = False
        btnimgfull3.Enabled = True
        btnimgrefresh3.Enabled = False
    End Sub

    Public Sub imgcancelfalse3()
        cmbimg3.Text = ""
        lblimgdate3.Text = ""
        lblimgname3.Text = ""
        btnimgadd3.Text = "Add Photo"
        btnimgrename3.Text = "Rename"
        btnimgadd3.Enabled = True
        btnimgrename3.Enabled = True
        btnimgremove3.Enabled = True
        btnimgcancel3.Enabled = False
        btnimgdl3.Enabled = True
        btnimgfull3.Enabled = True
        btnimgrefresh3.Enabled = True
        btnnot3.Enabled = True
        btnexempt3.Enabled = True
        btnconfirm3.Enabled = True
    End Sub

    Private Sub btnimgrefresh3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrefresh3.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meronstp3 = False
            imgpanel3.Visible = False
            imgpanel3.Controls.Clear()
            imgpanel3.Visible = True

            Dim ctr As Integer = 0
            sql = "Select * from tbldispatchstp3 where tripnum='" & lbltripnum3.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                meronstp3 = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                picstp3 = New PictureBox
                picstp3.Image = Image.FromStream(ms)
                ms.Dispose()
                picstp3.SizeMode = PictureBoxSizeMode.Zoom
                picstp3.SetBounds(wid, y, 104, 100)
                'picstp3.BackColor = Color.AliceBlue
                picstp3.Tag = dr("stp3imgid")
                picstp3.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler picstp3.Click, AddressOf convertPic3
                imgpanel3.Controls.Add(picstp3)
                imgpanel3.Controls.Add(lbl)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            imgbox3.Image = Nothing
            cmbimg3.Text = ""
            lblimgid3.Text = ""
            lblimgdate3.Text = ""
            lblimgname3.Text = ""

            Me.Cursor = Cursors.Default

            If meronstp3 = False Then
                btnimgrename3.Enabled = False
                btnimgremove3.Enabled = False
                btnimgcancel3.Enabled = False
                btnimgdl3.Enabled = False
                btnimgfull3.Enabled = False
                btnnot3.Enabled = True
                btnconfirm3.Enabled = False
            Else
                imgcancelfalse3()
            End If

            If grdstep3.Rows.Count = 0 Then
                grp3.Enabled = False
            Else
                grp3.Enabled = True
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Sub convertPic3(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            picstp3 = CType(sender, PictureBox)
            imgbox3.Image = picstp3.Image
            lblimgid3.Text = picstp3.Tag

            sql = "Select name,datecreated,createdby from tbldispatchstp3 where stp3imgid='" & lblimgid3.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbimg3.Text = dr("name")
                If IsDBNull(dr("datecreated")) = False Then
                    lblimgdate3.Text = Format(dr("datecreated"), "MM/dd/yyyy h:mm tt")
                Else
                    lblimgdate3.Text = ""
                End If
                lblimgname3.Text = dr("createdby").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgfull3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgfull3.Click
        If lblimgid3.Text <> "" Or imgbox3.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox3.Image
            viewimage.lblimgname.Text = cmbimg3.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnconfirm3.Click
        Try
            If login.neym <> "Checker" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum3.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum3.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum3.Text, "step3")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 3 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL3 HAS CONTROLS
            If imgpanel3.Controls.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If btnstartload.Text = "TIME START LOADING" Then
                Me.Cursor = Cursors.Default
                MsgBox("No Time Start Loading.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Val(Trim(txtlabor.Text)) = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("Input no. of labor.", MsgBoxStyle.Information, "")
                txtlabor.Text = ""
                txtlabor.Focus()
                Exit Sub
            End If

            If grdtrans3.Rows.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("You cancelled all order transactions under trip# " & lbltripnum3.Text & ". Add transaction to existing trip first.", MsgBoxStyle.Critical)
                Exit Sub
            End If

            pass = False
            confirmchecker.btncnf = False
            confirmchecker.tripnumber = lbltripnum3.Text
            confirmchecker.ShowDialog()
            If pass = False Then
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

            wctab = "tab3"

            sign.Width = 733
            sign.lblplate.Text = lblplate3.Text
            sign.GroupBox1.Text = "Driver (" & grdstep3.Rows(grdstep3.CurrentRow.Index).Cells(3).Value & ")"
            sign.GroupBox4.Text = "Helper (" & grdstep3.Rows(grdstep3.CurrentRow.Index).Cells(4).Value & ")"
            sign.GroupBox2.Text = "Checker" & " (" & confirmchecker.checkerfull & ")"
            sign.lbltrip.Text = lbltripnum3.Text
            sign.lblrems.Text = txtrems3.Text 'para dun ndin isang save nlng

            sign.yescnf = False
            sign.ShowDialog()

            If sign.yescnf = True Then
                zero3()
                grdtrans5.Rows.Clear()
                tripstep3()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgrename3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrename3.Click
        Try
            If login.neym <> "Checker" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum3.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum3.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum3.Text, "step3")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 3 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgrename3.Text = "Rename" Then
                If Trim(cmbimg3.Text) <> "" And imgbox3.Image IsNot Nothing Then
                    Dim tempname As String = Trim(cmbimg3.Text)
                    If tempname.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Cannot rename photo.", MsgBoxStyle.Exclamation, "")
                        cmbimg3.Focus()
                        Exit Sub
                    End If
                    cmbimg3.Enabled = True
                    cmbimg3.Focus()
                ElseIf Trim(cmbimg3.Text) = "" And imgbox3.Image IsNot Nothing Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg3.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    cmbimg3.Focus()
                    Exit Sub
                End If

                imgpanel3.Enabled = False
                imgcanceltrue3()
                btnimgrename3.Enabled = True
                btnimgrename3.Text = "Save"
            Else
                'search image name if existing
                connect()
                cmd = New SqlCommand("Select * from tbldispatchstp3 where tripnum='" & lbltripnum3.Text & "' and name='" & Trim(cmbimg3.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg3.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg3.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default

                    If cmbimg3.Text.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Invalid photo name.", MsgBoxStyle.Exclamation, "")
                        cmbimg3.Text = ""
                        cmbimg3.Focus()
                        Exit Sub
                    End If

                    'irename.. update yung name lng where imgid = lblimgid.text
                    sql = "Update tbldispatchstp3 set name='" & Trim(cmbimg3.Text) & "' where stp3imgid='" & lblimgid3.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                    btnimgrename3.Text = "Rename"
                    imgcancelfalse3()
                    imgpanel3.Enabled = True
                    btnimgrefresh3.PerformClick()
                    Me.Cursor = Cursors.Default
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgremove3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgremove3.Click
        Try
            If login.neym <> "Checker" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum3.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum3.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum3.Text, "step3")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 3 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(cmbimg3.Text) <> "" And imgbox3.Image IsNot Nothing Then
                Me.Cursor = Cursors.Default

                If cmbimg3.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot delete signature", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2)
                If a = vbYes Then
                    'delete image where imgid=lblimgid.text
                    sql = "Delete from tbldispatchstp3 where stp3imgid='" & lblimgid3.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully remove.", MsgBoxStyle.Information, "")

                    imgcancelfalse3()
                    imgpanel3.Enabled = True
                    btnimgrefresh3.PerformClick()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                cmbimg3.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgcancel3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel3.Click
        Try
            imgpanel3.Enabled = True
            imgbox3.Image = Nothing
            cmbimg3.Text = ""
            lblimgid3.Text = ""
            imgcancelfalse3()

            If meronstp3 = False Then
                btnimgrename3.Enabled = False
                btnimgremove3.Enabled = False
                btnimgcancel3.Enabled = False
                btnimgdl3.Enabled = False
                btnimgfull3.Enabled = False
            Else
                imgcancelfalse3()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnnot3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnot3.Click
        If login.neym <> "Checker" Then
            Me.Cursor = Cursors.Default
            MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
            Exit Sub
        End If

        'CHECK IF IMGPANEL3 HAS CONTROLS
        If imgpanel3.Controls.Count <> 0 Then
            'MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
            'Exit Sub
        End If

        pass = False
        confirmchecker.ShowDialog()
        If pass = False Then
            Me.Cursor = Cursors.Default
            Exit Sub
        Else
            Me.Cursor = Cursors.Default
            'save as confirm but does not requires sign of driver dahil not applicable sya
            'step3
            sql = "Update tbldispatchsum set step3='1', namestp3='" & confirmchecker.checkerneym & "', datestp3=GetDate(), mneymstp3='" & confirmchecker.checkerneym & "', mdeytstp3=GetDate(), remstp3='" & "NOT APPLICABLE - " & txtrems3.Text & "' where tripnum='" & lbltripnum3.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
            MsgBox("PROCCED TO NEXT STEP.", MsgBoxStyle.Information, "")

            zero3()
            tripstep3()

            Exit Sub
        End If

        wctab = "tab3"

        sign.Width = 733
        sign.lblplate.Text = lblplate3.Text
        sign.GroupBox1.Text = "Driver (" & grdstep3.Rows(grdstep3.CurrentRow.Index).Cells(3).Value & ")"
        sign.GroupBox4.Text = "Helper (" & grdstep3.Rows(grdstep3.CurrentRow.Index).Cells(4).Value & ")"
        sign.GroupBox2.Text = "Checker (" & confirmchecker.checkerfull & ")"
        sign.lbltrip.Text = lbltripnum3.Text
        sign.lblrems.Text = txtrems3.Text 'para dun ndin isang save nlng

        sign.yescnf = False
        sign.ShowDialog()

        If sign.yescnf = True Then
            If login.whse = "Agi" Then
                'save truckscale
                sql = "Update tbltripsum set loadscale='" & txtlabor.Text & "',datemodified=GetDate(),modifiedby='" & confirmchecker.checkerneym & "' where tripnum='" & lbltripnum3.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()
            End If

            zero3()
            tripstep3()
        End If
    End Sub

    Private Sub btnexempt3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexempt3.Click
        Try
            If login.neym <> "Checker" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum3.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum3.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum3.Text, "step3")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 3 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL3 HAS CONTROLS
            If imgpanel3.Controls.Count = 0 Then
                'MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
            End If

            If Trim(txtlabor.Text) = "" Then
                'MsgBox("Input truck scale.", MsgBoxStyle.Information, "")
            End If

            pass = False
            confirmchecker.ShowDialog()
            If pass = False Then
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

            ExecuteSaveStep3(strconn)

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteSaveStep3(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                'save truckscale
                sql = "Update tbltripsum set loadscale='" & txtlabor.Text & "',datemodified=GetDate(),modifiedby='" & confirmchecker.checkerneym & "' where tripnum='" & lbltripnum3.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                'save remarks
                sql = "Update tbldispatchsum set sneymstp3='" & login.cashier & "', sdeytstp3=GetDate(), remstp3='" & txtrems3.Text & "' where tripnum='" & lbltripnum3.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox(lblplate3.Text & " STEP 3 Saved as draft.", MsgBoxStyle.Information, "")

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                '/Console.WriteLine("Commit Exception Type: {0}", ex.GetType())
                '/Console.WriteLine("  Message: {0}", ex.Message)
                '/Dim typeName = ex.GetType().Name
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    ' This catch block will handle any errors that may have occurred 
                    ' on the server that would cause the rollback to fail, such as 
                    ' a closed connection.
                    Me.Cursor = Cursors.Default
                    '/Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType())
                    '/Console.WriteLine("  Message: {0}", ex2.Message)
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub cmbimg3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbimg3.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtrems3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems3.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Public Sub tripstep4()
        Try
            Me.Cursor = Cursors.WaitCursor

            grp4.Enabled = True
            grdstep4.Rows.Clear()

            'sql = "Select * from tbltripsum where tbltripsum.status='1'"
            sql = "SELECT tbltripsum.tripsumid,tbltripsum.tripnum,tbltripsum.platenum,tbltripsum.driver,tbltripsum.helper,tbltripsum.datepick,tbldispatchsum.whsename9,tbldispatchsum.timedep"
            sql = sql & " FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum"
            sql = sql & " where tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' and tbldispatchsum.step1='1' and tbldispatchsum.step4='0' order by datepick"
            grdsql = sql
            whatstep = 4

            bgw = New BackgroundWorker()

            AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
            AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
            AddHandler bgw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not bgw.IsBusy Then
                lblload4.Visible = True
                gstep4.Enabled = False
                bgw.WorkerReportsProgress = True
                bgw.WorkerSupportsCancellation = True
                bgw.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub zero4()
        lblplate4.Text = ""
        lbltype4.Text = ""
        lbltripnum4.Text = ""
        lblconfirm4.Text = 0
        txtrems4.Text = ""

        grdtrans4.Rows.Clear()
        btnstartdoc.Text = "TIME START RELEASE DOCUMENTS"

        imgpanel4.Visible = False
        imgpanel4.Controls.Clear()
        imgpanel4.Visible = True
    End Sub

    Private Sub grdstep4_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grdstep4.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdstep4.Rows(e.RowIndex)
            '<== But this is the name assigned to it in the properties of the control
            'If CDate(Format(dgvRow.Cells(1).Value, "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
            If dgvRow.Cells(5).Value <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
                dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
            End If
        End If
    End Sub

    Private Sub grdstep4_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep4.CellClick
        Try
            zero4()
            Me.Cursor = Cursors.WaitCursor

            lbltripnum4.Tag = grdstep4.Rows(grdstep4.CurrentRow.Index).Cells(0).Value
            lbltripnum4.Text = grdstep4.Rows(grdstep4.CurrentRow.Index).Cells(1).Value
            lblplate4.Text = grdstep4.Rows(grdstep4.CurrentRow.Index).Cells(2).Value

            SelectStep4(strconn)

            If imgpanel4.Controls.Count = 0 Then
                btnconfirm4.Enabled = False
            End If

            btnimgrefresh4.PerformClick()

            If grdstep4.Rows.Count <> 0 Then
                grp4.Text = lbltripnum4.Text & "     -     " & grdstep4.Rows(grdstep4.CurrentRow.Index).Cells(5).Value
            Else
                grp4.Text = "Photos"
            End If

            If grdtrans4.Rows.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("You cancelled all order transactions under trip# " & lbltripnum4.Text & ". Add transaction to existing trip first.", MsgBoxStyle.Critical)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub SelectStep4(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Select vtype from tblgeneral where platenum='" & lblplate4.Text & "' or vplate='" & lblplate4.Text & "' or csticker='" & lblplate4.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    lbltype4.Text = dr("vtype")
                End If
                dr.Dispose()

                grdtrans4.Rows.Clear()
                sql = "SELECT tblortrans.* FROM tblortrans inner join tbltripitems on tblortrans.transnum=tbltripitems.transnum"
                sql = sql & " where tbltripitems.tripnum='" & lbltripnum4.Text & "' and tbltripitems.status<>'0' and tbltripitems.status<>'3'"
                command.CommandText = sql
                dr = command.ExecuteReader
                While dr.Read
                    grdtrans4.Rows.Add(dr("transid"), dr("transnum"), dr("refnum"), dr("customer"), False, False, False, dr("arnum"), dr("rdrnum"), dr("drnum"), dr("dnnum"), dr("itrnum"), dr("transtype"), dr("notes"), dr("manager").ToString)
                End While
                dr.Dispose()

                btnstartdoc.Text = "TIME START RELEASE DOCUMENTS"
                sql = "Select step4,startdoc,remstp4 from tbldispatchsum where tripnum='" & lbltripnum4.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    If dr("step4") = 1 Then
                        lblconfirm4.Text = 1
                    End If

                    If dr("startdoc").ToString <> "" Then
                        Dim starttime As Date
                        Dim timeCheck As Boolean
                        timeCheck = IsDate(dr("startdoc").ToString)
                        If timeCheck = True Then
                            'MsgBox(Trim(txttime.Text) & timeCheck)
                            starttime = CDate(dr("startdoc").ToString)
                            btnstartdoc.Text = "TIME START RELEASE DOCUMENTS: " & Format(starttime, "HH:mm")
                            txtrems4.Text = dr("remstp4").ToString
                            startdocfalse()
                            btnexempt4.Enabled = True
                        End If
                    Else
                        btnstartdoc.Enabled = True
                        grdtrans4.ReadOnly = True
                        txtrems4.Enabled = False
                        txtrems4.Text = ""
                        tripinfo4.Enabled = False
                        btnimgadd4.Enabled = False
                        btnexempt4.Enabled = False
                    End If
                End If
                dr.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub startdocfalse()
        btnstartdoc.Enabled = False
        grdtrans4.ReadOnly = False
        grdtrans4.Columns(1).ReadOnly = True
        grdtrans4.Columns(2).ReadOnly = True
        grdtrans4.Columns(3).ReadOnly = True
        grdtrans4.Columns(12).ReadOnly = True
        txtrems4.Enabled = True
        tripinfo4.Enabled = True
        btnimgadd4.Enabled = True
    End Sub

    Private Sub grdstep4_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep4.CellContentClick

    End Sub

    Private Sub grdstep4_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdstep4.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Up Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Down Then
            e.Handled = True
        End If
    End Sub

    Private Sub grdstep4_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdstep4.SelectionChanged
        
    End Sub

    Private Sub btnrefstep4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrefstep4.Click
        tripstep4()
    End Sub

    Private Sub btnimgadd4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgadd4.Click
        Try
            If login.neym <> "Encoder" And login.neym <> "Manager" Then
                If login.neym = "Checker" And login.whse = "C3 Manila" Then
                ElseIf login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum4.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum4.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum4.Text, "step4")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 4 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgadd4.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofdstp4.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox4.Image = Nothing
                    Dim bmp As New Bitmap(ofdstp4.FileName)
                    imgbox4.Image = bmp
                    '/imgbox4.Image = LoadImage(ofdstp4.FileName)
                    cmbimg4.Text = ofdstp4.SafeFileName.ToString.Replace("'", "")
                    cmbimg4.Enabled = True
                    cmbimg4.Focus()

                    lblCompressionLevel.Text = ""

                    ' Display the file's size.
                    Dim file_info As New FileInfo(ofdstp4.FileName)
                    lblOriginalSize.Text = FormatBytes(file_info.Length)
                    If Microsoft.VisualBasic.Right(ofdstp4.FileName.ToString, 3) = "png" Then
                        lblDesiredSize.Text = FormatBytes(file_info.Length * 0.3)
                    Else
                        lblDesiredSize.Text = "1.10 MB" 'FormatBytes(file_info.Length * 0.4)
                    End If
                    lblCompressedSize.Text = ""
                    lblCompressionLevel.Text = ""

                    Me.Cursor = Cursors.Default
                    imgpanel4.Enabled = False
                    '/enabletab4only()
                    imgcanceltrue4()
                    btnimgadd4.Enabled = True
                    btnimgadd4.Text = "Add"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(cmbimg4.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg4.Focus()
                    Exit Sub
                End If

                If cmbimg4.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photoname.", MsgBoxStyle.Exclamation, "")
                    cmbimg4.Text = ""
                    cmbimg4.Focus()
                    Exit Sub
                End If

                Dim origsize As String = lblOriginalSize.Text
                If Val(origsize.Substring(0, origsize.Length - 2)) > 1 And Microsoft.VisualBasic.Right(origsize, 2) = "MB" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Image exceeds the maximum file size 1MB." & vbCrLf & "Compressing image. Please wait.", MsgBoxStyle.Information)

                    Button3.PerformClick()
                    pgbar4.Visible = True

                    If BackgroundWorker1.IsBusy = False Then
                        BackgroundWorker1.RunWorkerAsync()
                    End If

                    'COMPRESS IMAGE THEN REPLACE IMGBOX4.IMAGE NG COMPRESSED NA IMAGE
                    imgbox4.Image = compressimage(imgbox4.Image, Trim(cmbimg4.Text))
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.WaitCursor
                'insert photo in tblimg
                Dim ms As New MemoryStream()
                'search image name if existing
                conn.Open()
                '/connect()
                cmd = New SqlCommand("Select * from tbldispatchstp4 where tripnum='" & lbltripnum4.Text & "' and name='" & Trim(cmbimg4.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg4.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg4.Focus()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar4.Value = 0
                    pgbar4.Visible = False
                    Exit Sub
                Else
                    'save record in database
                    conn.Close()
                    conn.Open()
                    '/connect()
                    cmd = New SqlCommand("Insert into tbldispatchstp4 values(@tripnum,@name,@img,@status,GetDate(),@createdby)", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltripnum4.Text))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(cmbimg4.Text)))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                    imgbox4.Image.Save(ms, Imaging.ImageFormat.Jpeg)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    '/cmd.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                    cmd.ExecuteNonQuery()
                    conn.Close()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar4.Value = 0
                    pgbar4.Visible = False

                    MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    pgbar4.Value = 0
                    imgbox4.Image = Nothing
                    imgbox4.BackColor = Color.Empty
                    imgbox4.Invalidate()
                    ms.Close()
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.Default
                btnimgadd4.Text = "Add Photo"
                imgcancelfalse4()
                imgpanel4.Enabled = True
                '/enableall()
                btnimgrefresh4.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub imgcanceltrue4()
        btnimgadd4.Enabled = False
        btnimgrename4.Enabled = False
        btnimgremove4.Enabled = False
        btnimgcancel4.Enabled = True
        btnimgdl4.Enabled = False
        btnimgfull4.Enabled = True
        btnimgrefresh4.Enabled = False
    End Sub

    Public Sub imgcancelfalse4()
        If btnstartdoc.Text <> "TIME START RELEASE DOCUMENTS" Then
            cmbimg4.Text = ""
            lblimgdate4.Text = ""
            lblimgname4.Text = ""
            btnimgadd4.Text = "Add Photo"
            btnimgrename4.Text = "Rename"
            btnimgadd4.Enabled = True
            btnimgrename4.Enabled = True
            btnimgremove4.Enabled = True
            btnimgcancel4.Enabled = False
            btnimgdl4.Enabled = True
            btnimgfull4.Enabled = True
            btnimgrefresh4.Enabled = True
            btnexempt4.Enabled = True
            btnconfirm4.Enabled = True
        Else
            btnimgadd4.Enabled = False
            btnimgrename4.Enabled = False
            btnimgremove4.Enabled = False
            btnimgcancel4.Enabled = True
            btnimgdl4.Enabled = False
            btnimgfull4.Enabled = True
        End If
    End Sub

    Private Sub btnimgrefresh4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrefresh4.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meronstp4 = False
            imgpanel4.Visible = False
            imgpanel4.Controls.Clear()
            imgpanel4.Visible = True

            Dim ctr As Integer = 0
            sql = "Select * from tbldispatchstp4 where tripnum='" & lbltripnum4.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                meronstp4 = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                picstp4 = New PictureBox
                picstp4.Image = Image.FromStream(ms)
                ms.Dispose()
                picstp4.SizeMode = PictureBoxSizeMode.Zoom
                picstp4.SetBounds(wid, y, 104, 100)
                'picstp4.BackColor = Color.AliceBlue
                picstp4.Tag = dr("stp4imgid")
                picstp4.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler picstp4.Click, AddressOf convertPic4
                imgpanel4.Controls.Add(picstp4)
                imgpanel4.Controls.Add(lbl)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            imgbox4.Image = Nothing
            cmbimg4.Text = ""
            lblimgid4.Text = ""
            lblimgdate4.Text = ""
            lblimgname4.Text = ""

            Me.Cursor = Cursors.Default

            If meronstp4 = False Then
                If btnstartdoc.Text <> "TIME START RELEASE DOCUMENTS" Then
                    btnimgrename4.Enabled = False
                    btnimgremove4.Enabled = False
                    btnimgcancel4.Enabled = False
                    btnimgdl4.Enabled = False
                    btnimgfull4.Enabled = False
                    btnconfirm4.Enabled = False
                    If login.whse = "Cebu" Or login.whse = "Davao" Or login.whse = "Bacolod" Or login.whse = "Tacloban" Then
                        btnconfirm4.Enabled = True
                    End If
                End If
            Else
                imgcancelfalse4()
            End If

            If grdstep4.Rows.Count = 0 Then
                grp4.Enabled = False
            Else
                grp4.Enabled = True
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Sub convertPic4(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            picstp4 = CType(sender, PictureBox)
            imgbox4.Image = picstp4.Image
            lblimgid4.Text = picstp4.Tag

            sql = "Select name,datecreated,createdby from tbldispatchstp4 where stp4imgid='" & lblimgid4.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbimg4.Text = dr("name")
                If IsDBNull(dr("datecreated")) = False Then
                    lblimgdate4.Text = Format(dr("datecreated"), "MM/dd/yyyy h:mm tt")
                Else
                    lblimgdate4.Text = ""
                End If
                lblimgname4.Text = dr("createdby").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgfull4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgfull4.Click
        If lblimgid4.Text <> "" Or imgbox4.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox4.Image
            viewimage.lblimgname.Text = cmbimg4.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnconfirm4.Click
        Try
            If login.neym <> "Encoder" And login.neym <> "Manager" Then
                If login.neym = "Checker" And login.whse = "C3 Manila" Then
                ElseIf login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum4.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum4.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum4.Text, "step4")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 4 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL4 HAS CONTROLS
            If imgpanel4.Controls.Count = 0 And login.whse <> "Cebu" And login.whse <> "Davao" And login.whse <> "Bacolod" And login.whse <> "Tacloban" Then
                Me.Cursor = Cursors.Default
                MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If grdtrans4.Rows.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("You cancelled all order transactions under trip# " & lbltripnum4.Text & ". Add transaction to existing trip first.", MsgBoxStyle.Critical)
                Exit Sub
            End If

            sql = "Select * from tbldispatchsum where step3='0' and tripnum='" & lbltripnum4.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Me.Cursor = Cursors.Default
                MsgBox("Please confirm Step 3 (Loading) first.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            For Each row As DataGridViewRow In grdtrans4.Rows
                Dim trn As String = grdtrans4.Rows(row.Index).Cells(1).Value
                Dim ref As String = Trim(grdtrans4.Rows(row.Index).Cells(2).Value.ToString)
                Dim arn As String = Trim(grdtrans4.Rows(row.Index).Cells(7).Value.ToString)
                Dim rdr As String = Trim(grdtrans4.Rows(row.Index).Cells(8).Value.ToString)
                Dim drn As String = Trim(grdtrans4.Rows(row.Index).Cells(9).Value.ToString)
                Dim dnn As String = Trim(grdtrans4.Rows(row.Index).Cells(10).Value.ToString)
                Dim itr As String = Trim(grdtrans4.Rows(row.Index).Cells(11).Value.ToString)
                Dim type As String = Trim(grdtrans4.Rows(row.Index).Cells(12).Value.ToString)
                Dim notes As String = Trim(grdtrans4.Rows(row.Index).Cells(13).Value.ToString)

                If type = "JPSC SALES TRANSACTION" Or type = "CUSTOMER SALES TRANSACTION WHSE" Then
                    If arn = "" Or rdr = "" Or drn = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Incomplete input.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans4.Rows(row.Index).Cells(4), DataGridViewCheckBoxCell)
                    If checkCell.Value = False Then
                        Me.Cursor = Cursors.Default
                        If login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                            checkCell.Value = True
                        Else
                            MsgBox("Check SO.", MsgBoxStyle.Information, "")
                            Exit Sub
                        End If
                    End If

                ElseIf type = "JPSC STOCK TRANSFER WHSE TO WHSE" Then
                    If grdtrans4.Rows(row.Index).Cells(2).Value.ToString.Contains("ITR") Then
                        'STOCK TRANSFER WHSE TO WHSE ITR LANG
                        'STOCK TRANSFER PICKUP FRM PIER
                        If itr = "" Then
                            Me.Cursor = Cursors.Default
                            MsgBox("Incomplete input. Input ITR#.", MsgBoxStyle.Information, "")
                            Exit Sub
                        End If
                        Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans4.Rows(row.Index).Cells(6), DataGridViewCheckBoxCell)
                        If checkCell.Value = False Then
                            Me.Cursor = Cursors.Default
                            If login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                                checkCell.Value = True
                            Else
                                MsgBox("Check ITR.", MsgBoxStyle.Information, "")
                                Exit Sub
                            End If
                        End If
                    End If

                ElseIf type = "JPSC STOCK TRANSFER PICKUP FRM AGI CALAMBA" Or type = "JPSC STOCK TRANSFER PICKUP FRM AGI CALACA" Or type = "TRUCKING STOCK TRANSFER PICKUP FRM AGI CALAMBA" Or type = "TRUCKING STOCK TRANSFER PICKUP FRM AGI CALACA" Then

                    'STOCK TRANSFER PICKUP FRM AGI PO LANG
                    If dnn = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Incomplete input. Input DN#.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If
                    If itr = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Incomplete input. Input ITR#.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans4.Rows(row.Index).Cells(5), DataGridViewCheckBoxCell)
                    If checkCell.Value = False Then
                        Me.Cursor = Cursors.Default
                        If login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                            checkCell.Value = True
                        Else
                            MsgBox("Check PO.", MsgBoxStyle.Information, "")
                            Exit Sub
                        End If
                    End If

                ElseIf type.Contains("SALES TRANSACTION PICKUP FRM PIER") = True Then

                    If arn = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Incomplete input. Input AR#.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If
                    If rdr = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Incomplete input. Input RDR#.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If
                    If drn = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Incomplete input. Input DR#.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If

                ElseIf type.Contains("STOCK TRANSFER PICKUP FRM PIER") = True Then

                    If itr = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Incomplete input. Input ITR#.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If

                ElseIf type = "JPSC SALES TRANSACTION PICKUP FRM AGI CALAMBA" Or type = "JPSC SALES TRANSACTION PICKUP FRM AGI CALACA" Then
                    If arn = "" Or rdr = "" Or drn = "" Or dnn = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Incomplete input.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans4.Rows(row.Index).Cells(4), DataGridViewCheckBoxCell)
                    Dim checkCell1 As DataGridViewCheckBoxCell = CType(grdtrans4.Rows(row.Index).Cells(5), DataGridViewCheckBoxCell)
                    If checkCell.Value = False Or checkCell1.Value = False Then
                        Me.Cursor = Cursors.Default
                        If login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                            checkCell.Value = True
                            checkCell1.Value = True
                        Else
                            If ref <> "0000" Then
                                MsgBox("Check SO and PO if equal to AGI DN and GRPO.", MsgBoxStyle.Information, "")
                                Exit Sub
                            End If
                        End If
                    End If

                Else
                    If type.Contains("SALES TRANSACTION") = True Then
                        If arn = "" Or rdr = "" Or drn = "" Then
                            Me.Cursor = Cursors.Default
                            MsgBox("Incomplete input.", MsgBoxStyle.Information, "")
                            Exit Sub
                        End If
                    Else
                        If itr = "" Then
                            Me.Cursor = Cursors.Default
                            MsgBox("Incomplete input. Input ITR#.", MsgBoxStyle.Information, "")
                            Exit Sub
                        End If
                    End If

                End If
            Next

            If login.userid = 34 And login.whse = "Calamba" Then
                pass = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If pass = True Then
                    ExecuteConfirm4atAGI(strconn)

                    zero4()
                    grdtrans4.Rows.Clear()
                    tripstep4()
                End If

                Exit Sub
            End If


            wctab = "tab4"

            sign.Width = 733
            sign.lblplate.Text = lblplate4.Text
            If lbltype4.Text = "TRUCKING TRUCK" Then
                sign.GroupBox1.Text = "Pier Checker ()"
                sign.GroupBox4.Text = "Helper ()"
            Else
                sign.GroupBox1.Text = "Driver (" & grdstep4.Rows(grdstep4.CurrentRow.Index).Cells(3).Value & ")"
                sign.GroupBox4.Text = "Helper (" & grdstep4.Rows(grdstep4.CurrentRow.Index).Cells(4).Value & ")"
            End If

            sign.GroupBox2.Text = login.neym & " (" & login.fullneym & ")"
            sign.lbltrip.Text = lbltripnum4.Text
            sign.lblrems.Text = txtrems4.Text 'para dun ndin isang save nlng

            sign.yescnf = False
            sign.ShowDialog()

            If sign.yescnf = True Then
                zero4()
                grdtrans4.Rows.Clear()
                tripstep4()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteConfirm4atAGI(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            ' Start a local transaction
            transaction = connection.BeginTransaction("SampleTransaction")

            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                'tblortrans
                For Each row As DataGridViewRow In grdtrans4.Rows
                    Dim trn As String = grdtrans4.Rows(row.Index).Cells(1).Value
                    Dim arn As String = Trim(grdtrans4.Rows(row.Index).Cells(7).Value.ToString)
                    Dim rdr As String = Trim(grdtrans4.Rows(row.Index).Cells(8).Value.ToString)
                    Dim drn As String = Trim(grdtrans4.Rows(row.Index).Cells(9).Value.ToString)
                    Dim dnn As String = Trim(grdtrans4.Rows(row.Index).Cells(10).Value.ToString)
                    Dim itr As String = Trim(grdtrans4.Rows(row.Index).Cells(11).Value.ToString)
                    Dim notes As String = Trim(grdtrans4.Rows(row.Index).Cells(13).Value.ToString)

                    sql = "Update tblortrans set arnum='" & arn & "', rdrnum='" & rdr & "', drnum='" & drn & "', dnnum='" & dnn & "', itrnum='" & itr & "', notes='" & notes & "', datemodified=GetDate() where transnum='" & trn & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                Next

                'tbldispatchsum
                'step4
                sql = "Update tbldispatchsum set step4='1', namestp4='" & login.cashier & "', datestp4=GetDate(), mneymstp4='" & login.cashier & "', mdeytstp4=GetDate(), remstp4='" & Trim(txtrems4.Text) & "' where tripnum='" & lbltripnum4.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("PROCCED TO NEXT STEP.", MsgBoxStyle.Information, "")

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btnimgrename4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrename4.Click
        Try
            If login.neym <> "Encoder" And login.neym <> "Manager" Then
                If login.neym = "Checker" And login.whse = "C3 Manila" Then
                ElseIf login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum4.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum4.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum4.Text, "step4")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 4 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgrename4.Text = "Rename" Then
                If Trim(cmbimg4.Text) <> "" And imgbox4.Image IsNot Nothing Then
                    Dim tempname As String = Trim(cmbimg4.Text)
                    If tempname.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Cannot rename photo.", MsgBoxStyle.Exclamation, "")
                        cmbimg4.Focus()
                        Exit Sub
                    End If
                    cmbimg4.Enabled = True
                    cmbimg4.Focus()
                ElseIf Trim(cmbimg4.Text) = "" And imgbox4.Image IsNot Nothing Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg4.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    cmbimg4.Focus()
                    Exit Sub
                End If

                imgpanel4.Enabled = False
                imgcanceltrue4()
                btnimgrename4.Enabled = True
                btnimgrename4.Text = "Save"
            Else
                'search image name if existing
                connect()
                cmd = New SqlCommand("Select * from tbldispatchstp4 where tripnum='" & lbltripnum4.Text & "' and name='" & Trim(cmbimg4.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg4.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg4.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default

                    If cmbimg4.Text.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Invalid photo name.", MsgBoxStyle.Exclamation, "")
                        cmbimg4.Text = ""
                        cmbimg4.Focus()
                        Exit Sub
                    End If

                    'irename.. update yung name lng where imgid = lblimgid.text
                    sql = "Update tbldispatchstp4 set name='" & Trim(cmbimg4.Text) & "' where stp4imgid='" & lblimgid4.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                    btnimgrename4.Text = "Rename"
                    imgcancelfalse4()
                    imgpanel4.Enabled = True
                    btnimgrefresh4.PerformClick()
                    Me.Cursor = Cursors.Default
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgremove4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgremove4.Click
        Try
            If login.neym <> "Encoder" And login.neym <> "Manager" Then
                If login.neym = "Checker" And login.whse = "C3 Manila" Then
                ElseIf login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum4.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum4.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum4.Text, "step4")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 4 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(cmbimg4.Text) <> "" And imgbox4.Image IsNot Nothing Then
                If cmbimg4.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot delete signature", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2)
                If a = vbYes Then
                    'delete image where imgid=lblimgid.text
                    sql = "Delete from tbldispatchstp4 where stp4imgid='" & lblimgid4.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    Me.Cursor = Cursors.Default
                    MsgBox("Successfully remove.", MsgBoxStyle.Information, "")

                    imgcancelfalse4()
                    imgpanel4.Enabled = True
                    btnimgrefresh4.PerformClick()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                cmbimg4.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgcancel4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel4.Click
        Try
            imgpanel4.Enabled = True
            imgbox4.Image = Nothing
            cmbimg4.Text = ""
            lblimgid4.Text = ""
            imgcancelfalse4()

            If meronstp4 = False Then
                btnimgrename4.Enabled = False
                btnimgremove4.Enabled = False
                btnimgcancel4.Enabled = False
                btnimgdl4.Enabled = False
                btnimgfull4.Enabled = False
            Else
                imgcancelfalse4()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnexempt4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexempt4.Click
        Try
            If login.neym <> "Encoder" And login.neym <> "Manager" Then
                If login.neym = "Checker" And login.whse = "C3 Manila" Then
                ElseIf login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum4.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum4.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum4.Text, "step4")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 4 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL4 HAS CONTROLS
            If imgpanel4.Controls.Count = 0 Then
                'MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
            End If

            For Each row As DataGridViewRow In grdtrans4.Rows
                Dim trn As String = grdtrans4.Rows(row.Index).Cells(1).Value
                Dim arn As String = Trim(grdtrans4.Rows(row.Index).Cells(7).Value.ToString)
                Dim rdr As String = Trim(grdtrans4.Rows(row.Index).Cells(8).Value.ToString)
                Dim drn As String = Trim(grdtrans4.Rows(row.Index).Cells(9).Value.ToString)
                Dim dnn As String = Trim(grdtrans4.Rows(row.Index).Cells(10).Value.ToString)
                Dim itr As String = Trim(grdtrans4.Rows(row.Index).Cells(11).Value.ToString)
                Dim type As String = Trim(grdtrans4.Rows(row.Index).Cells(12).Value.ToString)
                Dim notes As String = Trim(grdtrans4.Rows(row.Index).Cells(13).Value.ToString)

                If type = "JPSC SALES TRANSACTION" Or type = "CUSTOMER SALES TRANSACTION WHSE" Then
                    If arn = "" Or rdr = "" Or drn = "" Then
                        'MsgBox("Incomplete input.", MsgBoxStyle.Information, "")
                        'Exit Sub
                    End If
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans4.Rows(row.Index).Cells(4), DataGridViewCheckBoxCell)
                    If checkCell.Value = False Then
                        If login.neym = "Encoder" Then
                            'MsgBox("Check SO.", MsgBoxStyle.Information, "")
                            'Exit Sub
                        End If
                    End If

                ElseIf type = "JPSC STOCK TRANSFER WHSE TO WHSE" Then
                    If grdtrans4.Rows(row.Index).Cells(2).Value.ToString.Contains("ITR") Then
                        'STOCK TRANSFER WHSE TO WHSE ITR LANG
                        'STOCK TRANSFER PICKUP FRM PIER
                        If itr = "" Then
                            ' MsgBox("Incomplete input.", MsgBoxStyle.Information, "")
                            'Exit Sub
                        End If
                        Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans4.Rows(row.Index).Cells(6), DataGridViewCheckBoxCell)
                        If checkCell.Value = False Then
                            If login.neym = "Encoder" Then
                                'MsgBox("Check ITR.", MsgBoxStyle.Information, "")
                                'Exit Sub
                            End If
                        End If
                    End If

                ElseIf type = "JPSC STOCK TRANSFER PICKUP FRM AGI CALAMBA" Or type = "JPSC STOCK TRANSFER PICKUP FRM AGI CALACA" Or type = "TRUCKING STOCK TRANSFER PICKUP FRM AGI CALAMBA" Or type = "TRUCKING STOCK TRANSFER PICKUP FRM AGI CALACA" Then

                    'STOCK TRANSFER PICKUP FRM AGI PO LANG
                    If dnn = "" Then
                        'MsgBox("Incomplete input.", MsgBoxStyle.Information, "")
                        'Exit Sub
                    End If
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans4.Rows(row.Index).Cells(5), DataGridViewCheckBoxCell)
                    If checkCell.Value = False Then
                        If login.neym = "Encoder" Then
                            'MsgBox("Check PO.", MsgBoxStyle.Information, "")
                            'Exit Sub
                        End If
                    End If

                Else
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans4.Rows(row.Index).Cells(4), DataGridViewCheckBoxCell)
                    Dim checkCell1 As DataGridViewCheckBoxCell = CType(grdtrans4.Rows(row.Index).Cells(5), DataGridViewCheckBoxCell)
                    If checkCell.Value = False Or checkCell1.Value = False Then
                        'MsgBox("Check SO and PO if equal to AGI DN and GRPO.", MsgBoxStyle.Information, "")
                        'Exit Sub
                    Else
                        'MsgBox("Email DR to AGI.", MsgBoxStyle.Information, "")
                    End If
                End If
            Next


            pass = False
            confirmsave.GroupBox1.Text = login.neym
            confirmsave.ShowDialog()

            If pass = True Then
                Me.Cursor = Cursors.Default
                ExecuteSaveStep4(strconn)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteSaveStep4(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            transaction = connection.BeginTransaction("SampleTransaction")

            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                For Each row As DataGridViewRow In grdtrans4.Rows
                    Dim trn As String = grdtrans4.Rows(row.Index).Cells(1).Value
                    Dim arn As String = Trim(grdtrans4.Rows(row.Index).Cells(7).Value.ToString)
                    Dim rdr As String = Trim(grdtrans4.Rows(row.Index).Cells(8).Value.ToString)
                    Dim drn As String = Trim(grdtrans4.Rows(row.Index).Cells(9).Value.ToString)
                    Dim dnn As String = Trim(grdtrans4.Rows(row.Index).Cells(10).Value.ToString)
                    Dim itr As String = Trim(grdtrans4.Rows(row.Index).Cells(11).Value.ToString)
                    Dim notes As String = Trim(grdtrans4.Rows(row.Index).Cells(13).Value.ToString)

                    sql = "Update tblortrans set arnum='" & arn & "', rdrnum='" & rdr & "', drnum='" & drn & "', dnnum='" & dnn & "', itrnum='" & itr & "', notes='" & notes & "', datemodified=GetDate(), manager='" & login.cashier & "' where transnum='" & trn & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                Next

                'save remarks
                sql = "Update tbldispatchsum set sneymstp4='" & login.cashier & "', sdeytstp4=GetDate(), remstp4='" & txtrems4.Text & "' where tripnum='" & lbltripnum4.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox(lblplate4.Text & " STEP 4 Saved as draft.", MsgBoxStyle.Information, "")

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub cmbimg4_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbimg4.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtrems4_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems4.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Public Sub tripstep5()
        Try
            Me.Cursor = Cursors.WaitCursor

            grp5.Enabled = True
            grdstep5.Rows.Clear()

            'sql = "Select * from tbltripsum where tbltripsum.status='1'"
            sql = "SELECT tbltripsum.tripsumid,tbltripsum.tripnum,tbltripsum.platenum,tbltripsum.driver,tbltripsum.helper,tbltripsum.datepick,tbldispatchsum.whsename9,tbldispatchsum.timedep"
            sql = sql & " FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum"
            sql = sql & " where tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' and tbldispatchsum.step1='1' and tbldispatchsum.step5='0' order by datepick"
            grdsql = sql
            whatstep = 5

            bgw = New BackgroundWorker()

            AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
            AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
            AddHandler bgw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not bgw.IsBusy Then
                lblload5.Visible = True
                gstep5.Enabled = False
                bgw.WorkerReportsProgress = True
                bgw.WorkerSupportsCancellation = True
                bgw.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub zero5()
        lblplate5.Text = ""
        lbltype5.Text = ""
        lbltripnum5.Text = ""
        lblconfirm5.Text = 0
        txtrems5.Text = ""

        grdtrans5.Rows.Clear()
        btnstartcash.Text = "TIME START RELEASE PETTY CASH"

        imgpanel5.Visible = False
        imgpanel5.Controls.Clear()
        imgpanel5.Visible = True
    End Sub

    Private Sub grdstep5_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grdstep5.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdstep5.Rows(e.RowIndex)
            '<== But this is the name assigned to it in the properties of the control
            'If CDate(Format(dgvRow.Cells(1).Value, "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
            If dgvRow.Cells(5).Value <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
                dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
            End If
        End If
    End Sub

    Private Sub grdstep5_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep5.CellClick
        Try
            zero5()
            Me.Cursor = Cursors.WaitCursor

            lbltripnum5.Tag = grdstep5.Rows(grdstep5.CurrentRow.Index).Cells(0).Value
            lbltripnum5.Text = grdstep5.Rows(grdstep5.CurrentRow.Index).Cells(1).Value
            lblplate5.Text = grdstep5.Rows(grdstep5.CurrentRow.Index).Cells(2).Value

            SelectStep5(strconn)

            If imgpanel5.Controls.Count = 0 Then
                btnconfirm5.Enabled = False
            End If

            btnimgrefresh5.PerformClick()

            If grdstep5.Rows.Count <> 0 Then
                grp5.Text = lbltripnum5.Text & "     -     " & grdstep5.Rows(grdstep5.CurrentRow.Index).Cells(5).Value
            Else
                grp5.Text = "Photos"
            End If

            If grdtrans5.Rows.Count = 0 Then
                '/Me.Cursor = Cursors.Default
                '/MsgBox("You cancelled all order transactions under trip# " & lbltripnum5.Text & ". Add transaction to existing trip first.", MsgBoxStyle.Critical)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub SelectStep5(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Select vtype from tblgeneral where platenum='" & lblplate5.Text & "' or vplate='" & lblplate5.Text & "' or csticker='" & lblplate5.Text & "'"
               command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    lbltype5.Text = dr("vtype")
                End If
                dr.Dispose()

                grdtrans5.Rows.Clear()
                sql = "SELECT tblortrans.* FROM tblortrans inner join tbltripitems on tblortrans.transnum=tbltripitems.transnum"
                sql = sql & " where tbltripitems.tripnum='" & lbltripnum5.Text & "' and tbltripitems.status<>'0' and tbltripitems.status<>'3'"
                command.CommandText = sql
                dr = command.ExecuteReader
                While dr.Read
                    grdtrans5.Rows.Add(dr("transid"), dr("transnum"), dr("refnum"), dr("customer"), dr("arnum"), dr("rdrnum"), dr("drnum"), dr("dnnum"), dr("itrnum"), dr("transtype"), dr("notes"))
                End While
                dr.Dispose()

                btnstartcash.Text = "TIME START RELEASE PETTY CASH"
                sql = "Select step5,startcash,remstp5 from tbldispatchsum where tripnum='" & lbltripnum5.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    If dr("step5") = 1 Then
                        lblconfirm5.Text = 1
                    End If

                    If dr("startcash").ToString <> "" Then
                        Dim starttime As Date
                        Dim timeCheck As Boolean
                        timeCheck = IsDate(dr("startcash").ToString)
                        If timeCheck = True Then
                            'MsgBox(Trim(txttime.Text) & timeCheck)
                            starttime = CDate(dr("startcash").ToString)
                            btnstartcash.Text = "TIME START RELEASE PETTY CASH: " & Format(starttime, "HH:mm")
                            txtrems5.Text = dr("remstp5").ToString
                            startcashfalse()
                            btnexempt5.Enabled = True
                        End If
                    Else
                        btnstartcash.Enabled = True
                        btnimgadd5.Enabled = False
                        txtrems5.Enabled = False
                        txtrems5.Text = ""
                        tripinfo5.Enabled = False
                        btnexempt5.Enabled = False
                    End If
                End If
                dr.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub startcashfalse()
        btnstartcash.Enabled = False
        btnimgadd5.Enabled = True
        txtrems5.Enabled = True
        tripinfo5.Enabled = True
    End Sub

    Private Sub grdstep5_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdstep5.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Up Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Down Then
            e.Handled = True
        End If
    End Sub

    Private Sub grdstep5_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdstep5.SelectionChanged
        
    End Sub

    Private Sub btnrefstep5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrefstep5.Click
        tripstep5()
    End Sub

    Private Sub btnimgadd5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgadd5.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" Then
                If login.neym = "Checker" And login.whse = "C3 Manila" Then
                ElseIf login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum5.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum5.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum5.Text, "step5")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 5 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgadd5.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofdstp5.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox5.Image = Nothing
                    Dim bmp As New Bitmap(ofdstp5.FileName)
                    imgbox5.Image = bmp
                    '/imgbox5.Image = LoadImage(ofdstp5.FileName)
                    cmbimg5.Text = ofdstp5.SafeFileName.ToString.Replace("'", "")
                    cmbimg5.Enabled = True
                    cmbimg5.Focus()

                    lblCompressionLevel.Text = ""

                    ' Display the file's size.
                    Dim file_info As New FileInfo(ofdstp5.FileName)
                    lblOriginalSize.Text = FormatBytes(file_info.Length)
                    If Microsoft.VisualBasic.Right(ofdstp5.FileName.ToString, 3) = "png" Then
                        lblDesiredSize.Text = FormatBytes(file_info.Length * 0.3)
                    Else
                        lblDesiredSize.Text = "1.10 MB" 'FormatBytes(file_info.Length * 0.4)
                    End If
                    lblCompressedSize.Text = ""
                    lblCompressionLevel.Text = ""

                    Me.Cursor = Cursors.Default
                    imgpanel5.Enabled = False
                    '/enabletab4only()
                    imgcanceltrue5()
                    btnimgadd5.Enabled = True
                    btnimgadd5.Text = "Add"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(cmbimg5.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg5.Focus()
                    Exit Sub
                End If

                If cmbimg5.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photoname.", MsgBoxStyle.Exclamation, "")
                    cmbimg5.Text = ""
                    cmbimg5.Focus()
                    Exit Sub
                End If

                Dim origsize As String = lblOriginalSize.Text
                If Val(origsize.Substring(0, origsize.Length - 2)) > 1 And Microsoft.VisualBasic.Right(origsize, 2) = "MB" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Image exceeds the maximum file size 1MB." & vbCrLf & "Compressing image. Please wait.", MsgBoxStyle.Information)

                    Button3.PerformClick()
                    pgbar5.Visible = True

                    If BackgroundWorker1.IsBusy = False Then
                        BackgroundWorker1.RunWorkerAsync()
                    End If

                    'COMPRESS IMAGE THEN REPLACE IMGBOX5.IMAGE NG COMPRESSED NA IMAGE
                    imgbox5.Image = compressimage(imgbox5.Image, Trim(cmbimg5.Text))
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.WaitCursor
                'insert photo in tblimg
                Dim ms As New MemoryStream()
                'search image name if existing
                conn.Open()
                '/connect()
                cmd = New SqlCommand("Select * from tbldispatchstp5 where tripnum='" & lbltripnum5.Text & "' and name='" & Trim(cmbimg5.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg5.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg5.Focus()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar5.Value = 0
                    pgbar5.Visible = False
                    Exit Sub
                Else
                    'save record in database
                    conn.Close()
                    conn.Open()
                    '/connect()
                    cmd = New SqlCommand("Insert into tbldispatchstp5 values(@tripnum,@name,@img,@status,GetDate(),@createdby)", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltripnum5.Text))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(cmbimg5.Text)))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                    imgbox5.Image.Save(ms, Imaging.ImageFormat.Jpeg)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    '/cmd.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                    cmd.ExecuteNonQuery()
                    conn.Close()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar5.Value = 0
                    pgbar5.Visible = False

                    MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    pgbar5.Value = 0
                    imgbox5.Image = Nothing
                    imgbox5.BackColor = Color.Empty
                    imgbox5.Invalidate()
                    ms.Close()
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.Default
                btnimgadd5.Text = "Add Photo"
                imgcancelfalse5()
                imgpanel5.Enabled = True
                '/enableall()
                btnimgrefresh5.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub imgcanceltrue5()
        btnimgadd5.Enabled = False
        btnimgrename5.Enabled = False
        btnimgremove5.Enabled = False
        btnimgcancel5.Enabled = True
        btnimgdl5.Enabled = False
        btnimgfull5.Enabled = True
        btnimgrefresh5.Enabled = False
    End Sub

    Public Sub imgcancelfalse5()
        cmbimg5.Text = ""
        lblimgdate5.Text = ""
        lblimgname5.Text = ""
        btnimgadd5.Text = "Add Photo"
        btnimgrename5.Text = "Rename"
        btnimgadd5.Enabled = True
        btnimgrename5.Enabled = True
        btnimgremove5.Enabled = True
        btnimgcancel5.Enabled = False
        btnimgdl5.Enabled = True
        btnimgfull5.Enabled = True
        btnimgrefresh5.Enabled = True
        btnexempt5.Enabled = True
        btnconfirm5.Enabled = True
    End Sub

    Private Sub btnimgrefresh5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrefresh5.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meronstp5 = False
            imgpanel5.Visible = False
            imgpanel5.Controls.Clear()
            imgpanel5.Visible = True

            Dim ctr As Integer = 0
            sql = "Select * from tbldispatchstp5 where tripnum='" & lbltripnum5.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                meronstp5 = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                picstp5 = New PictureBox
                picstp5.Image = Image.FromStream(ms)
                ms.Dispose()
                picstp5.SizeMode = PictureBoxSizeMode.Zoom
                picstp5.SetBounds(wid, y, 104, 100)
                'picstp5.BackColor = Color.AliceBlue
                picstp5.Tag = dr("stp5imgid")
                picstp5.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler picstp5.Click, AddressOf convertPic5
                imgpanel5.Controls.Add(picstp5)
                imgpanel5.Controls.Add(lbl)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            imgbox5.Image = Nothing
            cmbimg5.Text = ""
            lblimgid5.Text = ""
            lblimgdate5.Text = ""
            lblimgname5.Text = ""

            Me.Cursor = Cursors.Default

            If meronstp5 = False Then
                btnimgrename5.Enabled = False
                btnimgremove5.Enabled = False
                btnimgcancel5.Enabled = False
                btnimgdl5.Enabled = False
                btnimgfull5.Enabled = False
                'btnexempt5.Enabled = False
                btnconfirm5.Enabled = False
                If login.whse = "Cebu" Or login.whse = "Davao" Or login.whse = "Bacolod" Or login.whse = "Tacloban" Then
                    btnconfirm5.Enabled = True
                End If
            Else
                imgcancelfalse5()
            End If

            If grdstep5.Rows.Count = 0 Then
                grp5.Enabled = False
            Else
                grp5.Enabled = True
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Sub convertPic5(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            picstp5 = CType(sender, PictureBox)
            imgbox5.Image = picstp5.Image
            lblimgid5.Text = picstp5.Tag

            sql = "Select name,datecreated,createdby from tbldispatchstp5 where stp5imgid='" & lblimgid5.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbimg5.Text = dr("name")
                If IsDBNull(dr("datecreated")) = False Then
                    lblimgdate5.Text = Format(dr("datecreated"), "MM/dd/yyyy h:mm tt")
                Else
                    lblimgdate5.Text = ""
                End If
                lblimgname5.Text = dr("createdby").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgfull5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgfull5.Click
        If lblimgid5.Text <> "" Or imgbox5.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox5.Image
            viewimage.lblimgname.Text = cmbimg5.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnconfirm5.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" Then
                If login.neym = "Checker" And login.whse = "C3 Manila" Then
                ElseIf login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum5.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum5.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum5.Text, "step5")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 5 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            sql = "Select * from tbldispatchsum where step3='0' and tripnum='" & lbltripnum5.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Me.Cursor = Cursors.Default
                MsgBox("Please confirm Step 3 (Loading) first.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If grdtrans5.Rows.Count = 0 Then
                '/Me.Cursor = Cursors.Default
                '/MsgBox("You cancelled all order transactions under trip# " & lbltripnum5.Text & ". Add transaction to existing trip first.", MsgBoxStyle.Critical)
                '/Exit Sub
            End If

            If login.whse = "C3 Manila" Then
                'check if may pickup frm pier sa grdtrans5 cells(9)
                Dim withpuppier As Boolean = False
                For Each row As DataGridViewRow In grdtrans5.Rows
                    If grdtrans5.Rows(row.Index).Cells(9).Value.ToString.Contains("PICKUP FRM PIER") = True Then
                        withpuppier = True
                        Exit For
                    End If
                Next

                If withpuppier = True Then
                    'check kung confirm na ba step4
                    sql = "Select * from tbldispatchsum where step4='0' and tripnum='" & lbltripnum5.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Please confirm Step 4 (Release Documents) first.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            End If

            Me.Cursor = Cursors.Default
            'CHECK IF IMGPANEL5 HAS CONTROLS
            If imgpanel5.Controls.Count = 0 And login.whse <> "Cebu" And login.whse <> "Davao" And login.whse <> "Bacolod" And login.whse <> "Tacloban" Then
                MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
            Else

                If login.userid = 34 And login.whse = "Calamba" Then
                    'pag kay mam abigail lang
                    pass = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()
                    If pass = True Then
                        'tbldispatchsum
                        'step5
                        sql = "Update tbldispatchsum set step5='1', namestp5='" & login.cashier & "', datestp5=GetDate(), mneymstp5='" & login.cashier & "', mdeytstp5=GetDate(), remstp5='" & Trim(txtrems5.Text) & "' where tripnum='" & lbltripnum5.Text & "'"
                        conn.Open()
                        '/connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        zero5()
                        grdtrans5.Rows.Clear()
                        tripstep5()

                        MsgBox("PROCCED TO NEXT STEP.", MsgBoxStyle.Information, "")
                    End If

                    Exit Sub
                End If

                wctab = "tab5"

                sign.Width = 733
                sign.lblplate.Text = lblplate5.Text
                sign.GroupBox1.Text = "Driver (" & grdstep5.Rows(grdstep5.CurrentRow.Index).Cells(3).Value & ")"
                sign.GroupBox4.Text = "Helper (" & grdstep5.Rows(grdstep5.CurrentRow.Index).Cells(4).Value & ")"
                sign.GroupBox2.Text = login.neym & " (" & login.fullneym & ")"
                sign.lbltrip.Text = lbltripnum5.Text
                sign.lblrems.Text = txtrems5.Text 'para dun ndin isang save nlng

                sign.yescnf = False
                sign.ShowDialog()

                If sign.yescnf = True Then
                    zero5()
                    grdtrans5.Rows.Clear()
                    tripstep5()
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgrename5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrename5.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" Then
                If login.neym = "Checker" And login.whse = "C3 Manila" Then
                ElseIf login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum5.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum5.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum5.Text, "step5")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 5 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgrename5.Text = "Rename" Then
                If Trim(cmbimg5.Text) <> "" And imgbox5.Image IsNot Nothing Then
                    Dim tempname As String = Trim(cmbimg5.Text)
                    If tempname.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Cannot rename photo.", MsgBoxStyle.Exclamation, "")
                        cmbimg5.Focus()
                        Exit Sub
                    End If
                    cmbimg5.Enabled = True
                    cmbimg5.Focus()
                ElseIf Trim(cmbimg5.Text) = "" And imgbox5.Image IsNot Nothing Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg5.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    cmbimg5.Focus()
                    Exit Sub
                End If

                imgpanel5.Enabled = False
                imgcanceltrue5()
                btnimgrename5.Enabled = True
                btnimgrename5.Text = "Save"
            Else
                'search image name if existing
                connect()
                cmd = New SqlCommand("Select * from tbldispatchstp5 where tripnum='" & lbltripnum5.Text & "' and name='" & Trim(cmbimg5.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg5.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg5.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default

                    If cmbimg5.Text.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Invalid photo name.", MsgBoxStyle.Exclamation, "")
                        cmbimg5.Text = ""
                        cmbimg5.Focus()
                        Exit Sub
                    End If

                    'irename.. update yung name lng where imgid = lblimgid.text
                    sql = "Update tbldispatchstp5 set name='" & Trim(cmbimg5.Text) & "' where stp5imgid='" & lblimgid5.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                    btnimgrename5.Text = "Rename"
                    imgcancelfalse5()
                    imgpanel5.Enabled = True
                    btnimgrefresh5.PerformClick()
                    Me.Cursor = Cursors.Default
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgremove5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgremove5.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" Then
                If login.neym = "Checker" And login.whse = "C3 Manila" Then
                ElseIf login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum5.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum5.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum5.Text, "step5")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 5 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(cmbimg5.Text) <> "" And imgbox5.Image IsNot Nothing Then
                If cmbimg5.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot delete signature", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2)
                If a = vbYes Then
                    'delete image where imgid=lblimgid.text
                    sql = "Delete from tbldispatchstp5 where stp5imgid='" & lblimgid5.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    Me.Cursor = Cursors.Default
                    MsgBox("Successfully remove.", MsgBoxStyle.Information, "")

                    imgcancelfalse5()
                    imgpanel5.Enabled = True
                    btnimgrefresh5.PerformClick()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                cmbimg5.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgcancel5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel5.Click
        imgpanel5.Enabled = True
        imgbox5.Image = Nothing
        cmbimg5.Text = ""
        lblimgid5.Text = ""
        imgcancelfalse5()

        If meronstp5 = False Then
            btnimgrename5.Enabled = False
            btnimgremove5.Enabled = False
            btnimgcancel5.Enabled = False
            btnimgdl5.Enabled = False
            btnimgfull5.Enabled = False
        Else
            imgcancelfalse5()
        End If
    End Sub

    Private Sub btnexempt5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexempt5.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" Then
                If login.neym = "Checker" And login.whse = "C3 Manila" Then
                ElseIf login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum5.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum5.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum5.Text, "step5")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 5 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If


            pass = False
            confirmsave.GroupBox1.Text = login.neym
            confirmsave.ShowDialog()

            If pass = True Then
                'save remarks
                sql = "Update tbldispatchsum set sneymstp5='" & login.cashier & "', sdeytstp5=GetDate(), remstp5='" & txtrems5.Text & "' where tripnum='" & lbltripnum5.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                Me.Cursor = Cursors.Default
                MsgBox(lblplate5.Text & " STEP 5 Saved as draft.", MsgBoxStyle.Information, "")
            End If


            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbimg5_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbimg5.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtrems5_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems5.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Public Sub computedshould()
        If txtdiswith.Text <> "" And txtdshould.Text <> "" And IsNumeric(Trim(txtdiswith.Text)) And IsNumeric(Trim(txtdshould.Text)) Then
            If Val(lblpwith.Text) <> 0 And Val(lblpwout.Text) <> 0 Then
                txtdshould.Text = Val(Trim(lblinch.Text)) + Format((Val(Trim(txtdiswith.Text)) / Val(lblpwith.Text)) + (Val(Trim(txtdiswout.Text)) / Val(lblpwout.Text)), "0.00")
            Else
                txtdshould.Text = Val(Trim(lblfull.Text))
            End If
        Else
            txtdshould.Text = 0
        End If

        computepo()
    End Sub

    Public Sub computepo()
        'po=(2inch + diesel should be)-beg bal
        Dim cpo As Double
        Dim nt As Integer = 0
        If IsNumeric(txtdiesel.Text) And Val(txtdiesel.Text) >= 0 Then
            cpo = (Val(Trim(txtdshould.Text))) - Val(Trim(txtdiesel.Text))
            If cpo <= 0 Then
                txtpo.Text = 0
            Else
                nt = Fix(cpo)
                If nt < cpo Then
                    txtpo.Text = nt + 1
                Else
                    txtpo.Text = nt
                End If
            End If
        Else
            txtpo.Text = 0
        End If
    End Sub

    Private Sub txtdiswith_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtdiswith.KeyDown
        If e.KeyCode = Keys.Enter Then
            '' Your code here
            'SendKeys.Send("{TAB}")
            'e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txtdiswith.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txtdiswith.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txtdiswith.Paste()
        End If
    End Sub

    Private Sub txtdiswith_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtdiswith.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                computedshould()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtdiswith.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            'e.Handled = True
                        Else
                            'txtdiswith.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtdiswith.Text) <> "" And txtdiswith.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtdiswith.Text) <> "" And txtdiswith.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtdiswout_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtdiswout.KeyDown
        If e.KeyCode = Keys.Enter Then
            '' Your code here
            'SendKeys.Send("{TAB}")
            'e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txtdiswout.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txtdiswout.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txtdiswout.Paste()
        End If
    End Sub

    Private Sub txtdiswout_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtdiswout.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                computedshould()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtdiswout.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            'e.Handled = True
                        Else
                            'txtdiswout.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtdiswout.Text) <> "" And txtdiswout.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtdiswout.Text) <> "" And txtdiswout.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtdshould_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtdshould.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                computedshould()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtdshould.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            e.Handled = True
                        Else
                            txtdshould.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtdshould.Text) <> "" And txtdshould.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtdshould.Text) <> "" And txtdshould.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtdiesel_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtdiesel.KeyDown
        If e.KeyCode = Keys.Enter Then
            '' Your code here
            'SendKeys.Send("{TAB}")
            'e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txtdiesel.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txtdiesel.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txtdiesel.Paste()
        End If
    End Sub

    Private Sub txtdiesel_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtdiesel.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                computedshould()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtdiesel.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            'e.Handled = True
                        Else
                            'txtdiesel.Text = 0
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtdiesel.Text) <> "" And txtdiesel.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtdiesel.Text) <> "" And txtdiesel.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtaddpo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtaddpo.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Your code here
            SendKeys.Send("{TAB}")
            e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txtaddpo.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txtaddpo.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txtaddpo.Paste()
        End If
    End Sub

    Private Sub txtaddpo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtaddpo.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                'cmp()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtaddpo.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            e.Handled = True
                        Else
                            txtaddpo.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtaddpo.Text) <> "" And txtaddpo.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtaddpo.Text) <> "" And txtaddpo.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtdiswith_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtdiswith.Leave
        computedshould()
        If Trim(txtdiswith.Text) = "" Then
            txtdiswith.Text = 0
        Else
            If cmbtrans2.Items.Count = 1 Then
                txtdiswout.Text = txtdiswith.Text
            End If
        End If
    End Sub

    Private Sub txtaddpo_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtaddpo.Leave
        computedshould()
        If Trim(txtaddpo.Text) = "" Or Val(txtaddpo.Text) = 0 Then
            txtaddpo.Text = 0
        End If
        If Val(txtaddpo.Text) > 10 Then
            btnpo.Image = ImageList1.Images(1)
            btnpo.Tag = "NOT"
            'check sa database yung last dapat same diesel if 0 not approved if 1 approved
            sql = "Select TOP 1 * from tbladdpo where tripnum='" & lbltripnum2.Text & "' order by adpoid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("status") = 1 Then
                    If Val(txtaddpo.Text) = dr("addpo") Then
                        btnpo.Image = ImageList1.Images(0)
                        btnpo.Tag = "OK"
                    End If
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()
        Else
            btnpo.Image = ImageList1.Images(0)
            btnpo.Tag = "OK"
        End If
    End Sub

    Private Sub txtdiesel_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtdiesel.Leave

        If Trim(txtdiesel.Text) = "" Then
            txtdiesel.Text = 0
        End If

        computedshould()

        If Val(Trim(txtdiesel.Text)) < Trim(txtdieselbeg1.Text) And Trim(txtrems2.Text) <> "" Then
            Me.Cursor = Cursors.Default
            MsgBox("Beginning Actual Diesel is less than the Previous Diesel. Add Remarks.", MsgBoxStyle.Exclamation, "")
            '/txtrems2.Focus()
            '/Exit Sub
        End If

        If Val(Trim(txtdiesel.Text)) > Trim(txtdieselbeg1.Text) And Trim(txtrems2.Text) <> "" Then
            Me.Cursor = Cursors.Default
            MsgBox("Beginning Actual Diesel is greater than the Previous Diesel. Add Remarks.", MsgBoxStyle.Exclamation, "")
            '/txtrems2.Focus()
            '/Exit Sub
        End If

        If Val(txtdieselbeg1.Text) - Val(txtdiesel.Text) >= 5 Then
            'MsgBox("Add Remarks. Large variance between actual diesel and previous diesel.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub txtdshould_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtdshould.Leave
        computedshould()
        If Trim(txtdshould.Text) = "" Then
            txtdshould.Text = 0
        End If
    End Sub

    Private Sub txtdiswout_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtdiswout.Leave
        computedshould()
        If Trim(txtdiswout.Text) = "" Then
            txtdiswout.Text = 0
        End If
    End Sub

    Private Sub txtscale_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtlabor.KeyPress
        Try
            If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Then

            Else
                e.Handled = True
            End If

        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub tripstep6()
        Try
            Me.Cursor = Cursors.WaitCursor

            grp6.Enabled = True
            grdstep6.Rows.Clear()

            'sql = "Select * from tbltripsum where tbltripsum.status='1'"
            sql = "SELECT tbltripsum.tripsumid,tbltripsum.tripnum,tbltripsum.platenum,tbltripsum.driver,tbltripsum.helper,tbltripsum.datepick,tbldispatchsum.timedep,tbldispatchsum.whsename9"
            sql = sql & " FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum"
            sql = sql & " where tbltripsum.status='1' and tbldispatchsum.step1='1' and tbltripsum.whsename='" & login.whse & "' and tbldispatchsum.step2='1' and tbldispatchsum.step3='1' and tbldispatchsum.step4='1' and tbldispatchsum.step5='1' and tbldispatchsum.step6='0' order by datepick"
            grdsql = sql
            whatstep = 6

            bgw = New BackgroundWorker()

            AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
            AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
            AddHandler bgw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not bgw.IsBusy Then
                lblload6.Visible = True
                gstep6.Enabled = False
                bgw.WorkerReportsProgress = True
                bgw.WorkerSupportsCancellation = True
                bgw.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub zero6()
        lblplate6.Text = ""
        lbltype6.Text = ""
        lbltripnum6.Text = ""
        lblconfirm6.Text = 0
        txtrems6.Text = ""
        txtetd.Text = "ETD: "

        btndepart.Text = "TIME DEPARTURE TRUCK EXIT WHSE"

        imgpanel6.Visible = False
        imgpanel6.Controls.Clear()
        imgpanel6.Visible = True
    End Sub

    Private Sub grdstep6_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grdstep6.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdstep6.Rows(e.RowIndex)
            '<== But this is the name assigned to it in the properties of the control
            'If CDate(Format(dgvRow.Cells(1).Value, "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
            If dgvRow.Cells(6).Value = True Then
                dgvRow.DefaultCellStyle.BackColor = Color.PeachPuff
            Else
                dgvRow.DefaultCellStyle.BackColor = Color.PaleTurquoise
            End If
        End If
    End Sub

    Private Sub grdstep6_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep6.CellClick
        Try
            zero6()
            Me.Cursor = Cursors.WaitCursor

            lbltripnum6.Tag = grdstep6.Rows(grdstep6.CurrentRow.Index).Cells(0).Value
            lbltripnum6.Text = grdstep6.Rows(grdstep6.CurrentRow.Index).Cells(1).Value
            lblplate6.Text = grdstep6.Rows(grdstep6.CurrentRow.Index).Cells(2).Value

            SelectStep6(strconn)

            btnimgrefresh6.PerformClick()

            If grdstep6.Rows.Count <> 0 Then
                grp6.Text = lbltripnum6.Text & "     -     " & grdstep6.Rows(grdstep6.CurrentRow.Index).Cells(5).Value
            Else
                grp6.Text = "Photos"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub SelectStep6(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim command2 As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Select vtype from tblgeneral where platenum='" & lblplate6.Text & "' or vplate='" & lblplate6.Text & "' or csticker='" & lblplate6.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    lbltype6.Text = dr("vtype")
                End If
                dr.Dispose()

                sql = "Select etd, repair from tbltripsum where tripnum='" & lbltripnum6.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    txtetd.Text = "ETD: " & dr("etd")
                    lblpup6.Text = dr("repair")
                End If
                dr.Dispose()

                If lbltype6.Text = "CUSTOMER TRUCK" Or lbltype6.Text = "TRUCKING TRUCK" Then
                    cmbtrans6.Items.Clear()
                    sql = "Select transnum from tbltripitems where tripnum='" & lbltripnum6.Text & "' and status<>'0' and status<>'3'"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    While dr.Read
                        cmbtrans6.Items.Add(dr("transnum"))
                    End While
                    dr.Dispose()

                    If cmbtrans6.Items.Count <> 0 Then
                        cmbtrans6.SelectedIndex = 0
                        sql = "Select customer from tblortrans where transnum='" & cmbtrans6.SelectedItem & "'"
                        command.CommandText = sql
                        dr = command.ExecuteReader
                        If dr.Read Then
                            txtcustomer.Text = dr("customer")
                        End If
                        dr.Dispose()


                        Dim temp As String = "", temptype As String = ""
                        For i = 0 To cmbtrans6.Items.Count - 1
                            cmbtrans6.SelectedIndex = i
                            sql = "Select customer,transtype from tblortrans where transnum='" & cmbtrans6.SelectedItem & "'"
                            command.CommandText = sql
                            dr = command.ExecuteReader
                            While dr.Read
                                temp = temp & (dr("customer")) & " / "

                                If dr("transtype").ToString.Contains("PICKUP") Then
                                    Dim inSql As String = dr("transtype").ToString
                                    Dim lastPart As String
                                    Dim fromStart As Integer
                                    Dim firstpart As String

                                    fromStart = inSql.IndexOf("FRM ") + 4

                                    firstpart = inSql.Substring(0, fromStart - 4)
                                    temptype = Trim(firstpart)

                                    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

                                    temptype = lastPart & " "

                                End If
                            End While
                            dr.Dispose()
                        Next
                        txtcustomer.Text = "Destination: " & temp
                    End If
                Else
                    txtcustomer.Text = ""
                End If

                btndepart.Text = "TIME DEPARTURE TRUCK EXIT WHSE"
                sql = "Select step6,timedep,remstp6 from tbldispatchsum where tripnum='" & lbltripnum6.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    If dr("step6") = 1 Then
                        lblconfirm6.Text = 1
                    End If

                    If dr("timedep").ToString <> "" Then
                        Dim starttime As Date
                        Dim timeCheck As Boolean
                        timeCheck = IsDate(dr("timedep").ToString)
                        If timeCheck = True Then
                            'MsgBox(Trim(txttime.Text) & timeCheck)
                            starttime = CDate(dr("timedep").ToString)
                            btndepart.Text = "TIME DEPARTURE TRUCK EXIT WHSE: " & Format(starttime, "HH:mm")
                            txtrems6.Text = dr("remstp6").ToString
                            departfalse()
                            btnexempt6.Enabled = True
                        End If
                    Else
                        btndepart.Enabled = True
                        If login.whse = "Milaor" Then
                            btnmtc.Enabled = True
                        Else
                            btnmtc.Enabled = False
                        End If
                        txtrems6.Enabled = False
                        txtrems6.Text = ""
                        btnimgadd6.Enabled = False
                        btnconfirm6.Enabled = False
                        btnother6.Enabled = False
                        btnexempt6.Enabled = False
                    End If
                End If
                dr.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub departfalse()
        btndepart.Enabled = False
        btnmtc.Enabled = False
        txtrems6.Enabled = True
        btnimgadd6.Enabled = True
        btnconfirm6.Enabled = True
        btnother6.Enabled = True
    End Sub

    Private Sub grdstep6_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep6.CellContentClick
        
    End Sub

    Private Sub grdstep6_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdstep6.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Up Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Down Then
            e.Handled = True
        End If
    End Sub

    Private Sub grdstep6_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdstep6.SelectionChanged
        
    End Sub

    Private Sub btnrefstep6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrefstep6.Click
        tripstep6()
    End Sub

    Private Sub btnimgadd6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgadd6.Click
        Try
            If login.neym <> "Guard" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum6.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum6.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum6.Text, "step6")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 6 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgadd6.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofdstp6.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox6.Image = Nothing
                    Dim bmp As New Bitmap(ofdstp6.FileName)
                    imgbox6.Image = bmp
                    '/imgbox6.Image = LoadImage(ofdstp6.FileName)
                    cmbimg6.Text = ofdstp6.SafeFileName.ToString.Replace("'", "")
                    cmbimg6.Enabled = True
                    cmbimg6.Focus()

                    lblCompressionLevel.Text = ""

                    ' Display the file's size.
                    Dim file_info As New FileInfo(ofdstp6.FileName)
                    lblOriginalSize.Text = FormatBytes(file_info.Length)
                    If Microsoft.VisualBasic.Right(ofdstp6.FileName.ToString, 3) = "png" Then
                        lblDesiredSize.Text = FormatBytes(file_info.Length * 0.3)
                    Else
                        lblDesiredSize.Text = "1.10 MB" 'FormatBytes(file_info.Length * 0.4)
                    End If
                    lblCompressedSize.Text = ""
                    lblCompressionLevel.Text = ""

                    Me.Cursor = Cursors.Default
                    imgpanel6.Enabled = False
                    '/enabletab4only()
                    imgcanceltrue6()
                    btnimgadd6.Enabled = True
                    btnimgadd6.Text = "Add"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(cmbimg6.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg6.Focus()
                    Exit Sub
                End If

                If cmbimg6.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photoname.", MsgBoxStyle.Exclamation, "")
                    cmbimg6.Text = ""
                    cmbimg6.Focus()
                    Exit Sub
                End If

                Dim origsize As String = lblOriginalSize.Text
                If Val(origsize.Substring(0, origsize.Length - 2)) > 1 And Microsoft.VisualBasic.Right(origsize, 2) = "MB" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Image exceeds the maximum file size 1MB." & vbCrLf & "Compressing image. Please wait.", MsgBoxStyle.Information)

                    Button3.PerformClick()
                    pgbar6.Visible = True

                    If BackgroundWorker1.IsBusy = False Then
                        BackgroundWorker1.RunWorkerAsync()
                    End If

                    'COMPRESS IMAGE THEN REPLACE IMGBOX6.IMAGE NG COMPRESSED NA IMAGE
                    imgbox6.Image = compressimage(imgbox6.Image, Trim(cmbimg6.Text))
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.WaitCursor
                'insert photo in tblimg
                Dim ms As New MemoryStream()
                'search image name if existing
                conn.Open()
                '/connect()
                cmd = New SqlCommand("Select * from tbldispatchstp6 where tripnum='" & lbltripnum6.Text & "' and name='" & Trim(cmbimg6.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg6.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg6.Focus()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar6.Value = 0
                    pgbar6.Visible = False
                    Exit Sub
                Else
                    'save record in database
                    conn.Close()
                    conn.Open()
                    '/connect()
                    cmd = New SqlCommand("Insert into tbldispatchstp6 values(@tripnum,@name,@img,@status,GetDate(),@createdby)", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltripnum6.Text))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(cmbimg6.Text)))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                    imgbox6.Image.Save(ms, Imaging.ImageFormat.Jpeg)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    '/cmd.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                    cmd.ExecuteNonQuery()
                    conn.Close()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar6.Value = 0
                    pgbar6.Visible = False

                    MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    pgbar6.Value = 0
                    imgbox6.Image = Nothing
                    imgbox6.BackColor = Color.Empty
                    imgbox6.Invalidate()
                    ms.Close()
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.Default
                btnimgadd6.Text = "Add Photo"
                imgcancelfalse6()
                imgpanel6.Enabled = True
                '/enableall()
                btnimgrefresh6.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub imgcanceltrue6()
        btnimgadd6.Enabled = False
        btnimgrename6.Enabled = False
        btnimgremove6.Enabled = False
        btnimgcancel6.Enabled = True
        btnimgdl6.Enabled = False
        btnimgfull6.Enabled = True
        btnimgrefresh6.Enabled = False
        lblimgid6.Enabled = False
    End Sub

    Public Sub imgcancelfalse6()
        cmbimg6.Text = ""
        btnimgadd6.Text = "Add Photo"
        btnimgrename6.Text = "Rename"
        btnimgadd6.Enabled = True
        btnimgrename6.Enabled = True
        btnimgremove6.Enabled = True
        btnimgcancel6.Enabled = False
        btnimgdl6.Enabled = True
        btnimgfull6.Enabled = True
        btnimgrefresh6.Enabled = True
        lblimgid6.Enabled = True
        btnother6.Enabled = True
        btnexempt6.Enabled = True
    End Sub

    Private Sub btnimgrefresh6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrefresh6.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meronstp6 = False
            imgpanel6.Visible = False
            imgpanel6.Controls.Clear()
            imgpanel6.Visible = True

            Dim ctr As Integer = 0
            sql = "Select * from tbldispatchstp6 where tripnum='" & lbltripnum6.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                meronstp6 = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                picstp6 = New PictureBox
                picstp6.Image = Image.FromStream(ms)
                ms.Dispose()
                picstp6.SizeMode = PictureBoxSizeMode.Zoom
                picstp6.SetBounds(wid, y, 104, 100)
                'picstp6.BackColor = Color.AliceBlue
                picstp6.Tag = dr("stp6imgid")
                picstp6.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler picstp6.Click, AddressOf convertPic6
                imgpanel6.Controls.Add(picstp6)
                imgpanel6.Controls.Add(lbl)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            imgbox6.Image = Nothing
            cmbimg6.Text = ""
            lblimgid6.Text = ""

            Me.Cursor = Cursors.Default

            If meronstp6 = False Then
                btnimgrename6.Enabled = False
                btnimgremove6.Enabled = False
                btnimgcancel6.Enabled = False
                btnimgdl6.Enabled = False
                btnimgfull6.Enabled = False
                lblimgid6.Enabled = False
            Else
                imgcancelfalse6()
            End If

            If grdstep6.Rows.Count = 0 Then
                grp6.Enabled = False
            Else
                grp6.Enabled = True
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Sub convertPic6(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            picstp6 = CType(sender, PictureBox)
            imgbox6.Image = picstp6.Image
            lblimgid6.Text = picstp6.Tag

            sql = "Select * from tbldispatchstp6 where stp6imgid='" & lblimgid6.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbimg6.Text = dr("name")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgfull6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgfull6.Click
        If lblimgid6.Text <> "" Or imgbox6.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox6.Image
            viewimage.lblimgname.Text = cmbimg6.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub btnother6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnother6.Click
        Try
            If login.neym <> "Guard" And login.neym <> "Logistics Staff" And login.neym <> "Manager" And login.neym <> "Whse Logistics Staff" Then
                '/Me.Cursor = Cursors.Default
                '/MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                '/Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum6.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum6.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum6.Text, "step6")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 6 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL6 HAS CONTROLS
            If imgpanel6.Controls.Count = 0 Then
                'Me.Cursor = Cursors.Default
                'MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Information, "")
            End If

            ''CHECK IF may remarks
            'If Trim(txtrems6.Text) = "" Then
            '    Me.Cursor = Cursors.Default
            '    MsgBox("Input warehouse where the truck is arrived.", MsgBoxStyle.Exclamation, "")
            '    txtrems6.Focus()
            '    Exit Sub
            'End If

            tripwhse.cmbwhse.Items.Clear()
            sql = "Select whsename from tblwhse where company='J. Poon & Sons' and status='1' and whsename<>'" & login.whse & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                tripwhse.cmbwhse.Items.Add(dr("whsename"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            arrwhse = ""
            tripwhse.ShowDialog()

            If arrwhse <> "" Then
                If login.neym = "Guard" Then
                    pass = False
                    confirmguard.GroupBox1.Text = login.neym
                    confirmguard.ShowDialog()
                    If pass = True Then
                        ExecuteConfirmStep6(strconn, arrwhse)

                        zero6()
                        tripstep6()
                    End If
                    Me.Cursor = Cursors.Default
                    Exit Sub
                Else
                    pass = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()
                    If pass = True Then
                        ExecuteConfirmStep6(strconn, arrwhse)

                        zero6()
                        tripstep6()
                    End If
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnconfirm6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnconfirm6.Click
        Try
            If login.neym <> "Guard" And login.neym <> "Manager" And login.neym <> "Whse Logistics Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum6.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum6.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum6.Text, "step6")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 6 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL6 HAS CONTROLS
            If imgpanel6.Controls.Count = 0 Then
                Me.Cursor = Cursors.Default
                '/MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Information, "")
            End If

            'if may makitang naga whse automatic i-arrival to other whse

            pass = False
            confirmguard.ShowDialog()
            If pass = True Then
                ExecuteConfirmStep6(strconn, login.whse)

                zero6()
                tripstep6()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteConfirmStep6(ByVal connectionString As String, ByVal arrival_whse As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            transaction = connection.BeginTransaction("SampleTransaction")

            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                'step6
                sql = "Update tbldispatchsum set step6='1', arrwhse='" & arrival_whse & "', namestp6='" & login.cashier & "', datestp6=GetDate(), mneymstp6='" & login.cashier & "', mdeytstp6=GetDate(), remstp6='" & txtrems6.Text & "' where tripnum='" & lbltripnum6.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                sql = "Update tbltripsum set timearr=GetDate(), datemodified=GetDate(), modifiedby='" & login.neym & "' where tripnum='" & lbltripnum6.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                '/MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")  '/MsgBox("Both records are written to database.")

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btnmtc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnmtc.Click
        Try
            If login.neym <> "Guard" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum6.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum6.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum6.Text, "step6")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 6 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL6 HAS CONTROLS
            If imgpanel6.Controls.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Information, "")
            End If

            Me.Cursor = Cursors.Default
            MsgBox("MTC.", MsgBoxStyle.Information, "")

            pass = False
            confirmguard.ShowDialog()
            If pass = True Then
                ExecuteConfirmMTC(strconn)

                zero6()
                tripstep6()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteConfirmMTC(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                'step6
                sql = "Update tbldispatchsum set timedep=GetDate(), timedepby='" & login.cashier & "', step6='1', namestp6='" & login.cashier & "', datestp6=GetDate(), mneymstp6='" & login.cashier & "', mdeytstp6=GetDate(), remstp6='MTC' where tripnum='" & lbltripnum6.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                sql = "Update tbltripsum set timedep=GetDate(), timearr=GetDate(), datemodified=GetDate(), modifiedby='" & login.neym & "' where tripnum='" & lbltripnum6.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btnexempt6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexempt6.Click
        Try
            If login.neym <> "Guard" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum6.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum6.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum6.Text, "step6")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 6 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            pass = False
            confirmsave.GroupBox1.Text = login.neym
            confirmsave.ShowDialog()

            If pass = True Then
                'save remarks
                sql = "Update tbldispatchsum set sneymstp6='" & login.cashier & "', sdeytstp6=GetDate(), remstp6='" & txtrems6.Text & "' where tripnum='" & lbltripnum6.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                Me.Cursor = Cursors.Default
                MsgBox(lblplate6.Text & " STEP 6 Saved as draft.", MsgBoxStyle.Information, "")
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgrename6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrename6.Click
        Try
            If login.neym <> "Guard" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum6.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum6.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum6.Text, "step6")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 6 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgrename6.Text = "Rename" Then
                If Trim(cmbimg6.Text) <> "" And imgbox6.Image IsNot Nothing Then
                    Dim tempname As String = Trim(cmbimg6.Text)
                    If tempname.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Cannot rename photo.", MsgBoxStyle.Exclamation, "")
                        cmbimg6.Focus()
                        Exit Sub
                    End If
                    cmbimg6.Enabled = True
                    cmbimg6.Focus()
                ElseIf Trim(cmbimg6.Text) = "" And imgbox6.Image IsNot Nothing Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg6.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    cmbimg6.Focus()
                    Exit Sub
                End If

                imgpanel6.Enabled = False
                imgcanceltrue6()
                btnimgrename6.Enabled = True
                btnimgrename6.Text = "Save"
            Else
                'search image name if existing
                connect()
                cmd = New SqlCommand("Select * from tbldispatchstp6 where tripnum='" & lbltripnum6.Text & "' and name='" & Trim(cmbimg6.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg6.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg6.Focus()
                    Exit Sub
                Else
                    If cmbimg6.Text.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Invalid photo name.", MsgBoxStyle.Exclamation, "")
                        cmbimg6.Text = ""
                        cmbimg6.Focus()
                        Exit Sub
                    End If

                    'irename.. update yung name lng where imgid = lblimgid.text
                    sql = "Update tbldispatchstp6 set name='" & Trim(cmbimg6.Text) & "' where stp6imgid='" & lblimgid6.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    Me.Cursor = Cursors.Default
                    MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                    btnimgrename6.Text = "Rename"
                    imgcancelfalse6()
                    imgpanel6.Enabled = True
                    btnimgrefresh6.PerformClick()
                    Me.Cursor = Cursors.Default
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgremove6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgremove6.Click
        Try
            If login.neym <> "Guard" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum6.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum6.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum6.Text, "step6")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 6 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(cmbimg6.Text) <> "" And imgbox6.Image IsNot Nothing Then
                If cmbimg6.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot delete signature", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2)
                If a = vbYes Then
                    'delete image where imgid=lblimgid.text
                    sql = "Delete from tbldispatchstp6 where stp6imgid='" & lblimgid6.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    Me.Cursor = Cursors.Default
                    MsgBox("Successfully remove.", MsgBoxStyle.Information, "")

                    imgcancelfalse6()
                    imgpanel6.Enabled = True
                    btnimgrefresh6.PerformClick()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                cmbimg6.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgcancel6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel6.Click
        imgpanel6.Enabled = True
        imgbox6.Image = Nothing
        cmbimg6.Text = ""
        lblimgid6.Text = ""
        imgcancelfalse6()

        If meronstp6 = False Then
            btnimgrename6.Enabled = False
            btnimgremove6.Enabled = False
            btnimgcancel6.Enabled = False
            btnimgdl6.Enabled = False
            btnimgfull6.Enabled = False
        Else
            imgcancelfalse6()
        End If
    End Sub

    Private Sub cmbimg6_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbimg6.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtrems6_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems6.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtlabor_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtlabor.Leave
        txtlabor.Text = Val(txtlabor.Text)
    End Sub

    Public Sub tripstep7()
        Try
            Me.Cursor = Cursors.WaitCursor

            grp7.Enabled = True
            grdstep7.Rows.Clear()

            'sql = "Select * from tbltripsum where tbltripsum.status='1'"
            sql = "SELECT tbltripsum.tripsumid,tbltripsum.tripnum,tbltripsum.platenum,tbltripsum.driver,tbltripsum.helper,tbltripsum.datepick,tbldispatchsum.whsename9,tbldispatchsum.timedep"
            sql = sql & " FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum"
            sql = sql & " where tbltripsum.status='1' and tbldispatchsum.step1='1' and tbltripsum.whsename='" & login.whse & "' and tbldispatchsum.step2='1' and tbldispatchsum.step3='1' and tbldispatchsum.step4='1' and tbldispatchsum.step5='1' and tbldispatchsum.step6='1' and tbldispatchsum.step7='0' order by datepick"
            grdsql = sql
            whatstep = 7

            bgw = New BackgroundWorker()

            AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
            AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
            AddHandler bgw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not bgw.IsBusy Then
                lblload7.Visible = True
                gstep7.Enabled = False
                bgw.WorkerReportsProgress = True
                bgw.WorkerSupportsCancellation = True
                bgw.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub zero7()
        lblplate7.Text = ""
        lbltype7.Text = ""
        lbltripnum7.Text = ""
        lblconfirm7.Text = 0
        txtrems7.Text = ""

        chkpending.Checked = False
        grdtrans7.Rows.Clear()
        btnstartreturn.Text = "TIME START RETURN DOCUMENTS"

        imgpanel7.Visible = False
        imgpanel7.Controls.Clear()
        imgpanel7.Visible = True
    End Sub

    Private Sub grdstep7_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep7.CellContentClick

    End Sub

    Private Sub grdstep7_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grdstep7.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdstep7.Rows(e.RowIndex)
            '<== But this is the name assigned to it in the properties of the control
            'If CDate(Format(dgvRow.Cells(1).Value, "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
            If dgvRow.Cells(5).Value <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
                dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
            End If
        End If
    End Sub

    Private Sub grdstep7_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep7.CellClick
        Try
            zero7()
            Me.Cursor = Cursors.WaitCursor

            lbltripnum7.Tag = grdstep7.Rows(grdstep7.CurrentRow.Index).Cells(0).Value
            lbltripnum7.Text = grdstep7.Rows(grdstep7.CurrentRow.Index).Cells(1).Value
            lblplate7.Text = grdstep7.Rows(grdstep7.CurrentRow.Index).Cells(2).Value

            row7 = grdstep7.CurrentRow.Index
            SelectStep7(strconn)

            If imgpanel7.Controls.Count = 0 Then
                btnconfirm7.Enabled = False
            End If

            btnimgrefresh7.PerformClick()

            If grdstep7.Rows.Count <> 0 Then
                grp7.Text = lbltripnum7.Text & "     -     " & grdstep7.Rows(grdstep7.CurrentRow.Index).Cells(5).Value
            Else
                grp7.Text = "Photos"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub SelectStep7(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Select vtype from tblgeneral where platenum='" & lblplate7.Text & "' or vplate='" & lblplate7.Text & "' or csticker='" & lblplate7.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    lbltype7.Text = dr("vtype")
                End If
                dr.Dispose()

                grdtrans7.Rows.Clear()
                sql = "Select tblortrans.*, tbltripitems.status as tripitemstatus, tbltripitems.datecreated, tbltripitems.alreadydisp from tblortrans"
                sql = sql & " inner join tbltripitems on tblortrans.transnum=tbltripitems.transnum"
                sql = sql & " where tbltripitems.tripnum='" & lbltripnum7.Text & "' and tbltripitems.status<>'0' and tbltripitems.status<>'3'"
                command.CommandText = sql
                dr = command.ExecuteReader
                While dr.Read
                    Dim backloadall As Boolean = False, itn As String = "", grp As String = ""
                    If dr("tripitemstatus") = 4 Then
                        backloadall = True
                    End If

                    Dim cmemo As Boolean = False
                    If dr("tripitemstatus") = 5 Then
                        cmemo = True
                    End If

                    If dr("itnum").ToString = "" Then
                        If dr("transtype").ToString.Contains("STOCK TRANSFER") = False Then
                            itn = "N/A"
                        End If
                    Else
                        itn = dr("itnum").ToString
                    End If
                    If dr("grponum").ToString = "" Then
                        If dr("transtype").ToString.Contains("STOCK TRANSFER") = False Then
                            grp = "N/A"
                        End If
                    Else
                        grp = dr("grponum").ToString
                    End If

                    grdtrans7.Rows.Add(dr("transid"), dr("transnum"), dr("refnum"), dr("customer"), backloadall, cmemo, dr("arnum"), dr("rdrnum"), dr("drnum"), dr("dnnum"), dr("itrnum"), itn, grp, dr("transtype"), dr("notes"), "")

                    If IsDBNull(dr("datecreated")) = False Then
                        grdtrans7.Rows(grdtrans7.Rows.Count - 1).Cells(15).Value = dr("datecreated") 'ormat(dr("datecreated"), "yyyy/MM/dd HH:mm")
                    End If

                    If dr("cancel") = 1 Or dr("tripitemstatus") = 0 Then
                        grdtrans7.Rows(grdtrans7.Rows.Count - 1).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                    ElseIf dr("tripitemstatus") = 4 Then
                        grdtrans7.Rows(grdtrans7.Rows.Count - 1).DefaultCellStyle.BackColor = Color.Plum
                    ElseIf dr("tripitemstatus") = 5 Then
                        grdtrans7.Rows(grdtrans7.Rows.Count - 1).DefaultCellStyle.BackColor = Color.Orange
                    End If

                    If IsDBNull(dr("alreadydisp")) = False Then
                        If dr("alreadydisp") = 1 Then 'departure
                            grdtrans7.Item(15, grdtrans7.Rows.Count - 1).Style.BackColor = Color.FromArgb(192, 255, 255)
                        ElseIf dr("alreadydisp") = 2 Then 'arrival
                            grdtrans7.Item(15, grdtrans7.Rows.Count - 1).Style.BackColor = Color.FromArgb(255, 224, 192)
                        End If
                    End If
                End While
                dr.Dispose()

                btnstartreturn.Text = "TIME START RETURN OF DOCUMENTS"
                sql = "Select step7,startreturn,remstp7,withpending, tbltripsum.podiesel, tbltripsum.addpo, tbltripsum.postaddpo, tbltripsum.repair from tbldispatchsum"
                sql = sql & " inner join tbltripsum on tbldispatchsum.tripnum=tbltripsum.tripnum where tbldispatchsum.tripnum='" & lbltripnum7.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    txtpo7.Text = dr("podiesel") + dr("addpo") + dr("postaddpo")

                    If dr("step7") = 1 Then
                        lblconfirm7.Text = 1
                    End If

                    If dr("startreturn").ToString <> "" Then
                        Dim starttime As Date
                        Dim timeCheck As Boolean
                        timeCheck = IsDate(dr("startreturn").ToString)
                        If timeCheck = True Then
                            'MsgBox(Trim(txttime.Text) & timeCheck)
                            starttime = CDate(dr("startreturn").ToString)
                            btnstartreturn.Text = "TIME START RETURN OF DOCUMENTS: " & Format(starttime, "HH:mm")
                            txtrems7.Text = dr("remstp7").ToString
                            If IsDBNull(dr("withpending")) = False Then
                                If dr("withpending") = 1 Then
                                    chkpending.Checked = True
                                Else
                                    chkpending.Checked = False
                                End If
                            Else
                                chkpending.Checked = False
                            End If

                            startreturnfalse()
                        End If
                    Else
                        btnstartreturn.Enabled = True
                        btnimgadd7.Enabled = False
                        txtrems7.Enabled = False
                        txtrems7.Text = ""
                        tripinfo7.Enabled = False
                        btnexempt7.Enabled = False
                        link2to7.Enabled = False
                        chkpending.Enabled = False
                        grdtrans7.ReadOnly = True
                    End If

                    If dr("repair") = 1 Then
                        lblpick7.Visible = True
                        imgbox7.Location = New System.Drawing.Point(imgbox7.Location.X, 65)
                        imgbox7.Size = New System.Drawing.Point(imgbox7.Size.Width, 174)
                    Else
                        lblpick7.Visible = False
                        imgbox7.Location = New System.Drawing.Point(imgbox7.Location.X, 22)
                        imgbox7.Size = New System.Drawing.Point(imgbox7.Size.Width, 217)
                    End If

                End If
                dr.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                triplink7 = False

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub startreturnfalse()
        btnstartreturn.Enabled = False
        btnimgadd7.Enabled = True
        txtrems7.Enabled = True
        tripinfo7.Enabled = True
        btnexempt7.Enabled = True
        link2to7.Enabled = True
        chkpending.Enabled = True
        grdtrans7.ReadOnly = False
        grdtrans7.Columns(1).ReadOnly = True
        grdtrans7.Columns(2).ReadOnly = True
        grdtrans7.Columns(3).ReadOnly = True
        grdtrans7.Columns(13).ReadOnly = True
        grdtrans7.Columns(14).ReadOnly = True
    End Sub

    Private Sub grdstep7_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdstep7.SelectionChanged
        
    End Sub

    Private Sub btnrefstep7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrefstep7.Click
        tripstep7()
    End Sub

    Private Sub btnimgadd7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgadd7.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" And login.neym <> "Encoder" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum7.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum7.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum7.Text, "step7")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 7 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgadd7.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofdstp7.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox7.Image = Nothing
                    Dim bmp As New Bitmap(ofdstp7.FileName)
                    imgbox7.Image = bmp
                    '/imgbox7.Image = LoadImage(ofdstp7.FileName)
                    cmbimg7.Text = ofdstp7.SafeFileName.ToString.Replace("'", "")
                    cmbimg7.Enabled = True
                    cmbimg7.Focus()

                    lblCompressionLevel.Text = ""

                    ' Display the file's size.
                    Dim file_info As New FileInfo(ofdstp7.FileName)
                    lblOriginalSize.Text = FormatBytes(file_info.Length)
                    If Microsoft.VisualBasic.Right(ofdstp7.FileName.ToString, 3) = "png" Then
                        lblDesiredSize.Text = FormatBytes(file_info.Length * 0.3)
                    Else
                        lblDesiredSize.Text = "1.10 MB" 'FormatBytes(file_info.Length * 0.4)
                    End If
                    lblCompressedSize.Text = ""
                    lblCompressionLevel.Text = ""

                    Me.Cursor = Cursors.Default
                    imgpanel7.Enabled = False
                    '/enabletab4only()
                    imgcanceltrue7()
                    btnimgadd7.Enabled = True
                    btnimgadd7.Text = "Add"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(cmbimg7.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg7.Focus()
                    Exit Sub
                End If

                If cmbimg7.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photoname.", MsgBoxStyle.Exclamation, "")
                    cmbimg7.Text = ""
                    cmbimg7.Focus()
                    Exit Sub
                End If

                Dim origsize As String = lblOriginalSize.Text
                If Val(origsize.Substring(0, origsize.Length - 2)) > 1 And Microsoft.VisualBasic.Right(origsize, 2) = "MB" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Image exceeds the maximum file size 1MB." & vbCrLf & "Compressing image. Please wait.", MsgBoxStyle.Information)

                    Button3.PerformClick()
                    pgbar7.Visible = True

                    If BackgroundWorker1.IsBusy = False Then
                        BackgroundWorker1.RunWorkerAsync()
                    End If

                    'COMPRESS IMAGE THEN REPLACE IMGBOX7.IMAGE NG COMPRESSED NA IMAGE
                    imgbox7.Image = compressimage(imgbox7.Image, Trim(cmbimg7.Text))
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.WaitCursor
                'insert photo in tblimg
                Dim ms As New MemoryStream()
                'search image name if existing
                conn.Open()
                '/connect()
                cmd = New SqlCommand("Select * from tbldispatchstp7 where tripnum='" & lbltripnum7.Text & "' and name='" & Trim(cmbimg7.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg7.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg7.Focus()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar7.Value = 0
                    pgbar7.Visible = False
                    Exit Sub
                Else
                    'save record in database
                    conn.Close()
                    conn.Open()
                    '/connect()
                    cmd = New SqlCommand("Insert into tbldispatchstp7 values(@tripnum,@name,@img,@status,GetDate(),@createdby)", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltripnum7.Text))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(cmbimg7.Text)))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                    imgbox7.Image.Save(ms, Imaging.ImageFormat.Jpeg)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    '/cmd.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                    cmd.ExecuteNonQuery()
                    conn.Close()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar7.Value = 0
                    pgbar7.Visible = False

                    MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    pgbar7.Value = 0
                    imgbox7.Image = Nothing
                    imgbox7.BackColor = Color.Empty
                    imgbox7.Invalidate()
                    ms.Close()
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.Default
                btnimgadd7.Text = "Add Photo"
                imgcancelfalse7()
                imgpanel7.Enabled = True
                '/enableall()
                btnimgrefresh7.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub imgcanceltrue7()
        btnimgadd7.Enabled = False
        btnimgrename7.Enabled = False
        btnimgremove7.Enabled = False
        btnimgcancel7.Enabled = True
        btnimgdl7.Enabled = False
        btnimgfull7.Enabled = True
        btnimgrefresh7.Enabled = False
    End Sub

    Public Sub imgcancelfalse7()
        cmbimg7.Text = ""
        lblimgdate7.Text = ""
        lblimgname7.Text = ""
        btnimgadd7.Text = "Add Photo"
        btnimgrename7.Text = "Rename"
        btnimgadd7.Enabled = True
        btnimgrename7.Enabled = True
        btnimgremove7.Enabled = True
        btnimgcancel7.Enabled = False
        btnimgdl7.Enabled = True
        btnimgfull7.Enabled = True
        btnimgrefresh7.Enabled = True
        btnexempt7.Enabled = True
        link2to7.Enabled = True
        btnconfirm7.Enabled = True
        chkpending.Enabled = True
    End Sub

    Private Sub btnimgrefresh7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrefresh7.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meronstp7 = False
            imgpanel7.Visible = False
            imgpanel7.Controls.Clear()
            imgpanel7.Visible = True

            Dim ctr As Integer = 0
            sql = "Select * from tbldispatchstp7 where tripnum='" & lbltripnum7.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                meronstp7 = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                picstp7 = New PictureBox
                picstp7.Image = Image.FromStream(ms)
                ms.Dispose()
                picstp7.SizeMode = PictureBoxSizeMode.Zoom
                picstp7.SetBounds(wid, y, 104, 100)
                'picstp7.BackColor = Color.AliceBlue
                picstp7.Tag = dr("stp7imgid")
                picstp7.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler picstp7.Click, AddressOf convertPic7
                imgpanel7.Controls.Add(picstp7)
                imgpanel7.Controls.Add(lbl)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            imgbox7.Image = Nothing
            cmbimg7.Text = ""
            lblimgid7.Text = ""
            lblimgdate7.Text = ""
            lblimgname7.Text = ""

            Me.Cursor = Cursors.Default

            If meronstp7 = False Then
                btnimgrename7.Enabled = False
                btnimgremove7.Enabled = False
                btnimgcancel7.Enabled = False
                btnimgdl7.Enabled = False
                btnimgfull7.Enabled = False
                btnconfirm7.Enabled = False
            Else
                imgcancelfalse7()
            End If

            If grdstep7.Rows.Count = 0 Then
                grp7.Enabled = False
            Else
                grp7.Enabled = True
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Sub convertPic7(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            picstp7 = CType(sender, PictureBox)
            imgbox7.Image = picstp7.Image
            lblimgid7.Text = picstp7.Tag

            sql = "Select name,datecreated,createdby from tbldispatchstp7 where stp7imgid='" & lblimgid7.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbimg7.Text = dr("name")
                If IsDBNull(dr("datecreated")) = False Then
                    lblimgdate7.Text = Format(dr("datecreated"), "MM/dd/yyyy h:mm tt")
                Else
                    lblimgdate7.Text = ""
                End If
                lblimgname7.Text = dr("createdby").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgfull7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgfull7.Click
        If lblimgid7.Text <> "" Or imgbox7.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox7.Image
            viewimage.lblimgname.Text = cmbimg7.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub btnconfirm7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnconfirm7.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" And login.neym <> "Encoder" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum7.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum7.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum7.Text, "step7")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 7 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL7 HAS CONTROLS
            If imgpanel7.Controls.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            'check if may word na cancel
            For Each row As DataGridViewRow In grdtrans7.Rows
                Dim trn As String = grdtrans7.Rows(row.Index).Cells(1).Value
                Dim arn As String = Trim(grdtrans7.Rows(row.Index).Cells(6).Value.ToString)
                Dim rdr As String = Trim(grdtrans7.Rows(row.Index).Cells(7).Value.ToString)
                Dim drn As String = Trim(grdtrans7.Rows(row.Index).Cells(8).Value.ToString)
                Dim dnn As String = Trim(grdtrans7.Rows(row.Index).Cells(9).Value.ToString)
                Dim itr As String = Trim(grdtrans7.Rows(row.Index).Cells(10).Value.ToString)
                Dim it As String = Trim(grdtrans7.Rows(row.Index).Cells(11).Value.ToString)
                Dim grpo As String = Trim(grdtrans7.Rows(row.Index).Cells(12).Value.ToString)
                Dim notes As String = Trim(grdtrans7.Rows(row.Index).Cells(14).Value.ToString)
                Dim checkCell4 As DataGridViewCheckBoxCell = CType(grdtrans7.Rows(row.Index).Cells(4), DataGridViewCheckBoxCell)
                Dim checkCell5 As DataGridViewCheckBoxCell = CType(grdtrans7.Rows(row.Index).Cells(5), DataGridViewCheckBoxCell)

                If checkCell4.Value = False And checkCell5.Value = False And (arn.ToLower.Contains("cancel") Or rdr.ToLower.Contains("cancel") Or drn.ToLower.Contains("cancel") Or dnn.ToLower.Contains("cancel") Or itr.ToLower.Contains("cancel")) Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Transaction# " & trn & "." & " Tick the checkbox if For Reschedule / For AR Credit.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If

                If checkCell4.Value = False And checkCell5.Value = False And (arn = "" Or rdr = "" Or drn = "" Or dnn = "" Or itr = "" Or it = "" Or grpo = "") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Incomplete input for transaction# " & trn & ".", MsgBoxStyle.Information, "")
                    Exit Sub
                End If

                If checkCell4.Value = True And Trim(txtrems7.Text) = "" And lblpick7.Visible = False Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input remarks why transaction# " & trn & " is for Reschedule.", MsgBoxStyle.Information, "")
                    Exit Sub
                ElseIf checkCell5.Value = True And Trim(txtrems7.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input remarks why transaction# " & trn & " is for AR Credit Memo.", MsgBoxStyle.Information, "")
                    Exit Sub
                End If
            Next

            If triplink7 = False Then
                '/MsgBox("Click the View Trip Info link first to ensure that all the remarks and comments from other steps are checked.", MsgBoxStyle.Exclamation, "")
                '/Exit Sub
                viewtripinfo.lblid.Text = lbltripnum7.Tag
                viewtripinfo.lbltripnum.Text = lbltripnum7.Text
                viewtripinfo.Text = "Trip Information (" & lbltripnum7.Text & ")"
                viewtripinfo.ShowDialog()
                triplink7 = True
            End If

            wctab = "tab7"

            sign.Width = 733
            sign.lblplate.Text = lblplate7.Text
            If lbltype7.Text = "TRUCKING TRUCK" Then
                sign.GroupBox1.Text = "Pier Checker ()"
                sign.GroupBox4.Text = "Helper ()"
            Else
                sign.GroupBox1.Text = "Driver (" & grdstep7.Rows(grdstep7.CurrentRow.Index).Cells(3).Value & ")"
                sign.GroupBox4.Text = "Helper (" & grdstep7.Rows(grdstep7.CurrentRow.Index).Cells(4).Value & ")"
            End If

            If login.whse = "JP-Store" Then
                pass = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()

                If pass = True Then
                    Me.Cursor = Cursors.Default
                    ExecuteConfirmJPStore(strconn)
                    zero7()
                    grdtrans7.Rows.Clear()
                    tripstep7()
                    cnf7 = True
                End If

            Else
                sign.GroupBox2.Text = login.neym & " (" & login.fullneym & ")"
                sign.lbltrip.Text = lbltripnum7.Text
                sign.lblrems.Text = txtrems7.Text 'para dun ndin isang save nlng
                sign.yescnf = False
                sign.ShowDialog()

                If sign.yescnf = True Then
                    zero7()
                    grdtrans7.Rows.Clear()
                    tripstep7()
                    cnf7 = True
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteConfirmJPStore(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                'step 7
                For Each row As DataGridViewRow In grdtrans7.Rows
                    Dim trn As String = grdtrans7.Rows(row.Index).Cells(1).Value
                    Dim arn As String = Trim(grdtrans7.Rows(row.Index).Cells(6).Value.ToString)
                    Dim rdr As String = Trim(grdtrans7.Rows(row.Index).Cells(7).Value.ToString)
                    Dim drn As String = Trim(grdtrans7.Rows(row.Index).Cells(8).Value.ToString)
                    Dim dnn As String = Trim(grdtrans7.Rows(row.Index).Cells(9).Value.ToString)
                    Dim itr As String = Trim(grdtrans7.Rows(row.Index).Cells(10).Value.ToString)
                    Dim it As String = Trim(grdtrans7.Rows(row.Index).Cells(11).Value.ToString)
                    Dim grpo As String = Trim(grdtrans7.Rows(row.Index).Cells(12).Value.ToString)
                    Dim notes As String = Trim(grdtrans7.Rows(row.Index).Cells(14).Value.ToString)

                    sql = "Update tblortrans set arnum='" & arn & "', rdrnum='" & rdr & "', drnum='" & drn & "', dnnum='" & dnn & "', itrnum='" & itr & "', itnum='" & it & "', grponum='" & grpo & "', notes='" & notes & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where transnum='" & trn & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                Next


                'step7 'update withpending = false
                sql = "Update tbldispatchsum set withpending='0', step7='1', namestp7='" & login.cashier & "', datestp7=GetDate(), mneymstp7='" & login.cashier & "', mdeytstp7=GetDate(), remstp7='" & Trim(txtrems7.Text) & "' where tripnum='" & lbltripnum7.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("PROCCED TO NEXT STEP.", MsgBoxStyle.Information, "")

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.ToString, MsgBoxStyle.Exclamation, "")
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.ToString & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btnimgrename7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrename7.Click
        If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" And login.neym <> "Encoder" Then
            Me.Cursor = Cursors.Default
            MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
            Exit Sub
        End If

        cancelledtrip = False
        cancelledtrip = checkcancel(lbltripnum7.Text)
        If cancelledtrip = True Then
            Me.Cursor = Cursors.Default
            MsgBox("Trip# " & lbltripnum7.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
            Exit Sub
        End If

        completedstep = False
        completedstep = checkcompleted(lbltripnum7.Text, "step7")
        If completedstep = True Then
            Me.Cursor = Cursors.Default
            MsgBox("Step 7 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
            Exit Sub
        End If

        If btnimgrename7.Text = "Rename" Then
            If Trim(cmbimg7.Text) <> "" And imgbox7.Image IsNot Nothing Then
                Dim tempname As String = Trim(cmbimg7.Text)
                If tempname.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot rename photo.", MsgBoxStyle.Exclamation, "")
                    cmbimg7.Focus()
                    Exit Sub
                End If
                cmbimg7.Enabled = True
                cmbimg7.Focus()
            ElseIf Trim(cmbimg7.Text) = "" And imgbox7.Image IsNot Nothing Then
                Me.Cursor = Cursors.Default
                MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                cmbimg7.Focus()
                Exit Sub
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                cmbimg7.Focus()
                Exit Sub
            End If

            imgpanel7.Enabled = False
            imgcanceltrue7()
            btnimgrename7.Enabled = True
            btnimgrename7.Text = "Save"
        Else
            'search image name if existing
            connect()
            cmd = New SqlCommand("Select * from tbldispatchstp7 where tripnum='" & lbltripnum7.Text & "' and name='" & Trim(cmbimg7.Text) & "'", conn)
            dr = cmd.ExecuteReader()
            If dr.Read = True Then
                Me.Cursor = Cursors.Default
                MessageBox.Show("Image " & Trim(cmbimg7.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                cmbimg7.Focus()
                Exit Sub
            Else
                Me.Cursor = Cursors.Default

                If cmbimg7.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photo name.", MsgBoxStyle.Exclamation, "")
                    cmbimg7.Text = ""
                    cmbimg7.Focus()
                    Exit Sub
                End If

                'irename.. update yung name lng where imgid = lblimgid.text
                sql = "Update tbldispatchstp7 set name='" & Trim(cmbimg7.Text) & "' where stp7imgid='" & lblimgid7.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                btnimgrename7.Text = "Rename"
                imgcancelfalse7()
                imgpanel7.Enabled = True
                btnimgrefresh7.PerformClick()
                Me.Cursor = Cursors.Default
            End If
        End If
    End Sub

    Private Sub btnimgremove7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgremove7.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" And login.neym <> "Encoder" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum7.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum7.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum7.Text, "step7")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 7 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(cmbimg7.Text) <> "" And imgbox7.Image IsNot Nothing Then
                Me.Cursor = Cursors.Default

                If cmbimg7.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot delete signature", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2)
                If a = vbYes Then
                    'delete image where imgid=lblimgid.text
                    sql = "Delete from tbldispatchstp7 where stp7imgid='" & lblimgid7.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully remove.", MsgBoxStyle.Information, "")

                    imgcancelfalse7()
                    imgpanel7.Enabled = True
                    btnimgrefresh7.PerformClick()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                cmbimg7.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgcancel7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel7.Click
        imgpanel7.Enabled = True
        imgbox7.Image = Nothing
        cmbimg7.Text = ""
        lblimgid7.Text = ""
        imgcancelfalse7()

        If meronstp7 = False Then
            btnimgrename7.Enabled = False
            btnimgremove7.Enabled = False
            btnimgcancel7.Enabled = False
            btnimgdl7.Enabled = False
            btnimgfull7.Enabled = False
        Else
            imgcancelfalse7()
        End If
    End Sub

    Private Sub btnexempt7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexempt7.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" And login.neym <> "Encoder" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum7.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum7.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum7.Text, "step7")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 7 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL7 HAS CONTROLS
            If imgpanel7.Controls.Count = 0 Then
                'MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
                'Exit Sub
            End If

            pass = False
            confirmsave.GroupBox1.Text = login.neym
            confirmsave.ShowDialog()

            If pass = True Then
                Me.Cursor = Cursors.Default
                ExecuteSaveStep7(strconn)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteSaveStep7(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            transaction = connection.BeginTransaction("SampleTransaction")

            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                For Each row As DataGridViewRow In grdtrans7.Rows
                    Dim trn As String = grdtrans7.Rows(row.Index).Cells(1).Value
                    Dim arn As String = Trim(grdtrans7.Rows(row.Index).Cells(6).Value.ToString)
                    Dim rdr As String = Trim(grdtrans7.Rows(row.Index).Cells(7).Value.ToString)
                    Dim drn As String = Trim(grdtrans7.Rows(row.Index).Cells(8).Value.ToString)
                    Dim dnn As String = Trim(grdtrans7.Rows(row.Index).Cells(9).Value.ToString)
                    Dim itr As String = Trim(grdtrans7.Rows(row.Index).Cells(10).Value.ToString)
                    Dim it As String = Trim(grdtrans7.Rows(row.Index).Cells(11).Value.ToString)
                    Dim grpo As String = Trim(grdtrans7.Rows(row.Index).Cells(12).Value.ToString)
                    Dim notes As String = Trim(grdtrans7.Rows(row.Index).Cells(14).Value.ToString)

                    sql = "Update tblortrans set arnum='" & arn & "', rdrnum='" & rdr & "', drnum='" & drn & "', dnnum='" & dnn & "', itrnum='" & itr & "', itnum='" & it & "', grponum='" & grpo & "', notes='" & notes & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where transnum='" & trn & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                Next

                'save remarks
                sql = "Update tbldispatchsum set sneymstp7='" & login.cashier & "', sdeytstp7=GetDate(), remstp7='" & txtrems7.Text & "' where tripnum='" & lbltripnum7.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox(lblplate7.Text & " STEP 7 Saved as draft.", MsgBoxStyle.Information, "")

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub cmbimg7_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbimg7.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtrems7_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems7.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Public Sub tripstep8()
        Try
            Me.Cursor = Cursors.WaitCursor

            grp8.Enabled = True
            grdstep8.Rows.Clear()

            'sql = "Select * from tbltripsum where tbltripsum.status='1'"
            sql = "SELECT tbltripsum.tripsumid,tbltripsum.tripnum,tbltripsum.platenum,tbltripsum.driver,tbltripsum.helper,tbltripsum.datepick,tbldispatchsum.whsename9,tbldispatchsum.timedep"
            sql = sql & " FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum"

            If login.neym = "Motorpool Inspector" Then
                sql = sql & " where tbldispatchsum.arrwhse='Calamba' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' and tbldispatchsum.step1='1' and tbldispatchsum.step2='1' and tbldispatchsum.step3='1' and tbldispatchsum.step4='1' and tbldispatchsum.step5='1' and tbldispatchsum.step6='1' and tbldispatchsum.step8='0' order by datepick"
            Else
                sql = sql & " where tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' and tbldispatchsum.step1='1' and tbldispatchsum.step2='1' and tbldispatchsum.step3='1' and tbldispatchsum.step4='1' and tbldispatchsum.step5='1' and tbldispatchsum.step6='1' and tbldispatchsum.step8='0' order by datepick"
            End If

            grdsql = sql
            whatstep = 8

            bgw = New BackgroundWorker()

            AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
            AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
            AddHandler bgw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not bgw.IsBusy Then
                lblload8.Visible = True
                gstep8.Enabled = False
                bgw.WorkerReportsProgress = True
                bgw.WorkerSupportsCancellation = True
                bgw.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub zero8()
        lblplate8.Text = ""
        lbltype8.Text = ""
        lblmake8.Text = ""
        lbltripnum8.Text = ""
        lblconfirm8.Text = 0
        txtrems8.Text = ""
        lbltaxi.Text = ""

        txtdestin8.Text = "Destination:"
        txtodoend.Text = 0
        txtdieselend.Text = 0
        txtodobeg.Text = 0
        txttotaldiesel.Text = 0
        btnstartpost.Text = "TIME START POST-INSPECTION"

        txtinch8.Text = ""
        Panelinch8.Visible = False

        imgpanel8.Visible = False
        imgpanel8.Controls.Clear()
        imgpanel8.Visible = True
    End Sub

    Private Sub grdstep8_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grdstep8.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdstep8.Rows(e.RowIndex)
            '<== But this is the name assigned to it in the properties of the control
            'If CDate(Format(dgvRow.Cells(1).Value, "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
            If dgvRow.Cells(5).Value <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
                dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
            End If
        End If
    End Sub

    Private Sub grdstep8_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep8.CellClick
        Try
            If Panelinch8.Visible = True Then
                MsgBox("Close the converter first.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            zero8()
            Me.Cursor = Cursors.WaitCursor

            lbltripnum8.Tag = grdstep8.Rows(grdstep8.CurrentRow.Index).Cells(0).Value
            lbltripnum8.Text = grdstep8.Rows(grdstep8.CurrentRow.Index).Cells(1).Value
            lblplate8.Text = grdstep8.Rows(grdstep8.CurrentRow.Index).Cells(2).Value

            SelectStep8(strconn)

            btnimgrefresh8.PerformClick()

            If grdstep8.Rows.Count <> 0 Then
                grp8.Text = lbltripnum8.Text & "     -     " & grdstep8.Rows(grdstep8.CurrentRow.Index).Cells(5).Value
            Else
                grp8.Text = "Photos"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub SelectStep8(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Select vtype,makename from tblgeneral where platenum='" & lblplate8.Text & "' or vplate='" & lblplate8.Text & "' or csticker='" & lblplate8.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    lbltype8.Text = dr("vtype")
                    lblmake8.Text = dr("makename")
                End If
                dr.Dispose()

                txtodobeg.Text = 0
                txttotaldiesel.Text = 0
                sql = "Select odoactual,dieselactual,podiesel,addpo from tbltripsum where tripnum='" & lbltripnum8.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    txtodobeg.Text = dr("odoactual")
                    txttotaldiesel.Text = dr("dieselactual") + dr("podiesel") + dr("addpo")
                End If
                dr.Dispose()

                If lbltripnum8.Text <> "" Then
                    Dim origin As String = "", taxi As Integer = 0
                    sql = "SELECT origin,taxi,odoend,dieselend,postaddpo from tbltripsum where tripnum='" & lbltripnum8.Text & "'"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    If dr.Read Then
                        origin = dr("origin")
                        taxi = dr("taxi")

                        'dito yung view save details
                        txtodoend.Text = dr("odoend")
                        txtdieselend.Text = dr("dieselend")
                        txtpostpo.Text = dr("postaddpo")
                    End If
                    dr.Dispose()

                    cmbtrans8.Items.Clear()
                    sql = "SELECT transnum from tbltripitems where tripnum='" & lbltripnum8.Text & "' and status<>'0' and status<>'3'"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    While dr.Read
                        cmbtrans8.Items.Add(dr("transnum"))
                    End While
                    dr.Dispose()

                    Dim temp As String = "", temptype As String = ""
                    For i = 0 To cmbtrans8.Items.Count - 1
                        cmbtrans8.SelectedIndex = i
                        sql = "Select customer,transtype from tblortrans where transnum='" & cmbtrans8.SelectedItem & "'"
                        command.CommandText = sql
                        dr = command.ExecuteReader
                        While dr.Read
                            temp = temp & (dr("customer")) & " / "

                            If dr("transtype").ToString.Contains("PICKUP") Then
                                Dim inSql As String = dr("transtype").ToString
                                Dim lastPart As String
                                Dim fromStart As Integer
                                Dim firstpart As String

                                fromStart = inSql.IndexOf("FRM ") + 4

                                firstpart = inSql.Substring(0, fromStart - 4)
                                temptype = Trim(firstpart)

                                lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

                                temptype = lastPart & " "

                            End If
                        End While
                        dr.Dispose()
                    Next

                    If taxi = 1 Then
                        temp = "Taxi"
                        lbltaxi.Text = "Taxi"
                        txtdestin8.Text = "Destination: " & origin & " - " & temp
                    Else
                        lbltaxi.Text = ""
                        If temptype = "" Then
                            txtdestin8.Text = "Destination: " & origin & " - " & temp
                        Else
                            txtdestin8.Text = "Destination: " & "p/up " & temptype & "/ " & temp
                        End If
                    End If
                End If

                btnstartpost.Text = "TIME START POST-INSPECTION"
                sql = "Select step8,startpost,remstp8 from tbldispatchsum where tripnum='" & lbltripnum8.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    If dr("step8") = 1 Then
                        lblconfirm8.Text = 1
                    End If

                    If dr("startpost").ToString <> "" Then
                        Dim starttime As Date
                        Dim timeCheck As Boolean
                        timeCheck = IsDate(dr("startpost").ToString)
                        If timeCheck = True Then
                            'MsgBox(Trim(txttime.Text) & timeCheck)
                            starttime = CDate(dr("startpost").ToString)
                            btnstartpost.Text = "TIME START POST-INSPECTION: " & Format(starttime, "HH:mm")
                            txtrems8.Text = dr("remstp8").ToString
                            startpostfalse()
                        End If
                    Else
                        btnstartpost.Enabled = True
                        btninch8.Enabled = False
                        txtodoend.Enabled = False
                        txtdieselend.Enabled = False
                        txtpostpo.Enabled = False
                        btnimgadd8.Enabled = False
                        txtrems8.Enabled = False
                        txtrems8.Text = ""
                        tripinfo8.Enabled = False
                        '/btnrepair8.Enabled = False
                        btnconfirm8.Enabled = False
                        btnexempt8.Enabled = False
                    End If
                End If
                dr.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                triplink8 = False

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub startpostfalse()
        btnstartpost.Enabled = False
        If lblmake8.Text = "Service" Then
            txtdieselend.Text = 0
            txtdieselend.Enabled = False
            txtodoend.Text = 0
            btninch8.Enabled = False
            txtodoend.Enabled = False
        Else
            txtdieselend.Enabled = True
            btninch8.Enabled = True
            txtodoend.Enabled = True
        End If
        txtpostpo.Enabled = True
        btnimgadd8.Enabled = True
        txtrems8.Enabled = True
        tripinfo8.Enabled = True
        '/btnrepair8.Enabled = True
        btnconfirm8.Enabled = True
        btnexempt8.Enabled = True
    End Sub

    Private Sub grdstep8_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep8.CellContentClick
        
    End Sub

    Private Sub grdstep8_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdstep8.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Up Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Down Then
            e.Handled = True
        End If
    End Sub

    Private Sub grdstep8_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdstep8.SelectionChanged
        
    End Sub

    Private Sub btnrefstep8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrefstep8.Click
        tripstep8()
    End Sub

    Private Sub btnimgadd8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgadd8.Click
        Try
            If login.neym <> "Motorpool Inspector" And login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum8.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum8.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum8.Text, "step8")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 8 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgadd8.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofdstp8.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox8.Image = Nothing
                    Dim bmp As New Bitmap(ofdstp8.FileName)
                    imgbox8.Image = bmp
                    '/imgbox8.Image = LoadImage(ofdstp8.FileName)
                    cmbimg8.Text = ofdstp8.SafeFileName.ToString.Replace("'", "")
                    cmbimg8.Enabled = True
                    cmbimg8.Focus()

                    lblCompressionLevel.Text = ""

                    ' Display the file's size.
                    Dim file_info As New FileInfo(ofdstp8.FileName)
                    lblOriginalSize.Text = FormatBytes(file_info.Length)
                    If Microsoft.VisualBasic.Right(ofdstp8.FileName.ToString, 3) = "png" Then
                        lblDesiredSize.Text = FormatBytes(file_info.Length * 0.3)
                    Else
                        lblDesiredSize.Text = "1.10 MB" 'FormatBytes(file_info.Length * 0.4)
                    End If
                    lblCompressedSize.Text = ""
                    lblCompressionLevel.Text = ""

                    Me.Cursor = Cursors.Default
                    imgpanel8.Enabled = False
                    '/enabletab4only()
                    imgcanceltrue8()
                    btnimgadd8.Enabled = True
                    btnimgadd8.Text = "Add"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(cmbimg8.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg8.Focus()
                    Exit Sub
                End If

                If cmbimg8.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photoname.", MsgBoxStyle.Exclamation, "")
                    cmbimg8.Text = ""
                    cmbimg8.Focus()
                    Exit Sub
                End If

                Dim origsize As String = lblOriginalSize.Text
                If Val(origsize.Substring(0, origsize.Length - 2)) > 1 And Microsoft.VisualBasic.Right(origsize, 2) = "MB" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Image exceeds the maximum file size 1MB." & vbCrLf & "Compressing image. Please wait.", MsgBoxStyle.Information)

                    Button3.PerformClick()
                    pgbar8.Visible = True

                    If BackgroundWorker1.IsBusy = False Then
                        BackgroundWorker1.RunWorkerAsync()
                    End If

                    'COMPRESS IMAGE THEN REPLACE IMGBOX8.IMAGE NG COMPRESSED NA IMAGE
                    imgbox8.Image = compressimage(imgbox8.Image, Trim(cmbimg8.Text))
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.WaitCursor
                'insert photo in tblimg
                Dim ms As New MemoryStream()
                'search image name if existing
                conn.Open()
                '/connect()
                cmd = New SqlCommand("Select * from tbldispatchstp8 where tripnum='" & lbltripnum8.Text & "' and name='" & Trim(cmbimg8.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg8.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg8.Focus()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar8.Value = 0
                    pgbar8.Visible = False
                    Exit Sub
                Else
                    'save record in database
                    conn.Close()
                    conn.Open()
                    '/connect()
                    cmd = New SqlCommand("Insert into tbldispatchstp8 values(@tripnum,@name,@img,@status,GetDate(),@createdby)", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltripnum8.Text))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(cmbimg8.Text)))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                    imgbox8.Image.Save(ms, Imaging.ImageFormat.Jpeg)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    '/cmd.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                    cmd.ExecuteNonQuery()
                    conn.Close()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar8.Value = 0
                    pgbar8.Visible = False

                    MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    pgbar8.Value = 0
                    imgbox8.Image = Nothing
                    imgbox8.BackColor = Color.Empty
                    imgbox8.Invalidate()
                    ms.Close()
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.Default
                btnimgadd8.Text = "Add Photo"
                imgcancelfalse8()
                imgpanel8.Enabled = True
                '/enableall()
                btnimgrefresh8.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub imgcanceltrue8()
        btnimgadd8.Enabled = False
        btnimgrename8.Enabled = False
        btnimgremove8.Enabled = False
        btnimgcancel8.Enabled = True
        btnimgdl8.Enabled = False
        btnimgfull8.Enabled = True
        btnimgrefresh8.Enabled = False
    End Sub

    Public Sub imgcancelfalse8()
        cmbimg8.Text = ""
        lblimgdate8.Text = ""
        lblimgname8.Text = ""
        btnimgadd8.Text = "Add Photo"
        btnimgrename8.Text = "Rename"
        btnimgadd8.Enabled = True
        btnimgrename8.Enabled = True
        btnimgremove8.Enabled = True
        btnimgcancel8.Enabled = False
        btnimgdl8.Enabled = True
        btnimgfull8.Enabled = True
        btnimgrefresh8.Enabled = True
        '/btnrepair8.Enabled = True
        btnexempt8.Enabled = True
        btnconfirm8.Enabled = True
    End Sub

    Private Sub btnimgrefresh8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrefresh8.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meronstp8 = False
            imgpanel8.Visible = False
            imgpanel8.Controls.Clear()
            imgpanel8.Visible = True

            Dim ctr As Integer = 0
            sql = "Select * from tbldispatchstp8 where tripnum='" & lbltripnum8.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                meronstp8 = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                picstp8 = New PictureBox
                picstp8.Image = Image.FromStream(ms)
                ms.Dispose()
                picstp8.SizeMode = PictureBoxSizeMode.Zoom
                picstp8.SetBounds(wid, y, 104, 100)
                'picstp8.BackColor = Color.AliceBlue
                picstp8.Tag = dr("stp8imgid")
                picstp8.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler picstp8.Click, AddressOf convertPic8
                imgpanel8.Controls.Add(picstp8)
                imgpanel8.Controls.Add(lbl)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            imgbox8.Image = Nothing
            cmbimg8.Text = ""
            lblimgid8.Text = ""
            lblimgdate8.Text = ""
            lblimgname8.Text = ""

            Me.Cursor = Cursors.Default

            If meronstp8 = False Then
                btnimgrename8.Enabled = False
                btnimgremove8.Enabled = False
                btnimgcancel8.Enabled = False
                btnimgdl8.Enabled = False
                btnimgfull8.Enabled = False
            Else
                imgcancelfalse8()
            End If

            If grdstep8.Rows.Count = 0 Then
                grp8.Enabled = False
            Else
                grp8.Enabled = True
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Sub convertPic8(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            picstp8 = CType(sender, PictureBox)
            imgbox8.Image = picstp8.Image
            lblimgid8.Text = picstp8.Tag

            sql = "Select name,datecreated,createdby from tbldispatchstp8 where stp8imgid='" & lblimgid8.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbimg8.Text = dr("name")
                If IsDBNull(dr("datecreated")) = False Then
                    lblimgdate8.Text = Format(dr("datecreated"), "MM/dd/yyyy h:mm tt")
                Else
                    lblimgdate8.Text = ""
                End If
                lblimgname8.Text = dr("createdby").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgfull8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgfull8.Click
        If lblimgid8.Text <> "" Or imgbox8.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox8.Image
            viewimage.lblimgname.Text = cmbimg8.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnconfirm8.Click
        Try
            If login.neym <> "Motorpool Inspector" And login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum8.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum8.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum8.Text, "step8")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 8 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL2 HAS CONTROLS
            If imgpanel8.Controls.Count = 0 And login.whse <> "Cebu" And login.whse <> "Davao" And login.whse <> "Bacolod" And login.whse <> "Tacloban" Then
                Me.Cursor = Cursors.Default
                If Val(txtpostpo.Text) <> 0 Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Attach diesel receipt for additional diesel.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
                MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Val(txtpostpo.Text) <> 0 And Trim(txtrems8.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Add reason why you need to add diesel.", MsgBoxStyle.Information, "")
                txtrems8.Focus()
                Exit Sub
            End If

            If (Val(txtodoend.Text) = 0 Or Val(txtdieselend.Text) = 0) And lblmake8.Text = "Truck" Then
                Me.Cursor = Cursors.Default
                MsgBox("Incomplete input.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Val(txtodobeg.Text) >= Val(txtodoend.Text) And Trim(txtrems8.Text) = "" And lblmake8.Text = "Truck" Then
                Me.Cursor = Cursors.Default
                MsgBox("Ending Odometer is less than the Start Odometer. Add Remarks.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Val(txtdieselend.Text) >= Val(txttotaldiesel.Text) And Trim(txtrems8.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Ending Diesel is greater than its the total diesel plus additional diesel. Add Remarks.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If triplink8 = False Then
                '/MsgBox("Click the View Trip Info link first to ensure that all the remarks and comments from other steps are checked.", MsgBoxStyle.Exclamation, "")
                '/Exit Sub
                viewtripinfo.lblid.Text = lbltripnum8.Tag
                viewtripinfo.lbltripnum.Text = lbltripnum8.Text
                viewtripinfo.Text = "Trip Information (" & lbltripnum8.Text & ")"
                viewtripinfo.ShowDialog()
                triplink8 = True
            End If

            wctab = "tab81"

            'sign.Width = 733
            sign.Width = 373

            sign.lblplate.Text = lblplate8.Text
            sign.GroupBox1.Text = login.neym & " (" & login.fullneym & ")"
            'sign.GroupBox1.Text = "Driver (" & grdstep8.Rows(grdstep8.CurrentRow.Index).Cells(3).Value & ")"
            'sign.GroupBox4.Text = "Helper (" & grdstep8.Rows(grdstep8.CurrentRow.Index).Cells(4).Value & ")"
            'sign.GroupBox2.Text = login.neym & " (" & login.fullneym & ")"
            sign.lbltrip.Text = lbltripnum8.Text
            sign.lblrems.Text = txtrems8.Text 'para dun ndin isang save nlng

            sign.yescnf = False
            sign.ShowDialog()

            If sign.yescnf = True Then
                zero8()
                tripstep8()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnexempt8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexempt8.Click
        Try
            If login.neym <> "Motorpool Inspector" And login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum8.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum8.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum8.Text, "step8")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 8 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Val(txtodobeg.Text) >= Val(txtodoend.Text) And Trim(txtrems8.Text) = "" Then
                'MsgBox("Ending Odometer is less than the Start Odometer. Add Remarks.", MsgBoxStyle.Exclamation, "")
                'Exit Sub
            End If

            If Val(txtdieselend.Text) >= Val(txttotaldiesel.Text) And Trim(txtrems8.Text) = "" Then
                'MsgBox("Ending Diesel is greater than its the total diesel plus additional diesel. Add Remarks.", MsgBoxStyle.Exclamation, "")
                'Exit Sub
            End If

            pass = False
            confirmsave.GroupBox1.Text = login.neym
            confirmsave.ShowDialog()

            If pass = True Then
                Me.Cursor = Cursors.Default
                ExecuteSaveStep8(strconn)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteSaveStep8(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            transaction = connection.BeginTransaction("SampleTransaction")

            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Update tbltripsum set odoend='" & txtodoend.Text & "', dieselend='" & txtdieselend.Text & "', postaddpo='" & txtpostpo.Text & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where tripnum='" & lbltripnum8.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                'save remarks
                sql = "Update tbldispatchsum set sneymstp8='" & login.cashier & "', sdeytstp8=GetDate(), remstp8='" & txtrems8.Text & "' where tripnum='" & lbltripnum8.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox(lblplate8.Text & " STEP 8 Saved as draft.", MsgBoxStyle.Information, "")

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btnimgrename8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrename8.Click
        Try
            If login.neym <> "Motorpool Inspector" And login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum8.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum8.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum8.Text, "step8")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 8 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgrename8.Text = "Rename" Then
                If Trim(cmbimg8.Text) <> "" And imgbox8.Image IsNot Nothing Then
                    Dim tempname As String = Trim(cmbimg8.Text)
                    If tempname.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Cannot rename photo.", MsgBoxStyle.Exclamation, "")
                        cmbimg8.Focus()
                        Exit Sub
                    End If
                    cmbimg8.Enabled = True
                    cmbimg8.Focus()
                ElseIf Trim(cmbimg8.Text) = "" And imgbox8.Image IsNot Nothing Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg8.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    cmbimg8.Focus()
                    Exit Sub
                End If

                imgpanel8.Enabled = False
                imgcanceltrue8()
                btnimgrename8.Enabled = True
                btnimgrename8.Text = "Save"
            Else
                'search image name if existing
                connect()
                cmd = New SqlCommand("Select * from tbldispatchstp8 where tripnum='" & lbltripnum8.Text & "' and name='" & Trim(cmbimg8.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg8.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg8.Focus()
                    Exit Sub
                Else
                    If cmbimg8.Text.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Invalid photo name.", MsgBoxStyle.Exclamation, "")
                        cmbimg8.Text = ""
                        cmbimg8.Focus()
                        Exit Sub
                    End If

                    'irename.. update yung name lng where imgid = lblimgid.text
                    sql = "Update tbldispatchstp8 set name='" & Trim(cmbimg8.Text) & "' where stp8imgid='" & lblimgid8.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    Me.Cursor = Cursors.Default
                    MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                    btnimgrename8.Text = "Rename"
                    imgcancelfalse8()
                    imgpanel8.Enabled = True
                    btnimgrefresh8.PerformClick()
                    Me.Cursor = Cursors.Default
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgremove8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgremove8.Click
        Try
            If login.neym <> "Motorpool Inspector" And login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum8.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum8.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum8.Text, "step8")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 8 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(cmbimg8.Text) <> "" And imgbox8.Image IsNot Nothing Then
                If cmbimg8.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot delete signature", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2)
                If a = vbYes Then
                    'delete image where imgid=lblimgid.text
                    sql = "Delete from tbldispatchstp8 where stp8imgid='" & lblimgid8.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    Me.Cursor = Cursors.Default
                    MsgBox("Successfully remove.", MsgBoxStyle.Information, "")

                    imgcancelfalse8()
                    imgpanel8.Enabled = True
                    btnimgrefresh8.PerformClick()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                cmbimg8.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgcancel8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel8.Click
        imgpanel8.Enabled = True
        imgbox8.Image = Nothing
        cmbimg8.Text = ""
        lblimgid8.Text = ""
        imgcancelfalse8()

        If meronstp8 = False Then
            btnimgrename8.Enabled = False
            btnimgremove8.Enabled = False
            btnimgcancel8.Enabled = False
            btnimgdl8.Enabled = False
            btnimgfull8.Enabled = False
        Else
            imgcancelfalse8()
        End If
    End Sub

    Private Sub btnrepair8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            If login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum8.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum8.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum8.Text, "step8")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 8 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'MsgBox("Input repair description in remarks.", MsgBoxStyle.Information, "")

            'CHECK IF IMGPANEL8 HAS CONTROLS
            If imgpanel8.Controls.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
            End If

            If Val(txtodoend.Text) = 0 Or Val(txtdieselend.Text) = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("Incomplete input.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Val(txtodobeg.Text) >= Val(txtodoend.Text) And Trim(txtrems8.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Ending Odometer is less than the Start Odometer. Add Remarks.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Val(txtdieselend.Text) >= Val(txttotaldiesel.Text) And Trim(txtrems8.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Ending Diesel is greater than its the total diesel plus additional diesel. Add Remarks.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Trim(txtrems8.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Input repair description in remarks.", MsgBoxStyle.Exclamation, "")
                txtrems9.Focus()
                Exit Sub
            End If

            wctab = "tab8"

            sign.Width = 733
            sign.GroupBox1.Text = "Driver (" & grdstep8.Rows(grdstep8.CurrentRow.Index).Cells(3).Value & ")"
            sign.GroupBox4.Text = "Helper (" & grdstep8.Rows(grdstep8.CurrentRow.Index).Cells(4).Value & ")"
            sign.GroupBox2.Text = login.neym & " (" & login.fullneym & ")"
            sign.lbltrip.Text = lbltripnum8.Text
            sign.lblrems.Text = txtrems8.Text 'para dun ndin isang save nlng

            sign.yescnf = False
            sign.ShowDialog()

            If sign.yescnf = True Then
                If lbltaxi.Text = "Taxi" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("STEPS COMPLETED.", MsgBoxStyle.Information, "")
                End If

                zero8()
                tripstep8()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbimg8_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbimg8.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtrems8_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems8.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtodoend_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtodoend.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Your code here
            SendKeys.Send("{TAB}")
            e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txtodoend.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txtodoend.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txtodoend.Paste()
        End If
    End Sub

    Private Sub txtodoend_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtodoend.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then

            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtodoend.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            e.Handled = True
                        Else
                            txtodoend.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtodoend.Text) <> "" And txtodoend.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtodoend.Text) <> "" And txtodoend.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtodoend_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtodoend.Leave
        If Val(Trim(txtodoend.Text)) = 0 Then
            txtodoend.Text = 0
        Else
            'check if nde negative yung input
            If Val(txtodobeg.Text) > Val(txtodoend.Text) Then
                Me.Cursor = Cursors.Default
                MsgBox("Ending Odometer is less than the Start Odometer. Add Remarks.", MsgBoxStyle.Exclamation, "")
            ElseIf Val(txtodobeg.Text) = Val(txtodoend.Text) Then
                Me.Cursor = Cursors.Default
                MsgBox("Ending Odometer is the same as Start Odometer. Add Remarks.", MsgBoxStyle.Exclamation, "")
            End If
        End If
    End Sub

    Private Sub txtdieselend_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtdieselend.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Your code here
            SendKeys.Send("{TAB}")
            e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txtdieselend.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txtdieselend.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txtdieselend.Paste()
        End If
    End Sub

    Private Sub txtdieselend_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtdieselend.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then

            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtdieselend.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            'e.Handled = True
                        Else
                            'txtdieselend.Text = 0
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtdieselend.Text) <> "" And txtdieselend.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtdieselend.Text) <> "" And txtdieselend.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtdieselend_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtdieselend.Leave
        If Trim(txtdieselend.Text) = "" Then
            txtdieselend.Text = 0
        Else
            'check if nde negative yung input
            If Val(txtdieselend.Text) >= (Val(txttotaldiesel.Text) + Val(txtpostpo.Text)) Then
                Me.Cursor = Cursors.Default
                MsgBox("Ending Diesel is greater than its the total diesel plus additional diesel. Add Remarks.", MsgBoxStyle.Exclamation, "")
            End If
        End If
    End Sub

    Private Sub txtodo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtodo.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Your code here
            SendKeys.Send("{TAB}")
            e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txtodo.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txtodo.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txtodo.Paste()
        End If
    End Sub

    Private Sub txtodo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtodo.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then

            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtodo.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            e.Handled = True
                        Else
                            txtodo.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtodo.Text) <> "" And txtodo.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtodo.Text) <> "" And txtodo.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtodo_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtodo.Leave
        If Trim(txtodo.Text) = "" Then
            txtodo.Text = 0
        End If

        If Val(Trim(txtodo.Text)) = 0 Then
            txtodo.Text = 0
        Else
            'check if nde negative yung input
            'Val(txtodo.Text) - Val(txtodoend1.Text) >= 5
            If Val(txtodo.Text) < Val(txtodoend1.Text) Then
                Me.Cursor = Cursors.Default
                MsgBox("Actual start Odometer is less than the Previous Ending Odometer. Add Remarks.", MsgBoxStyle.Exclamation, "")
            End If

            If Val(txtodo.Text) - Val(txtodoend1.Text) >= 5 Then
                Me.Cursor = Cursors.Default
                MsgBox("Actual start Odometer is greater than the Previous Ending Odometer. Add Remarks.", MsgBoxStyle.Exclamation, "")
            End If
        End If
    End Sub

    Private Sub txtdiswith_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdiswith.TextChanged

    End Sub

    Private Sub btnstartload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstartload.Click
        Try
            If login.neym <> "Checker" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum3.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum3.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum3.Text, "step3")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 3 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum3.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("step3") = 1 Then
                    lblconfirm3.Text = 1
                End If

                If IsDBNull(dr("startload")) = False Then
                    Dim starttime As Date = CDate(dr("startload").ToString)
                    btnstartload.Text = "TIME START LOADING: " & Format(starttime, "HH:mm")
                    txtrems3.Text = dr("remstp3").ToString
                    startloadfalse()
                    btnexempt3.Enabled = True
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If btnstartload.Text = "TIME START LOADING" Then
                pass = False
                confirmchecker.btncnf = False
                confirmchecker.tripnumber = ""
                confirmchecker.ShowDialog()
                If pass = True Then
                    btnstartload.Text = "TIME START LOADING: " & Format(Date.Now, "HH:mm")

                    sql = "Update tbldispatchsum set startload=GetDate(), startloadby='" & confirmchecker.checkerneym & "' where tripnum='" & lbltripnum3.Text & "'"
                    conn.Open()
                    '/connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    imgcancelfalse3()
                    startloadfalse()
                End If
            End If

            If imgpanel3.Controls.Count = 0 Then
                btnconfirm3.Enabled = False
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub tripstep9()
        Try
            '/Me.WindowState = FormWindowState.Normal
            Me.Cursor = Cursors.WaitCursor

            grp9.Enabled = True
            grdstep9.Rows.Clear()

            'sql = "Select * from tbltripsum where tbltripsum.status='1'"
            sql = "SELECT DISTINCT tbltripsum.tripsumid,tbltripsum.tripnum,tbltripsum.platenum,tbltripsum.driver,tbltripsum.helper,tbldispatchsum.whsename9,tbltripsum.datepick,tbldispatchsum.timedep"
            sql = sql & " FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum"
            sql = sql & " RIGHT OUTER JOIN tbltripitems on tbldispatchsum.tripnum=tbltripitems.tripnum"
            sql = sql & " RIGHT OUTER JOIN tblortrans on tbltripitems.transnum=tblortrans.transnum"
            sql = sql & " RIGHT OUTER JOIN tblcustomer on tblortrans.customer=tblcustomer.customer"
            sql = sql & " where ((tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' and tbldispatchsum.step1='1' and tbldispatchsum.step2='1' and tbldispatchsum.step3='1' and tbldispatchsum.step4='1' and tbldispatchsum.step5='1' and tbldispatchsum.step6='1' and tbldispatchsum.step7='1' and tbldispatchsum.step8='1' and tbldispatchsum.step9='0')"   ' and tbltripsum.datepick<='" & Format(Date.Now, "MM/dd/yyyy") & "' 
            sql = sql & " OR (tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' and tbldispatchsum.step1='1' and tbldispatchsum.step2='1' and tbldispatchsum.step3='1' and tbldispatchsum.step4='1' and tbldispatchsum.step5='1' and tbldispatchsum.step6='1' and tbldispatchsum.step8='1' and tbldispatchsum.step9='0' and a9='1'))"   ' and tbltripsum.datepick<='" & Format(Date.Now, "MM/dd/yyyy") & "' 
            If cmbwhse9.SelectedItem <> "All" Then
                If cmbwhse9.SelectedItem = "LC Accounting Staff" Then
                    sql = sql & "  and tblcustomer.record='" & cmbwhse9.SelectedItem & "' and tblortrans.refnum<>'0000'"
                ElseIf cmbwhse9.SelectedItem = "AGI Accounting Staff" Then
                    sql = sql & "  and tblcustomer.area='Agi Customer' and  tblortrans.refnum='0000'"
                ElseIf cmbwhse9.SelectedItem = login.whse Then
                    sql = sql & "  and (tblcustomer.record='' or tblcustomer.record is null)"
                Else
                    sql = sql & "  and tblcustomer.record='" & cmbwhse9.SelectedItem & "'"
                End If
            End If
            sql = sql & "  order by datepick"
            grdsql = sql
            whatstep = 9

            bgw = New BackgroundWorker()

            AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
            AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
            AddHandler bgw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not bgw.IsBusy Then
                lblload9.Visible = True
                gstep9.Enabled = False
                bgw.WorkerReportsProgress = True
                bgw.WorkerSupportsCancellation = True
                bgw.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub zero9()
        lblplate9.Text = ""
        lbltype9.Text = ""
        lbltripnum9.Text = ""
        lblconfirm9.Text = 0
        txtrems9.Text = ""

        grdtrans9.Rows.Clear()
        btnstartrecord.Text = "TIME START RECORDING"

        imgpanel9.Visible = False
        imgpanel9.Controls.Clear()
        imgpanel9.Visible = True
    End Sub

    Private Sub grdstep9_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grdstep9.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdstep9.Rows(e.RowIndex)
            '<== But this is the name assigned to it in the properties of the control
            'If CDate(Format(dgvRow.Cells(1).Value, "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
            If dgvRow.Cells(6).Value <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
                dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
            End If
        End If
    End Sub

    Private Sub grdstep9_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep9.CellClick
        Try
            If toberecord = 1 Then
                '/Exit Sub di pala pwede kasi di updated yung nakikita
            End If

            zero9()
            Me.Cursor = Cursors.WaitCursor

            lbltripnum9.Tag = grdstep9.Rows(grdstep9.CurrentRow.Index).Cells(0).Value
            lbltripnum9.Text = grdstep9.Rows(grdstep9.CurrentRow.Index).Cells(1).Value
            lblplate9.Text = grdstep9.Rows(grdstep9.CurrentRow.Index).Cells(2).Value

            row9 = grdstep9.CurrentRow.Index
            SelectStep9(strconn)

            If login.neym <> "Diesel Controller" Then
                grdtrans9.Enabled = True
            Else
                grdtrans9.Enabled = False
            End If

            btnimgrefresh9.PerformClick()

            If grdstep9.Rows.Count <> 0 Then
                grp9.Text = lbltripnum9.Text & "     -     " & grdstep9.Rows(grdstep9.CurrentRow.Index).Cells(6).Value
            Else
                grp9.Text = "Photos"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub SelectStep9(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Select vtype from tblgeneral where platenum='" & lblplate9.Text & "' or vplate='" & lblplate9.Text & "' or csticker='" & lblplate9.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    lbltype9.Text = dr("vtype")
                End If
                dr.Dispose()

                grdtrans9.Rows.Clear()
               
                sql = "Select tblortrans.*, tbltripitems.tripid, tbltripitems.status as tripitemstatus, tbltripitems.datecreated, tbltripitems.alreadydisp, tbltripitems.datemodified as tripdatemod, tbltripitems.modifiedby as tripmodby from tblortrans"
                sql = sql & " inner join tbltripitems on tblortrans.transnum=tbltripitems.transnum"
                sql = sql & " where tbltripitems.tripnum='" & lbltripnum9.Text & "' and tbltripitems.status<>'0' and tbltripitems.status<>'3'"
                command.CommandText = sql
                dr = command.ExecuteReader
                While dr.Read
                    Dim backloadall As Boolean = False, cmemo As Boolean = False, yell As Boolean = False, itn As String = "", grp As String = ""

                    If dr("tripitemstatus") = 4 Then
                        backloadall = True
                    ElseIf dr("tripitemstatus") = 5 Then
                        cmemo = True
                    ElseIf dr("tripitemstatus") = 2 Then
                        yell = True
                    End If


                    If dr("itnum").ToString = "" Then
                        If dr("transtype").ToString.Contains("STOCK TRANSFER") = False Then
                            itn = "N/A"
                        End If
                    Else
                        itn = dr("itnum").ToString
                    End If
                    If dr("grponum").ToString = "" Then
                        If dr("transtype").ToString.Contains("STOCK TRANSFER") = False Then
                            grp = "N/A"
                        End If
                    Else
                        grp = dr("grponum").ToString
                    End If

                    grdtrans9.Rows.Add(dr("transid"), dr("transnum"), dr("refnum"), dr("customer"), backloadall, cmemo, dr("arnum"), dr("rdrnum"), dr("drnum"), dr("dnnum"), dr("itrnum"), itn, grp, dr("transtype"), dr("notes"), "", dr("tripid"), yell, "", "")

                    If dr("cancel") = 1 Or dr("tripitemstatus") = 0 Then
                        grdtrans9.Rows(grdtrans9.Rows.Count - 1).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                    ElseIf dr("tripitemstatus") = 4 Then
                        grdtrans9.Rows(grdtrans9.Rows.Count - 1).DefaultCellStyle.BackColor = Color.Plum
                    ElseIf dr("tripitemstatus") = 5 Then
                        grdtrans9.Rows(grdtrans9.Rows.Count - 1).DefaultCellStyle.BackColor = Color.Orange
                    ElseIf dr("tripitemstatus") = 2 Then
                        grdtrans9.Rows(grdtrans9.Rows.Count - 1).DefaultCellStyle.BackColor = Color.Yellow
                        grdtrans9.Rows(grdtrans9.Rows.Count - 1).Cells(18).Value = dr("tripmodby")
                        grdtrans9.Rows(grdtrans9.Rows.Count - 1).Cells(19).Value = dr("tripdatemod")
                    End If

                    If IsDBNull(dr("datecreated")) = False Then
                        grdtrans9.Rows(grdtrans9.Rows.Count - 1).Cells(15).Value = dr("datecreated") 'ormat(dr("datecreated"), "yyyy/MM/dd HH:mm")
                    End If
                    If IsDBNull(dr("alreadydisp")) = False Then
                        If dr("alreadydisp") = 1 Then 'departure
                            grdtrans9.Item(15, grdtrans9.Rows.Count - 1).Style.BackColor = Color.FromArgb(192, 255, 255)
                        ElseIf dr("alreadydisp") = 2 Then 'arrival
                            grdtrans9.Item(15, grdtrans9.Rows.Count - 1).Style.BackColor = Color.FromArgb(255, 224, 192)
                        End If
                    End If
                End While
                dr.Dispose()

                For Each row In grdtrans9.Rows
                    sql = "Select record from tblcustomer where customer='" & grdtrans9.Rows(row.index).Cells(3).Value & "' and record is not NULL"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    If dr.Read Then
                        If grdtrans9.Rows(row.index).Cells(2).Value = "0000" And grdtrans9.Rows(row.index).Cells(13).Value.ToString.Contains("Trucking only for Oro Allado Customers") = False Then
                            grdtrans9.Rows(row.index).Cells(3).ErrorText = "    AGI Accounting Staff"
                        ElseIf Trim(dr("record").ToString) <> "" Then
                            grdtrans9.Rows(row.index).Cells(3).ErrorText = "    " & dr("record")
                        End If
                    End If
                    dr.Dispose()
                Next

                btnstartrecord.Text = "TIME START RECORDING"
                sql = "Select step9,startrecord,remstp9, tbltripsum.podiesel, tbltripsum.addpo, tbltripsum.postaddpo, tbltripsum.repair"
                sql = sql & " from tbldispatchsum inner join tbltripsum on tbldispatchsum.tripnum=tbltripsum.tripnum where tbldispatchsum.tripnum='" & lbltripnum9.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    txtpo9.Text = dr("podiesel") + dr("addpo") + dr("postaddpo")
                    If login.whse = "Calamba" Then
                        txtpo9.Visible = True
                        Label31.Visible = True
                        link2to9.Visible = True
                    End If

                    If dr("step9") = 1 Then
                        lblconfirm9.Text = 1
                    End If

                    If dr("startrecord").ToString <> "" Then
                        Dim starttime As Date
                        Dim timeCheck As Boolean
                        timeCheck = IsDate(dr("startrecord").ToString)
                        If timeCheck = True Then
                            'MsgBox(Trim(txttime.Text) & timeCheck)
                            starttime = CDate(dr("startrecord").ToString)
                            btnstartrecord.Text = "TIME START RECORDING: " & Format(starttime, "HH:mm")
                            txtrems9.Text = dr("remstp9").ToString
                            startrecordfalse()
                        End If
                    Else
                        btnstartrecord.Enabled = True
                        btnimgadd9.Enabled = False
                        txtrems9.Enabled = False
                        txtrems9.Text = ""
                        tripinfo9.Enabled = False
                        btnconfirm9.Enabled = False
                        grdtrans9.ReadOnly = True
                        btnexempt9.Enabled = False
                        link2to9.Enabled = False
                    End If

                    If dr("repair") = 1 Then
                        lblpick9.Visible = True
                        imgbox9.Location = New System.Drawing.Point(imgbox9.Location.X, 65)
                        imgbox9.Size = New System.Drawing.Point(imgbox9.Size.Width, 174)
                    Else
                        lblpick9.Visible = False
                        imgbox9.Location = New System.Drawing.Point(imgbox9.Location.X, 22)
                        imgbox9.Size = New System.Drawing.Point(imgbox9.Size.Width, 217)
                    End If
                End If
                dr.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                triplink9 = False

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub startrecordfalse()
        btnstartrecord.Enabled = False
        btnimgadd9.Enabled = True
        txtrems9.Enabled = True
        tripinfo9.Enabled = True
        btnconfirm9.Enabled = True
        If login.neym = "LC Accounting Staff" Or login.neym = "AGI Accounting Staff" Then
            grdtrans9.ReadOnly = True
        Else
            grdtrans9.ReadOnly = False
            grdtrans9.Columns(1).ReadOnly = True
            grdtrans9.Columns(2).ReadOnly = True
            grdtrans9.Columns(3).ReadOnly = True
            grdtrans9.Columns(13).ReadOnly = True
            grdtrans9.Columns(14).ReadOnly = True
            grdtrans9.Columns(15).ReadOnly = True
            grdtrans9.Columns(16).ReadOnly = True
            grdtrans9.Columns(18).ReadOnly = True
            grdtrans9.Columns(19).ReadOnly = True
        End If
        btnexempt9.Enabled = True
        link2to9.Enabled = True
    End Sub

    Private Sub grdstep9_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdstep9.CellContentClick

    End Sub

    Private Sub grdstep9_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdstep9.CellMouseClick
        Try
            If login.neym = "Diesel Controller" Then
                Exit Sub
            End If
            'right click to set ng pag filter
            If e.Button = Windows.Forms.MouseButtons.Right And e.RowIndex > -1 Then
                If login.userwhse = login.whse Then
                    toberecord = 1
                    grdstep9.ClearSelection()
                    grdstep9.Rows(e.RowIndex).Cells(e.ColumnIndex).Selected = True

                    selectedrow = e.RowIndex

                    For Each item As ToolStripItem In Me.ToBeRecordedByToolStripMenuItem.DropDownItems
                        '/MsgBox(item.ToString)
                        If item.ToString = cmbwhse9.SelectedItem Then
                            item.Enabled = False
                        Else
                            item.Enabled = True
                            If cmbwhse9.SelectedItem = "All" Then
                                If item.ToString = grdstep9.Rows(selectedrow).Cells(5).Value.ToString Then
                                    item.Enabled = False
                                End If
                            End If
                        End If
                    Next
                    Me.ContextMenuStrip2.Show(Cursor.Position)
                    toberecord = 0

                ElseIf login.userwhse = "All" Then
                    If login.neym = "Administrator" Or login.neym = "Supervisor" Or login.neym = "Manager" Or login.neym = "Logistics Staff" Then
                        toberecord = 1
                        grdstep9.ClearSelection()
                        grdstep9.Rows(e.RowIndex).Cells(e.ColumnIndex).Selected = True

                        selectedrow = e.RowIndex

                        For Each item As ToolStripItem In Me.ToBeRecordedByToolStripMenuItem.DropDownItems
                            '/MsgBox(item.ToString)
                            If item.ToString = cmbwhse9.SelectedItem Then
                                item.Enabled = False
                            Else
                                item.Enabled = True
                                If cmbwhse9.SelectedItem = "All" Then
                                    If item.ToString = grdstep9.Rows(selectedrow).Cells(5).Value.ToString Then
                                        item.Enabled = False
                                    End If
                                End If
                            End If
                        Next
                        Me.ContextMenuStrip2.Show(Cursor.Position)
                        toberecord = 0
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdstep9_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdstep9.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Up Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Down Then
            e.Handled = True
        End If
    End Sub

    Private Sub grdstep9_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdstep9.SelectionChanged
        
    End Sub

    Private Sub btnrefstep9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrefstep9.Click
        tripstep9()
    End Sub

    Private Sub btnimgadd9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgadd9.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Encoder" And login.neym <> "Manager" Then
                If login.neym = "Diesel Controller" And login.whse = "Calamba" Then

                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum9.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum9.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum9.Text, "step9")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 9 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgadd9.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofdstp9.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox9.Image = Nothing
                    Dim bmp As New Bitmap(ofdstp9.FileName)
                    imgbox9.Image = bmp
                    '/imgbox9.Image = LoadImage(ofdstp9.FileName)
                    cmbimg9.Text = ofdstp9.SafeFileName.ToString.Replace("'", "")
                    cmbimg9.Enabled = True
                    cmbimg9.Focus()

                    lblCompressionLevel.Text = ""

                    ' Display the file's size.
                    Dim file_info As New FileInfo(ofdstp9.FileName)
                    lblOriginalSize.Text = FormatBytes(file_info.Length)
                    If Microsoft.VisualBasic.Right(ofdstp9.FileName.ToString, 3) = "png" Then
                        lblDesiredSize.Text = FormatBytes(file_info.Length * 0.3)
                    Else
                        lblDesiredSize.Text = "1.10 MB" 'FormatBytes(file_info.Length * 0.4)
                    End If
                    lblCompressedSize.Text = ""
                    lblCompressionLevel.Text = ""

                    Me.Cursor = Cursors.Default
                    imgpanel9.Enabled = False
                    '/enabletab4only()
                    imgcanceltrue9()
                    btnimgadd9.Enabled = True
                    btnimgadd9.Text = "Add"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(cmbimg9.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg9.Focus()
                    Exit Sub
                End If

                If cmbimg9.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photoname.", MsgBoxStyle.Exclamation, "")
                    cmbimg9.Text = ""
                    cmbimg9.Focus()
                    Exit Sub
                End If

                Dim origsize As String = lblOriginalSize.Text
                If Val(origsize.Substring(0, origsize.Length - 2)) > 1 And Microsoft.VisualBasic.Right(origsize, 2) = "MB" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Image exceeds the maximum file size 1MB." & vbCrLf & "Compressing image. Please wait.", MsgBoxStyle.Information)

                    Button3.PerformClick()
                    pgbar9.Visible = True

                    If BackgroundWorker1.IsBusy = False Then
                        BackgroundWorker1.RunWorkerAsync()
                    End If

                    'COMPRESS IMAGE THEN REPLACE IMGBOX9.IMAGE NG COMPRESSED NA IMAGE
                    imgbox9.Image = compressimage(imgbox9.Image, Trim(cmbimg9.Text))
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.WaitCursor
                'insert photo in tblimg
                Dim ms As New MemoryStream()
                'search image name if existing
                conn.Open()
                '/connect()
                cmd = New SqlCommand("Select * from tbldispatchstp9 where tripnum='" & lbltripnum9.Text & "' and name='" & Trim(cmbimg9.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg9.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg9.Focus()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar9.Value = 0
                    pgbar9.Visible = False
                    Exit Sub
                Else
                    'save record in database
                    conn.Close()
                    conn.Open()
                    '/connect()
                    cmd = New SqlCommand("Insert into tbldispatchstp9 values(@tripnum,@name,@img,@status,GetDate(),@createdby)", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("tripnum", lbltripnum9.Text))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(cmbimg9.Text)))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                    imgbox9.Image.Save(ms, Imaging.ImageFormat.Jpeg)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    '/cmd.Parameters.Add(New SqlClient.SqlParameter("datecreated", CDate(Format(Date.Now, "yyyy/MM/dd HH:mm"))))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                    cmd.ExecuteNonQuery()
                    conn.Close()

                    If BackgroundWorker1.WorkerSupportsCancellation = True Then
                        BackgroundWorker1.CancelAsync()
                    End If

                    pgbar9.Value = 0
                    pgbar9.Visible = False

                    MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    pgbar9.Value = 0
                    imgbox9.Image = Nothing
                    imgbox9.BackColor = Color.Empty
                    imgbox9.Invalidate()
                    ms.Close()
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.Default
                btnimgadd9.Text = "Add Photo"
                imgcancelfalse9()
                imgpanel9.Enabled = True
                '/enableall()
                btnimgrefresh9.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub imgcanceltrue9()
        btnimgadd9.Enabled = False
        btnimgrename9.Enabled = False
        btnimgremove9.Enabled = False
        btnimgcancel9.Enabled = True
        btnimgdl9.Enabled = False
        btnimgfull9.Enabled = True
        btnimgrefresh9.Enabled = False
    End Sub

    Public Sub imgcancelfalse9()
        cmbimg9.Text = ""
        lblimgdate9.Text = ""
        lblimgname9.Text = ""
        btnimgadd9.Text = "Add Photo"
        btnimgrename9.Text = "Rename"
        btnimgadd9.Enabled = True
        btnimgrename9.Enabled = True
        btnimgremove9.Enabled = True
        btnimgcancel9.Enabled = False
        btnimgdl9.Enabled = True
        btnimgfull9.Enabled = True
        btnimgrefresh9.Enabled = True
        btnexempt9.Enabled = True
        link2to9.Enabled = True
        btnconfirm9.Enabled = True
    End Sub

    Private Sub btnimgrefresh9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrefresh9.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meronstp9 = False
            imgpanel9.Visible = False
            imgpanel9.Controls.Clear()
            imgpanel9.Visible = True

            Dim ctr As Integer = 0
            sql = "Select * from tbldispatchstp9 where tripnum='" & lbltripnum9.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                meronstp9 = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                picstp9 = New PictureBox
                picstp9.Image = Image.FromStream(ms)
                ms.Dispose()
                picstp9.SizeMode = PictureBoxSizeMode.Zoom
                picstp9.SetBounds(wid, y, 104, 100)
                'picstp9.BackColor = Color.AliceBlue
                picstp9.Tag = dr("stp9imgid")
                picstp9.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler picstp9.Click, AddressOf convertPic9
                imgpanel9.Controls.Add(picstp9)
                imgpanel9.Controls.Add(lbl)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            imgbox9.Image = Nothing
            cmbimg9.Text = ""
            lblimgid9.Text = ""
            lblimgdate9.Text = ""
            lblimgname9.Text = ""

            Me.Cursor = Cursors.Default

            If meronstp9 = False Then
                btnimgrename9.Enabled = False
                btnimgremove9.Enabled = False
                btnimgcancel9.Enabled = False
                btnimgdl9.Enabled = False
                btnimgfull9.Enabled = False
            Else
                imgcancelfalse9()
            End If

            If grdstep9.Rows.Count = 0 Then
                grp9.Enabled = False
            Else
                grp9.Enabled = True
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Sub convertPic9(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            picstp9 = CType(sender, PictureBox)
            imgbox9.Image = picstp9.Image
            lblimgid9.Text = picstp9.Tag

            sql = "Select name,datecreated,createdby from tbldispatchstp9 where stp9imgid='" & lblimgid9.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbimg9.Text = dr("name")
                If IsDBNull(dr("datecreated")) = False Then
                    lblimgdate9.Text = Format(dr("datecreated"), "MM/dd/yyyy h:mm tt")
                Else
                    lblimgdate9.Text = ""
                End If
                lblimgname9.Text = dr("createdby").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgfull9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgfull9.Click
        If lblimgid9.Text <> "" Or imgbox9.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox9.Image
            viewimage.lblimgname.Text = cmbimg9.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnconfirm9.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Encoder" And login.neym <> "Manager" And login.neym <> "LC Accounting Staff" And login.neym <> "AGI Accounting Staff" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If lblpick9.Visible = True Then
                If login.neym = "LC Accounting Staff" Or login.neym = "AGI Accounting Staff" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied! This is pickup trip only.", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum9.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum9.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum9.Text, "step9")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 9 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'check if confirmed na step 7
            sql = "Select step7 from tbldispatchsum where tripnum='" & lbltripnum9.Text & "' and complete=0 and step7=0"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Me.Cursor = Cursors.Default
                MsgBox("Confirm Step 7 first.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            'check if complete
            For Each row As DataGridViewRow In grdtrans9.Rows
                Dim trn As String = grdtrans9.Rows(row.Index).Cells(1).Value
                Dim refn As String = grdtrans9.Rows(row.Index).Cells(2).Value
                Dim arn As String = Trim(grdtrans9.Rows(row.Index).Cells(6).Value.ToString)
                Dim rdr As String = Trim(grdtrans9.Rows(row.Index).Cells(7).Value.ToString)
                Dim drn As String = Trim(grdtrans9.Rows(row.Index).Cells(8).Value.ToString)
                Dim dnn As String = Trim(grdtrans9.Rows(row.Index).Cells(9).Value.ToString)
                Dim itr As String = Trim(grdtrans9.Rows(row.Index).Cells(10).Value.ToString)
                Dim it As String = Trim(grdtrans9.Rows(row.Index).Cells(11).Value.ToString)
                Dim grpo As String = Trim(grdtrans9.Rows(row.Index).Cells(12).Value.ToString)
                Dim notes As String = Trim(grdtrans9.Rows(row.Index).Cells(14).Value.ToString)
                Dim checkCell4 As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(row.Index).Cells(4), DataGridViewCheckBoxCell)
                Dim checkCell5 As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(row.Index).Cells(5), DataGridViewCheckBoxCell)

                If (checkCell4.Value = False And checkCell5.Value = False) And (arn = "" Or rdr = "" Or drn = "" Or dnn = "" Or itr = "" Or it = "" Or grpo = "") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Incomplete input for transaction# " & trn & ".", MsgBoxStyle.Exclamation, "")
                    Exit Sub

                ElseIf (checkCell4.Value = False And checkCell5.Value = False) And (arn.ToLower.Contains("follow") Or rdr.ToLower.Contains("follow") Or drn.ToLower.Contains("follow") Or dnn.ToLower.Contains("follow") Or itr.ToLower.Contains("follow") Or it.ToLower.Contains("follow") Or grpo.ToLower.Contains("follow")) Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Transaction# " & trn & " has to follow #.", MsgBoxStyle.Exclamation, "")
                    Exit Sub

                ElseIf (checkCell4.Value = False And checkCell5.Value = False) And (arn.ToLower.Contains("cancel") Or rdr.ToLower.Contains("cancel") Or drn.ToLower.Contains("cancel") Or dnn.ToLower.Contains("cancel") Or itr.ToLower.Contains("cancel") Or it.ToLower.Contains("cancel") Or grpo.ToLower.Contains("cancel")) Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Transaction# " & trn & "." & " Tick the checkbox if For Reschedule / For AR Credit Memo.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If

                If checkCell4.Value = True And Trim(txtrems9.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    ''/MsgBox("Input remarks why transaction# " & trn & " is for Reschedule.", MsgBoxStyle.Information, "")
                    '/Exit Sub
                ElseIf checkCell5.Value = True And Trim(txtrems9.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input remarks why transaction# " & trn & " is for AR Credit Memo.", MsgBoxStyle.Information, "")
                    Exit Sub
                End If

                If refn.ToString.ToLower.Contains("follow") Then '/And (Trim(txtrems9.Text) = "" And notes = "") Then
                    Me.Cursor = Cursors.Default
                    MsgBox(refn.ToString & "." & vbCrLf & vbCrLf & "Edit TO FOLLOW reference # for transaction# " & trn & ".", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
            Next

            'check if pwede nya ba irecord to
            If grdstep9.Rows(grdstep9.CurrentRow.Index).Cells(5).Value <> "" Then
                If login.userwhse = login.whse Then
                    'puro taga whse lang
                ElseIf login.userwhse = grdstep9.Rows(grdstep9.CurrentRow.Index).Cells(5).Value Then
                    'kung anung whse ka dapat equal dun ung current row sa grdstep9
                ElseIf login.userwhse = "All" Then
                    If login.neym = "LC Accounting Staff" Or login.neym = "AGI Accounting Staff" Then
                        'if login.neym = grdstep9.Rows(grdstep9.CurrentRow.Index).Cells(5).Value Or login.whse = grdstep9.Rows(grdstep9.CurrentRow.Index).Cells(5).Value Then
                        'puro lc and agi
                    Else
                        MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                        Exit Sub
                    End If
                Else
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            Else
                If login.userwhse = login.whse Then
                    'puro taga whse lang
                Else
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If


            'CHECK IF IMGPANEL9 HAS CONTROLS
            If imgpanel9.Controls.Count = 0 Then
                Me.Cursor = Cursors.Default
                '/MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Information, "")
            End If

            If triplink9 = False Then
                '/MsgBox("Click the View Trip Info link first to ensure that all the remarks and comments from other steps are checked.", MsgBoxStyle.Exclamation, "")
                '/Exit Sub
                viewtripinfo.lblid.Text = lbltripnum9.Tag
                viewtripinfo.lbltripnum.Text = lbltripnum9.Text
                viewtripinfo.Text = "Trip Information (" & lbltripnum9.Text & ")"
                viewtripinfo.ShowDialog()
                triplink9 = True
            End If

            Me.Cursor = Cursors.Default
            Dim a As String = MsgBox("Did you check the Order Transaction Information?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
            If a <> vbYes Then
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

            pass = False
            If login.neym = "Encoder" Then
                confirmencoder.ShowDialog()
            ElseIf login.neym = "Manager" Then
                confirm.GroupBox1.Text = login.neym
                confirm.ShowDialog()
            Else
                confirmrecord.GroupBox1.Text = login.neym
                confirmrecord.ShowDialog()
            End If

            If pass = True Then
                Me.Cursor = Cursors.Default
                ExecuteConfirmStep9(strconn)

                zero9()
                grdtrans9.Rows.Clear()
                tripstep9()
                cnf9 = True
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteConfirmStep9(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                'step9
                For Each row As DataGridViewRow In grdtrans9.Rows
                    Dim checkCell4 As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(row.Index).Cells(4), DataGridViewCheckBoxCell)
                    Dim checkCellrecord As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(row.Index).Cells(17), DataGridViewCheckBoxCell)
                    If checkCellrecord.Value = False And checkCell4.Value = False Then
                        Dim trn As String = grdtrans9.Rows(row.Index).Cells(1).Value
                        Dim arn As String = Trim(grdtrans9.Rows(row.Index).Cells(6).Value.ToString)
                        Dim rdr As String = Trim(grdtrans9.Rows(row.Index).Cells(7).Value.ToString)
                        Dim drn As String = Trim(grdtrans9.Rows(row.Index).Cells(8).Value.ToString)
                        Dim dnn As String = Trim(grdtrans9.Rows(row.Index).Cells(9).Value.ToString)
                        Dim itr As String = Trim(grdtrans9.Rows(row.Index).Cells(10).Value.ToString)
                        Dim it As String = Trim(grdtrans9.Rows(row.Index).Cells(11).Value.ToString)
                        Dim grpo As String = Trim(grdtrans9.Rows(row.Index).Cells(12).Value.ToString)
                        Dim notes As String = Trim(grdtrans9.Rows(row.Index).Cells(14).Value.ToString)

                        sql = "Update tblortrans set status='2', arnum='" & arn & "', rdrnum='" & rdr & "', drnum='" & drn & "', dnnum='" & dnn & "', itrnum='" & itr & "', itnum='" & it & "', grponum='" & grpo & "', notes='" & notes & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where transnum='" & trn & "'"
                        command.CommandText = sql
                        command.ExecuteNonQuery()
                    End If
                Next

                sql = "Update tbldispatchsum set complete='1', step9='1', namestp9='" & login.cashier & "', datestp9=GetDate(), mneymstp9='" & login.cashier & "', mdeytstp9=GetDate(), remstp9='" & txtrems9.Text & "' where tripnum='" & lbltripnum9.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                sql = "Update tbltripsum set status='2', datemodified=GetDate(), modifiedby='" & login.cashier & "' where tripnum='" & lbltripnum9.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                sql = "Update tbltripitems set status='2', datemodified=GetDate(), modifiedby='" & login.cashier & "' where tripnum='" & lbltripnum9.Text & "' and status='1'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("STEPS COMPLETED.", MsgBoxStyle.Information, "")

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btnimgrename9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrename9.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Encoder" And login.neym <> "Manager" Then
                If login.neym = "Diesel Controller" And login.whse = "Calamba" Then

                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum9.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum9.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum9.Text, "step9")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 9 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgrename9.Text = "Rename" Then
                If Trim(cmbimg9.Text) <> "" And imgbox9.Image IsNot Nothing Then
                    Dim tempname As String = Trim(cmbimg9.Text)
                    If tempname.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Cannot rename photo.", MsgBoxStyle.Exclamation, "")
                        cmbimg9.Focus()
                        Exit Sub
                    End If
                    cmbimg9.Enabled = True
                    cmbimg9.Focus()
                ElseIf Trim(cmbimg9.Text) = "" And imgbox9.Image IsNot Nothing Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg9.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    cmbimg9.Focus()
                    Exit Sub
                End If

                imgpanel9.Enabled = False
                imgcanceltrue9()
                btnimgrename9.Enabled = True
                btnimgrename9.Text = "Save"
            Else
                'search image name if existing
                connect()
                cmd = New SqlCommand("Select * from tbldispatchstp9 where tripnum='" & lbltripnum9.Text & "' and name='" & Trim(cmbimg9.Text) & "'", conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg9.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg9.Focus()
                    Exit Sub
                Else
                    If cmbimg9.Text.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Invalid photo name.", MsgBoxStyle.Exclamation, "")
                        cmbimg9.Text = ""
                        cmbimg9.Focus()
                        Exit Sub
                    End If

                    'irename.. update yung name lng where imgid = lblimgid.text
                    sql = "Update tbldispatchstp9 set name='" & Trim(cmbimg9.Text) & "' where stp9imgid='" & lblimgid9.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    Me.Cursor = Cursors.Default
                    MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                    btnimgrename9.Text = "Rename"
                    imgcancelfalse9()
                    imgpanel9.Enabled = True
                    btnimgrefresh9.PerformClick()
                    Me.Cursor = Cursors.Default
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgremove9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgremove9.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Encoder" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum9.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum9.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum9.Text, "step9")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 9 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(cmbimg9.Text) <> "" And imgbox9.Image IsNot Nothing Then
                If cmbimg9.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot delete signature", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2)
                If a = vbYes Then
                    'delete image where imgid=lblimgid.text
                    sql = "Delete from tbldispatchstp9 where stp9imgid='" & lblimgid9.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    Me.Cursor = Cursors.Default
                    MsgBox("Successfully remove.", MsgBoxStyle.Information, "")

                    imgcancelfalse9()
                    imgpanel9.Enabled = True
                    btnimgrefresh9.PerformClick()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                cmbimg9.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgcancel9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel9.Click
        imgpanel9.Enabled = True
        imgbox9.Image = Nothing
        cmbimg9.Text = ""
        lblimgid9.Text = ""
        imgcancelfalse9()

        If meronstp9 = False Then
            btnimgrename9.Enabled = False
            btnimgremove9.Enabled = False
            btnimgcancel9.Enabled = False
            btnimgdl9.Enabled = False
            btnimgfull9.Enabled = False
        Else
            imgcancelfalse9()
        End If
    End Sub

    Private Sub btnexempt9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexempt9.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Encoder" And login.neym <> "Manager" And login.neym <> "LC Accounting Staff" And login.neym <> "AGI Accounting Staff" Then
                If login.neym = "Diesel Controller" And login.whse = "Calamba" Then

                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum9.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum9.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum9.Text, "step9")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 9 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL9 HAS CONTROLS
            If imgpanel9.Controls.Count = 0 Then
                'MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
            End If

            pass = False
            confirmsave.GroupBox1.Text = login.neym
            confirmsave.ShowDialog()

            If pass = True Then
                Me.Cursor = Cursors.Default
                ExecuteSaveStep9(strconn)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteSaveStep9(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            transaction = connection.BeginTransaction("SampleTransaction")

            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                For Each row As DataGridViewRow In grdtrans9.Rows
                    Dim checkCellrecord As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(row.Index).Cells(17), DataGridViewCheckBoxCell)
                    If checkCellrecord.Value = False Then
                        Dim trn As String = grdtrans9.Rows(row.Index).Cells(1).Value
                        Dim arn As String = Trim(grdtrans9.Rows(row.Index).Cells(6).Value.ToString)
                        Dim rdr As String = Trim(grdtrans9.Rows(row.Index).Cells(7).Value.ToString)
                        Dim drn As String = Trim(grdtrans9.Rows(row.Index).Cells(8).Value.ToString)
                        Dim dnn As String = Trim(grdtrans9.Rows(row.Index).Cells(9).Value.ToString)
                        Dim itr As String = Trim(grdtrans9.Rows(row.Index).Cells(10).Value.ToString)
                        Dim it As String = Trim(grdtrans9.Rows(row.Index).Cells(11).Value.ToString)
                        Dim grpo As String = Trim(grdtrans9.Rows(row.Index).Cells(12).Value.ToString)
                        Dim notes As String = Trim(grdtrans9.Rows(row.Index).Cells(14).Value.ToString)

                        sql = "Update tblortrans set arnum='" & arn & "', rdrnum='" & rdr & "', drnum='" & drn & "', dnnum='" & dnn & "', itrnum='" & itr & "', itnum='" & it & "', grponum='" & grpo & "', notes='" & notes & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where transnum='" & trn & "'"
                        command.CommandText = sql
                        command.ExecuteNonQuery()
                    End If
                Next

                'save remarks
                sql = "Update tbldispatchsum set sneymstp9='" & login.cashier & "', sdeytstp9=GetDate(), remstp9='" & txtrems9.Text & "' where tripnum='" & lbltripnum9.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                'insert remarks
                sql = "Insert into tblsdraftstp9 (tripnum, sneymstp9, sdeytstp9, remstp9, status) values ('" & lbltripnum9.Text & "', '" & login.cashier & "', GetDate(), '" & txtrems9.Text & "', '1')"
                command.CommandText = sql
                command.ExecuteNonQuery()


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox(lblplate9.Text & " STEP 9 Saved as draft.", MsgBoxStyle.Information, "")

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub cmbimg9_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbimg9.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtrems9_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems9.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnstartpre_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstartpre.Click
        Try
            If login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Guard" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum1.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum1.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum1.Text, "step1")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 1 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            sql = "Select step1,startpre,remstp1 from tbldispatchsum where tripnum='" & lbltripnum1.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("step1") = 1 Then
                    lblconfirm1.Text = 1
                End If

                If IsDBNull(dr("startpre")) = False Then
                    Dim starttime As Date = CDate(dr("startpre").ToString)
                    btnstartpre.Text = "TIME START PRE-INSPECTION: " & Format(starttime, "HH:mm")
                    txtrems1.Text = dr("remstp1").ToString
                    startprefalse()
                    btnimgadd1.Enabled = True
                    btnexempt1.Enabled = True
                    btnconfirm1.Enabled = True
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Dim prevtripnum As String = ""
            sql = "Select TOP 1 tripnum from tbltripsum where status<>'3' and platenum='" & lblplate1.Text & "' and tripsumid<'" & grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(0).Value & "' order by tripsumid DESC"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                prevtripnum = dr("tripnum")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            sql = "SELECT tbltripsum.tripnum FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum where tbltripsum.status<>'3' and tbltripsum.tripnum='" & prevtripnum & "' and (tbldispatchsum.step8='0' or (tbldispatchsum.step8='1' and tbldispatchsum.step6='0'))"
            'sql = "Select * from tbldispatchsum where tripnum='" & prevtripnum & "' and step8='0'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Me.Cursor = Cursors.Default
                MsgBox("Post-Inspection first the previous trip of " & lblplate1.Text & " (" & prevtripnum & ").", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            If btnstartpre.Text = "TIME START PRE-INSPECTION" Then
                btnstartpre.Text = "TIME START PRE-INSPECTION: " & Format(Date.Now, "HH:mm")

                sql = "Update tbldispatchsum set startpre=GetDate(), startpreby='" & login.cashier & "' where tripnum='" & lbltripnum1.Text & "'"
                conn.Open()
                '/connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()
            End If


            If txtodoend1.Text = 0 Then
                sql = "Select TOP 1 odoend from tbltripsum where status<>'3' and platenum='" & lblplate1.Text & "' and tripsumid<'" & grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(0).Value & "' order by tripsumid DESC"
                conn.Open()
                '/connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    txtodoend1.Text = dr("odoend")
                Else
                    txtodoend1.Text = 0
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

            imgcancelfalse1()
            startprefalse()

            btnconfirm1.Enabled = False
            If login.whse = "Cebu" Or login.whse = "Davao" Or login.whse = "Bacolod" Or login.whse = "Tacloban" Then
                btnconfirm1.Enabled = True
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub startprefalse()
        btnstartpre.Enabled = False
        btnodo.Enabled = True
        txtodo.Enabled = True
        txtrems1.Enabled = True
        tripinfo1.Enabled = True
    End Sub

    Private Sub btnstartdiesel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstartdiesel.Click
        Try
            If login.neym <> "Inspector" And login.neym <> "Whse Logistics Staff" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum2.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum2.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum2.Text, "step2")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 2 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            sql = "Select step2, startdiesel, remstp2 from tbldispatchsum where tripnum='" & lbltripnum2.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("step2") = 1 Then
                    lblconfirm2.Text = 1
                End If

                If IsDBNull(dr("startdiesel")) = False Then
                    Dim starttime As Date = CDate(dr("startdiesel").ToString)
                    btnstartdiesel.Text = "TIME START DIESEL: " & Format(starttime, "HH:mm")
                    txtrems2.Text = dr("remstp2").ToString
                    startdieselfalse()
                    btnimgadd2.Enabled = True
                    btnconfirm2.Enabled = True
                    btnexempt2.Enabled = True
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            If btnstartdiesel.Text = "TIME START DIESEL" Then
                btnstartdiesel.Text = "TIME START DIESEL: " & Format(Date.Now, "HH:mm")

                sql = "Update tbldispatchsum set startdiesel=GetDate(), startdieselby='" & login.cashier & "' where tripnum='" & lbltripnum2.Text & "'"
                conn.Open()
                '/connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()
            End If

            If txtdieselbeg1.Text = 0 Then
                sql = "Select TOP 1 * from tbltripsum where status<>'3' and platenum='" & lblplate2.Text & "' and tripsumid<'" & grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(0).Value & "' order by tripsumid DESC"
                conn.Open()
                '/connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    txtdieselbeg1.Text = dr("dieselend")
                Else
                    txtdieselbeg1.Text = 0
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

            imgcancelfalse2()
            startdieselfalse()
            btnconfirm2.Enabled = True

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub startdieselfalse()
        btnstartdiesel.Enabled = False
        btnpo.Enabled = True
        btndis.Enabled = True
        txtdiswith.Enabled = True
        txtdiswout.Enabled = True
        If lblmake2.Text = "Service" Then
            txtdiesel.Text = 0
            txtdiesel.Enabled = False
            btninch2.Enabled = False
        Else
            txtdiesel.Enabled = True
            btninch2.Enabled = True
        End If
        txtaddpo.Enabled = True
        txtaddpo.ReadOnly = False
        If login.neym = "Logistics Staff" Or login.neym = "Supervisor" Then
            txtaddpo.ReadOnly = True
        End If
        txtrems2.Enabled = True
        tripinfo2.Enabled = True
    End Sub

    Private Sub btnstartdoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstartdoc.Click
        Try
            If login.neym <> "Encoder" And login.neym <> "Manager" Then
                If login.neym = "Checker" And login.whse = "C3 Manila" Then

                ElseIf login.neym = "Diesel Controller" And login.whse = "Calamba" Then

                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum4.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum4.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum4.Text, "step4")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 4 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            sql = "Select step4, startdoc, remstp4 from tbldispatchsum where tripnum='" & lbltripnum4.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("step4") = 1 Then
                    lblconfirm4.Text = 1
                End If

                If IsDBNull(dr("startdoc")) = False Then
                    Dim starttime As Date = CDate(dr("startdoc").ToString)
                    btnstartdoc.Text = "TIME START RELEASE DOCUMENTS: " & Format(starttime, "HH:mm")
                    txtrems4.Text = dr("remstp4").ToString
                    startdocfalse()
                    btnexempt4.Enabled = True
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If btnstartdoc.Text = "TIME START RELEASE DOCUMENTS" Then
                btnstartdoc.Text = "TIME START RELEASE DOCUMENTS: " & Format(Date.Now, "HH:mm")

                sql = "Update tbldispatchsum set startdoc=GetDate(), startdocby='" & login.cashier & "' where tripnum='" & lbltripnum4.Text & "'"
                conn.Open()
                '/connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()
            End If

            imgcancelfalse4()
            startdocfalse()

            If imgpanel4.Controls.Count = 0 Then
                btnconfirm4.Enabled = False
                If login.whse = "Cebu" Or login.whse = "Davao" Or login.whse = "Bacolod" Or login.whse = "Tacloban" Then
                    btnconfirm4.Enabled = True
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnstartcash_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstartcash.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" Then
                If login.neym = "Checker" And login.whse = "C3 Manila" Then
                ElseIf login.neym = "Diesel Controller" And login.whse = "Calamba" Then
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum5.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum5.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum5.Text, "step5")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 5 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum5.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("step5") = 1 Then
                    lblconfirm5.Text = 1
                End If

                If IsDBNull(dr("startcash")) = False Then
                    Dim starttime As Date = CDate(dr("startcash").ToString)
                    btnstartcash.Text = "TIME START RELEASE PETTY CASH: " & Format(starttime, "HH:mm")
                    txtrems5.Text = dr("remstp5").ToString
                    startcashfalse()
                    btnexempt5.Enabled = True
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If btnstartcash.Text = "TIME START RELEASE PETTY CASH" Then
                btnstartcash.Text = "TIME START RELEASE PETTY CASH: " & Format(Date.Now, "HH:mm")

                sql = "Update tbldispatchsum set startcash=GetDate(), startcashby='" & login.cashier & "' where tripnum='" & lbltripnum5.Text & "'"
                conn.Open()
                '/connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()
            End If

            imgcancelfalse5()
            startcashfalse()

            If imgpanel5.Controls.Count = 0 Then
                btnconfirm5.Enabled = False
                If login.whse = "Cebu" Or login.whse = "Davao" Or login.whse = "Bacolod" Or login.whse = "Tacloban" Then
                    btnconfirm5.Enabled = True
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btndepart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndepart.Click
        Try
            If login.neym <> "Guard" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum6.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum6.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum6.Text, "step6")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 6 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum6.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("step6") = 1 Then
                    lblconfirm6.Text = 1
                End If

                If IsDBNull(dr("timedep")) = False Then
                    Dim starttime As Date = CDate(dr("timedep").ToString)
                    btndepart.Text = "TIME DEPARTURE TRUCK EXIT WHSE: " & Format(starttime, "HH:mm")
                    txtrems6.Text = dr("remstp6").ToString
                    departfalse()
                    btnexempt6.Enabled = True
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            'btndepart.Text = "TIME DEPARTURE TRUCK EXIT WHSE: " & Format(Date.Now, "HH:mm")
            If btndepart.Text = "TIME DEPARTURE TRUCK EXIT WHSE" Then
                pass = False
                confirmguard.ShowDialog()
                If pass = True Then
                    If lbltype6.Text = "CUSTOMER TRUCK" Then
                        'MsgBox(lblplate6.Text)
                        'step6
                        sql = "Update tbldispatchsum set timedep=GetDate(), timedepby='" & login.cashier & "', step6='1', namestp6='" & login.cashier & "', datestp6=GetDate(), mneymstp6='" & login.cashier & "', mdeytstp6=GetDate(), remstp6='" & txtrems6.Text & "' where tripnum='" & lbltripnum6.Text & "'"
                        conn.Open()
                        '/connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        sql = "Update tbltripsum set timedep=GetDate(), timearr=GetDate(), datemodified=GetDate(), modifiedby='" & login.neym & "' where tripnum='" & lbltripnum6.Text & "'"
                        conn.Open()
                        '/connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                    ElseIf lbltype6.Text = "TRUCKING TRUCK" And Not (txtcustomer.Text.Contains("C3 MANILA WHSE") Or txtcustomer.Text.Contains("CALAMBA WHSE") Or txtcustomer.Text.Contains("PAGBILAO WHSE") Or txtcustomer.Text.Contains("MILAOR WHSE") Or txtcustomer.Text.Contains("NAGA WHSE") Or txtcustomer.Text.Contains("CEBU WHSE") Or txtcustomer.Text.Contains("DAVAO WHSE") Or txtcustomer.Text.Contains("BACOLOD WHSE") Or txtcustomer.Text.Contains("TACLOBAN WHSE") Or txtcustomer.Text.Contains("JP-STORE WHSE")) Then
                        'MsgBox(lblplate6.Text)
                        'step6
                        sql = "Update tbldispatchsum set timedep=GetDate(), timedepby='" & login.cashier & "', step6='1', namestp6='" & login.cashier & "', datestp6=GetDate(), mneymstp6='" & login.cashier & "', mdeytstp6=GetDate(), remstp6='" & txtrems6.Text & "' where tripnum='" & lbltripnum6.Text & "'"
                        conn.Open()
                        '/connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        sql = "Update tbltripsum set timedep=GetDate(), timearr=GetDate(), datemodified=GetDate(), modifiedby='" & login.neym & "' where tripnum='" & lbltripnum6.Text & "'"
                        conn.Open()
                        '/connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                    Else
                        'step6
                        sql = "Update tbltripsum set timedep=GetDate(), datemodified=GetDate(), modifiedby='" & login.cashier & "' where tripnum='" & lbltripnum6.Text & "'"
                        conn.Open()
                        '/connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        sql = "Update tbldispatchsum set timedep=GetDate(), remstp6='" & txtrems6.Text & "', timedepby='" & login.cashier & "' where tripnum='" & lbltripnum6.Text & "'"
                        conn.Open()
                        '/connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()
                    End If

                    If lblpup6.Text = 1 Then
                        Dim selecttrans As String = "Select tblortrans.transnum from tblortrans inner join tbltripitems on tblortrans.transnum=tbltripitems.transnum where tbltripitems.status='1' and tblortrans.cancel<>'1' and tbltripitems.tripnum='" & lbltripnum6.Text & "'"
                        sql = "Update tblortrans set status='1' where cancel<>'1' and transnum=(" & selecttrans & ")"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        sql = "Update tbltripitems set status='4', cancelby='" & login.cashier & "', canceldate=GetDate() where status='1' and tripnum='" & lbltripnum6.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()
                    End If

                    imgcancelfalse6()
                    departfalse()
                    btnexempt6.Enabled = True

                    zero6()
                    tripstep6()

                ElseIf pass = False Then
                    btndepart.Text = "TIME DEPARTURE TRUCK EXIT WHSE"
                End If
            Else
                zero6()
                tripstep6()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnstartreturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstartreturn.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" And login.neym <> "Encoder" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum7.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum7.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum7.Text, "step7")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 7 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum7.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("step7") = 1 Then
                    lblconfirm7.Text = 1
                End If

                If IsDBNull(dr("startreturn")) = False Then
                    Dim starttime As Date = CDate(dr("startreturn").ToString)
                    btnstartreturn.Text = "TIME START RETURN OF DOCUMENTS: " & Format(starttime, "HH:mm")
                    txtrems7.Text = dr("remstp7").ToString
                    startreturnfalse()
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If btnstartreturn.Text = "TIME START RETURN OF DOCUMENTS" Then
                btnstartreturn.Text = "TIME START RETURN OF DOCUMENTS: " & Format(Date.Now, "HH:mm")

                sql = "Update tbldispatchsum set startreturn=GetDate(), startreturnby='" & login.cashier & "' where tripnum='" & lbltripnum7.Text & "'"
                conn.Open()
                '/connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()
            End If

            imgcancelfalse7()
            startreturnfalse()

            If imgpanel7.Controls.Count = 0 Then
                btnconfirm7.Enabled = False
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnstartpost_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstartpost.Click
        Try
            If login.neym <> "Motorpool Inspector" And login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum8.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum8.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum8.Text, "step8")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 8 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum8.Text & "'"
            conn.Open()
            '/connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("step8") = 1 Then
                    lblconfirm8.Text = 1
                End If

                If IsDBNull(dr("startpost")) = False Then
                    Dim starttime As Date = CDate(dr("startpost").ToString)
                    btnstartpost.Text = "TIME START POST-INSPECTION: " & Format(starttime, "HH:mm")
                    txtrems8.Text = dr("remstp8").ToString
                    startpostfalse()
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If btnstartpost.Text = "TIME START POST-INSPECTION" Then
                btnstartpost.Text = "TIME START POST-INSPECTION: " & Format(Date.Now, "HH:mm")

                sql = "Update tbldispatchsum set startpost=GetDate(), startpostby='" & login.cashier & "' where tripnum='" & lbltripnum8.Text & "'"
                conn.Open()
                '/connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()
            End If

            imgcancelfalse8()
            startpostfalse()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnstartrecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstartrecord.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Encoder" And login.neym <> "Manager" Then
                If login.neym = "Diesel Controller" And login.whse = "Calamba" Then

                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
            End If

            cancelledtrip = False
            cancelledtrip = checkcancel(lbltripnum9.Text)
            If cancelledtrip = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Trip# " & lbltripnum9.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            completedstep = False
            completedstep = checkcompleted(lbltripnum9.Text, "step9")
            If completedstep = True Then
                Me.Cursor = Cursors.Default
                MsgBox("Step 9 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum9.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("step9") = 1 Then
                    lblconfirm9.Text = 1
                End If

                If IsDBNull(dr("startrecord")) = False Then
                    Dim starttime As Date = CDate(dr("startrecord").ToString)
                    btnstartrecord.Text = "TIME START RECORDING: " & Format(starttime, "HH:mm")
                    txtrems9.Text = dr("remstp9").ToString
                    startrecordfalse()
                End If
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If btnstartrecord.Text = "TIME START RECORDING" Then
                btnstartrecord.Text = "TIME START RECORDING: " & Format(Date.Now, "HH:mm")

                sql = "Update tbldispatchsum set startrecord=GetDate(), startrecordby='" & login.cashier & "' where tripnum='" & lbltripnum9.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()
            End If

            imgcancelfalse9()
            startrecordfalse()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtrems6_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtrems6.Leave
        If Trim(txtrems6.Text) <> "" Then
            sql = "Update tbldispatchsum set mneymstp1='" & login.cashier & "', mdeytstp1=GetDate(), remstp6='" & Trim(txtrems6.Text) & "' where tripnum='" & lbltripnum6.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
        End If
    End Sub

    Private Sub grdtrans4_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans4.CellClick
        If btnstartdoc.Text = "TIME START RELEASE DOCUMENTS" Then
            grdtrans4.ReadOnly = True
        Else
            grdtrans4.ReadOnly = False
            grdtrans4.Columns(1).ReadOnly = True
            grdtrans4.Columns(2).ReadOnly = True
            grdtrans4.Columns(3).ReadOnly = True
            grdtrans4.Columns(12).ReadOnly = True
        End If
    End Sub

    Private Sub grdtrans4_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans4.CellContentClick
        Try
            'link
            If e.ColumnIndex = 1 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdtrans4.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrans4.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdtrans4.RowCount <> 0 Then
                    If grdtrans4.Item(1, grdtrans4.CurrentRow.Index).Value IsNot Nothing Then
                        viewtrans.Text = "View Transaction"
                        viewtrans.grouptrans.Visible = False
                        viewtrans.lbltripnum.Text = lbltripnum4.Text
                        viewtrans.txttrans.Text = grdtrans4.Item(1, grdtrans4.CurrentRow.Index).Value
                        viewtrans.sing = True
                        viewtrans.ShowDialog()
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrans5_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans5.CellContentClick
        Try
            'link
            If e.ColumnIndex = 1 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdtrans5.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrans5.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdtrans5.RowCount <> 0 Then
                    If grdtrans5.Item(1, grdtrans5.CurrentRow.Index).Value IsNot Nothing Then
                        viewtrans.Text = "View Transaction"
                        viewtrans.grouptrans.Visible = False
                        viewtrans.lbltripnum.Text = lbltripnum5.Text
                        viewtrans.txttrans.Text = grdtrans5.Item(1, grdtrans5.CurrentRow.Index).Value
                        viewtrans.sing = True
                        viewtrans.ShowDialog()
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrans9_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans9.CellClick
        If btnstartrecord.Text = "TIME START RECORDING" Then
            grdtrans9.ReadOnly = True
        Else
            grdtrans9.ReadOnly = False
            grdtrans9.Columns(1).ReadOnly = True
            grdtrans9.Columns(2).ReadOnly = True
            grdtrans9.Columns(3).ReadOnly = True
            grdtrans9.Columns(13).ReadOnly = True
            grdtrans9.Columns(14).ReadOnly = True
            grdtrans9.Columns(15).ReadOnly = True
            grdtrans9.Columns(16).ReadOnly = True
            grdtrans9.Columns(18).ReadOnly = True
            grdtrans9.Columns(19).ReadOnly = True
            If e.RowIndex <> 4 And e.RowIndex <> 5 And e.RowIndex <> 17 Then
                If grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Yellow Then
                    For Each col As DataGridViewColumn In grdtrans9.Columns
                        If col.Index <> 17 Then
                            Dim cell As DataGridViewCell = grdtrans9.Rows(e.RowIndex).Cells(col.Index)
                            cell.ReadOnly = True
                        End If
                    Next
                    '/grdtrans9.Rows(e.RowIndex).ReadOnly = True
                End If
            End If
        End If
    End Sub

    Private Sub grdtrans9_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans9.CellContentClick
        Try
            If e.RowIndex = 4 Or e.RowIndex = 5 Then
                If grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Yellow Then
                    Exit Sub
                End If
            End If

            'link
            If e.ColumnIndex = 1 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdtrans9.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrans9.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdtrans9.RowCount <> 0 Then
                    If grdtrans9.Item(1, grdtrans9.CurrentRow.Index).Value IsNot Nothing Then
                        viewtrans.Text = "View Transaction"
                        viewtrans.grouptrans.Visible = False
                        viewtrans.lbltripnum.Text = lbltripnum9.Text
                        viewtrans.txttrans.Text = grdtrans9.Item(1, grdtrans9.CurrentRow.Index).Value
                        viewtrans.sing = True
                        viewtrans.ShowDialog()
                    End If
                End If

            ElseIf e.ColumnIndex = 4 And e.RowIndex > -1 Then
                If btnstartrecord.Text = "TIME START RECORDING" Then
                    'bawal pag di pa naka tym start
                    Exit Sub
                End If

                If login.neym = "LC Accounting Staff" Or login.neym = "AGI Accounting Staff" Then
                    Me.Cursor = Cursors.Default
                    '/MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                'bawal kapag cancelled na sya
                If grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor <> Color.DeepSkyBlue Then

                    If lblconfirm9.Text = 1 Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Step 9 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                        Exit Sub
                    Else
                        sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum9.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            If dr("step9") = 1 Then
                                lblconfirm9.Text = 1
                            End If
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        If lblconfirm9.Text = 1 Then
                            Me.Cursor = Cursors.Default
                            MsgBox("Step 9 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                            Exit Sub
                        End If
                    End If

                    Dim transnum As String = grdtrans9.Rows(e.RowIndex).Cells(1).Value
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(4), DataGridViewCheckBoxCell)
                    Dim checkCell5 As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(5), DataGridViewCheckBoxCell)
                    Dim checkCellrecord As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(17), DataGridViewCheckBoxCell)
                    'lbltripnum9.Text

                    If checkCell.Value = False Then
                        sql = "Select * from tbltripitems where transnum='" & transnum & "' and (status='1' or status='2') and tripnum<>'" & lbltripnum9.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            MsgBox("Cannot uncheck. Transaction is in process with another trip#.", MsgBoxStyle.Exclamation, "")
                            grdtrans9.Rows(e.RowIndex).Cells(4).Value = True
                            grdtrans9.Rows(e.RowIndex).Cells(3).Selected = True
                            Exit Sub
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()
                    End If

                    If checkCellrecord.Value = True And checkCell.Value = False Then
                        MsgBox("Cannot check Reschedule if Recorded is checked.", MsgBoxStyle.Exclamation, "")
                        grdtrans9.Rows(e.RowIndex).Cells(4).Value = False
                        grdtrans9.Rows(e.RowIndex).Cells(3).Selected = True
                        Exit Sub
                    End If

                    If checkCell5.Value = True And checkCell.Value = True Then
                        MsgBox("Cannot check Reschedule if For AR Credit Memo is checked.", MsgBoxStyle.Exclamation, "")
                        grdtrans9.Rows(e.RowIndex).Cells(4).Value = False
                        grdtrans9.Rows(e.RowIndex).Cells(3).Selected = True
                        Exit Sub
                    End If

                    'confirm
                    pass = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()

                    If pass = True Then
                        If checkCell.Value = True Then
                            '/MsgBox("Cancelled") 'tripitemsstatus = 4

                            sql = "Update tbltripitems set status='4', cancelby='" & login.cashier & "', canceldate=GetDate() where status<>'3' and tripnum='" & lbltripnum9.Text & "' and transnum='" & transnum & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            sql = "Update tblortrans set status='1' where cancel<>'1' and transnum='" & transnum & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'refresh
                            grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Plum
                        Else
                            '/MsgBox("Correction not Cancelled") 'tripitemsstatus = 1

                            sql = "Update tbltripitems set status='1', cancelby=NULL, canceldate=NULL where status<>'3' and tripnum='" & lbltripnum9.Text & "' and transnum='" & transnum & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            sql = "Update tblortrans set status='0' where cancel<>'1' and transnum='" & transnum & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'refresh
                            If e.RowIndex Mod 2 = 0 Then
                                grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.White
                            Else
                                grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Drawing.Color.FromArgb(219, 255, 219)
                            End If
                        End If
                    Else
                        If checkCell.Value = True Then
                            grdtrans9.Rows(e.RowIndex).Cells(4).Value = False
                            grdtrans9.Rows(e.RowIndex).Cells(3).Selected = True
                        Else
                            grdtrans9.Rows(e.RowIndex).Cells(4).Value = True
                            grdtrans9.Rows(e.RowIndex).Cells(3).Selected = True
                        End If
                    End If
                End If

            ElseIf e.ColumnIndex = 5 And e.RowIndex > -1 Then
                If btnstartrecord.Text = "TIME START RECORDING" Then
                    'bawal pag di pa naka tym start
                    Exit Sub
                End If

                If login.neym = "LC Accounting Staff" Or login.neym = "AGI Accounting Staff" Then
                    Me.Cursor = Cursors.Default
                    '/MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                'bawal kapag cancelled na sya
                If grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor <> Color.DeepSkyBlue Then

                    If lblconfirm9.Text = 1 Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Step 9 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                        Exit Sub
                    Else
                        sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum9.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            If dr("step9") = 1 Then
                                lblconfirm9.Text = 1
                            End If
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        If lblconfirm9.Text = 1 Then
                            Me.Cursor = Cursors.Default
                            MsgBox("Step 9 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                            Exit Sub
                        End If
                    End If

                    Dim transnum As String = grdtrans9.Rows(e.RowIndex).Cells(1).Value
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(5), DataGridViewCheckBoxCell)
                    Dim checkCell4 As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(4), DataGridViewCheckBoxCell)
                    Dim checkCellrecord As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(17), DataGridViewCheckBoxCell)

                    If checkCellrecord.Value = True And checkCell.Value = False Then
                        MsgBox("Cannot check For AR Credit Memo if Recorded is checked.", MsgBoxStyle.Exclamation, "")
                        grdtrans9.Rows(e.RowIndex).Cells(5).Value = False
                        grdtrans9.Rows(e.RowIndex).Cells(3).Selected = True
                        Exit Sub
                    End If

                    If checkCell4.Value = True And checkCell.Value = True Then
                        MsgBox("Cannot check For AR Credit Memo if Reschedule is checked.", MsgBoxStyle.Exclamation, "")
                        grdtrans9.Rows(e.RowIndex).Cells(5).Value = False
                        grdtrans9.Rows(e.RowIndex).Cells(3).Selected = True
                        Exit Sub
                    End If

                    'lbltripnum9.Text
                    'confirm
                    pass = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()

                    If pass = True Then
                        If checkCell.Value = True Then
                            '/MsgBox("Cancelled") 'tripitemsstatus = 4

                            sql = "Update tbltripitems set status='5', cancelby='" & login.cashier & "', canceldate=GetDate() where status<>'3' and tripnum='" & lbltripnum9.Text & "' and transnum='" & transnum & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'refresh
                            grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Orange
                        Else
                            '/MsgBox("Correction not Cancelled") 'tripitemsstatus = 1

                            sql = "Update tbltripitems set status='1', cancelby=NULL, canceldate=NULL where status<>'3' and tripnum='" & lbltripnum9.Text & "' and transnum='" & transnum & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'refresh
                            If e.RowIndex Mod 2 = 0 Then
                                grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.White
                            Else
                                grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Drawing.Color.FromArgb(219, 255, 219)
                            End If
                        End If
                    Else
                        If checkCell.Value = True Then
                            grdtrans9.Rows(e.RowIndex).Cells(5).Value = False
                            grdtrans9.Rows(e.RowIndex).Cells(3).Selected = True
                        Else
                            grdtrans9.Rows(e.RowIndex).Cells(5).Value = True
                            grdtrans9.Rows(e.RowIndex).Cells(3).Selected = True
                        End If
                    End If
                End If

            ElseIf e.ColumnIndex = 17 And e.RowIndex > -1 Then
                If btnstartrecord.Text = "TIME START RECORDING" Then
                    'bawal pag di pa naka tym start
                    Exit Sub
                End If

                'bawal kapag cancelled na sya
                If grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor <> Color.DeepSkyBlue Then

                    If lblconfirm9.Text = 1 Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Step 9 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                        Exit Sub
                    Else
                        sql = "Select * from tbldispatchsum where tripnum='" & lbltripnum9.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            If dr("step9") = 1 Then
                                lblconfirm9.Text = 1
                            End If
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        If lblconfirm9.Text = 1 Then
                            Me.Cursor = Cursors.Default
                            MsgBox("Step 9 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                            Exit Sub
                        End If
                    End If

                    Dim transnum As String = grdtrans9.Rows(e.RowIndex).Cells(1).Value
                    Dim checkCellrecord As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(17), DataGridViewCheckBoxCell)
                    Dim checkCell5 As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(5), DataGridViewCheckBoxCell)
                    Dim checkCell4 As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(4), DataGridViewCheckBoxCell)

                    If checkCell4.Value = True Or checkCell5.Value = True Then
                        MsgBox("Cannot check Recorded if Reschedule or For AR Credit Memo is checked.", MsgBoxStyle.Exclamation, "")
                        grdtrans9.Rows(e.RowIndex).Cells(17).Value = False
                        grdtrans9.Rows(e.RowIndex).Cells(18).Selected = True
                        Exit Sub
                    End If

                    'nacheck na na pwede icheck ung recorded, iccheck nmn kung completed ba yung details sa row and walang to follow
                    'check if complete

                    Dim trn As String = grdtrans9.Rows(e.RowIndex).Cells(1).Value
                    Dim refn As String = grdtrans9.Rows(e.RowIndex).Cells(2).Value
                    Dim arn As String = Trim(grdtrans9.Rows(e.RowIndex).Cells(6).Value.ToString)
                    Dim rdr As String = Trim(grdtrans9.Rows(e.RowIndex).Cells(7).Value.ToString)
                    Dim drn As String = Trim(grdtrans9.Rows(e.RowIndex).Cells(8).Value.ToString)
                    Dim dnn As String = Trim(grdtrans9.Rows(e.RowIndex).Cells(9).Value.ToString)
                    Dim itr As String = Trim(grdtrans9.Rows(e.RowIndex).Cells(10).Value.ToString)
                    Dim it As String = Trim(grdtrans9.Rows(e.RowIndex).Cells(11).Value.ToString)
                    Dim grpo As String = Trim(grdtrans9.Rows(e.RowIndex).Cells(12).Value.ToString)
                    Dim notes As String = Trim(grdtrans9.Rows(e.RowIndex).Cells(14).Value.ToString)

                    If (arn = "" Or rdr = "" Or drn = "" Or dnn = "" Or itr = "" Or it = "" Or grpo = "") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Incomplete input for transaction# " & trn & ".", MsgBoxStyle.Exclamation, "")
                        grdtrans9.Rows(e.RowIndex).Cells(17).Value = False
                        grdtrans9.Rows(e.RowIndex).Cells(18).Selected = True
                        Exit Sub

                    ElseIf (arn.ToLower.Contains("follow") Or rdr.ToLower.Contains("follow") Or drn.ToLower.Contains("follow") Or dnn.ToLower.Contains("follow") Or itr.ToLower.Contains("follow") Or it.ToLower.Contains("follow") Or grpo.ToLower.Contains("follow")) Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Transaction# " & trn & " has to follow #.", MsgBoxStyle.Exclamation, "")
                        grdtrans9.Rows(e.RowIndex).Cells(17).Value = False
                        grdtrans9.Rows(e.RowIndex).Cells(18).Selected = True
                        Exit Sub

                    ElseIf (arn.ToLower.Contains("cancel") Or rdr.ToLower.Contains("cancel") Or drn.ToLower.Contains("cancel") Or dnn.ToLower.Contains("cancel") Or itr.ToLower.Contains("cancel") Or it.ToLower.Contains("cancel") Or grpo.ToLower.Contains("cancel")) Then
                        Me.Cursor = Cursors.Default
                        MsgBox("You input the word cancel in Transaction# " & trn & "." & vbCrLf & " Tick the Reschedule or For AR Credit Memo checkbox.", MsgBoxStyle.Exclamation, "")
                        grdtrans9.Rows(e.RowIndex).Cells(17).Value = False
                        grdtrans9.Rows(e.RowIndex).Cells(18).Selected = True
                        Exit Sub
                    End If

                    If refn.ToString.ToLower.Contains("follow") Then '/And (Trim(txtrems9.Text) = "" And notes = "") Then
                        Me.Cursor = Cursors.Default
                        MsgBox(refn.ToString & "." & vbCrLf & vbCrLf & "Edit TO FOLLOW reference # for transaction# " & trn & ".", MsgBoxStyle.Exclamation, "")
                        grdtrans9.Rows(e.RowIndex).Cells(17).Value = False
                        grdtrans9.Rows(e.RowIndex).Cells(18).Selected = True
                        Exit Sub
                    End If

                    'check if ung recorded by is yun din ung mag a uncheck or pwedeng ako or si marylou
                    If checkCellrecord.Value = False And (login.cashier <> grdtrans9.Rows(e.RowIndex).Cells(18).Value And login.neym <> "Administrator" And login.neym <> "Supervisor") Then
                        MsgBox("Access Denied.", MsgBoxStyle.Critical, "")
                        grdtrans9.Rows(e.RowIndex).Cells(17).Value = True
                        grdtrans9.Rows(e.RowIndex).Cells(18).Selected = True
                        Exit Sub
                    End If

                    'lbltripnum9.Text
                    'confirm
                    pass = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()

                    If pass = True Then
                        If checkCellrecord.Value = True Then
                            '/MsgBox("Recorded") 'tripitemsstatus = 2
                            sql = "Update tblortrans set status='2', arnum='" & arn & "', rdrnum='" & rdr & "', drnum='" & drn & "', dnnum='" & dnn & "', itrnum='" & itr & "', itnum='" & it & "', grponum='" & grpo & "', notes='" & notes & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where transnum='" & trn & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            sql = "Update tbltripitems set status='2', modifiedby='" & login.cashier & "', datemodified=GetDate() where status='1' and tripid='" & grdtrans9.Rows(e.RowIndex).Cells(16).Value & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'refresh
                            grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Yellow
                            grdtrans9.Rows(e.RowIndex).Cells(18).Value = login.cashier
                            grdtrans9.Rows(e.RowIndex).Cells(19).Value = Date.Now
                        Else
                            '/MsgBox("Correction not Recorded") 'tripitemsstatus = 1
                            sql = "Update tbltripitems set status='1', modifiedby='" & login.cashier & "', datemodified=GetDate() where status='2' and tripid='" & grdtrans9.Rows(e.RowIndex).Cells(16).Value & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            sql = "Update tblortrans set status='0' where transnum='" & trn & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            grdtrans9.Rows(e.RowIndex).Cells(18).Value = ""
                            grdtrans9.Rows(e.RowIndex).Cells(19).Value = ""

                            grdtrans9.Columns(1).ReadOnly = True
                            grdtrans9.Columns(2).ReadOnly = True
                            grdtrans9.Columns(3).ReadOnly = True
                            grdtrans9.Columns(13).ReadOnly = True
                            grdtrans9.Columns(14).ReadOnly = True
                            grdtrans9.Columns(15).ReadOnly = True
                            grdtrans9.Columns(16).ReadOnly = True
                            grdtrans9.Columns(18).ReadOnly = True
                            grdtrans9.Columns(19).ReadOnly = True

                            For Each col As DataGridViewColumn In grdtrans9.Columns
                                If col.Index <> 17 And col.Index <> 1 And col.Index <> 2 And col.Index <> 3 And col.Index <> 13 And col.Index <> 14 And col.Index <> 15 And col.Index <> 16 And col.Index <> 18 And col.Index <> 19 Then
                                    Dim cell As DataGridViewCell = grdtrans9.Rows(e.RowIndex).Cells(col.Index)
                                    cell.ReadOnly = False
                                End If
                            Next

                            'refresh
                            If e.RowIndex Mod 2 = 0 Then
                                grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.White
                            Else
                                grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Drawing.Color.FromArgb(219, 255, 219)
                            End If
                        End If
                    Else
                        If checkCellrecord.Value = True Then
                            grdtrans9.Rows(e.RowIndex).Cells(17).Value = False
                            grdtrans9.Rows(e.RowIndex).Cells(18).Selected = True
                        Else
                            grdtrans9.Rows(e.RowIndex).Cells(17).Value = True
                            grdtrans9.Rows(e.RowIndex).Cells(18).Selected = True
                        End If
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtpostpo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtpostpo.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Your code here
            SendKeys.Send("{TAB}")
            e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txtpostpo.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txtpostpo.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txtpostpo.Paste()
        End If
    End Sub

    Private Sub txtpostpo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtpostpo.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then

            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtpostpo.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            'e.Handled = True
                        Else
                            'txtpostpo.Text = 0
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtpostpo.Text) <> "" And txtpostpo.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtpostpo.Text) <> "" And txtpostpo.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtpostpo_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtpostpo.Leave
        If Trim(txtpostpo.Text) = "" Then
            txtpostpo.Text = 0
        Else
            'check if nde negative yung input
            If Val(txtdieselend.Text) >= (Val(txttotaldiesel.Text) + Val(txtpostpo.Text)) Then
                Me.Cursor = Cursors.Default
                MsgBox("Ending Diesel is greater than its the total diesel plus additional diesel. Add Remarks.", MsgBoxStyle.Exclamation, "")
            End If

            If Val(txtpostpo.Text) <> 0 And Trim(txtrems8.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Add reason why you need to add diesel.", MsgBoxStyle.Information, "")
            End If
        End If
    End Sub

    Private Sub grdtrans7_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans7.CellClick
        If btnstartreturn.Text = "TIME START RETURN OF DOCUMENTS" Then
            grdtrans7.ReadOnly = True
        Else
            grdtrans7.ReadOnly = False
            grdtrans7.Columns(1).ReadOnly = True
            grdtrans7.Columns(2).ReadOnly = True
            grdtrans7.Columns(3).ReadOnly = True
            grdtrans7.Columns(13).ReadOnly = True
            grdtrans7.Columns(14).ReadOnly = True
        End If
    End Sub

    Private Sub grdtrans7_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans7.CellContentClick
        Try
            'link
            If e.ColumnIndex = 1 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grdtrans7.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grdtrans7.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grdtrans7.RowCount <> 0 Then
                    If grdtrans7.Item(1, grdtrans7.CurrentRow.Index).Value IsNot Nothing Then
                        viewtrans.Text = "View Transaction"
                        viewtrans.grouptrans.Visible = False
                        viewtrans.lbltripnum.Text = lbltripnum7.Text
                        viewtrans.txttrans.Text = grdtrans7.Item(1, grdtrans7.CurrentRow.Index).Value
                        viewtrans.sing = True
                        viewtrans.ShowDialog()
                    End If
                End If

            ElseIf e.ColumnIndex = 4 And e.RowIndex > -1 Then
                If btnstartreturn.Text = "TIME START RETURN OF DOCUMENTS" Then
                    'bawal pag di pa naka tym start
                    Exit Sub
                End If

                'bawal kapag cancelled na sya
                If grdtrans7.Rows(e.RowIndex).DefaultCellStyle.BackColor <> Color.DeepSkyBlue Then

                    cancelledtrip = False
                    cancelledtrip = checkcancel(lbltripnum7.Text)
                    If cancelledtrip = True Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Trip# " & lbltripnum7.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If

                    completedstep = False
                    completedstep = checkcompleted(lbltripnum7.Text, "step7")
                    If completedstep = True Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Step 7 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If

                    Dim transnum As String = grdtrans7.Rows(e.RowIndex).Cells(1).Value
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans7.Rows(e.RowIndex).Cells(4), DataGridViewCheckBoxCell)
                    Dim checkCell5 As DataGridViewCheckBoxCell = CType(grdtrans7.Rows(e.RowIndex).Cells(5), DataGridViewCheckBoxCell)
                    'lbltripnum7.Text

                    If checkCell.Value = False Then
                        sql = "Select * from tbltripitems where transnum='" & transnum & "' and (status='1' or status='2') and tripnum<>'" & lbltripnum7.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            MsgBox("Cannot uncheck. Transaction is in process with another trip#.", MsgBoxStyle.Exclamation, "")
                            grdtrans7.Rows(e.RowIndex).Cells(4).Value = True
                            grdtrans7.Rows(e.RowIndex).Cells(3).Selected = True
                            Exit Sub
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()
                    End If

                    If checkCell5.Value = True And checkCell.Value = True Then
                        MsgBox("Cannot check Reschedule if For AR Credit Memo is checked.", MsgBoxStyle.Exclamation, "")
                        grdtrans7.Rows(e.RowIndex).Cells(4).Value = False
                        grdtrans7.Rows(e.RowIndex).Cells(3).Selected = True
                        Exit Sub
                    End If

                    'confirm
                    pass = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()

                    If pass = True Then
                        If checkCell.Value = True Then
                            '/MsgBox("Cancelled") 'tripitemsstatus = 4

                            sql = "Update tbltripitems set status='4', cancelby='" & login.cashier & "', canceldate=GetDate() where status<>'3' and tripnum='" & lbltripnum7.Text & "' and transnum='" & transnum & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            sql = "Update tblortrans set status='1' where cancel<>'1' and transnum='" & transnum & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'refresh
                            grdtrans7.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Plum
                        Else
                            '/MsgBox("Correction not Cancelled") 'tripitemsstatus = 1

                            sql = "Select * from tbltripitems where transnum='" & transnum & "' and (status='1' or status='2') and tripnum<>'" & lbltripnum7.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            dr = cmd.ExecuteReader
                            If dr.Read Then
                                MsgBox("Cannot uncheck. Transaction is in process with another trip#.", MsgBoxStyle.Exclamation, "")
                                Exit Sub
                            End If
                            dr.Dispose()
                            cmd.Dispose()
                            conn.Close()

                            sql = "Update tbltripitems set status='1', cancelby=NULL, canceldate=NULL where status<>'3' and tripnum='" & lbltripnum7.Text & "' and transnum='" & transnum & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            sql = "Update tblortrans set status='0' where cancel<>'1' and transnum='" & transnum & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'refresh
                            If e.RowIndex Mod 2 = 0 Then
                                grdtrans7.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.White
                            Else
                                grdtrans7.Rows(e.RowIndex).DefaultCellStyle.BackColor = Drawing.Color.FromArgb(219, 255, 219)
                            End If
                        End If
                    Else
                        If checkCell.Value = True Then
                            grdtrans7.Rows(e.RowIndex).Cells(4).Value = False
                            grdtrans7.Rows(e.RowIndex).Cells(3).Selected = True
                        Else
                            grdtrans7.Rows(e.RowIndex).Cells(4).Value = True
                            grdtrans7.Rows(e.RowIndex).Cells(3).Selected = True
                        End If
                    End If
                End If

            ElseIf e.ColumnIndex = 5 And e.RowIndex > -1 Then
                If btnstartreturn.Text = "TIME START RETURN OF DOCUMENTS" Then
                    'bawal pag di pa naka tym start
                    Exit Sub
                End If

                'bawal kapag cancelled na sya
                If grdtrans7.Rows(e.RowIndex).DefaultCellStyle.BackColor <> Color.DeepSkyBlue Then

                    cancelledtrip = False
                    cancelledtrip = checkcancel(lbltripnum7.Text)
                    If cancelledtrip = True Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Trip# " & lbltripnum7.Text & " is already cancelled. Refresh the list.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If

                    completedstep = False
                    completedstep = checkcompleted(lbltripnum7.Text, "step7")
                    If completedstep = True Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Step 7 is already confirmed. Refresh the list.", MsgBoxStyle.Information, "")
                        Exit Sub
                    End If

                    Dim transnum As String = grdtrans7.Rows(e.RowIndex).Cells(1).Value
                    Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans7.Rows(e.RowIndex).Cells(5), DataGridViewCheckBoxCell)
                    Dim checkCell4 As DataGridViewCheckBoxCell = CType(grdtrans7.Rows(e.RowIndex).Cells(4), DataGridViewCheckBoxCell)

                    If checkCell4.Value = True And checkCell.Value = True Then
                        MsgBox("Cannot check For AR Credit Memo if Reschedule is checked.", MsgBoxStyle.Exclamation, "")
                        grdtrans7.Rows(e.RowIndex).Cells(5).Value = False
                        grdtrans7.Rows(e.RowIndex).Cells(3).Selected = True
                        Exit Sub
                    End If

                    'confirm
                    pass = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()

                    If pass = True Then
                        If checkCell.Value = True Then
                            '/MsgBox("Cancelled") 'tripitemsstatus = 5

                            sql = "Update tbltripitems set status='5', cancelby='" & login.cashier & "', canceldate=GetDate() where status<>'3' and tripnum='" & lbltripnum7.Text & "' and transnum='" & transnum & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'refresh
                            grdtrans7.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Orange
                        Else
                            '/MsgBox("Correction not Cancelled") 'tripitemsstatus = 1

                            sql = "Update tbltripitems set status='1', cancelby=NULL, canceldate=NULL where status<>'3' and tripnum='" & lbltripnum7.Text & "' and transnum='" & transnum & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'refresh
                            If e.RowIndex Mod 2 = 0 Then
                                grdtrans7.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.White
                            Else
                                grdtrans7.Rows(e.RowIndex).DefaultCellStyle.BackColor = Drawing.Color.FromArgb(219, 255, 219)
                            End If
                        End If
                    Else
                        If checkCell.Value = True Then
                            grdtrans7.Rows(e.RowIndex).Cells(5).Value = False
                            grdtrans7.Rows(e.RowIndex).Cells(3).Selected = True
                        Else
                            grdtrans7.Rows(e.RowIndex).Cells(5).Value = True
                            grdtrans7.Rows(e.RowIndex).Cells(3).Selected = True
                        End If
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrans7_CellValueChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans7.CellValueChanged
        Try
            If e.ColumnIndex = 4 And e.RowIndex > -1 Then
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans7.Rows(e.RowIndex).Cells(4), DataGridViewCheckBoxCell)

                '/MsgBox(checkCell.Value)

                grdtrans7.Invalidate()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub grdtrans7_CurrentCellDirtyStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdtrans7.CurrentCellDirtyStateChanged
        If grdtrans7.IsCurrentCellDirty Then
            grdtrans7.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub

    Private Sub grdtrans4_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans4.CellEndEdit
        grdtrans4.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = grdtrans4.Rows(e.RowIndex).Cells(e.ColumnIndex).Value.ToString.Replace("'", "")
        grdtrans4.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = grdtrans4.Rows(e.RowIndex).Cells(e.ColumnIndex).Value.ToString.Replace(".", "")

        'check if whse to whse transaction type then if yes yung value ng itr = refnum minus ITR# characters
        If grdtrans4.Rows(e.RowIndex).Cells(12).Value.ToString.Contains("WHSE TO WHSE") = True Then 'str = str.Remove(0, 8)
            grdtrans4.Rows(e.RowIndex).Cells(11).Value = grdtrans4.Rows(e.RowIndex).Cells(2).Value.ToString.Remove(0, 4)
        End If
    End Sub

    Private Sub grdtrans7_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans7.CellEndEdit
        grdtrans7.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = grdtrans7.Rows(e.RowIndex).Cells(e.ColumnIndex).Value.ToString.Replace("'", "")
        grdtrans7.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = grdtrans7.Rows(e.RowIndex).Cells(e.ColumnIndex).Value.ToString.Replace(".", "")

        'check if whse to whse transaction type then if yes yung value ng itr = refnum minus ITR# characters
        If grdtrans7.Rows(e.RowIndex).Cells(13).Value.ToString.Contains("WHSE TO WHSE") = True Then 'str = str.Remove(0, 8)
            grdtrans7.Rows(e.RowIndex).Cells(10).Value = grdtrans7.Rows(e.RowIndex).Cells(2).Value.ToString.Remove(0, 4)
        End If
    End Sub

    Private Sub grdtrans9_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans9.CellEndEdit
        grdtrans9.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = grdtrans9.Rows(e.RowIndex).Cells(e.ColumnIndex).Value.ToString.Replace("'", "")
        grdtrans9.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = grdtrans9.Rows(e.RowIndex).Cells(e.ColumnIndex).Value.ToString.Replace(".", "")

        'check if whse to whse transaction type then if yes yung value ng itr = refnum minus ITR# characters
        If grdtrans9.Rows(e.RowIndex).Cells(13).Value.ToString.Contains("WHSE TO WHSE") = True Then 'str = str.Remove(0, 8)
            grdtrans9.Rows(e.RowIndex).Cells(10).Value = grdtrans9.Rows(e.RowIndex).Cells(2).Value.ToString.Remove(0, 4)
        End If
    End Sub

    Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        pgbar1.Visible = True
    End Sub

    Private Sub BackgroundWorker1_DoWork(ByVal sender As Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        For i As Integer = 1 To 100
            If BackgroundWorker1.CancellationPending = True Then
                e.Cancel = True
                Exit For
            Else
                System.Threading.Thread.Sleep(100)
                BackgroundWorker1.ReportProgress(i * 1)
            End If
        Next
    End Sub

    Private Sub BackgroundWorker1_ProgressChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
        pgbar1.Value = e.ProgressPercentage
    End Sub

    Private Sub BackgroundWorker1_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
        If e.Cancelled = True Then
            '/MsgBox("Cancelled!")
        ElseIf e.Error IsNot Nothing Then
            '/MsgBox("Error!")
        Else
            '/MsgBox("Done!")
        End If
    End Sub

    Private Sub tripdispatch_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.WindowState = FormWindowState.Maximized

        '/checkhasrows7()
        If hasrows7 = True Then
            '/pendingstep7.ShowDialog()
        End If

        '/checkhasrows8()
        If hasrows8 = True Then
            '/pendingstep8.ShowDialog()
        End If
    End Sub

    Public Sub checkhasrows7()
        Try
            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step7<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) Then
                        hasrows7 = True
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub checkhasrows8()
        Try
            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step8<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) Then
                        hasrows8 = True
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub grdstep7_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdstep7.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Up Then
            e.Handled = True
        ElseIf e.KeyCode = Keys.Down Then
            e.Handled = True
        End If
    End Sub

    Private Sub chkpending_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkpending.Click
        Try
            If login.neym <> "Whse Accounting Staff" And login.neym <> "Manager" And login.neym <> "Encoder" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If chkpending.Checked = True Then
                'withpending = true then hold driver
                Dim a As String = MsgBox(lbltripnum7.Text & " is WITH PENDING receipts c/o driver?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                If a = vbYes Then
                    'update withpending = true
                    sql = "Update tbldispatchsum set withpending='1', withpendingneym='" & login.cashier & "', withpendingdate=GetDate() where tripnum='" & lbltripnum7.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    chkpending.Checked = True
                Else
                    chkpending.Checked = False
                End If
            ElseIf chkpending.Checked = False Then
                'withpending = false then dont hold driver
                Dim a As String = MsgBox(lbltripnum7.Text & " pending receipts c/o driver is COMPLETED?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                If a = vbYes Then
                    'update withpending = false
                    sql = "Update tbldispatchsum set withpending='0' where tripnum='" & lbltripnum7.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    chkpending.Checked = False
                Else
                    chkpending.Checked = True
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checkpendingyesterday()
        Try
            For Each row As DataGridViewRow In grdstep7.Rows
                Dim tripnumb As String = grdstep7.Rows(row.Index).Cells(1).Value
                sql = "Select tbltripsum.tripsumid, tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step9='0' and tbltripsum.tripnum='" & tripnumb & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    If CDate(Format(dr("datepick"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
                        grdstep7.Rows(row.Index).DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
                    End If
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub txtlabor_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtlabor.TextChanged

    End Sub

    Private Sub cmbimg1_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg1.Leave
        cmbimg1.Text = Trim(cmbimg1.Text).ToString.Replace("'", "")
    End Sub

    Private Sub cmbimg2_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg2.Leave
        cmbimg2.Text = Trim(cmbimg2.Text).ToString.Replace("'", "")
    End Sub

    Private Sub cmbimg3_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg3.Leave
        cmbimg3.Text = Trim(cmbimg3.Text).ToString.Replace("'", "")
    End Sub

    Private Sub cmbimg4_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg4.Leave
        cmbimg4.Text = Trim(cmbimg4.Text).ToString.Replace("'", "")
    End Sub

    Private Sub cmbimg5_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg5.Leave
        cmbimg5.Text = Trim(cmbimg5.Text).ToString.Replace("'", "")
    End Sub

    Private Sub cmbimg6_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg6.Leave
        cmbimg6.Text = Trim(cmbimg6.Text).ToString.Replace("'", "")
    End Sub

    Private Sub cmbimg7_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg7.Leave
        cmbimg7.Text = Trim(cmbimg7.Text).ToString.Replace("'", "")
    End Sub

    Private Sub cmbimg8_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg8.Leave
        cmbimg8.Text = Trim(cmbimg8.Text).ToString.Replace("'", "")
    End Sub

    Private Sub cmbimg9_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg9.Leave
        cmbimg9.Text = Trim(cmbimg9.Text).ToString.Replace("'", "")
    End Sub

    Private Sub cmbimg1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbimg1.SelectedIndexChanged

    End Sub

    Private Sub cmbimg1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg1.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = cmbimg1.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbimg1.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbimg1.Text.Length - 1
            Letter = cmbimg1.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbimg1.Text = theText
        cmbimg1.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtrems1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtrems1.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtrems1.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtrems1.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtrems1.Text.Length - 1
            Letter = txtrems1.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtrems1.Text = theText
        txtrems1.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub cmbimg2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbimg2.SelectedIndexChanged

    End Sub

    Private Sub cmbimg2_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg2.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = cmbimg2.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbimg2.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbimg2.Text.Length - 1
            Letter = cmbimg2.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbimg2.Text = theText
        cmbimg2.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtrems2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtrems2.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtrems2.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtrems2.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtrems2.Text.Length - 1
            Letter = txtrems2.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtrems2.Text = theText
        txtrems2.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub cmbimg3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbimg3.SelectedIndexChanged

    End Sub

    Private Sub cmbimg3_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg3.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = cmbimg3.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbimg3.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbimg3.Text.Length - 1
            Letter = cmbimg3.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbimg3.Text = theText
        cmbimg3.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtrems3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtrems3.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtrems3.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtrems3.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtrems3.Text.Length - 1
            Letter = txtrems3.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtrems3.Text = theText
        txtrems3.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub cmbimg4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbimg4.SelectedIndexChanged

    End Sub

    Private Sub cmbimg4_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg4.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = cmbimg4.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbimg4.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbimg4.Text.Length - 1
            Letter = cmbimg4.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbimg4.Text = theText
        cmbimg4.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtrems4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtrems4.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtrems4.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtrems4.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtrems4.Text.Length - 1
            Letter = txtrems4.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtrems4.Text = theText
        txtrems4.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub cmbimg5_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbimg5.SelectedIndexChanged

    End Sub

    Private Sub cmbimg5_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg5.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = cmbimg5.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbimg5.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbimg5.Text.Length - 1
            Letter = cmbimg5.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbimg5.Text = theText
        cmbimg5.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtrems5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtrems5.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtrems5.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtrems5.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtrems5.Text.Length - 1
            Letter = txtrems5.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtrems5.Text = theText
        txtrems5.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub cmbimg6_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbimg6.SelectedIndexChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = cmbimg6.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbimg6.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbimg6.Text.Length - 1
            Letter = cmbimg6.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbimg6.Text = theText
        cmbimg6.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtrems6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtrems6.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtrems6.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtrems6.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtrems6.Text.Length - 1
            Letter = txtrems6.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtrems6.Text = theText
        txtrems6.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub cmbimg7_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbimg7.SelectedIndexChanged

    End Sub

    Private Sub cmbimg7_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg7.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = cmbimg7.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbimg7.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbimg7.Text.Length - 1
            Letter = cmbimg7.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbimg7.Text = theText
        cmbimg7.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtrems7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtrems7.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtrems7.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtrems7.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtrems7.Text.Length - 1
            Letter = txtrems7.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtrems7.Text = theText
        txtrems7.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub cmbimg8_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbimg8.SelectedIndexChanged

    End Sub

    Private Sub cmbimg8_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg8.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = cmbimg8.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbimg8.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbimg8.Text.Length - 1
            Letter = cmbimg8.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbimg8.Text = theText
        cmbimg8.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtrems8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtrems8.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtrems8.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtrems8.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtrems8.Text.Length - 1
            Letter = txtrems8.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtrems8.Text = theText
        txtrems8.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub cmbimg9_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbimg9.SelectedIndexChanged

    End Sub

    Private Sub cmbimg9_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbimg9.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = cmbimg9.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbimg9.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbimg9.Text.Length - 1
            Letter = cmbimg9.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbimg9.Text = theText
        cmbimg9.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtrems9_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtrems9.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtrems9.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtrems9.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtrems9.Text.Length - 1
            Letter = txtrems9.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtrems9.Text = theText
        txtrems9.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtdiesel_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdiesel.TextChanged

    End Sub

    Private Sub grdtrans4_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdtrans4.CellMouseClick
        Try
            If e.Button = Windows.Forms.MouseButtons.Right And e.RowIndex > -1 Then
                If e.ColumnIndex = 2 Then
                    If grdtrans4.Rows(e.RowIndex).DefaultCellStyle.BackColor <> Color.DeepSkyBlue Then
                        grdtrans4.ClearSelection()
                        grdtrans4.Rows(e.RowIndex).Cells(2).Selected = True

                        selectedrow = e.RowIndex

                        Dim refnum As String = grdtrans4.Rows(e.RowIndex).Cells(2).Value

                        If refnum = "0000" Then
                            Exit Sub
                        End If

                        If btnstartdoc.Text = "TIME START RELEASE DOCUMENTS" Then
                            MsgBox("Time start release documents first.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If

                        Me.ContextMenuStrip1.Show(Cursor.Position)
                        editstep = 4
                        EditSOToolStripMenuItem.Visible = False
                        EditPOToolStripMenuItem.Visible = False
                        EditITRToolStripMenuItem.Visible = False
                        EditSWSToolStripMenuItem.Visible = False

                        If refnum.ToUpper.ToString.Contains("SO#") = True Then
                            EditSOToolStripMenuItem.Visible = True
                        End If
                        If refnum.ToUpper.ToString.Contains("PO#") = True Then
                            EditPOToolStripMenuItem.Visible = True
                        ElseIf refnum.ToUpper.ToString.Contains("ITR#") = True Then
                            EditITRToolStripMenuItem.Visible = True
                        ElseIf refnum.ToUpper.ToString.Contains("SWS#") = True Then
                            EditSWSToolStripMenuItem.Visible = True
                        End If
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrans7_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdtrans7.CellMouseClick
        Try
            If e.Button = Windows.Forms.MouseButtons.Right And e.RowIndex > -1 Then
                If e.ColumnIndex = 2 Then
                    If grdtrans7.Rows(e.RowIndex).DefaultCellStyle.BackColor <> Color.DeepSkyBlue Then
                        grdtrans7.ClearSelection()
                        grdtrans7.Rows(e.RowIndex).Cells(2).Selected = True

                        selectedrow = e.RowIndex

                        Dim refnum As String = grdtrans7.Rows(e.RowIndex).Cells(2).Value

                        If refnum = "0000" Then
                            Exit Sub
                        End If

                        If btnstartreturn.Text = "TIME START RETURN OF DOCUMENTS" Then
                            MsgBox("Time start return documents first.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If

                        Me.ContextMenuStrip1.Show(Cursor.Position)
                        editstep = 7
                        EditSOToolStripMenuItem.Visible = False
                        EditPOToolStripMenuItem.Visible = False
                        EditITRToolStripMenuItem.Visible = False
                        EditSWSToolStripMenuItem.Visible = False

                        If refnum.ToUpper.ToString.Contains("SO#") = True Then
                            EditSOToolStripMenuItem.Visible = True
                        End If
                        If refnum.ToUpper.ToString.Contains("PO#") = True Then
                            EditPOToolStripMenuItem.Visible = True
                        ElseIf refnum.ToUpper.ToString.Contains("ITR#") = True Then
                            EditITRToolStripMenuItem.Visible = True
                        ElseIf refnum.ToUpper.ToString.Contains("SWS#") = True Then
                            EditSWSToolStripMenuItem.Visible = True
                        End If
                    End If

                Else '/ kahit anong column sa grdtrans7 dun lang lalabas yung menustrip na cancel transaction



                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrans9_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdtrans9.CellMouseClick
        Try
            If e.Button = Windows.Forms.MouseButtons.Right And e.RowIndex > -1 Then
                If e.ColumnIndex = 2 Then
                    If grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor <> Color.DeepSkyBlue Then
                        grdtrans9.ClearSelection()
                        grdtrans9.Rows(e.RowIndex).Cells(2).Selected = True

                        selectedrow = e.RowIndex

                        Dim refnum As String = grdtrans9.Rows(e.RowIndex).Cells(2).Value

                        If refnum = "0000" Then
                            Exit Sub
                        End If

                        If btnstartrecord.Text = "TIME START RECORDING" Then
                            MsgBox("Time start recording first.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If

                        Me.ContextMenuStrip1.Show(Cursor.Position)
                        editstep = 9
                        EditSOToolStripMenuItem.Visible = False
                        EditPOToolStripMenuItem.Visible = False
                        EditITRToolStripMenuItem.Visible = False
                        EditSWSToolStripMenuItem.Visible = False

                        If grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Yellow Then
                            Exit Sub
                        End If

                        If refnum.ToUpper.ToString.Contains("SO#") = True Then
                            EditSOToolStripMenuItem.Visible = True
                        End If
                        If refnum.ToUpper.ToString.Contains("PO#") = True Then
                            EditPOToolStripMenuItem.Visible = True
                        ElseIf refnum.ToUpper.ToString.Contains("ITR#") = True Then
                            EditITRToolStripMenuItem.Visible = True
                        ElseIf refnum.ToUpper.ToString.Contains("SWS#") = True Then
                            EditSWSToolStripMenuItem.Visible = True
                        End If
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrans9_CellPainting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles grdtrans9.CellPainting
        If e.Handled Then
            Exit Sub 'Already handled.
        End If

        'Paint everything except the ErrorIcon the standard way.
        e.Paint(e.ClipBounds, e.PaintParts And Not DataGridViewPaintParts.ErrorIcon)

        'Paint the ErrorIcon, if necessary, the custom way.
        If (e.PaintParts And DataGridViewPaintParts.ErrorIcon) = DataGridViewPaintParts.ErrorIcon Then
            If e.ErrorText <> "" Then
                With e.Graphics
                    Dim gstate As Drawing2D.GraphicsState = .Save()
                    Dim iconRect As Rectangle = New Rectangle(e.CellBounds.Right - 20, e.CellBounds.Top + e.CellBounds.Height \ 2 - 6, 12, 12)
                    Dim backColor As Color
                    If (e.State And DataGridViewElementStates.Selected) = DataGridViewElementStates.Selected Then
                        backColor = e.CellStyle.SelectionBackColor
                    Else
                        backColor = e.CellStyle.BackColor
                    End If

                    'Restrict drawing within cell boundaries.
                    .SetClip(e.CellBounds)
                    'Clear background area behind the icon.
                    Using brush As New SolidBrush(backColor)
                        .FillRectangle(brush, iconRect)
                    End Using
                    'Draw the icon.
                    .DrawIcon(SystemIcons.Information, iconRect)
                    .Restore(gstate)
                End With
            End If
        End If

        e.Handled = True
    End Sub

    Private Sub grdtrans9_CellValueChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdtrans9.CellValueChanged
        Try
            If e.ColumnIndex = 4 And e.RowIndex > -1 Then
                Dim checkCell As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(4), DataGridViewCheckBoxCell)

                '/MsgBox(checkCell.Value)

                grdtrans9.Invalidate()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdtrans9_CurrentCellDirtyStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdtrans9.CurrentCellDirtyStateChanged
        If grdtrans9.IsCurrentCellDirty Then
            grdtrans9.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub

    Private Sub EditSOToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditSOToolStripMenuItem.Click
        edited = False
        tripeditref.lbl1.Text = "SO#"
        tripeditref.lbl2.Text = "SO#"

        editrefnum()
    End Sub

    Private Sub EditPOToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditPOToolStripMenuItem.Click
        edited = False
        tripeditref.lbl1.Text = "PO#"
        tripeditref.lbl2.Text = "PO#"

        editrefnum()
    End Sub

    Private Sub EditITRToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditITRToolStripMenuItem.Click
        edited = False
        tripeditref.lbl1.Text = "ITR#"
        tripeditref.lbl2.Text = "ITR#"

        editrefnum()
    End Sub

    Private Sub EditSWSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditSWSToolStripMenuItem.Click
        edited = False
        tripeditref.lbl1.Text = "SWS#"
        tripeditref.lbl2.Text = "SWS#"

        editrefnum()
    End Sub

    Private Sub ViewEditReferenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewEditReferenceToolStripMenuItem.Click
        If editstep = 3 Then
            transoredit.lbltrans.Text = grdtrans3.Item(1, grdtrans3.CurrentRow.Index).Value
            transoredit.lblcus.Text = grdtrans3.Item(3, grdtrans3.CurrentRow.Index).Value
            transoredit.ShowDialog()
        ElseIf editstep = 4 Then
            transoredit.lbltrans.Text = grdtrans4.Item(1, grdtrans4.CurrentRow.Index).Value
            transoredit.lblcus.Text = grdtrans4.Item(3, grdtrans4.CurrentRow.Index).Value
            transoredit.ShowDialog()
        ElseIf editstep = 7 Then
            transoredit.lbltrans.Text = grdtrans7.Item(1, grdtrans7.CurrentRow.Index).Value
            transoredit.lblcus.Text = grdtrans7.Item(3, grdtrans7.CurrentRow.Index).Value
            transoredit.ShowDialog()
        ElseIf editstep = 9 Then
            transoredit.lbltrans.Text = grdtrans9.Item(1, grdtrans9.CurrentRow.Index).Value
            transoredit.lblcus.Text = grdtrans9.Item(3, grdtrans9.CurrentRow.Index).Value
            transoredit.ShowDialog()
        End If
    End Sub

    Public Sub editrefnum()
        tripeditref.frm = Me.Name

        If editstep = 4 Then
            tripeditref.txttransid.Text = grdtrans4.Rows(selectedrow).Cells(0).Value
            tripeditref.txttransnum.Text = grdtrans4.Rows(selectedrow).Cells(1).Value
            tripeditref.txtcus.Text = grdtrans4.Rows(selectedrow).Cells(3).Value
            tripeditref.ShowDialog()

            If edited = True Then
                grdtrans4.Rows(selectedrow).Cells(2).Value = tripeditref.refnum
            End If

        ElseIf editstep = 7 Then
            tripeditref.txttransid.Text = grdtrans7.Rows(selectedrow).Cells(0).Value
            tripeditref.txttransnum.Text = grdtrans7.Rows(selectedrow).Cells(1).Value
            tripeditref.txtcus.Text = grdtrans7.Rows(selectedrow).Cells(3).Value
            tripeditref.ShowDialog()

            If edited = True Then
                grdtrans7.Rows(selectedrow).Cells(2).Value = tripeditref.refnum
            End If

        ElseIf editstep = 9 Then
            tripeditref.txttransid.Text = grdtrans9.Rows(selectedrow).Cells(0).Value
            tripeditref.txttransnum.Text = grdtrans9.Rows(selectedrow).Cells(1).Value
            tripeditref.txtcus.Text = grdtrans9.Rows(selectedrow).Cells(3).Value
            tripeditref.ShowDialog()

            If edited = True Then
                grdtrans9.Rows(selectedrow).Cells(2).Value = tripeditref.refnum
            End If
        End If
    End Sub

    Private Sub LCAccountingStaffToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LCAccountingStaffToolStripMenuItem.Click
        Try
            pass = False
            confirmrecordedby.GroupBox1.Text = login.neym
            confirmrecordedby.ShowDialog()
            If pass = True Then
                Dim tripn As String = grdstep9.Rows(selectedrow).Cells(1).Value.ToString
                'MsgBox(grdstep9.Rows(selectedrow).Cells(1).Value.ToString)

                sql = "Update tbldispatchsum set whsename9='" & LCAccountingStaffToolStripMenuItem.Text & "' where tripnum='" & tripn & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                sql = "Insert into tblwhsenamestp9 (tripnum, whsename9, datemodified, modifiedby, status) values ('" & tripn & "', '" & LCAccountingStaffToolStripMenuItem.Text & "', GetDate(), '" & login.cashier & "', '1')"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Trip# " & tripn & " - To be recorded by " & LCAccountingStaffToolStripMenuItem.Text & "." & vbCrLf & "Refresh list.", MsgBoxStyle.Information, "")

                grdstep9.Rows(selectedrow).Cells(5).Value = LCAccountingStaffToolStripMenuItem.Text
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub AGIAccountingStaffToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AGIAccountingStaffToolStripMenuItem.Click
        Try
            pass = False
            confirmrecordedby.GroupBox1.Text = login.neym
            confirmrecordedby.ShowDialog()
            If pass = True Then
                Dim tripn As String = grdstep9.Rows(selectedrow).Cells(1).Value.ToString
                'MsgBox(grdstep9.Rows(selectedrow).Cells(1).Value.ToString)

                sql = "Update tbldispatchsum set whsename9='" & AGIAccountingStaffToolStripMenuItem.Text & "' where tripnum='" & tripn & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                sql = "Insert into tblwhsenamestp9 (tripnum, whsename9, datemodified, modifiedby, status) values ('" & tripn & "', '" & AGIAccountingStaffToolStripMenuItem.Text & "', GetDate(), '" & login.cashier & "', '1')"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Trip# " & tripn & " - To be recorded by " & AGIAccountingStaffToolStripMenuItem.Text & "." & vbCrLf & "Refresh list.", MsgBoxStyle.Information, "")

                grdstep9.Rows(selectedrow).Cells(5).Value = AGIAccountingStaffToolStripMenuItem.Text
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub C3ManilaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles C3ManilaToolStripMenuItem.Click
        Try
            pass = False
            confirmrecordedby.GroupBox1.Text = login.neym
            confirmrecordedby.ShowDialog()
            If pass = True Then
                Dim tripn As String = grdstep9.Rows(selectedrow).Cells(1).Value.ToString
                'MsgBox(grdstep9.Rows(selectedrow).Cells(1).Value.ToString)

                sql = "Update tbldispatchsum set whsename9='" & C3ManilaToolStripMenuItem.Text & "' where tripnum='" & tripn & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                sql = "Insert into tblwhsenamestp9 (tripnum, whsename9, datemodified, modifiedby, status) values ('" & tripn & "', '" & C3ManilaToolStripMenuItem.Text & "', GetDate(), '" & login.cashier & "', '1')"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Trip# " & tripn & " - To be recorded by " & C3ManilaToolStripMenuItem.Text & "." & vbCrLf & "Refresh list.", MsgBoxStyle.Information, "")

                grdstep9.Rows(selectedrow).Cells(5).Value = C3ManilaToolStripMenuItem.Text
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub CalambaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CalambaToolStripMenuItem.Click
        Try
            pass = False
            confirmrecordedby.GroupBox1.Text = login.neym
            confirmrecordedby.ShowDialog()
            If pass = True Then
                Dim tripn As String = grdstep9.Rows(selectedrow).Cells(1).Value.ToString
                'MsgBox(grdstep9.Rows(selectedrow).Cells(1).Value.ToString)

                sql = "Update tbldispatchsum set whsename9='" & CalambaToolStripMenuItem.Text & "' where tripnum='" & tripn & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                sql = "Insert into tblwhsenamestp9 (tripnum, whsename9, datemodified, modifiedby, status) values ('" & tripn & "', '" & CalambaToolStripMenuItem.Text & "', GetDate(), '" & login.cashier & "', '1')"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Trip# " & tripn & " - To be recorded by " & CalambaToolStripMenuItem.Text & "." & vbCrLf & "Refresh list.", MsgBoxStyle.Information, "")

                grdstep9.Rows(selectedrow).Cells(5).Value = CalambaToolStripMenuItem.Text
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub PagbilaoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PagbilaoToolStripMenuItem.Click
        Try
            pass = False
            confirmrecordedby.GroupBox1.Text = login.neym
            confirmrecordedby.ShowDialog()
            If pass = True Then
                Dim tripn As String = grdstep9.Rows(selectedrow).Cells(1).Value.ToString
                'MsgBox(grdstep9.Rows(selectedrow).Cells(1).Value.ToString)

                sql = "Update tbldispatchsum set whsename9='" & PagbilaoToolStripMenuItem.Text & "' where tripnum='" & tripn & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                sql = "Insert into tblwhsenamestp9 (tripnum, whsename9, datemodified, modifiedby, status) values ('" & tripn & "', '" & PagbilaoToolStripMenuItem.Text & "', GetDate(), '" & login.cashier & "', '1')"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Trip# " & tripn & " - To be recorded by " & PagbilaoToolStripMenuItem.Text & "." & vbCrLf & "Refresh list.", MsgBoxStyle.Information, "")

                grdstep9.Rows(selectedrow).Cells(5).Value = PagbilaoToolStripMenuItem.Text
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub MilaorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MilaorToolStripMenuItem.Click
        Try
            pass = False
            confirmrecordedby.GroupBox1.Text = login.neym
            confirmrecordedby.ShowDialog()
            If pass = True Then
                Dim tripn As String = grdstep9.Rows(selectedrow).Cells(1).Value.ToString
                'MsgBox(grdstep9.Rows(selectedrow).Cells(1).Value.ToString)

                sql = "Update tbldispatchsum set whsename9='" & MilaorToolStripMenuItem.Text & "' where tripnum='" & tripn & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                sql = "Insert into tblwhsenamestp9 (tripnum, whsename9, datemodified, modifiedby, status) values ('" & tripn & "', '" & MilaorToolStripMenuItem.Text & "', GetDate(), '" & login.cashier & "', '1')"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Trip# " & tripn & " - To be recorded by " & MilaorToolStripMenuItem.Text & "." & vbCrLf & "Refresh list.", MsgBoxStyle.Information, "")

                grdstep9.Rows(selectedrow).Cells(5).Value = MilaorToolStripMenuItem.Text
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub CebuToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CebuToolStripMenuItem.Click
        Try
            pass = False
            confirmrecordedby.GroupBox1.Text = login.neym
            confirmrecordedby.ShowDialog()
            If pass = True Then
                Dim tripn As String = grdstep9.Rows(selectedrow).Cells(1).Value.ToString
                'MsgBox(grdstep9.Rows(selectedrow).Cells(1).Value.ToString)

                sql = "Update tbldispatchsum set whsename9='" & CebuToolStripMenuItem.Text & "' where tripnum='" & tripn & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                sql = "Insert into tblwhsenamestp9 (tripnum, whsename9, datemodified, modifiedby, status) values ('" & tripn & "', '" & CebuToolStripMenuItem.Text & "', GetDate(), '" & login.cashier & "', '1')"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Trip# " & tripn & " - To be recorded by " & CebuToolStripMenuItem.Text & "." & vbCrLf & "Refresh list.", MsgBoxStyle.Information, "")

                grdstep9.Rows(selectedrow).Cells(5).Value = CebuToolStripMenuItem.Text
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub DavaoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DavaoToolStripMenuItem.Click
        Try
            pass = False
            confirmrecordedby.GroupBox1.Text = login.neym
            confirmrecordedby.ShowDialog()
            If pass = True Then
                Dim tripn As String = grdstep9.Rows(selectedrow).Cells(1).Value.ToString
                'MsgBox(grdstep9.Rows(selectedrow).Cells(1).Value.ToString)

                sql = "Update tbldispatchsum set whsename9='" & DavaoToolStripMenuItem.Text & "' where tripnum='" & tripn & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                sql = "Insert into tblwhsenamestp9 (tripnum, whsename9, datemodified, modifiedby, status) values ('" & tripn & "', '" & DavaoToolStripMenuItem.Text & "', GetDate(), '" & login.cashier & "', '1')"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Trip# " & tripn & " - To be recorded by " & DavaoToolStripMenuItem.Text & "." & vbCrLf & "Refresh list.", MsgBoxStyle.Information, "")

                grdstep9.Rows(selectedrow).Cells(5).Value = DavaoToolStripMenuItem.Text
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub BacolodToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BacolodToolStripMenuItem.Click
        Try
            pass = False
            confirmrecordedby.GroupBox1.Text = login.neym
            confirmrecordedby.ShowDialog()
            If pass = True Then
                Dim tripn As String = grdstep9.Rows(selectedrow).Cells(1).Value.ToString
                'MsgBox(grdstep9.Rows(selectedrow).Cells(1).Value.ToString)

                sql = "Update tbldispatchsum set whsename9='" & BacolodToolStripMenuItem.Text & "' where tripnum='" & tripn & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                sql = "Insert into tblwhsenamestp9 (tripnum, whsename9, datemodified, modifiedby, status) values ('" & tripn & "', '" & BacolodToolStripMenuItem.Text & "', GetDate(), '" & login.cashier & "', '1')"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Trip# " & tripn & " - To be recorded by " & BacolodToolStripMenuItem.Text & "." & vbCrLf & "Refresh list.", MsgBoxStyle.Information, "")

                grdstep9.Rows(selectedrow).Cells(5).Value = BacolodToolStripMenuItem.Text
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub TaclobanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TaclobanToolStripMenuItem.Click
        Try
            pass = False
            confirmrecordedby.GroupBox1.Text = login.neym
            confirmrecordedby.ShowDialog()
            If pass = True Then
                Dim tripn As String = grdstep9.Rows(selectedrow).Cells(1).Value.ToString
                'MsgBox(grdstep9.Rows(selectedrow).Cells(1).Value.ToString)

                sql = "Update tbldispatchsum set whsename9='" & TaclobanToolStripMenuItem.Text & "' where tripnum='" & tripn & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                sql = "Insert into tblwhsenamestp9 (tripnum, whsename9, datemodified, modifiedby, status) values ('" & tripn & "', '" & TaclobanToolStripMenuItem.Text & "', GetDate(), '" & login.cashier & "', '1')"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Trip# " & tripn & " - To be recorded by " & TaclobanToolStripMenuItem.Text & "." & vbCrLf & "Refresh list.", MsgBoxStyle.Information, "")

                grdstep9.Rows(selectedrow).Cells(5).Value = TaclobanToolStripMenuItem.Text
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Function checkcancel(ByVal tripnumb As String)
        Try
            sql = "Select * from tbltripsum where tripnum='" & tripnumb & "' and status='3'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cancelledtrip = True
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Return cancelledtrip

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Function

    Private Function checkcompleted(ByVal tripnumb As String, ByVal stepnum As String)
        Try
            sql = "Select * from tbldispatchsum where tripnum='" & tripnumb & "' and " & stepnum & "='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                completedstep = True
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Return completedstep

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Function

    Private Sub bgw_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabled = True

        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If

        Dim cmdx As SqlCommand = New SqlCommand(grdsql, connection)
        Dim drx As SqlDataReader = cmdx.ExecuteReader
        While drx.Read
            If Me.InvokeRequired Then
                Dim depart As Boolean = False
                If IsDBNull(drx("timedep")) = False Then
                    depart = True
                End If
                Me.Invoke(m_addRowDelegate, drx("tripsumid"), drx("tripnum"), drx("platenum"), drx("driver"), drx("helper").ToString, drx("datepick"), whatstep, drx("whsename9"), depart)
            Else
                Dim depart As Boolean = False
                If IsDBNull(drx("timedep")) = False Then
                    depart = True
                End If
                AddDGVRow(drx("tripsumid"), drx("tripnum"), drx("platenum"), drx("driver"), drx("helper").ToString, drx("datepick"), whatstep, drx("whsename9"), depart)
            End If
        End While
        drx.Dispose()
        cmdx.Dispose()
        connection.Close()
    End Sub

    Delegate Sub AddRowDelegate(ByVal value0 As Object, ByVal value1 As Object, ByVal value2 As Object, ByVal value3 As Object, ByVal value4 As Object, ByVal value5 As Object, ByVal value6 As Object, ByVal valuestep9 As Object, ByVal valuestep6 As Object)
    Private m_addRowDelegate As AddRowDelegate

    Private Sub AddDGVRow(ByVal val0 As Integer, ByVal val1 As String, ByVal val2 As String, ByVal val3 As String, ByVal val4 As String, ByVal val5 As Date, ByVal val6 As Integer, ByVal valstep9 As String, ByVal valstep6 As Boolean)
        If threadEnabled = True Then
            If Me.InvokeRequired Then
                Me.BeginInvoke(New AddRowDelegate(AddressOf AddDGVRow), val0, val1, val2, val3, val4, val5, val6, valstep9, valstep6)
            Else
                If val6 = 1 Then
                    grdstep1.Rows.Add(val0, val1, val2, val3, val4, val5)
                ElseIf val6 = 2 Then
                    grdstep2.Rows.Add(val0, val1, val2, val3, val4, val5)
                ElseIf val6 = 3 Then
                    grdstep3.Rows.Add(val0, val1, val2, val3, val4, val5)
                ElseIf val6 = 4 Then
                    grdstep4.Rows.Add(val0, val1, val2, val3, val4, val5)
                ElseIf val6 = 5 Then
                    grdstep5.Rows.Add(val0, val1, val2, val3, val4, val5)
                ElseIf val6 = 6 Then
                    grdstep6.Rows.Add(val0, val1, val2, val3, val4, val5, valstep6)
                ElseIf val6 = 7 Then
                    grdstep7.Rows.Add(val0, val1, val2, val3, val4, val5)
                ElseIf val6 = 8 Then
                    grdstep8.Rows.Add(val0, val1, val2, val3, val4, val5)
                ElseIf val6 = 9 Then
                    grdstep9.Rows.Add(val0, val1, val2, val3, val4, valstep9, val5)
                End If
            End If
        End If
    End Sub

    Private Sub bgw_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        '/lblloading.Visible = False
        If e.Error IsNot Nothing Then
            Me.Cursor = Cursors.Default
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            Me.Cursor = Cursors.Default
            MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            Me.Cursor = Cursors.Default
            If whatstep = 1 Then
                grdstep1.SuspendLayout()
                grdstep1.ResumeLayout()
                gstep1.Enabled = True
                lblload1.Visible = False
                If grdstep1.Rows.Count = 0 Then
                    zero1()
                    grp1.Enabled = False
                Else
                    grp1.Enabled = True
                    Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                    grdstep1.Rows(0).Cells(1).Selected = True
                    grdstep1_CellClick(grdstep1, eventArgs)
                End If

            ElseIf whatstep = 2 Then
                grdstep2.SuspendLayout()
                grdstep2.ResumeLayout()
                gstep2.Enabled = True
                lblload2.Visible = False
                If grdstep2.Rows.Count = 0 Then
                    zero2()
                    grp2.Enabled = False
                Else
                    grp2.Enabled = True
                    Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                    grdstep2.Rows(0).Cells(1).Selected = True
                    grdstep2_CellClick(grdstep2, eventArgs)
                End If

            ElseIf whatstep = 3 Then
                grdstep3.SuspendLayout()
                grdstep3.ResumeLayout()
                gstep3.Enabled = True
                lblload3.Visible = False
                If grdstep3.Rows.Count = 0 Then
                    zero3()
                    grp3.Enabled = False
                Else
                    grp3.Enabled = True
                    Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                    grdstep3.Rows(0).Cells(1).Selected = True
                    grdstep3_CellClick(grdstep3, eventArgs)
                End If

            ElseIf whatstep = 4 Then
                grdstep4.SuspendLayout()
                grdstep4.ResumeLayout()
                gstep4.Enabled = True
                lblload4.Visible = False
                If grdstep4.Rows.Count = 0 Then
                    zero4()
                    grp4.Enabled = False
                Else
                    grp4.Enabled = True
                    Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                    grdstep4.Rows(0).Cells(1).Selected = True
                    grdstep4_CellClick(grdstep4, eventArgs)
                End If

            ElseIf whatstep = 5 Then
                grdstep5.SuspendLayout()
                grdstep5.ResumeLayout()
                gstep5.Enabled = True
                lblload5.Visible = False
                If grdstep5.Rows.Count = 0 Then
                    zero5()
                    grp5.Enabled = False
                Else
                    grp5.Enabled = True
                    Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                    grdstep5.Rows(0).Cells(1).Selected = True
                    grdstep5_CellClick(grdstep5, eventArgs)
                End If

            ElseIf whatstep = 6 Then
                grdstep6.SuspendLayout()
                grdstep6.ResumeLayout()
                gstep6.Enabled = True
                lblload6.Visible = False
                If grdstep6.Rows.Count = 0 Then
                    zero6()
                    grp6.Enabled = False
                Else
                    grp6.Enabled = True
                    Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                    grdstep6.Rows(0).Cells(1).Selected = True
                    grdstep6_CellClick(grdstep6, eventArgs)
                End If

            ElseIf whatstep = 7 Then
                grdstep7.SuspendLayout()
                grdstep7.ResumeLayout()
                gstep7.Enabled = True
                lblload7.Visible = False
                If grdstep7.Rows.Count = 0 Then
                    zero7()
                    grp7.Enabled = False
                Else
                    'grp7.Enabled = True
                    'Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                    'grdstep7.Rows(0).Cells(1).Selected = True
                    'grdstep7_CellClick(grdstep7, eventArgs)

                    grp7.Enabled = True
                    If row7 > -1 And cnf7 = True Then

                        Dim MyDesiredIndex As Integer

                        If row7 <= grdstep7.RowCount - 1 Then
                            MyDesiredIndex = row7

                            Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                            grdstep7.Rows(MyDesiredIndex).Cells(1).Selected = True
                            grdstep7_CellClick(grdstep7, eventArgs)

                        ElseIf row7 = grdstep7.RowCount Then
                            MyDesiredIndex = row7 - 1

                            Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                            grdstep7.Rows(MyDesiredIndex).Cells(1).Selected = True
                            grdstep7_CellClick(grdstep7, eventArgs)
                        End If

                    Else  'If row7 = -1 Then
                        Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                        grdstep7.Rows(0).Cells(1).Selected = True
                        grdstep7_CellClick(grdstep7, eventArgs)
                    End If
                End If

                cnf7 = False

            ElseIf whatstep = 8 Then
                grdstep8.SuspendLayout()
                grdstep8.ResumeLayout()
                gstep8.Enabled = True
                lblload8.Visible = False
                If grdstep8.Rows.Count = 0 Then
                    zero8()
                    grp8.Enabled = False
                Else
                    grp8.Enabled = True
                    Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                    grdstep8.Rows(0).Cells(1).Selected = True
                    grdstep8_CellClick(grdstep8, eventArgs)
                End If

            ElseIf whatstep = 9 Then
                grdstep9.SuspendLayout()
                grdstep9.ResumeLayout()
                gstep9.Enabled = True
                lblload9.Visible = False
                If grdstep9.Rows.Count = 0 Then
                    zero9()
                    grp9.Enabled = False
                Else
                    grp9.Enabled = True
                    If row9 > -1 And cnf9 = True Then

                        Dim MyDesiredIndex As Integer

                        If row9 <= grdstep9.RowCount - 1 Then
                            MyDesiredIndex = row9

                            Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                            grdstep9.Rows(MyDesiredIndex).Cells(1).Selected = True
                            grdstep9_CellClick(grdstep9, eventArgs)

                        ElseIf row9 = grdstep9.RowCount Then
                            MyDesiredIndex = row9 - 1

                            Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                            grdstep9.Rows(MyDesiredIndex).Cells(1).Selected = True
                            grdstep9_CellClick(grdstep9, eventArgs)
                        End If

                    Else  'If row9 = -1 Then
                        Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                        grdstep9.Rows(0).Cells(1).Selected = True
                        grdstep9_CellClick(grdstep9, eventArgs)
                    End If
                End If

                If grdstep9.Rows.Count = 0 Then
                    grp9.Enabled = False
                Else
                    grp9.Enabled = True
                End If

                cnf9 = False
            End If
            '/Me.WindowState = FormWindowState.Maximized
        End If
    End Sub

    Private Sub bgw_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label12.Text = e.ProgressPercentage.ToString() & "% complete"
        gstep1.Enabled = False
        lblload1.Visible = True
        gstep2.Enabled = False
        lblload2.Visible = True
        gstep3.Enabled = False
        lblload3.Visible = True
        gstep4.Enabled = False
        lblload4.Visible = True
        gstep5.Enabled = False
        lblload5.Visible = True
        gstep6.Enabled = False
        lblload6.Visible = True
        gstep7.Enabled = False
        lblload7.Visible = True
        gstep8.Enabled = False
        lblload8.Visible = True
        gstep9.Enabled = False
        lblload9.Visible = True
        '/Me.WindowState = FormWindowState.Normal
    End Sub

    Private Sub tripinfo1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles tripinfo1.LinkClicked
        viewtripinfo.lblid.Text = lbltripnum1.Tag
        viewtripinfo.lbltripnum.Text = lbltripnum1.Text
        viewtripinfo.Text = "Trip Information (" & lbltripnum1.Text & ")"
        viewtripinfo.ShowDialog()
    End Sub

    Private Sub tripinfo2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles tripinfo2.LinkClicked
        viewtripinfo.lblid.Text = lbltripnum2.Tag
        viewtripinfo.lbltripnum.Text = lbltripnum2.Text
        viewtripinfo.Text = "Trip Information (" & lbltripnum2.Text & ")"
        viewtripinfo.ShowDialog()
    End Sub

    Private Sub tripinfo3_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles tripinfo3.LinkClicked
        viewtripinfo.lblid.Text = lbltripnum3.Tag
        viewtripinfo.lbltripnum.Text = lbltripnum3.Text
        viewtripinfo.Text = "Trip Information (" & lbltripnum3.Text & ")"
        viewtripinfo.ShowDialog()
    End Sub

    Private Sub tripinfo4_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles tripinfo4.LinkClicked
        viewtripinfo.lblid.Text = lbltripnum4.Tag
        viewtripinfo.lbltripnum.Text = lbltripnum4.Text
        viewtripinfo.Text = "Trip Information (" & lbltripnum4.Text & ")"
        viewtripinfo.ShowDialog()
    End Sub

    Private Sub tripinfo5_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles tripinfo5.LinkClicked
        viewtripinfo.lblid.Text = lbltripnum5.Tag
        viewtripinfo.lbltripnum.Text = lbltripnum5.Text
        viewtripinfo.Text = "Trip Information (" & lbltripnum5.Text & ")"
        viewtripinfo.ShowDialog()
    End Sub

    Private Sub tripinfo7_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles tripinfo7.LinkClicked
        viewtripinfo.lblid.Text = lbltripnum7.Tag
        viewtripinfo.lbltripnum.Text = lbltripnum7.Text
        viewtripinfo.Text = "Trip Information (" & lbltripnum7.Text & ")"
        viewtripinfo.ShowDialog()
        triplink7 = True
    End Sub

    Private Sub tripinfo8_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles tripinfo8.LinkClicked
        viewtripinfo.lblid.Text = lbltripnum8.Tag
        viewtripinfo.lbltripnum.Text = lbltripnum8.Text
        viewtripinfo.Text = "Trip Information (" & lbltripnum8.Text & ")"
        viewtripinfo.ShowDialog()
        triplink8 = True
    End Sub

    Private Sub tripinfo9_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles tripinfo9.LinkClicked
        viewtripinfo.lblid.Text = lbltripnum9.Tag
        viewtripinfo.lbltripnum.Text = lbltripnum9.Text
        viewtripinfo.Text = "Trip Information (" & lbltripnum9.Text & ")"
        viewtripinfo.ShowDialog()
        triplink9 = True
    End Sub

    Private Sub grdtrans9_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles grdtrans9.RowPostPaint
        Exit Sub
        If e.RowIndex > -1 Then
            Dim checkCellresched As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(4), DataGridViewCheckBoxCell)
            Dim checkCellcmemo As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(5), DataGridViewCheckBoxCell)
            Dim checkCellrecord As DataGridViewCheckBoxCell = CType(grdtrans9.Rows(e.RowIndex).Cells(17), DataGridViewCheckBoxCell)

            If checkCellresched.Value = True Then
                grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Plum
            ElseIf checkCellcmemo.Value = True Then
                grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Orange
            ElseIf checkCellrecord.Value = True Then
                grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Yellow
            Else
                If e.RowIndex Mod 2 = 0 Then
                    grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.White
                Else
                    grdtrans9.Rows(e.RowIndex).DefaultCellStyle.BackColor = Drawing.Color.FromArgb(219, 255, 219)
                End If
            End If
        End If
    End Sub

    Private Sub txtaddpo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtaddpo.TextChanged

    End Sub

    Private Sub btnpo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpo.Click
        Try
            If btnpo.Tag = "NOT" And (login.neym = "Supervisor" Or login.neym = "Logistics Staff" Or login.neym = "Administrator") Then
               
                sql = "Select TOP 1 * from tbladdpo where tripnum='" & lbltripnum2.Text & "' order by adpoid DESC"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    If dr("status") = 1 Then
                        If Val(txtaddpo.Text) = dr("addpo") Then
                            btnpo.Image = ImageList1.Images(0)
                            btnpo.Tag = "OK"
                            MsgBox("Additional diesel amount is already approved.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If
                    End If
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                pass = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If pass = True Then
                    'pagumabot dito meaning hindi pa approved
                    sql = "Insert into tbladdpo (tripnum, addpo, remarks, datecreated, createdby, status) values ('" & lbltripnum2.Text & "', '" & txtaddpo.Text & "', '', GetDate(), '" & login.cashier & "', '1')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()

                    MsgBox("Additional diesel amount is approved.", MsgBoxStyle.Exclamation, "")
                    btnpo.Image = ImageList1.Images(0)
                    btnpo.Tag = "OK"
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub btntrip9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntrip9.Click
        Dim found As Boolean = False
        For Each row As DataGridViewRow In grdstep9.Rows
            If grdstep9.Rows(row.Index).Cells(1).Value = lbls9.Text & Trim(txts9.Text) Then
                found = True
                grdstep9.ClearSelection()
                '/grdstep9.CurrentCell = grdstep9.Rows(row.Index).Cells(1)
                '/grdstep9.Rows(row.Index).Selected = True

                Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                grdstep9.Rows(row.Index).Cells(1).Selected = True
                grdstep9_CellClick(grdstep9, eventArgs)
                txts9.Text = ""
                Exit Sub
            End If
        Next

        If found = False Then
            MsgBox("Cannot found trip# " & lbls9.Text & Trim(txts9.Text), MsgBoxStyle.Exclamation, "")
            txts9.Text = ""
        End If
    End Sub

    Private Sub txts9_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txts9.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btntrip9.PerformClick()
        End If
    End Sub

    Private Sub txts9_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txts9.TextChanged
        Dim charactersDisallowed As String = "0123456789-"
        Dim theText As String = txts9.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txts9.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txts9.Text.Length - 1
            Letter = txts9.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txts9.Text = theText
        txts9.Select(SelectionIndex - Change, 0)

        Dim str As String
        str = txts9.Text
        If str.Length <> 0 Then
            Dim answer As Char
            answer = str.Substring(0, 1)
            If answer = "-" Then
                str = str.Substring(1, str.Length - 1)
                txts9.Text = str
            End If
        End If
    End Sub

    Private Sub btntrip7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntrip7.Click
        Dim found As Boolean = False
        For Each row As DataGridViewRow In grdstep7.Rows
            If grdstep7.Rows(row.Index).Cells(1).Value = lbls7.Text & Trim(txts7.Text) Then
                found = True
                grdstep7.ClearSelection()
                '/grdstep7.CurrentCell = grdstep7.Rows(row.Index).Cells(1)
                '/grdstep7.Rows(row.Index).Selected = True

                Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                grdstep7.Rows(row.Index).Cells(1).Selected = True
                grdstep7_CellClick(grdstep7, eventArgs)
                txts7.Text = ""
                Exit Sub
            End If
        Next

        If found = False Then
            MsgBox("Cannot found trip# " & lbls7.Text & Trim(txts7.Text), MsgBoxStyle.Exclamation, "")
            txts7.Text = ""
        End If
    End Sub

    Private Sub txts7_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txts7.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btntrip7.PerformClick()
        End If
    End Sub

    Private Sub txts7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txts7.TextChanged
        Dim charactersDisallowed As String = "0123456789-"
        Dim theText As String = txts7.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txts7.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txts7.Text.Length - 1
            Letter = txts7.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txts7.Text = theText
        txts7.Select(SelectionIndex - Change, 0)

        Dim str As String
        str = txts7.Text
        If str.Length <> 0 Then
            Dim answer As Char
            answer = str.Substring(0, 1)
            If answer = "-" Then
                str = str.Substring(1, str.Length - 1)
                txts7.Text = str
            End If
        End If
    End Sub

    Private Sub btndis_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndis.Click
        Try
            sql = "Select TOP 1 comstp8 from tbldispatchsum inner join tbltripsum on tbltripsum.tripnum=tbldispatchsum.tripnum"
            sql = sql & " where tbltripsum.status<>'3' and platenum='" & lblplate2.Text & "' and tripsumid<'" & grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(0).Value & "' order by tripsumid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                MsgBox("Previous Trip: " & dr("comstp8").ToString, MsgBoxStyle.Exclamation, "")
                btndis.Tag = 1
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub btnodo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnodo.Click
        Try
            sql = "Select TOP 1 comstp8 from tbldispatchsum inner join tbltripsum on tbltripsum.tripnum=tbldispatchsum.tripnum"
            sql = sql & " where tbltripsum.status<>'3' and platenum='" & lblplate1.Text & "' and tripsumid<'" & grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(0).Value & "' order by tripsumid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                MsgBox("Previous Trip: " & dr("comstp8").ToString, MsgBoxStyle.Exclamation, "")
                btnodo.Tag = 1
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub link2to7_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles link2to7.LinkClicked
        If lbltype7.Text <> "" And lbltype7.Text <> "CUSTOMER TRUCK" And lbltype7.Text <> "TRUCKING TRUCK" And lbltype7.Text <> "TYPE" Then
            viewstep1.lblstep.Text = "2"
            viewstep1.Text = "View Step2 ( TRIP# " & lbltripnum7.Text & " )"
            viewstep1.lbltripnum1.Text = lbltripnum7.Text
            viewstep1.lblplate1.Text = lblplate7.Text
            viewstep1.lbltype1.Text = lbltype7.Text
            '/viewstep1.txtdes.Text = txtdes.Text
            viewstep1.finish()
            viewstep1.ShowDialog()
        Else
            MsgBox("Step 2 is skipped.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub link2to9_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles link2to9.LinkClicked
        If lbltype9.Text <> "" And lbltype9.Text <> "CUSTOMER TRUCK" And lbltype9.Text <> "TRUCKING TRUCK" And lbltype9.Text <> "TYPE" Then
            viewstep1.lblstep.Text = "2"
            viewstep1.Text = "View Step2 ( TRIP# " & lbltripnum9.Text & " )"
            viewstep1.lbltripnum1.Text = lbltripnum9.Text
            viewstep1.lblplate1.Text = lblplate9.Text
            viewstep1.lbltype1.Text = lbltype9.Text
            '/viewstep1.txtdes.Text = txtdes.Text
            viewstep1.finish()
            viewstep1.ShowDialog()
        Else
            MsgBox("Step 2 is skipped.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub cmbwhse9_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbwhse9.SelectedIndexChanged

    End Sub

    Private Sub btninch8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninch8.Click
        Try
            If login.neym <> "Motorpool Inspector" And login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            txtdieselend.Enabled = False
            Panelinch8.Visible = True
            txtinch8.Focus()
            btnconfirm8.Enabled = False

        Catch ex As Exception

        End Try
    End Sub

    Private Sub btninch8ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninch8ok.Click
        Try
            If IsNumeric(txtinch8.Text) = True Then
                If Val(txtinch8.Text) <= 0 Then
                    MsgBox("Invalid inches.", MsgBoxStyle.Exclamation, "")
                    txtinch8.Focus()
                    Exit Sub
                End If
            Else
                MsgBox("Invalid inches.", MsgBoxStyle.Exclamation, "")
                txtinch8.Focus()
                Exit Sub
            End If

            Dim literperinch As Double
            sql = "Select liter from tbldiesel inner join tblgeneral on tbldiesel.genid=tblgeneral.genid where platenum='" & lblplate8.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                literperinch = dr("liter")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            'MsgBox(Val(Trim(txtinch8.Text)))
            txtdieselend.Text = (literperinch * Val(Trim(txtinch8.Text))).ToString("n2") 'Math.Round(literperinch * Val(Trim(txtinch8.Text)), 2)
            txtdieselend.Enabled = True
            Panelinch8.Visible = False
            btnconfirm8.Enabled = True

            Me.Cursor = Cursors.Default
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub btninch8cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninch8cancel.Click
        txtdieselend.Enabled = True
        Panelinch8.Visible = False
        btnconfirm8.Enabled = True
    End Sub

    Private Sub txtinch8_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtinch8.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btninch8ok.PerformClick()
        End If
    End Sub

    Private Sub btninch2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninch2.Click
        Try
            If login.neym <> "Motorpool Inspector" And login.neym <> "Inspector" And login.neym <> "Diesel Controller" And login.neym <> "Manager" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            txtdiesel.Enabled = False
            Panelinch2.Visible = True
            txtinch2.Focus()
            btnconfirm2.Enabled = False

        Catch ex As Exception

        End Try
    End Sub

    Private Sub btninch2ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninch2ok.Click
        Try
            If IsNumeric(txtinch2.Text) = True Then
                If Val(txtinch2.Text) <= 0 Then
                    MsgBox("Invalid inches.", MsgBoxStyle.Exclamation, "")
                    txtinch2.Focus()
                    Exit Sub
                End If
            Else
                MsgBox("Invalid inches.", MsgBoxStyle.Exclamation, "")
                txtinch2.Focus()
                Exit Sub
            End If

            Dim literperinch As Double
            sql = "Select liter from tbldiesel inner join tblgeneral on tbldiesel.genid=tblgeneral.genid where platenum='" & lblplate2.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                literperinch = dr("liter")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            'MsgBox(Val(Trim(txtinch2.Text)))
            txtdiesel.Text = (literperinch * Val(Trim(txtinch2.Text))).ToString("n2") 'Math.Round(literperinch * Val(Trim(txtinch2.Text)), 2)
            txtdiesel.Enabled = True
            Panelinch2.Visible = False

            Me.Cursor = Cursors.Default
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub btninch2cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninch2cancel.Click
        txtdiesel.Enabled = True
        Panelinch2.Visible = False
    End Sub

    Private Sub txtinch2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtinch2.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btninch2ok.PerformClick()
        End If
    End Sub
End Class