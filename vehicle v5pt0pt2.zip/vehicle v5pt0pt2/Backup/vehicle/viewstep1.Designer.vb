﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class viewstep1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DataGridViewCellStyle131 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle132 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle133 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle134 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle135 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(viewstep1))
        Dim DataGridViewCellStyle136 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle137 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle138 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle139 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle140 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.grdcom = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Button1 = New System.Windows.Forms.Button
        Me.lblpick = New System.Windows.Forms.Label
        Me.lblimgname1 = New System.Windows.Forms.Label
        Me.lblimgdate1 = New System.Windows.Forms.Label
        Me.tripinfolink = New System.Windows.Forms.LinkLabel
        Me.lblloading = New System.Windows.Forms.Label
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.txtlabor = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.txtdes = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.lbltype1 = New System.Windows.Forms.Label
        Me.picwarn = New System.Windows.Forms.PictureBox
        Me.picinfo = New System.Windows.Forms.PictureBox
        Me.rbwarn = New System.Windows.Forms.RadioButton
        Me.rbok = New System.Windows.Forms.RadioButton
        Me.cmbtrans4 = New System.Windows.Forms.ComboBox
        Me.grdtrans4 = New System.Windows.Forms.DataGridView
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column10 = New System.Windows.Forms.DataGridViewLinkColumn
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column21 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.lblsaveby = New System.Windows.Forms.Label
        Me.lbllogis = New System.Windows.Forms.Label
        Me.btncomment = New System.Windows.Forms.Button
        Me.txtcomment = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.lblfinishby = New System.Windows.Forms.Label
        Me.lblstartby = New System.Windows.Forms.Label
        Me.txtrescue = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtrems = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblsave = New System.Windows.Forms.Label
        Me.lblfinish = New System.Windows.Forms.Label
        Me.lblstart = New System.Windows.Forms.Label
        Me.lbldraft = New System.Windows.Forms.Label
        Me.lbl2 = New System.Windows.Forms.Label
        Me.lbl1 = New System.Windows.Forms.Label
        Me.lblstep = New System.Windows.Forms.Label
        Me.lbltripnum1 = New System.Windows.Forms.Label
        Me.lblplate1 = New System.Windows.Forms.Label
        Me.btnimgdl1 = New System.Windows.Forms.Button
        Me.lblimgid1 = New System.Windows.Forms.Label
        Me.btnimgset1 = New System.Windows.Forms.Button
        Me.btnimgfull1 = New System.Windows.Forms.Button
        Me.btnimgupdate1 = New System.Windows.Forms.Button
        Me.txtimg1 = New System.Windows.Forms.TextBox
        Me.imgpanel1 = New System.Windows.Forms.Panel
        Me.imgbox1 = New System.Windows.Forms.PictureBox
        Me.btnimgremove1 = New System.Windows.Forms.Button
        Me.btnimgadd1 = New System.Windows.Forms.Button
        Me.btnimgcancel1 = New System.Windows.Forms.Button
        Me.btnimgrefresh1 = New System.Windows.Forms.Button
        Me.btnimgrename1 = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txt16 = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.txt15 = New System.Windows.Forms.TextBox
        Me.txt14 = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.txt13 = New System.Windows.Forms.TextBox
        Me.txt12 = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txt11 = New System.Windows.Forms.TextBox
        Me.txt10 = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.txt5 = New System.Windows.Forms.TextBox
        Me.txt6 = New System.Windows.Forms.TextBox
        Me.txt7 = New System.Windows.Forms.TextBox
        Me.txt9 = New System.Windows.Forms.TextBox
        Me.txt8 = New System.Windows.Forms.TextBox
        Me.txt4 = New System.Windows.Forms.TextBox
        Me.txt3 = New System.Windows.Forms.TextBox
        Me.lbl8 = New System.Windows.Forms.Label
        Me.lbl5 = New System.Windows.Forms.Label
        Me.lbl4 = New System.Windows.Forms.Label
        Me.lbl7 = New System.Windows.Forms.Label
        Me.lbl3 = New System.Windows.Forms.Label
        Me.lbl6 = New System.Windows.Forms.Label
        Me.lbl9 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.EditSOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditPOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditITRToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditSWSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewRefHistoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.btnodobeg = New System.Windows.Forms.Button
        Me.btnodoend = New System.Windows.Forms.Button
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewEditHistoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GroupBox3.SuspendLayout()
        CType(Me.grdcom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.picwarn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picinfo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdtrans4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgbox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.White
        Me.GroupBox3.Controls.Add(Me.grdcom)
        Me.GroupBox3.Controls.Add(Me.Button1)
        Me.GroupBox3.Controls.Add(Me.lblpick)
        Me.GroupBox3.Controls.Add(Me.lblimgname1)
        Me.GroupBox3.Controls.Add(Me.lblimgdate1)
        Me.GroupBox3.Controls.Add(Me.tripinfolink)
        Me.GroupBox3.Controls.Add(Me.lblloading)
        Me.GroupBox3.Controls.Add(Me.Panel4)
        Me.GroupBox3.Controls.Add(Me.txtdes)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.lbltype1)
        Me.GroupBox3.Controls.Add(Me.picwarn)
        Me.GroupBox3.Controls.Add(Me.picinfo)
        Me.GroupBox3.Controls.Add(Me.rbwarn)
        Me.GroupBox3.Controls.Add(Me.rbok)
        Me.GroupBox3.Controls.Add(Me.cmbtrans4)
        Me.GroupBox3.Controls.Add(Me.grdtrans4)
        Me.GroupBox3.Controls.Add(Me.lblsaveby)
        Me.GroupBox3.Controls.Add(Me.lbllogis)
        Me.GroupBox3.Controls.Add(Me.btncomment)
        Me.GroupBox3.Controls.Add(Me.txtcomment)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.lblfinishby)
        Me.GroupBox3.Controls.Add(Me.lblstartby)
        Me.GroupBox3.Controls.Add(Me.txtrescue)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.txtrems)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.lblsave)
        Me.GroupBox3.Controls.Add(Me.lblfinish)
        Me.GroupBox3.Controls.Add(Me.lblstart)
        Me.GroupBox3.Controls.Add(Me.lbldraft)
        Me.GroupBox3.Controls.Add(Me.lbl2)
        Me.GroupBox3.Controls.Add(Me.lbl1)
        Me.GroupBox3.Controls.Add(Me.lblstep)
        Me.GroupBox3.Controls.Add(Me.lbltripnum1)
        Me.GroupBox3.Controls.Add(Me.lblplate1)
        Me.GroupBox3.Controls.Add(Me.btnimgdl1)
        Me.GroupBox3.Controls.Add(Me.lblimgid1)
        Me.GroupBox3.Controls.Add(Me.btnimgset1)
        Me.GroupBox3.Controls.Add(Me.btnimgfull1)
        Me.GroupBox3.Controls.Add(Me.btnimgupdate1)
        Me.GroupBox3.Controls.Add(Me.txtimg1)
        Me.GroupBox3.Controls.Add(Me.imgpanel1)
        Me.GroupBox3.Controls.Add(Me.imgbox1)
        Me.GroupBox3.Controls.Add(Me.btnimgremove1)
        Me.GroupBox3.Controls.Add(Me.btnimgadd1)
        Me.GroupBox3.Controls.Add(Me.btnimgcancel1)
        Me.GroupBox3.Controls.Add(Me.btnimgrefresh1)
        Me.GroupBox3.Controls.Add(Me.btnimgrename1)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(3, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(879, 650)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Photos"
        '
        'grdcom
        '
        Me.grdcom.AllowUserToAddRows = False
        Me.grdcom.AllowUserToDeleteRows = False
        DataGridViewCellStyle131.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdcom.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle131
        Me.grdcom.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdcom.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdcom.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdcom.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle132.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle132.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle132.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle132.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle132.NullValue = Nothing
        DataGridViewCellStyle132.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle132.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle132.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdcom.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle132
        Me.grdcom.ColumnHeadersHeight = 25
        Me.grdcom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdcom.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.Column6, Me.Column7, Me.Column8})
        DataGridViewCellStyle133.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle133.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle133.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle133.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle133.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle133.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle133.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdcom.DefaultCellStyle = DataGridViewCellStyle133
        Me.grdcom.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdcom.EnableHeadersVisualStyles = False
        Me.grdcom.GridColor = System.Drawing.Color.Salmon
        Me.grdcom.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdcom.Location = New System.Drawing.Point(70, 429)
        Me.grdcom.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdcom.MultiSelect = False
        Me.grdcom.Name = "grdcom"
        Me.grdcom.ReadOnly = True
        Me.grdcom.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle134.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle134.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle134.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle134.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle134.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle134.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle134.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdcom.RowHeadersDefaultCellStyle = DataGridViewCellStyle134
        Me.grdcom.RowHeadersWidth = 10
        Me.grdcom.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle135.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle135.NullValue = Nothing
        DataGridViewCellStyle135.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdcom.RowsDefaultCellStyle = DataGridViewCellStyle135
        Me.grdcom.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdcom.Size = New System.Drawing.Size(524, 62)
        Me.grdcom.TabIndex = 109
        Me.grdcom.Visible = False
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.Frozen = True
        Me.DataGridViewTextBoxColumn1.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Visible = False
        '
        'Column6
        '
        Me.Column6.HeaderText = "Comment"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        Me.Column6.Width = 400
        '
        'Column7
        '
        Me.Column7.HeaderText = "Logistics Staff"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        '
        'Column8
        '
        Me.Column8.HeaderText = "Date and Time"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(798, 580)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 108
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'lblpick
        '
        Me.lblpick.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblpick.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblpick.Font = New System.Drawing.Font("HoloLens MDL2 Assets", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpick.Location = New System.Drawing.Point(600, 20)
        Me.lblpick.Name = "lblpick"
        Me.lblpick.Size = New System.Drawing.Size(273, 38)
        Me.lblpick.TabIndex = 106
        Me.lblpick.Text = "PICKUP TRIP ONLY"
        Me.lblpick.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgname1
        '
        Me.lblimgname1.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgname1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgname1.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgname1.Location = New System.Drawing.Point(744, 293)
        Me.lblimgname1.Name = "lblimgname1"
        Me.lblimgname1.Size = New System.Drawing.Size(129, 20)
        Me.lblimgname1.TabIndex = 105
        Me.lblimgname1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgdate1
        '
        Me.lblimgdate1.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgdate1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgdate1.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgdate1.Location = New System.Drawing.Point(600, 293)
        Me.lblimgdate1.Name = "lblimgdate1"
        Me.lblimgdate1.Size = New System.Drawing.Size(138, 20)
        Me.lblimgdate1.TabIndex = 104
        Me.lblimgdate1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tripinfolink
        '
        Me.tripinfolink.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tripinfolink.AutoSize = True
        Me.tripinfolink.Location = New System.Drawing.Point(798, 628)
        Me.tripinfolink.Name = "tripinfolink"
        Me.tripinfolink.Size = New System.Drawing.Size(75, 14)
        Me.tripinfolink.TabIndex = 99
        Me.tripinfolink.TabStop = True
        Me.tripinfolink.Text = "View Trip Info"
        '
        'lblloading
        '
        Me.lblloading.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblloading.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblloading.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblloading.Location = New System.Drawing.Point(7, 162)
        Me.lblloading.Name = "lblloading"
        Me.lblloading.Size = New System.Drawing.Size(585, 154)
        Me.lblloading.TabIndex = 98
        Me.lblloading.Text = "Loading..."
        Me.lblloading.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel4.BackColor = System.Drawing.Color.LightGreen
        Me.Panel4.Controls.Add(Me.txtlabor)
        Me.Panel4.Controls.Add(Me.Label10)
        Me.Panel4.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel4.Location = New System.Drawing.Point(600, 543)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(273, 28)
        Me.Panel4.TabIndex = 97
        '
        'txtlabor
        '
        Me.txtlabor.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtlabor.BackColor = System.Drawing.Color.White
        Me.txtlabor.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.txtlabor.Location = New System.Drawing.Point(154, 3)
        Me.txtlabor.Name = "txtlabor"
        Me.txtlabor.ReadOnly = True
        Me.txtlabor.Size = New System.Drawing.Size(115, 21)
        Me.txtlabor.TabIndex = 76
        Me.txtlabor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label10
        '
        Me.Label10.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label10.Location = New System.Drawing.Point(3, 6)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(122, 15)
        Me.Label10.TabIndex = 75
        Me.Label10.Text = "Loading No. of Labor"
        '
        'txtdes
        '
        Me.txtdes.BackColor = System.Drawing.Color.White
        Me.txtdes.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtdes.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdes.Location = New System.Drawing.Point(83, 143)
        Me.txtdes.Name = "txtdes"
        Me.txtdes.ReadOnly = True
        Me.txtdes.Size = New System.Drawing.Size(509, 14)
        Me.txtdes.TabIndex = 96
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 142)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 15)
        Me.Label3.TabIndex = 95
        Me.Label3.Text = "Destination:"
        '
        'lbltype1
        '
        Me.lbltype1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbltype1.BackColor = System.Drawing.Color.Transparent
        Me.lbltype1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype1.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltype1.Location = New System.Drawing.Point(413, 21)
        Me.lbltype1.Name = "lbltype1"
        Me.lbltype1.Size = New System.Drawing.Size(181, 38)
        Me.lbltype1.TabIndex = 94
        Me.lbltype1.Text = "TYPE"
        Me.lbltype1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'picwarn
        '
        Me.picwarn.Image = CType(resources.GetObject("picwarn.Image"), System.Drawing.Image)
        Me.picwarn.Location = New System.Drawing.Point(602, 616)
        Me.picwarn.Name = "picwarn"
        Me.picwarn.Size = New System.Drawing.Size(19, 22)
        Me.picwarn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picwarn.TabIndex = 93
        Me.picwarn.TabStop = False
        Me.picwarn.Visible = False
        '
        'picinfo
        '
        Me.picinfo.Image = CType(resources.GetObject("picinfo.Image"), System.Drawing.Image)
        Me.picinfo.Location = New System.Drawing.Point(602, 588)
        Me.picinfo.Name = "picinfo"
        Me.picinfo.Size = New System.Drawing.Size(19, 22)
        Me.picinfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picinfo.TabIndex = 92
        Me.picinfo.TabStop = False
        Me.picinfo.Visible = False
        '
        'rbwarn
        '
        Me.rbwarn.AutoSize = True
        Me.rbwarn.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbwarn.Location = New System.Drawing.Point(627, 618)
        Me.rbwarn.Name = "rbwarn"
        Me.rbwarn.Size = New System.Drawing.Size(57, 20)
        Me.rbwarn.TabIndex = 91
        Me.rbwarn.Text = "Warn"
        Me.rbwarn.UseVisualStyleBackColor = True
        Me.rbwarn.Visible = False
        '
        'rbok
        '
        Me.rbok.AutoSize = True
        Me.rbok.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbok.Location = New System.Drawing.Point(627, 590)
        Me.rbok.Name = "rbok"
        Me.rbok.Size = New System.Drawing.Size(61, 20)
        Me.rbok.TabIndex = 90
        Me.rbok.Text = "Inform"
        Me.rbok.UseVisualStyleBackColor = True
        Me.rbok.Visible = False
        '
        'cmbtrans4
        '
        Me.cmbtrans4.FormattingEnabled = True
        Me.cmbtrans4.Location = New System.Drawing.Point(9, 409)
        Me.cmbtrans4.Name = "cmbtrans4"
        Me.cmbtrans4.Size = New System.Drawing.Size(104, 22)
        Me.cmbtrans4.TabIndex = 89
        Me.cmbtrans4.Visible = False
        '
        'grdtrans4
        '
        Me.grdtrans4.AllowUserToAddRows = False
        Me.grdtrans4.AllowUserToDeleteRows = False
        DataGridViewCellStyle136.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdtrans4.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle136
        Me.grdtrans4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdtrans4.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdtrans4.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdtrans4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle137.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle137.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle137.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle137.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle137.NullValue = Nothing
        DataGridViewCellStyle137.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle137.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle137.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans4.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle137
        Me.grdtrans4.ColumnHeadersHeight = 25
        Me.grdtrans4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdtrans4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column9, Me.Column10, Me.Column11, Me.Column15, Me.Column12, Me.Column13, Me.Column14, Me.Column18, Me.Column19, Me.Column2, Me.Column3, Me.Column16, Me.Column17, Me.Column21, Me.Column1, Me.Column4, Me.Column5})
        DataGridViewCellStyle138.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle138.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle138.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle138.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle138.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle138.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle138.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans4.DefaultCellStyle = DataGridViewCellStyle138
        Me.grdtrans4.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdtrans4.EnableHeadersVisualStyles = False
        Me.grdtrans4.GridColor = System.Drawing.Color.Salmon
        Me.grdtrans4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdtrans4.Location = New System.Drawing.Point(6, 321)
        Me.grdtrans4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdtrans4.MultiSelect = False
        Me.grdtrans4.Name = "grdtrans4"
        Me.grdtrans4.ReadOnly = True
        Me.grdtrans4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle139.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle139.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle139.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle139.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle139.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle139.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle139.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans4.RowHeadersDefaultCellStyle = DataGridViewCellStyle139
        Me.grdtrans4.RowHeadersWidth = 10
        Me.grdtrans4.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle140.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle140.NullValue = Nothing
        DataGridViewCellStyle140.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdtrans4.RowsDefaultCellStyle = DataGridViewCellStyle140
        Me.grdtrans4.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdtrans4.Size = New System.Drawing.Size(588, 187)
        Me.grdtrans4.TabIndex = 88
        '
        'Column9
        '
        Me.Column9.Frozen = True
        Me.Column9.HeaderText = "ID"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        Me.Column9.Visible = False
        '
        'Column10
        '
        Me.Column10.ActiveLinkColor = System.Drawing.Color.Black
        Me.Column10.Frozen = True
        Me.Column10.HeaderText = "Transaction #"
        Me.Column10.LinkColor = System.Drawing.Color.Red
        Me.Column10.MinimumWidth = 10
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        Me.Column10.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column10.Width = 130
        '
        'Column11
        '
        Me.Column11.Frozen = True
        Me.Column11.HeaderText = "Reference #"
        Me.Column11.MinimumWidth = 10
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        Me.Column11.Width = 120
        '
        'Column15
        '
        Me.Column15.Frozen = True
        Me.Column15.HeaderText = "Recipient"
        Me.Column15.MinimumWidth = 10
        Me.Column15.Name = "Column15"
        Me.Column15.ReadOnly = True
        Me.Column15.Width = 150
        '
        'Column12
        '
        Me.Column12.HeaderText = "AR #"
        Me.Column12.MinimumWidth = 10
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        Me.Column12.Width = 120
        '
        'Column13
        '
        Me.Column13.HeaderText = "RDR"
        Me.Column13.MinimumWidth = 10
        Me.Column13.Name = "Column13"
        Me.Column13.ReadOnly = True
        Me.Column13.Width = 120
        '
        'Column14
        '
        Me.Column14.HeaderText = "DR#"
        Me.Column14.MinimumWidth = 10
        Me.Column14.Name = "Column14"
        Me.Column14.ReadOnly = True
        Me.Column14.Width = 120
        '
        'Column18
        '
        Me.Column18.HeaderText = "DN#"
        Me.Column18.Name = "Column18"
        Me.Column18.ReadOnly = True
        '
        'Column19
        '
        Me.Column19.HeaderText = "ITR#"
        Me.Column19.Name = "Column19"
        Me.Column19.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.HeaderText = "IT#"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'Column3
        '
        Me.Column3.HeaderText = "GRPO#"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        '
        'Column16
        '
        Me.Column16.HeaderText = "Transaction Type"
        Me.Column16.MinimumWidth = 10
        Me.Column16.Name = "Column16"
        Me.Column16.ReadOnly = True
        Me.Column16.Width = 155
        '
        'Column17
        '
        Me.Column17.HeaderText = "Notes"
        Me.Column17.MinimumWidth = 10
        Me.Column17.Name = "Column17"
        Me.Column17.ReadOnly = True
        Me.Column17.Width = 210
        '
        'Column21
        '
        Me.Column21.HeaderText = "manager"
        Me.Column21.Name = "Column21"
        Me.Column21.ReadOnly = True
        Me.Column21.Visible = False
        '
        'Column1
        '
        Me.Column1.HeaderText = "Date Added to Trip"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 130
        '
        'Column4
        '
        Me.Column4.HeaderText = "Recorded By"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'Column5
        '
        Me.Column5.HeaderText = "Date Recorded"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Width = 130
        '
        'lblsaveby
        '
        Me.lblsaveby.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblsaveby.AutoSize = True
        Me.lblsaveby.Location = New System.Drawing.Point(413, 94)
        Me.lblsaveby.Name = "lblsaveby"
        Me.lblsaveby.Size = New System.Drawing.Size(0, 14)
        Me.lblsaveby.TabIndex = 87
        '
        'lbllogis
        '
        Me.lbllogis.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbllogis.AutoSize = True
        Me.lbllogis.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllogis.Location = New System.Drawing.Point(3, 620)
        Me.lbllogis.Name = "lbllogis"
        Me.lbllogis.Size = New System.Drawing.Size(0, 15)
        Me.lbllogis.TabIndex = 86
        '
        'btncomment
        '
        Me.btncomment.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncomment.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncomment.Image = CType(resources.GetObject("btncomment.Image"), System.Drawing.Image)
        Me.btncomment.Location = New System.Drawing.Point(637, 501)
        Me.btncomment.Name = "btncomment"
        Me.btncomment.Size = New System.Drawing.Size(208, 30)
        Me.btncomment.TabIndex = 85
        Me.btncomment.Text = "Edit Comment"
        Me.btncomment.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncomment.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncomment.UseVisualStyleBackColor = True
        '
        'txtcomment
        '
        Me.txtcomment.BackColor = System.Drawing.Color.White
        Me.txtcomment.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcomment.Location = New System.Drawing.Point(70, 581)
        Me.txtcomment.Multiline = True
        Me.txtcomment.Name = "txtcomment"
        Me.txtcomment.ReadOnly = True
        Me.txtcomment.Size = New System.Drawing.Size(524, 61)
        Me.txtcomment.TabIndex = 84
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(3, 584)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(71, 30)
        Me.Label9.TabIndex = 83
        Me.Label9.Text = "Logistics Comment:"
        '
        'lblfinishby
        '
        Me.lblfinishby.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblfinishby.AutoSize = True
        Me.lblfinishby.Location = New System.Drawing.Point(413, 118)
        Me.lblfinishby.Name = "lblfinishby"
        Me.lblfinishby.Size = New System.Drawing.Size(0, 14)
        Me.lblfinishby.TabIndex = 82
        '
        'lblstartby
        '
        Me.lblstartby.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblstartby.AutoSize = True
        Me.lblstartby.Location = New System.Drawing.Point(413, 71)
        Me.lblstartby.Name = "lblstartby"
        Me.lblstartby.Size = New System.Drawing.Size(0, 14)
        Me.lblstartby.TabIndex = 81
        '
        'txtrescue
        '
        Me.txtrescue.BackColor = System.Drawing.Color.White
        Me.txtrescue.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrescue.Location = New System.Drawing.Point(70, 463)
        Me.txtrescue.Name = "txtrescue"
        Me.txtrescue.ReadOnly = True
        Me.txtrescue.Size = New System.Drawing.Size(261, 21)
        Me.txtrescue.TabIndex = 80
        Me.txtrescue.Visible = False
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 466)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 15)
        Me.Label2.TabIndex = 79
        Me.Label2.Text = "Rescue:"
        Me.Label2.Visible = False
        '
        'txtrems
        '
        Me.txtrems.BackColor = System.Drawing.Color.White
        Me.txtrems.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrems.Location = New System.Drawing.Point(70, 514)
        Me.txtrems.Multiline = True
        Me.txtrems.Name = "txtrems"
        Me.txtrems.ReadOnly = True
        Me.txtrems.Size = New System.Drawing.Size(524, 61)
        Me.txtrems.TabIndex = 78
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 517)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 15)
        Me.Label1.TabIndex = 77
        Me.Label1.Text = "Remarks:"
        '
        'lblsave
        '
        Me.lblsave.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblsave.AutoSize = True
        Me.lblsave.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsave.Location = New System.Drawing.Point(246, 94)
        Me.lblsave.Name = "lblsave"
        Me.lblsave.Size = New System.Drawing.Size(33, 15)
        Me.lblsave.TabIndex = 76
        Me.lblsave.Text = "save"
        '
        'lblfinish
        '
        Me.lblfinish.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblfinish.AutoSize = True
        Me.lblfinish.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfinish.Location = New System.Drawing.Point(246, 118)
        Me.lblfinish.Name = "lblfinish"
        Me.lblfinish.Size = New System.Drawing.Size(37, 15)
        Me.lblfinish.TabIndex = 75
        Me.lblfinish.Text = "finish"
        '
        'lblstart
        '
        Me.lblstart.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblstart.AutoSize = True
        Me.lblstart.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstart.Location = New System.Drawing.Point(246, 71)
        Me.lblstart.Name = "lblstart"
        Me.lblstart.Size = New System.Drawing.Size(31, 15)
        Me.lblstart.TabIndex = 74
        Me.lblstart.Text = "start"
        '
        'lbldraft
        '
        Me.lbldraft.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbldraft.AutoSize = True
        Me.lbldraft.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldraft.Location = New System.Drawing.Point(6, 94)
        Me.lbldraft.Name = "lbldraft"
        Me.lbldraft.Size = New System.Drawing.Size(196, 15)
        Me.lbldraft.TabIndex = 73
        Me.lbldraft.Text = "Time Save as Draft Pre - Inpection:"
        '
        'lbl2
        '
        Me.lbl2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl2.AutoSize = True
        Me.lbl2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2.Location = New System.Drawing.Point(6, 118)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(157, 15)
        Me.lbl2.TabIndex = 72
        Me.lbl2.Text = "Time Finish Pre - Inpection:"
        '
        'lbl1
        '
        Me.lbl1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl1.AutoSize = True
        Me.lbl1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.Location = New System.Drawing.Point(6, 71)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(148, 15)
        Me.lbl1.TabIndex = 69
        Me.lbl1.Text = "Time Start Pre - Inpection:"
        '
        'lblstep
        '
        Me.lblstep.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblstep.AutoSize = True
        Me.lblstep.Location = New System.Drawing.Point(835, 22)
        Me.lblstep.Name = "lblstep"
        Me.lblstep.Size = New System.Drawing.Size(31, 14)
        Me.lblstep.TabIndex = 71
        Me.lblstep.Text = "imgid"
        Me.lblstep.Visible = False
        '
        'lbltripnum1
        '
        Me.lbltripnum1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbltripnum1.BackColor = System.Drawing.Color.Transparent
        Me.lbltripnum1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltripnum1.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltripnum1.Location = New System.Drawing.Point(6, 21)
        Me.lbltripnum1.Name = "lbltripnum1"
        Me.lbltripnum1.Size = New System.Drawing.Size(107, 38)
        Me.lbltripnum1.TabIndex = 70
        Me.lbltripnum1.Text = "Trip#"
        Me.lbltripnum1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbltripnum1.Visible = False
        '
        'lblplate1
        '
        Me.lblplate1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblplate1.BackColor = System.Drawing.Color.Transparent
        Me.lblplate1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate1.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate1.Location = New System.Drawing.Point(6, 21)
        Me.lblplate1.Name = "lblplate1"
        Me.lblplate1.Size = New System.Drawing.Size(408, 38)
        Me.lblplate1.TabIndex = 69
        Me.lblplate1.Text = "Label2"
        Me.lblplate1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnimgdl1
        '
        Me.btnimgdl1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgdl1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl1.Image = CType(resources.GetObject("btnimgdl1.Image"), System.Drawing.Image)
        Me.btnimgdl1.Location = New System.Drawing.Point(637, 393)
        Me.btnimgdl1.Name = "btnimgdl1"
        Me.btnimgdl1.Size = New System.Drawing.Size(208, 30)
        Me.btnimgdl1.TabIndex = 64
        Me.btnimgdl1.Text = "Download Photo"
        Me.btnimgdl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl1.UseVisualStyleBackColor = True
        '
        'lblimgid1
        '
        Me.lblimgid1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblimgid1.AutoSize = True
        Me.lblimgid1.Location = New System.Drawing.Point(597, 565)
        Me.lblimgid1.Name = "lblimgid1"
        Me.lblimgid1.Size = New System.Drawing.Size(31, 14)
        Me.lblimgid1.TabIndex = 68
        Me.lblimgid1.Text = "imgid"
        Me.lblimgid1.Visible = False
        '
        'btnimgset1
        '
        Me.btnimgset1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgset1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgset1.Image = CType(resources.GetObject("btnimgset1.Image"), System.Drawing.Image)
        Me.btnimgset1.Location = New System.Drawing.Point(600, 357)
        Me.btnimgset1.Name = "btnimgset1"
        Me.btnimgset1.Size = New System.Drawing.Size(21, 30)
        Me.btnimgset1.TabIndex = 62
        Me.btnimgset1.Text = "Set as Primary Photo"
        Me.btnimgset1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgset1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgset1.UseVisualStyleBackColor = True
        Me.btnimgset1.Visible = False
        '
        'btnimgfull1
        '
        Me.btnimgfull1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgfull1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull1.Image = CType(resources.GetObject("btnimgfull1.Image"), System.Drawing.Image)
        Me.btnimgfull1.Location = New System.Drawing.Point(637, 429)
        Me.btnimgfull1.Name = "btnimgfull1"
        Me.btnimgfull1.Size = New System.Drawing.Size(208, 30)
        Me.btnimgfull1.TabIndex = 65
        Me.btnimgfull1.Text = "View Larger"
        Me.btnimgfull1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull1.UseVisualStyleBackColor = True
        '
        'btnimgupdate1
        '
        Me.btnimgupdate1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgupdate1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgupdate1.Image = CType(resources.GetObject("btnimgupdate1.Image"), System.Drawing.Image)
        Me.btnimgupdate1.Location = New System.Drawing.Point(600, 321)
        Me.btnimgupdate1.Name = "btnimgupdate1"
        Me.btnimgupdate1.Size = New System.Drawing.Size(21, 30)
        Me.btnimgupdate1.TabIndex = 63
        Me.btnimgupdate1.Text = "Update Photo"
        Me.btnimgupdate1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgupdate1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgupdate1.UseVisualStyleBackColor = True
        Me.btnimgupdate1.Visible = False
        '
        'txtimg1
        '
        Me.txtimg1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtimg1.BackColor = System.Drawing.Color.White
        Me.txtimg1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtimg1.Location = New System.Drawing.Point(600, 269)
        Me.txtimg1.Name = "txtimg1"
        Me.txtimg1.ReadOnly = True
        Me.txtimg1.Size = New System.Drawing.Size(273, 21)
        Me.txtimg1.TabIndex = 57
        '
        'imgpanel1
        '
        Me.imgpanel1.AutoScroll = True
        Me.imgpanel1.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.imgpanel1.Location = New System.Drawing.Point(6, 166)
        Me.imgpanel1.Name = "imgpanel1"
        Me.imgpanel1.Size = New System.Drawing.Size(588, 144)
        Me.imgpanel1.TabIndex = 63
        '
        'imgbox1
        '
        Me.imgbox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.imgbox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox1.Location = New System.Drawing.Point(600, 61)
        Me.imgbox1.Name = "imgbox1"
        Me.imgbox1.Size = New System.Drawing.Size(273, 204)
        Me.imgbox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox1.TabIndex = 62
        Me.imgbox1.TabStop = False
        '
        'btnimgremove1
        '
        Me.btnimgremove1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgremove1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove1.Image = CType(resources.GetObject("btnimgremove1.Image"), System.Drawing.Image)
        Me.btnimgremove1.Location = New System.Drawing.Point(637, 357)
        Me.btnimgremove1.Name = "btnimgremove1"
        Me.btnimgremove1.Size = New System.Drawing.Size(101, 30)
        Me.btnimgremove1.TabIndex = 60
        Me.btnimgremove1.Text = "Remove"
        Me.btnimgremove1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove1.UseVisualStyleBackColor = True
        Me.btnimgremove1.Visible = False
        '
        'btnimgadd1
        '
        Me.btnimgadd1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgadd1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd1.Image = CType(resources.GetObject("btnimgadd1.Image"), System.Drawing.Image)
        Me.btnimgadd1.Location = New System.Drawing.Point(637, 321)
        Me.btnimgadd1.Name = "btnimgadd1"
        Me.btnimgadd1.Size = New System.Drawing.Size(101, 30)
        Me.btnimgadd1.TabIndex = 58
        Me.btnimgadd1.Text = "Add Photo"
        Me.btnimgadd1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd1.UseVisualStyleBackColor = True
        Me.btnimgadd1.Visible = False
        '
        'btnimgcancel1
        '
        Me.btnimgcancel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgcancel1.Enabled = False
        Me.btnimgcancel1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel1.Image = CType(resources.GetObject("btnimgcancel1.Image"), System.Drawing.Image)
        Me.btnimgcancel1.Location = New System.Drawing.Point(637, 357)
        Me.btnimgcancel1.Name = "btnimgcancel1"
        Me.btnimgcancel1.Size = New System.Drawing.Size(208, 30)
        Me.btnimgcancel1.TabIndex = 61
        Me.btnimgcancel1.Text = "Cancel"
        Me.btnimgcancel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel1.UseVisualStyleBackColor = True
        '
        'btnimgrefresh1
        '
        Me.btnimgrefresh1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgrefresh1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh1.Image = CType(resources.GetObject("btnimgrefresh1.Image"), System.Drawing.Image)
        Me.btnimgrefresh1.Location = New System.Drawing.Point(637, 465)
        Me.btnimgrefresh1.Name = "btnimgrefresh1"
        Me.btnimgrefresh1.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh1.TabIndex = 66
        Me.btnimgrefresh1.Text = "Refresh"
        Me.btnimgrefresh1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh1.UseVisualStyleBackColor = True
        '
        'btnimgrename1
        '
        Me.btnimgrename1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgrename1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename1.Image = CType(resources.GetObject("btnimgrename1.Image"), System.Drawing.Image)
        Me.btnimgrename1.Location = New System.Drawing.Point(637, 321)
        Me.btnimgrename1.Name = "btnimgrename1"
        Me.btnimgrename1.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrename1.TabIndex = 59
        Me.btnimgrename1.Text = "Rename"
        Me.btnimgrename1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename1.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnodoend)
        Me.GroupBox1.Controls.Add(Me.btnodobeg)
        Me.GroupBox1.Controls.Add(Me.txt16)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.txt15)
        Me.GroupBox1.Controls.Add(Me.txt14)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.txt13)
        Me.GroupBox1.Controls.Add(Me.txt12)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txt11)
        Me.GroupBox1.Controls.Add(Me.txt10)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txt5)
        Me.GroupBox1.Controls.Add(Me.txt6)
        Me.GroupBox1.Controls.Add(Me.txt7)
        Me.GroupBox1.Controls.Add(Me.txt9)
        Me.GroupBox1.Controls.Add(Me.txt8)
        Me.GroupBox1.Controls.Add(Me.txt4)
        Me.GroupBox1.Controls.Add(Me.txt3)
        Me.GroupBox1.Controls.Add(Me.lbl8)
        Me.GroupBox1.Controls.Add(Me.lbl5)
        Me.GroupBox1.Controls.Add(Me.lbl4)
        Me.GroupBox1.Controls.Add(Me.lbl7)
        Me.GroupBox1.Controls.Add(Me.lbl3)
        Me.GroupBox1.Controls.Add(Me.lbl6)
        Me.GroupBox1.Controls.Add(Me.lbl9)
        Me.GroupBox1.Location = New System.Drawing.Point(888, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(264, 650)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        '
        'txt16
        '
        Me.txt16.BackColor = System.Drawing.Color.Khaki
        Me.txt16.Location = New System.Drawing.Point(34, 601)
        Me.txt16.Name = "txt16"
        Me.txt16.ReadOnly = True
        Me.txt16.Size = New System.Drawing.Size(209, 21)
        Me.txt16.TabIndex = 29
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(10, 583)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(115, 15)
        Me.Label12.TabIndex = 28
        Me.Label12.Text = "Actual Diesel Used:"
        '
        'txt15
        '
        Me.txt15.BackColor = System.Drawing.Color.Khaki
        Me.txt15.Location = New System.Drawing.Point(34, 558)
        Me.txt15.Name = "txt15"
        Me.txt15.ReadOnly = True
        Me.txt15.Size = New System.Drawing.Size(209, 21)
        Me.txt15.TabIndex = 27
        '
        'txt14
        '
        Me.txt14.BackColor = System.Drawing.Color.PaleGreen
        Me.txt14.Location = New System.Drawing.Point(34, 515)
        Me.txt14.Name = "txt14"
        Me.txt14.ReadOnly = True
        Me.txt14.Size = New System.Drawing.Size(209, 21)
        Me.txt14.TabIndex = 25
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(10, 497)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(144, 15)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "Diesel Balance (Ending):"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(10, 540)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(208, 15)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "Actual Distance based on Odometer:"
        '
        'txt13
        '
        Me.txt13.BackColor = System.Drawing.Color.PaleGreen
        Me.txt13.Location = New System.Drawing.Point(34, 471)
        Me.txt13.Name = "txt13"
        Me.txt13.ReadOnly = True
        Me.txt13.Size = New System.Drawing.Size(209, 21)
        Me.txt13.TabIndex = 23
        '
        'txt12
        '
        Me.txt12.BackColor = System.Drawing.Color.PaleGreen
        Me.txt12.Location = New System.Drawing.Point(34, 427)
        Me.txt12.Name = "txt12"
        Me.txt12.ReadOnly = True
        Me.txt12.Size = New System.Drawing.Size(209, 21)
        Me.txt12.TabIndex = 22
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(10, 409)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(165, 15)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "Odometer Reading (Ending):"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(10, 453)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(174, 15)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "Post Add'l Diesel (PO) in Liters"
        '
        'txt11
        '
        Me.txt11.BackColor = System.Drawing.Color.PowderBlue
        Me.txt11.Location = New System.Drawing.Point(34, 383)
        Me.txt11.Name = "txt11"
        Me.txt11.ReadOnly = True
        Me.txt11.Size = New System.Drawing.Size(209, 21)
        Me.txt11.TabIndex = 19
        '
        'txt10
        '
        Me.txt10.BackColor = System.Drawing.Color.PowderBlue
        Me.txt10.Location = New System.Drawing.Point(34, 339)
        Me.txt10.Name = "txt10"
        Me.txt10.ReadOnly = True
        Me.txt10.Size = New System.Drawing.Size(209, 21)
        Me.txt10.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 321)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(121, 15)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "Diesel (PO) in Liters:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 365)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(150, 15)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "Add'l Diesel (PO) in Liters:"
        '
        'txt5
        '
        Me.txt5.BackColor = System.Drawing.Color.PowderBlue
        Me.txt5.Location = New System.Drawing.Point(34, 119)
        Me.txt5.Name = "txt5"
        Me.txt5.ReadOnly = True
        Me.txt5.Size = New System.Drawing.Size(209, 21)
        Me.txt5.TabIndex = 15
        '
        'txt6
        '
        Me.txt6.BackColor = System.Drawing.Color.PowderBlue
        Me.txt6.Location = New System.Drawing.Point(34, 163)
        Me.txt6.Name = "txt6"
        Me.txt6.ReadOnly = True
        Me.txt6.Size = New System.Drawing.Size(209, 21)
        Me.txt6.TabIndex = 14
        '
        'txt7
        '
        Me.txt7.BackColor = System.Drawing.Color.PowderBlue
        Me.txt7.Location = New System.Drawing.Point(34, 207)
        Me.txt7.Name = "txt7"
        Me.txt7.ReadOnly = True
        Me.txt7.Size = New System.Drawing.Size(209, 21)
        Me.txt7.TabIndex = 13
        '
        'txt9
        '
        Me.txt9.BackColor = System.Drawing.Color.PowderBlue
        Me.txt9.Location = New System.Drawing.Point(34, 295)
        Me.txt9.Name = "txt9"
        Me.txt9.ReadOnly = True
        Me.txt9.Size = New System.Drawing.Size(209, 21)
        Me.txt9.TabIndex = 12
        '
        'txt8
        '
        Me.txt8.BackColor = System.Drawing.Color.PowderBlue
        Me.txt8.Location = New System.Drawing.Point(34, 251)
        Me.txt8.Name = "txt8"
        Me.txt8.ReadOnly = True
        Me.txt8.Size = New System.Drawing.Size(209, 21)
        Me.txt8.TabIndex = 11
        '
        'txt4
        '
        Me.txt4.BackColor = System.Drawing.Color.NavajoWhite
        Me.txt4.Location = New System.Drawing.Point(34, 75)
        Me.txt4.Name = "txt4"
        Me.txt4.ReadOnly = True
        Me.txt4.Size = New System.Drawing.Size(209, 21)
        Me.txt4.TabIndex = 10
        '
        'txt3
        '
        Me.txt3.BackColor = System.Drawing.Color.NavajoWhite
        Me.txt3.Location = New System.Drawing.Point(34, 31)
        Me.txt3.Name = "txt3"
        Me.txt3.ReadOnly = True
        Me.txt3.Size = New System.Drawing.Size(209, 21)
        Me.txt3.TabIndex = 9
        '
        'lbl8
        '
        Me.lbl8.AutoSize = True
        Me.lbl8.Location = New System.Drawing.Point(10, 233)
        Me.lbl8.Name = "lbl8"
        Me.lbl8.Size = New System.Drawing.Size(184, 15)
        Me.lbl8.TabIndex = 5
        Me.lbl8.Text = "Previous Diesel Ending  (Liters):"
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.Location = New System.Drawing.Point(10, 101)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(164, 15)
        Me.lbl5.TabIndex = 2
        Me.lbl5.Text = "Total Distance w/ Load (Km):"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Location = New System.Drawing.Point(10, 57)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(218, 15)
        Me.lbl4.TabIndex = 1
        Me.lbl4.Text = "Actual Odometer Reading (Beginning):"
        '
        'lbl7
        '
        Me.lbl7.AutoSize = True
        Me.lbl7.Location = New System.Drawing.Point(10, 189)
        Me.lbl7.Name = "lbl7"
        Me.lbl7.Size = New System.Drawing.Size(148, 15)
        Me.lbl7.TabIndex = 4
        Me.lbl7.Text = "Diesel Should be + 2inch;"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Location = New System.Drawing.Point(10, 13)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(158, 15)
        Me.lbl3.TabIndex = 0
        Me.lbl3.Text = "Previous Ending Odometer:"
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.Location = New System.Drawing.Point(10, 145)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(171, 15)
        Me.lbl6.TabIndex = 3
        Me.lbl6.Text = "Total Distance w/o Load (Km):"
        '
        'lbl9
        '
        Me.lbl9.AutoSize = True
        Me.lbl9.Location = New System.Drawing.Point(10, 277)
        Me.lbl9.Name = "lbl9"
        Me.lbl9.Size = New System.Drawing.Size(149, 15)
        Me.lbl9.TabIndex = 6
        Me.lbl9.Text = "Actual Diesel Beg (Liters):"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.AutoScroll = True
        Me.Panel1.Controls.Add(Me.GroupBox3)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Location = New System.Drawing.Point(2, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1160, 664)
        Me.Panel1.TabIndex = 4
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditSOToolStripMenuItem, Me.EditPOToolStripMenuItem, Me.EditITRToolStripMenuItem, Me.EditSWSToolStripMenuItem, Me.ViewRefHistoryToolStripMenuItem, Me.EditToolStripMenuItem, Me.ViewEditHistoryToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(168, 158)
        '
        'EditSOToolStripMenuItem
        '
        Me.EditSOToolStripMenuItem.Image = CType(resources.GetObject("EditSOToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditSOToolStripMenuItem.Name = "EditSOToolStripMenuItem"
        Me.EditSOToolStripMenuItem.Size = New System.Drawing.Size(253, 22)
        Me.EditSOToolStripMenuItem.Text = "Edit SO#"
        Me.EditSOToolStripMenuItem.Visible = False
        '
        'EditPOToolStripMenuItem
        '
        Me.EditPOToolStripMenuItem.Image = CType(resources.GetObject("EditPOToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditPOToolStripMenuItem.Name = "EditPOToolStripMenuItem"
        Me.EditPOToolStripMenuItem.Size = New System.Drawing.Size(253, 22)
        Me.EditPOToolStripMenuItem.Text = "Edit PO#"
        Me.EditPOToolStripMenuItem.Visible = False
        '
        'EditITRToolStripMenuItem
        '
        Me.EditITRToolStripMenuItem.Image = CType(resources.GetObject("EditITRToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditITRToolStripMenuItem.Name = "EditITRToolStripMenuItem"
        Me.EditITRToolStripMenuItem.Size = New System.Drawing.Size(253, 22)
        Me.EditITRToolStripMenuItem.Text = "Edit ITR#"
        Me.EditITRToolStripMenuItem.Visible = False
        '
        'EditSWSToolStripMenuItem
        '
        Me.EditSWSToolStripMenuItem.Image = CType(resources.GetObject("EditSWSToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditSWSToolStripMenuItem.Name = "EditSWSToolStripMenuItem"
        Me.EditSWSToolStripMenuItem.Size = New System.Drawing.Size(253, 22)
        Me.EditSWSToolStripMenuItem.Text = "Edit SWS#"
        Me.EditSWSToolStripMenuItem.Visible = False
        '
        'ViewRefHistoryToolStripMenuItem
        '
        Me.ViewRefHistoryToolStripMenuItem.Image = CType(resources.GetObject("ViewRefHistoryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewRefHistoryToolStripMenuItem.Name = "ViewRefHistoryToolStripMenuItem"
        Me.ViewRefHistoryToolStripMenuItem.Size = New System.Drawing.Size(253, 22)
        Me.ViewRefHistoryToolStripMenuItem.Text = "View Ref# History"
        Me.ViewRefHistoryToolStripMenuItem.Visible = False
        '
        'btnodobeg
        '
        Me.btnodobeg.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnodobeg.BackColor = System.Drawing.Color.NavajoWhite
        Me.btnodobeg.FlatAppearance.BorderSize = 0
        Me.btnodobeg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnodobeg.Image = CType(resources.GetObject("btnodobeg.Image"), System.Drawing.Image)
        Me.btnodobeg.Location = New System.Drawing.Point(220, 76)
        Me.btnodobeg.Name = "btnodobeg"
        Me.btnodobeg.Size = New System.Drawing.Size(20, 19)
        Me.btnodobeg.TabIndex = 108
        Me.btnodobeg.Tag = "Odometer Beginning"
        Me.btnodobeg.UseVisualStyleBackColor = False
        '
        'btnodoend
        '
        Me.btnodoend.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnodoend.BackColor = System.Drawing.Color.PaleGreen
        Me.btnodoend.FlatAppearance.BorderSize = 0
        Me.btnodoend.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnodoend.Image = CType(resources.GetObject("btnodoend.Image"), System.Drawing.Image)
        Me.btnodoend.Location = New System.Drawing.Point(220, 428)
        Me.btnodoend.Name = "btnodoend"
        Me.btnodoend.Size = New System.Drawing.Size(20, 19)
        Me.btnodoend.TabIndex = 109
        Me.btnodoend.Tag = "Odometer Ending"
        Me.btnodoend.UseVisualStyleBackColor = False
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.Image = CType(resources.GetObject("EditToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.EditToolStripMenuItem.Text = "Edit"
        Me.EditToolStripMenuItem.Visible = False
        '
        'ViewEditHistoryToolStripMenuItem
        '
        Me.ViewEditHistoryToolStripMenuItem.Image = CType(resources.GetObject("ViewEditHistoryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewEditHistoryToolStripMenuItem.Name = "ViewEditHistoryToolStripMenuItem"
        Me.ViewEditHistoryToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.ViewEditHistoryToolStripMenuItem.Text = "View Edit History"
        '
        'viewstep1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1167, 671)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "viewstep1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "View Step1"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.grdcom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.picwarn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picinfo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdtrans4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgbox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents lbltripnum1 As System.Windows.Forms.Label
    Friend WithEvents lblplate1 As System.Windows.Forms.Label
    Friend WithEvents btnimgdl1 As System.Windows.Forms.Button
    Friend WithEvents lblimgid1 As System.Windows.Forms.Label
    Friend WithEvents btnimgset1 As System.Windows.Forms.Button
    Friend WithEvents btnimgfull1 As System.Windows.Forms.Button
    Friend WithEvents btnimgupdate1 As System.Windows.Forms.Button
    Friend WithEvents txtimg1 As System.Windows.Forms.TextBox
    Friend WithEvents imgpanel1 As System.Windows.Forms.Panel
    Friend WithEvents imgbox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnimgremove1 As System.Windows.Forms.Button
    Friend WithEvents btnimgadd1 As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel1 As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh1 As System.Windows.Forms.Button
    Friend WithEvents btnimgrename1 As System.Windows.Forms.Button
    Friend WithEvents lblstep As System.Windows.Forms.Label
    Friend WithEvents lbldraft As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents lblsave As System.Windows.Forms.Label
    Friend WithEvents lblfinish As System.Windows.Forms.Label
    Friend WithEvents lblstart As System.Windows.Forms.Label
    Friend WithEvents txtrems As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtrescue As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblfinishby As System.Windows.Forms.Label
    Friend WithEvents lblstartby As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lbl4 As System.Windows.Forms.Label
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents lbl8 As System.Windows.Forms.Label
    Friend WithEvents lbl7 As System.Windows.Forms.Label
    Friend WithEvents lbl6 As System.Windows.Forms.Label
    Friend WithEvents lbl5 As System.Windows.Forms.Label
    Friend WithEvents lbl9 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txt5 As System.Windows.Forms.TextBox
    Friend WithEvents txt6 As System.Windows.Forms.TextBox
    Friend WithEvents txt7 As System.Windows.Forms.TextBox
    Friend WithEvents txt9 As System.Windows.Forms.TextBox
    Friend WithEvents txt8 As System.Windows.Forms.TextBox
    Friend WithEvents txt4 As System.Windows.Forms.TextBox
    Friend WithEvents txt3 As System.Windows.Forms.TextBox
    Friend WithEvents txt13 As System.Windows.Forms.TextBox
    Friend WithEvents txt12 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txt11 As System.Windows.Forms.TextBox
    Friend WithEvents txt10 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txt14 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtcomment As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btncomment As System.Windows.Forms.Button
    Friend WithEvents lbllogis As System.Windows.Forms.Label
    Friend WithEvents lblsaveby As System.Windows.Forms.Label
    Friend WithEvents grdtrans4 As System.Windows.Forms.DataGridView
    Friend WithEvents cmbtrans4 As System.Windows.Forms.ComboBox
    Friend WithEvents txt15 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txt16 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents picinfo As System.Windows.Forms.PictureBox
    Friend WithEvents rbwarn As System.Windows.Forms.RadioButton
    Friend WithEvents rbok As System.Windows.Forms.RadioButton
    Friend WithEvents picwarn As System.Windows.Forms.PictureBox
    Friend WithEvents lbltype1 As System.Windows.Forms.Label
    Friend WithEvents txtdes As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents txtlabor As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblloading As System.Windows.Forms.Label
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents EditSOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditPOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditITRToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditSWSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewRefHistoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tripinfolink As System.Windows.Forms.LinkLabel
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lblimgname1 As System.Windows.Forms.Label
    Friend WithEvents lblimgdate1 As System.Windows.Forms.Label
    Friend WithEvents lblpick As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents grdcom As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnodobeg As System.Windows.Forms.Button
    Friend WithEvents btnodoend As System.Windows.Forms.Button
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewEditHistoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
