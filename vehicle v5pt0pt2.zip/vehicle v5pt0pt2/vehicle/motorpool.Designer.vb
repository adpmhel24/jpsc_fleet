﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class motorpool
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(motorpool))
        Dim DataGridViewCellStyle51 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle52 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle54 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle55 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle56 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle53 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle57 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle58 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle60 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle61 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle62 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle59 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle63 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle64 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle65 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle66 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle67 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle68 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle69 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle70 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle71 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle72 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle46 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle47 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle48 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle49 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle50 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle73 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle74 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle76 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle77 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle78 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle75 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle79 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle80 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle82 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle83 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle84 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle81 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle85 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle86 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle88 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle89 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle90 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle87 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel0 = New System.Windows.Forms.Panel()
        Me.gstep0 = New System.Windows.Forms.GroupBox()
        Me.lblload0 = New System.Windows.Forms.Label()
        Me.btnrefstep0 = New System.Windows.Forms.Button()
        Me.grdstep0 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grp0 = New System.Windows.Forms.GroupBox()
        Me.btnstartfor = New System.Windows.Forms.Button()
        Me.lbltype0 = New System.Windows.Forms.Label()
        Me.lblplate0 = New System.Windows.Forms.Label()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.gstep1 = New System.Windows.Forms.GroupBox()
        Me.lblload1 = New System.Windows.Forms.Label()
        Me.btnrefstep1 = New System.Windows.Forms.Button()
        Me.grdstep1 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column28 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grp1 = New System.Windows.Forms.GroupBox()
        Me.lblstart = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtchk = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblimgname1 = New System.Windows.Forms.Label()
        Me.btnexempt1 = New System.Windows.Forms.Button()
        Me.lblimgdate1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.lblDesiredSize = New System.Windows.Forms.TextBox()
        Me.lblOriginalSize = New System.Windows.Forms.Label()
        Me.lblCompressedSize = New System.Windows.Forms.Label()
        Me.lblCompressionLevel = New System.Windows.Forms.Label()
        Me.pgbar1 = New System.Windows.Forms.ProgressBar()
        Me.btnstartpre = New System.Windows.Forms.Button()
        Me.lbltype1 = New System.Windows.Forms.Label()
        Me.cmbimg1 = New System.Windows.Forms.ComboBox()
        Me.txtrems1 = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnrepair = New System.Windows.Forms.Button()
        Me.btnconfirm1 = New System.Windows.Forms.Button()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.lblplate1 = New System.Windows.Forms.Label()
        Me.btnimgdl1 = New System.Windows.Forms.Button()
        Me.lblimgid1 = New System.Windows.Forms.Label()
        Me.btnimgfull1 = New System.Windows.Forms.Button()
        Me.imgpanel1 = New System.Windows.Forms.Panel()
        Me.imgbox1 = New System.Windows.Forms.PictureBox()
        Me.btnimgremove1 = New System.Windows.Forms.Button()
        Me.btnimgadd1 = New System.Windows.Forms.Button()
        Me.btnimgcancel1 = New System.Windows.Forms.Button()
        Me.btnimgrefresh1 = New System.Windows.Forms.Button()
        Me.btnimgrename1 = New System.Windows.Forms.Button()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.gstep2 = New System.Windows.Forms.GroupBox()
        Me.lblload2 = New System.Windows.Forms.Label()
        Me.btnrefstep2 = New System.Windows.Forms.Button()
        Me.grdstep2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grp2 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblimgname2 = New System.Windows.Forms.Label()
        Me.lblimgdate2 = New System.Windows.Forms.Label()
        Me.pgbar2 = New System.Windows.Forms.ProgressBar()
        Me.lbltype2 = New System.Windows.Forms.Label()
        Me.btnstartdiesel = New System.Windows.Forms.Button()
        Me.cmbimg2 = New System.Windows.Forms.ComboBox()
        Me.txtrems2 = New System.Windows.Forms.TextBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.btnconfirm2 = New System.Windows.Forms.Button()
        Me.lblplate2 = New System.Windows.Forms.Label()
        Me.btnimgdl2 = New System.Windows.Forms.Button()
        Me.lblimgid2 = New System.Windows.Forms.Label()
        Me.btnimgfull2 = New System.Windows.Forms.Button()
        Me.imgpanel2 = New System.Windows.Forms.Panel()
        Me.imgbox2 = New System.Windows.Forms.PictureBox()
        Me.btnimgremove2 = New System.Windows.Forms.Button()
        Me.btnimgadd2 = New System.Windows.Forms.Button()
        Me.btnimgcancel2 = New System.Windows.Forms.Button()
        Me.btnimgrefresh2 = New System.Windows.Forms.Button()
        Me.btnimgrename2 = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btnupload = New System.Windows.Forms.Button()
        Me.cmbtype = New System.Windows.Forms.TextBox()
        Me.btnview = New System.Windows.Forms.Button()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.txtid = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.dateto = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmbplate = New System.Windows.Forms.ComboBox()
        Me.datefrom = New System.Windows.Forms.DateTimePicker()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblload3 = New System.Windows.Forms.Label()
        Me.grdlist = New System.Windows.Forms.DataGridView()
        Me.mid3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.platenum3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.vtype3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tcon3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.grdlogs = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tcon = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblplatebig = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnnot = New System.Windows.Forms.Button()
        Me.txtplatenot = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblloadnot = New System.Windows.Forms.Label()
        Me.btnrefnot = New System.Windows.Forms.Button()
        Me.grdnot = New System.Windows.Forms.DataGridView()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnava = New System.Windows.Forms.Button()
        Me.txtplateava = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblloadava = New System.Windows.Forms.Label()
        Me.btnrefava = New System.Windows.Forms.Button()
        Me.grdava = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtappid = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.dtcom = New System.Windows.Forms.DateTimePicker()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.dfcom = New System.Windows.Forms.DateTimePicker()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btncompleted = New System.Windows.Forms.Button()
        Me.txtapp = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblloadcom = New System.Windows.Forms.Label()
        Me.grdapp_com = New System.Windows.Forms.DataGridView()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.start = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.finish = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.mechanic = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.chknum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ViewAttachmentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel0.SuspendLayout()
        Me.gstep0.SuspendLayout()
        CType(Me.grdstep0, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp0.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.gstep1.SuspendLayout()
        CType(Me.grdstep1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.imgbox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.gstep2.SuspendLayout()
        CType(Me.grdstep2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp2.SuspendLayout()
        Me.Panel6.SuspendLayout()
        CType(Me.imgbox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.grdlist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        CType(Me.grdlogs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.grdnot, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.grdava, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.grdapp_com, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(10, 10)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1259, 641)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Panel0)
        Me.TabPage1.Location = New System.Drawing.Point(4, 27)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1251, 610)
        Me.TabPage1.TabIndex = 3
        Me.TabPage1.Text = "For Inspection          "
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Panel0
        '
        Me.Panel0.BackColor = System.Drawing.Color.White
        Me.Panel0.Controls.Add(Me.gstep0)
        Me.Panel0.Controls.Add(Me.grp0)
        Me.Panel0.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel0.Location = New System.Drawing.Point(3, 3)
        Me.Panel0.Name = "Panel0"
        Me.Panel0.Size = New System.Drawing.Size(1245, 604)
        Me.Panel0.TabIndex = 2
        '
        'gstep0
        '
        Me.gstep0.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gstep0.BackColor = System.Drawing.Color.White
        Me.gstep0.Controls.Add(Me.lblload0)
        Me.gstep0.Controls.Add(Me.btnrefstep0)
        Me.gstep0.Controls.Add(Me.grdstep0)
        Me.gstep0.Location = New System.Drawing.Point(3, 12)
        Me.gstep0.Name = "gstep0"
        Me.gstep0.Size = New System.Drawing.Size(479, 569)
        Me.gstep0.TabIndex = 2
        Me.gstep0.TabStop = False
        Me.gstep0.Text = "Trucks"
        '
        'lblload0
        '
        Me.lblload0.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload0.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload0.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload0.Location = New System.Drawing.Point(7, 52)
        Me.lblload0.Name = "lblload0"
        Me.lblload0.Size = New System.Drawing.Size(465, 476)
        Me.lblload0.TabIndex = 98
        Me.lblload0.Text = "Loading..."
        Me.lblload0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnrefstep0
        '
        Me.btnrefstep0.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefstep0.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefstep0.Image = CType(resources.GetObject("btnrefstep0.Image"), System.Drawing.Image)
        Me.btnrefstep0.Location = New System.Drawing.Point(372, 533)
        Me.btnrefstep0.Name = "btnrefstep0"
        Me.btnrefstep0.Size = New System.Drawing.Size(101, 30)
        Me.btnrefstep0.TabIndex = 70
        Me.btnrefstep0.Text = "Refresh List"
        Me.btnrefstep0.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefstep0.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefstep0.UseVisualStyleBackColor = True
        '
        'grdstep0
        '
        Me.grdstep0.AllowUserToAddRows = False
        Me.grdstep0.AllowUserToDeleteRows = False
        DataGridViewCellStyle51.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdstep0.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle51
        Me.grdstep0.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdstep0.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdstep0.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle52.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle52.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle52.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle52.NullValue = Nothing
        DataGridViewCellStyle52.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle52.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle52.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep0.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle52
        Me.grdstep0.ColumnHeadersHeight = 30
        Me.grdstep0.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdstep0.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn8})
        DataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle54.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle54.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle54.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle54.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle54.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep0.DefaultCellStyle = DataGridViewCellStyle54
        Me.grdstep0.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdstep0.EnableHeadersVisualStyles = False
        Me.grdstep0.GridColor = System.Drawing.Color.Salmon
        Me.grdstep0.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdstep0.Location = New System.Drawing.Point(6, 20)
        Me.grdstep0.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdstep0.MultiSelect = False
        Me.grdstep0.Name = "grdstep0"
        Me.grdstep0.ReadOnly = True
        Me.grdstep0.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle55.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle55.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle55.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle55.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle55.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle55.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep0.RowHeadersDefaultCellStyle = DataGridViewCellStyle55
        Me.grdstep0.RowHeadersWidth = 10
        Me.grdstep0.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle56.NullValue = Nothing
        DataGridViewCellStyle56.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep0.RowsDefaultCellStyle = DataGridViewCellStyle56
        Me.grdstep0.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdstep0.Size = New System.Drawing.Size(467, 508)
        Me.grdstep0.TabIndex = 10
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.Frozen = True
        Me.DataGridViewTextBoxColumn2.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 80
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.Frozen = True
        Me.DataGridViewTextBoxColumn4.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 80
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn4.Width = 110
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.HeaderText = "Vehicle Type"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.Width = 120
        '
        'DataGridViewTextBoxColumn8
        '
        DataGridViewCellStyle53.Format = "yyyy/MM/dd"
        Me.DataGridViewTextBoxColumn8.DefaultCellStyle = DataGridViewCellStyle53
        Me.DataGridViewTextBoxColumn8.HeaderText = "Arrived"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Width = 120
        '
        'grp0
        '
        Me.grp0.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grp0.BackColor = System.Drawing.Color.White
        Me.grp0.Controls.Add(Me.btnstartfor)
        Me.grp0.Controls.Add(Me.lbltype0)
        Me.grp0.Controls.Add(Me.lblplate0)
        Me.grp0.Controls.Add(Me.Panel12)
        Me.grp0.Location = New System.Drawing.Point(484, 12)
        Me.grp0.Name = "grp0"
        Me.grp0.Size = New System.Drawing.Size(581, 569)
        Me.grp0.TabIndex = 3
        Me.grp0.TabStop = False
        Me.grp0.Text = "Photos"
        '
        'btnstartfor
        '
        Me.btnstartfor.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnstartfor.Enabled = False
        Me.btnstartfor.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstartfor.Image = CType(resources.GetObject("btnstartfor.Image"), System.Drawing.Image)
        Me.btnstartfor.Location = New System.Drawing.Point(6, 65)
        Me.btnstartfor.Name = "btnstartfor"
        Me.btnstartfor.Size = New System.Drawing.Size(569, 62)
        Me.btnstartfor.TabIndex = 80
        Me.btnstartfor.Text = "TIME START CHECK-UP"
        Me.btnstartfor.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnstartfor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnstartfor.UseVisualStyleBackColor = False
        '
        'lbltype0
        '
        Me.lbltype0.BackColor = System.Drawing.Color.Transparent
        Me.lbltype0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype0.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltype0.Location = New System.Drawing.Point(360, 22)
        Me.lbltype0.Name = "lbltype0"
        Me.lbltype0.Size = New System.Drawing.Size(215, 38)
        Me.lbltype0.TabIndex = 81
        Me.lbltype0.Text = "TYPE"
        Me.lbltype0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblplate0
        '
        Me.lblplate0.BackColor = System.Drawing.Color.Transparent
        Me.lblplate0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate0.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate0.Location = New System.Drawing.Point(6, 22)
        Me.lblplate0.Name = "lblplate0"
        Me.lblplate0.Size = New System.Drawing.Size(360, 38)
        Me.lblplate0.TabIndex = 69
        Me.lblplate0.Text = "Plate #"
        Me.lblplate0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel12
        '
        Me.Panel12.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel12.AutoScroll = True
        Me.Panel12.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Panel12.Location = New System.Drawing.Point(6, 133)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(569, 430)
        Me.Panel12.TabIndex = 63
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.White
        Me.TabPage2.Controls.Add(Me.Panel1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 27)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1251, 610)
        Me.TabPage2.TabIndex = 0
        Me.TabPage2.Text = "In Progress            "
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.gstep1)
        Me.Panel1.Controls.Add(Me.grp1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1245, 604)
        Me.Panel1.TabIndex = 0
        '
        'gstep1
        '
        Me.gstep1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gstep1.BackColor = System.Drawing.Color.White
        Me.gstep1.Controls.Add(Me.lblload1)
        Me.gstep1.Controls.Add(Me.btnrefstep1)
        Me.gstep1.Controls.Add(Me.grdstep1)
        Me.gstep1.Location = New System.Drawing.Point(3, 12)
        Me.gstep1.Name = "gstep1"
        Me.gstep1.Size = New System.Drawing.Size(479, 569)
        Me.gstep1.TabIndex = 2
        Me.gstep1.TabStop = False
        Me.gstep1.Text = "Trucks"
        '
        'lblload1
        '
        Me.lblload1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload1.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload1.Location = New System.Drawing.Point(7, 52)
        Me.lblload1.Name = "lblload1"
        Me.lblload1.Size = New System.Drawing.Size(465, 476)
        Me.lblload1.TabIndex = 98
        Me.lblload1.Text = "Loading..."
        Me.lblload1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnrefstep1
        '
        Me.btnrefstep1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefstep1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefstep1.Image = CType(resources.GetObject("btnrefstep1.Image"), System.Drawing.Image)
        Me.btnrefstep1.Location = New System.Drawing.Point(372, 533)
        Me.btnrefstep1.Name = "btnrefstep1"
        Me.btnrefstep1.Size = New System.Drawing.Size(101, 30)
        Me.btnrefstep1.TabIndex = 70
        Me.btnrefstep1.Text = "Refresh List"
        Me.btnrefstep1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefstep1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefstep1.UseVisualStyleBackColor = True
        '
        'grdstep1
        '
        Me.grdstep1.AllowUserToAddRows = False
        Me.grdstep1.AllowUserToDeleteRows = False
        DataGridViewCellStyle57.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdstep1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle57
        Me.grdstep1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdstep1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdstep1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle58.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle58.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle58.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle58.NullValue = Nothing
        DataGridViewCellStyle58.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle58.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle58
        Me.grdstep1.ColumnHeadersHeight = 30
        Me.grdstep1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdstep1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn3, Me.Column1, Me.Column28})
        DataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle60.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle60.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle60.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle60.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle60.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle60.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep1.DefaultCellStyle = DataGridViewCellStyle60
        Me.grdstep1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdstep1.EnableHeadersVisualStyles = False
        Me.grdstep1.GridColor = System.Drawing.Color.Salmon
        Me.grdstep1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdstep1.Location = New System.Drawing.Point(6, 20)
        Me.grdstep1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdstep1.MultiSelect = False
        Me.grdstep1.Name = "grdstep1"
        Me.grdstep1.ReadOnly = True
        Me.grdstep1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle61.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle61.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle61.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle61.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle61.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle61.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep1.RowHeadersDefaultCellStyle = DataGridViewCellStyle61
        Me.grdstep1.RowHeadersWidth = 10
        Me.grdstep1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle62.NullValue = Nothing
        DataGridViewCellStyle62.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep1.RowsDefaultCellStyle = DataGridViewCellStyle62
        Me.grdstep1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdstep1.Size = New System.Drawing.Size(467, 508)
        Me.grdstep1.TabIndex = 10
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.Frozen = True
        Me.DataGridViewTextBoxColumn1.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 80
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.Frozen = True
        Me.DataGridViewTextBoxColumn3.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 80
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn3.Width = 110
        '
        'Column1
        '
        Me.Column1.HeaderText = "Vehicle Type"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 120
        '
        'Column28
        '
        DataGridViewCellStyle59.Format = "yyyy/MM/dd"
        Me.Column28.DefaultCellStyle = DataGridViewCellStyle59
        Me.Column28.HeaderText = "Arrived"
        Me.Column28.Name = "Column28"
        Me.Column28.ReadOnly = True
        Me.Column28.Width = 120
        '
        'grp1
        '
        Me.grp1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grp1.BackColor = System.Drawing.Color.White
        Me.grp1.Controls.Add(Me.lblstart)
        Me.grp1.Controls.Add(Me.Label13)
        Me.grp1.Controls.Add(Me.txtchk)
        Me.grp1.Controls.Add(Me.Label2)
        Me.grp1.Controls.Add(Me.Label1)
        Me.grp1.Controls.Add(Me.lblimgname1)
        Me.grp1.Controls.Add(Me.btnexempt1)
        Me.grp1.Controls.Add(Me.lblimgdate1)
        Me.grp1.Controls.Add(Me.Button1)
        Me.grp1.Controls.Add(Me.Button3)
        Me.grp1.Controls.Add(Me.lblDesiredSize)
        Me.grp1.Controls.Add(Me.lblOriginalSize)
        Me.grp1.Controls.Add(Me.lblCompressedSize)
        Me.grp1.Controls.Add(Me.lblCompressionLevel)
        Me.grp1.Controls.Add(Me.pgbar1)
        Me.grp1.Controls.Add(Me.btnstartpre)
        Me.grp1.Controls.Add(Me.lbltype1)
        Me.grp1.Controls.Add(Me.cmbimg1)
        Me.grp1.Controls.Add(Me.txtrems1)
        Me.grp1.Controls.Add(Me.Panel3)
        Me.grp1.Controls.Add(Me.lblplate1)
        Me.grp1.Controls.Add(Me.btnimgdl1)
        Me.grp1.Controls.Add(Me.lblimgid1)
        Me.grp1.Controls.Add(Me.btnimgfull1)
        Me.grp1.Controls.Add(Me.imgpanel1)
        Me.grp1.Controls.Add(Me.imgbox1)
        Me.grp1.Controls.Add(Me.btnimgremove1)
        Me.grp1.Controls.Add(Me.btnimgadd1)
        Me.grp1.Controls.Add(Me.btnimgcancel1)
        Me.grp1.Controls.Add(Me.btnimgrefresh1)
        Me.grp1.Controls.Add(Me.btnimgrename1)
        Me.grp1.Location = New System.Drawing.Point(484, 12)
        Me.grp1.Name = "grp1"
        Me.grp1.Size = New System.Drawing.Size(761, 569)
        Me.grp1.TabIndex = 3
        Me.grp1.TabStop = False
        Me.grp1.Text = "Photos"
        '
        'lblstart
        '
        Me.lblstart.AutoSize = True
        Me.lblstart.Location = New System.Drawing.Point(76, 130)
        Me.lblstart.Name = "lblstart"
        Me.lblstart.Size = New System.Drawing.Size(0, 15)
        Me.lblstart.TabIndex = 108
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(6, 130)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(64, 15)
        Me.Label13.TabIndex = 107
        Me.Label13.Text = "Started by:"
        '
        'txtchk
        '
        Me.txtchk.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtchk.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtchk.Location = New System.Drawing.Point(607, 462)
        Me.txtchk.Name = "txtchk"
        Me.txtchk.ReadOnly = True
        Me.txtchk.Size = New System.Drawing.Size(145, 21)
        Me.txtchk.TabIndex = 106
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(526, 465)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 15)
        Me.Label2.TabIndex = 105
        Me.Label2.Text = "CheckList #:"
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 465)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 15)
        Me.Label1.TabIndex = 104
        Me.Label1.Text = "Remarks:"
        '
        'lblimgname1
        '
        Me.lblimgname1.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgname1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgname1.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgname1.Location = New System.Drawing.Point(651, 271)
        Me.lblimgname1.Name = "lblimgname1"
        Me.lblimgname1.Size = New System.Drawing.Size(105, 20)
        Me.lblimgname1.TabIndex = 103
        Me.lblimgname1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnexempt1
        '
        Me.btnexempt1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnexempt1.Enabled = False
        Me.btnexempt1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexempt1.Image = CType(resources.GetObject("btnexempt1.Image"), System.Drawing.Image)
        Me.btnexempt1.Location = New System.Drawing.Point(730, 403)
        Me.btnexempt1.Name = "btnexempt1"
        Me.btnexempt1.Size = New System.Drawing.Size(24, 35)
        Me.btnexempt1.TabIndex = 73
        Me.btnexempt1.Text = "SAVE AS DRAFT"
        Me.btnexempt1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnexempt1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnexempt1.UseVisualStyleBackColor = True
        Me.btnexempt1.Visible = False
        '
        'lblimgdate1
        '
        Me.lblimgdate1.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgdate1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgdate1.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgdate1.Location = New System.Drawing.Point(529, 271)
        Me.lblimgdate1.Name = "lblimgdate1"
        Me.lblimgdate1.Size = New System.Drawing.Size(117, 20)
        Me.lblimgdate1.TabIndex = 102
        Me.lblimgdate1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(735, 374)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(19, 23)
        Me.Button1.TabIndex = 99
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(735, 333)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(26, 21)
        Me.Button3.TabIndex = 97
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        Me.Button3.Visible = False
        '
        'lblDesiredSize
        '
        Me.lblDesiredSize.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblDesiredSize.Location = New System.Drawing.Point(538, 437)
        Me.lblDesiredSize.Name = "lblDesiredSize"
        Me.lblDesiredSize.Size = New System.Drawing.Size(34, 21)
        Me.lblDesiredSize.TabIndex = 96
        Me.lblDesiredSize.Visible = False
        '
        'lblOriginalSize
        '
        Me.lblOriginalSize.AutoSize = True
        Me.lblOriginalSize.Location = New System.Drawing.Point(542, 444)
        Me.lblOriginalSize.Name = "lblOriginalSize"
        Me.lblOriginalSize.Size = New System.Drawing.Size(73, 15)
        Me.lblOriginalSize.TabIndex = 95
        Me.lblOriginalSize.Text = "original size"
        Me.lblOriginalSize.Visible = False
        '
        'lblCompressedSize
        '
        Me.lblCompressedSize.AutoSize = True
        Me.lblCompressedSize.Location = New System.Drawing.Point(621, 444)
        Me.lblCompressedSize.Name = "lblCompressedSize"
        Me.lblCompressedSize.Size = New System.Drawing.Size(63, 15)
        Me.lblCompressedSize.TabIndex = 94
        Me.lblCompressedSize.Text = "comp size"
        Me.lblCompressedSize.Visible = False
        '
        'lblCompressionLevel
        '
        Me.lblCompressionLevel.AutoSize = True
        Me.lblCompressionLevel.Location = New System.Drawing.Point(690, 444)
        Me.lblCompressionLevel.Name = "lblCompressionLevel"
        Me.lblCompressionLevel.Size = New System.Drawing.Size(66, 15)
        Me.lblCompressionLevel.TabIndex = 93
        Me.lblCompressionLevel.Text = "comp level"
        Me.lblCompressionLevel.Visible = False
        '
        'pgbar1
        '
        Me.pgbar1.Location = New System.Drawing.Point(529, 216)
        Me.pgbar1.Name = "pgbar1"
        Me.pgbar1.Size = New System.Drawing.Size(227, 23)
        Me.pgbar1.TabIndex = 85
        Me.pgbar1.Visible = False
        '
        'btnstartpre
        '
        Me.btnstartpre.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnstartpre.Enabled = False
        Me.btnstartpre.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstartpre.Image = CType(resources.GetObject("btnstartpre.Image"), System.Drawing.Image)
        Me.btnstartpre.Location = New System.Drawing.Point(6, 65)
        Me.btnstartpre.Name = "btnstartpre"
        Me.btnstartpre.Size = New System.Drawing.Size(517, 62)
        Me.btnstartpre.TabIndex = 80
        Me.btnstartpre.Text = "TIME START CHECK-UP"
        Me.btnstartpre.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnstartpre.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnstartpre.UseVisualStyleBackColor = False
        '
        'lbltype1
        '
        Me.lbltype1.BackColor = System.Drawing.Color.Transparent
        Me.lbltype1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype1.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltype1.Location = New System.Drawing.Point(344, 22)
        Me.lbltype1.Name = "lbltype1"
        Me.lbltype1.Size = New System.Drawing.Size(178, 38)
        Me.lbltype1.TabIndex = 81
        Me.lbltype1.Text = "TYPE"
        Me.lbltype1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbimg1
        '
        Me.cmbimg1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbimg1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbimg1.FormattingEnabled = True
        Me.cmbimg1.Items.AddRange(New Object() {"", "Motorpool Checklist Form"})
        Me.cmbimg1.Location = New System.Drawing.Point(529, 245)
        Me.cmbimg1.Name = "cmbimg1"
        Me.cmbimg1.Size = New System.Drawing.Size(227, 23)
        Me.cmbimg1.TabIndex = 73
        '
        'txtrems1
        '
        Me.txtrems1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtrems1.Location = New System.Drawing.Point(6, 490)
        Me.txtrems1.Multiline = True
        Me.txtrems1.Name = "txtrems1"
        Me.txtrems1.Size = New System.Drawing.Size(517, 71)
        Me.txtrems1.TabIndex = 72
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel3.Controls.Add(Me.btnrepair)
        Me.Panel3.Controls.Add(Me.btnconfirm1)
        Me.Panel3.Controls.Add(Me.Label32)
        Me.Panel3.Location = New System.Drawing.Point(529, 490)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(223, 71)
        Me.Panel3.TabIndex = 71
        '
        'btnrepair
        '
        Me.btnrepair.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrepair.Enabled = False
        Me.btnrepair.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrepair.Image = CType(resources.GetObject("btnrepair.Image"), System.Drawing.Image)
        Me.btnrepair.Location = New System.Drawing.Point(115, 3)
        Me.btnrepair.Name = "btnrepair"
        Me.btnrepair.Size = New System.Drawing.Size(105, 65)
        Me.btnrepair.TabIndex = 102
        Me.btnrepair.Text = "FOR REPAIR"
        Me.btnrepair.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrepair.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrepair.UseVisualStyleBackColor = True
        '
        'btnconfirm1
        '
        Me.btnconfirm1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnconfirm1.Enabled = False
        Me.btnconfirm1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirm1.Image = CType(resources.GetObject("btnconfirm1.Image"), System.Drawing.Image)
        Me.btnconfirm1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnconfirm1.Location = New System.Drawing.Point(3, 3)
        Me.btnconfirm1.Name = "btnconfirm1"
        Me.btnconfirm1.Size = New System.Drawing.Size(105, 65)
        Me.btnconfirm1.TabIndex = 72
        Me.btnconfirm1.Text = "GOOD CONDITION"
        Me.btnconfirm1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnconfirm1.UseVisualStyleBackColor = True
        '
        'Label32
        '
        Me.Label32.Location = New System.Drawing.Point(173, -67)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(71, 27)
        Me.Label32.TabIndex = 101
        Me.Label32.Visible = False
        '
        'lblplate1
        '
        Me.lblplate1.BackColor = System.Drawing.Color.Transparent
        Me.lblplate1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate1.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate1.Location = New System.Drawing.Point(6, 22)
        Me.lblplate1.Name = "lblplate1"
        Me.lblplate1.Size = New System.Drawing.Size(340, 38)
        Me.lblplate1.TabIndex = 69
        Me.lblplate1.Text = "Plate #"
        Me.lblplate1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnimgdl1
        '
        Me.btnimgdl1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl1.Image = CType(resources.GetObject("btnimgdl1.Image"), System.Drawing.Image)
        Me.btnimgdl1.Location = New System.Drawing.Point(529, 21)
        Me.btnimgdl1.Name = "btnimgdl1"
        Me.btnimgdl1.Size = New System.Drawing.Size(34, 39)
        Me.btnimgdl1.TabIndex = 64
        Me.btnimgdl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl1.UseVisualStyleBackColor = True
        Me.btnimgdl1.Visible = False
        '
        'lblimgid1
        '
        Me.lblimgid1.AutoSize = True
        Me.lblimgid1.Location = New System.Drawing.Point(534, 419)
        Me.lblimgid1.Name = "lblimgid1"
        Me.lblimgid1.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid1.TabIndex = 68
        Me.lblimgid1.Text = "imgid"
        Me.lblimgid1.Visible = False
        '
        'btnimgfull1
        '
        Me.btnimgfull1.Enabled = False
        Me.btnimgfull1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull1.Image = CType(resources.GetObject("btnimgfull1.Image"), System.Drawing.Image)
        Me.btnimgfull1.Location = New System.Drawing.Point(554, 375)
        Me.btnimgfull1.Name = "btnimgfull1"
        Me.btnimgfull1.Size = New System.Drawing.Size(176, 30)
        Me.btnimgfull1.TabIndex = 65
        Me.btnimgfull1.Text = "View Larger"
        Me.btnimgfull1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull1.UseVisualStyleBackColor = True
        '
        'imgpanel1
        '
        Me.imgpanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.imgpanel1.AutoScroll = True
        Me.imgpanel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.imgpanel1.Location = New System.Drawing.Point(6, 149)
        Me.imgpanel1.Name = "imgpanel1"
        Me.imgpanel1.Size = New System.Drawing.Size(517, 309)
        Me.imgpanel1.TabIndex = 63
        '
        'imgbox1
        '
        Me.imgbox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox1.Location = New System.Drawing.Point(529, 20)
        Me.imgbox1.Name = "imgbox1"
        Me.imgbox1.Size = New System.Drawing.Size(227, 219)
        Me.imgbox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox1.TabIndex = 62
        Me.imgbox1.TabStop = False
        '
        'btnimgremove1
        '
        Me.btnimgremove1.Enabled = False
        Me.btnimgremove1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove1.Image = CType(resources.GetObject("btnimgremove1.Image"), System.Drawing.Image)
        Me.btnimgremove1.Location = New System.Drawing.Point(554, 339)
        Me.btnimgremove1.Name = "btnimgremove1"
        Me.btnimgremove1.Size = New System.Drawing.Size(91, 30)
        Me.btnimgremove1.TabIndex = 60
        Me.btnimgremove1.Text = "Remove"
        Me.btnimgremove1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove1.UseVisualStyleBackColor = True
        '
        'btnimgadd1
        '
        Me.btnimgadd1.Enabled = False
        Me.btnimgadd1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd1.Image = CType(resources.GetObject("btnimgadd1.Image"), System.Drawing.Image)
        Me.btnimgadd1.Location = New System.Drawing.Point(554, 303)
        Me.btnimgadd1.Name = "btnimgadd1"
        Me.btnimgadd1.Size = New System.Drawing.Size(91, 30)
        Me.btnimgadd1.TabIndex = 58
        Me.btnimgadd1.Text = "Add Photo"
        Me.btnimgadd1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd1.UseVisualStyleBackColor = True
        '
        'btnimgcancel1
        '
        Me.btnimgcancel1.Enabled = False
        Me.btnimgcancel1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel1.Image = CType(resources.GetObject("btnimgcancel1.Image"), System.Drawing.Image)
        Me.btnimgcancel1.Location = New System.Drawing.Point(651, 339)
        Me.btnimgcancel1.Name = "btnimgcancel1"
        Me.btnimgcancel1.Size = New System.Drawing.Size(79, 30)
        Me.btnimgcancel1.TabIndex = 61
        Me.btnimgcancel1.Text = "Cancel"
        Me.btnimgcancel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel1.UseVisualStyleBackColor = True
        '
        'btnimgrefresh1
        '
        Me.btnimgrefresh1.Enabled = False
        Me.btnimgrefresh1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh1.Image = CType(resources.GetObject("btnimgrefresh1.Image"), System.Drawing.Image)
        Me.btnimgrefresh1.Location = New System.Drawing.Point(554, 411)
        Me.btnimgrefresh1.Name = "btnimgrefresh1"
        Me.btnimgrefresh1.Size = New System.Drawing.Size(176, 30)
        Me.btnimgrefresh1.TabIndex = 66
        Me.btnimgrefresh1.Text = "Refresh Photos"
        Me.btnimgrefresh1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh1.UseVisualStyleBackColor = True
        '
        'btnimgrename1
        '
        Me.btnimgrename1.Enabled = False
        Me.btnimgrename1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename1.Image = CType(resources.GetObject("btnimgrename1.Image"), System.Drawing.Image)
        Me.btnimgrename1.Location = New System.Drawing.Point(651, 303)
        Me.btnimgrename1.Name = "btnimgrename1"
        Me.btnimgrename1.Size = New System.Drawing.Size(79, 30)
        Me.btnimgrename1.TabIndex = 59
        Me.btnimgrename1.Text = "Rename"
        Me.btnimgrename1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename1.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.White
        Me.TabPage3.Controls.Add(Me.Panel2)
        Me.TabPage3.Location = New System.Drawing.Point(4, 27)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1251, 610)
        Me.TabPage3.TabIndex = 1
        Me.TabPage3.Text = "Under Repair          "
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.gstep2)
        Me.Panel2.Controls.Add(Me.grp2)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1245, 604)
        Me.Panel2.TabIndex = 0
        '
        'gstep2
        '
        Me.gstep2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gstep2.BackColor = System.Drawing.Color.White
        Me.gstep2.Controls.Add(Me.lblload2)
        Me.gstep2.Controls.Add(Me.btnrefstep2)
        Me.gstep2.Controls.Add(Me.grdstep2)
        Me.gstep2.Location = New System.Drawing.Point(3, 12)
        Me.gstep2.Name = "gstep2"
        Me.gstep2.Size = New System.Drawing.Size(479, 569)
        Me.gstep2.TabIndex = 2
        Me.gstep2.TabStop = False
        Me.gstep2.Text = "Trucks"
        '
        'lblload2
        '
        Me.lblload2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload2.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload2.Location = New System.Drawing.Point(7, 52)
        Me.lblload2.Name = "lblload2"
        Me.lblload2.Size = New System.Drawing.Size(465, 476)
        Me.lblload2.TabIndex = 99
        Me.lblload2.Text = "Loading..."
        Me.lblload2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnrefstep2
        '
        Me.btnrefstep2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefstep2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefstep2.Image = CType(resources.GetObject("btnrefstep2.Image"), System.Drawing.Image)
        Me.btnrefstep2.Location = New System.Drawing.Point(372, 533)
        Me.btnrefstep2.Name = "btnrefstep2"
        Me.btnrefstep2.Size = New System.Drawing.Size(101, 30)
        Me.btnrefstep2.TabIndex = 70
        Me.btnrefstep2.Text = "Refresh List"
        Me.btnrefstep2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefstep2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefstep2.UseVisualStyleBackColor = True
        '
        'grdstep2
        '
        Me.grdstep2.AllowUserToAddRows = False
        Me.grdstep2.AllowUserToDeleteRows = False
        DataGridViewCellStyle63.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdstep2.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle63
        Me.grdstep2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdstep2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdstep2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle64.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle64.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle64.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle64.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle64.NullValue = Nothing
        DataGridViewCellStyle64.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle64.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle64.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle64
        Me.grdstep2.ColumnHeadersHeight = 30
        Me.grdstep2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdstep2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn7, Me.Column2, Me.Column7})
        DataGridViewCellStyle65.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle65.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle65.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle65.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle65.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle65.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle65.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep2.DefaultCellStyle = DataGridViewCellStyle65
        Me.grdstep2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdstep2.EnableHeadersVisualStyles = False
        Me.grdstep2.GridColor = System.Drawing.Color.Salmon
        Me.grdstep2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdstep2.Location = New System.Drawing.Point(6, 20)
        Me.grdstep2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdstep2.MultiSelect = False
        Me.grdstep2.Name = "grdstep2"
        Me.grdstep2.ReadOnly = True
        Me.grdstep2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle66.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle66.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle66.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle66.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle66.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle66.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle66.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep2.RowHeadersDefaultCellStyle = DataGridViewCellStyle66
        Me.grdstep2.RowHeadersWidth = 10
        Me.grdstep2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle67.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle67.NullValue = Nothing
        DataGridViewCellStyle67.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdstep2.RowsDefaultCellStyle = DataGridViewCellStyle67
        Me.grdstep2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdstep2.Size = New System.Drawing.Size(467, 508)
        Me.grdstep2.TabIndex = 10
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.Frozen = True
        Me.DataGridViewTextBoxColumn5.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Width = 80
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.Frozen = True
        Me.DataGridViewTextBoxColumn7.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 80
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn7.Width = 110
        '
        'Column2
        '
        Me.Column2.HeaderText = "Vehicle Type"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 120
        '
        'Column7
        '
        Me.Column7.HeaderText = "Arrived"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Width = 120
        '
        'grp2
        '
        Me.grp2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grp2.BackColor = System.Drawing.Color.White
        Me.grp2.Controls.Add(Me.Label3)
        Me.grp2.Controls.Add(Me.lblimgname2)
        Me.grp2.Controls.Add(Me.lblimgdate2)
        Me.grp2.Controls.Add(Me.pgbar2)
        Me.grp2.Controls.Add(Me.lbltype2)
        Me.grp2.Controls.Add(Me.btnstartdiesel)
        Me.grp2.Controls.Add(Me.cmbimg2)
        Me.grp2.Controls.Add(Me.txtrems2)
        Me.grp2.Controls.Add(Me.Panel6)
        Me.grp2.Controls.Add(Me.lblplate2)
        Me.grp2.Controls.Add(Me.btnimgdl2)
        Me.grp2.Controls.Add(Me.lblimgid2)
        Me.grp2.Controls.Add(Me.btnimgfull2)
        Me.grp2.Controls.Add(Me.imgpanel2)
        Me.grp2.Controls.Add(Me.imgbox2)
        Me.grp2.Controls.Add(Me.btnimgremove2)
        Me.grp2.Controls.Add(Me.btnimgadd2)
        Me.grp2.Controls.Add(Me.btnimgcancel2)
        Me.grp2.Controls.Add(Me.btnimgrefresh2)
        Me.grp2.Controls.Add(Me.btnimgrename2)
        Me.grp2.Location = New System.Drawing.Point(484, 12)
        Me.grp2.Name = "grp2"
        Me.grp2.Size = New System.Drawing.Size(763, 569)
        Me.grp2.TabIndex = 3
        Me.grp2.TabStop = False
        Me.grp2.Text = "Photos"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 465)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 15)
        Me.Label3.TabIndex = 106
        Me.Label3.Text = "Remarks:"
        '
        'lblimgname2
        '
        Me.lblimgname2.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgname2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgname2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgname2.Location = New System.Drawing.Point(651, 271)
        Me.lblimgname2.Name = "lblimgname2"
        Me.lblimgname2.Size = New System.Drawing.Size(105, 20)
        Me.lblimgname2.TabIndex = 105
        Me.lblimgname2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblimgdate2
        '
        Me.lblimgdate2.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblimgdate2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblimgdate2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblimgdate2.Location = New System.Drawing.Point(529, 271)
        Me.lblimgdate2.Name = "lblimgdate2"
        Me.lblimgdate2.Size = New System.Drawing.Size(117, 20)
        Me.lblimgdate2.TabIndex = 104
        Me.lblimgdate2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pgbar2
        '
        Me.pgbar2.Location = New System.Drawing.Point(529, 216)
        Me.pgbar2.Name = "pgbar2"
        Me.pgbar2.Size = New System.Drawing.Size(227, 23)
        Me.pgbar2.TabIndex = 86
        Me.pgbar2.Visible = False
        '
        'lbltype2
        '
        Me.lbltype2.BackColor = System.Drawing.Color.Transparent
        Me.lbltype2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltype2.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltype2.Location = New System.Drawing.Point(344, 22)
        Me.lbltype2.Name = "lbltype2"
        Me.lbltype2.Size = New System.Drawing.Size(178, 38)
        Me.lbltype2.TabIndex = 85
        Me.lbltype2.Text = "TYPE"
        Me.lbltype2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnstartdiesel
        '
        Me.btnstartdiesel.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnstartdiesel.Enabled = False
        Me.btnstartdiesel.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstartdiesel.Image = CType(resources.GetObject("btnstartdiesel.Image"), System.Drawing.Image)
        Me.btnstartdiesel.Location = New System.Drawing.Point(6, 65)
        Me.btnstartdiesel.Name = "btnstartdiesel"
        Me.btnstartdiesel.Size = New System.Drawing.Size(517, 62)
        Me.btnstartdiesel.TabIndex = 84
        Me.btnstartdiesel.Text = "TIME START TRUCK CLEARANCE"
        Me.btnstartdiesel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnstartdiesel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnstartdiesel.UseVisualStyleBackColor = False
        '
        'cmbimg2
        '
        Me.cmbimg2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbimg2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbimg2.FormattingEnabled = True
        Me.cmbimg2.Items.AddRange(New Object() {"", "Checklist Form"})
        Me.cmbimg2.Location = New System.Drawing.Point(529, 245)
        Me.cmbimg2.Name = "cmbimg2"
        Me.cmbimg2.Size = New System.Drawing.Size(227, 23)
        Me.cmbimg2.TabIndex = 73
        '
        'txtrems2
        '
        Me.txtrems2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtrems2.Location = New System.Drawing.Point(6, 490)
        Me.txtrems2.Multiline = True
        Me.txtrems2.Name = "txtrems2"
        Me.txtrems2.Size = New System.Drawing.Size(517, 71)
        Me.txtrems2.TabIndex = 72
        '
        'Panel6
        '
        Me.Panel6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel6.Controls.Add(Me.btnconfirm2)
        Me.Panel6.Location = New System.Drawing.Point(529, 492)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(227, 71)
        Me.Panel6.TabIndex = 71
        '
        'btnconfirm2
        '
        Me.btnconfirm2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnconfirm2.Enabled = False
        Me.btnconfirm2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirm2.Image = CType(resources.GetObject("btnconfirm2.Image"), System.Drawing.Image)
        Me.btnconfirm2.Location = New System.Drawing.Point(3, 3)
        Me.btnconfirm2.Name = "btnconfirm2"
        Me.btnconfirm2.Size = New System.Drawing.Size(221, 62)
        Me.btnconfirm2.TabIndex = 72
        Me.btnconfirm2.Text = "ALLOWED TO TRAVEL"
        Me.btnconfirm2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnconfirm2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnconfirm2.UseVisualStyleBackColor = True
        '
        'lblplate2
        '
        Me.lblplate2.BackColor = System.Drawing.Color.Transparent
        Me.lblplate2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplate2.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplate2.Location = New System.Drawing.Point(6, 22)
        Me.lblplate2.Name = "lblplate2"
        Me.lblplate2.Size = New System.Drawing.Size(340, 38)
        Me.lblplate2.TabIndex = 69
        Me.lblplate2.Text = "Plate #"
        Me.lblplate2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnimgdl2
        '
        Me.btnimgdl2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl2.Image = CType(resources.GetObject("btnimgdl2.Image"), System.Drawing.Image)
        Me.btnimgdl2.Location = New System.Drawing.Point(521, 439)
        Me.btnimgdl2.Name = "btnimgdl2"
        Me.btnimgdl2.Size = New System.Drawing.Size(20, 30)
        Me.btnimgdl2.TabIndex = 64
        Me.btnimgdl2.Text = "Download Photo"
        Me.btnimgdl2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl2.UseVisualStyleBackColor = True
        Me.btnimgdl2.Visible = False
        '
        'lblimgid2
        '
        Me.lblimgid2.AutoSize = True
        Me.lblimgid2.Location = New System.Drawing.Point(518, 408)
        Me.lblimgid2.Name = "lblimgid2"
        Me.lblimgid2.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid2.TabIndex = 68
        Me.lblimgid2.Text = "imgid"
        Me.lblimgid2.Visible = False
        '
        'btnimgfull2
        '
        Me.btnimgfull2.Enabled = False
        Me.btnimgfull2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull2.Image = CType(resources.GetObject("btnimgfull2.Image"), System.Drawing.Image)
        Me.btnimgfull2.Location = New System.Drawing.Point(555, 375)
        Me.btnimgfull2.Name = "btnimgfull2"
        Me.btnimgfull2.Size = New System.Drawing.Size(176, 30)
        Me.btnimgfull2.TabIndex = 65
        Me.btnimgfull2.Text = "View Larger"
        Me.btnimgfull2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull2.UseVisualStyleBackColor = True
        '
        'imgpanel2
        '
        Me.imgpanel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.imgpanel2.AutoScroll = True
        Me.imgpanel2.BackColor = System.Drawing.Color.MistyRose
        Me.imgpanel2.Location = New System.Drawing.Point(6, 133)
        Me.imgpanel2.Name = "imgpanel2"
        Me.imgpanel2.Size = New System.Drawing.Size(517, 325)
        Me.imgpanel2.TabIndex = 63
        '
        'imgbox2
        '
        Me.imgbox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox2.Location = New System.Drawing.Point(529, 20)
        Me.imgbox2.Name = "imgbox2"
        Me.imgbox2.Size = New System.Drawing.Size(227, 219)
        Me.imgbox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox2.TabIndex = 62
        Me.imgbox2.TabStop = False
        '
        'btnimgremove2
        '
        Me.btnimgremove2.Enabled = False
        Me.btnimgremove2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove2.Image = CType(resources.GetObject("btnimgremove2.Image"), System.Drawing.Image)
        Me.btnimgremove2.Location = New System.Drawing.Point(555, 339)
        Me.btnimgremove2.Name = "btnimgremove2"
        Me.btnimgremove2.Size = New System.Drawing.Size(91, 30)
        Me.btnimgremove2.TabIndex = 60
        Me.btnimgremove2.Text = "Remove"
        Me.btnimgremove2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove2.UseVisualStyleBackColor = True
        '
        'btnimgadd2
        '
        Me.btnimgadd2.Enabled = False
        Me.btnimgadd2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd2.Image = CType(resources.GetObject("btnimgadd2.Image"), System.Drawing.Image)
        Me.btnimgadd2.Location = New System.Drawing.Point(555, 303)
        Me.btnimgadd2.Name = "btnimgadd2"
        Me.btnimgadd2.Size = New System.Drawing.Size(91, 30)
        Me.btnimgadd2.TabIndex = 58
        Me.btnimgadd2.Text = "Add Photo"
        Me.btnimgadd2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd2.UseVisualStyleBackColor = True
        '
        'btnimgcancel2
        '
        Me.btnimgcancel2.Enabled = False
        Me.btnimgcancel2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel2.Image = CType(resources.GetObject("btnimgcancel2.Image"), System.Drawing.Image)
        Me.btnimgcancel2.Location = New System.Drawing.Point(652, 339)
        Me.btnimgcancel2.Name = "btnimgcancel2"
        Me.btnimgcancel2.Size = New System.Drawing.Size(79, 30)
        Me.btnimgcancel2.TabIndex = 61
        Me.btnimgcancel2.Text = "Cancel"
        Me.btnimgcancel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel2.UseVisualStyleBackColor = True
        '
        'btnimgrefresh2
        '
        Me.btnimgrefresh2.Enabled = False
        Me.btnimgrefresh2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh2.Image = CType(resources.GetObject("btnimgrefresh2.Image"), System.Drawing.Image)
        Me.btnimgrefresh2.Location = New System.Drawing.Point(555, 411)
        Me.btnimgrefresh2.Name = "btnimgrefresh2"
        Me.btnimgrefresh2.Size = New System.Drawing.Size(176, 30)
        Me.btnimgrefresh2.TabIndex = 66
        Me.btnimgrefresh2.Text = "Refresh Photos"
        Me.btnimgrefresh2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh2.UseVisualStyleBackColor = True
        '
        'btnimgrename2
        '
        Me.btnimgrename2.Enabled = False
        Me.btnimgrename2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename2.Image = CType(resources.GetObject("btnimgrename2.Image"), System.Drawing.Image)
        Me.btnimgrename2.Location = New System.Drawing.Point(652, 303)
        Me.btnimgrename2.Name = "btnimgrename2"
        Me.btnimgrename2.Size = New System.Drawing.Size(79, 30)
        Me.btnimgrename2.TabIndex = 59
        Me.btnimgrename2.Text = "Rename"
        Me.btnimgrename2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename2.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.White
        Me.TabPage4.Controls.Add(Me.Panel4)
        Me.TabPage4.Location = New System.Drawing.Point(4, 27)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1251, 610)
        Me.TabPage4.TabIndex = 2
        Me.TabPage4.Text = "Fleet Motorpool Logs          "
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Controls.Add(Me.TableLayoutPanel1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Padding = New System.Windows.Forms.Padding(10)
        Me.Panel4.Size = New System.Drawing.Size(1251, 610)
        Me.Panel4.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.btnupload)
        Me.Panel5.Controls.Add(Me.cmbtype)
        Me.Panel5.Controls.Add(Me.btnview)
        Me.Panel5.Controls.Add(Me.btnsearch)
        Me.Panel5.Controls.Add(Me.txtid)
        Me.Panel5.Controls.Add(Me.Label8)
        Me.Panel5.Controls.Add(Me.Label7)
        Me.Panel5.Controls.Add(Me.dateto)
        Me.Panel5.Controls.Add(Me.Label4)
        Me.Panel5.Controls.Add(Me.Label5)
        Me.Panel5.Controls.Add(Me.Label6)
        Me.Panel5.Controls.Add(Me.cmbplate)
        Me.Panel5.Controls.Add(Me.datefrom)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel5.Location = New System.Drawing.Point(10, 10)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1231, 78)
        Me.Panel5.TabIndex = 0
        '
        'btnupload
        '
        Me.btnupload.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.btnupload.Image = CType(resources.GetObject("btnupload.Image"), System.Drawing.Image)
        Me.btnupload.Location = New System.Drawing.Point(811, 39)
        Me.btnupload.Name = "btnupload"
        Me.btnupload.Size = New System.Drawing.Size(98, 23)
        Me.btnupload.TabIndex = 103
        Me.btnupload.Text = "Upload"
        Me.btnupload.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnupload.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnupload.UseVisualStyleBackColor = True
        '
        'cmbtype
        '
        Me.cmbtype.BackColor = System.Drawing.Color.White
        Me.cmbtype.Location = New System.Drawing.Point(452, 40)
        Me.cmbtype.Name = "cmbtype"
        Me.cmbtype.ReadOnly = True
        Me.cmbtype.Size = New System.Drawing.Size(202, 21)
        Me.cmbtype.TabIndex = 102
        '
        'btnview
        '
        Me.btnview.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.btnview.Image = CType(resources.GetObject("btnview.Image"), System.Drawing.Image)
        Me.btnview.Location = New System.Drawing.Point(916, 11)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(98, 23)
        Me.btnview.TabIndex = 47
        Me.btnview.Text = "Pending"
        Me.btnview.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnview.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnview.UseVisualStyleBackColor = True
        Me.btnview.Visible = False
        '
        'btnsearch
        '
        Me.btnsearch.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.btnsearch.Image = CType(resources.GetObject("btnsearch.Image"), System.Drawing.Image)
        Me.btnsearch.Location = New System.Drawing.Point(705, 39)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(98, 23)
        Me.btnsearch.TabIndex = 46
        Me.btnsearch.Text = "Search"
        Me.btnsearch.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnsearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'txtid
        '
        Me.txtid.Location = New System.Drawing.Point(706, 11)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(202, 21)
        Me.txtid.TabIndex = 43
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label8.Location = New System.Drawing.Point(678, 14)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(22, 15)
        Me.Label8.TabIndex = 42
        Me.Label8.Text = "ID:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label7.Location = New System.Drawing.Point(378, 43)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 15)
        Me.Label7.TabIndex = 41
        Me.Label7.Text = "Truck Type:"
        '
        'dateto
        '
        Me.dateto.CustomFormat = "yyyy/MM/dd"
        Me.dateto.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.dateto.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dateto.Location = New System.Drawing.Point(143, 40)
        Me.dateto.Name = "dateto"
        Me.dateto.Size = New System.Drawing.Size(202, 21)
        Me.dateto.TabIndex = 36
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(114, 45)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(23, 15)
        Me.Label4.TabIndex = 40
        Me.Label4.Text = "To:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(13, 18)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(124, 15)
        Me.Label5.TabIndex = 39
        Me.Label5.Text = "Check-up Date From:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label6.Location = New System.Drawing.Point(389, 14)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 15)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "Plate No:"
        '
        'cmbplate
        '
        Me.cmbplate.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbplate.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbplate.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.cmbplate.FormattingEnabled = True
        Me.cmbplate.Location = New System.Drawing.Point(452, 11)
        Me.cmbplate.Name = "cmbplate"
        Me.cmbplate.Size = New System.Drawing.Size(202, 23)
        Me.cmbplate.Sorted = True
        Me.cmbplate.TabIndex = 37
        '
        'datefrom
        '
        Me.datefrom.CustomFormat = "yyyy/MM/dd"
        Me.datefrom.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.datefrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datefrom.Location = New System.Drawing.Point(143, 13)
        Me.datefrom.Name = "datefrom"
        Me.datefrom.Size = New System.Drawing.Size(202, 21)
        Me.datefrom.TabIndex = 35
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel9, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel7, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(10, 94)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1231, 506)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.GroupBox1)
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel9.Location = New System.Drawing.Point(4, 4)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Padding = New System.Windows.Forms.Padding(5)
        Me.Panel9.Size = New System.Drawing.Size(362, 498)
        Me.Panel9.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.StatusStrip1)
        Me.GroupBox1.Controls.Add(Me.lblload3)
        Me.GroupBox1.Controls.Add(Me.grdlist)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(5, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(352, 488)
        Me.GroupBox1.TabIndex = 101
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel4, Me.ToolStripStatusLabel5, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(3, 461)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(346, 24)
        Me.StatusStrip1.TabIndex = 101
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ToolStripStatusLabel4.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(69, 19)
        Me.ToolStripStatusLabel4.Text = "     Done     "
        '
        'ToolStripStatusLabel5
        '
        Me.ToolStripStatusLabel5.BackColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
        Me.ToolStripStatusLabel5.Size = New System.Drawing.Size(10, 19)
        Me.ToolStripStatusLabel5.Text = " "
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ToolStripStatusLabel2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(115, 19)
        Me.ToolStripStatusLabel2.Text = "Pending-Inspection"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.BackColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(10, 19)
        Me.ToolStripStatusLabel1.Text = " "
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.BackColor = System.Drawing.Color.MistyRose
        Me.ToolStripStatusLabel3.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(128, 19)
        Me.ToolStripStatusLabel3.Text = "Pending-Under Repair"
        '
        'lblload3
        '
        Me.lblload3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblload3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblload3.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblload3.Location = New System.Drawing.Point(4, 40)
        Me.lblload3.Name = "lblload3"
        Me.lblload3.Size = New System.Drawing.Size(342, 415)
        Me.lblload3.TabIndex = 100
        Me.lblload3.Text = "Loading..."
        Me.lblload3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grdlist
        '
        Me.grdlist.AllowUserToAddRows = False
        Me.grdlist.AllowUserToDeleteRows = False
        DataGridViewCellStyle68.BackColor = System.Drawing.Color.Honeydew
        Me.grdlist.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle68
        Me.grdlist.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdlist.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdlist.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdlist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle69.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle69.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle69.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle69.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle69.NullValue = Nothing
        DataGridViewCellStyle69.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle69.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle69.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdlist.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle69
        Me.grdlist.ColumnHeadersHeight = 20
        Me.grdlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdlist.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.mid3, Me.platenum3, Me.vtype3, Me.tcon3})
        DataGridViewCellStyle70.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle70.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle70.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle70.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle70.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle70.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle70.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdlist.DefaultCellStyle = DataGridViewCellStyle70
        Me.grdlist.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdlist.EnableHeadersVisualStyles = False
        Me.grdlist.GridColor = System.Drawing.Color.Salmon
        Me.grdlist.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdlist.Location = New System.Drawing.Point(5, 19)
        Me.grdlist.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdlist.Name = "grdlist"
        Me.grdlist.ReadOnly = True
        Me.grdlist.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle71.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle71.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle71.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle71.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle71.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle71.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle71.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdlist.RowHeadersDefaultCellStyle = DataGridViewCellStyle71
        Me.grdlist.RowHeadersWidth = 10
        Me.grdlist.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle72.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle72.NullValue = Nothing
        DataGridViewCellStyle72.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdlist.RowsDefaultCellStyle = DataGridViewCellStyle72
        Me.grdlist.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdlist.Size = New System.Drawing.Size(342, 436)
        Me.grdlist.TabIndex = 45
        '
        'mid3
        '
        Me.mid3.HeaderText = "MID"
        Me.mid3.Name = "mid3"
        Me.mid3.ReadOnly = True
        Me.mid3.Width = 75
        '
        'platenum3
        '
        Me.platenum3.HeaderText = "Plate #"
        Me.platenum3.Name = "platenum3"
        Me.platenum3.ReadOnly = True
        Me.platenum3.Width = 120
        '
        'vtype3
        '
        Me.vtype3.HeaderText = "Vehicle Type"
        Me.vtype3.Name = "vtype3"
        Me.vtype3.ReadOnly = True
        Me.vtype3.Width = 120
        '
        'tcon3
        '
        Me.tcon3.HeaderText = "tcondition"
        Me.tcon3.Name = "tcon3"
        Me.tcon3.ReadOnly = True
        Me.tcon3.Visible = False
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.Panel8)
        Me.Panel7.Controls.Add(Me.lblplatebig)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel7.Location = New System.Drawing.Point(373, 4)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Padding = New System.Windows.Forms.Padding(5)
        Me.Panel7.Size = New System.Drawing.Size(854, 498)
        Me.Panel7.TabIndex = 1
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.grdlogs)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel8.Location = New System.Drawing.Point(5, 57)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Padding = New System.Windows.Forms.Padding(0, 5, 0, 3)
        Me.Panel8.Size = New System.Drawing.Size(844, 436)
        Me.Panel8.TabIndex = 1
        '
        'grdlogs
        '
        Me.grdlogs.AllowUserToAddRows = False
        Me.grdlogs.AllowUserToDeleteRows = False
        DataGridViewCellStyle46.BackColor = System.Drawing.Color.Honeydew
        Me.grdlogs.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle46
        Me.grdlogs.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdlogs.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdlogs.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdlogs.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle47.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle47.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle47.NullValue = Nothing
        DataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdlogs.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle47
        Me.grdlogs.ColumnHeadersHeight = 20
        Me.grdlogs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdlogs.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.Column3, Me.Column5, Me.Column6, Me.tcon})
        DataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle48.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle48.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle48.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdlogs.DefaultCellStyle = DataGridViewCellStyle48
        Me.grdlogs.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdlogs.EnableHeadersVisualStyles = False
        Me.grdlogs.GridColor = System.Drawing.Color.Salmon
        Me.grdlogs.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdlogs.Location = New System.Drawing.Point(0, 5)
        Me.grdlogs.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdlogs.Name = "grdlogs"
        Me.grdlogs.ReadOnly = True
        Me.grdlogs.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle49.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle49.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle49.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle49.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle49.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdlogs.RowHeadersDefaultCellStyle = DataGridViewCellStyle49
        Me.grdlogs.RowHeadersWidth = 10
        Me.grdlogs.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle50.NullValue = Nothing
        DataGridViewCellStyle50.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdlogs.RowsDefaultCellStyle = DataGridViewCellStyle50
        Me.grdlogs.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdlogs.Size = New System.Drawing.Size(844, 325)
        Me.grdlogs.TabIndex = 46
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.HeaderText = "PID"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.Width = 60
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "Time Started"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "Started by"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        Me.DataGridViewTextBoxColumn11.Width = 120
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.HeaderText = "Time Finished"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        '
        'Column3
        '
        Me.Column3.HeaderText = "Finished by"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 120
        '
        'Column5
        '
        Me.Column5.HeaderText = "Remarks"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        '
        'Column6
        '
        Me.Column6.HeaderText = "Checklist#"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'tcon
        '
        Me.tcon.HeaderText = "Condition"
        Me.tcon.Name = "tcon"
        Me.tcon.ReadOnly = True
        '
        'lblplatebig
        '
        Me.lblplatebig.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lblplatebig.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblplatebig.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblplatebig.Font = New System.Drawing.Font("Century Gothic", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplatebig.Location = New System.Drawing.Point(5, 5)
        Me.lblplatebig.Name = "lblplatebig"
        Me.lblplatebig.Size = New System.Drawing.Size(844, 52)
        Me.lblplatebig.TabIndex = 0
        Me.lblplatebig.Text = "PLATE #"
        Me.lblplatebig.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.White
        Me.TabPage5.Controls.Add(Me.Panel10)
        Me.TabPage5.Location = New System.Drawing.Point(4, 27)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1251, 610)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Not yet Arrived          "
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.GroupBox2)
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel10.Location = New System.Drawing.Point(3, 3)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(1245, 604)
        Me.Panel10.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.btnnot)
        Me.GroupBox2.Controls.Add(Me.txtplatenot)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.lblloadnot)
        Me.GroupBox2.Controls.Add(Me.btnrefnot)
        Me.GroupBox2.Controls.Add(Me.grdnot)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(559, 588)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Trucks"
        '
        'btnnot
        '
        Me.btnnot.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnnot.Image = CType(resources.GetObject("btnnot.Image"), System.Drawing.Image)
        Me.btnnot.Location = New System.Drawing.Point(479, 18)
        Me.btnnot.Name = "btnnot"
        Me.btnnot.Size = New System.Drawing.Size(75, 23)
        Me.btnnot.TabIndex = 101
        Me.btnnot.Text = "Search"
        Me.btnnot.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnnot.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnnot.UseVisualStyleBackColor = True
        '
        'txtplatenot
        '
        Me.txtplatenot.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtplatenot.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtplatenot.Location = New System.Drawing.Point(354, 19)
        Me.txtplatenot.Name = "txtplatenot"
        Me.txtplatenot.Size = New System.Drawing.Size(119, 21)
        Me.txtplatenot.TabIndex = 100
        '
        'Label10
        '
        Me.Label10.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(303, 22)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(45, 15)
        Me.Label10.TabIndex = 99
        Me.Label10.Text = "Plate#:"
        '
        'lblloadnot
        '
        Me.lblloadnot.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblloadnot.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblloadnot.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblloadnot.Location = New System.Drawing.Point(7, 87)
        Me.lblloadnot.Name = "lblloadnot"
        Me.lblloadnot.Size = New System.Drawing.Size(545, 460)
        Me.lblloadnot.TabIndex = 98
        Me.lblloadnot.Text = "Loading..."
        Me.lblloadnot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnrefnot
        '
        Me.btnrefnot.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefnot.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefnot.Image = CType(resources.GetObject("btnrefnot.Image"), System.Drawing.Image)
        Me.btnrefnot.Location = New System.Drawing.Point(452, 552)
        Me.btnrefnot.Name = "btnrefnot"
        Me.btnrefnot.Size = New System.Drawing.Size(101, 30)
        Me.btnrefnot.TabIndex = 70
        Me.btnrefnot.Text = "Refresh List"
        Me.btnrefnot.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefnot.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefnot.UseVisualStyleBackColor = True
        '
        'grdnot
        '
        Me.grdnot.AllowUserToAddRows = False
        Me.grdnot.AllowUserToDeleteRows = False
        DataGridViewCellStyle73.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdnot.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle73
        Me.grdnot.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdnot.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdnot.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle74.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle74.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle74.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle74.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle74.NullValue = Nothing
        DataGridViewCellStyle74.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle74.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle74.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdnot.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle74
        Me.grdnot.ColumnHeadersHeight = 30
        Me.grdnot.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdnot.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column4, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16})
        DataGridViewCellStyle76.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle76.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle76.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle76.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle76.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle76.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle76.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdnot.DefaultCellStyle = DataGridViewCellStyle76
        Me.grdnot.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdnot.EnableHeadersVisualStyles = False
        Me.grdnot.GridColor = System.Drawing.Color.Salmon
        Me.grdnot.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdnot.Location = New System.Drawing.Point(6, 55)
        Me.grdnot.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdnot.MultiSelect = False
        Me.grdnot.Name = "grdnot"
        Me.grdnot.ReadOnly = True
        Me.grdnot.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle77.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle77.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle77.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle77.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle77.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle77.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle77.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdnot.RowHeadersDefaultCellStyle = DataGridViewCellStyle77
        Me.grdnot.RowHeadersWidth = 10
        Me.grdnot.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle78.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle78.NullValue = Nothing
        DataGridViewCellStyle78.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdnot.RowsDefaultCellStyle = DataGridViewCellStyle78
        Me.grdnot.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdnot.Size = New System.Drawing.Size(547, 492)
        Me.grdnot.TabIndex = 10
        '
        'Column4
        '
        Me.Column4.Frozen = True
        Me.Column4.HeaderText = "Trip#"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Width = 120
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.Frozen = True
        Me.DataGridViewTextBoxColumn14.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn14.MinimumWidth = 80
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        Me.DataGridViewTextBoxColumn14.Width = 110
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.HeaderText = "Vehicle Type"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        Me.DataGridViewTextBoxColumn15.Width = 120
        '
        'DataGridViewTextBoxColumn16
        '
        DataGridViewCellStyle75.Format = "yyyy/MM/dd"
        Me.DataGridViewTextBoxColumn16.DefaultCellStyle = DataGridViewCellStyle75
        Me.DataGridViewTextBoxColumn16.HeaderText = "Status"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.ReadOnly = True
        Me.DataGridViewTextBoxColumn16.Width = 150
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.White
        Me.TabPage6.Controls.Add(Me.GroupBox3)
        Me.TabPage6.Location = New System.Drawing.Point(4, 27)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1251, 610)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Available Trucks          "
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.BackColor = System.Drawing.Color.White
        Me.GroupBox3.Controls.Add(Me.btnava)
        Me.GroupBox3.Controls.Add(Me.txtplateava)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.lblloadava)
        Me.GroupBox3.Controls.Add(Me.btnrefava)
        Me.GroupBox3.Controls.Add(Me.grdava)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(559, 588)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Trucks"
        '
        'btnava
        '
        Me.btnava.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnava.Image = CType(resources.GetObject("btnava.Image"), System.Drawing.Image)
        Me.btnava.Location = New System.Drawing.Point(479, 18)
        Me.btnava.Name = "btnava"
        Me.btnava.Size = New System.Drawing.Size(75, 23)
        Me.btnava.TabIndex = 101
        Me.btnava.Text = "Search"
        Me.btnava.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnava.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnava.UseVisualStyleBackColor = True
        '
        'txtplateava
        '
        Me.txtplateava.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtplateava.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtplateava.Location = New System.Drawing.Point(354, 19)
        Me.txtplateava.Name = "txtplateava"
        Me.txtplateava.Size = New System.Drawing.Size(119, 21)
        Me.txtplateava.TabIndex = 100
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(303, 22)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 15)
        Me.Label9.TabIndex = 99
        Me.Label9.Text = "Plate#:"
        '
        'lblloadava
        '
        Me.lblloadava.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblloadava.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblloadava.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblloadava.Location = New System.Drawing.Point(7, 87)
        Me.lblloadava.Name = "lblloadava"
        Me.lblloadava.Size = New System.Drawing.Size(545, 460)
        Me.lblloadava.TabIndex = 98
        Me.lblloadava.Text = "Loading..."
        Me.lblloadava.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnrefava
        '
        Me.btnrefava.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnrefava.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefava.Image = CType(resources.GetObject("btnrefava.Image"), System.Drawing.Image)
        Me.btnrefava.Location = New System.Drawing.Point(452, 552)
        Me.btnrefava.Name = "btnrefava"
        Me.btnrefava.Size = New System.Drawing.Size(101, 30)
        Me.btnrefava.TabIndex = 70
        Me.btnrefava.Text = "Refresh List"
        Me.btnrefava.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefava.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefava.UseVisualStyleBackColor = True
        '
        'grdava
        '
        Me.grdava.AllowUserToAddRows = False
        Me.grdava.AllowUserToDeleteRows = False
        DataGridViewCellStyle79.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdava.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle79
        Me.grdava.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdava.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdava.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle80.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle80.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle80.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle80.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle80.NullValue = Nothing
        DataGridViewCellStyle80.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle80.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle80.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdava.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle80
        Me.grdava.ColumnHeadersHeight = 30
        Me.grdava.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdava.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn19})
        DataGridViewCellStyle82.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle82.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle82.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle82.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle82.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle82.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle82.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdava.DefaultCellStyle = DataGridViewCellStyle82
        Me.grdava.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdava.EnableHeadersVisualStyles = False
        Me.grdava.GridColor = System.Drawing.Color.Salmon
        Me.grdava.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdava.Location = New System.Drawing.Point(6, 55)
        Me.grdava.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdava.MultiSelect = False
        Me.grdava.Name = "grdava"
        Me.grdava.ReadOnly = True
        Me.grdava.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle83.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle83.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle83.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle83.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle83.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle83.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle83.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdava.RowHeadersDefaultCellStyle = DataGridViewCellStyle83
        Me.grdava.RowHeadersWidth = 10
        Me.grdava.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle84.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle84.NullValue = Nothing
        DataGridViewCellStyle84.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdava.RowsDefaultCellStyle = DataGridViewCellStyle84
        Me.grdava.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdava.Size = New System.Drawing.Size(547, 492)
        Me.grdava.TabIndex = 10
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.Frozen = True
        Me.DataGridViewTextBoxColumn17.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn17.MinimumWidth = 80
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        Me.DataGridViewTextBoxColumn17.Width = 110
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "Vehicle Type"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        Me.DataGridViewTextBoxColumn18.Width = 120
        '
        'DataGridViewTextBoxColumn19
        '
        DataGridViewCellStyle81.Format = "yyyy/MM/dd"
        Me.DataGridViewTextBoxColumn19.DefaultCellStyle = DataGridViewCellStyle81
        Me.DataGridViewTextBoxColumn19.HeaderText = "Checklist#"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.ReadOnly = True
        Me.DataGridViewTextBoxColumn19.Width = 150
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.White
        Me.TabPage7.Controls.Add(Me.Panel11)
        Me.TabPage7.Location = New System.Drawing.Point(4, 27)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(1251, 610)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "App Completed Checklist           "
        '
        'Panel11
        '
        Me.Panel11.AutoScroll = True
        Me.Panel11.Controls.Add(Me.GroupBox4)
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel11.Location = New System.Drawing.Point(3, 3)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(1245, 604)
        Me.Panel11.TabIndex = 0
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.BackColor = System.Drawing.Color.White
        Me.GroupBox4.Controls.Add(Me.txtappid)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Controls.Add(Me.dtcom)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Controls.Add(Me.dfcom)
        Me.GroupBox4.Controls.Add(Me.Label12)
        Me.GroupBox4.Controls.Add(Me.btncompleted)
        Me.GroupBox4.Controls.Add(Me.txtapp)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.lblloadcom)
        Me.GroupBox4.Controls.Add(Me.grdapp_com)
        Me.GroupBox4.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(1239, 583)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Trucks"
        '
        'txtappid
        '
        Me.txtappid.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtappid.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtappid.Location = New System.Drawing.Point(1069, 19)
        Me.txtappid.Name = "txtappid"
        Me.txtappid.Size = New System.Drawing.Size(78, 21)
        Me.txtappid.TabIndex = 107
        '
        'Label15
        '
        Me.Label15.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(1032, 22)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(31, 15)
        Me.Label15.TabIndex = 106
        Me.Label15.Text = "MID:"
        '
        'dtcom
        '
        Me.dtcom.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dtcom.CustomFormat = "yyyy/MM/dd"
        Me.dtcom.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.dtcom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtcom.Location = New System.Drawing.Point(698, 19)
        Me.dtcom.Name = "dtcom"
        Me.dtcom.Size = New System.Drawing.Size(125, 21)
        Me.dtcom.TabIndex = 105
        '
        'Label14
        '
        Me.Label14.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(673, 22)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(23, 15)
        Me.Label14.TabIndex = 104
        Me.Label14.Text = "To:"
        '
        'dfcom
        '
        Me.dfcom.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dfcom.CustomFormat = "yyyy/MM/dd"
        Me.dfcom.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.dfcom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dfcom.Location = New System.Drawing.Point(529, 19)
        Me.dfcom.Name = "dfcom"
        Me.dfcom.Size = New System.Drawing.Size(125, 21)
        Me.dfcom.TabIndex = 103
        '
        'Label12
        '
        Me.Label12.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(459, 22)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(68, 15)
        Me.Label12.TabIndex = 102
        Me.Label12.Text = "From Date:"
        '
        'btncompleted
        '
        Me.btncompleted.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncompleted.Image = CType(resources.GetObject("btncompleted.Image"), System.Drawing.Image)
        Me.btncompleted.Location = New System.Drawing.Point(1159, 18)
        Me.btncompleted.Name = "btncompleted"
        Me.btncompleted.Size = New System.Drawing.Size(75, 23)
        Me.btncompleted.TabIndex = 101
        Me.btncompleted.Text = "Search"
        Me.btncompleted.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncompleted.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncompleted.UseVisualStyleBackColor = True
        '
        'txtapp
        '
        Me.txtapp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtapp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtapp.Location = New System.Drawing.Point(897, 19)
        Me.txtapp.Name = "txtapp"
        Me.txtapp.Size = New System.Drawing.Size(119, 21)
        Me.txtapp.TabIndex = 100
        '
        'Label11
        '
        Me.Label11.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(846, 22)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(45, 15)
        Me.Label11.TabIndex = 99
        Me.Label11.Text = "Plate#:"
        '
        'lblloadcom
        '
        Me.lblloadcom.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblloadcom.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblloadcom.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblloadcom.Location = New System.Drawing.Point(7, 87)
        Me.lblloadcom.Name = "lblloadcom"
        Me.lblloadcom.Size = New System.Drawing.Size(1225, 481)
        Me.lblloadcom.TabIndex = 98
        Me.lblloadcom.Text = "Loading..."
        Me.lblloadcom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblloadcom.Visible = False
        '
        'grdapp_com
        '
        Me.grdapp_com.AllowUserToAddRows = False
        Me.grdapp_com.AllowUserToDeleteRows = False
        DataGridViewCellStyle85.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdapp_com.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle85
        Me.grdapp_com.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdapp_com.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grdapp_com.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle86.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle86.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle86.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle86.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle86.NullValue = Nothing
        DataGridViewCellStyle86.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle86.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle86.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdapp_com.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle86
        Me.grdapp_com.ColumnHeadersHeight = 30
        Me.grdapp_com.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grdapp_com.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column8, Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn20, Me.Column9, Me.Column11, Me.Column10, Me.start, Me.finish, Me.mechanic, Me.chknum})
        DataGridViewCellStyle88.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle88.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle88.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle88.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle88.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle88.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle88.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdapp_com.DefaultCellStyle = DataGridViewCellStyle88
        Me.grdapp_com.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grdapp_com.EnableHeadersVisualStyles = False
        Me.grdapp_com.GridColor = System.Drawing.Color.Salmon
        Me.grdapp_com.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grdapp_com.Location = New System.Drawing.Point(6, 55)
        Me.grdapp_com.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grdapp_com.MultiSelect = False
        Me.grdapp_com.Name = "grdapp_com"
        Me.grdapp_com.ReadOnly = True
        Me.grdapp_com.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle89.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle89.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle89.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle89.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle89.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle89.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle89.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdapp_com.RowHeadersDefaultCellStyle = DataGridViewCellStyle89
        Me.grdapp_com.RowHeadersWidth = 10
        Me.grdapp_com.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle90.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle90.NullValue = Nothing
        DataGridViewCellStyle90.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdapp_com.RowsDefaultCellStyle = DataGridViewCellStyle90
        Me.grdapp_com.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grdapp_com.Size = New System.Drawing.Size(1227, 513)
        Me.grdapp_com.TabIndex = 10
        '
        'Column8
        '
        Me.Column8.HeaderText = "MID"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        Me.Column8.Width = 80
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.HeaderText = "Plate #"
        Me.DataGridViewTextBoxColumn13.MinimumWidth = 80
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        Me.DataGridViewTextBoxColumn13.Width = 110
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.HeaderText = "Vehicle Type"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.ReadOnly = True
        Me.DataGridViewTextBoxColumn20.Width = 120
        '
        'Column9
        '
        Me.Column9.HeaderText = "Trip#"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        Me.Column9.Width = 130
        '
        'Column11
        '
        Me.Column11.HeaderText = "Arrived"
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        Me.Column11.Width = 140
        '
        'Column10
        '
        Me.Column10.HeaderText = "Date of Inspection"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        '
        'start
        '
        Me.start.HeaderText = "Time Started"
        Me.start.Name = "start"
        Me.start.ReadOnly = True
        '
        'finish
        '
        Me.finish.HeaderText = "Time Finished"
        Me.finish.Name = "finish"
        Me.finish.ReadOnly = True
        '
        'mechanic
        '
        Me.mechanic.HeaderText = "Mechanic"
        Me.mechanic.Name = "mechanic"
        Me.mechanic.ReadOnly = True
        Me.mechanic.Width = 150
        '
        'chknum
        '
        DataGridViewCellStyle87.Format = "yyyy/MM/dd"
        Me.chknum.DefaultCellStyle = DataGridViewCellStyle87
        Me.chknum.HeaderText = "Checklist#"
        Me.chknum.Name = "chknum"
        Me.chknum.ReadOnly = True
        Me.chknum.Width = 130
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewAttachmentsToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(171, 26)
        '
        'ViewAttachmentsToolStripMenuItem
        '
        Me.ViewAttachmentsToolStripMenuItem.Name = "ViewAttachmentsToolStripMenuItem"
        Me.ViewAttachmentsToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.ViewAttachmentsToolStripMenuItem.Text = "View Attachments"
        '
        'motorpool
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1279, 661)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "motorpool"
        Me.Padding = New System.Windows.Forms.Padding(10)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Motorpool Inspection"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel0.ResumeLayout(False)
        Me.gstep0.ResumeLayout(False)
        CType(Me.grdstep0, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp0.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.gstep1.ResumeLayout(False)
        CType(Me.grdstep1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp1.ResumeLayout(False)
        Me.grp1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        CType(Me.imgbox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.gstep2.ResumeLayout(False)
        CType(Me.grdstep2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp2.ResumeLayout(False)
        Me.grp2.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        CType(Me.imgbox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.grdlist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        CType(Me.grdlogs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.grdnot, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.grdava, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.grdapp_com, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Panel1 As Panel
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents gstep1 As GroupBox
    Friend WithEvents lblload1 As Label
    Friend WithEvents btnrefstep1 As Button
    Friend WithEvents grdstep1 As DataGridView
    Friend WithEvents grp1 As GroupBox
    Friend WithEvents lblimgname1 As Label
    Friend WithEvents lblimgdate1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents lblDesiredSize As TextBox
    Friend WithEvents lblOriginalSize As Label
    Friend WithEvents lblCompressedSize As Label
    Friend WithEvents lblCompressionLevel As Label
    Friend WithEvents pgbar1 As ProgressBar
    Friend WithEvents btnstartpre As Button
    Friend WithEvents lbltype1 As Label
    Friend WithEvents cmbimg1 As ComboBox
    Friend WithEvents txtrems1 As TextBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents btnexempt1 As Button
    Friend WithEvents btnconfirm1 As Button
    Friend WithEvents Label32 As Label
    Friend WithEvents lblplate1 As Label
    Friend WithEvents btnimgdl1 As Button
    Friend WithEvents lblimgid1 As Label
    Friend WithEvents btnimgfull1 As Button
    Friend WithEvents imgpanel1 As Panel
    Friend WithEvents imgbox1 As PictureBox
    Friend WithEvents btnimgremove1 As Button
    Friend WithEvents btnimgadd1 As Button
    Friend WithEvents btnimgcancel1 As Button
    Friend WithEvents btnimgrefresh1 As Button
    Friend WithEvents btnimgrename1 As Button
    Friend WithEvents btnrepair As Button
    Friend WithEvents txtchk As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents gstep2 As GroupBox
    Friend WithEvents lblload2 As Label
    Friend WithEvents btnrefstep2 As Button
    Friend WithEvents grdstep2 As DataGridView
    Friend WithEvents grp2 As GroupBox
    Friend WithEvents lblimgname2 As Label
    Friend WithEvents lblimgdate2 As Label
    Friend WithEvents pgbar2 As ProgressBar
    Friend WithEvents lbltype2 As Label
    Friend WithEvents btnstartdiesel As Button
    Friend WithEvents cmbimg2 As ComboBox
    Friend WithEvents txtrems2 As TextBox
    Friend WithEvents Panel6 As Panel
    Friend WithEvents btnconfirm2 As Button
    Friend WithEvents lblplate2 As Label
    Friend WithEvents btnimgdl2 As Button
    Friend WithEvents lblimgid2 As Label
    Friend WithEvents btnimgfull2 As Button
    Friend WithEvents imgpanel2 As Panel
    Friend WithEvents imgbox2 As PictureBox
    Friend WithEvents btnimgremove2 As Button
    Friend WithEvents btnimgadd2 As Button
    Friend WithEvents btnimgcancel2 As Button
    Friend WithEvents btnimgrefresh2 As Button
    Friend WithEvents btnimgrename2 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents Panel4 As Panel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents txtid As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents dateto As DateTimePicker
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents cmbplate As ComboBox
    Friend WithEvents datefrom As DateTimePicker
    Friend WithEvents grdlist As DataGridView
    Friend WithEvents btnsearch As Button
    Friend WithEvents btnview As Button
    Friend WithEvents lblplatebig As Label
    Friend WithEvents lblload3 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel5 As ToolStripStatusLabel
    Friend WithEvents cmbtype As TextBox
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents Panel0 As Panel
    Friend WithEvents gstep0 As GroupBox
    Friend WithEvents lblload0 As Label
    Friend WithEvents btnrefstep0 As Button
    Friend WithEvents grdstep0 As DataGridView
    Friend WithEvents grp0 As GroupBox
    Friend WithEvents btnstartfor As Button
    Friend WithEvents lbltype0 As Label
    Friend WithEvents lblplate0 As Label
    Friend WithEvents Panel12 As Panel
    Friend WithEvents lblstart As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Panel8 As Panel
    Friend WithEvents grdlogs As DataGridView
    Friend WithEvents Panel9 As Panel
    Friend WithEvents mid3 As DataGridViewTextBoxColumn
    Friend WithEvents platenum3 As DataGridViewTextBoxColumn
    Friend WithEvents vtype3 As DataGridViewTextBoxColumn
    Friend WithEvents tcon3 As DataGridViewTextBoxColumn
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents tcon As DataGridViewTextBoxColumn
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents ViewAttachmentsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents Panel10 As Panel
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnnot As Button
    Friend WithEvents txtplatenot As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents lblloadnot As Label
    Friend WithEvents btnrefnot As Button
    Friend WithEvents grdnot As DataGridView
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents btnava As Button
    Friend WithEvents txtplateava As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents lblloadava As Label
    Friend WithEvents btnrefava As Button
    Friend WithEvents grdava As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As DataGridViewTextBoxColumn
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents Panel11 As Panel
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents btncompleted As Button
    Friend WithEvents txtapp As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents lblloadcom As Label
    Friend WithEvents grdapp_com As DataGridView
    Friend WithEvents dfcom As DateTimePicker
    Friend WithEvents Label12 As Label
    Friend WithEvents dtcom As DateTimePicker
    Friend WithEvents Label14 As Label
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents Column11 As DataGridViewTextBoxColumn
    Friend WithEvents Column10 As DataGridViewTextBoxColumn
    Friend WithEvents start As DataGridViewTextBoxColumn
    Friend WithEvents finish As DataGridViewTextBoxColumn
    Friend WithEvents mechanic As DataGridViewTextBoxColumn
    Friend WithEvents chknum As DataGridViewTextBoxColumn
    Friend WithEvents btnupload As Button
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column28 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents txtappid As TextBox
    Friend WithEvents Label15 As Label
End Class
