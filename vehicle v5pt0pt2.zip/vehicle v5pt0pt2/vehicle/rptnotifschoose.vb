﻿Public Class rptnotifschoose

    Private Sub btnok_Click(sender As Object, e As EventArgs) Handles btnok.Click
        Dim pmsdue As String = ""
        If chk0.Checked = False And chk1.Checked = False And chk2.Checked = False And chk3.Checked = False Then
            MsgBox("Choose change oil status.", MsgBoxStyle.Exclamation, "")
            Exit Sub
        ElseIf chk0.Checked = False And chk1.Checked = True And chk2.Checked = True And chk3.Checked = True Then
            'all due
            pmsdue = " and not (o.odoend < (p.nextodo - 500))"
        ElseIf chk0.Checked = True And chk1.Checked = False And chk2.Checked = False And chk3.Checked = False Then
            'all updated
            pmsdue = " and (o.odoend < (p.nextodo - 500))"
        ElseIf chk0.Checked = True And chk1.Checked = True And chk2.Checked = True And chk3.Checked = True Then
            pmsdue = ""
        Else
            If chk0.Checked = True Then
                pmsdue = pmsdue & " and (o.odoend < (p.nextodo - 500))"
            End If
            If chk1.Checked = True Then
                pmsdue = pmsdue & " and (o.odoend >= (p.nextodo - 500) And o.odoend <= (p.nextodo - 0.1))"
            End If
            If chk2.Checked = True Then
                pmsdue = pmsdue & " and o.odoend = p.nextodo"
            End If
            If chk3.Checked = True Then
                pmsdue = pmsdue & " and o.odoend > p.nextodo"
            End If
        End If


        '/pms_viewall(pmsdue)
        rptnotifsprev1.WindowState = FormWindowState.Maximized
        rptnotifsprev1.ShowDialog()
        Me.Dispose()
    End Sub

    Private Sub rptnotifschoose_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class