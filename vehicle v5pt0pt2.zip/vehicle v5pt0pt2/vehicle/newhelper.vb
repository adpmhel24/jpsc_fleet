﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Globalization

Public Class newhelper
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Public drcnf As Boolean = False
    Public dreason As String = "", dfinish As Date
    Dim wctab As String = "tab1"

    Dim ofd As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim pic As PictureBox
    Dim meron As Boolean = False
    Dim culture As CultureInfo = Nothing

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub newhelper_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated

    End Sub

    Private Sub newhelper_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
       
    End Sub

    Private Sub newhelper_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        loadcompsch()
        loaddoc()
        loadwhsesch()
        loadwhse()

        btnok.PerformClick()

        datelastrenew.MaxDate = Date.Now    '/// nag eerrror na lumalagpas kc sya sa maximum date
        dateexpired.MinDate = datelastrenew.Value

        datelastrenew.CustomFormat = "yyyy/MM/dd"
        dateexpired.CustomFormat = "yyyy/MM/dd"

        datebirth.CustomFormat = "yyyy/MM/dd"
        datebirth.Value = Date.Now
        datebirth.MaxDate = datebirth.Value.AddYears(-14)
        datebirth.Value = datebirth.MaxDate

    End Sub

    Private Sub TabControl1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TabControl1.MouseClick
        If TabControl1.SelectedTab Is tab1 Then
            wctab = "tab1"
        ElseIf TabControl1.SelectedTab Is tab2 Then
            wctab = "tab2"
            If lblhelperbig.Text = "" Then
                GroupBox6.Enabled = False
            Else
                GroupBox6.Enabled = True
                btnviewalldoc.PerformClick()
                If btnupdatedoc.Text = "Update" Then
                    chkuse.Checked = False
                    chkuse.Checked = True
                End If
            End If
        ElseIf TabControl1.SelectedTab Is tab4 Then
            wctab = "tab4"
            If lblhelperbig.Text = "" Then
                GroupBox9.Enabled = False
            Else
                GroupBox9.Enabled = True
                btnimgrefresh.PerformClick()
            End If
        End If
    End Sub

    Private Sub TabControl1_TabIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl1.TabIndexChanged
        If TabControl1.SelectedTab Is tab1 Then
            wctab = "tab1"
        ElseIf TabControl1.SelectedTab Is tab2 Then
            wctab = "tab2"
        ElseIf TabControl1.SelectedTab Is tab4 Then
            wctab = "tab4"
        End If
    End Sub

    Public Sub loadcompsch()
        Try
            cmbcompsch.Items.Clear()

            cmbcompany.Items.Clear()
            cmbcompany.Items.Add("")

            sql = "Select * from tblcompany where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbcompsch.Items.Add(dr("company"))
                cmbcompany.Items.Add(dr("company"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbcompsch.Items.Count <> 0 Then
                cmbcompsch.Items.Add("All")
                cmbcompsch.SelectedIndex = 0
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loaddoc()
        Try
            cmbdocname.Items.Clear()
            cmbdocname.Items.Add("")

            sql = "Select * from tbldoc where status='1' order by docname"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbdocname.Items.Add(dr("docname"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadwhsesch()
        Try
            cmbwhsesch.Items.Clear()

            If cmbcompsch.SelectedItem <> "All" Then
                sql = "Select * from tblwhse where status='1' and company='" & cmbcompsch.SelectedItem & "'"
            Else
                sql = "Select * from tblwhse where status='1'"
            End If

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbwhsesch.Items.Add(dr("whsename"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbwhsesch.Items.Count <> 0 Then
                cmbwhsesch.Items.Add("All")
                cmbwhsesch.SelectedIndex = 0
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadwhse()
        Try
            cmbwhse.Items.Clear()
            cmbwhse.Items.Add("")

            sql = "Select * from tblwhse where status='1' and company='" & cmbcompany.SelectedItem & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbwhse.Items.Add(dr("whsename"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txthelper_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txthelper.Leave, txthelper.Leave
        Try
            txthelper.Text = StrConv(Trim(txthelper.Text), VbStrConv.ProperCase)

            If Trim(txthelper.Text) <> "" And txthelper.ReadOnly = False Then
                If btnvadd.Text = "Add" Then
                    sql = "Select helper from tblhelper where helper='" & Trim(txthelper.Text) & "'"
                ElseIf btnuphelper.Text = "Save" Then
                    sql = "Select helper from tblhelper where helper='" & Trim(txthelper.Text) & "' and helperid<>'" & lblid.Text & "'"
                End If

                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    Me.Cursor = Cursors.Default
                    MsgBox(Trim(txthelper.Text) & " is already exist.", MsgBoxStyle.Exclamation, "")
                    txthelper.Text = ""
                    txthelper.Focus()
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txthelper_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txthelper.TextChanged, txthelper.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ. "
        Dim theText As String = txthelper.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txthelper.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txthelper.Text.Length - 1
            Letter = txthelper.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txthelper.Text = theText
        txthelper.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtlicense_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtlicense.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789-"
        Dim theText As String = txtlicense.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtlicense.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtlicense.Text.Length - 1
            Letter = txtlicense.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtlicense.Text = theText
        txtlicense.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtcontact_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcontact.TextChanged
        Dim charactersDisallowed As String = "0123456789"
        Dim theText As String = txtcontact.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtcontact.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtcontact.Text.Length - 1
            Letter = txtcontact.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtcontact.Text = theText
        txtcontact.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtrems_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnrefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrefresh.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            grdhelper.Rows.Clear()
            Dim plnum As String = ""

            'sql = sql & " order by vplate, platenum"
            sql = lbllastsearch.Text
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read

                grdhelper.Rows.Add(dr1("helperid"), dr1("helper"), dr1("license").ToString, "", dr1("status"))
            End While
            dr1.Dispose()
            cmd1.Dispose()

            'lblselect.Text = cmbwhsesch.SelectedItem
            'grdhelper.Sort(grdhelper.Columns(2), ListSortDirection.Ascending)
            'grdhelper.Sort(grdhelper.Columns(1), ListSortDirection.Ascending)

            loaddoc()
            loadcompsch()

            If grdhelper.Rows.Count = 0 Then
                btnvdeac.Enabled = False
                TabControl1.Enabled = False
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            Else
                btnvdeac.Enabled = True
                TabControl1.Enabled = True
                'checknotifdocu and rms
                checknotifgrd()
                grdhelper.Enabled = True
                btnuphelper.Enabled = True
                selectionchnge()
            End If

            btnvadd.Text = "Add Helper"
            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            grdhelper.Rows.Clear()
            Dim plnum As String = ""

            If chkdeac.Checked = False Then
                sql = "Select * from tblhelper where status='1'"
            Else
                sql = "Select * from tblhelper where status='0'"
            End If

            If Trim(txtsearch.Text) <> "" Then
                sql = sql & " and helper like '%" & Trim(txtsearch.Text) & "%'"
            End If

            If cmbwhsesch.SelectedItem <> "" And cmbwhsesch.SelectedItem <> "All" Then
                sql = sql & " and whsename ='" & cmbwhsesch.SelectedItem & "'"
            End If

            If cmbcompsch.SelectedItem <> "" And cmbcompsch.SelectedItem <> "All" Then
                sql = sql & " and company ='" & cmbcompsch.SelectedItem & "'"
            End If

            sql = sql & " order by helper"

            lbllastsearch.Text = sql
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read

                grdhelper.Rows.Add(dr1("helperid"), dr1("helper"), dr1("license").ToString, "", dr1("status"))
            End While
            dr1.Dispose()
            cmd1.Dispose()

            lblselect.Text = cmbwhsesch.SelectedItem
            'grdhelper.Sort(grdhelper.Columns(2), ListSortDirection.Ascending)

            loaddoc()
            loadcompsch()

            If grdhelper.Rows.Count = 0 Then
                btnvdeac.Enabled = False
                TabControl1.Enabled = False
                Me.Cursor = Cursors.Default
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            Else
                btnvdeac.Enabled = True
                TabControl1.Enabled = True
                'checknotifdocu and rms
                checknotifgrd()
                grdhelper.Enabled = True
                btnuphelper.Enabled = True
                selectionchnge()
            End If

            btnvadd.Text = "Add Helper"
            txtsearch.Text = ""

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checknotifgrd()
        Try

            For Each row As DataGridViewRow In grdhelper.Rows
                Dim temp As Integer = 0

                'tbldocexp
                sql = "Select * from tbldocexp where helperid='" & grdhelper.Rows(row.Index).Cells(0).Value & "' and status='1' and (statusexp='Soon to expire' or statusexp='Expired')"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                While dr.Read
                    temp = temp + 1
                End While
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                grdhelper.Rows(row.Index).Cells(3).Value = temp

                If temp <> 0 Then
                    grdhelper.Rows(row.Index).DefaultCellStyle.BackColor = Color.PeachPuff
                Else
                    grdhelper.Rows(row.Index).DefaultCellStyle.BackColor = Color.White
                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub selectionchnge()
        Try
            Me.Cursor = Cursors.WaitCursor

            If grdhelper.Rows.Count <> 0 Then

                'lahat ng controls sa tab dpt read only lng
                readonlytrue()
                '//  MsgBox(grdhelper.Rows(grdhelper.CurrentRow.Index).Cells(1).Value.ToString)
                ' If wctab = "tab1"  Then
                Dim cmd As SqlCommand
                Dim dr As SqlDataReader
                If btnvadd.Text <> "Add" Then
                    Dim plnum As String = ""

                    sql = "Select * from tblhelper where tblhelper.helper='" & grdhelper.Rows(grdhelper.CurrentRow.Index).Cells(1).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        lblhelperbig.Text = dr("helper").ToString
                        lblid.Text = dr("helperid")
                        txthelper.Text = dr("helper").ToString
                        txtlicense.Text = dr("license").ToString
                        txtcontact.Text = dr("contact").ToString
                        If IsDBNull(dr("bday")) = False Then
                            datebirth.Value = Format(dr("bday"), "yyyy/MM/dd")
                        End If
                        cmbcompany.SelectedItem = dr("company").ToString
                        cmbwhse.SelectedItem = dr("whsename").ToString

                        '////listbox.Items.Clear()
                        '////imgphoto.Image = Nothing
                        txtrems.Text = dr("remarks").ToString
                        If dr("status") = 0 Then
                            lbldreason.Visible = True
                            lbldreason.Text = "Deactivated status: " & dr("dreason").ToString
                        Else
                            lbldreason.Visible = False
                        End If
                        lblprimary.Text = dr("imgid").ToString
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()


                    imgphoto.Image = Nothing
                    If lblprimary.Text <> "" Then
                        sql = "Select * from tblimage where imgid='" & lblprimary.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            'MsgBox(dr("name").ToString)
                            Dim data As Byte() = DirectCast(dr("img"), Byte())
                            Dim ms As New MemoryStream(data)

                            imgphoto.Image = Image.FromStream(ms)
                            imgphoto.SizeMode = PictureBoxSizeMode.Zoom
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()
                    End If


                    If wctab = "tab2" Then
                        viewalldoc()
                    ElseIf wctab = "tab4" Then
                        btnimgrefresh.PerformClick()
                    End If


                    listbox.Items.Clear()

                    'tbldocexp
                    sql = "Select * from tbldocexp where helperid='" & grdhelper.Rows(grdhelper.CurrentRow.Index).Cells(0).Value & "' and status='1' and (statusexp='Soon to expire' or statusexp='Expired')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    While dr.Read
                        Me.Cursor = Cursors.WaitCursor
                        listbox.Items.Add(dr("docname").ToString & " - " & dr("statusexp").ToString)
                    End While
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If

                Me.Cursor = Cursors.Default

                If grdhelper.Rows(grdhelper.CurrentRow.Index).Cells(4).Value = 1 Then
                    btnvdeac.Text = "Deactivate"
                    btnuphelper.Enabled = True
                Else
                    btnvdeac.Text = "Activate"
                    btnuphelper.Enabled = False
                End If

                If lblhelperbig.Text <> "" Then
                    enableall()
                End If

                checknotifgrd()
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub enabletab1only()
        TabControl1.TabPages(1).Enabled = False 'tab2
        TabControl1.TabPages(2).Enabled = False 'tab4
    End Sub

    Public Sub enabletab2only()
        TabControl1.TabPages(0).Enabled = False 'tab1
        TabControl1.TabPages(2).Enabled = False 'tab4
    End Sub

    Public Sub enabletab4only()
        TabControl1.TabPages(0).Enabled = False 'tab1
        TabControl1.TabPages(1).Enabled = False 'tab2
    End Sub

    Public Sub enableall()
        TabControl1.TabPages(0).Enabled = True 'tab1
        TabControl1.TabPages(1).Enabled = True 'tab2
        TabControl1.TabPages(2).Enabled = True 'tab4
    End Sub

    Public Sub readonlytrue()
        txthelper.ReadOnly = True
        txthelper.BackColor = Color.White
        txtlicense.ReadOnly = True
        txtlicense.BackColor = Color.White
        txtcontact.ReadOnly = True
        txtcontact.BackColor = Color.White

        datebirth.Enabled = False
        listbox.Enabled = True
        txtrems.ReadOnly = True
        txtrems.BackColor = Color.White
        cmbwhse.Enabled = False
        cmbcompany.Enabled = False
    End Sub

    Public Sub readonlyfalse()
        txthelper.ReadOnly = False
        txtlicense.ReadOnly = False
        txtcontact.ReadOnly = False

        datebirth.Enabled = True
        listbox.Enabled = True
        txtrems.ReadOnly = False
        cmbwhse.Enabled = True
        cmbcompany.Enabled = True
    End Sub

    Public Sub viewalldoc()
        Try
            Me.Cursor = Cursors.WaitCursor
            grddoc.Rows.Clear()
            Dim statexp As String = ""

            sql = "Select * from tbldocexp where status='1' and helperid='" & lblid.Text & "' order by docname"
            connect()
            Dim cmd2 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr2 As SqlDataReader = cmd2.ExecuteReader
            While dr2.Read
                grddoc.Rows.Add(dr2("docid"), dr2("docname"), Format(dr2("datelast"), "yyyy/MM/dd"), dr2("num") & " " & dr2("interval"), Format(dr2("dateexpired"), "yyyy/MM/dd"), dr2("statusexp"))
            End While
            dr2.Dispose()
            cmd2.Dispose()

            If grddoc.Rows.Count = 0 Then
                btnupdatedoc.Enabled = False
                btnremovedoc.Enabled = False
            Else
                btnupdatedoc.Enabled = True
                btnremovedoc.Enabled = True
                If btnupdatedoc.Text = "Save" Then
                    btnremovedoc.Enabled = False
                End If
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbcompsch_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcompsch.SelectedIndexChanged
        loadwhsesch()
    End Sub

    Private Sub grdhelper_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdhelper.SelectionChanged, grdhelper.SelectionChanged
        selectionchnge()
    End Sub

    Private Sub btncanceladd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncanceladd.Click
        Try
            Me.Cursor = Cursors.WaitCursor

            enableall()

            GroupBox1.Enabled = True
            btnrefresh.PerformClick()
            btncanceladd.Enabled = False
            GroupBox6.Enabled = True

            selectionchnge()

            Me.Cursor = Cursors.Default
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub btnuphelper_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnuphelper.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If btnuphelper.Text = "Update" And grdhelper.Rows(grdhelper.CurrentRow.Index).Cells(4).Value = 1 Then
                enabletab1only()
                GroupBox1.Enabled = False
                btnvadd.Enabled = False
                btnvdeac.Enabled = False
                grdhelper.Enabled = False
                btncancelupdate.Enabled = True
                btnuphelper.Text = "Save"

                readonlyfalse()

            Else
                'check for required if not null
                If Trim(txthelper.Text) <> "" And cmbwhse.SelectedItem <> "" And cmbcompany.SelectedItem <> "" Then

                    'check if already exist
                    Dim exist As Boolean = False
                    sql = "Select * from tblhelper where helper='" & Trim(txthelper.Text) & "' and helperid<>'" & lblid.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        exist = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    If exist = False Then
                        drcnf = False
                        confirmsave.GroupBox1.Text = login.neym
                        confirmsave.ShowDialog()
                        If drcnf = True Then
                            'save
                            sql = "Update tblhelper set helper='" & Trim(txthelper.Text) & "',license='" & Trim(txtlicense.Text) & "',contact='" & Trim(txtcontact.Text) & "',bday='" & Format(datebirth.Value, "yyyy/MM/dd") & "', whsename='" & cmbwhse.SelectedItem & "', company='" & cmbcompany.SelectedItem & "', remarks='" & Trim(txtrems.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where helperid='" & lblid.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'check platenum
                            sql = "Update tbltripsum set helper='" & Trim(txthelper.Text) & "' where helper='" & lblhelperbig.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")
                        End If
                    End If

                    btncancelupdate.PerformClick()
                Else
                    MsgBox("You must fill-up the required fields.", MsgBoxStyle.Exclamation, "")
                    txthelper.Focus()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
                drcnf = False
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncancelupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancelupdate.Click
        GroupBox1.Enabled = True
        btnvadd.Enabled = True
        btnvdeac.Enabled = True
        grdhelper.Enabled = True
        btnuphelper.Text = "Update"
        enableall()

        readonlytrue()
        btnrefresh.PerformClick()
        btncancelupdate.Enabled = False
    End Sub

    Private Sub cmbcompany_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcompany.SelectedIndexChanged
        loadwhse()
    End Sub

    Private Sub cmbwhse_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbwhse.Click
        loadwhse()
    End Sub

    Private Sub btnviewalldoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnviewalldoc.Click
        loaddoc()
        viewalldoc()
    End Sub

    Private Sub chkuse_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkuse.CheckedChanged
        If chkuse.Checked = True Then
            num.Enabled = True
            cmbinterval.Enabled = True
            dateexpired.Enabled = False
        Else
            num.Enabled = False
            cmbinterval.Enabled = False
            dateexpired.Enabled = True
            num.Value = 0
            cmbinterval.SelectedItem = ""
        End If
    End Sub

    Private Sub btnadddoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadddoc.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            'check first if complete
            If cmbdocname.SelectedItem <> "" Then
                If chkuse.Checked = True Then
                    If cmbinterval.SelectedItem = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Select tracking interval.", MsgBoxStyle.Exclamation, "")
                        cmbinterval.Focus()
                        Exit Sub
                    End If
                End If

                'check muna if nsa list na.. if wla pde i add.. 
                Dim chkmeronna As Boolean = False
                For Each row As DataGridViewRow In grddoc.Rows
                    If grddoc.Rows(row.Index).Cells(1).Value.ToString.Contains(cmbdocname.SelectedItem) Then
                        chkmeronna = True
                    End If
                Next

                If chkmeronna = False Then
                    'add
                    confirm.ShowDialog()
                    If drcnf = True Then
                        statusofexp()

                        sql = "Insert into tbldocexp (helperid, docname, datelast, num, interval, dateexpired, datecreated, createdby, datemodified, modifiedby, statusexp, status) values ('" & lblid.Text & "','" & cmbdocname.SelectedItem & "', '" & Format(datelastrenew.Value, "yyyy/MM/dd") & "', '" & num.Value & "', '" & cmbinterval.SelectedItem & "', '" & Format(dateexpired.Value, "yyyy/MM/dd") & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '" & lblexp.Text & "', '1')"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        Me.Cursor = Cursors.Default
                        MsgBox("Successfully added.", MsgBoxStyle.Information, "")
                        btnviewalldoc.PerformClick()
                    End If
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox(cmbdocname.SelectedItem & " is already added.", MsgBoxStyle.Exclamation, "")
                    cmbdocname.Focus()
                    Exit Sub
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select Document name.", MsgBoxStyle.Exclamation, "")
                cmbdocname.Focus()
                Exit Sub
            End If

            drcnf = False
            btncanceldoc.PerformClick()
            btnviewalldoc.PerformClick()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub statusofexp()
        Try
            Dim dnow As Date = CDate(Format(Date.Now, "yyyy/MM/dd"))
            Dim dexp As Date = CDate(Format(dateexpired.Value, "yyyy/MM/dd"))
            Dim db4 As Date = CDate(Format(dateexpired.Value.AddDays(-14), "yyyy/MM/dd"))

            If dnow >= dexp Then
                ' MsgBox("Expired")
                lblexp.Text = "Expired"
            ElseIf dnow = dexp Then
                ' MsgBox("Expired")
                lblexp.Text = "Expired"
            ElseIf dnow >= db4 And dnow < dexp Then
                ' MsgBox("Soon to expire")
                lblexp.Text = "Soon to expire"
            Else
                ' MsgBox("Updated")
                lblexp.Text = "Updated"
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnupdatedoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdatedoc.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grddoc.Rows.Count <> 0 Then
                If grddoc.SelectedCells.Count = 1 Or grddoc.SelectedRows.Count = 1 Then
                    grddoc.Enabled = False
                    GroupBox1.Enabled = False
                    btnvadd.Enabled = False
                    btnvdeac.Enabled = False
                    grdhelper.Enabled = False

                    enabletab2only()

                    If btnupdatedoc.Text = "Update" Then
                        chkuse.Checked = False
                        Dim nm As String = grddoc.Rows(grddoc.CurrentRow.Index).Cells(3).Value.ToString

                        Dim TestString As String = nm
                        Dim TestArray() As String = nm.ToString.Split(" ")
                        Dim LastNonEmpty As Integer = -1
                        For i As Integer = 0 To TestArray.Length - 1
                            If TestArray(i) <> " " Then
                                LastNonEmpty += 1
                                TestArray(LastNonEmpty) = TestArray(i)
                            End If
                        Next
                        ReDim Preserve TestArray(LastNonEmpty)
                        ' TestArray now holds {"apple", "pear", "banana"}
                        ' MsgBox(TestArray(0))
                        num.Value = TestArray(0)
                        If LastNonEmpty = 1 And TestArray(1) <> "" Then
                            cmbinterval.SelectedItem = TestArray(1)
                        End If

                        lbldocid.Text = grddoc.Rows(grddoc.CurrentRow.Index).Cells(0).Value
                        cmbdocname.SelectedItem = grddoc.Rows(grddoc.CurrentRow.Index).Cells(1).Value
                        datelastrenew.Value = grddoc.Rows(grddoc.CurrentRow.Index).Cells(2).Value
                        dateexpired.MinDate = datelastrenew.Value
                        dateexpired.Value = grddoc.Rows(grddoc.CurrentRow.Index).Cells(4).Value

                        If cmbinterval.SelectedItem <> "" Then
                            chkuse.Checked = True
                        End If

                        btnupdatedoc.Enabled = True
                        btnadddoc.Enabled = False
                        btnremovedoc.Enabled = False
                        btnviewalldoc.Enabled = False
                        btncanceldoc.Enabled = True
                        btnupdatedoc.Text = "Save"
                    Else
                        'check if complete then confirm
                        If cmbdocname.SelectedItem <> "" Then
                            'check if already exist ehere docid <> lbldocid.text
                            Me.Cursor = Cursors.Default
                            For Each row As DataGridViewRow In grddoc.Rows
                                If grddoc.Rows(row.Index).Cells(1).Value = cmbdocname.SelectedItem And grddoc.Rows(row.Index).Cells(0).Value <> lbldocid.Text Then
                                    MsgBox(cmbdocname.SelectedItem & " is already exist.", MsgBoxStyle.Exclamation, "")
                                    cmbdocname.SelectedItem = grddoc.Rows(grddoc.CurrentRow.Index).Cells(1).Value
                                    Me.Cursor = Cursors.Default
                                    Exit Sub
                                End If
                            Next

                            If chkuse.Checked = True Then
                                If cmbinterval.SelectedItem = "" Then
                                    Me.Cursor = Cursors.Default
                                    MsgBox("Select tracking interval.", MsgBoxStyle.Exclamation, "")
                                    Exit Sub
                                End If
                            End If

                            confirm.ShowDialog()
                            If drcnf = True Then
                                'save
                                statusofexp()

                                sql = "Update tbldocexp set docname='" & cmbdocname.SelectedItem & "', datelast='" & Format(datelastrenew.Value, "yyyy/MM/dd") & "', num='" & num.Value & "', interval='" & cmbinterval.SelectedItem & "', dateexpired='" & Format(dateexpired.Value, "yyyy/MM/dd") & "', datemodified=GetDate(), modifiedby='" & login.cashier & "', statusexp='" & lblexp.Text & "' where docid='" & lbldocid.Text & "'"
                                connect()
                                cmd = New SqlCommand(sql, conn)
                                cmd.ExecuteNonQuery()
                                cmd.Dispose()
                                conn.Close()

                                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                                drcnf = False
                                btncanceldoc.PerformClick()
                                btnviewalldoc.PerformClick()
                                'btnrefresh.PerformClick()
                            End If
                        Else
                            MsgBox("Select document name.", MsgBoxStyle.Exclamation, "")
                        End If
                    End If
                Else
                    MsgBox("Select only one.", MsgBoxStyle.Exclamation, "")
                End If
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncanceldoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncanceldoc.Click
        grddoc.Enabled = True
        lbldocid.Text = ""
        cmbdocname.SelectedItem = ""
        datelastrenew.Value = datelastrenew.MaxDate
        dateexpired.Value = dateexpired.MinDate
        num.Value = 0
        cmbinterval.SelectedItem = ""

        chkuse.Checked = True
        btnupdatedoc.Text = "Update"
        btnupdatedoc.Enabled = True
        btnadddoc.Enabled = True
        btnremovedoc.Enabled = True
        btnviewalldoc.Enabled = True
        btncanceldoc.Enabled = False
        btnviewalldoc.PerformClick()

        GroupBox1.Enabled = True
        btnvadd.Enabled = True
        btnvdeac.Enabled = True
        grdhelper.Enabled = True
        enableall()
    End Sub

    Private Sub num_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles num.ValueChanged
        checkdateexp()
    End Sub

    Private Sub cmbinterval_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbinterval.SelectedIndexChanged
        checkdateexp()
    End Sub

    Public Sub checkdateexp()
        If num.Value <> 0 Then
            Dim last As Date = CDate(Format(datelastrenew.Value, "yyyy/MM/dd"))
            If cmbinterval.SelectedIndex = 1 Then
                ' dateexpired.Value = datelastrenew.Value.AddYears(+num.Value)
                dateexpired.Value = last.AddYears(+num.Value)
            ElseIf cmbinterval.SelectedIndex = 2 Then
                dateexpired.Value = last.AddMonths(+num.Value)
            ElseIf cmbinterval.SelectedIndex = 3 Then
                dateexpired.Value = last.AddDays(+num.Value)
            End If
        Else
            If btnupdatedoc.Text = "Update" Then
                cmbinterval.SelectedIndex = 0
                dateexpired.Value = datelastrenew.Value
            End If
        End If
    End Sub

    Private Sub btnremovedoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnremovedoc.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" And login.neym <> "Manager" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grddoc.SelectedCells.Count = 1 Or grddoc.SelectedRows.Count = 1 Then
                Dim a As String = MsgBox("Are you sure you want to remove?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                If a = vbYes Then
                    confirm.ShowDialog()
                    If drcnf = True Then
                        ' sql = "Update tbldocexp set status='0' where docid='" & grddoc.Rows(grddoc.CurrentRow.Index).Cells(0).Value & "'"
                        sql = "Delete from tbldocexp where docid='" & grddoc.Rows(grddoc.CurrentRow.Index).Cells(0).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully remove.", MsgBoxStyle.Information, "")
                    End If
                    drcnf = False
                    btnviewalldoc.PerformClick()
                End If
            Else
                MsgBox("Select only one.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbdocname_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbdocname.SelectedIndexChanged
        If cmbdocname.SelectedItem <> "" Then
            btncanceldoc.Enabled = True
            If btnupdatedoc.Text = "Update" Then
                btnupdatedoc.Enabled = False
                btnremovedoc.Enabled = False
                btnviewalldoc.Enabled = False
            End If
        End If
    End Sub

    Private Sub datelastrenew_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datelastrenew.ValueChanged
        dateexpired.MinDate = datelastrenew.Value
        If chkuse.Checked = True Then
            checkdateexp()
        End If
    End Sub

    Private Sub btnimgrefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrefresh.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meron = False
            imgpanel.Visible = False
            imgpanel.Controls.Clear()
            imgpanel.Visible = True

            Dim ctr As Integer = 0
            sql = "Select * from tblimage where helperid='" & lblid.Text & "'"
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                meron = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr1("img"), Byte())
                Dim ms As New MemoryStream(data)

                pic = New PictureBox
                pic.Image = Image.FromStream(ms)
                pic.SizeMode = PictureBoxSizeMode.Zoom
                pic.SetBounds(wid, y, 104, 100)
                'pic.BackColor = Color.AliceBlue
                pic.Tag = dr1("imgid")
                pic.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr1("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler pic.Click, AddressOf convertPic
                imgpanel.Controls.Add(pic)
                imgpanel.Controls.Add(lbl)
            End While
            dr1.Dispose()
            cmd1.Dispose()

            imgbox.Image = Nothing
            txtimg.Text = ""
            lblimgid.Text = ""

            Me.Cursor = Cursors.Default

            If meron = False Then
                btnimgrename.Enabled = False
                btnimgremove.Enabled = False
                btnimgcancel.Enabled = False
                btnimgset.Enabled = False
                btnimgupdate.Enabled = False
                btnimgdl.Enabled = False
                btnimgfull.Enabled = False
            Else
                imgcancelfalse()
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgfull_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgfull.Click
        If lblimgid.Text <> "" Then
            viewimage.lblimgid.Text = lblimgid.Text
            viewimage.lblimgname.Text = txtimg.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub btnimgdl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgdl.Click
        Try
            If lblimgid.Text <> "" Then
                saveimage.ShowDialog()
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgupdate.Click
        Try
            'browse muna then saka update
            If btnimgupdate.Text = "Update Photo" Then
                If lblimgid.Text <> "" Then
                    If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
                        imgbox.Image = Image.FromFile(ofd.FileName.ToUpper)
                        ' txtimg.Text = ofd.SafeFileName
                        ' txtimg.ReadOnly = False
                        txtimg.Focus()

                        imgpanel.Enabled = False
                        GroupBox1.Enabled = False
                        btnvadd.Enabled = False
                        btnvdeac.Enabled = False
                        grdhelper.Enabled = False
                        enabletab4only()
                        imgcanceltrue()
                        btnimgupdate.Enabled = True
                        btnimgupdate.Text = "Save Photo"
                    Else
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If

            Else
                If Trim(txtimg.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    txtimg.Focus()
                    Exit Sub
                End If

                drcnf = False
                confirm.ShowDialog()
                If drcnf = True Then
                    Me.Cursor = Cursors.WaitCursor

                    Dim ms As New MemoryStream()
                    connect()
                    cmd = New SqlCommand("Update tblimage set img=@img where imgid=@imgid", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("imgid", Trim(lblimgid.Text)))
                    imgbox.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    cmd.ExecuteNonQuery()
                    drcnf = False
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If

                btnimgupdate.Text = "Update Photo"
                imgcancelfalse()
                imgpanel.Enabled = True
                GroupBox1.Enabled = True
                btnvadd.Enabled = True
                btnvdeac.Enabled = True
                grdhelper.Enabled = True
                enableall()
                btnimgrefresh.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgset.Click
        Try
            If lblimgid.Text <> "" Then
                Dim a As String = MsgBox("Are you sure you want to set the photo as primary photo?.", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
                If a = vbYes Then
                    drcnf = False
                    confirm.ShowDialog()
                    If drcnf = True Then
                        'update tblhelper
                        sql = "Update tblhelper set imgid='" & lblimgid.Text & "' where helperid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")
                    End If
                End If
            Else
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgremove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgremove.Click
        Try
            If Trim(txtimg.Text) <> "" And imgbox.Image IsNot Nothing Then
                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                If a = vbYes Then
                    drcnf = False
                    confirm.ShowDialog()
                    If drcnf = True Then
                        'delete image where imgid=lblimgid.text
                        sql = "Delete from tblimage where imgid='" & lblimgid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully remove.", MsgBoxStyle.Information, "")

                        drcnf = False
                        imgcancelfalse()
                        imgpanel.Enabled = True
                        GroupBox1.Enabled = True
                        btnvadd.Enabled = True
                        btnvdeac.Enabled = True
                        grdhelper.Enabled = True
                        enableall()
                        btnimgrefresh.PerformClick()
                    End If
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                txtimg.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgcancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel.Click
        imgpanel.Enabled = True
        GroupBox1.Enabled = True
        btnvadd.Enabled = True
        btnvdeac.Enabled = True
        grdhelper.Enabled = True
        enableall()
        imgbox.Image = Nothing
        txtimg.Text = ""
        lblimgid.Text = ""
        imgcancelfalse()

        If meron = False Then
            btnimgrename.Enabled = False
            btnimgremove.Enabled = False
            btnimgcancel.Enabled = False
            btnimgset.Enabled = False
            btnimgupdate.Enabled = False
            btnimgdl.Enabled = False
            btnimgfull.Enabled = False
        Else
            imgcancelfalse()
        End If
    End Sub

    Private Sub btnimgadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgadd.Click
        Try
            If btnimgadd.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox.Image = Image.FromFile(ofd.FileName.ToUpper)
                    txtimg.Text = ofd.SafeFileName
                    txtimg.ReadOnly = False
                    txtimg.Focus()

                    imgpanel.Enabled = False
                    GroupBox1.Enabled = False
                    btnvadd.Enabled = False
                    btnvdeac.Enabled = False
                    grdhelper.Enabled = False
                    'enabletab4only()
                    enableall()
                    imgcanceltrue()
                    btnimgadd.Enabled = True
                    btnimgadd.Text = "Add"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(txtimg.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    txtimg.Focus()
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to add photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
                If a = vbYes Then
                    Me.Cursor = Cursors.WaitCursor
                    'insert photo in tblimg
                    Dim ms As New MemoryStream()
                    'search image name if existing
                    connect()
                    cmd = New SqlCommand("Select * from tblimage where helperid='" & lblid.Text & "' and name='" & Trim(txtimg.Text) & "'", conn)
                    dr = cmd.ExecuteReader()
                    If dr.Read = True Then
                        Me.Cursor = Cursors.Default
                        MessageBox.Show("Image " & Trim(txtimg.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        'save record in database
                        connect()
                        cmd = New SqlCommand("Insert into tblimage values(@genid,@driverid,@helperid,@name,@img)", conn)
                        cmd.Parameters.Add(New SqlClient.SqlParameter("genid", ""))
                        cmd.Parameters.Add(New SqlClient.SqlParameter("driverid", ""))
                        cmd.Parameters.Add(New SqlClient.SqlParameter("helperid", lblid.Text))
                        cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(txtimg.Text)))
                        imgbox.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                        Dim data As Byte() = ms.GetBuffer()
                        Dim img As New SqlParameter("@img", SqlDbType.Image)
                        img.Value = data
                        cmd.Parameters.Add(img)
                        cmd.ExecuteNonQuery()
                        MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        imgbox.Image = Nothing
                        imgbox.BackColor = Color.Empty
                        imgbox.Invalidate()
                        Me.Cursor = Cursors.Default
                    End If
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If

                btnimgadd.Text = "Add Photo"
                imgcancelfalse()
                imgpanel.Enabled = True
                GroupBox1.Enabled = True
                btnvadd.Enabled = True
                btnvdeac.Enabled = True
                grdhelper.Enabled = True
                enableall()
                btnimgrefresh.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimgrename_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgrename.Click
        Try
            If btnimgrename.Text = "Rename" Then
                If Trim(txtimg.Text) <> "" And imgbox.Image IsNot Nothing Then
                    txtimg.ReadOnly = False
                    txtimg.Focus()
                ElseIf Trim(txtimg.Text) = "" And imgbox.Image IsNot Nothing Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    txtimg.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    txtimg.Focus()
                    Exit Sub
                End If

                imgpanel.Enabled = False
                GroupBox1.Enabled = False
                btnvadd.Enabled = False
                btnvdeac.Enabled = False
                grdhelper.Enabled = False
                enabletab4only()
                imgcanceltrue()
                btnimgrename.Enabled = True
                btnimgrename.Text = "Save"
            Else
                drcnf = False
                confirm.ShowDialog()
                If drcnf = True Then
                    'irename.. update yung name lng where imgid = lblimgid.text
                    sql = "Update tblimage set name='" & Trim(txtimg.Text) & "' where imgid='" & lblimgid.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                    btnimgrename.Text = "Rename"
                    imgcancelfalse()
                    imgpanel.Enabled = True
                    GroupBox1.Enabled = True
                    btnvadd.Enabled = True
                    btnvdeac.Enabled = True
                    grdhelper.Enabled = True
                    enableall()
                    btnimgrefresh.PerformClick()
                    Me.Cursor = Cursors.Default
                End If
                drcnf = False
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtimg_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtimg.Leave
        'tignan kung valid ung filename ng picture
        If txtimg.Text.ToString.Contains("'") Then
            txtimg.Text = Trim(txtimg.Text.ToString.Replace("'", ""))
        End If
    End Sub

    Public Sub imgcanceltrue()
        btnimgadd.Enabled = False
        btnimgrename.Enabled = False
        btnimgremove.Enabled = False
        btnimgcancel.Enabled = True
        btnimgset.Enabled = False
        btnimgupdate.Enabled = False
        btnimgdl.Enabled = False
        btnimgfull.Enabled = False
        btnimgrefresh.Enabled = False
    End Sub

    Public Sub imgcancelfalse()
        txtimg.ReadOnly = True
        txtimg.Text = ""
        btnimgadd.Text = "Add Photo"
        btnimgrename.Text = "Rename"
        btnimgupdate.Text = "Update Photo"
        btnimgadd.Enabled = True
        btnimgrename.Enabled = True
        btnimgremove.Enabled = True
        btnimgcancel.Enabled = False
        btnimgset.Enabled = True
        btnimgupdate.Enabled = True
        btnimgdl.Enabled = True
        btnimgfull.Enabled = True
        btnimgrefresh.Enabled = True
    End Sub

    Sub convertPic(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            pic = CType(sender, PictureBox)
            imgbox.Image = pic.Image
            lblimgid.Text = pic.Tag

            sql = "Select * from tblimage where imgid='" & lblimgid.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                txtimg.Text = dr("name")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnvadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnvadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If btnvadd.Text = "Add Helper" Then
                TabControl1.Enabled = True
                'ireset ung mga laman ng tab1
                readonlyfalse()
                lblhelperbig.Text = ""
                lblid.Text = ""
                txthelper.Text = ""
                cmbwhse.SelectedItem = ""
                cmbcompany.SelectedItem = ""
                txthelper.Text = ""
                listbox.Items.Clear()
                imgphoto.Image = Nothing
                txtrems.Text = ""
                lblprimary.Text = ""
                txtlicense.Text = ""
                txtcontact.Text = ""
                datebirth.Value = datebirth.MaxDate

                enabletab1only()

                btnvdeac.Enabled = False
                btnuphelper.Enabled = False
                grdhelper.Enabled = False
                btncanceladd.Enabled = True
                GroupBox1.Enabled = False
                btnvadd.Text = "Add"

                If cmbwhsesch.SelectedItem <> "" And cmbwhsesch.SelectedItem <> "All" Then
                    cmbwhse.SelectedItem = cmbwhsesch.SelectedItem
                End If

                helperid()
            Else
                'insert in database
                If Trim(txthelper.Text) <> "" And cmbwhse.SelectedItem <> "" And cmbcompany.SelectedItem <> "" Then
                    'check if already exist
                    Dim exist As Boolean = False

                    sql = "Select * from tblhelper where helper='" & Trim(txthelper.Text) & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        exist = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    If exist = False Then
                        drcnf = False
                        confirmsave.GroupBox1.Text = login.neym
                        confirmsave.ShowDialog()
                        If drcnf = True Then
                            sql = "Insert into tblhelper (helper, license, contact, bday, company, whsename, remarks, dreason, datecreated, createdby, datemodified, modifiedby, status) values ('" & Trim(txthelper.Text) & "', '" & Trim(txtlicense.Text) & "', '" & Trim(txtcontact.Text) & "', '" & Format(datebirth.Value, "yyyy/MM/dd") & "', '" & cmbcompany.SelectedItem & "', '" & cmbwhse.SelectedItem & "', '" & Trim(txtrems.Text) & "', '', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            MsgBox("Successfully Added.", MsgBoxStyle.Information, "")
                        End If
                    End If
                Else
                    MsgBox("You must fill-up the required fields.", MsgBoxStyle.Exclamation, "")
                    txthelper.Focus()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If

                drcnf = False
                btnvdeac.Enabled = True
                btnuphelper.Enabled = True
                btnupdatedoc.Enabled = True
                grdhelper.Enabled = True
                btncanceladd.Enabled = True
                GroupBox1.Enabled = True
                btncanceladd.PerformClick()
                btnvadd.Text = "Add Helper"

                enableall()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnvdeac_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnvdeac.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdhelper.SelectedCells.Count = 1 Or grdhelper.SelectedRows.Count = 1 Then
                If btnvdeac.Text = "Deactivate" Then
                    drcnf = False
                    Dim a As String = MsgBox("Are you sure you want to deactivate helper?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                    If a = vbYes Then
                        grdhelper.Enabled = False
                        'lalabas yung pag lalagyan ng reason why
                        reason.ShowDialog()
                        If dreason <> "" Then
                            drcnf = False
                            confirmsave.GroupBox1.Text = login.neym
                            confirmsave.ShowDialog()
                            If drcnf = True Then
                                sql = "Update tblhelper set modifiedby='" & login.cashier & "',datemodified=GetDate(), status='0', dreason='" & dreason & "' where helperid='" & grdhelper.Rows(grdhelper.CurrentRow.Index).Cells(0).Value & "'"
                                connect()
                                cmd = New SqlCommand(sql, conn)
                                cmd.ExecuteNonQuery()
                                cmd.Dispose()
                                conn.Close()

                                Me.Cursor = Cursors.Default
                                MsgBox("Successfully deactivated.", MsgBoxStyle.Information, "")
                                btnrefresh.PerformClick()
                            Else
                                Me.Cursor = Cursors.Default
                                MsgBox("Deactivation Cancelled.", MsgBoxStyle.Information, "")
                            End If
                        Else
                            Me.Cursor = Cursors.Default
                            MsgBox("Deactivation Cancelled.", MsgBoxStyle.Information, "")
                        End If
                    End If
                    dreason = ""
                    drcnf = False
                    grdhelper.Enabled = True

                Else
                    'activate helper
                    drcnf = False
                    Dim a As String = MsgBox("Are you sure you want to activate helper?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
                    If a = vbYes Then
                        grdhelper.Enabled = False
                        drcnf = False
                        confirmsave.GroupBox1.Text = login.neym
                        confirmsave.ShowDialog()
                        If drcnf = True Then
                            sql = "Update tblhelper set modifiedby='" & login.cashier & "',datemodified=GetDate(), status='1', dreason='' where helperid='" & grdhelper.Rows(grdhelper.CurrentRow.Index).Cells(0).Value & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            Me.Cursor = Cursors.Default
                            MsgBox("Successfully activated.", MsgBoxStyle.Information, "")
                            btnrefresh.PerformClick()
                        Else
                            Me.Cursor = Cursors.Default
                            MsgBox("Deactivation Cancelled.", MsgBoxStyle.Information, "")
                        End If
                    End If
                    dreason = ""
                    drcnf = False
                    grdhelper.Enabled = True
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select only one.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub helperid()
        Try
            Dim gnum As String = "1", temp As String = ""
            sql = "Select Top 1 * from tblhelper order by helperid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                gnum = Val(dr("helperid")) + 1
            End If
            cmd.Dispose()
            dr.Dispose()
            conn.Close()

            lblid.Text = gnum

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnimport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimport.Click
        If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
            MsgBox("Access denied!", MsgBoxStyle.Critical, "")
            Exit Sub
        End If
        importhelper.ShowDialog()
        btnok.PerformClick()
    End Sub

    Private Sub newhelper_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.WindowState = FormWindowState.Maximized
    End Sub
End Class