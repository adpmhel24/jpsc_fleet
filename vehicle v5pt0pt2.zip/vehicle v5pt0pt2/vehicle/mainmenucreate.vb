﻿Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Text
Imports System.Globalization
Imports System.ComponentModel

Public Class mainmenucreate
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Dim dt As Integer = 0
    Dim lasttext As String
    Dim iftxt As Integer = 0
    Dim lastdgv As String
    Public activeTextBox As TextBox, imgname As String
    Public clickimg As PictureBox, voidd As Boolean = False
    Dim culture As CultureInfo = Nothing
    Dim tempamt As Double
    Public counters As Boolean = False

    Dim based As Double = 0, yesbased As Boolean = False, ibabawas As Double = 0, keyEnter As Boolean = False, keyEnter2 As Boolean = False
    Public dtServerDateTime As DateTime
    Dim path As String, ColAdd As Boolean = False, refnum As String = ""
    Dim firstref As String = "", secondref As String = ""
    Private backgroundWorkerdestin As BackgroundWorker, threadEnableddestin As Boolean, cancelpending As Boolean = False
    Dim gridsql As String = ""
    Public edittrans As Boolean, frm As String

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub mainmenucopy_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If Asc(e.KeyCode) = Windows.Forms.Keys.Alt Then
            e.Handled = True
        End If
    End Sub

    Private Sub mainmenucopy_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            ColAdd = True

            path = (Microsoft.VisualBasic.Left(Application.StartupPath, Len(Application.StartupPath)))

            cmbcus.AutoCompleteMode = AutoCompleteMode.SuggestAppend
            cmbcus.DropDownStyle = ComboBoxStyle.DropDown
            cmbcus.AutoCompleteSource = AutoCompleteSource.ListItems

            'cmbtype.AutoCompleteMode = AutoCompleteMode.SuggestAppend
            'cmbtype.DropDownStyle = ComboBoxStyle.DropDown
            'cmbtype.AutoCompleteSource = AutoCompleteSource.ListItems

            cmbpick.AutoCompleteMode = AutoCompleteMode.SuggestAppend
            cmbpick.DropDownStyle = ComboBoxStyle.DropDown
            cmbpick.AutoCompleteSource = AutoCompleteSource.ListItems

            grdorders.Rows.Add()

            Me.TableLayoutPanel1.SetRowSpan(Panel2, 2)
            Me.TableLayoutPanel1.SetRowSpan(Panel14, 2)

            datebook.CustomFormat = "yyyy/MM/dd"
            dateexp.CustomFormat = "yyyy/MM/dd"

            whse()
            ttype()
            view()
            connect()
            cmd = New SqlCommand("Select GetDate()", conn)
            dtServerDateTime = cmd.ExecuteScalar
            conn.Close()

            datebook.MaxDate = dtServerDateTime.Date
            customer()
            defaultload()
            'poi()

            cmbpupadd.DropDownWidth = 400
            keyEnter2 = False
            btnok.Focus()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub viewcat()
        Try
            Exit Sub
            'update status of items
            Dim btncat(200) As Button
            Dim wid As Int32
            Dim ctr As Integer = 0, y As Integer, mody As Integer, row As Integer

            sql = "Select * from tblorcat where status='1' order by category"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                Me.Cursor = Cursors.WaitCursor
                ctr += 1
                btncat(ctr) = New Button()
                btncat(ctr).Width = 95
                btncat(ctr).Height = 55
                btncat(ctr).Text = dr(1).ToString
                btncat(ctr).Tag = dr(0)
                btncat(ctr).Font = New Drawing.Font("Arial", 9.5)
                btncat(ctr).Font = New Font(btncat(ctr).Font, FontStyle.Bold)

                btncat(ctr).BackColor = Color.FromArgb(255, 224, 192)

                mody = ctr Mod 7
                row = ctr / 7

                If mody = 1 Then
                    y = (row * 55) + (1 * row)
                    wid = 0
                End If

                btncat(ctr).SetBounds(wid, y, 95, 55)
                wid += 98

                AddHandler btncat(ctr).Click, AddressOf imgClicked
            End While

            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub clearpanel()
        Try
            Panel14.Visible = False
            Panel14.Controls.Clear()
            Panel14.Visible = True
            enablelahat()
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub enablelahat()
        Try
            'For Each btn As Button In Panel5.Controls
            'If btn.Text <> clickbtn.Text Then
            'btn.Enabled = True
            'btn.BackColor = Color.FromArgb(255, 224, 192)
            'Else
            'btn.Enabled = False
            'btn.BackColor = Color.FromArgb(255, 192, 128)
            'End If
            'Next
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ttype()
        Try
            cmbtype.Items.Clear()
            cmbtype.Items.Add("")

            sql = "Select transtype from tbltranstype where status='1'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbtype.Items.Add(dr("transtype"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception

        End Try
    End Sub

    Public Sub savetransaction()
        Try
            Me.Cursor = Cursors.WaitCursor
            'first check entries dun sa btnok
            ExecuteOk(strconn)

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteOk(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction

            ' Start a local transaction
            transaction = connection.BeginTransaction("OkTransaction")

            ' Must assign both transaction object and connection 
            ' to Command object for a pending local transaction.
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                'load transnum'''''load again transnum
                Dim trnum As String = "1", temp As String = ""
                'check kung pang ilang LOGSHEET NA SA YEAR NA 2018 na
                command.CommandText = "Select Count(transid) from tblortrans where transyear=Year(GetDate()) and whsename='" & login.whse & "'"
                trnum = command.ExecuteScalar + 1

                Dim prefix As String = ""
                sql = "Select whsecode from tblwhse where whsename='" & login.whse & "' and status='1'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    prefix = dr("whsecode")
                End If
                dr.Dispose()

                If trnum < 1000000 Then
                    For vv As Integer = 1 To 6 - trnum.Length
                        temp += "0"
                    Next
                    'lbltrnum.Text = Date.Now.Year & "-" & Format(Date.Now, "MM") & Format(Date.Now, "dd") & temp & trnum
                End If

                lbltrnum.Text = "O." & prefix & "-" & Format(Date.Now, "yy") & "-" & temp & trnum
                ''''''''end of transnum

                'transaction type
                Dim transtype As String = ""
                If cmbtype.SelectedIndex <> 0 Then
                    If cmbtype.SelectedItem.ToString.Contains("PICKUP") And Trim(cmbpick.Text) = "" Then
                        'MsgBox("Pick up Warehouse.", MsgBoxStyle.Exclamation, "")
                        'Exit Sub
                    Else
                        If Trim(cmbpick.Text) = "" Then
                            transtype = cmbtype.SelectedItem
                        Else
                            transtype = cmbtype.SelectedItem & " FRM " & Trim(cmbpick.Text)
                        End If
                    End If
                End If

                If txtso.Enabled = True And txtpo.Enabled = True Then
                    refnum = lblso.Text & Trim(txtso.Text) & " / " & lblpo.Text & Trim(txtpo.Text)
                ElseIf txtso.Enabled = True And txtpo.Enabled = False Then
                    refnum = lblso.Text & Trim(txtso.Text)
                ElseIf txtso.Enabled = False And txtpo.Enabled = True Then
                    refnum = lblpo.Text & Trim(txtpo.Text)
                ElseIf txtso.Enabled = False And txtpo.Enabled = False Then
                    refnum = "0000"
                End If

                Dim sonum As String = "", ponum As String = "", swsnum As String = "", itrnum As String = ""
                If lblso.Text = "SO#" And txtso.Enabled = True Then
                    sonum = Trim(txtso.Text)
                End If

                If lblpo.Text = "PO#" And txtpo.Enabled = True Then
                    ponum = Trim(txtpo.Text)
                ElseIf lblpo.Text = "ITR#" And txtpo.Enabled = True Then
                    itrnum = Trim(txtpo.Text)
                ElseIf lblpo.Text = "SWS#" And txtpo.Enabled = True Then
                    swsnum = Trim(txtpo.Text)
                End If

                Dim drn As String = "", ar As String = "", rdr As String = "", dn As String = "", it As String = "", grpo As String = ""
                If cmbtype.SelectedItem.ToString.Contains("SALES TRANSACTION PICKUP") = True Then
                    itrnum = "N/A"
                    it = "N/A"
                    grpo = "N/A"
                    swsnum = "N/A"
                    If cmbpick.Text.ToString.Contains("AGI ") = False Then
                        dn = "N/A"
                    End If
                ElseIf cmbtype.SelectedItem.ToString.Contains("SALES TRANSACTION") = True Then
                    ponum = "N/A"
                    dn = "N/A"
                    itrnum = "N/A"
                    it = "N/A"
                    grpo = "N/A"
                    swsnum = "N/A"
                ElseIf cmbtype.SelectedItem.ToString.Contains("STOCK TRANSFER PICKUP") = True Then
                    sonum = ""
                    drn = "N/A"
                    ar = "N/A"
                    If cmbpick.Text.ToString.Contains("AGI ") = False Then
                        dn = "N/A"
                    End If
                ElseIf cmbtype.SelectedItem.ToString.Contains("STOCK TRANSFER WHSE TO WHSE") = True Then
                    sonum = ""
                    drn = "N/A"
                    ar = "N/A"
                    dn = "N/A"
                    ponum = "N/A"
                    grpo = "N/A"
                    swsnum = "N/A"
                ElseIf cmbtype.SelectedItem.ToString.Contains("JPSC TRUCKING FOR OTHERS PICKUP") = True Then
                    itrnum = "N/A"
                    it = "N/A"
                    grpo = "N/A"
                    swsnum = "N/A"
                ElseIf cmbtype.SelectedItem.ToString.Contains("JPSC TAXI") = True Then
                    sonum = ""
                    ar = "N/A"
                    drn = "N/A"
                    rdr = "N/A"
                    ponum = "N/A"
                    dn = "N/A"
                    swsnum = "N/A"
                    itrnum = "N/A"
                    it = "N/A"
                    grpo = "N/A"
                End If

                Dim chk As String = "", chkint As Integer = 0
                Dim pupfrm As String = ""
                If Trim(cmbpick.Text) <> "" And cmbpick.Text.Length >= 4 Then
                    pupfrm = cmbpick.Text.ToString.Substring(0, 4)
                End If
                If chkagi.Checked = True And cmbtype.SelectedItem.ToString.Contains("JPSC TRUCKING FOR OTHERS PICKUP") = True And pupfrm = "AGI " Then
                    chk = chkagi.Text
                    chkint = 1
                ElseIf chkso.Checked = True Then
                    chk = chkso.Text
                    chkint = 2
                ElseIf chkoro.Checked = True And cmbtype.SelectedItem.ToString.Contains("JPSC TRUCKING FOR OTHERS PICKUP") = True And pupfrm = "ORO " Then
                    chk = chkoro.Text
                    chkint = 3
                ElseIf chkmonde.Checked = True And cmbtype.SelectedItem.ToString.Contains("JPSC TRUCKING FOR OTHERS PICKUP") = True Then
                    chk = chkmonde.Text
                    chkint = 4
                End If

                Dim prio As Integer = 0, lc As Integer = 0, ship As Integer = 0
                If chkprio.Checked = True Then
                    prio = 1
                End If
                If chklc.Checked = True Then
                    lc = 1
                End If
                If chkstuff.Checked = True Then
                    ship = 1
                End If

                Dim poiid As String = "Null", pup_poiid As String = "Null"
                If lblpoiid.Text <> "" Then
                    poiid = lblpoiid.Text
                End If
                If lblpuppoiid.Text <> "" Then
                    pup_poiid = lblpuppoiid.Text
                End If

                'save customer
                Dim exists As Boolean = False
                sql = "Select customer from tblcustomer where customer='" & Trim(cmbcus.Text).ToString.Replace("'", "''") & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    exists = True
                End If
                dr.Dispose()

                If exists = False Then
                    sql = "Insert into tblcustomer (customer, description, address, email, remarks, area, record, datecreated, createdby, datemodified, modifiedby, status)"
                    sql = sql & " values ('" & Trim(cmbcus.Text).ToString.Replace("'", "''") & "','" & Trim(cmbcus.Tag).ToString.Replace("'", "''") & "', '-', '', '', '', '', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                    sql = "Insert into tblcuspoi (cusid,poiid,datecreated,createdby,datemodified,modifiedby,status)"
                    sql = sql & " values ((Select cusid from tblcustomer where customer='" & Trim(cmbcus.Text).ToString.Replace("'", "''") & "'),"
                    sql = sql & " (Select p.poiid from tblpoi p where p.poiname='---TEMPORARY POI---'"
                    sql = sql & " and not exists (Select cp.poiid from tblcuspoi cp where cp.poiid=p.poiid and"
                    sql = sql & " cp.cusid=(Select cusid from tblcustomer where customer='" & Trim(cmbcus.Text).ToString.Replace("'", "''") & "'))),"
                    sql = sql & " GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                End If

                'save tblortrans
                Dim s As String = Trim(txtnotes.Text.TrimEnd(ControlChars.Cr, ControlChars.Lf))
                sql = "Insert into tblortrans (transyear,transnum,refnum,datebooked,customer,notes,cancel,whsename,"
                sql = sql & " sonum,ponum,swsnum,arnum,rdrnum,drnum,itrnum,dnnum,itnum,grponum,"
                sql = sql & " chktype,datecreated,createdby,datemodified,modifiedby,status,dateexpected,"
                sql = sql & " priority,sapwhse,sap,poiid,pup_poiid,edited,stuffing,trid,pupid)"
                sql = sql & " values (Year(GetDate()),'" & lbltrnum.Text & "', '" & refnum & "', "
                sql = sql & " '" & Format(datebook.Value, "yyyy/MM/dd") & "', '" & Trim(cmbcus.Text).ToString.Replace("'", "''") & "',"
                sql = sql & " '" & s.Replace("'", "''") & "', '0', '" & login.whse & "',"
                sql = sql & " '" & sonum & "','" & ponum & "','" & swsnum & "','" & ar & "','" & rdr & "',"
                sql = sql & " '" & drn & "','" & itrnum & "','" & dn & "','" & it & "','" & grpo & "',"
                sql = sql & " '" & chkint & "',GetDate(),'" & login.cashier & "',GetDate(),"
                sql = sql & " '" & login.cashier & "','1','" & Format(dateexp.Value, "yyyy/MM/dd") & "',"
                sql = sql & " '" & prio & "','" & Trim(txtwhse.Text) & "','" & lc & "'," & poiid & "," & pup_poiid & ",'0','" & ship & "',"
                sql = sql & " (Select trid from tbltranstype where transtype='" & cmbtype.SelectedItem & "'),"
                sql = sql & " (Select whseid from tblwhse where whsename='" & Trim(cmbpick.Text) & "'))"
                               command.CommandText = sql
                command.ExecuteNonQuery()

                'save tblorder
                'tblorder
                Dim dsc(grdorders.Rows.Count - 1) As String
                Dim marks As String = ""
                Dim totalfree As Double = 0

                For Each row As DataGridViewRow In grdorders.Rows
                    Me.Cursor = Cursors.WaitCursor
                    Dim iname As String = grdorders.Rows(row.Index).Cells(0).Value
                    Dim iqty As Double = Val(grdorders.Rows(row.Index).Cells(1).Value.ToString)

                    sql = "Insert into tblorder (transnum, itemcode, qty, status)"
                    sql = sql & " values('" & lbltrnum.Text & "','" & iname & "','" & iqty & "','1')"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                Next

                'save tblorimage
                If imgbox2.Image IsNot Nothing Then
                    Dim ms As New MemoryStream()
                    Dim filename As String = lblpo.Text & Trim(txtpo.Text)

                    command.Parameters.Clear()
                    command.CommandText = "Insert into tblorimage values(@transnum,@name,@img)"
                    command.Parameters.Add(New SqlClient.SqlParameter("transnum", lbltrnum.Text))
                    command.Parameters.Add(New SqlClient.SqlParameter("name", filename))
                    imgbox2.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    command.Parameters.Add(img)
                    command.ExecuteNonQuery()
                End If

                If imgbox22.Image IsNot Nothing Then
                    Dim ms As New MemoryStream()
                    Dim filename As String = lblpo.Text & Trim(txtpo.Text) & "(2)"

                    command.Parameters.Clear()
                    command.CommandText = "Insert into tblorimage values(@transnum,@name,@img)"
                    command.Parameters.Add(New SqlClient.SqlParameter("transnum", lbltrnum.Text))
                    command.Parameters.Add(New SqlClient.SqlParameter("name", filename))
                    imgbox22.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    command.Parameters.Add(img)
                    command.ExecuteNonQuery()
                End If

                If imgbox222.Image IsNot Nothing Then
                    Dim ms As New MemoryStream()
                    Dim filename As String = lblpo.Text & Trim(txtpo.Text) & "(3)"

                    command.Parameters.Clear()
                    command.CommandText = "Insert into tblorimage values(@transnum,@name,@img)"
                    command.Parameters.Add(New SqlClient.SqlParameter("transnum", lbltrnum.Text))
                    command.Parameters.Add(New SqlClient.SqlParameter("name", filename))
                    imgbox222.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    command.Parameters.Add(img)
                    command.ExecuteNonQuery()
                End If

                If imgbox1.Image IsNot Nothing Then
                    Dim ms As New MemoryStream()
                    Dim filename As String = lblso.Text & Trim(txtso.Text)

                    command.Parameters.Clear()
                    command.CommandText = "Insert into tblorimage values(@transnum,@name,@img)"
                    command.Parameters.Add(New SqlClient.SqlParameter("transnum", lbltrnum.Text))
                    command.Parameters.Add(New SqlClient.SqlParameter("name", filename))
                    imgbox1.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    command.Parameters.Add(img)
                    command.ExecuteNonQuery()
                End If

                If imgbox11.Image IsNot Nothing Then
                    Dim ms As New MemoryStream()
                    Dim filename As String = lblso.Text & Trim(txtso.Text) & "(2)"

                    command.Parameters.Clear()
                    command.CommandText = "Insert into tblorimage values(@transnum,@name,@img)"
                    command.Parameters.Add(New SqlClient.SqlParameter("transnum", lbltrnum.Text))
                    command.Parameters.Add(New SqlClient.SqlParameter("name", filename))
                    imgbox11.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    command.Parameters.Add(img)
                    command.ExecuteNonQuery()
                End If

                If imgbox111.Image IsNot Nothing Then
                    Dim ms As New MemoryStream()
                    Dim filename As String = lblso.Text & Trim(txtso.Text) & "(3)"

                    command.Parameters.Clear()
                    command.CommandText = "Insert into tblorimage values(@transnum,@name,@img)"
                    command.Parameters.Add(New SqlClient.SqlParameter("transnum", lbltrnum.Text))
                    command.Parameters.Add(New SqlClient.SqlParameter("name", filename))
                    imgbox111.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    command.Parameters.Add(img)
                    command.ExecuteNonQuery()
                End If


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default                '/MsgBox("Both records are written to database.")
                imgbox1.BackColor = Color.Empty
                imgbox1.Invalidate()
                imgbox11.BackColor = Color.Empty
                imgbox11.Invalidate()
                imgbox111.BackColor = Color.Empty
                imgbox111.Invalidate()
                imgbox2.BackColor = Color.Empty
                imgbox2.Invalidate()
                imgbox22.BackColor = Color.Empty
                imgbox22.Invalidate()
                imgbox222.BackColor = Color.Empty
                imgbox222.Invalidate()

                lblstat.Visible = False
                defaultload()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                '/Console.WriteLine("Commit Exception Type: {0}", ex.GetType())
                '/Console.WriteLine("  Message: {0}", ex.Message)
                '/Dim typeName = ex.GetType().Name
                MsgBox("1: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()

                Catch ex2 As Exception
                    ' This catch block will handle any errors that may have occurred 
                    ' on the server that would cause the rollback to fail, such as 
                    ' a closed connection.
                    Me.Cursor = Cursors.Default
                    '/Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType())
                    '/Console.WriteLine("  Message: {0}", ex2.Message)
                    MsgBox("2: " & ex2.ToString & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub ExecuteUpdateCustomer(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor

                If Trim(cmbcus.Text).Contains("'") = True Then
                    'check muna kung walang customer ganyan na customer, meaning dapat customer is not exist with apostrophe
                    Dim exist As Boolean = False
                    sql = "Select cusid from tblcustomer where customer='" & Trim(cmbcus.Text).ToString.Replace("'", "''") & "'"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    If dr.Read Then
                        exist = True
                    End If
                    dr.Dispose()

                    If exist = False Then
                        'if may apostrophe, at cannot found sa db
                        'check sa db kung merong equal ito na walang '
                        Dim updatecus As Boolean = False, cusid As Integer
                        sql = "Select cusid from tblcustomer where customer='" & Trim(cmbcus.Text).ToString.Replace("'", "") & "'"
                        command.CommandText = sql
                        dr = command.ExecuteReader
                        If dr.Read Then
                            updatecus = True
                            cusid = dr("cusid")
                        End If
                        dr.Dispose()

                        If updatecus = True Then
                            sql = "Update tblcustomer set customer='" & Trim(cmbcus.Text).ToString.Replace("'", "''") & "' where cusid='" & cusid & "'"
                            command.CommandText = sql
                            command.ExecuteNonQuery()
                        End If
                    Else
                        'MsgBox("exist true")
                    End If
                End If

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                'Try
                '    Me.Cursor = Cursors.Default
                '    transaction.Rollback()
                'Catch ex2 As Exception
                '    Me.Cursor = Cursors.Default
                '    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                'End Try
            End Try
        End Using
    End Sub

    Public Sub saveedittrans()
        Try
            ExecuteSAveEdit(strconn)

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteSAveEdit(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                'first check entries dun sa btnok
                'transaction type
                Dim transtype As String = ""
                If cmbtype.SelectedIndex <> 0 Then
                    If cmbtype.SelectedItem.ToString.Contains("PICKUP") And Trim(cmbpick.Text) = "" Then
                        'MsgBox("Pick up Warehouse.", MsgBoxStyle.Exclamation, "")
                        'Exit Sub
                    Else
                        If Trim(cmbpick.Text) = "" Then
                            transtype = cmbtype.SelectedItem
                        Else
                            transtype = cmbtype.SelectedItem & " FRM " & Trim(cmbpick.Text)
                        End If
                    End If
                End If

                If txtso.Enabled = True And txtpo.Enabled = True Then
                    refnum = lblso.Text & txtso.Text & " / " & lblpo.Text & txtpo.Text
                ElseIf txtso.Enabled = True And txtpo.Enabled = False Then
                    refnum = lblso.Text & txtso.Text
                ElseIf txtso.Enabled = False And txtpo.Enabled = True Then
                    refnum = lblpo.Text & txtpo.Text
                ElseIf txtso.Enabled = False And txtpo.Enabled = False Then
                    refnum = "0000"
                End If


                Dim sonum As String = "", ponum As String = "", swsnum As String = "", itrnum As String = ""
                If lblso.Text = "SO#" And txtso.Enabled = True Then
                    sonum = Trim(txtso.Text)
                End If

                If lblpo.Text = "PO#" And txtpo.Enabled = True Then
                    ponum = Trim(txtpo.Text)
                ElseIf lblpo.Text = "ITR#" And txtpo.Enabled = True Then
                    itrnum = Trim(txtpo.Text)
                ElseIf lblpo.Text = "SWS#" And txtpo.Enabled = True Then
                    swsnum = Trim(txtpo.Text)
                End If

                Dim drn As String = "", ar As String = "", rdr As String = "", dn As String = "", it As String = "", grpo As String = ""
                If cmbtype.SelectedItem.ToString.Contains("SALES TRANSACTION PICKUP") = True Then
                    itrnum = "N/A"
                    it = "N/A"
                    grpo = "N/A"
                    swsnum = "N/A"
                    If cmbpick.Text.ToString.Contains("AGI ") = False Then
                        dn = "N/A"
                    End If
                ElseIf cmbtype.SelectedItem.ToString.Contains("SALES TRANSACTION") = True Then
                    ponum = "N/A"
                    dn = "N/A"
                    itrnum = "N/A"
                    it = "N/A"
                    grpo = "N/A"
                    swsnum = "N/A"
                ElseIf cmbtype.SelectedItem.ToString.Contains("STOCK TRANSFER PICKUP") = True Then
                    sonum = ""
                    drn = "N/A"
                    ar = "N/A"
                    If cmbpick.Text.ToString.Contains("AGI ") = False Then
                        dn = "N/A"
                    End If
                ElseIf cmbtype.SelectedItem.ToString.Contains("STOCK TRANSFER WHSE TO WHSE") = True Then
                    sonum = ""
                    drn = "N/A"
                    ar = "N/A"
                    ponum = "N/A"
                    grpo = "N/A"
                    swsnum = "N/A"
                ElseIf cmbtype.SelectedItem.ToString.Contains("JPSC TRUCKING FOR OTHERS PICKUP") = True Then
                    itrnum = "N/A"
                    it = "N/A"
                    grpo = "N/A"
                    swsnum = "N/A"
                ElseIf cmbtype.SelectedItem.ToString.Contains("JPSC TAXI") = True Then
                    sonum = ""
                    ar = "N/A"
                    drn = "N/A"
                    rdr = "N/A"
                    ponum = "N/A"
                    dn = "N/A"
                    swsnum = "N/A"
                    itrnum = "N/A"
                    it = "N/A"
                    grpo = "N/A"
                End If

                Dim chk As String = "", chkint As Integer = 0
                Dim pupfrm As String = ""
                If Trim(cmbpick.Text) <> "" And cmbpick.Text.Length >= 4 Then
                    pupfrm = cmbpick.Text.ToString.Substring(0, 4)
                End If
                If chkagi.Checked = True And cmbtype.SelectedItem.ToString.Contains("JPSC TRUCKING FOR OTHERS PICKUP") = True And pupfrm = "AGI " Then
                    chk = chkagi.Text
                    chkint = 1
                ElseIf chkso.Checked = True Then
                    chk = chkso.Text
                    chkint = 2
                ElseIf chkoro.Checked = True And cmbtype.SelectedItem.ToString.Contains("JPSC TRUCKING FOR OTHERS PICKUP") = True And pupfrm = "ORO " Then
                    chk = chkoro.Text
                    chkint = 3
                ElseIf chkmonde.Checked = True And cmbtype.SelectedItem.ToString.Contains("JPSC TRUCKING FOR OTHERS PICKUP") = True Then
                    chk = chkmonde.Text
                    chkint = 4
                End If

                Dim prio As Integer = 0
                If chkprio.Checked = True Then
                    prio = 1
                End If

                Dim lc As Integer = 0
                If chklc.Checked = True Then
                    lc = 1
                End If

                Dim ship As Integer = 0
                If chkstuff.Checked = True Then
                    ship = 1
                End If

                'command.CommandText = "Insert into tblortrans (transyear,transnum,refnum,datebooked,customer,transtype,notes,"
                'command.CommandText = command.CommandText & " sonum,ponum,swsnum,arnum,rdrnum,drnum,itrnum,dnnum,itnum,grponum,"

                Dim poiid As String = "Null", pup_poiid As String = "Null"
                If lblpoiid.Text <> "" Then
                    poiid = lblpoiid.Text
                End If
                If lblpuppoiid.Text <> "" Then
                    pup_poiid = lblpuppoiid.Text
                End If

                Dim s As String = Trim(txtnotes.Text.TrimEnd(ControlChars.Cr, ControlChars.Lf))
                sql = "Update tblortrans set refnum='" & refnum & "',arnum='" & ar & "', rdrnum='" & rdr & "', drnum='" & drn & "', dnnum='" & dn & "',"
                sql = sql & " itnum='" & it & "', grponum='" & grpo & "', itrnum='" & itrnum & "', sonum='" & sonum & "', ponum='" & ponum & "', swsnum='" & swsnum & "',"
                sql = sql & " datebooked='" & Format(datebook.Value, "yyyy/MM/dd") & "', dateexpected='" & Format(dateexp.Value, "yyyy/MM/dd") & "',"
                sql = sql & " customer='" & Trim(cmbcus.Text).ToString.Replace("'", "''") & "', notes='" & s.Replace("'", "''") & "',"
                sql = sql & " chktype='" & chkint & "', priority='" & prio & "', sapwhse='" & Trim(txtwhse.Text) & "',"
                sql = sql & " sap='" & lc & "',edited='1',stuffing='" & ship & "', datemodified=GetDate(), modifiedby='" & login.cashier & "', poiid=" & poiid & ", pup_poiid=" & pup_poiid & ","
                sql = sql & " trid=(Select trid from tbltranstype where transtype='" & cmbtype.SelectedItem & "'),"
                sql = sql & " pupid=(Select whseid from tblwhse where whsename='" & Trim(cmbpick.Text) & "')"
                sql = sql & " where transid='" & lbltransid.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()


                'delete orders in tblorder
                sql = "Delete from tblorder where transnum='" & lbltrnum.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()


                'save orders in tblorder

                'Dim dsc(grdorders.Rows.Count - 1) As String
                Dim marks As String = ""
                Dim totalfree As Double = 0

                For Each row As DataGridViewRow In grdorders.Rows
                    Me.Cursor = Cursors.WaitCursor
                    Dim iname As String = grdorders.Rows(row.Index).Cells(0).Value
                    Dim iqty As Double = Val(grdorders.Rows(row.Index).Cells(1).Value.ToString)

                    sql = "Insert into tblorder (transnum, itemcode, qty, status) values('" & lbltrnum.Text & "','" & iname & "','" & iqty & "','1')"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                Next

                'save edit logs
                Dim strform As String = ""
                If frm = "trans" Then
                    strform = "Order Transactions"
                ElseIf frm = "tripadd" Then
                    strform = "Trip Scheduling"
                End If
                sql = "Insert into tblorderedit (transnum,dateedited,editedby,frm) values ('" & lbltrnum.Text & "',GetDate(),'" & login.cashier & "','" & strform & " - Edit Orders" & "')"
                command.CommandText = sql
                command.ExecuteNonQuery()

                'delete image in tblorimage
                sql = "Delete from tblorimage where transnum='" & lbltrnum.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                If imgbox1.Image IsNot Nothing Then
                    Dim ms As New MemoryStream()
                    Dim filename As String = lblso.Text & Trim(txtso.Text)

                    sql = "Insert into tblorimage (transnum,name,img) values(@transnum1,@name1,@img1)"
                    command.CommandText = sql
                    command.Parameters.Add(New SqlClient.SqlParameter("@transnum1", lbltrnum.Text))
                    command.Parameters.Add(New SqlClient.SqlParameter("@name1", filename))
                    imgbox1.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img1", SqlDbType.Image)
                    img.Value = data
                    command.Parameters.Add(img)
                    command.ExecuteNonQuery()
                    imgbox1.BackColor = Color.Empty
                    imgbox1.Invalidate()
                End If

                If imgbox11.Image IsNot Nothing Then
                    Dim ms As New MemoryStream()
                    Dim filename As String = lblso.Text & Trim(txtso.Text) & "(2)"

                    sql = "Insert into tblorimage (transnum,name,img) values(@transnum11,@name11,@img11)"
                    command.CommandText = sql
                    command.Parameters.Add(New SqlClient.SqlParameter("@transnum11", lbltrnum.Text))
                    command.Parameters.Add(New SqlClient.SqlParameter("@name11", filename))
                    imgbox11.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img11", SqlDbType.Image)
                    img.Value = data
                    command.Parameters.Add(img)
                    command.ExecuteNonQuery()
                    imgbox11.BackColor = Color.Empty
                    imgbox11.Invalidate()
                End If

                If imgbox111.Image IsNot Nothing Then
                    Dim ms As New MemoryStream()
                    Dim filename As String = lblso.Text & Trim(txtso.Text) & "(3)"

                    sql = "Insert into tblorimage (transnum,name,img) values(@transnum111,@name111,@img111)"
                    command.CommandText = sql
                    command.Parameters.Add(New SqlClient.SqlParameter("@transnum111", lbltrnum.Text))
                    command.Parameters.Add(New SqlClient.SqlParameter("@name111", filename))
                    imgbox111.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img111", SqlDbType.Image)
                    img.Value = data
                    command.Parameters.Add(img)
                    command.ExecuteNonQuery()
                    imgbox111.BackColor = Color.Empty
                    imgbox111.Invalidate()
                End If

                If imgbox2.Image IsNot Nothing Then
                    Dim ms As New MemoryStream()
                    Dim filename As String = lblpo.Text & Trim(txtpo.Text)

                    sql = "Insert into tblorimage (transnum,name,img) values(@transnum2,@name2,@img2)"
                    command.CommandText = sql
                    command.Parameters.Add(New SqlClient.SqlParameter("@transnum2", lbltrnum.Text))
                    command.Parameters.Add(New SqlClient.SqlParameter("@name2", filename))
                    imgbox2.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img2", SqlDbType.Image)
                    img.Value = data
                    command.Parameters.Add(img)
                    command.ExecuteNonQuery()
                    imgbox2.BackColor = Color.Empty
                    imgbox2.Invalidate()
                End If

                If imgbox22.Image IsNot Nothing Then
                    Dim ms As New MemoryStream()
                    Dim filename As String = lblpo.Text & Trim(txtpo.Text) & "(2)"

                    sql = "Insert into tblorimage (transnum,name,img) values(@transnum22,@name22,@img22)"
                    command.CommandText = sql
                    command.Parameters.Add(New SqlClient.SqlParameter("@transnum22", lbltrnum.Text))
                    command.Parameters.Add(New SqlClient.SqlParameter("@name22", filename))
                    imgbox22.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img22", SqlDbType.Image)
                    img.Value = data
                    command.Parameters.Add(img)
                    command.ExecuteNonQuery()
                    imgbox22.BackColor = Color.Empty
                    imgbox22.Invalidate()
                End If

                If imgbox222.Image IsNot Nothing Then
                    Dim ms As New MemoryStream()
                    Dim filename As String = lblpo.Text & Trim(txtpo.Text) & "(3)"

                    sql = "Insert into tblorimage (transnum,name,img) values(@transnum222,@name222,@img222)"
                    command.CommandText = sql
                    command.Parameters.Add(New SqlClient.SqlParameter("@transnum222", lbltrnum.Text))
                    command.Parameters.Add(New SqlClient.SqlParameter("@name222", filename))
                    imgbox222.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img222", SqlDbType.Image)
                    img.Value = data
                    command.Parameters.Add(img)
                    command.ExecuteNonQuery()
                    imgbox222.BackColor = Color.Empty
                    imgbox222.Invalidate()
                End If

                ' Attempt to commit the transaction.
                transaction.Commit()

                Me.Cursor = Cursors.Default
                'save tblorimage
                lblstat.Visible = False
                defaultload()

                If frm = "trans" Then
                    If trans.clickbtn = "Searched" Then
                        trans.btnsearch.PerformClick()
                    Else
                        trans.btnview.PerformClick()
                    End If
                ElseIf frm = "tripadd" Then
                    tripadd.btnview.PerformClick()
                End If


            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.ToString & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            If btnok.Text = "OK" Then

                If grdorders.Rows.Count <> 0 Then
                    Dim a As String = MsgBox("Please confirm CANCELLATION of this transaction.", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MessageBoxDefaultButton.Button2, "")
                    If a = vbYes Then
                        defaultload()
                        '/gcform.grdgc.Rows.Clear()
                        grdorders.Rows.Clear()
                        grdorders.Rows.Add()

                        '/gcform.txtamt.Text = "100.00"
                        '/gcform.txtserial.Text = ""
                        '/gcform.lblgctotal.Text = "0.00"

                        voidd = False
                    End If
                Else
                    MsgBox("No orders entered. Please check entries.", MsgBoxStyle.Exclamation, "")
                    '/   btnok.Enabled = True
                    If grdorders.Rows.Count = 0 Then
                        grdorders.Rows.Add()
                    End If
                    defaultload()
                    Exit Sub
                End If

            Else
                Me.Dispose()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadtransnum()
        Try
            If edittrans = False Then
                '''''load again transnum
                Dim trnum As String = "1", temp As String = ""
                'sql = "Select Top 1 * from tblortrans order by transid DESC"
                'connect()
                'cmd = New SqlCommand(sql, conn)
                'dr = cmd.ExecuteReader
                'If dr.Read Then
                '    '/trnum = Val(dr("transid")) + 1
                'End If
                'cmd.Dispose()
                'dr.Dispose()
                'conn.Close()

                'check kung pang ilang LOGSHEET NA SA YEAR NA 2018 na
                sql = "Select Count(transid) from tblortrans where transyear=Year(GetDate()) And whsename='" & login.whse & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                trnum = cmd.ExecuteScalar + 1
                cmd.Dispose()
                conn.Close()

                Dim prefix As String = ""
                sql = "Select whsecode from tblwhse where whsename='" & login.whse & "' and status='1'"
                connect()
                cmd = New SqlCommand(sql, conn)
                Dim drm As SqlDataReader = cmd.ExecuteReader
                If drm.Read Then
                    prefix = drm("whsecode")
                End If
                drm.Dispose()
                cmd.Dispose()
                conn.Close()

                If trnum < 1000000 Then
                    For vv As Integer = 1 To 6 - trnum.Length
                        temp += "0"
                    Next
                    'lbltrnum.Text = Date.Now.Year & "-" & Format(Date.Now, "MM") & Format(Date.Now, "dd") & temp & trnum
                End If

                lbltrnum.Text = "O." & prefix & "-" & Format(Date.Now, "yy") & "-" & temp & trnum

            ElseIf edittrans = True Then
                ExecuteViewTrans(strconn)
            End If


        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteViewTrans(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim drm As SqlDataReader
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                Dim poiid As Integer = 0, pup_poiid As Integer = 0
                sql = "select o.transid,o.transnum,o.refnum,o.datebooked,o.customer,tr.transtype,w.whsename as pupwhse,"
                sql = sql & " o.notes,o.whsename,o.chktype,o.dateexpected,o.priority,o.sapwhse,o.sap,o.poiid,o.pup_poiid,o.stuffing,"
                sql = sql & " p.poiname as gpspoi,p.address as gps_add,pp.poiname as puppoi,pp.address as pup_add"
                sql = sql & " From tblortrans o"
                sql = sql & " Right outer join tbltranstype tr on tr.trid=o.trid"
                sql = sql & " Left outer join tblwhse w on w.whseid=o.pupid"
                sql = sql & " Left outer join tblpoi p on p.poiid=o.poiid"
                sql = sql & " Left outer join tblpoi pp on pp.poiid=o.pup_poiid"
                sql = sql & " where o.transid='" & lbltransid.Text & "'"
                command.CommandText = sql
                drm = command.ExecuteReader
                If drm.Read Then
                    cmbcus.SelectedItem = drm("customer")
                    cmbdestin.Text = drm("gpspoi").ToString
                    cmbadd.Text = drm("gps_add")
                    cmbpupadd.Items.Add(drm("pup_add"))
                    cmbpupadd.SelectedItem = drm("pup_add")

                    cmbtype.SelectedItem = drm("transtype")
                    cmbpick.Text = drm("pupwhse").ToString
                    txtnotes.Text = drm("notes")
                    txtwhse.Text = drm("sapwhse").ToString
                    datebook.Value = drm("datebooked")
                    If IsDBNull(drm("dateexpected")) = False Then
                        dateexp.Value = drm("dateexpected")
                    Else
                        dateexp.Value = drm("datebooked")
                    End If
                    chkprio.Checked = False
                    If IsDBNull(drm("priority")) = False Then
                        If drm("priority") = 1 Then
                            chkprio.Checked = True
                        End If
                    End If
                    chklc.Checked = False
                    If IsDBNull(drm("sap")) = False Then
                        If drm("sap") = 1 Then
                            chklc.Checked = True
                        End If
                    End If
                    chkstuff.Checked = False
                    If IsDBNull(drm("stuffing")) = False Then
                        If drm("stuffing") = 1 Then
                            chkstuff.Checked = True
                        End If
                    End If

                    If drm("refnum").ToString.Contains("/") Then
                        If drm("refnum").ToString.Contains("SO#") Then
                            Dim inSql As String = drm("refnum").ToString
                            Dim fromStart As Integer
                            Dim firstpart As String

                            fromStart = inSql.IndexOf("/")
                            firstpart = inSql.Substring(3, fromStart - 4)
                            txtso.Text = Trim(firstpart)

                        End If

                        If drm("refnum").ToString.Contains("PO#") Then
                            Dim inSql As String = drm("refnum").ToString
                            Dim lastPart As String
                            Dim fromStart As Integer

                            fromStart = inSql.IndexOf("PO#") + 3
                            lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)
                            txtpo.Text = Trim(lastPart)
                        End If

                        If drm("refnum").ToString.Contains("SWS#") Then
                            Dim inSql As String = drm("refnum").ToString
                            Dim lastPart As String
                            Dim fromStart As Integer

                            fromStart = inSql.IndexOf("SWS#") + 4
                            lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)
                            txtpo.Text = Trim(lastPart)

                        End If
                    Else
                        If drm("refnum").ToString.Contains("SO#") Then
                            Dim inSql As String = drm("refnum").ToString
                            Dim fromStart As Integer
                            Dim firstpart As String

                            fromStart = inSql.IndexOf("#") + 1
                            firstpart = inSql.Substring(fromStart, inSql.Length - fromStart)
                            txtso.Text = Trim(firstpart)

                        Else
                            'If drm("refnum").ToString.Contains("PO#") Then
                            Dim inSql As String = drm("refnum").ToString
                            If inSql <> "" Then
                                Dim firstpart As String
                                Dim fromStart As Integer

                                fromStart = inSql.IndexOf("#") + 1
                                firstpart = inSql.Substring(fromStart, inSql.Length - fromStart)
                                lblpo.Text = inSql.Substring(0, fromStart)
                                txtpo.Text = Trim(firstpart)
                            End If

                        End If

                    End If


                    txtnotes.Focus()

                    If drm("chktype") = 1 Then
                        chkagi.Checked = True
                    ElseIf drm("chktype") = 2 Then
                        chkso.Checked = True
                    ElseIf drm("chktype") = 3 Then
                        chkoro.Checked = True
                    ElseIf drm("chktype") = 4 Then
                        chkmonde.Checked = True
                    End If
                End If
                drm.Dispose()


                Dim ctr As Integer = 0
                sql = "Select * from tblorimage where transnum='" & lbltrnum.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                While dr.Read
                    Me.Cursor = Cursors.WaitCursor
                    ctr += 1
                    Dim data As Byte() = DirectCast(dr("img"), Byte())
                    Dim ms As New MemoryStream(data)

                    If dr("name").ToString.Contains("SO") Then
                        If imgbox1.Image Is Nothing Then
                            imgbox1.Image = Image.FromStream(ms)
                        ElseIf imgbox11.Image Is Nothing Then
                            imgbox11.Image = Image.FromStream(ms)
                        ElseIf imgbox111.Image Is Nothing Then
                            imgbox111.Image = Image.FromStream(ms)
                        End If
                    Else
                        If imgbox2.Image Is Nothing Then
                            imgbox2.Image = Image.FromStream(ms)
                        ElseIf imgbox22.Image Is Nothing Then
                            imgbox22.Image = Image.FromStream(ms)
                        ElseIf imgbox222.Image Is Nothing Then
                            imgbox222.Image = Image.FromStream(ms)
                        End If
                    End If
                End While
                dr.Dispose()


                grdorders.Rows.Clear()
                sql = "Select itemcode,qty from tblorder where transnum='" & lbltrnum.Text & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                While dr.Read
                    grdorders.Rows.Add(dr("itemcode"), dr("qty"))
                End While
                dr.Dispose()

                grdorders.Rows.Add()


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.ToString & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Public Sub defaultload()
        Me.Cursor = Cursors.WaitCursor
        customer()
        'grdorders.Rows.Clear()

        txtnotes.Text = ""
        cmbcus.Enabled = True
        cmbcus.Text = ""
        'cmbdestin.Items.Clear()
        'cmbdestin.text= ""
        datebook.Value = dtServerDateTime.Date
        dateexp.Value = dtServerDateTime.Date
        chkprio.Checked = False
        chkstuff.Checked = False

        cmbdestin.Enabled = True
        cmbadd.Enabled = True

        cmbtype.SelectedItem = ""
        cmbpick.Text = ""
        cmbpupadd.SelectedItem = ""
        cmbpupadd.Items.Clear()
        lbltrucking.Text = ""
        txtwhse.Text = ""
        cmbdestin.Text = ""
        cmbadd.Text = ""
        lblpoiid.Text = ""

        GroupBox2.Text = "PO"

        imgbox.Image = Nothing

        txtso.Text = "0000"
        imgbox1.Image = Nothing
        imgbox11.Image = Nothing
        imgbox111.Image = Nothing

        txtpo.Text = "0000"
        imgbox2.Image = Nothing
        imgbox22.Image = Nothing
        imgbox222.Image = Nothing

        lblso.Text = "SO#"
        lblso.Enabled = False
        txtso.Enabled = False
        chkso.Checked = False
        chkso.Enabled = False

        chkoro.Checked = False
        chkoro.Enabled = False

        chkmonde.Checked = False
        chkmonde.Enabled = False

        lblpo.Text = "PO#"
        lblpo.Enabled = False
        txtpo.Enabled = False
        chkpo.Checked = False
        chkpo.Enabled = False

        btnattachso.Enabled = False
        btnattachpo.Enabled = False

        Panel14.Enabled = True
        TableLayoutPanel2.Enabled = True
        Panel15.Enabled = True
        btnok.Enabled = True

        loadtransnum()
        Me.Cursor = Cursors.Default
        'End If
    End Sub

    Public Sub savelogout()
        Try
            Dim logid As Integer = 0

            sql = "Select * from tbllogin where datelogin='" & Format(Date.Now, "yyyy/MM/dd") & "' and username='" & login.cashier & "' and logout=''"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                logid = dr("systemid")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            sql = "Update tbllogin set logout='" & Format(Date.Now, "HH:mm") & "' where systemid='" & logid & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub savebreak()
        Try
            Dim logid As Integer = 0

            sql = "Select * from tbllogin where datelogin='" & Format(Date.Now, "yyyy/MM/dd") & "' and username='" & login.cashier & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                logid = dr("systemid")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            sql = "Update tbllogin set cbreak='" & Format(Date.Now, "HH:mm") & "' where systemid='" & logid & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub ref()
        Try
            'For Each btn As Button In Panel5.Controls
            'If btn.Enabled = False Then
            'clickbtn = CType(btn, Button)
            'clearpanel()
            'viewitems()
            'End If
            'Next
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub mainmenucopy_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.WindowState = FormWindowState.Maximized

    End Sub

    Public Sub customer()
        Try
            cmbcus.Items.Clear()

            sql = "Select customer from tblcustomer where status='1' order by customer"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbcus.Items.Add(dr("customer"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    'Private Sub poi()
    '    Try
    '        backgroundWorkerdestin = New BackgroundWorker()
    '        backgroundWorkerdestin.WorkerSupportsCancellation = True

    '        cmbdestin.Text = ""
    '        cmbdestin.Items.Clear()
    '        cmbadd.SelectedItem = ""
    '        cmbdestin.Enabled = False

    '        'sql = "Select DISTINCT p.poiname from tblpoi p"
    '        'sql = sql & " inner join tblpoidistance d on p.poiid=d.poiid and d.whsename='" & login.whse & "' and d.value is not null"
    '        'sql = sql & " where p.status='1' order by p.poiname"

    '        sql = "Select DISTINCT p.poiname from tblpoi p"
    '        sql = sql & " inner join tblpoidistance d on p.poiid=d.poiid and d.whsename='" & login.whse & "'" ' and d.value is not null"
    '        sql = sql & " inner join tblcuspoi cp on d.poiid=cp.poiid and cp.status='1'"
    '        sql = sql & " inner join tblcustomer c on cp.cusid=c.cusid"
    '        sql = sql & " where p.status='1' and c.customer='" & Trim(cmbcus.Text.ToString.Replace("'", "''")) & "'"
    '        sql = sql & " order by p.poiname"
    '        gridsql = sql

    '        AddHandler backgroundWorkerdestin.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkerdestin_DoWork)
    '        AddHandler backgroundWorkerdestin.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkerdestin_Completed)
    '        AddHandler backgroundWorkerdestin.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorkerdestin_ProgressChanged)
    '        m_destinRowDelegate = New destinRowDelegate(AddressOf destinDGVRow)

    '        If Not backgroundWorkerdestin.IsBusy Then
    '            backgroundWorkerdestin.WorkerReportsProgress = True
    '            backgroundWorkerdestin.WorkerSupportsCancellation = True
    '            backgroundWorkerdestin.RunWorkerAsync() 'start ng select query
    '        End If


    '        'connect()
    '        'cmd = New SqlCommand(sql, conn)
    '        'dr = cmd.ExecuteReader
    '        'While dr.Read
    '        '    If Not cmbdestin.Items.Contains(dr("poiname")) Then
    '        '        cmbdestin.Items.Add(dr("poiname"))
    '        '    End If
    '        'End While
    '        'dr.Dispose()
    '        'cmd.Dispose()
    '        'conn.Close()

    '        Me.Cursor = Cursors.Default
    '    Catch ex As System.InvalidOperationException
    '        Me.Cursor = Cursors.Default
    '        MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
    '    Catch ex As Exception
    '        Me.Cursor = Cursors.Default
    '        MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
    '    Finally
    '        disconnect()
    '    End Try
    'End Sub

    'Private Sub backgroundWorkerdestin_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
    '    If cancelpending = True Then
    '        e.Cancel = True
    '    Else
    '        threadEnableddestin = True
    '        Dim temp As String = "", temptype As String = "", temp2 As String = "", temptype2 As String = "", taxides As String = ""
    '        Dim connection As SqlConnection
    '        connection = New SqlConnection
    '        connection.ConnectionString = strconn
    '        If connection.State <> ConnectionState.Open Then
    '            connection.Open()
    '        End If
    '        cmd = New SqlCommand(gridsql, connection)
    '        Dim drx As SqlDataReader = cmd.ExecuteReader

    '        While drx.Read
    '            If backgroundWorkerdestin.CancellationPending = True Then
    '                e.Cancel = True
    '                Exit While
    '            Else
    '                'If Me.InvokeRequired Then
    '                '    Me.Invoke(m_destinRowDelegate, drx("poiname"))
    '                'Else
    '                destinDGVRow(drx("poiname"))
    '                'End If
    '            End If
    '        End While
    '        drx.Dispose()
    '        cmd.Dispose()
    '        connection.Close()
    '    End If
    'End Sub

    'Delegate Sub destinRowDelegate(ByVal value0 As Object)
    'Private m_destinRowDelegate As destinRowDelegate

    'Private Sub destinDGVRow(ByVal value0 As Object)
    '    If threadEnableddestin = True Then
    '        If Me.InvokeRequired Then
    '            Me.BeginInvoke(New destinRowDelegate(AddressOf destinDGVRow), value0)
    '        Else
    '            cmbdestin.Items.Add(value0)
    '        End If
    '    End If
    'End Sub

    'Private Sub backgroundWorkerdestin_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
    '    Me.Cursor = Cursors.Default
    '    'ProgressBar1.Visible = False
    '    'ProgressBar1.Style = ProgressBarStyle.Blocks
    '    'lblloading.Visible = False
    '    'Panel1.Enabled = True
    '    If e.Error IsNot Nothing Then
    '        MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
    '    ElseIf e.Cancelled = True Then
    '        MsgBox("Operation Is cancelled.", MsgBoxStyle.Exclamation, "")
    '    Else
    '        cmbdestin.Enabled = True
    '        cmbadd.Enabled = True
    '        If Trim(cmbcus.Text) <> "" Then
    '            'cmbdestin.Items.Add("---TEMPORARY POI---")
    '            If cmbdestin.Items.Count > 0 And cmbdestin.Items.Count <= 2 Then
    '                If cmbdestin.Items(0) <> "---TEMPORARY POI---" Then
    '                    cmbdestin.Text = cmbdestin.Items(0)
    '                End If
    '            Else
    '                cmbdestin.Enabled = False
    '                cmbadd.Enabled = False
    '            End If
    '        End If
    '    End If
    'End Sub

    Private Sub backgroundWorkerdestin_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label3.Text = e.ProgressPercentage.ToString() & "% complete"
    End Sub

    Private Sub btnattach_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnattachso.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim open As OpenFileDialog
            open = New OpenFileDialog
            open.FileName = ""
            open.Filter = "Image Formats(*.jpg;*.jpeg;*.bmp;*.gif;*.png;*.tif)|*.jpg;*.jpeg;*.bmp;*.gif;*.png;*.tif|JPEG Format(*.jpg;*.jpeg)|*.jpg;*.jpeg|BITMAP Format(*.bmp)|*.bmp|GIF Format(*.gif)|*.gif|PNG Format(*.png)|*.png"
            If open.ShowDialog = Windows.Forms.DialogResult.OK Then
                If imgbox1.Image Is Nothing Then
                    imgbox1.Image = Image.FromFile(open.FileName.ToUpper)
                    'filename = open.SafeFileName.ToString() 'Get as image name
                ElseIf imgbox11.Image Is Nothing Then
                    imgbox11.Image = Image.FromFile(open.FileName.ToUpper)
                    'filename = open.SafeFileName.ToString() 'Get as image name
                ElseIf imgbox111.Image Is Nothing Then
                    imgbox111.Image = Image.FromFile(open.FileName.ToUpper)
                    'filename = open.SafeFileName.ToString() 'Get as image name
                End If
            End If
            Me.Cursor = Cursors.Default

        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try
    End Sub

    Private Sub imgbox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles imgbox1.Click
        If imgbox1.Image IsNot Nothing Then
            imgbox.Image = imgbox1.Image
            imgname = imgbox1.Name
        End If
    End Sub

    Public Sub imgClicked(ByVal sender As Object, ByVal e As EventArgs)
        Try
            clickimg = CType(sender, PictureBox)
            MsgBox(clickimg.Name.ToString)
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtso_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtso.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            'searchSO()
            btnok.Focus()
            'txtso.Focus()
        End If
    End Sub

    Private Sub cmbcus_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbcus.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbcus_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbcus.Leave
        If keyEnter2 = False Then
            selectcustomer()
        End If
    End Sub

    Private Sub selectcustomer()
        Try
            If Trim(cmbcus.Text) <> "" Then
                Dim exist As Boolean = False
                sql = "Select customer from tblcustomer where status='1' and customer='" & Trim(cmbcus.Text).ToString.Replace("'", "''") & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                Dim dr2 As SqlDataReader = cmd.ExecuteReader
                If dr2.Read Then
                    exist = True
                    cmbcus.Text = dr2("customer")
                Else
                    cmbcus.Text = ""
                End If
                dr2.Dispose()
                cmd.Dispose()
                conn.Close()

                If cmbcus.Text <> "" Then
                    transactiontype()
                End If
            Else
                cmbdestin.Text = ""
                cmbadd.Text = ""
            End If
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        trans.ShowDialog()
    End Sub

    Private Sub btnattachpo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnattachpo.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim open As OpenFileDialog
            open = New OpenFileDialog
            open.FileName = ""
            open.Filter = "Image Formats(*.jpg;*.jpeg;*.bmp;*.gif;*.png;*.tif)|*.jpg;*.jpeg;*.bmp;*.gif;*.png;*.tif|JPEG Format(*.jpg;*.jpeg)|*.jpg;*.jpeg|BITMAP Format(*.bmp)|*.bmp|GIF Format(*.gif)|*.gif|PNG Format(*.png)|*.png"
            If open.ShowDialog = Windows.Forms.DialogResult.OK Then
                If imgbox2.Image Is Nothing Then
                    imgbox2.Image = Image.FromFile(open.FileName.ToUpper)
                    'filename = open.SafeFileName.ToString() 'Get as image name
                ElseIf imgbox22.Image Is Nothing Then
                    imgbox22.Image = Image.FromFile(open.FileName.ToUpper)
                    'filename = open.SafeFileName.ToString() 'Get as image name
                ElseIf imgbox222.Image Is Nothing Then
                    imgbox222.Image = Image.FromFile(open.FileName.ToUpper)
                    'filename = open.SafeFileName.ToString() 'Get as image name
                End If
            End If
            Me.Cursor = Cursors.Default

        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try
    End Sub

    Private Sub imgbox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles imgbox2.Click
        If imgbox2.Image IsNot Nothing Then
            imgbox.Image = imgbox2.Image
            imgname = imgbox2.Name
        End If
    End Sub

    Private Sub txtso_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtso.Leave
        'If firstref <> Trim(txtso.Text) Then
        searchSO()
        'End If
    End Sub

    Private Sub searchSO()
        Try
            If Trim(txtso.Text) <> "" Or Val(Trim(txtso.Text)) <> 0 Then
                'check if may letter na TOFLW
                Dim Mystring As String = Trim(txtso.Text)
                If Mystring.ToUpper.Contains("O") And Mystring.ToUpper.Contains("F") And Mystring.ToUpper.Contains("L") And Mystring.ToUpper.Contains("W") Then
                    '/If CheckForAlphaCharacters(Mystring) Then
                    txtso.Text = "TO FOLLOW"
                    '/Else
                    'do stuff here if it doesn't contain letters
                End If

                If Trim(txtso.Text) <> "TO FOLLOW" And Trim(txtso.Text) <> "0000" Then
                    firstref = Trim(txtso.Text)
                    ExecuteSO(strconn, firstref)
                ElseIf Trim(txtso.Text) = "TO FOLLOW" Then
                    chklc.Checked = False
                    txtwhse.Text = ""
                    MsgBox("Input notes why SO# is TO FOLLOW.", MsgBoxStyle.Exclamation, "")
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteSO(ByVal connectionString As String, ByVal sonum As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                Dim searchfrmsap As Boolean = False

                sql = "Select refnum from tblortrans where cancel='0' and (refnum like 'SO#" & Trim(txtso.Text) & " /%' OR refnum='SO#" & Trim(txtso.Text) & "')"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    MsgBox("SO# already exists.", MsgBoxStyle.Information, "")
                End If
                dr.Dispose()

                sql = "Select status from tblactivate where status='1' and module='searchfrmsap'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    searchfrmsap = True
                End If
                dr.Dispose()


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

                chklc.Checked = False
                If login.svrlc = True Then  'mditrip.connectSAP
                    If IsNumeric(Trim(txtso.Text)) = True Then
                        If searchfrmsap = True Then
                            lblstat.Visible = False
                            cmbcus.Tag = ""
                            'searchSO_from_SAP(Trim(txtso.Text), login.connStrSAP)
                            getSO_Details(Trim(txtso.Text))
                        Else
                            lblstat.Visible = True
                            chklc.Checked = False
                            cmbcus.Enabled = True
                            txtwhse.Text = ""
                        End If
                    Else
                        MsgBox("Invalid SO#.", MsgBoxStyle.Exclamation, "")
                    End If
                End If
                If chklc.Checked = True And Trim(cmbcus.Text).Contains("'") = True Then
                    ExecuteUpdateCustomer(strconn)
                End If

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.ToString & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Exclamation, "")
            End Try
        End Using
    End Sub

    Function CheckForAlphaCharacters(ByVal StringToCheck As String)
        For i = 0 To StringToCheck.Length - 1
            If Char.IsLetter(StringToCheck.Chars(i)) Then
                Return True
            End If
        Next

        Return False

    End Function

    Private Sub txtpo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtpo.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            'searchPO()
            btnok.Focus()
            'txtpo.Focus()
        End If
    End Sub

    Private Sub txtpo_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtpo.Leave
        'If secondref <> Trim(txtpo.Text) Then
        searchPO()
        'End If
    End Sub

    Private Sub searchPO()
        Try
            If Trim(txtpo.Text) <> "" Or Val(Trim(txtpo.Text)) <> 0 Then
                'check if may letter na TOFLW
                Dim Mystring As String = Trim(txtpo.Text)
                If Mystring.ToUpper.Contains("O") And Mystring.ToUpper.Contains("F") And Mystring.ToUpper.Contains("L") And Mystring.ToUpper.Contains("W") Then
                    '/If CheckForAlphaCharacters(Mystring) Then
                    txtpo.Text = "TO FOLLOW"
                    '/Else
                    'do stuff here if it doesn't contain letters
                End If

                If Trim(txtpo.Text) <> "TO FOLLOW" And Trim(txtpo.Text) <> "0000" Then
                    secondref = Trim(txtpo.Text)
                    sql = "Select refnum from tblortrans where cancel='0' and (refnum like '%/ " & Trim(lblpo.Text) & Trim(txtpo.Text) & "' OR refnum='" & Trim(lblpo.Text) & Trim(txtpo.Text) & "')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox(Trim(lblpo.Text) & " already exists.", MsgBoxStyle.Information, "")
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    If login.svrlc = True Then
                        If txtso.Enabled = False Then
                            chklc.Checked = False
                            'WALANG SO, PO OR ITR LANG
                            If IsNumeric(Trim(txtpo.Text)) = True Then
                                If lblpo.Text = "PO#" Then
                                    'searchPO_from_SAP(Trim(txtpo.Text), login.connStrSAP, "PO")
                                    getPO_Details(Trim(txtpo.Text))
                                ElseIf lblpo.Text = "ITR#" Then
                                    'searchPO_from_SAP(Trim(txtpo.Text), login.connStrSAP, "ITR")
                                    getITR_Details(Trim(txtpo.Text))
                                End If
                            Else
                                MsgBox("Invalid " & lblpo.Text & ".", MsgBoxStyle.Exclamation, "")
                            End If
                        Else
                            'SO ITEMS ANG DAPAT MAG REFLECT
                            'NO NEED TO SEARCH KASI SA PAG ENTER NMN NG SO YUN
                            'searchSO_from_SAP(Trim(txtpo.Text), mditrip.connStrLC)
                        End If
                    End If
                ElseIf Trim(txtpo.Text) = "TO FOLLOW" Then
                    chklc.Checked = False
                    MsgBox("Input notes why " & lblpo.Text & " is TO FOLLOW.", MsgBoxStyle.Exclamation, "")
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtso_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtso.TextChanged
        Try
            Dim charactersDisallowed As String = "toflwTOFLW1234567890 "
            Dim theText As String = txtso.Text
            Dim Letter As String
            Dim SelectionIndex As Integer = txtso.SelectionStart
            Dim Change As Integer

            For x As Integer = 0 To txtso.Text.Length - 1
                Letter = txtso.Text.Substring(x, 1)
                If Not charactersDisallowed.Contains(Letter) Then
                    theText = theText.Replace(Letter, String.Empty)
                    Change = 1
                End If
            Next

            txtso.Text = theText.ToUpper
            txtso.Select(SelectionIndex - Change, 0)

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdorders_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdorders.CellContentClick
        grdorders.BeginEdit(True)
    End Sub

    Private Sub grdorders_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdorders.CellEndEdit
        Try
            Dim ii As Integer = grdorders.CurrentRow.Index

            If e.ColumnIndex = 0 Then
                If grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value IsNot Nothing Then
                    If Trim(grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value) <> "" Then

                        grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value = grdorders.Rows(grdorders.CurrentRow.Index).Cells(0).Value.ToString.ToUpper()
                    End If
                End If
            End If

            If e.ColumnIndex = 1 Then
                If grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value.ToString IsNot Nothing And Val(grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value) = 0 Then
                    MsgBox("Input must be a non zero number", MsgBoxStyle.Exclamation, "")
                    Me.Cursor = Cursors.Default
                    Exit Sub
                ElseIf grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value.ToString IsNot Nothing And Val(grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value) < 0 Then
                    MsgBox("Invalid input", MsgBoxStyle.Exclamation, "")
                    grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value = 0
                    Me.Cursor = Cursors.Default
                    Exit Sub
                Else
                    Dim qty As Double = Val(grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value)
                    grdorders.Rows(grdorders.CurrentRow.Index).Cells(1).Value = qty
                End If
            End If

            'If e.ColumnIndex = 5 Then
            '    If grdorders.Rows(grdorders.CurrentRow.Index).Cells(5).Value.ToString.Contains("'") Then
            '        Dim strtemp As String = grdorders.Rows(grdorders.CurrentRow.Index).Cells(5).Value
            '        grdorders.Rows(grdorders.CurrentRow.Index).Cells(5).Value = strtemp.Replace("'", String.Empty)
            '    End If
            'End If

            If grdorders.Rows(ii).Cells(0).Value IsNot Nothing And grdorders.Rows(ii).Cells(1).Value IsNot Nothing Then
                If grdorders.RowCount = ii + 1 Then
                    grdorders.Rows.Add()
                    grdorders.CurrentCell = grdorders(0, grdorders.RowCount - 1)
                    grdorders.BeginEdit(False)
                End If
                grdorders.Rows(ii).ErrorText = ""
            Else
                grdorders.Rows(ii).ErrorText = "Complete the required fields"
            End If

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try

    End Sub

    Public Sub view()
        Try
            fillcombo()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub fillcombo()
        Try
            'For rowIndex As Integer = 0 To grdorders.Rows.Count - 1
            sql = "Select itemcode from tbloritems where status='1' order by itemcode"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                CType(Me.grdorders.Columns(0), DataGridViewComboBoxColumn).Items.Add(dr("itemcode"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            'Next
            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdorders_CellValidating(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellValidatingEventArgs) Handles grdorders.CellValidating
        If ColAdd Then
            Dim comboBoxColumn As DataGridViewComboBoxColumn = CType(grdorders.Columns(0), DataGridViewComboBoxColumn)
            If (e.ColumnIndex = comboBoxColumn.DisplayIndex) Then
                'If (Not comboBoxColumn.Items.Contains(e.FormattedValue)) Then
                '    comboBoxColumn.Items.Add(e.FormattedValue)
                '    grdorders.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = comboBoxColumn.Items(comboBoxColumn.Items.Count - 1)
                'End If
            End If
        End If
    End Sub

    Private Sub grdorders_DataError(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles grdorders.DataError
        If (e.Context = DataGridViewDataErrorContexts.LeaveControl) Then
            MessageBox.Show("leave control error")
        End If
    End Sub

    Private Sub grdorders_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles grdorders.EditingControlShowing
        Dim comboBoxColumn As DataGridViewComboBoxColumn = grdorders.Columns(0)
        If (grdorders.CurrentCellAddress.X = comboBoxColumn.DisplayIndex) Then
            Dim cb As ComboBox = e.Control
            If (cb IsNot Nothing) Then
                cb.DropDownStyle = ComboBoxStyle.DropDown
                cb.AutoCompleteSource = AutoCompleteSource.ListItems
                cb.AutoCompleteMode = AutoCompleteMode.SuggestAppend
            End If
        End If
    End Sub

    Private Sub btnimgremove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgremove.Click
        If imgbox.Image Is Nothing Then
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
            Exit Sub
        End If

        If imgname = "imgbox1" Then
            imgbox1.Image = imgbox11.Image
            imgbox11.Image = imgbox111.Image
            imgbox111.Image = Nothing
        ElseIf imgname = "imgbox11" Then
            imgbox11.Image = imgbox111.Image
            imgbox111.Image = Nothing
        ElseIf imgname = "imgbox111" Then
            imgbox111.Image = Nothing
        ElseIf imgname = "imgbox2" Then
            imgbox2.Image = imgbox22.Image
            imgbox22.Image = imgbox222.Image
            imgbox222.Image = Nothing
        ElseIf imgname = "imgbox22" Then
            imgbox22.Image = imgbox222.Image
            imgbox222.Image = Nothing
        ElseIf imgname = "imgbox222" Then
            imgbox222.Image = Nothing
        End If
        imgbox.Image = Nothing
    End Sub

    Private Sub imgbox11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles imgbox11.Click
        If imgbox11.Image IsNot Nothing Then
            imgbox.Image = imgbox11.Image
            imgname = imgbox11.Name
        End If
    End Sub

    Private Sub imgbox111_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles imgbox111.Click
        If imgbox111.Image IsNot Nothing Then
            imgbox.Image = imgbox111.Image
            imgname = imgbox111.Name
        End If
    End Sub

    Private Sub imgbox22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles imgbox22.Click
        If imgbox22.Image IsNot Nothing Then
            imgbox.Image = imgbox22.Image
            imgname = imgbox22.Name
        End If
    End Sub

    Private Sub imgbox222_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles imgbox222.Click
        If imgbox222.Image IsNot Nothing Then
            imgbox.Image = imgbox222.Image
            imgname = imgbox222.Name
        End If
    End Sub

    Private Sub btnimgcancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnimgcancel.Click
        If imgbox.Image IsNot Nothing Then
            imgbox.Image = Nothing
        End If
    End Sub

    Private Sub imgbox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles imgbox.Click
        If imgbox.Image IsNot Nothing Then
            viewimage.lblimgname.Text = ""
            viewimage.imgbox.Image = imgbox.Image
            viewimage.ShowDialog()
        End If
    End Sub

    Private Sub grdorders_RowsRemoved(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowsRemovedEventArgs) Handles grdorders.RowsRemoved
        If grdorders.Rows.Count = 0 Then
            'grdorders.Rows.Add()
        End If
    End Sub

    Private Sub cmbtype_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbtype.Leave

    End Sub

    Private Sub cmbtype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbtype.SelectedIndexChanged

    End Sub

    Private Sub transactiontype()
        Try
            'check muna if complete, may recipient, may transtype at kung enabled ang pickup dapat may supplier warehouse
            chkso.Enabled = False
            cmbcus.Enabled = True
            chkpo.Checked = False
            chkpo.Enabled = False

            If cmbtype.SelectedItem = "" Then
                cmbpick.Text = ""
                cmbpick.Enabled = False
                defaultref()
                txtso.Text = "0000"
                txtpo.Text = "0000"
            ElseIf cmbtype.SelectedItem.ToString.Contains("STOCK TRANSFER") = True Then

                'customer dapat with whse
                If Trim(cmbcus.Text).Contains(" WHSE") = True Or Trim(cmbcus.Text) = "" Then

                Else
                    MsgBox("Invalid recipient. If Recipient is NOT a warehouse, transaction type should NOT be a STOCK TRANSFER.", MsgBoxStyle.Exclamation, "")
                    If cmbtype.SelectedItem.ToString.Contains(" PICKUP") = True Then
                        cmbpick.Enabled = True
                    End If

                    lbltrucking.Text = ""
                    cmbcus.Text = ""
                    cmbcus.Focus()
                    cmbdestin.Text = ""
                    cmbadd.Text = ""
                    'Exit Sub
                End If

                '//////////////////////////////////////////////////////////
                'check kung may pup or wala
                If cmbtype.SelectedItem.ToString.Contains(" PICKUP") = True Then
                    cmbpick.Enabled = True
                    If Trim(cmbpick.Text) = "" Then
                        defaultref()
                        'txtso.Text = "0000"
                        'secondreftrue()
                    ElseIf Trim(cmbpick.Text).Contains("PIER") Or Trim(cmbpick.Text).Contains("PENSUMIL") Then
                        'if any pier or pensumil (ITR)
                        defaultref()
                        secondreftrue()
                        lblpo.Text = "ITR#"
                        GroupBox2.Text = "ITR"
                        btnattachpo.Text = "ATTACH ITR"
                    Else
                        'if any agi or other supplier dapat may (PO)
                        chkpo.Enabled = True
                        defaultref()
                        secondreftrue()
                        lblpo.Text = "PO#"
                        GroupBox2.Text = "PO"
                        btnattachpo.Text = "ATTACH PO"
                    End If
                Else
                    'ITR auto matic
                    cmbpupadd.Items.Clear()
                    cmbpupadd.Items.Add("")
                    cmbpupadd.SelectedItem = ""
                    defaultref()
                    cmbpick.Text = ""
                    cmbpick.Enabled = False
                    secondreftrue()
                    lblpo.Text = "ITR#"
                    GroupBox2.Text = "ITR"
                    btnattachpo.Text = "ATTACH ITR"
                End If
                '//////////////////////////////////////////////////////////

            ElseIf cmbtype.SelectedItem.ToString.Contains("SALES TRANSACTION") = True Then
                chkso.Enabled = True

                'customer dapat without whse
                If Trim(cmbcus.Text).Contains(" WHSE") = False Or Trim(cmbcus.Text) = "" Then

                Else
                    MsgBox("Invalid recipient. If Recipient is a warehouse, transaction type should be a STOCK TRANSFER.", MsgBoxStyle.Exclamation, "")
                    If cmbtype.SelectedItem.ToString.Contains(" PICKUP") = True Then
                        cmbpick.Enabled = True
                    End If
                    lbltrucking.Text = ""
                    cmbcus.Text = ""
                    cmbcus.Focus()
                    cmbdestin.Text = ""
                    cmbadd.Text = ""
                    'Exit Sub
                End If

                '//////////////////////////////////////////////////////////
                'check kung may pup or wala
                If cmbtype.SelectedItem.ToString.Contains(" PICKUP") = True Then
                    cmbpick.Enabled = True
                    If Trim(cmbpick.Text) = "" Then
                        defaultref()
                        firstreftrue()
                    ElseIf Trim(cmbpick.Text).Contains("AGI ") = True Then
                        'if any AGI (SO AND PO)
                        defaultref()
                        bothreftrue()
                        lblso.Text = "SO#"
                        btnattachso.Text = "ATTACH SO"

                        lblpo.Text = "PO#"
                        GroupBox2.Text = "PO"
                        btnattachpo.Text = "ATTACH PO"
                    Else
                        'any other supplier dapat may (SO)
                        defaultref()
                        firstreftrue()
                        lblso.Text = "SO#"
                        btnattachso.Text = "ATTACH SO"
                    End If
                Else
                    'SO
                    cmbpupadd.Items.Clear()
                    cmbpupadd.Items.Add("")
                    cmbpupadd.SelectedItem = ""
                    defaultref()
                    cmbpick.Text = ""
                    cmbpick.Enabled = False
                    firstreftrue()
                    lblso.Text = "SO#"
                    btnattachso.Text = "ATTACH SO"
                End If

                If cmbtype.SelectedItem.ToString.Contains("CUSTOMER SALES") = True Then
                    chkstuff.Checked = False
                    chkstuff.Enabled = False
                End If
                '//////////////////////////////////////////////////////////

            ElseIf cmbtype.SelectedItem = "JPSC TRUCKING FOR OTHERS PICKUP" Then
                chkso.Enabled = True
                cmbpick.Enabled = True

                'check kung allowed mag trucking sa customer na yun
                Dim ok As Boolean = True, chk As String = ""
                If Trim(cmbcus.Text) <> "" Then
                    sql = "Select area from tblcustomer where status='1' and customer='" & Trim(cmbcus.Text).ToString.Replace("'", "''") & "' and area is not null and area<>''"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        chk = "Trucking only for " & dr("area").ToString
                    Else
                        ok = False
                        MsgBox("Invalid Transaction type. Set to allow JPSC TRUCKING.", MsgBoxStyle.Exclamation, "")
                        cmbtype.SelectedItem = ""
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If

                If ok = True Then
                    If Trim(cmbpick.Text) = "" Then
                        defaultref()
                        txtpo.Text = "0000"
                    Else
                        'any other supplier dapat may (SO) - AR service
                        defaultref()
                        'firstreftrue() -NEED ALISIN COMMENT KUNG MERON NG SO KAPAG TRUCKING - truckingwithSO
                        lblso.Text = "SO#"
                        btnattachso.Text = "ATTACH SO"
                        lbltrucking.Text = chk
                    End If
                End If

            ElseIf cmbtype.SelectedItem = "JPSC TAXI" Then
                cmbpupadd.Items.Clear()
                cmbpupadd.Items.Add("")
                cmbpupadd.SelectedItem = ""
                defaultref()
                txtso.Text = "0000"
                imgbox1.Image = Nothing
                imgbox11.Image = Nothing
                imgbox111.Image = Nothing
                txtpo.Text = "0000"
                imgbox2.Image = Nothing
                imgbox22.Image = Nothing
                imgbox222.Image = Nothing
                grdorders.Rows.Clear()
                grdorders.Rows.Add()
                cmbpick.Text = ""
                cmbpick.Enabled = False
                txtwhse.Text = ""
                chkso.Enabled = False
                chkpo.Checked = False
                chkpo.Enabled = False

                chkstuff.Checked = False
                chkstuff.Enabled = False
            End If

            'check anung reference
            If txtpo.Enabled = True Then
                sql = "Select reference from tblwhse where whsename='" & Trim(cmbpick.Text) & "' and reference is not null"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    lblpo.Text = dr("reference") & "#"
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                If lblpo.Text = "PO#" Then
                    chkpo.Enabled = True
                    chkpo.Checked = False
                Else
                    chkpo.Enabled = False
                    chkpo.Checked = False
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub defaultref()
        lbltrucking.Text = ""

        lblso.Enabled = False
        txtso.Enabled = False
        btnattachso.Enabled = False

        lblpo.Text = "PO#"
        lblpo.Enabled = False
        txtpo.Enabled = False
        btnattachpo.Text = "ATTACH PO"
        btnattachpo.Enabled = False

        chkso.Enabled = False
        chkpo.Checked = False
        chkpo.Enabled = False
        chkstuff.Enabled = True
    End Sub

    Private Sub firstreftrue()
        lblso.Enabled = True
        txtso.Enabled = True
        btnattachso.Enabled = True
        chkso.Enabled = True

        If edittrans = False Then
            txtpo.Text = "0000"
            imgbox2.Image = Nothing
            imgbox22.Image = Nothing
            imgbox222.Image = Nothing
        End If
    End Sub

    Private Sub secondreftrue()
        lblpo.Enabled = True
        txtpo.Enabled = True
        btnattachpo.Enabled = True
        If lblpo.Text = "PO#" Then
            chkpo.Enabled = True
        End If

        If edittrans = False Then
            txtso.Text = "0000"
            imgbox1.Image = Nothing
            imgbox11.Image = Nothing
            imgbox111.Image = Nothing
        End If
    End Sub

    Private Sub bothreftrue()
        lblso.Enabled = True
        txtso.Enabled = True
        btnattachso.Enabled = True
        chkso.Enabled = True
        If lblpo.Text = "PO#" Then
            chkpo.Enabled = True
        End If

        lblpo.Enabled = True
        txtpo.Enabled = True
        btnattachpo.Enabled = True
    End Sub

    Public Sub selecttype()
        Try
            Exit Sub
            If cmbtype.SelectedIndex = 0 Then
                If edittrans = False Then
                    txtso.Text = "0000"
                End If
                lblso.Enabled = False
                txtso.Enabled = False
                btnattachso.Enabled = False

                txtpo.Text = "0000"
                lblpo.Enabled = False
                lblpo.Text = "PO#"
                txtpo.Enabled = False
                btnattachpo.Enabled = False
                btnattachpo.Text = "ATTACH PO"

                cmbpick.Enabled = False
                chkagi.Checked = False
                'chkagi.Enabled = False
                refnum = ""
            Else
                If cmbtype.SelectedItem.ToString.Contains("PICKUP") Then
                    If cmbpick.Text = "" Then
                        'txtso.Text = "0000"
                        lblso.Enabled = False
                        txtso.Enabled = False
                        btnattachso.Enabled = False
                        chkso.Checked = False
                        chkso.Enabled = False

                        'txtpo.Text = "0000"
                        txtpo.Enabled = False
                        lblpo.Enabled = False
                        lblpo.Text = "PO#"
                        btnattachpo.Text = "ATTACH PO"
                        btnattachpo.Enabled = False

                        If cmbtype.SelectedItem.ToString.Contains("SALES TRANSACTION PICKUP") Then
                            If chkoro.Checked = True Then
                                chkoro.Checked = False
                            End If
                            chkoro.Enabled = True

                            If chkmonde.Checked = True Then
                                chkmonde.Checked = False
                            End If
                            chkmonde.Enabled = True
                        Else
                            chkoro.Checked = False
                            chkoro.Enabled = False

                            chkmonde.Checked = False
                            chkmonde.Enabled = False

                            If cmbtype.SelectedItem = "JPSC TRUCKING FOR OTHERS PICKUP" Then
                                'check kung may recipient na nakalagay 
                                'if meron check sa database kung 
                                If edittrans = False Then
                                    txtso.Text = "0000"
                                End If
                                lblso.Enabled = False
                                txtso.Enabled = False
                                btnattachso.Enabled = False

                                If edittrans = False Then
                                    txtpo.Text = "0000"
                                End If
                                lblpo.Enabled = False
                                lblpo.Text = "PO#"
                                txtpo.Enabled = False
                                btnattachpo.Text = "ATTACH PO"
                                btnattachpo.Enabled = False

                                If Trim(cmbcus.Text) <> "" Then
                                    sql = "Select area from tblcustomer where status='1' and customer='" & Trim(cmbcus.Text).ToString.Replace("'", "''") & "' and area is not null and area<>''"
                                    connect()
                                    cmd = New SqlCommand(sql, conn)
                                    dr = cmd.ExecuteReader
                                    If dr.Read Then
                                        MsgBox("Trucking only for " & dr("area").ToString, MsgBoxStyle.Information, "")
                                    Else
                                        MsgBox("Invalid Transaction type. Set to allow JPSC TRUCKING.", MsgBoxStyle.Exclamation, "")
                                        cmbtype.SelectedItem = ""
                                    End If
                                    dr.Dispose()
                                    cmd.Dispose()
                                    conn.Close()
                                End If
                            End If
                        End If

                        cmbpick.Enabled = True
                        refnum = ""
                    Else
                        cmbpick.Enabled = True

                        If cmbtype.SelectedItem = "JPSC TRUCKING FOR OTHERS PICKUP" Then
                            'check kung may recipient na nakalagay 
                            'if meron check sa database kung 
                            If edittrans = False Then
                                txtso.Text = "0000"
                            End If
                            lblso.Enabled = False
                            txtso.Enabled = False
                            btnattachso.Enabled = False

                            If edittrans = False Then
                                txtpo.Text = "0000"
                            End If
                            lblpo.Enabled = False
                            lblpo.Text = "PO#"
                            txtpo.Enabled = False
                            btnattachpo.Text = "ATTACH PO"
                            btnattachpo.Enabled = False

                            If Trim(cmbcus.Text) <> "" Then
                                sql = "Select area from tblcustomer where status='1' and customer='" & Trim(cmbcus.Text).ToString.Replace("'", "''") & "' and area is not null and area<>''"
                                connect()
                                cmd = New SqlCommand(sql, conn)
                                dr = cmd.ExecuteReader
                                If dr.Read Then
                                    MsgBox("Trucking only for " & dr("area").ToString, MsgBoxStyle.Information, "")
                                Else
                                    MsgBox("Invalid Transaction type. Set to allow JPSC TRUCKING.", MsgBoxStyle.Exclamation, "")
                                    cmbtype.SelectedItem = ""
                                End If
                                dr.Dispose()
                                cmd.Dispose()
                                conn.Close()
                            End If
                        End If
                    End If

                Else
                    If edittrans = False Then
                        txtso.Text = "0000"
                    End If
                    lblso.Enabled = False
                    txtso.Enabled = False
                    btnattachso.Enabled = False

                    'txtpo.Text = "0000"
                    lblpo.Enabled = False
                    lblpo.Text = "PO#"
                    txtpo.Enabled = False
                    btnattachpo.Text = "ATTACH PO"
                    btnattachpo.Enabled = False

                    cmbpick.Text = ""
                    cmbpick.Enabled = False
                    chkagi.Checked = False
                    'chkagi.Enabled = False
                    refnum = ""

                    If cmbtype.SelectedItem = "JPSC STOCK TRANSFER WHSE TO WHSE" Then
                        If edittrans = False Then
                            txtso.Text = "0000"
                        End If
                        lblso.Enabled = False
                        txtso.Enabled = False
                        btnattachso.Enabled = False

                        chkso.Checked = False
                        chkso.Enabled = False

                        chkoro.Checked = False
                        chkoro.Enabled = False

                        chkmonde.Checked = False
                        chkmonde.Enabled = False

                        'txtpo.Text = "0000"
                        lblpo.Enabled = True
                        txtpo.Enabled = True
                        btnattachpo.Enabled = True

                        imgbox1.Enabled = False
                        imgbox1.Image = Nothing
                        imgbox2.Enabled = True

                        lblpo.Text = "ITR#"
                        GroupBox2.Text = "ITR"
                        btnattachpo.Text = "ATTACH ITR"

                    ElseIf cmbtype.SelectedItem = "TRUCKING STOCK TRANSFER WHSE TO WHSE" Then
                        If edittrans = False Then
                            txtso.Text = "0000"
                        End If
                        lblso.Enabled = False
                        txtso.Enabled = False
                        btnattachso.Enabled = False

                        chkso.Checked = False
                        chkso.Enabled = False

                        chkoro.Checked = False
                        chkoro.Enabled = False

                        chkmonde.Checked = False
                        chkmonde.Enabled = False

                        'txtpo.Text = "0000"
                        lblpo.Enabled = True
                        txtpo.Enabled = True
                        btnattachpo.Enabled = True

                        imgbox1.Enabled = False
                        imgbox1.Image = Nothing
                        imgbox2.Enabled = True

                        lblpo.Text = "ITR#"
                        GroupBox2.Text = "ITR"
                        btnattachpo.Text = "ATTACH ITR"

                    ElseIf cmbtype.SelectedItem = "JPSC SALES TRANSACTION" Then
                        lblso.Enabled = True
                        txtso.Enabled = True
                        btnattachso.Enabled = True

                        lblpo.Enabled = False
                        txtpo.Enabled = False
                        btnattachpo.Enabled = False

                        If chkso.Checked = True Then
                            chkso.Checked = False
                        End If
                        chkso.Enabled = True

                        If chkoro.Checked = True Then
                            chkoro.Checked = False
                        End If
                        chkoro.Enabled = True

                        If chkmonde.Checked = True Then
                            chkmonde.Checked = False
                        End If
                        chkmonde.Enabled = True

                        imgbox1.Enabled = True
                        imgbox2.Enabled = False
                        imgbox2.Image = Nothing

                        lblpo.Text = "PO#"
                        GroupBox2.Text = "PO"
                        btnattachpo.Text = "ATTACH PO"

                    ElseIf cmbtype.SelectedItem = "CUSTOMER SALES TRANSACTION WHSE" Then
                        lblso.Enabled = True
                        txtso.Enabled = True
                        btnattachso.Enabled = True

                        lblpo.Enabled = False
                        txtpo.Enabled = False
                        btnattachpo.Enabled = False

                        If chkso.Checked = True Then
                            chkso.Checked = False
                        End If
                        chkso.Enabled = True

                        If chkoro.Checked = True Then
                            chkoro.Checked = False
                        End If
                        chkoro.Enabled = True

                        If chkmonde.Checked = True Then
                            chkmonde.Checked = False
                        End If
                        chkmonde.Enabled = True

                        imgbox1.Enabled = True
                        imgbox2.Enabled = False
                        imgbox2.Image = Nothing

                        lblpo.Text = "PO#"
                        GroupBox2.Text = "PO"
                        btnattachpo.Text = "ATTACH PO"

                    ElseIf cmbtype.SelectedItem = "TRUCKING SALES TRANSACTION WHSE" Then
                        lblso.Enabled = True
                        txtso.Enabled = True
                        btnattachso.Enabled = True

                        lblpo.Enabled = False
                        txtpo.Enabled = False
                        btnattachpo.Enabled = False

                        If chkso.Checked = True Then
                            chkso.Checked = False
                        End If
                        chkso.Enabled = True

                        If chkoro.Checked = True Then
                            chkoro.Checked = False
                        End If
                        chkoro.Enabled = True

                        If chkmonde.Checked = True Then
                            chkmonde.Checked = False
                        End If
                        chkmonde.Enabled = True

                        imgbox1.Enabled = True
                        imgbox2.Enabled = False
                        imgbox2.Image = Nothing

                        lblpo.Text = "PO#"
                        GroupBox2.Text = "PO"
                        btnattachpo.Text = "ATTACH PO"
                    End If
                End If

                chkagi.Checked = False
                'chkagi.Enabled = False
                'pickupselect()
            End If
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub cmbpick_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbpick.Leave
        If Not cmbpick.Items.Contains(Trim(cmbpick.Text)) Then
            MsgBox("Invalid supplier name.", MsgBoxStyle.Exclamation, "")
            cmbpick.Focus()
        Else
            If keyEnter = False Then
                If Trim(cmbpick.Text) <> "" Then
                    'check anu whseadd
                    viewpupaddress()
                End If
            End If
        End If
    End Sub
    Private Sub cmbpick_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbpick.SelectedIndexChanged
        'chkagi.Checked = False
        'chkagi.Enabled = False
        'pickupselect()
    End Sub

    Private Sub cmbtype_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbtype.TextChanged
        Exit Sub
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ "
        Dim theText As String = cmbtype.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbtype.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbtype.Text.Length - 1
            Letter = cmbtype.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbtype.Text = theText.ToUpper
        cmbtype.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub cmbpick_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbpick.TextChanged
        Try
            Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ- "
            Dim theText As String = cmbpick.Text
            Dim Letter As String
            Dim SelectionIndex As Integer = cmbpick.SelectionStart
            Dim Change As Integer

            For x As Integer = 0 To cmbpick.Text.Length - 1
                Letter = cmbpick.Text.Substring(x, 1)
                If Not charactersDisallowed.Contains(Letter) Then
                    theText = theText.Replace(Letter, String.Empty)
                    Change = 1
                End If
            Next

            cmbpick.Text = theText.ToUpper
            cmbpick.Select(SelectionIndex - Change, 0)
        Catch ex As Exception

        End Try
    End Sub

    Public Sub whse()
        Try
            cmbpick.Items.Clear()
            cmbpick.Items.Add("")

            sql = "Select * from tblwhse where status='1' and (company='Atlantic Grains' or company='Supplier Warehouse') order by whsename"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbpick.Items.Add(dr("whsename").ToString.ToUpper)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub txtpo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtpo.TextChanged
        Try
            Dim charactersDisallowed As String = "toflwTOFLW1234567890 "
            Dim theText As String = txtpo.Text
            Dim Letter As String
            Dim SelectionIndex As Integer = txtpo.SelectionStart
            Dim Change As Integer

            For x As Integer = 0 To txtpo.Text.Length - 1
                Letter = txtpo.Text.Substring(x, 1)
                If Not charactersDisallowed.Contains(Letter) Then
                    theText = theText.Replace(Letter, String.Empty)
                    Change = 1
                End If
            Next

            txtpo.Text = theText.ToUpper
            txtpo.Select(SelectionIndex - Change, 0)

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnok_Click(sender As Object, e As EventArgs) Handles btnok.Click
        Try
            If txtso.Enabled = True And Trim(txtso.Text) = "TO FOLLOW" And txtpo.Enabled = False And Trim(txtnotes.Text) = "" Then
                MsgBox("Input notes why SO# is TO FOLLOW.", MsgBoxStyle.Exclamation, "")
                txtnotes.Focus()
                Exit Sub
            ElseIf txtpo.Enabled = True And Trim(txtpo.Text) = "TO FOLLOW" And txtso.Enabled = False And Trim(txtnotes.Text) = "" Then
                MsgBox("Input notes why " & lblpo.Text & "# is TO FOLLOW.", MsgBoxStyle.Exclamation, "")
                txtnotes.Focus()
                Exit Sub
            ElseIf txtso.Enabled = True And Trim(txtso.Text) = "TO FOLLOW" And txtpo.Enabled = True And Trim(txtpo.Text) = "TO FOLLOW" And Trim(txtnotes.Text) = "" Then
                MsgBox("Input notes why SO# and " & lblpo.Text & " are TO FOLLOW.", MsgBoxStyle.Exclamation, "")
                txtnotes.Focus()
                Exit Sub
            End If

            If cmbtype.SelectedIndex = 0 Then
                MsgBox("Invalid transaction type.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            Else
                If cmbtype.SelectedItem.ToString.Contains("PICKUP") And Trim(cmbpick.Text) = "" Then
                    MsgBox("Input pick up Warehouse.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
            End If

            If txtso.Enabled = True And Val(txtso.Text) = 0 And txtso.Text.ToString.ToLower.Contains("follow") = False Then
                MsgBox("Input " & lblso.Text & ".", MsgBoxStyle.Exclamation, "")
                Exit Sub
            ElseIf txtpo.Enabled = True And Val(txtpo.Text) = 0 And txtpo.Text.ToString.ToLower.Contains("follow") = False Then
                MsgBox("Input " & lblpo.Text & ".", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            If Trim(cmbcus.Text) = "" Then
                MsgBox("Input recipient.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            'check if kung stock transfer and customer is contains whse
            If cmbtype.SelectedItem.ToString.Contains("STOCK TRANSFER") = True And Not cmbcus.Text.ToString.Contains(" WHSE") Then
                MsgBox("If recipient is not warehouse, transaction type should not be stock transfer.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            ElseIf cmbtype.SelectedItem.ToString.Contains("STOCK TRANSFER") = False And cmbtype.SelectedItem.ToString.Contains("JPSC TAXI") = False And cmbcus.Text.ToString.Contains(" WHSE") = True Then
                MsgBox("If recipient is warehouse, transaction type should be stock transfer.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            lblpoiid.Text = ""
            If cmbtype.SelectedItem.ToString.Contains("CUSTOMER ") = False Then
                If IsDBNull(cmbdestin.Text) = True Then
                    MsgBox("Input drop off.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                ElseIf IsDBNull(cmbadd.text) = True Then
                    MsgBox("Input drop off address.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                ElseIf Trim(cmbdestin.Text) = "" Then
                    MsgBox("Input drop off.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                ElseIf cmbadd.text = "" Then
                    MsgBox("Input drop off address.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                ElseIf Trim(cmbdestin.Text) <> "" And cmbadd.text <> "" Then
                    'check POIid
                    sql = "Select poiid from tblpoi where poiname='" & Trim(cmbdestin.Text.ToString.Replace("'", "''")) & "' and address='" & Trim(cmbadd.Text.ToString.Replace("'", "''")) & "' and status='1'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        lblpoiid.Text = dr("poiid")
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    If lblpoiid.Text = "" Then
                        MsgBox("Input valid drop off and address.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                End If
            Else
                cmbadd.Text = ""
                cmbdestin.Text = ""
            End If

            lblpuppoiid.Text = ""
            If Trim(cmbpick.Text) <> "" Then
                If IsDBNull(cmbpupadd.SelectedItem) = True Then
                    MsgBox("Input valid pickup address.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                ElseIf cmbpupadd.SelectedItem = "" Then
                    MsgBox("Input valid pickup address.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
                'check pup poi
                sql = "select p.poiid "
                sql = sql & " from tblpoi p inner join tblwhsepoi s On p.poiid=s.poiid And s.status='1'"
                sql = sql & " inner join tblwhse w on w.whseid=s.whseid"
                sql = sql & " where w.whsename='" & Trim(cmbpick.Text) & "' and p.address ='" & cmbpupadd.SelectedItem.ToString.Replace("'", "''") & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    lblpuppoiid.Text = dr("poiid")
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                If lblpuppoiid.Text = "" Then
                    MsgBox("Input valid pickup address.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
            End If

            If dateexp.Value < datebook.Value Then
                dateexp.Value = datebook.Value
            End If

            If Trim(cmbcus.Text) <> "" Then
                If chklc.Checked = False Then
                    If btnattachpo.Enabled = True And imgbox2.Image Is Nothing Then
                        MsgBox("Attach " & GroupBox2.Text, MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If

                    If btnattachso.Enabled = True And imgbox1.Image Is Nothing Then
                        MsgBox("Attach " & GroupBox1.Text, MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                End If
            Else
                MsgBox("Complete the required fields.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            'tanggalin ung mga rows na nde kumpleto then
            'if taxi no orders
            If cmbtype.SelectedItem <> "JPSC TAXI" Then
                If Trim(txtwhse.Text) = "" And chklc.Checked = True Then
                    MsgBox("Input SAP whse.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If

                'check if grd has orders
                Dim meronpa As Boolean = True
                If grdorders.RowCount <> 0 Then
                    If grdorders.RowCount = 1 Then
                        If (grdorders.Rows(0).Cells(1).Value Is Nothing Or Val(grdorders.Rows(0).Cells(1).Value) = 0) Then
                            MsgBox("No orders entered. Please check entries.", MsgBoxStyle.Exclamation, "")
                            grdorders.Rows.Clear()
                            grdorders.Rows.Add()
                            Exit Sub
                        End If
                    End If

                    For irow As Integer = 0 To grdorders.RowCount - 1
                        Try
                            While (grdorders.Rows(irow).Cells(1).Value Is Nothing Or Val(grdorders.Rows(irow).Cells(1).Value) = 0)
                                'MsgBox(irow)
                                grdorders.Rows.Remove(grdorders.Rows(irow))
                                grdorders.Refresh()
                                If grdorders.Rows.Count = 0 Then
                                    MsgBox("No orders entered. Please check entries.", MsgBoxStyle.Exclamation, "")
                                    grdorders.Rows.Clear()
                                    grdorders.Rows.Add()
                                    Exit Sub
                                End If
                            End While

                            While (Trim(grdorders.Rows(irow).Cells(0).Value.ToString) = "")
                                'MsgBox(irow)
                                grdorders.Rows.Remove(grdorders.Rows(irow))
                                grdorders.Refresh()
                                If grdorders.Rows.Count = 0 Then
                                    MsgBox("No orders entered. Please check entries.", MsgBoxStyle.Exclamation, "")
                                    grdorders.Rows.Clear()
                                    grdorders.Rows.Add()
                                    Exit Sub
                                End If
                            End While
                        Catch ex As Exception
                            Me.Cursor = Cursors.Default
                            'MsgBox(ex.message & vbcrlf & vbcrlf & ex.stacktrace, MsgBoxStyle.Information)
                            If grdorders.RowCount = 0 Then
                                Exit Sub
                            End If
                        End Try
                    Next
                Else
                    MsgBox("No orders entered. Please check entries.", MsgBoxStyle.Exclamation, "")
                    grdorders.Rows.Clear()
                    grdorders.Rows.Add()
                    Exit Sub
                End If
            Else
                grdorders.Rows.Clear()
            End If

            Dim a As String = MsgBox("Confirmed Order?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
            If a = vbYes Then
                If btnok.Text = "OK" Then
                    savetransaction()
                    chklc.Checked = False
                Else
                    saveedittrans()
                    Me.Dispose()
                    Exit Sub
                End If
                grdorders.Rows.Clear()
                grdorders.Rows.Add()
            End If

        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtnotes_TextChanged(sender As Object, e As EventArgs) Handles txtnotes.TextChanged

    End Sub

    Private Sub chkagi_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkagi.CheckedChanged
        If chkagi.Checked = True Then
            chkso.Checked = False
            chkoro.Checked = False
            chkmonde.Checked = False

            'If edittrans = False Then
            '    txtso.Text = "0000"
            'End If
            'lblso.Enabled = False
            'txtso.Enabled = False

            'If edittrans = False Then
            '    txtpo.Text = "0000"
            'End If
            'lblpo.Enabled = False
            'txtpo.Enabled = False

            'btnattachso.Enabled = False
            'imgbox1.Enabled = False
            'imgbox1.Image = Nothing
            'btnattachpo.Enabled = False
            'imgbox2.Enabled = False
            'imgbox2.Image = Nothing

            'lblpo.Text = "PO#"
            'GroupBox2.Text = "PO"
            'btnattachpo.Text = "ATTACH PO"
        Else
            'If chkso.Checked = False Or chkoro.Checked = False Or chkmonde.Checked = False Then
            '    'pickupselect()
            'End If
        End If
    End Sub

    Private Sub chkmonde_CheckedChanged(sender As Object, e As EventArgs) Handles chkmonde.CheckedChanged
        If chkmonde.Checked = True Then
            chkso.Checked = False
            chkoro.Checked = False
            chkagi.Checked = False

            'chkmonde.Checked = True

            'If edittrans = False Then
            '    txtso.Text = "0000"
            'End If
            'lblso.Enabled = False
            'txtso.Enabled = False

            'If edittrans = False Then
            '    txtpo.Text = "0000"
            'End If
            'lblpo.Enabled = False
            'txtpo.Enabled = False

            'btnattachso.Enabled = False
            'imgbox1.Enabled = False
            'imgbox1.Image = Nothing
            'btnattachpo.Enabled = False
            'imgbox2.Enabled = False
            'imgbox2.Image = Nothing

            'If cmbpick.Text.ToString.Contains("PIER") Then
            '    lblpo.Text = "SWS#"
            '    GroupBox2.Text = "SWS"
            '    btnattachpo.Text = "ATTACH SWS"
            'Else
            '    lblpo.Text = "PO#"
            '    GroupBox2.Text = "PO"
            '    btnattachpo.Text = "ATTACH PO"
            'End If

        Else
            'If chkagi.Checked = False Then
            '    selecttype()
            'End If
        End If
    End Sub

    Private Sub chkso_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkso.CheckedChanged
        If chkso.Checked = True Then
            'If chkagi.Checked = True Or chkoro.Checked = True Or chkmonde.Checked = True Then
            '    chkoro.Checked = False
            '    chkmonde.Checked = False
            '    chkagi.Checked = False
            '    'pickupselect()
            'End If

            chkso.Checked = True

            lblso.Enabled = False
            txtso.Enabled = False
            If edittrans = False Then
                txtso.Text = "0000"
            End If

            btnattachso.Enabled = False
            imgbox1.Enabled = False
            imgbox1.Image = Nothing
        Else
            'If chkagi.Checked = False Then
            '    selecttype()
            'End If
            lblso.Enabled = True
            txtso.Enabled = True
            If edittrans = False Then
                txtso.Text = "0000"
            End If

            btnattachso.Enabled = True
            imgbox1.Enabled = True
        End If
    End Sub

    Private Sub chkprio_CheckedChanged(sender As Object, e As EventArgs) Handles chkprio.CheckedChanged
        If chkprio.Checked = True Then
            Panel5.BackColor = Color.FromArgb(255, 192, 192)
        Else
            Panel5.BackColor = Color.FromArgb(255, 255, 162)
        End If
    End Sub

    Private Sub chkoro_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkoro.CheckedChanged
        If chkoro.Checked = True Then
            chkso.Checked = False
            chkmonde.Checked = False
            chkagi.Checked = False

            'chkoro.Checked = True

            'If edittrans = False Then
            '    txtso.Text = "0000"
            'End If
            'lblso.Enabled = False
            'txtso.Enabled = False

            'If edittrans = False Then
            '    txtpo.Text = "0000"
            'End If
            'lblpo.Enabled = False
            'txtpo.Enabled = False

            'btnattachso.Enabled = False
            'imgbox1.Enabled = False
            'imgbox1.Image = Nothing
            'btnattachpo.Enabled = False
            'imgbox2.Enabled = False
            'imgbox2.Image = Nothing

            'If cmbpick.Text.ToString.Contains("PIER") Then
            '    lblpo.Text = "SWS#"
            '    GroupBox2.Text = "SWS"
            '    btnattachpo.Text = "ATTACH SWS"
            'Else
            '    lblpo.Text = "PO#"
            '    GroupBox2.Text = "PO"
            '    btnattachpo.Text = "ATTACH PO"
            'End If

        Else
            'If chkagi.Checked = False Then
            '    selecttype()
            'End If
        End If
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        If grdorders.Rows.Count > 1 Then
            Dim a As String = MsgBox("Are you sure you want To clear items?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
            If a = vbYes Then
                grdorders.Rows.Clear()
                grdorders.Rows.Add()
            End If
        End If
    End Sub

    Private Sub cmbcus_TextChanged(sender As Object, e As EventArgs) Handles cmbcus.TextChanged
        If cmbcus.DroppedDown = True Then
            cmbcus.DroppedDown = False
            cmbcus.Text = ""
            cmbcus.Focus()
        End If
    End Sub

    Private Sub txtnotes_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtnotes.KeyPress
        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 Then
            If Asc(e.KeyChar) = 39 Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub cmbcus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbcus.SelectedIndexChanged

    End Sub

    Private Sub cmbtype_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbtype.SelectedValueChanged
        'selecttype()
        'pickupselect()
        transactiontype()
    End Sub

    Private Sub cmbdestin_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub cmbadd_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub cmbpick_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbpick.SelectedValueChanged
        If Not cmbpick.Items.Contains(Trim(cmbpick.Text)) Then
            MsgBox("Invalid supplier name.", MsgBoxStyle.Exclamation, "")
            cmbpick.Focus()
            Exit Sub
        Else
            transactiontype()
            If keyEnter = False Then
                If Trim(cmbpick.Text) <> "" Then
                    'check anu whseadd
                    viewpupaddress()
                End If
            End If
        End If
    End Sub

    Private Sub viewpupaddress()
        Try
            cmbpupadd.SelectedItem = ""
            cmbpupadd.Items.Clear()
            cmbpupadd.Items.Add("")
            Dim i As Integer = 0

            sql = "Select g.address "
            sql = sql & " from tblwhse w left outer join tblwhsepoi p On w.whseid=p.whseid And p.status='1'"
            sql = sql & " left outer join tblpoi g On p.poiid=g.poiid"
            sql = sql & " where w.whsename='" & Trim(cmbpick.Text) & "'"
            sql = sql & " group by g.address"
            sql = sql & " having Count(p.poiid) >0"
            sql = sql & " order by g.address"
            connect()
            cmd = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmd.ExecuteReader
            While drx.Read
                cmbpupadd.Items.Add(drx("address"))
                If i = 0 Then
                    cmbpupadd.SelectedItem = drx("address")
                Else
                    cmbpupadd.SelectedItem = ""
                End If
                i += 1
            End While
            drx.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub datebook_ValueChanged(sender As Object, e As EventArgs) Handles datebook.ValueChanged
        dateexp.MinDate = datebook.Value
    End Sub

    Private Sub dateexp_ValueChanged(sender As Object, e As EventArgs) Handles dateexp.ValueChanged

    End Sub

    Private Sub lbltrucking_Click(sender As Object, e As EventArgs) Handles lbltrucking.Click

    End Sub

    Private Sub chklc_CheckedChanged(sender As Object, e As EventArgs) Handles chklc.CheckedChanged

    End Sub

    Private Sub cmbpupadd_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbpupadd.SelectedIndexChanged

    End Sub

    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles Label11.Click

    End Sub

    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click

    End Sub

    Private Sub chkpo_CheckedChanged(sender As Object, e As EventArgs) Handles chkpo.CheckedChanged
        If lblpo.Text = "PO#" Then
            If chkpo.Checked = True Then
                chkpo.Checked = True

                lblpo.Enabled = False
                txtpo.Enabled = False
                If edittrans = False Then
                    txtpo.Text = "0000"
                End If

                btnattachpo.Enabled = False
                imgbox1.Enabled = False
                imgbox1.Image = Nothing
            Else
                'If chkagi.Checked = False Then
                '    selecttype()
                'End If
                lblpo.Enabled = True
                txtpo.Enabled = True
                If edittrans = False Then
                    txtpo.Text = "0000"
                End If

                btnattachpo.Enabled = True
                imgbox1.Enabled = True
            End If
        Else
            lblpo.Enabled = True
            txtpo.Enabled = True
            If edittrans = False Then
                txtpo.Text = "0000"
            End If

            btnattachpo.Enabled = True
            imgbox1.Enabled = True
        End If
    End Sub

    Private Sub btnpoi_Click_1(sender As Object, e As EventArgs) Handles btnpoi.Click
        poiselect.frm = "mainmenucreate"
        poiselect.customer = Trim(cmbcus.Text)
        poiselect.ShowDialog()
    End Sub

    Private Sub chkstuff_CheckedChanged(sender As Object, e As EventArgs) Handles chkstuff.CheckedChanged
        If chkstuff.Checked = True Then
            MsgBox("PIER POI.", MsgBoxStyle.Information, "")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim pupfrm As String = cmbpick.Text.ToString.Substring(0, 4)
        If pupfrm = "AGI " Then
            MsgBox(pupfrm)
        Else
            MsgBox("WRONG")
        End If
    End Sub

    Private Sub txtso_EnabledChanged(sender As Object, e As EventArgs) Handles txtso.EnabledChanged
        If txtso.Enabled = False Then
            txtso.BackColor = Color.FromArgb(255, 224, 192)
            txtso.BorderStyle = BorderStyle.None
        Else
            txtso.BackColor = Color.White
            txtso.BorderStyle = BorderStyle.FixedSingle
        End If
    End Sub

    Private Sub txtpo_EnabledChanged(sender As Object, e As EventArgs) Handles txtpo.EnabledChanged
        If txtpo.Enabled = False Then
            txtpo.BackColor = Color.FromArgb(255, 224, 192)
            txtpo.BorderStyle = BorderStyle.None
        Else
            txtpo.BackColor = Color.White
            txtpo.BorderStyle = BorderStyle.FixedSingle
        End If
    End Sub

    Private Sub grdorders_KeyDown(sender As Object, e As KeyEventArgs) Handles grdorders.KeyDown
        If grdorders.Rows.Count > 0 Then
            If e.KeyCode = Keys.Delete And grdorders.Rows(rowno).Selected = True Then
                'check if may itemcode 
                If grdorders.Rows(rowno).Cells(0).Value = "" Then
                    e.Handled = True
                End If
            End If
        End If
    End Sub
    Dim rowno As Integer
    Private Sub grdorders_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles grdorders.RowHeaderMouseClick
        rowno = e.RowIndex
    End Sub

    Private Sub cmbcus_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbcus.SelectedValueChanged
        'poi()
    End Sub

    Private Sub mainmenucreate_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If threadEnableddestin = True Then
            If backgroundWorkerdestin.IsBusy = True Then
                If backgroundWorkerdestin.WorkerSupportsCancellation = True Then
                    cancelpending = True
                    backgroundWorkerdestin.CancelAsync()
                End If
            End If
        End If

        Me.Dispose()
    End Sub

    Private Sub cmbpick_KeyUp(sender As Object, e As KeyEventArgs) Handles cmbpick.KeyUp
        keyEnter = False
        If e.KeyCode = Keys.Enter Then
            keyEnter = True
            If Trim(cmbpick.Text) <> "" Then
                'check anu whseadd
                viewpupaddress()
            End If
        End If
    End Sub

    Private Sub lbltrucking_TextChanged(sender As Object, e As EventArgs) Handles lbltrucking.TextChanged
        If lbltrucking.Text <> "" Then
            If lbltrucking.Text = "Trucking only for Agi Customer" Then
                chkagi.Checked = True
            ElseIf lbltrucking.Text = "Trucking only for Monde Customer" Then
                chkmonde.Checked = True
            ElseIf lbltrucking.Text = "Trucking only for Oro Allado Customer" Then
                chkoro.Checked = True
            End If
        End If
    End Sub

    Private Sub cmbcus_KeyUp(sender As Object, e As KeyEventArgs) Handles cmbcus.KeyUp
        keyEnter2 = False
        If e.KeyCode = Keys.Enter Then
            keyEnter2 = True
            selectcustomer()
        End If
    End Sub
End Class