﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports Excel = Microsoft.Office.Interop.Excel

Public Class Form2
    Dim lines = System.IO.File.ReadAllLines("connectionstring.txt")
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            sql = "Select * from tbltripsum right outer join tbldispatchstp7 on tbltripsum.tripnum=tbldispatchstp7.tripnum where  tbltripsum.datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and tbltripsum.datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "'"
            'sql = "Select * from tbltripsum  where tbltripsum.status='1' and tbltripsum.datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and tbltripsum.datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                grdpic.Rows.Add(dr("tripnum"), dr("name"), Image.FromStream(ms))
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class