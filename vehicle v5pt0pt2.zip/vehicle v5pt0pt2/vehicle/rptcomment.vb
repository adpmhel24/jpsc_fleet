﻿Imports System.IO
Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports Excel = Microsoft.Office.Interop.Excel

Public Class rptcomment
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Dim SheetList As New ArrayList
    Dim MyConnection As OleDbConnection
    Dim DtSet As System.Data.DataSet
    Dim MyCommand As OleDbDataAdapter
    Dim ii As Integer
    Dim checkBoxColumn As New DataGridViewCheckBoxColumn()
    Dim ds As New DataSet
    Dim dv As DataView

    Dim derrors As Boolean = False
    Public importcnf As Boolean = False

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        grd.Rows.Clear()
        grd.Columns.Clear()

        grd.Columns.Add("1", "Tripnum")
        grd.Columns.Add("2", "comstp")
        grd.Columns.Add("3", "cneymstp")
        grd.Columns.Add("4", "cdeytstp")
        grd.Columns.Add("5", "cstatstp")

        sql = "Select * from tbldispatchsum where "
        If cmb.Text = 1 Then
            sql = sql & " cdeytstp1>='" & Format(dateselected.Value, "yyyy/MM/dd") & "'"
        ElseIf cmb.Text = 2 Then
            sql = sql & " cdeytstp2>='" & Format(dateselected.Value, "yyyy/MM/dd") & "'"
        ElseIf cmb.Text = 3 Then
            sql = sql & " cdeytstp3>='" & Format(dateselected.Value, "yyyy/MM/dd") & "'"
        ElseIf cmb.Text = 4 Then
            sql = sql & " cdeytstp4>='" & Format(dateselected.Value, "yyyy/MM/dd") & "'"
        ElseIf cmb.Text = 5 Then
            sql = sql & " cdeytstp5>='" & Format(dateselected.Value, "yyyy/MM/dd") & "'"
        ElseIf cmb.Text = 6 Then
            sql = sql & " cdeytstp6>='" & Format(dateselected.Value, "yyyy/MM/dd") & "'"
        ElseIf cmb.Text = 7 Then
            sql = sql & " cdeytstp7>='" & Format(dateselected.Value, "yyyy/MM/dd") & "'"
        ElseIf cmb.Text = 8 Then
            sql = sql & " cdeytstp8>='" & Format(dateselected.Value, "yyyy/MM/dd") & "'"
        ElseIf cmb.Text = 9 Then
            sql = sql & " cdeytstp9>='" & Format(dateselected.Value, "yyyy/MM/dd") & "'"
        End If

        connect()
        cmd = New SqlCommand(sql, conn)
        dr = cmd.ExecuteReader
        While dr.Read
            If cmb.Text = 1 Then
                grd.Rows.Add(dr("tripnum"), dr("comstp1"), dr("cneymstp1"), dr("cdeytstp1"), dr("cstatstp1"))
            ElseIf cmb.Text = 2 Then
                grd.Rows.Add(dr("tripnum"), dr("comstp2"), dr("cneymstp2"), dr("cdeytstp2"), dr("cstatstp2"))
            ElseIf cmb.Text = 3 Then
                grd.Rows.Add(dr("tripnum"), dr("comstp3"), dr("cneymstp3"), dr("cdeytstp3"), dr("cstatstp3"))
            ElseIf cmb.Text = 4 Then
                grd.Rows.Add(dr("tripnum"), dr("comstp4"), dr("cneymstp4"), dr("cdeytstp4"), dr("cstatstp4"))
            ElseIf cmb.Text = 5 Then
                grd.Rows.Add(dr("tripnum"), dr("comstp5"), dr("cneymstp5"), dr("cdeytstp5"), dr("cstatstp5"))
            ElseIf cmb.Text = 6 Then
                grd.Rows.Add(dr("tripnum"), dr("comstp6"), dr("cneymstp6"), dr("cdeytstp6"), dr("cstatstp6"))
            ElseIf cmb.Text = 7 Then
                grd.Rows.Add(dr("tripnum"), dr("comstp7"), dr("cneymstp7"), dr("cdeytstp7"), dr("cstatstp7"))
            ElseIf cmb.Text = 8 Then
                grd.Rows.Add(dr("tripnum"), dr("comstp8"), dr("cneymstp8"), dr("cdeytstp8"), dr("cstatstp8"))
            ElseIf cmb.Text = 9 Then
                grd.Rows.Add(dr("tripnum"), dr("comstp9"), dr("cneymstp9"), dr("cdeytstp9"), dr("cstatstp9"))
            End If
        End While
        dr.Dispose()
        cmd.Dispose()
        conn.Close()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try

            For Each row As DataGridViewRow In grd.Rows
                Dim tripnum As String = grd.Rows(row.Index).Cells(0).Value.ToString
                Dim comstp As String = grd.Rows(row.Index).Cells(1).Value.ToString
                Dim cneymstp As String = grd.Rows(row.Index).Cells(2).Value.ToString
                Dim cdeytstp As Date = CDate(Format(grd.Rows(row.Index).Cells(3).Value, "MM/dd/yyyy HH:mm"))
                Dim cstatstp As Integer = Val(grd.Rows(row.Index).Cells(4).Value)


                If cmb.Text = 1 Then
                    sql = "Update tbldispatchsum set comstp1='" & comstp & "', cneymstp1='" & cneymstp & "', cdeytstp1='" & CDate(cdeytstp) & "', cstatstp1='" & cstatstp & "' where tripnum='" & tripnum & "'"
                ElseIf cmb.Text = 2 Then
                    sql = "Update tbldispatchsum set comstp2='" & comstp & "', cneymstp2='" & cneymstp & "', cdeytstp2='" & CDate(cdeytstp) & "', cstatstp2='" & cstatstp & "' where tripnum='" & tripnum & "'"
                ElseIf cmb.Text = 3 Then
                    sql = "Update tbldispatchsum set comstp3='" & comstp & "', cneymstp3='" & cneymstp & "', cdeytstp3='" & CDate(cdeytstp) & "', cstatstp3='" & cstatstp & "' where tripnum='" & tripnum & "'"
                ElseIf cmb.Text = 4 Then
                    sql = "Update tbldispatchsum set comstp4='" & comstp & "', cneymstp4='" & cneymstp & "', cdeytstp4='" & CDate(cdeytstp) & "', cstatstp4='" & cstatstp & "' where tripnum='" & tripnum & "'"
                ElseIf cmb.Text = 5 Then
                    sql = "Update tbldispatchsum set comstp5='" & comstp & "', cneymstp5='" & cneymstp & "', cdeytstp5='" & CDate(cdeytstp) & "', cstatstp5='" & cstatstp & "' where tripnum='" & tripnum & "'"
                ElseIf cmb.Text = 6 Then
                    sql = "Update tbldispatchsum set comstp6='" & comstp & "', cneymstp6='" & cneymstp & "', cdeytstp6='" & CDate(cdeytstp) & "', cstatstp6='" & cstatstp & "' where tripnum='" & tripnum & "'"
                ElseIf cmb.Text = 7 Then
                    sql = "Update tbldispatchsum set comstp7='" & comstp & "', cneymstp7='" & cneymstp & "', cdeytstp7='" & CDate(cdeytstp) & "', cstatstp7='" & cstatstp & "' where tripnum='" & tripnum & "'"
                ElseIf cmb.Text = 8 Then
                    sql = "Update tbldispatchsum set comstp8='" & comstp & "', cneymstp8='" & cneymstp & "', cdeytstp8='" & CDate(cdeytstp) & "', cstatstp8='" & cstatstp & "' where tripnum='" & tripnum & "'"
                ElseIf cmb.Text = 9 Then
                    sql = "Update tbldispatchsum set comstp9='" & comstp & "', cneymstp9='" & cneymstp & "', cdeytstp9='" & CDate(cdeytstp) & "', cstatstp9='" & cstatstp & "' where tripnum='" & tripnum & "'"
                End If

                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()
            Next

            MsgBox("Successfully saved.")

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub rptcomment_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            Dim a As String = MsgBox("Are you sure you want to close?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
            If a = vbYes Then
                DtSet.Clear()
                '/moduless.Show()
                Me.Dispose()
            Else
                e.Cancel = True
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub rptcomment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtPath.Text = ""
        btnLoadData.Enabled = False
        grd.Rows.Clear()
        grd.Columns.Clear()
        DtSet = New System.Data.DataSet
    End Sub

    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        With OpenFileDialog1
            .FileName = "Excel File"
            .Filter = "Excel Worksheets|*.xls;*.xlsx"
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                txtPath.Text = .FileName
                If txtPath.Text <> "" Then
                    btnLoadData.Enabled = True
                    'btnadd.Enabled = False
                Else
                    btnLoadData.Enabled = False
                End If
            End If
        End With
    End Sub

    Private Sub btnLoadData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadData.Click
        DtSet = New System.Data.DataSet
        Dim sheetName As String
        Try
            grd.Columns.Clear()
            MyConnection = New OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0;Data Source='" & txtPath.Text & "';Extended Properties=""Excel 8.0;HDR={1}""")

            Dim objExcel As Excel.Application
            Dim objWorkBook As Excel.Workbook
            Dim objWorkSheets As Excel.Worksheet
            Dim ExcelSheetName As String = ""

            objExcel = CreateObject("Excel.Application")
            objWorkBook = objExcel.Workbooks.Open(txtPath.Text)

            For Each objWorkSheets In objWorkBook.Worksheets
                SheetList.Add(objWorkSheets.Name)
            Next

            MyCommand = New OleDbDataAdapter("select * from [" & SheetList(0) & "$]", MyConnection)
            MyCommand.TableMappings.Add("Table", "Net-informations.com")
            'MsgBox(SheetList(0).ToString)

            MyCommand.Fill(DtSet)
            grd.DataSource = DtSet.Tables(0)
            ' MyCommand.Dispose()
            MyConnection.Close()

            objWorkBook.Close()
            objExcel.Quit()

            releaseObject(objWorkBook)
            releaseObject(objExcel)

            Me.Cursor = Cursors.Default

            grd.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True
            'grd.ColumnHeadersHeight = 40
            grd.Columns(0).Width = 150
            grd.Columns(1).Width = 150
            grd.Columns(2).Width = 300

            derrors = False

            'remember: sa price kung nde sya numeric di sya iloload

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " + ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub
End Class