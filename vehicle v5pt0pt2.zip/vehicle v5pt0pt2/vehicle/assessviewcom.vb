﻿Imports System.Data.SqlClient
Public Class assessviewcom
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand
    Public cnf As Boolean

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Private Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub
    Private Sub assessviewcom_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Me.Dispose()
    End Sub

    Private Sub assessviewcom_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btncreate_Click(sender As Object, e As EventArgs) Handles btncreate.Click
        cnf = False
        confirmsave.GroupBox1.Text = login.neym
        confirmsave.ShowDialog()
        If cnf = True Then
            ExecuteAdd(strconn)
        End If
    End Sub
    Private Sub ExecuteAdd(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                sql = "Insert into tblassesscom (aid,comment,comby,datecom) values"
                sql = sql & " ('" & assessall.grd.Rows(assessall.grd.CurrentRow.Index).Cells("aid").Value & "','" & Trim(txtcom.Text.Replace("'", "''")) & "','" & login.cashier & "',GetDate())"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                assessall.viewcomms(assessall.grd.Rows(assessall.grd.CurrentRow.Index).Cells("aid").Value)
                txtcom.Text = ""

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
            End Try
        End Using
    End Sub
End Class