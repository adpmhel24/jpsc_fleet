﻿Imports System.IO
Imports System.Data.SqlClient

Public Class assessadd
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand
    Public cnf As Boolean

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Private Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub assessadd_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        selectneym()
    End Sub

    Private Sub selectneym()
        Try
            sql = "Select fullname from tblusers where username='" & viewsteps.lblfinishby.Text & "' and whsename='" & login.whse & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                list1.Items.Add(dr("fullname"))
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncreate_Click(sender As Object, e As EventArgs) Handles btncreate.Click
        Try
            If list1.Items.Count = 0 Then
                MsgBox("Add employee.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            ElseIf Trim(txtcom.text) = "" Then
                MsgBox("Input logistics' comment.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            ElseIf Trim(txtsub.text) = "" Then
                MsgBox("Select subject.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            Else
                cnf = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If cnf = True Then
                    If btncreate.Text = "Create" Then
                        ExecuteCreate(strconn)
                    Else

                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteCreate(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                Dim trnum As String = "1", temp As String = "", ctrnum As String = ""

                command.CommandText = "Select Count(aid) from tblassess where ayear=Year(GetDate()) and whsename='" & login.whse & "'"
                trnum = command.ExecuteScalar + 1

                Dim prefix As String = ""
                sql = "Select whsecode from tblwhse where whsename='" & login.whse & "' and status='1'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    prefix = dr("whsecode")
                End If
                dr.Dispose()

                If trnum < 10000 Then
                    For vv As Integer = 1 To 4 - trnum.Length
                        temp += "0"
                    Next
                End If

                ctrnum = "A." & prefix & "-" & Format(Date.Now, "yy") & "-" & temp & trnum

                sql = "Insert into tblassess (ayear,ctrnum,tripnum,acid,createdby,datecreated,modifiedby,datemodified,status,whsename) values"
                sql = sql & " (Year(GetDate()),'" & ctrnum & "','" & txttrip.Text & "','" & txtsub.Tag & "','" & login.cashier & "',GetDate(),'" & login.cashier & "',GetDate(),'0','" & login.whse & "')"
                command.CommandText = sql
                command.ExecuteNonQuery()

                sql = "Insert into tblassesscom (aid,comment,comby,datecom) values"
                sql = sql & " ((Select top 1 aid from tblassess order by aid DESC),'" & Trim(txtcom.Text.Replace("'", "''")) & "','" & login.cashier & "',GetDate())"
                command.CommandText = sql
                command.ExecuteNonQuery()

                For i = 0 To list1.Items.Count - 1
                    sql = "Insert into tblassessemp (aid,userid,dateadded,addedby,status) values"
                    sql = sql & " ((Select top 1 aid from tblassess order by aid DESC),"
                    sql = sql & " (Select systemid from tblusers where fullname='" & list1.Items(i) & "'),GetDate(),'" & login.cashier & "','1')"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                Next

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully created.", MsgBoxStyle.Information, "")
                assessall.view(txttrip.Text)
                Me.Dispose()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
            End Try
        End Using
    End Sub

    Private Sub btncat_Click(sender As Object, e As EventArgs) Handles btncat.Click
        assessviewcat.frm = "assessadd"
        assessviewcat.ShowDialog()
    End Sub

    Private Sub linkadd_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles linkadd.LinkClicked
        assessviewemp.frm = "assessadd"
        assessviewemp.ShowDialog()
    End Sub

    Private Sub assessadd_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Me.Dispose()
    End Sub

    Private Sub list1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles list1.SelectedIndexChanged

    End Sub

    Private Sub list1_KeyDown(sender As Object, e As KeyEventArgs) Handles list1.KeyDown
        If e.KeyCode = Keys.Delete AndAlso list1.SelectedItem <> Nothing Then
            list1.Items.RemoveAt(list1.SelectedIndex)
        End If
    End Sub

End Class