﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mdiform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mdiform))
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.logouttool = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VehicleTypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BodyTypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MakeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SupplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PMServiceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RepairServicesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfPartsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateMoreVehicleDocumentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportExcelToAddMoreVehiclesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportExcelToUpdateVehicleParametersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfCompanyToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfVehicleTypeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfBodyTypeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfWarehouseToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfMakeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfSupplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfDocumentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfPMServicesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VehicleGeneralInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VehicleNotificationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VehicleStatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VehicleChangeOilToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackupDatabasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SampToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.SetupToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.ReportsToolStripMenuItem, Me.BackupToolStripMenuItem})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(1274, 24)
        Me.MenuStrip2.TabIndex = 20
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.logouttool})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'logouttool
        '
        Me.logouttool.Image = CType(resources.GetObject("logouttool.Image"), System.Drawing.Image)
        Me.logouttool.Name = "logouttool"
        Me.logouttool.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.F4), System.Windows.Forms.Keys)
        Me.logouttool.Size = New System.Drawing.Size(154, 22)
        Me.logouttool.Text = "Logout"
        '
        'SetupToolStripMenuItem
        '
        Me.SetupToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VehicleTypeToolStripMenuItem, Me.BodyTypeToolStripMenuItem, Me.MakeToolStripMenuItem, Me.SupplierToolStripMenuItem, Me.PMServiceToolStripMenuItem, Me.RepairServicesToolStripMenuItem, Me.ListOfPartsToolStripMenuItem})
        Me.SetupToolStripMenuItem.Name = "SetupToolStripMenuItem"
        Me.SetupToolStripMenuItem.Size = New System.Drawing.Size(49, 20)
        Me.SetupToolStripMenuItem.Text = "Setup"
        '
        'VehicleTypeToolStripMenuItem
        '
        Me.VehicleTypeToolStripMenuItem.Image = CType(resources.GetObject("VehicleTypeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleTypeToolStripMenuItem.Name = "VehicleTypeToolStripMenuItem"
        Me.VehicleTypeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.VehicleTypeToolStripMenuItem.Text = "Vehicle Type"
        '
        'BodyTypeToolStripMenuItem
        '
        Me.BodyTypeToolStripMenuItem.Image = CType(resources.GetObject("BodyTypeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BodyTypeToolStripMenuItem.Name = "BodyTypeToolStripMenuItem"
        Me.BodyTypeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.BodyTypeToolStripMenuItem.Text = "Body Type"
        '
        'MakeToolStripMenuItem
        '
        Me.MakeToolStripMenuItem.Image = CType(resources.GetObject("MakeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MakeToolStripMenuItem.Name = "MakeToolStripMenuItem"
        Me.MakeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.MakeToolStripMenuItem.Text = "Make"
        '
        'SupplierToolStripMenuItem
        '
        Me.SupplierToolStripMenuItem.Image = CType(resources.GetObject("SupplierToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SupplierToolStripMenuItem.Name = "SupplierToolStripMenuItem"
        Me.SupplierToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SupplierToolStripMenuItem.Text = "Supplier"
        '
        'PMServiceToolStripMenuItem
        '
        Me.PMServiceToolStripMenuItem.Image = CType(resources.GetObject("PMServiceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PMServiceToolStripMenuItem.Name = "PMServiceToolStripMenuItem"
        Me.PMServiceToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.PMServiceToolStripMenuItem.Text = "PM Service"
        '
        'RepairServicesToolStripMenuItem
        '
        Me.RepairServicesToolStripMenuItem.Image = CType(resources.GetObject("RepairServicesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RepairServicesToolStripMenuItem.Name = "RepairServicesToolStripMenuItem"
        Me.RepairServicesToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.RepairServicesToolStripMenuItem.Text = "Repair Services"
        Me.RepairServicesToolStripMenuItem.Visible = False
        '
        'ListOfPartsToolStripMenuItem
        '
        Me.ListOfPartsToolStripMenuItem.Image = CType(resources.GetObject("ListOfPartsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ListOfPartsToolStripMenuItem.Name = "ListOfPartsToolStripMenuItem"
        Me.ListOfPartsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ListOfPartsToolStripMenuItem.Text = "Vehicle Parts"
        Me.ListOfPartsToolStripMenuItem.Visible = False
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UpdateMoreVehicleDocumentToolStripMenuItem, Me.ImportExcelToAddMoreVehiclesToolStripMenuItem, Me.ImportExcelToUpdateVehicleParametersToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(56, 20)
        Me.ToolsToolStripMenuItem.Text = "Vehicle"
        '
        'UpdateMoreVehicleDocumentToolStripMenuItem
        '
        Me.UpdateMoreVehicleDocumentToolStripMenuItem.Image = CType(resources.GetObject("UpdateMoreVehicleDocumentToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UpdateMoreVehicleDocumentToolStripMenuItem.Name = "UpdateMoreVehicleDocumentToolStripMenuItem"
        Me.UpdateMoreVehicleDocumentToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
        Me.UpdateMoreVehicleDocumentToolStripMenuItem.Text = "Update More Vehicle Document"
        '
        'ImportExcelToAddMoreVehiclesToolStripMenuItem
        '
        Me.ImportExcelToAddMoreVehiclesToolStripMenuItem.Image = CType(resources.GetObject("ImportExcelToAddMoreVehiclesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ImportExcelToAddMoreVehiclesToolStripMenuItem.Name = "ImportExcelToAddMoreVehiclesToolStripMenuItem"
        Me.ImportExcelToAddMoreVehiclesToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
        Me.ImportExcelToAddMoreVehiclesToolStripMenuItem.Text = "Import Excel to Add More Vehicles"
        '
        'ImportExcelToUpdateVehicleParametersToolStripMenuItem
        '
        Me.ImportExcelToUpdateVehicleParametersToolStripMenuItem.Image = CType(resources.GetObject("ImportExcelToUpdateVehicleParametersToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ImportExcelToUpdateVehicleParametersToolStripMenuItem.Name = "ImportExcelToUpdateVehicleParametersToolStripMenuItem"
        Me.ImportExcelToUpdateVehicleParametersToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
        Me.ImportExcelToUpdateVehicleParametersToolStripMenuItem.Text = "Import Excel to Update Vehicle Parameters"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListToolStripMenuItem, Me.VehicleGeneralInformationToolStripMenuItem, Me.VehicleNotificationToolStripMenuItem, Me.VehicleStatusToolStripMenuItem, Me.VehicleChangeOilToolStripMenuItem})
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.ReportsToolStripMenuItem.Text = "Reports"
        '
        'ListToolStripMenuItem
        '
        Me.ListToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListOfCompanyToolStripMenuItem1, Me.ListOfVehicleTypeToolStripMenuItem1, Me.ListOfBodyTypeToolStripMenuItem1, Me.ListOfWarehouseToolStripMenuItem1, Me.ListOfMakeToolStripMenuItem, Me.ListOfSupplierToolStripMenuItem, Me.ListOfDocumentToolStripMenuItem, Me.ListOfPMServicesToolStripMenuItem})
        Me.ListToolStripMenuItem.Image = CType(resources.GetObject("ListToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ListToolStripMenuItem.Name = "ListToolStripMenuItem"
        Me.ListToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.ListToolStripMenuItem.Text = "List"
        '
        'ListOfCompanyToolStripMenuItem1
        '
        Me.ListOfCompanyToolStripMenuItem1.Name = "ListOfCompanyToolStripMenuItem1"
        Me.ListOfCompanyToolStripMenuItem1.Size = New System.Drawing.Size(173, 22)
        Me.ListOfCompanyToolStripMenuItem1.Text = "List of Company"
        '
        'ListOfVehicleTypeToolStripMenuItem1
        '
        Me.ListOfVehicleTypeToolStripMenuItem1.Name = "ListOfVehicleTypeToolStripMenuItem1"
        Me.ListOfVehicleTypeToolStripMenuItem1.Size = New System.Drawing.Size(173, 22)
        Me.ListOfVehicleTypeToolStripMenuItem1.Text = "List of Vehicle Type"
        '
        'ListOfBodyTypeToolStripMenuItem1
        '
        Me.ListOfBodyTypeToolStripMenuItem1.Name = "ListOfBodyTypeToolStripMenuItem1"
        Me.ListOfBodyTypeToolStripMenuItem1.Size = New System.Drawing.Size(173, 22)
        Me.ListOfBodyTypeToolStripMenuItem1.Text = "List of Body Type"
        '
        'ListOfWarehouseToolStripMenuItem1
        '
        Me.ListOfWarehouseToolStripMenuItem1.Name = "ListOfWarehouseToolStripMenuItem1"
        Me.ListOfWarehouseToolStripMenuItem1.Size = New System.Drawing.Size(173, 22)
        Me.ListOfWarehouseToolStripMenuItem1.Text = "List of Warehouse"
        '
        'ListOfMakeToolStripMenuItem
        '
        Me.ListOfMakeToolStripMenuItem.Name = "ListOfMakeToolStripMenuItem"
        Me.ListOfMakeToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.ListOfMakeToolStripMenuItem.Text = "List of Make"
        '
        'ListOfSupplierToolStripMenuItem
        '
        Me.ListOfSupplierToolStripMenuItem.Name = "ListOfSupplierToolStripMenuItem"
        Me.ListOfSupplierToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.ListOfSupplierToolStripMenuItem.Text = "List of Supplier"
        '
        'ListOfDocumentToolStripMenuItem
        '
        Me.ListOfDocumentToolStripMenuItem.Name = "ListOfDocumentToolStripMenuItem"
        Me.ListOfDocumentToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.ListOfDocumentToolStripMenuItem.Text = "List of Document"
        '
        'ListOfPMServicesToolStripMenuItem
        '
        Me.ListOfPMServicesToolStripMenuItem.Name = "ListOfPMServicesToolStripMenuItem"
        Me.ListOfPMServicesToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.ListOfPMServicesToolStripMenuItem.Text = "List of PM Services"
        '
        'VehicleGeneralInformationToolStripMenuItem
        '
        Me.VehicleGeneralInformationToolStripMenuItem.Image = CType(resources.GetObject("VehicleGeneralInformationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleGeneralInformationToolStripMenuItem.Name = "VehicleGeneralInformationToolStripMenuItem"
        Me.VehicleGeneralInformationToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.VehicleGeneralInformationToolStripMenuItem.Text = "Vehicle Information"
        '
        'VehicleNotificationToolStripMenuItem
        '
        Me.VehicleNotificationToolStripMenuItem.Image = CType(resources.GetObject("VehicleNotificationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleNotificationToolStripMenuItem.Name = "VehicleNotificationToolStripMenuItem"
        Me.VehicleNotificationToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.VehicleNotificationToolStripMenuItem.Text = "Vehicle Notification"
        '
        'VehicleStatusToolStripMenuItem
        '
        Me.VehicleStatusToolStripMenuItem.Image = CType(resources.GetObject("VehicleStatusToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleStatusToolStripMenuItem.Name = "VehicleStatusToolStripMenuItem"
        Me.VehicleStatusToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.VehicleStatusToolStripMenuItem.Text = "Vehicle Status"
        '
        'VehicleChangeOilToolStripMenuItem
        '
        Me.VehicleChangeOilToolStripMenuItem.Image = CType(resources.GetObject("VehicleChangeOilToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleChangeOilToolStripMenuItem.Name = "VehicleChangeOilToolStripMenuItem"
        Me.VehicleChangeOilToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.VehicleChangeOilToolStripMenuItem.Text = "Vehicle Change Oil"
        '
        'BackupToolStripMenuItem
        '
        Me.BackupToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackupDatabasToolStripMenuItem, Me.SampToolStripMenuItem})
        Me.BackupToolStripMenuItem.Name = "BackupToolStripMenuItem"
        Me.BackupToolStripMenuItem.Size = New System.Drawing.Size(58, 20)
        Me.BackupToolStripMenuItem.Text = "Backup"
        '
        'BackupDatabasToolStripMenuItem
        '
        Me.BackupDatabasToolStripMenuItem.Name = "BackupDatabasToolStripMenuItem"
        Me.BackupDatabasToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.BackupDatabasToolStripMenuItem.Text = "Backup Database"
        '
        'SampToolStripMenuItem
        '
        Me.SampToolStripMenuItem.Name = "SampToolStripMenuItem"
        Me.SampToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.SampToolStripMenuItem.Text = "samp"
        '
        'mdiform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(1274, 671)
        Me.Controls.Add(Me.MenuStrip2)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip2
        Me.Name = "mdiform"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Fleet Management System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip2 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents logouttool As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleTypeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MakeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BodyTypeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateMoreVehicleDocumentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportExcelToAddMoreVehiclesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PMServiceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfCompanyToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfVehicleTypeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfBodyTypeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfWarehouseToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfMakeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfSupplierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfDocumentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfPMServicesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleNotificationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RepairServicesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfPartsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleStatusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleGeneralInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackupDatabasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportExcelToUpdateVehicleParametersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleChangeOilToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SampToolStripMenuItem As ToolStripMenuItem
End Class
