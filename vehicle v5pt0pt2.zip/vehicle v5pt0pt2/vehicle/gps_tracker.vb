﻿Public Class gps_tracker
    Public Property success As Boolean
    Public Property list As List(Of List_tracker)

    Public Class Source
        Public Property id As Integer
        Public Property device_id As String
        Public Property model As String
        Public Property blocked As Boolean
        Public Property tariff_id As Integer
        Public Property phone As String
        Public Property status_listing_id As Integer?
        Public Property creation_date As String
        Public Property tariff_end_date As String
    End Class

    Public Class TagBinding
        Public Property tag_id As Integer
        Public Property ordinal As Integer
    End Class

    Public Class List_tracker
        Public Property id As Integer
        Public Property label As String
        Public Property group_id As Integer
        Public Property source As Source
        Public Property tag_bindings As List(Of TagBinding)
        Public Property clone As Boolean
    End Class

End Class
