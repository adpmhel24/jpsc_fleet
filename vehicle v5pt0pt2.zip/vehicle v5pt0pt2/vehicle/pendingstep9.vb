﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Windows.Forms
Imports CrystalDecisions.ReportSource
Imports System.Drawing.Printing
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.ComponentModel

Public Class pendingstep9
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand, logwhse As String

    Private backgroundWorkerdestin As BackgroundWorker, threadEnableddestin As Boolean
    Private bgw As BackgroundWorker, threadEnabledbgw As Boolean

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub pendingstep9_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        logwhse = login.whse
    End Sub
    Private Sub viewwhse9()
        Try
            cmbwhse9.Items.Clear()
            cmbwhse9.Items.Add("All")
            cmbwhse9.Items.Add("LC Accounting Staff")
            cmbwhse9.Items.Add("AGI Accounting Staff")
            cmbwhse9.Items.Add("via Shipping Lines")

            sql = "Select whsename from tblwhse where status='1' and company='J. Poon & Sons' order by whsename"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbwhse9.Items.Add(dr("whsename"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub count()
        lblcount.Text = grd.Rows.Count.ToString("n2")
    End Sub

    Private Sub backgroundWorkerdestin_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnableddestin = True

        'destination
        For Each row As DataGridViewRow In grd.Rows
            If backgroundWorkerdestin.CancellationPending = True Then
                e.Cancel = True
                Exit For
            Else
                Dim temp As String = "", temptype As String = "", temp2 As String = "", temptype2 As String = "", taxides As String = ""

                'sql = "Select distinct o.customer,o.transtype,i.steady, i.alreadydisp, s.remarks FROM tbltripsum s"
                'sql = sql & " Left OUTER JOIN tbltripitems i ON s.tripnum=i.tripnum and i.status<>'3'"
                'sql = sql & " Left OUTER JOIN tblortrans o on i.transnum=o.transnum"
                'sql = sql & " where s.tripnum ='" & grd.Rows(row.Index).Cells(1).Value & "'"

                'sql = "Select distinct o.transtype,"
                'sql = sql & " (CASE WHEN O.transtype Like '% PICKUP FRM %' and (i.steady=0 or i.steady is null) THEN (SUBSTRING(o.transtype,CHARINDEX('PICKUP FRM ',o.transtype) + 11,LEN(o.transtype)))"
                'sql = sql & " Else '' END) as pup,"
                'sql = sql & " o.customer,i.steady, i.alreadydisp, s.remarks FROM tbltripsum s"
                'sql = sql & " Left OUTER JOIN tbltripitems i ON s.tripnum=i.tripnum And i.status<>'3'"
                'sql = sql & " Left OUTER JOIN tblortrans o on i.transnum=o.transnum"
                'sql = sql & " where s.tripnum ='" & grd.Rows(row.Index).Cells(1).Value & "'"

                sql = "Select distinct "
                sql = sql & " Cast((CASE WHEN o.pupid is not null and (i.steady=0 or i.steady is null) THEN w.whsename"
                sql = sql & " Else '' END) as NVARCHAR) as pup,"
                sql = sql & " o.customer,i.steady, i.alreadydisp, s.remarks FROM tbltripsum s"
                sql = sql & " Left OUTER JOIN tbltripitems i ON s.tripnum=i.tripnum And i.status<>'3'"
                sql = sql & " Left OUTER JOIN tblortrans o on i.transnum=o.transnum"
                sql = sql & " left OUTER JOIN tblwhse w on w.whseid=o.pupid"
                sql = sql & " where s.tripnum ='" & grd.Rows(row.Index).Cells(1).Value & "'"
                Dim connection As SqlConnection
                connection = New SqlConnection
                connection.ConnectionString = strconn
                If connection.State <> ConnectionState.Open Then
                    connection.Open()
                End If
                cmd = New SqlCommand(sql, connection)
                Dim dr11x As SqlDataReader = cmd.ExecuteReader
                While dr11x.Read
                    Dim pupwhse As String = dr11x("pup").ToString.ToUpper
                    If IsDBNull(dr11x("customer")) = False Then
                        If IsDBNull(dr11x("alreadydisp")) = True Then
                            If temptype = "" Then
                                temptype = temptype & pupwhse
                            Else
                                If pupwhse <> "" Then
                                    If temptype.Contains(pupwhse) = False Then
                                        temptype = temptype & " / " & pupwhse
                                    End If
                                End If
                            End If

                            If temp = "" Then
                                temp = temp & dr11x("customer")
                            Else
                                temp = temp & " / " & dr11x("customer")
                            End If
                        Else
                            If dr11x("alreadydisp") = 0 Then
                                If temptype = "" Then
                                    temptype = temptype & pupwhse
                                Else
                                    If pupwhse <> "" Then
                                        If temptype.Contains(pupwhse) = False Then
                                            temptype = temptype & " / " & pupwhse
                                        End If
                                    End If
                                End If

                                If temp = "" Then
                                    temp = temp & dr11x("customer")
                                Else
                                    temp = temp & " / " & dr11x("customer")
                                End If

                            Else
                                If temp2 = "" Then
                                    temp2 = temp2 & dr11x("customer")
                                Else
                                    temp2 = temp2 & " / " & dr11x("customer")
                                End If

                                If temptype2 = "" Then
                                    temptype2 = temptype2 & pupwhse
                                Else
                                    If pupwhse <> "" Then
                                        If temptype2.Contains(pupwhse) = False Then
                                            temptype2 = temptype2 & " / " & pupwhse
                                        End If
                                    End If
                                End If
                            End If
                        End If

                    Else
                        taxides = dr11x("remarks")
                    End If
                End While
                dr11x.Dispose()
                cmd.Dispose()
                connection.Close()

                Dim destination As String = ""
                If taxides <> "" Then
                    temp = "Taxi" & " - " & taxides
                    destination = temp
                Else
                    If temptype = "" Then
                        destination = temp
                        If temp2 <> "" Then
                            If temptype2 = "" Then
                                destination = temp & " // " & temp2
                            Else
                                If temp = "" Then
                                    temp = "Taxi"
                                End If
                                destination = temp & " // " & "p/up " & temptype2 & " / " & temp2
                            End If
                        End If
                    Else
                        destination = "p/up " & temptype & " / " & temp
                        If temp2 <> "" Then
                            If temptype2 = "" Then
                                destination = "p/up " & temptype & " / " & temp & " // " & temp2
                            Else
                                destination = "p/up " & temptype & " / " & temp & " // " & "p/up " & temptype2 & " / " & temp2
                            End If
                        End If
                    End If
                End If

                Dim rowin As Object = row.Index
                If grd.InvokeRequired Then
                    destinDGVRow(rowin, destination)
                End If
            End If
        Next
    End Sub

    Delegate Sub destinRowDelegate(ByVal value0 As Object, ByVal value1 As Object)
    Private m_destinRowDelegate As destinRowDelegate

    Private Sub destinDGVRow(ByVal rowin As Integer, ByVal val1 As String)
        If threadEnableddestin = True Then
            If grd.InvokeRequired Then
                grd.BeginInvoke(New destinRowDelegate(AddressOf destinDGVRow), rowin, val1)
            Else
                If grd.Rows.Count > 0 Then
                    If rowin < grd.Rows.Count Then
                        grd.Rows(rowin).Cells(4).Value = val1
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub backgroundWorkerdestin_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        Me.Cursor = Cursors.Default
        'ProgressBar1.Visible = False
        'ProgressBar1.Style = ProgressBarStyle.Blocks
        'lblloading.Visible = False
        'Panel1.Enabled = True
        If e.Error IsNot Nothing Then
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            'MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            count()
        End If
    End Sub

    Private Sub backgroundWorkerdestin_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label3.Text = e.ProgressPercentage.ToString() & "% complete"
    End Sub

    Private Sub grd_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd.CellContentClick

    End Sub

    Private Sub rbtrip_CheckedChanged(sender As Object, e As EventArgs) Handles rbtrip.CheckedChanged

    End Sub

    Private Sub rbtrans_CheckedChanged(sender As Object, e As EventArgs) Handles rbtrans.CheckedChanged

    End Sub

    Private Sub pendingstep9_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If backgroundWorkerdestin.IsBusy = True Then
            If backgroundWorkerdestin.WorkerSupportsCancellation = True Then
                backgroundWorkerdestin.CancelAsync()
            End If
        End If

        If threadEnabledbgw = True Then
            If bgw.IsBusy = True Then
                If bgw.WorkerSupportsCancellation = True Then
                    bgw.CancelAsync()
                End If
            End If
        End If

        Me.Dispose()
    End Sub

    Private Sub pendingstep9_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        If lblstep.Text = "9" Then
            viewwhse9()
            rbtrip.PerformClick()
        End If
    End Sub

    Private Sub rbtrip_Click(sender As Object, e As EventArgs) Handles rbtrip.Click
        Try
            If rbtrip.Checked = True Then
                If threadEnabledbgw = True Then
                    If bgw.IsBusy = True Then
                        If bgw.WorkerSupportsCancellation = True Then
                            bgw.CancelAsync()
                        End If
                    End If
                End If

                grd.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(192, 255, 192)
                grd.Columns(7).Visible = False
                grd.Rows.Clear()

                rbtrip.Enabled = False
                rbtrans.Enabled = True
                cmbwhse9.Enabled = False

                sql = "Select * from vTripNotifStep9"
                sql = sql & " where whsename='" & login.whse & "' and DaysDue>=2 order by DaysDue DESC"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                While dr.Read
                    grd.Rows.Add(dr("tripsumid"), dr("tripnum"), dr("platenum"), dr("driver"), "", dr("confirmed7"), dr("DaysDue"), "")
                End While
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                backgroundWorkerdestin = New BackgroundWorker()
                backgroundWorkerdestin.WorkerSupportsCancellation = True

                If grd.Rows.Count <> 0 Then
                    AddHandler backgroundWorkerdestin.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkerdestin_DoWork)
                    AddHandler backgroundWorkerdestin.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkerdestin_Completed)
                    AddHandler backgroundWorkerdestin.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorkerdestin_ProgressChanged)
                    m_destinRowDelegate = New destinRowDelegate(AddressOf destinDGVRow)

                    If Not backgroundWorkerdestin.IsBusy Then
                        backgroundWorkerdestin.WorkerReportsProgress = True
                        backgroundWorkerdestin.WorkerSupportsCancellation = True
                        backgroundWorkerdestin.RunWorkerAsync() 'start ng select query
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub rbtrans_Click(sender As Object, e As EventArgs) Handles rbtrans.Click
        Try
            If rbtrans.Checked = True Then
                cmbwhse9.SelectedItem = Nothing
                cmbwhse9.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub bgw_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabledbgw = True

        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If
        cmd = New SqlCommand(sql, connection)
        Dim dr11x As SqlDataReader = cmd.ExecuteReader
        While dr11x.Read
            If bgw.CancellationPending = True Then
                e.Cancel = True
                Exit Sub
            Else
                addDGVRow(dr11x("tripsumid"), dr11x("tripnum"), dr11x("platenum"), dr11x("driver"), dr11x("customer"), dr11x("confirmed7"), dr11x("DaysDue"), dr11x("TobeRecordedby"))
            End If
        End While
        dr11x.Dispose()
        cmd.Dispose()
        connection.Close()
    End Sub

    Delegate Sub addRowDelegate(ByVal v0 As Object, ByVal v1 As Object, ByVal v2 As Object, ByVal v3 As Object, ByVal v4 As Object, ByVal v5 As Object, ByVal v6 As Object, ByVal v7 As Object)
    Private m_addRowDelegate As addRowDelegate

    Private Sub cmbwhse9_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbwhse9.SelectedIndexChanged

    End Sub

    Private Sub addDGVRow(ByVal v0 As Object, ByVal v1 As Object, ByVal v2 As Object, ByVal v3 As Object, ByVal v4 As Object, ByVal v5 As Object, ByVal v6 As Object, ByVal v7 As Object)
        If threadEnabledbgw = True Then
            If grd.InvokeRequired Then
                grd.BeginInvoke(New addRowDelegate(AddressOf addDGVRow), v0, v1, v2, v3, v4, v5, v6, v7)
            Else
                grd.Rows.Add(v0, v1, v2, v3, v4, v5, v6, v7)
            End If
        End If
    End Sub

    Private Sub bgw_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        Me.Cursor = Cursors.Default
        If e.Error IsNot Nothing Then
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            'MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            count()
            colorcoding()
        End If
    End Sub

    Private Sub bgw_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label3.Text = e.ProgressPercentage.ToString() & "% complete"
    End Sub

    Private Sub cmbwhse9_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbwhse9.SelectedValueChanged
        Try
            If rbtrans.Checked = True Then
                If threadEnableddestin = True Then
                    If backgroundWorkerdestin.IsBusy = True Then
                        If backgroundWorkerdestin.WorkerSupportsCancellation = True Then
                            backgroundWorkerdestin.CancelAsync()
                        End If
                    End If
                End If

                grd.AlternatingRowsDefaultCellStyle.BackColor = Nothing
                grd.Columns(7).Visible = True
                grd.Rows.Clear()

                rbtrip.Enabled = True
                rbtrans.Enabled = False
                cmbwhse9.Enabled = True

                sql = "Select tripsumid,tripnum,platenum,driver,customer,confirmed7,DaysDue,TobeRecordedby from vTripNotifStep9acc"
                sql = sql & " where whsename='" & logwhse & "' and DaysDue>=2"
                If cmbwhse9.SelectedItem <> "All" Then
                    sql = sql & " and TobeRecordedby='" & cmbwhse9.SelectedItem & "'"
                End If
                sql = sql & " order by DaysDue DESC"

                bgw = New BackgroundWorker()
                bgw.WorkerSupportsCancellation = True

                AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
                AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
                AddHandler bgw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw_ProgressChanged)
                m_addRowDelegate = New addRowDelegate(AddressOf addDGVRow)

                If Not bgw.IsBusy Then
                    bgw.WorkerReportsProgress = True
                    bgw.WorkerSupportsCancellation = True
                    bgw.RunWorkerAsync() 'start ng select query
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub colorcoding()
        Dim temp_trip As String = "", colotag As Color = Color.White
        For Each row As DataGridViewRow In grd.Rows
            If IsDBNull(grd.Rows(row.Index).Cells(1).Value) = False Then
                If temp_trip <> grd.Rows(row.Index).Cells(1).Value Then

                    If colotag = Color.White Then
                        colotag = Color.FromArgb(192, 255, 192)
                    Else
                        colotag = Color.White
                    End If

                    temp_trip = grd.Rows(row.Index).Cells(1).Value
                End If
            End If
            grd.Rows(row.Index).DefaultCellStyle.BackColor = colotag
        Next
    End Sub

    Private Sub grd_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd.CellDoubleClick
        Try
            If e.RowIndex > -1 Then
                If e.ColumnIndex = 1 Then
                    If rbtrip.Checked = True Then
                        Dim tripnum As String = grd.Rows(e.RowIndex).Cells(1).Value
                        Dim plate As String = grd.Rows(e.RowIndex).Cells(2).Value
                        Dim des As String = grd.Rows(e.RowIndex).Cells(4).Value
                        Dim vtype As String = ""

                        sql = "Select vtype from tblgeneral where platenum='" & plate & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            vtype = dr("vtype")
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        viewsteps.lblstep.Text = "9"
                        viewsteps.Text = "View Step9"
                        viewsteps.lbltripnum1.Text = tripnum
                        viewsteps.lblplate1.Text = plate
                        viewsteps.lbltype1.Text = vtype
                        viewsteps.txtdes.Text = "Destination: " & des
                        viewsteps.notfinish()
                        viewsteps.ShowDialog()

                        'If tripdispatch.IsHandleCreated Then
                        '    tripdispatch.Dispose()
                        'End If
                        'tripdispatch.tripstep9()
                        'tripdispatch.txts9.Text = "20-006952"
                        'tripdispatch.selectstep = 9
                        'tripdispatch.MdiParent = mditrip
                        'tripdispatch.Show()
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub
End Class