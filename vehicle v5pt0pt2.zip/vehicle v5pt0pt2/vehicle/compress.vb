﻿Imports System.IO

Public Class compress

    Private Sub compress_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim desired_size As Double = FormattedBytesToBytes(txtDesiredSize.Text)
            If desired_size < 10 Then
                MessageBox.Show("Invalid desired size.", "Invalid Size", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtDesiredSize.Focus()
                Exit Sub
            End If

            If sfdJpeg.ShowDialog() = Windows.Forms.DialogResult.OK Then
                picNew.Image = Nothing
                txtCompressionLevel.Clear()
                txtCompressedSize.Clear()

                Dim file_name As String = sfdJpeg.FileName
                Dim file_size As Long
                For compression_level As Integer = 100 To 10 Step -1
                    ' Save the file into a memory stream.
                    Dim memory_stream As MemoryStream = SaveJpegIntoStream(picOriginal.Image, compression_level)

                    ' See how big it is.
                    file_size = memory_stream.Length
                    If file_size <= desired_size Then
                        ' Display the final size and image.
                        ' Save the file.
                        'My.Computer.FileSystem.WriteAllBytes(file_name, memory_stream.ToArray(), False)
                        Dim ms As New MemoryStream(memory_stream.ToArray())
                        picNew.Image = Image.FromStream(ms)
                        'picNew.Image = LoadImage(file_name)
                        txtCompressionLevel.Text = compression_level
                        txtCompressedSize.Text = FormatBytes(file_size)
                        Exit For
                    End If
                Next compression_level
            End If
        Catch ex As Exception
            MessageBox.Show("Error saving file." & vbCrLf & ex.Message, "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Load a bitmap so it's not locked.
    Private Function LoadImage(ByVal file_name As String) As Bitmap
        Using bm As New Bitmap(file_name)
            Dim bm2 As New Bitmap(bm)
            Return bm2
        End Using
    End Function
End Class