﻿Public Class gps_address
    Public Property success As Boolean
    Public Property value As String
End Class
