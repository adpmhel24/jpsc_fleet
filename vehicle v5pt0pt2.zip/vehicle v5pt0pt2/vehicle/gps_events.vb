﻿Public Class gps_events

    Public Property success As Boolean
    Public Property list As List(Of List_of_events)
    Public Property limit_exceeded As Boolean

    Public Class List_of_events
        Public Property type As String
        Public Property id As Integer
        Public Property [event] As String
        Public Property message As String
        Public Property time As DateTime
        Public Property extra As Extra_events
        Public Property tracker_id As Integer
        Public Property rule_id As Object
        Public Property track_id
        Public Property location As Location_events
        Public Property address As String
        Public Property is_read As Boolean

        Public Class Extra_events
            Public Property place_ids As List(Of Integer)
            Public Property tracker_label As String
        End Class

        Public Class Location_events
            Public Property address As String
            Public Property lat As Double
            Public Property lng As Double
        End Class
    End Class
End Class
