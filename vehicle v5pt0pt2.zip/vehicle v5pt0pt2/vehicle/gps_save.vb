﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Net
Imports System.Net.WebClient
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports System.ComponentModel

Module gps_save
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String
    Dim JsonHash As String = "", JsonTracker As String = "", JsonEvents As String = "", hashstring As String = "", trackerIDstring As String = ""
    Dim account As String = "", password As String = ""
    Dim platenum As String = "", lbltracker As String = "", tripdate As String = "", inspect As String = "", loadtrip As String = "", arrtrip As String = ""
    Private backgroundWorkerdestin As BackgroundWorker, threadEnableddestin As Boolean
    Dim parseTrack As Object

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub MainGps(ByVal tripnum As String)
        account = ""
        password = ""
        platenum = ""
        tripdate = ""
        inspect = ""
        loadtrip = ""
        arrtrip = ""
        hashstring = ""
        trackerIDstring = ""
        lbltracker = ""

        ExecuteViewDetails(strconn, tripnum)
        If account <> "" Then
            hashstring = get_Hash(account, users.Decrypt(password))
        End If

        If hashstring <> "" Then
            trackerIDstring = get_tracker(platenum)
            If trackerIDstring = "" Then
                MsgBox("No GPS Tracker.", MsgBoxStyle.Exclamation, "")
                'save sa tbltripevent 
                ExecuteSaveNoGPS(strconn, tripnum)
            ElseIf inspect = "" And loadtrip = "" Then
                MsgBox("Loading is not yet started.", MsgBoxStyle.Exclamation, "")
            Else
                tripdispatch.JsonEventss = get_eventss()
            End If
        Else
            MsgBox("Could not load.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub ExecuteSaveNoGPS(ByVal connectionString As String, ByVal tripnum As String)
        Try
            sql = "Insert into tbltripevent (tripnum,remarks) values"
            sql = sql & " ('" & tripnum & "','No GPS Tracker.')"
            connect()
            cmd = New SqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub ExecuteViewDetails(ByVal connectionString As String, ByVal tripnum As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                'Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                'details
                sql = "Select g.platenum,g.tracker_id, cast(s.datepick as Date) as datepick, d.startpre, d.startload, d.step3, d.namestp3, d.timedep, d.datestp6"
                sql = sql & " From tblgeneral g right outer Join tbltripsum s on g.platenum=s.platenum"
                sql = sql & " Right outer join tbldispatchsum d on s.tripnum=d.tripnum"
                sql = sql & " Where s.tripnum='" & tripnum & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    If IsDBNull(dr("datestp6")) = False Then
                        'arrival true
                        platenum = dr("platenum")
                        tripdate = Format(dr("datepick"), "yyyy/MM/dd")
                        If IsDBNull(dr("startload")) = False Then
                            inspect = Format(dr("startload"), "yyyy/MM/dd HH:mm:ss")
                            loadtrip = Format(dr("startload"), "yyyy/MM/dd h:mm:ss tt")
                        Else
                            'check inspection if skipped yung step 3
                            If dr("step3") = 1 And dr("namestp3") = "" Then
                                If IsDBNull(dr("startpre")) = False Then
                                    inspect = Format(dr("startpre"), "yyyy/MM/dd HH:mm:ss")
                                End If
                            End If
                        End If
                        inspect = Format(dr("timedep"), "yyyy/MM/dd HH:mm:ss") 'dati sa load lang
                        arrtrip = Format(dr("datestp6"), "yyyy/MM/dd HH:mm:ss")
                    Else
                        MsgBox("Confirm Arrival first.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                End If
                dr.Dispose()


                'account
                sql = "Select account, password From tblgpsaccount Where status ='1'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    account = dr("account")
                    password = dr("password")
                End If
                dr.Dispose()


                ' Attempt to commit the transaction.
                transaction.Commit()
                'Me.Cursor = Cursors.Default

            Catch ex As Exception
                'Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    'Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    'Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Function get_Hash(ByVal account As String, ByVal password As String) As String
        Try
            Dim api_query As String = "https://api.mgps.online/user/auth/?login=" & account & "&password=" & password
            Dim request As WebRequest = WebRequest.Create(api_query)
            request.Credentials = CredentialCache.DefaultCredentials
            Dim response As WebResponse = request.GetResponse()
            'TextBox1.Text = ((CType(response, HttpWebResponse)).StatusDescription) 'OK

            Using dataStream As Stream = response.GetResponseStream()
                Dim reader As StreamReader = New StreamReader(dataStream)
                Dim responseFromServer As String = reader.ReadToEnd()
                'If responseFromServer.Contains(currentversion) Then

                'End If
                JsonHash = (responseFromServer)
            End Using

            response.Close()

            hashstring = Deserializations_Hash(JsonHash)
            Return hashstring
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Function

    Private Function Deserializations_Hash(ByVal json As String) As String
        Try
            ' JsonConvert.DeserializeObject(Of List(Of Receiver))(json)
            ' JsonConvert.DeserializeObject(Of Dictionary(Of String, Receiver))(json)
            ' JsonConvert.DeserializeObject(Of gps_hash)(json)
            'Dim jsonResult = JsonConvert.DeserializeObject(json).ToString()
            Dim ss As String = ""
            Dim parsedObject = JsonConvert.DeserializeObject(Of gps_hash)(json)
            If parsedObject.success = True Then
                ss = parsedObject.hash
            End If

            Return ss
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Function
    Private Function get_tracker(ByVal platenum As String)
        Try
            Dim api_query As String = "https://api.mgps.online/tracker/list?hash=" & hashstring
            Dim request As WebRequest = WebRequest.Create(api_query)
            request.Credentials = CredentialCache.DefaultCredentials
            Dim response As WebResponse = request.GetResponse()
            'Dim okie As String = ((CType(response, HttpWebResponse)).StatusDescription) 'OK

            Using dataStream As Stream = response.GetResponseStream()
                Dim reader As StreamReader = New StreamReader(dataStream)
                Dim responseFromServer As String = reader.ReadToEnd()
                'If responseFromServer.Contains(currentversion) Then

                'End If
                JsonTracker = (responseFromServer)
            End Using

            response.Close()

            trackerIDstring = Deserializations_tracker(JsonTracker, platenum)

            Return trackerIDstring

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Function

    Private Function Deserializations_tracker(ByVal json As String, ByVal platenum As String) As String
        Try
            Dim tracker_id As String = ""
            ' JsonConvert.DeserializeObject(Of List(Of Receiver))(json)
            ' JsonConvert.DeserializeObject(Of Dictionary(Of String, Receiver))(json)
            ' JsonConvert.DeserializeObject(Of gps_hash)(json)
            'Dim jsonResult = JsonConvert.DeserializeObject(json).ToString()
            Dim parsedObject = JsonConvert.DeserializeObject(Of gps_tracker)(json)
            If parsedObject.success = True Then
                For Each num In parsedObject.list
                    If num.label.ToString.Contains(platenum) = True Then
                        tracker_id = num.id
                        lbltracker = num.label
                        Exit For
                    End If
                Next
            End If

            Return tracker_id
            'Return tracker_label
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Function
    Private Function get_eventss() As String
        Try
            Dim xfrom As Date = CDate(inspect)
            Dim xto As Date = CDate(arrtrip)
            Dim dfrom As String = (Format(xfrom, "yyyy-MM-dd"))
            Dim tfrom As String = (Format(xfrom, "HH:mm:ss"))
            Dim dto As String = (Format(xto, "yyyy-MM-dd"))
            Dim tto As String = (Format(xto, "HH:mm:ss"))
            Dim endpt As String = "https://api.mgps.online/history/tracker/list/?trackers=%5B"
            Dim api_query As String = endpt & trackerIDstring & "%5D&from=" & dfrom & "%20" & tfrom & "&to=" & dto & "%20" & tto & "&hash=" & hashstring & "&event=speedup"

            Dim request As WebRequest = WebRequest.Create(api_query)
            request.Credentials = CredentialCache.DefaultCredentials
            Dim response As WebResponse = request.GetResponse()
            'TextBox1.Text = ((CType(response, HttpWebResponse)).StatusDescription)

            Using dataStream As Stream = response.GetResponseStream()
                Dim reader As StreamReader = New StreamReader(dataStream)
                Dim responseFromServer As String = reader.ReadToEnd()
                'If responseFromServer.Contains(currentversion) Then

                'End If
                JsonEvents = (responseFromServer)
            End Using

            response.Close()

            Return JsonEvents

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Function
End Module
