﻿Public Class gps_track

    Public Property success As Boolean
    Public Property list As List(Of List_of_track)
    Public Property limit_exceeded As Boolean

    Public Class Extra
        Public Property place_ids As List(Of Integer)
        Public Property tracker_label As String
    End Class

    Public Class Location
        Public Property address As String
        Public Property lat As Double
        Public Property lng As Double
    End Class

    Public Class List_of_track
        Public Property type As String
        Public Property id As Integer
        Public Property [event] As String
        Public Property message As String
        Public Property time As String
        Public Property extra As Extra
        Public Property tracker_id As Integer
        Public Property rule_id As Integer
        Public Property track_id As Integer
        Public Property location As Location
        Public Property address As String
        Public Property is_read As Boolean
    End Class

End Class
