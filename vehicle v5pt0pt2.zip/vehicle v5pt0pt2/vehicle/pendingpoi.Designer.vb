﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class pendingpoi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(pendingpoi))
        Me.grd = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn37 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tripnum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.platenum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.transnum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cusid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.customer = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.notes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pier = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Column23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.due = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblstep = New System.Windows.Forms.Label()
        Me.lblcount = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.GPSPOIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateGPSPOIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewTripInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.grd, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'grd
        '
        Me.grd.AllowUserToAddRows = False
        Me.grd.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grd.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grd.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grd.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grd.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.grd.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 8.25!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.grd.ColumnHeadersHeight = 20
        Me.grd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.grd.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn37, Me.tripnum, Me.platenum, Me.Column1, Me.transnum, Me.cusid, Me.customer, Me.notes, Me.pier, Me.Column23, Me.due})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Arial", 8.25!)
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.DefaultCellStyle = DataGridViewCellStyle5
        Me.grd.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke
        Me.grd.EnableHeadersVisualStyles = False
        Me.grd.GridColor = System.Drawing.Color.Salmon
        Me.grd.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.grd.Location = New System.Drawing.Point(12, 78)
        Me.grd.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grd.Name = "grd"
        Me.grd.ReadOnly = True
        Me.grd.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Arial", 8.25!)
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.Padding = New System.Windows.Forms.Padding(10)
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.grd.RowHeadersWidth = 10
        Me.grd.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.NullValue = Nothing
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.RowsDefaultCellStyle = DataGridViewCellStyle7
        Me.grd.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grd.Size = New System.Drawing.Size(980, 404)
        Me.grd.TabIndex = 20
        '
        'DataGridViewTextBoxColumn37
        '
        Me.DataGridViewTextBoxColumn37.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn37.Name = "DataGridViewTextBoxColumn37"
        Me.DataGridViewTextBoxColumn37.ReadOnly = True
        Me.DataGridViewTextBoxColumn37.Visible = False
        '
        'tripnum
        '
        Me.tripnum.HeaderText = "Trip #"
        Me.tripnum.MinimumWidth = 50
        Me.tripnum.Name = "tripnum"
        Me.tripnum.ReadOnly = True
        '
        'platenum
        '
        Me.platenum.HeaderText = "Plate #"
        Me.platenum.MinimumWidth = 50
        Me.platenum.Name = "platenum"
        Me.platenum.ReadOnly = True
        '
        'Column1
        '
        Me.Column1.HeaderText = "Driver"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'transnum
        '
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Red
        Me.transnum.DefaultCellStyle = DataGridViewCellStyle3
        Me.transnum.HeaderText = "Transaction#"
        Me.transnum.Name = "transnum"
        Me.transnum.ReadOnly = True
        Me.transnum.Width = 120
        '
        'cusid
        '
        Me.cusid.HeaderText = "cusid"
        Me.cusid.Name = "cusid"
        Me.cusid.ReadOnly = True
        Me.cusid.Visible = False
        '
        'customer
        '
        Me.customer.HeaderText = "Recipient"
        Me.customer.Name = "customer"
        Me.customer.ReadOnly = True
        Me.customer.Width = 160
        '
        'notes
        '
        Me.notes.HeaderText = "Notes"
        Me.notes.Name = "notes"
        Me.notes.ReadOnly = True
        Me.notes.Width = 180
        '
        'pier
        '
        Me.pier.HeaderText = "Stuffing"
        Me.pier.Name = "pier"
        Me.pier.ReadOnly = True
        Me.pier.Width = 50
        '
        'Column23
        '
        DataGridViewCellStyle4.Format = "yyyy/MM/dd HH:mm"
        Me.Column23.DefaultCellStyle = DataGridViewCellStyle4
        Me.Column23.HeaderText = "Date Time Arrival"
        Me.Column23.Name = "Column23"
        Me.Column23.ReadOnly = True
        Me.Column23.Width = 120
        '
        'due
        '
        Me.due.HeaderText = "Days Due"
        Me.due.Name = "due"
        Me.due.ReadOnly = True
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label3.Location = New System.Drawing.Point(86, 36)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(745, 35)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "Update drop off point."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(86, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(173, 16)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "Reminder: Temporary POI"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(68, 61)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 24
        Me.PictureBox1.TabStop = False
        '
        'lblstep
        '
        Me.lblstep.AutoSize = True
        Me.lblstep.Location = New System.Drawing.Point(631, 56)
        Me.lblstep.Name = "lblstep"
        Me.lblstep.Size = New System.Drawing.Size(21, 13)
        Me.lblstep.TabIndex = 23
        Me.lblstep.Text = "poi"
        Me.lblstep.Visible = False
        '
        'lblcount
        '
        Me.lblcount.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblcount.Location = New System.Drawing.Point(672, 491)
        Me.lblcount.Name = "lblcount"
        Me.lblcount.Size = New System.Drawing.Size(320, 23)
        Me.lblcount.TabIndex = 22
        Me.lblcount.Text = "0.00"
        Me.lblcount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 494)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 15)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Count:"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GPSPOIToolStripMenuItem, Me.UpdateGPSPOIToolStripMenuItem, Me.ViewTripInformationToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(188, 70)
        '
        'GPSPOIToolStripMenuItem
        '
        Me.GPSPOIToolStripMenuItem.Image = CType(resources.GetObject("GPSPOIToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GPSPOIToolStripMenuItem.Name = "GPSPOIToolStripMenuItem"
        Me.GPSPOIToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.GPSPOIToolStripMenuItem.Text = "GPS POI"
        '
        'UpdateGPSPOIToolStripMenuItem
        '
        Me.UpdateGPSPOIToolStripMenuItem.Image = CType(resources.GetObject("UpdateGPSPOIToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UpdateGPSPOIToolStripMenuItem.Name = "UpdateGPSPOIToolStripMenuItem"
        Me.UpdateGPSPOIToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.UpdateGPSPOIToolStripMenuItem.Text = "Update Drop off"
        '
        'ViewTripInformationToolStripMenuItem
        '
        Me.ViewTripInformationToolStripMenuItem.Image = CType(resources.GetObject("ViewTripInformationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewTripInformationToolStripMenuItem.Name = "ViewTripInformationToolStripMenuItem"
        Me.ViewTripInformationToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.ViewTripInformationToolStripMenuItem.Text = "View Trip Information"
        '
        'pendingpoi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1004, 518)
        Me.Controls.Add(Me.grd)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblstep)
        Me.Controls.Add(Me.lblcount)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "pendingpoi"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Pending Trip w/ Temporary POI"
        CType(Me.grd, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grd As DataGridView
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblstep As Label
    Friend WithEvents lblcount As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents UpdateGPSPOIToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GPSPOIToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewTripInformationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DataGridViewTextBoxColumn37 As DataGridViewTextBoxColumn
    Friend WithEvents tripnum As DataGridViewTextBoxColumn
    Friend WithEvents platenum As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents transnum As DataGridViewTextBoxColumn
    Friend WithEvents cusid As DataGridViewTextBoxColumn
    Friend WithEvents customer As DataGridViewTextBoxColumn
    Friend WithEvents notes As DataGridViewTextBoxColumn
    Friend WithEvents pier As DataGridViewCheckBoxColumn
    Friend WithEvents Column23 As DataGridViewTextBoxColumn
    Friend WithEvents due As DataGridViewTextBoxColumn
End Class
