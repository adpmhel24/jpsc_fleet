﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Windows.Forms
Imports CrystalDecisions.ReportSource
Imports System.Drawing.Printing
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.ComponentModel

Public Class pendingstep7
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand, logwhse As String

    Private backgroundWorkerdestin As BackgroundWorker, threadEnableddestin As Boolean

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub pendingstep7_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'If lblstep.Text = "7" Then
        '    viewpending7()
        '    count()
        'End If
        logwhse = login.whse
    End Sub

    Private Sub viewpending7()
        Try
            grd.Rows.Clear()

            sql = "Select * from vTripNotifStep7"
            sql = sql & " where whsename='" & login.whse & "' order by Arrival"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grd.Rows.Add(dr("tripsumid"), dr("tripnum"), dr("platenum"), dr("driver"), "", dr("Arrival"), dr("DaysDue"))
                If dr("ViaShip") > 0 Then
                    grd.Rows(grd.Rows.Count - 1).Cells(4).ErrorText = "   W/ Delivery via Shipping Lines"
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            backgroundWorkerdestin = New BackgroundWorker()
            backgroundWorkerdestin.WorkerSupportsCancellation = True

            If grd.Rows.Count <> 0 Then
                AddHandler backgroundWorkerdestin.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkerdestin_DoWork)
                AddHandler backgroundWorkerdestin.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkerdestin_Completed)
                AddHandler backgroundWorkerdestin.ProgressChanged, New ProgressChangedEventHandler(AddressOf backgroundWorkerdestin_ProgressChanged)
                m_destinRowDelegate = New destinRowDelegate(AddressOf destinDGVRow)

                If Not backgroundWorkerdestin.IsBusy Then
                    backgroundWorkerdestin.WorkerReportsProgress = True
                    backgroundWorkerdestin.WorkerSupportsCancellation = True
                    backgroundWorkerdestin.RunWorkerAsync() 'start ng select query
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub count()
        lblcount.Text = grd.Rows.Count.ToString("n2")
    End Sub

    Private Delegate Sub updateProgressDelegate()

    Private Sub updateProgressBar()
        '/ProgressBar1.Visible = True
        '/ProgressBar1.Value = ProgressBar1.Maximum        '/ProgressBar1.Value=
    End Sub

    Private Sub backgroundWorkerdestin_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnableddestin = True
        'Me.Invoke(New updateProgressDelegate(AddressOf updateProgressBar))
        '//dito ilalagay yung select statement
        '/For i As Integer = 1 To 100
        '/backgroundWorker.ReportProgress(i)
        '/System.Threading.Thread.Sleep(100)
        '/Next

        'destination
        For Each row As DataGridViewRow In grd.Rows
            If backgroundWorkerdestin.CancellationPending = True Then
                e.Cancel = True
                Exit For
            Else
                Dim temp As String = "", temptype As String = "", temp2 As String = "", temptype2 As String = "", taxides As String = ""

                'sql = "Select distinct o.customer,o.transtype,i.steady, i.alreadydisp, s.remarks FROM tbltripsum s"
                'sql = sql & " Left OUTER JOIN tbltripitems i ON s.tripnum=i.tripnum and i.status<>'3'"
                'sql = sql & " Left OUTER JOIN tblortrans o on i.transnum=o.transnum"
                'sql = sql & " where s.tripnum ='" & grd.Rows(row.Index).Cells(1).Value & "'"

                'sql = "Select distinct o.transtype,"
                'sql = sql & " (CASE WHEN O.transtype Like '% PICKUP FRM %' and (i.steady=0 or i.steady is null) THEN (SUBSTRING(o.transtype,CHARINDEX('PICKUP FRM ',o.transtype) + 11,LEN(o.transtype)))"
                'sql = sql & " Else '' END) as pup,"
                'sql = sql & " o.customer,i.steady, i.alreadydisp, s.remarks FROM tbltripsum s"
                'sql = sql & " Left OUTER JOIN tbltripitems i ON s.tripnum=i.tripnum And i.status<>'3'"
                'sql = sql & " Left OUTER JOIN tblortrans o on i.transnum=o.transnum"
                'sql = sql & " where s.tripnum ='" & grd.Rows(row.Index).Cells(1).Value & "'"

                sql = "Select distinct "
                sql = sql & " Cast((CASE WHEN o.pupid is not null and (i.steady=0 or i.steady is null) THEN w.whsename"
                sql = sql & " Else '' END) as NVARCHAR) as pup,"
                sql = sql & " o.customer,i.steady, i.alreadydisp, s.remarks FROM tbltripsum s"
                sql = sql & " Left OUTER JOIN tbltripitems i ON s.tripnum=i.tripnum And i.status<>'3'"
                sql = sql & " Left OUTER JOIN tblortrans o on i.transnum=o.transnum"
                sql = sql & " left OUTER JOIN tblwhse w on w.whseid=o.pupid"
                sql = sql & " where s.tripnum ='" & grd.Rows(row.Index).Cells(1).Value & "'"
                Dim connection As SqlConnection
                connection = New SqlConnection
                connection.ConnectionString = strconn
                If connection.State <> ConnectionState.Open Then
                    connection.Open()
                End If
                cmd = New SqlCommand(sql, connection)
                Dim dr11x As SqlDataReader = cmd.ExecuteReader
                While dr11x.Read
                    Dim pupwhse As String = dr11x("pup").ToString.ToUpper
                    If IsDBNull(dr11x("customer")) = False Then
                        If IsDBNull(dr11x("alreadydisp")) = True Then
                            If temptype = "" Then
                                temptype = temptype & pupwhse
                            Else
                                If pupwhse <> "" Then
                                    If temptype.Contains(pupwhse) = False Then
                                        temptype = temptype & " / " & pupwhse
                                    End If
                                End If
                            End If

                            If temp = "" Then
                                temp = temp & dr11x("customer")
                            Else
                                temp = temp & " / " & dr11x("customer")
                            End If
                        Else
                            If dr11x("alreadydisp") = 0 Then
                                If temptype = "" Then
                                    temptype = temptype & pupwhse
                                Else
                                    If pupwhse <> "" Then
                                        If temptype.Contains(pupwhse) = False Then
                                            temptype = temptype & " / " & pupwhse
                                        End If
                                    End If
                                End If

                                If temp = "" Then
                                    temp = temp & dr11x("customer")
                                Else
                                    temp = temp & " / " & dr11x("customer")
                                End If

                            Else
                                If temp2 = "" Then
                                    temp2 = temp2 & dr11x("customer")
                                Else
                                    temp2 = temp2 & " / " & dr11x("customer")
                                End If

                                If temptype2 = "" Then
                                    temptype2 = temptype2 & pupwhse
                                Else
                                    If pupwhse <> "" Then
                                        If temptype2.Contains(pupwhse) = False Then
                                            temptype2 = temptype2 & " / " & pupwhse
                                        End If
                                    End If
                                End If
                            End If
                        End If

                    Else
                        taxides = dr11x("remarks")
                    End If
                End While
                dr11x.Dispose()
                cmd.Dispose()
                connection.Close()

                Dim destination As String = ""
                If taxides <> "" Then
                    temp = "Taxi" & " - " & taxides
                    destination = temp
                Else
                    If temptype = "" Then
                        destination = temp
                        If temp2 <> "" Then
                            If temptype2 = "" Then
                                destination = temp & " // " & temp2
                            Else
                                If temp = "" Then
                                    temp = "Taxi"
                                End If
                                destination = temp & " // " & "p/up " & temptype2 & " / " & temp2
                            End If
                        End If
                    Else
                        destination = "p/up " & temptype & " / " & temp
                        If temp2 <> "" Then
                            If temptype2 = "" Then
                                destination = "p/up " & temptype & " / " & temp & " // " & temp2
                            Else
                                destination = "p/up " & temptype & " / " & temp & " // " & "p/up " & temptype2 & " / " & temp2
                            End If
                        End If
                    End If
                End If

                Dim rowin As Object = row.Index
                If grd.InvokeRequired Then
                    destinDGVRow(rowin, destination)
                End If
            End If
        Next
    End Sub

    Delegate Sub destinRowDelegate(ByVal value0 As Object, ByVal value1 As Object)
    Private m_destinRowDelegate As destinRowDelegate

    Private Sub destinDGVRow(ByVal rowin As Integer, ByVal val1 As String)
        If threadEnableddestin = True Then
            If grd.InvokeRequired Then
                grd.BeginInvoke(New destinRowDelegate(AddressOf destinDGVRow), rowin, val1)
            Else
                grd.Rows(rowin).Cells(4).Value = val1
            End If
        End If
    End Sub

    Private Sub backgroundWorkerdestin_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        Me.Cursor = Cursors.Default
        'ProgressBar1.Visible = False
        'ProgressBar1.Style = ProgressBarStyle.Blocks
        'lblloading.Visible = False
        'Panel1.Enabled = True
        If e.Error IsNot Nothing Then
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            'MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            If grd.Rows.Count = 0 Then
                'MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            Else
                'If Trim(txttrip.Text) = "" And Trim(txtref.Text) = "" Then
                '    'MsgBox("Loading data completed.", MsgBoxStyle.Information, "")
                'End If
            End If
        End If
    End Sub

    Private Sub backgroundWorkerdestin_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label3.Text = e.ProgressPercentage.ToString() & "% complete"
    End Sub

    Private Sub grd_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd.CellContentClick

    End Sub

    Private Sub pendingstep7_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If backgroundWorkerdestin.IsBusy = True Then
            If backgroundWorkerdestin.WorkerSupportsCancellation = True Then
                backgroundWorkerdestin.CancelAsync()
            End If
        End If

        Me.Dispose()
    End Sub

    Private Sub pendingstep7_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        If lblstep.Text = "7" Then
            viewpending7()
            count()
        End If
    End Sub

    Private Sub grd_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd.CellDoubleClick
        Try
            If e.RowIndex > -1 Then
                If e.ColumnIndex = 1 Then
                    Dim tripnum As String = grd.Rows(e.RowIndex).Cells(1).Value
                    Dim plate As String = grd.Rows(e.RowIndex).Cells(2).Value
                    Dim des As String = grd.Rows(e.RowIndex).Cells(4).Value
                    Dim vtype As String = ""

                    sql = "Select vtype from tblgeneral where platenum='" & plate & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        vtype = dr("vtype")
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    viewsteps.lblstep.Text = "7"
                    viewsteps.Text = "View Step7"
                    viewsteps.lbltripnum1.Text = tripnum
                    viewsteps.lblplate1.Text = plate
                    viewsteps.lbltype1.Text = vtype
                    viewsteps.txtdes.Text = "Destination: " & des
                    viewsteps.notfinish()
                    viewsteps.ShowDialog()

                    'If tripdispatch.IsHandleCreated Then
                    '    tripdispatch.Dispose()
                    'End If
                    'tripdispatch.tripstep7()
                    'tripdispatch.txts7.Text = "20-006952"
                    'tripdispatch.selectstep = 7
                    'tripdispatch.MdiParent = mditrip
                    'tripdispatch.Show()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub grd_CellPainting(sender As Object, e As DataGridViewCellPaintingEventArgs) Handles grd.CellPainting
        Me.Cursor = Cursors.Default
        'Exit Sub

        'Paint everything except the ErrorIcon the standard way.
        e.Paint(e.ClipBounds, e.PaintParts And Not DataGridViewPaintParts.ErrorIcon)

        'Paint the ErrorIcon, if necessary, the custom way.
        If (e.PaintParts And DataGridViewPaintParts.ErrorIcon) = DataGridViewPaintParts.ErrorIcon Then
            If e.ErrorText <> "" And (e.ColumnIndex = 4) Then

                With e.Graphics
                    Dim gstate As Drawing2D.GraphicsState = .Save()
                    Dim iconRect As Rectangle = New Rectangle(e.CellBounds.Right - 20, e.CellBounds.Top + e.CellBounds.Height \ 2 - 8, 13, 13)
                    Dim backColor As Color
                    If (e.State And DataGridViewElementStates.Selected) = DataGridViewElementStates.Selected Then
                        backColor = e.CellStyle.SelectionBackColor
                    Else
                        backColor = e.CellStyle.BackColor
                    End If

                    'Restrict drawing within cell boundaries.
                    .SetClip(e.CellBounds)
                    'Clear background area behind the icon.
                    Using brush As New SolidBrush(backColor)
                        .FillRectangle(brush, iconRect)
                    End Using
                    'Draw the icon.

                    .DrawIcon(SystemIcons.Information, iconRect)

                    .Restore(gstate)
                End With
            End If
        End If

        e.Handled = True
    End Sub
End Class