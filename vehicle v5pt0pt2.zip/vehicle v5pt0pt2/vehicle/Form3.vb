﻿Public Class Form3
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'TextBox1.Text = getSO_Details(724202)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'TextBox1.Text = getPO_Details(7821)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'TextBox1.Text = getITR_Details(38057)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim s As String = TextBox1.Text
        ' s = s.TrimEnd(ControlChars.Cr, ControlChars.Lf)
        MsgBox(Trim(s))
    End Sub
End Class