﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class mditrip
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mditrip))
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.GeneralToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CompanyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WarehouseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DocumentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VehicleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrafficViolationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DriverToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelperToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.POIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CategoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ItemsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransactionTypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VehicleTripToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreateOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrderTransactionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TripSchedulingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TripDispatchingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TripDispatchSummaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TripSummaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TripScheduleReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TripViaShippingLinesPendingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ForChangeOilToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TripTodayToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServiceVehicleOdometerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TruckEndingOdometerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VehicularAccidentLTOApprehensionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TruckStatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MotorpoolInspectionStatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdministratorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UsersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoginLogsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VersionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdjustQtyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InsertIntoDashboardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestoreCommentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeletePreviousAttachmentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PendingStatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GPSAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ForAssessmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CategoryToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MotorpoolToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UploadOfflineDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SampleSAPAPIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PerYearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NotificationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Step7PendingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Step8PendingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Step9PendingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ForContainerStuffingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PendingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MotorpoolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MPInspectionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip2
        '
        Me.MenuStrip2.BackColor = System.Drawing.Color.Azure
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.GeneralToolStripMenuItem, Me.VehicleTripToolStripMenuItem, Me.ReportsToolStripMenuItem, Me.AdministratorToolStripMenuItem, Me.NotificationsToolStripMenuItem, Me.MotorpoolToolStripMenuItem})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(1269, 24)
        Me.MenuStrip2.TabIndex = 20
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Image = CType(resources.GetObject("ToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(73, 20)
        Me.ToolStripMenuItem1.Text = "Logout"
        '
        'GeneralToolStripMenuItem
        '
        Me.GeneralToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CompanyToolStripMenuItem, Me.WarehouseToolStripMenuItem, Me.DocumentsToolStripMenuItem, Me.VehicleToolStripMenuItem, Me.TrafficViolationToolStripMenuItem, Me.DriverToolStripMenuItem, Me.HelperToolStripMenuItem, Me.CustomerToolStripMenuItem, Me.POIToolStripMenuItem, Me.CategoryToolStripMenuItem, Me.ItemsToolStripMenuItem, Me.TransactionTypeToolStripMenuItem})
        Me.GeneralToolStripMenuItem.Image = CType(resources.GetObject("GeneralToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GeneralToolStripMenuItem.Name = "GeneralToolStripMenuItem"
        Me.GeneralToolStripMenuItem.Size = New System.Drawing.Size(75, 20)
        Me.GeneralToolStripMenuItem.Text = "General"
        '
        'CompanyToolStripMenuItem
        '
        Me.CompanyToolStripMenuItem.Image = CType(resources.GetObject("CompanyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CompanyToolStripMenuItem.Name = "CompanyToolStripMenuItem"
        Me.CompanyToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.CompanyToolStripMenuItem.Text = "Company"
        '
        'WarehouseToolStripMenuItem
        '
        Me.WarehouseToolStripMenuItem.Image = CType(resources.GetObject("WarehouseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.WarehouseToolStripMenuItem.Name = "WarehouseToolStripMenuItem"
        Me.WarehouseToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.WarehouseToolStripMenuItem.Text = "Warehouse"
        '
        'DocumentsToolStripMenuItem
        '
        Me.DocumentsToolStripMenuItem.Image = CType(resources.GetObject("DocumentsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DocumentsToolStripMenuItem.Name = "DocumentsToolStripMenuItem"
        Me.DocumentsToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.DocumentsToolStripMenuItem.Text = "Documents"
        '
        'VehicleToolStripMenuItem
        '
        Me.VehicleToolStripMenuItem.Image = CType(resources.GetObject("VehicleToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleToolStripMenuItem.Name = "VehicleToolStripMenuItem"
        Me.VehicleToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.VehicleToolStripMenuItem.Text = "Vehicle"
        '
        'TrafficViolationToolStripMenuItem
        '
        Me.TrafficViolationToolStripMenuItem.Image = CType(resources.GetObject("TrafficViolationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TrafficViolationToolStripMenuItem.Name = "TrafficViolationToolStripMenuItem"
        Me.TrafficViolationToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.TrafficViolationToolStripMenuItem.Text = "Traffic Violation and Other Charges"
        '
        'DriverToolStripMenuItem
        '
        Me.DriverToolStripMenuItem.Image = CType(resources.GetObject("DriverToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DriverToolStripMenuItem.Name = "DriverToolStripMenuItem"
        Me.DriverToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.DriverToolStripMenuItem.Text = "Driver"
        '
        'HelperToolStripMenuItem
        '
        Me.HelperToolStripMenuItem.Image = CType(resources.GetObject("HelperToolStripMenuItem.Image"), System.Drawing.Image)
        Me.HelperToolStripMenuItem.Name = "HelperToolStripMenuItem"
        Me.HelperToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.HelperToolStripMenuItem.Text = "Helper"
        '
        'CustomerToolStripMenuItem
        '
        Me.CustomerToolStripMenuItem.Image = CType(resources.GetObject("CustomerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CustomerToolStripMenuItem.Name = "CustomerToolStripMenuItem"
        Me.CustomerToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.CustomerToolStripMenuItem.Text = "Customer"
        '
        'POIToolStripMenuItem
        '
        Me.POIToolStripMenuItem.Image = CType(resources.GetObject("POIToolStripMenuItem.Image"), System.Drawing.Image)
        Me.POIToolStripMenuItem.Name = "POIToolStripMenuItem"
        Me.POIToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.POIToolStripMenuItem.Text = "POI"
        '
        'CategoryToolStripMenuItem
        '
        Me.CategoryToolStripMenuItem.Image = CType(resources.GetObject("CategoryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CategoryToolStripMenuItem.Name = "CategoryToolStripMenuItem"
        Me.CategoryToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.CategoryToolStripMenuItem.Text = "Category"
        '
        'ItemsToolStripMenuItem
        '
        Me.ItemsToolStripMenuItem.Image = CType(resources.GetObject("ItemsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ItemsToolStripMenuItem.Name = "ItemsToolStripMenuItem"
        Me.ItemsToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.ItemsToolStripMenuItem.Text = "Items"
        '
        'TransactionTypeToolStripMenuItem
        '
        Me.TransactionTypeToolStripMenuItem.Image = CType(resources.GetObject("TransactionTypeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TransactionTypeToolStripMenuItem.Name = "TransactionTypeToolStripMenuItem"
        Me.TransactionTypeToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.TransactionTypeToolStripMenuItem.Text = "Transaction Type"
        '
        'VehicleTripToolStripMenuItem
        '
        Me.VehicleTripToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreateOrderToolStripMenuItem, Me.OrderTransactionsToolStripMenuItem, Me.TripSchedulingToolStripMenuItem, Me.TripDispatchingToolStripMenuItem, Me.TripDispatchSummaryToolStripMenuItem, Me.TripSummaryToolStripMenuItem})
        Me.VehicleTripToolStripMenuItem.Image = CType(resources.GetObject("VehicleTripToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicleTripToolStripMenuItem.Name = "VehicleTripToolStripMenuItem"
        Me.VehicleTripToolStripMenuItem.Size = New System.Drawing.Size(94, 20)
        Me.VehicleTripToolStripMenuItem.Text = "Vehicle Trip"
        '
        'CreateOrderToolStripMenuItem
        '
        Me.CreateOrderToolStripMenuItem.Image = CType(resources.GetObject("CreateOrderToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CreateOrderToolStripMenuItem.Name = "CreateOrderToolStripMenuItem"
        Me.CreateOrderToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.CreateOrderToolStripMenuItem.Text = "Create Order"
        '
        'OrderTransactionsToolStripMenuItem
        '
        Me.OrderTransactionsToolStripMenuItem.Image = CType(resources.GetObject("OrderTransactionsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OrderTransactionsToolStripMenuItem.Name = "OrderTransactionsToolStripMenuItem"
        Me.OrderTransactionsToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.OrderTransactionsToolStripMenuItem.Text = "Order Transactions"
        '
        'TripSchedulingToolStripMenuItem
        '
        Me.TripSchedulingToolStripMenuItem.Image = CType(resources.GetObject("TripSchedulingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TripSchedulingToolStripMenuItem.Name = "TripSchedulingToolStripMenuItem"
        Me.TripSchedulingToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.TripSchedulingToolStripMenuItem.Text = "Trip Scheduling"
        '
        'TripDispatchingToolStripMenuItem
        '
        Me.TripDispatchingToolStripMenuItem.Image = CType(resources.GetObject("TripDispatchingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TripDispatchingToolStripMenuItem.Name = "TripDispatchingToolStripMenuItem"
        Me.TripDispatchingToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.TripDispatchingToolStripMenuItem.Text = "Trip Dispatching"
        '
        'TripDispatchSummaryToolStripMenuItem
        '
        Me.TripDispatchSummaryToolStripMenuItem.Image = CType(resources.GetObject("TripDispatchSummaryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TripDispatchSummaryToolStripMenuItem.Name = "TripDispatchSummaryToolStripMenuItem"
        Me.TripDispatchSummaryToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.TripDispatchSummaryToolStripMenuItem.Text = "Trip Dispatch Summary"
        '
        'TripSummaryToolStripMenuItem
        '
        Me.TripSummaryToolStripMenuItem.Image = CType(resources.GetObject("TripSummaryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TripSummaryToolStripMenuItem.Name = "TripSummaryToolStripMenuItem"
        Me.TripSummaryToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.TripSummaryToolStripMenuItem.Text = "Trip Summary"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TripScheduleReportToolStripMenuItem, Me.TripViaShippingLinesPendingToolStripMenuItem, Me.ForChangeOilToolStripMenuItem, Me.TripTodayToolStripMenuItem1, Me.ServiceVehicleOdometerToolStripMenuItem, Me.TruckEndingOdometerToolStripMenuItem, Me.VehicularAccidentLTOApprehensionToolStripMenuItem, Me.TruckStatusToolStripMenuItem, Me.MotorpoolInspectionStatusToolStripMenuItem})
        Me.ReportsToolStripMenuItem.Image = CType(resources.GetObject("ReportsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(75, 20)
        Me.ReportsToolStripMenuItem.Text = "Reports"
        '
        'TripScheduleReportToolStripMenuItem
        '
        Me.TripScheduleReportToolStripMenuItem.Image = CType(resources.GetObject("TripScheduleReportToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TripScheduleReportToolStripMenuItem.Name = "TripScheduleReportToolStripMenuItem"
        Me.TripScheduleReportToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.TripScheduleReportToolStripMenuItem.Text = "Trip Schedule Report"
        '
        'TripViaShippingLinesPendingToolStripMenuItem
        '
        Me.TripViaShippingLinesPendingToolStripMenuItem.Image = CType(resources.GetObject("TripViaShippingLinesPendingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TripViaShippingLinesPendingToolStripMenuItem.Name = "TripViaShippingLinesPendingToolStripMenuItem"
        Me.TripViaShippingLinesPendingToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.TripViaShippingLinesPendingToolStripMenuItem.Text = "Trip via Shipping Lines (Pending)"
        '
        'ForChangeOilToolStripMenuItem
        '
        Me.ForChangeOilToolStripMenuItem.Image = CType(resources.GetObject("ForChangeOilToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ForChangeOilToolStripMenuItem.Name = "ForChangeOilToolStripMenuItem"
        Me.ForChangeOilToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.ForChangeOilToolStripMenuItem.Text = "For Change Oil"
        '
        'TripTodayToolStripMenuItem1
        '
        Me.TripTodayToolStripMenuItem1.Image = CType(resources.GetObject("TripTodayToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.TripTodayToolStripMenuItem1.Name = "TripTodayToolStripMenuItem1"
        Me.TripTodayToolStripMenuItem1.Size = New System.Drawing.Size(279, 22)
        Me.TripTodayToolStripMenuItem1.Text = "Pending Trip Status per Date"
        '
        'ServiceVehicleOdometerToolStripMenuItem
        '
        Me.ServiceVehicleOdometerToolStripMenuItem.Image = CType(resources.GetObject("ServiceVehicleOdometerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ServiceVehicleOdometerToolStripMenuItem.Name = "ServiceVehicleOdometerToolStripMenuItem"
        Me.ServiceVehicleOdometerToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.ServiceVehicleOdometerToolStripMenuItem.Text = "Service Vehicle Odometer"
        '
        'TruckEndingOdometerToolStripMenuItem
        '
        Me.TruckEndingOdometerToolStripMenuItem.Image = CType(resources.GetObject("TruckEndingOdometerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TruckEndingOdometerToolStripMenuItem.Name = "TruckEndingOdometerToolStripMenuItem"
        Me.TruckEndingOdometerToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.TruckEndingOdometerToolStripMenuItem.Text = "Vehicle (Ending Odometer)"
        '
        'VehicularAccidentLTOApprehensionToolStripMenuItem
        '
        Me.VehicularAccidentLTOApprehensionToolStripMenuItem.Image = CType(resources.GetObject("VehicularAccidentLTOApprehensionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VehicularAccidentLTOApprehensionToolStripMenuItem.Name = "VehicularAccidentLTOApprehensionToolStripMenuItem"
        Me.VehicularAccidentLTOApprehensionToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.VehicularAccidentLTOApprehensionToolStripMenuItem.Text = "Vehicular Accident / LTO Apprehension"
        '
        'TruckStatusToolStripMenuItem
        '
        Me.TruckStatusToolStripMenuItem.Image = CType(resources.GetObject("TruckStatusToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TruckStatusToolStripMenuItem.Name = "TruckStatusToolStripMenuItem"
        Me.TruckStatusToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.TruckStatusToolStripMenuItem.Text = "Truck Status"
        '
        'MotorpoolInspectionStatusToolStripMenuItem
        '
        Me.MotorpoolInspectionStatusToolStripMenuItem.Image = CType(resources.GetObject("MotorpoolInspectionStatusToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MotorpoolInspectionStatusToolStripMenuItem.Name = "MotorpoolInspectionStatusToolStripMenuItem"
        Me.MotorpoolInspectionStatusToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.MotorpoolInspectionStatusToolStripMenuItem.Text = "Motorpool Inspection Status"
        '
        'AdministratorToolStripMenuItem
        '
        Me.AdministratorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UsersToolStripMenuItem, Me.LoginLogsToolStripMenuItem, Me.VersionToolStripMenuItem, Me.AdjustQtyToolStripMenuItem, Me.InsertIntoDashboardToolStripMenuItem, Me.RestoreCommentToolStripMenuItem, Me.DeletePreviousAttachmentsToolStripMenuItem, Me.BackupToolStripMenuItem, Me.PendingStatusToolStripMenuItem, Me.GPSAccountToolStripMenuItem, Me.ForAssessmentToolStripMenuItem, Me.MotorpoolToolStripMenuItem1, Me.SampleSAPAPIToolStripMenuItem, Me.PerYearToolStripMenuItem})
        Me.AdministratorToolStripMenuItem.Image = CType(resources.GetObject("AdministratorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AdministratorToolStripMenuItem.Name = "AdministratorToolStripMenuItem"
        Me.AdministratorToolStripMenuItem.Size = New System.Drawing.Size(108, 20)
        Me.AdministratorToolStripMenuItem.Text = "Administrator"
        '
        'UsersToolStripMenuItem
        '
        Me.UsersToolStripMenuItem.Image = CType(resources.GetObject("UsersToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UsersToolStripMenuItem.Name = "UsersToolStripMenuItem"
        Me.UsersToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.UsersToolStripMenuItem.Text = "Users"
        '
        'LoginLogsToolStripMenuItem
        '
        Me.LoginLogsToolStripMenuItem.Image = CType(resources.GetObject("LoginLogsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LoginLogsToolStripMenuItem.Name = "LoginLogsToolStripMenuItem"
        Me.LoginLogsToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.LoginLogsToolStripMenuItem.Text = "Login Logs"
        '
        'VersionToolStripMenuItem
        '
        Me.VersionToolStripMenuItem.Image = CType(resources.GetObject("VersionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VersionToolStripMenuItem.Name = "VersionToolStripMenuItem"
        Me.VersionToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.VersionToolStripMenuItem.Text = "Version"
        '
        'AdjustQtyToolStripMenuItem
        '
        Me.AdjustQtyToolStripMenuItem.Image = CType(resources.GetObject("AdjustQtyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AdjustQtyToolStripMenuItem.Name = "AdjustQtyToolStripMenuItem"
        Me.AdjustQtyToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.AdjustQtyToolStripMenuItem.Text = "Adjust Qty"
        '
        'InsertIntoDashboardToolStripMenuItem
        '
        Me.InsertIntoDashboardToolStripMenuItem.Image = CType(resources.GetObject("InsertIntoDashboardToolStripMenuItem.Image"), System.Drawing.Image)
        Me.InsertIntoDashboardToolStripMenuItem.Name = "InsertIntoDashboardToolStripMenuItem"
        Me.InsertIntoDashboardToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.InsertIntoDashboardToolStripMenuItem.Text = "Insert into Dashboard"
        '
        'RestoreCommentToolStripMenuItem
        '
        Me.RestoreCommentToolStripMenuItem.Image = CType(resources.GetObject("RestoreCommentToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RestoreCommentToolStripMenuItem.Name = "RestoreCommentToolStripMenuItem"
        Me.RestoreCommentToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.RestoreCommentToolStripMenuItem.Text = "Restore Comment"
        Me.RestoreCommentToolStripMenuItem.Visible = False
        '
        'DeletePreviousAttachmentsToolStripMenuItem
        '
        Me.DeletePreviousAttachmentsToolStripMenuItem.Image = CType(resources.GetObject("DeletePreviousAttachmentsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DeletePreviousAttachmentsToolStripMenuItem.Name = "DeletePreviousAttachmentsToolStripMenuItem"
        Me.DeletePreviousAttachmentsToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.DeletePreviousAttachmentsToolStripMenuItem.Text = "Delete Previous Attachments"
        Me.DeletePreviousAttachmentsToolStripMenuItem.Visible = False
        '
        'BackupToolStripMenuItem
        '
        Me.BackupToolStripMenuItem.Image = CType(resources.GetObject("BackupToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BackupToolStripMenuItem.Name = "BackupToolStripMenuItem"
        Me.BackupToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.BackupToolStripMenuItem.Text = "Backup"
        '
        'PendingStatusToolStripMenuItem
        '
        Me.PendingStatusToolStripMenuItem.Name = "PendingStatusToolStripMenuItem"
        Me.PendingStatusToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.PendingStatusToolStripMenuItem.Text = "Pending Status"
        Me.PendingStatusToolStripMenuItem.Visible = False
        '
        'GPSAccountToolStripMenuItem
        '
        Me.GPSAccountToolStripMenuItem.Image = CType(resources.GetObject("GPSAccountToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GPSAccountToolStripMenuItem.Name = "GPSAccountToolStripMenuItem"
        Me.GPSAccountToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.GPSAccountToolStripMenuItem.Text = "GPS Account"
        '
        'ForAssessmentToolStripMenuItem
        '
        Me.ForAssessmentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CategoryToolStripMenuItem1})
        Me.ForAssessmentToolStripMenuItem.Image = CType(resources.GetObject("ForAssessmentToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ForAssessmentToolStripMenuItem.Name = "ForAssessmentToolStripMenuItem"
        Me.ForAssessmentToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.ForAssessmentToolStripMenuItem.Text = "Assessment"
        '
        'CategoryToolStripMenuItem1
        '
        Me.CategoryToolStripMenuItem1.Name = "CategoryToolStripMenuItem1"
        Me.CategoryToolStripMenuItem1.Size = New System.Drawing.Size(122, 22)
        Me.CategoryToolStripMenuItem1.Text = "Category"
        '
        'MotorpoolToolStripMenuItem1
        '
        Me.MotorpoolToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EnableToolStripMenuItem, Me.DisableToolStripMenuItem, Me.UploadOfflineDataToolStripMenuItem})
        Me.MotorpoolToolStripMenuItem1.Image = CType(resources.GetObject("MotorpoolToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.MotorpoolToolStripMenuItem1.Name = "MotorpoolToolStripMenuItem1"
        Me.MotorpoolToolStripMenuItem1.Size = New System.Drawing.Size(226, 22)
        Me.MotorpoolToolStripMenuItem1.Text = "Motorpool"
        '
        'EnableToolStripMenuItem
        '
        Me.EnableToolStripMenuItem.Image = CType(resources.GetObject("EnableToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EnableToolStripMenuItem.Name = "EnableToolStripMenuItem"
        Me.EnableToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.EnableToolStripMenuItem.Text = "Enable Connection"
        '
        'DisableToolStripMenuItem
        '
        Me.DisableToolStripMenuItem.Image = CType(resources.GetObject("DisableToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DisableToolStripMenuItem.Name = "DisableToolStripMenuItem"
        Me.DisableToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.DisableToolStripMenuItem.Text = "Disable Connection"
        '
        'UploadOfflineDataToolStripMenuItem
        '
        Me.UploadOfflineDataToolStripMenuItem.Image = CType(resources.GetObject("UploadOfflineDataToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UploadOfflineDataToolStripMenuItem.Name = "UploadOfflineDataToolStripMenuItem"
        Me.UploadOfflineDataToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.UploadOfflineDataToolStripMenuItem.Text = "Upload Offline data"
        '
        'SampleSAPAPIToolStripMenuItem
        '
        Me.SampleSAPAPIToolStripMenuItem.Name = "SampleSAPAPIToolStripMenuItem"
        Me.SampleSAPAPIToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.SampleSAPAPIToolStripMenuItem.Text = "Sample SAP API"
        Me.SampleSAPAPIToolStripMenuItem.Visible = False
        '
        'PerYearToolStripMenuItem
        '
        Me.PerYearToolStripMenuItem.Name = "PerYearToolStripMenuItem"
        Me.PerYearToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.PerYearToolStripMenuItem.Text = "Per year"
        '
        'NotificationsToolStripMenuItem
        '
        Me.NotificationsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Step7PendingToolStripMenuItem, Me.Step8PendingToolStripMenuItem, Me.Step9PendingToolStripMenuItem, Me.ForContainerStuffingToolStripMenuItem, Me.PendingToolStripMenuItem})
        Me.NotificationsToolStripMenuItem.Image = CType(resources.GetObject("NotificationsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NotificationsToolStripMenuItem.Name = "NotificationsToolStripMenuItem"
        Me.NotificationsToolStripMenuItem.Size = New System.Drawing.Size(103, 20)
        Me.NotificationsToolStripMenuItem.Text = "Notifications"
        '
        'Step7PendingToolStripMenuItem
        '
        Me.Step7PendingToolStripMenuItem.Image = CType(resources.GetObject("Step7PendingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.Step7PendingToolStripMenuItem.Name = "Step7PendingToolStripMenuItem"
        Me.Step7PendingToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.Step7PendingToolStripMenuItem.Text = "Step 7 Pending"
        '
        'Step8PendingToolStripMenuItem
        '
        Me.Step8PendingToolStripMenuItem.Image = CType(resources.GetObject("Step8PendingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.Step8PendingToolStripMenuItem.Name = "Step8PendingToolStripMenuItem"
        Me.Step8PendingToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.Step8PendingToolStripMenuItem.Text = "Step 8 Pending"
        '
        'Step9PendingToolStripMenuItem
        '
        Me.Step9PendingToolStripMenuItem.Image = CType(resources.GetObject("Step9PendingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.Step9PendingToolStripMenuItem.Name = "Step9PendingToolStripMenuItem"
        Me.Step9PendingToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.Step9PendingToolStripMenuItem.Text = "Step 9 Pending"
        '
        'ForContainerStuffingToolStripMenuItem
        '
        Me.ForContainerStuffingToolStripMenuItem.Name = "ForContainerStuffingToolStripMenuItem"
        Me.ForContainerStuffingToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.ForContainerStuffingToolStripMenuItem.Text = "For Container Stuffing"
        Me.ForContainerStuffingToolStripMenuItem.Visible = False
        '
        'PendingToolStripMenuItem
        '
        Me.PendingToolStripMenuItem.Image = CType(resources.GetObject("PendingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PendingToolStripMenuItem.Name = "PendingToolStripMenuItem"
        Me.PendingToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.PendingToolStripMenuItem.Text = "Temporary POI"
        '
        'MotorpoolToolStripMenuItem
        '
        Me.MotorpoolToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MPInspectionToolStripMenuItem})
        Me.MotorpoolToolStripMenuItem.Image = CType(resources.GetObject("MotorpoolToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MotorpoolToolStripMenuItem.Name = "MotorpoolToolStripMenuItem"
        Me.MotorpoolToolStripMenuItem.Size = New System.Drawing.Size(92, 20)
        Me.MotorpoolToolStripMenuItem.Text = "Motorpool"
        '
        'MPInspectionToolStripMenuItem
        '
        Me.MPInspectionToolStripMenuItem.Image = CType(resources.GetObject("MPInspectionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MPInspectionToolStripMenuItem.Name = "MPInspectionToolStripMenuItem"
        Me.MPInspectionToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.MPInspectionToolStripMenuItem.Text = "Truck Inspection"
        '
        'Timer1
        '
        Me.Timer1.Interval = 600000
        '
        'mditrip
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(1269, 701)
        Me.Controls.Add(Me.MenuStrip2)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip2
        Me.Name = "mditrip"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Fleet Management System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip2 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GeneralToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleTripToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AdministratorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CompanyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WarehouseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DocumentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DriverToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelperToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CategoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ItemsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreateOrderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OrderTransactionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripSchedulingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripDispatchingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripDispatchSummaryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripSummaryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripScheduleReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ForChangeOilToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UsersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoginLogsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VersionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AdjustQtyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InsertIntoDashboardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestoreCommentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeletePreviousAttachmentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PendingStatusToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TripTodayToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ServiceVehicleOdometerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TruckEndingOdometerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TripViaShippingLinesPendingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GPSAccountToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents POIToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NotificationsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Timer1 As Timer
    Friend WithEvents TrafficViolationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ForAssessmentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Step7PendingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Step8PendingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VehicularAccidentLTOApprehensionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TruckStatusToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ForContainerStuffingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TransactionTypeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MotorpoolInspectionStatusToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PendingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MotorpoolToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MPInspectionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Step9PendingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CategoryToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents MotorpoolToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents EnableToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DisableToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SampleSAPAPIToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UploadOfflineDataToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PerYearToolStripMenuItem As ToolStripMenuItem
End Class
