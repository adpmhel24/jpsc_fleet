﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class poiselect
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(poiselect))
        Me.grdcus2 = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.txtpoi = New System.Windows.Forms.TextBox()
        Me.txtadd = New System.Windows.Forms.TextBox()
        Me.btnview = New System.Windows.Forms.Button()
        Me.id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.poiid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.poiname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.address = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.distance = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tym = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lng = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.status = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.grdcus2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grdcus2
        '
        Me.grdcus2.AllowUserToAddRows = False
        Me.grdcus2.AllowUserToDeleteRows = False
        Me.grdcus2.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        Me.grdcus2.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdcus2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdcus2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdcus2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdcus2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.grdcus2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdcus2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.id, Me.poiid, Me.poiname, Me.address, Me.distance, Me.tym, Me.lat, Me.lng, Me.status})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.Padding = New System.Windows.Forms.Padding(1)
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdcus2.DefaultCellStyle = DataGridViewCellStyle3
        Me.grdcus2.EnableHeadersVisualStyles = False
        Me.grdcus2.GridColor = System.Drawing.Color.Salmon
        Me.grdcus2.Location = New System.Drawing.Point(12, 45)
        Me.grdcus2.Name = "grdcus2"
        Me.grdcus2.ReadOnly = True
        Me.grdcus2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdcus2.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.grdcus2.RowHeadersWidth = 10
        Me.grdcus2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.grdcus2.Size = New System.Drawing.Size(830, 413)
        Me.grdcus2.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "POI Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(372, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Address:"
        '
        'btnsearch
        '
        Me.btnsearch.Image = CType(resources.GetObject("btnsearch.Image"), System.Drawing.Image)
        Me.btnsearch.Location = New System.Drawing.Point(679, 8)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(75, 23)
        Me.btnsearch.TabIndex = 16
        Me.btnsearch.Text = "Search"
        Me.btnsearch.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnsearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'txtpoi
        '
        Me.txtpoi.Location = New System.Drawing.Point(77, 10)
        Me.txtpoi.Name = "txtpoi"
        Me.txtpoi.Size = New System.Drawing.Size(277, 20)
        Me.txtpoi.TabIndex = 17
        '
        'txtadd
        '
        Me.txtadd.Location = New System.Drawing.Point(426, 10)
        Me.txtadd.Name = "txtadd"
        Me.txtadd.Size = New System.Drawing.Size(247, 20)
        Me.txtadd.TabIndex = 18
        '
        'btnview
        '
        Me.btnview.Image = CType(resources.GetObject("btnview.Image"), System.Drawing.Image)
        Me.btnview.Location = New System.Drawing.Point(760, 8)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(75, 23)
        Me.btnview.TabIndex = 19
        Me.btnview.Text = "View All"
        Me.btnview.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnview.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnview.UseVisualStyleBackColor = True
        '
        'id
        '
        Me.id.Frozen = True
        Me.id.HeaderText = "ID"
        Me.id.Name = "id"
        Me.id.ReadOnly = True
        Me.id.Visible = False
        '
        'poiid
        '
        Me.poiid.Frozen = True
        Me.poiid.HeaderText = "POI ID"
        Me.poiid.Name = "poiid"
        Me.poiid.ReadOnly = True
        Me.poiid.Visible = False
        '
        'poiname
        '
        Me.poiname.Frozen = True
        Me.poiname.HeaderText = "Name"
        Me.poiname.MinimumWidth = 200
        Me.poiname.Name = "poiname"
        Me.poiname.ReadOnly = True
        Me.poiname.Width = 200
        '
        'address
        '
        Me.address.Frozen = True
        Me.address.HeaderText = "Address"
        Me.address.MinimumWidth = 10
        Me.address.Name = "address"
        Me.address.ReadOnly = True
        Me.address.Width = 450
        '
        'distance
        '
        Me.distance.Frozen = True
        Me.distance.HeaderText = "Standard Distance (Km)"
        Me.distance.Name = "distance"
        Me.distance.ReadOnly = True
        Me.distance.Width = 120
        '
        'tym
        '
        Me.tym.HeaderText = "Travel Time"
        Me.tym.Name = "tym"
        Me.tym.ReadOnly = True
        Me.tym.Visible = False
        '
        'lat
        '
        Me.lat.HeaderText = "Latitude"
        Me.lat.Name = "lat"
        Me.lat.ReadOnly = True
        Me.lat.Visible = False
        '
        'lng
        '
        Me.lng.HeaderText = "Longitude"
        Me.lng.Name = "lng"
        Me.lng.ReadOnly = True
        Me.lng.Visible = False
        '
        'status
        '
        Me.status.HeaderText = "Status"
        Me.status.Name = "status"
        Me.status.ReadOnly = True
        Me.status.Visible = False
        '
        'poiselect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightCyan
        Me.ClientSize = New System.Drawing.Size(854, 470)
        Me.Controls.Add(Me.btnview)
        Me.Controls.Add(Me.txtadd)
        Me.Controls.Add(Me.txtpoi)
        Me.Controls.Add(Me.btnsearch)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.grdcus2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "poiselect"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Select POI"
        CType(Me.grdcus2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grdcus2 As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnsearch As Button
    Friend WithEvents txtpoi As TextBox
    Friend WithEvents txtadd As TextBox
    Friend WithEvents btnview As Button
    Friend WithEvents id As DataGridViewTextBoxColumn
    Friend WithEvents poiid As DataGridViewTextBoxColumn
    Friend WithEvents poiname As DataGridViewTextBoxColumn
    Friend WithEvents address As DataGridViewTextBoxColumn
    Friend WithEvents distance As DataGridViewTextBoxColumn
    Friend WithEvents tym As DataGridViewTextBoxColumn
    Friend WithEvents lat As DataGridViewTextBoxColumn
    Friend WithEvents lng As DataGridViewTextBoxColumn
    Friend WithEvents status As DataGridViewTextBoxColumn
End Class
