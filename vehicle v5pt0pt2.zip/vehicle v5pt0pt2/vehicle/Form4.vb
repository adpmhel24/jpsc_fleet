﻿Imports System.Data.SqlClient
Public Class Form4
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String, selectedrow As Integer
    Dim dtServerDateTime As Date

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try
            If Trim(txtsearch.Text) = "" Then
                MsgBox("Input you want to search.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            Me.Cursor = Cursors.WaitCursor

            grd.Rows.Clear()

            If cmbcus.SelectedItem = "All" Then
                'sql = "Select * from vStuffing"
                'sql = sql & " where (tripnum like '%" & Trim(txtsearch.Text) & "%' or platenum like '%" & Trim(txtsearch.Text) & "%'"
                'sql = sql & " or transnum like '%" & Trim(txtsearch.Text) & "%' or ponum like '%" & Trim(txtsearch.Text) & "%' or arnum like '%" & Trim(txtsearch.Text) & "%'"
                'sql = sql & " or dnnum like '%" & Trim(txtsearch.Text) & "%' or itrnum like '%" & Trim(txtsearch.Text) & "%')"
            Else
                sql = "Select * from vStuffing where customer='" & cmbcus.SelectedItem.ToString.Replace("'", "''") & "'"
                sql = sql & " and (tripnum like '%" & Trim(txtsearch.Text) & "%' or platenum like '%" & Trim(txtsearch.Text) & "%'"
                sql = sql & " or transnum like '%" & Trim(txtsearch.Text) & "%' or ponum like '%" & Trim(txtsearch.Text) & "%' or arnum like '%" & Trim(txtsearch.Text) & "%'"
                sql = sql & " or dnnum like '%" & Trim(txtsearch.Text) & "%' or itrnum like '%" & Trim(txtsearch.Text) & "%')"
            End If

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grd.Rows.Add(dr("tripnum"), dr("platenum"), dr("transnum").ToString, dr("customer").ToString, dr("ponum"), dr("arnum"), dr("dnnum"), dr("itrnum"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub
End Class