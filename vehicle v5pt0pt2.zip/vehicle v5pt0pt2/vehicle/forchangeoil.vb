﻿Imports System.IO
Imports System.Data.SqlClient
Imports Excel = Microsoft.Office.Interop.Excel

Public Class forchangeoil
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand
    Dim dtServerDateTime As DateTime

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub forchangeoil_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

    End Sub

    Private Sub forchangeoil_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '/view()

        connect()
        cmd = New SqlCommand("Select GetDate()", conn)
        dtServerDateTime = cmd.ExecuteScalar
        conn.Close()

        Label1.Text = "As of " & dtServerDateTime.ToString

        grdpms.Rows.Clear()
        If login.userwhse = "All" Then
            grdpms.Columns(10).Visible = True
        Else
            grdpms.Columns(10).Visible = False
        End If

        If login.svrlc = False Then
            Me.Cursor = Cursors.Default
            MsgBox("Can't connect to LC server.", MsgBoxStyle.Critical, "")
            Exit Sub
        End If

        viewwhse()
        viewplate()
        'MsgBox(login.whse & " - " & login.userwhse)
        If login.whse = login.userwhse Then
            pms_viewnotif("pmsstat<>'0'", " and g.whsename='" & Trim(cmbwhse.Text) & "'")
        Else
            pms_viewnotif("pmsstat<>'0'", "")
        End If
        lblcount.Text = grdpms.Rows.Count
    End Sub

    Private Sub viewwhse()
        Try
            cmbwhse.Items.Clear()
            cmbwhse.Items.Add("All")

            sql = "Select whsename from tblwhse where company='J. Poon & Sons' and status='1' order by whsename"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbwhse.Items.Add(dr("whsename"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            cmbwhse.SelectedItem = login.userwhse
            If login.userwhse <> "All" Then
                cmbwhse.Enabled = False
            Else
                cmbwhse.Enabled = True
            End If

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub viewplate()
        Try
            cmbplate.Items.Clear()

            If login.userwhse <> "All" Then
                sql = "Select platenum from tblgeneral where company='J. Poon & Sons' and whsename='" & login.userwhse & "' and status='1' order by platenum"
            Else
                sql = "Select platenum from tblgeneral where company='J. Poon & Sons' and status='1' order by platenum"
            End If

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbplate.Items.Add(dr("platenum"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub btnexport_Click(sender As Object, e As EventArgs) Handles btnexport.Click
        Try
            If grdpms.Rows.Count = 0 Then
                MsgBox("No record.", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Me.Cursor = Cursors.WaitCursor
            Dim objExcel As New Excel.Application
            Dim bkWorkBook As Excel.Workbook
            Dim shWorkSheet As Excel.Worksheet
            Dim misValue As Object = System.Reflection.Missing.Value

            Dim i As Integer
            Dim j As Integer
            Dim dtoday As String = Format(Date.Now, "MMM_dd_yyyy")
            Dim sfilename As String = login.whse & " Whse " & " For Change Oil " & dtoday & ".xls"

            objExcel = New Excel.Application
            bkWorkBook = objExcel.Workbooks.Add
            shWorkSheet = CType(bkWorkBook.ActiveSheet, Excel.Worksheet)

            With shWorkSheet
                .Range("A1", misValue).EntireRow.Font.Bold = True

                .Range("A1:J" & grdpms.RowCount + 1).HorizontalAlignment = -4108
                .Range("A1:J" & grdpms.RowCount + 1).VerticalAlignment = -4108
                .Range("A1:J" & grdpms.RowCount + 1).Font.Size = 10
                'Set Clipboard Copy Mode     
                grdpms.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
                grdpms.SelectAll()
                grdpms.RowHeadersVisible = False

                'Get the content from Grid for Clipboard     
                'Dim str As String = TryCast(grdpms.GetClipboardContent().GetData(DataFormats.UnicodeText), String)
                Dim str As String = grdpms.GetClipboardContent().GetData(DataFormats.UnicodeText)

                'Set the content to Clipboard     
                Clipboard.SetText(str, TextDataFormat.UnicodeText) 'TextDataFormat.UnicodeText)

                'Identify and select the range of cells in Excel to paste the clipboard data.     
                .Range("A1:J1", misValue).Select()

                'WIDTH
                .Range("A1:A" & grdpms.RowCount + 1).ColumnWidth = 11
                .Range("B1:B" & grdpms.RowCount + 1).ColumnWidth = 12
                .Range("C1:C" & grdpms.RowCount + 1).ColumnWidth = 15
                .Range("D1:D" & grdpms.RowCount + 1).ColumnWidth = 10
                .Range("E1:E" & grdpms.RowCount + 1).ColumnWidth = 15
                .Range("G1:F" & grdpms.RowCount + 1).ColumnWidth = 13
                .Range("H1:J" & grdpms.RowCount + 1).ColumnWidth = 16

                'Paste the clipboard data     
                .Paste()
                Clipboard.Clear()

            End With

            'format alignment
            'shWorkSheet.Range("D2", "D" & grdpms.RowCount + 1).HorizontalAlignment = Excel.XlHAlign.xlHAlignRight
            For i = 0 To grdpms.RowCount + 2
                'shWorkSheet.Cells(i + 2, 1) = grd.Rows(i).Cells(1).Value
                shWorkSheet.Range("C1").EntireRow.NumberFormat = "MM/dd/yyyy"
            Next

            shWorkSheet.Range("A1:J" & grdpms.RowCount + 1).WrapText = True

            'lagyan ng title na red door kit tska ung date na sakop ng report
            'shWorkSheet.Range("A1").EntireRow.Insert()
            'shWorkSheet.Range("A2").EntireRow.Insert()
            'shWorkSheet.Range("A3").EntireRow.Insert()
            'shWorkSheet.Cells(1, 1) = login.whse & " Warehouse"
            'shWorkSheet.Cells(1, 1).Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red)
            'shWorkSheet.Range("A1:Z" & grdtemp.RowCount + 1).WrapText = True

            Me.Cursor = Cursors.Default

            objExcel.Visible = False
            'objExcel.Application.DisplayAlerts = False

            '/Dim password As String = "Pms123"
            'objExcel.ActiveWorkbook.SaveAs(Application.StartupPath & "sample.xls", FileFormat:=51, )
            '/bkWorkBook.SaveAs(Filename:=Application.StartupPath & "\template\" & sfilename, FileFormat:=51, Password:=password, CreateBackup:=False)
            bkWorkBook.SaveAs(Filename:=Application.StartupPath & "\template\" & sfilename, FileFormat:=51, CreateBackup:=False)

            bkWorkBook.Close(True, misValue, misValue)
            objExcel.Quit()

            'objExcel = Nothing

            releaseObject(bkWorkBook)
            releaseObject(shWorkSheet)
            releaseObject(objExcel)

            MessageBox.Show("Data Successfully Exported") ' & sfilename)
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As System.Runtime.InteropServices.COMException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " + ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub btnimport_Click(sender As Object, e As EventArgs) Handles btnimport.Click
        If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
            MsgBox("Access denied!", MsgBoxStyle.Critical, "")
            Exit Sub
        End If
        '/ importchangeoil.ShowDialog()
        Dim myForm As New importchangeoil
        importchangeoil.MdiParent = mditrip
        importchangeoil.WindowState = FormWindowState.Maximized
        importchangeoil.Show()
    End Sub

    Private Sub grdpms_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdpms.CellContentClick

    End Sub

    Private Sub grdpms_SelectionChanged(sender As Object, e As EventArgs) Handles grdpms.SelectionChanged

    End Sub

    Private Sub grdpms_RowPrePaint(sender As Object, e As DataGridViewRowPrePaintEventArgs) Handles grdpms.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdpms.Rows(e.RowIndex)
            If dgvRow.Cells(9).Value = "Over Due" Then
                dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
            ElseIf dgvRow.Cells(9).Value = ">6 Months" Then
                dgvRow.DefaultCellStyle.BackColor = Color.PowderBlue
            End If
        End If
    End Sub

    Private Sub cmbplate_TextChanged(sender As Object, e As EventArgs) Handles cmbplate.TextChanged

    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try
            grdpms.Rows.Clear()

            Dim plate As String = "", make As String = "", whse As String = "", stat As String = ""
            If Trim(cmbplate.Text) <> "" Then
                plate = " and g.platenum='" & Trim(cmbplate.Text) & "'"
            Else
                If Trim(cmbmake.Text) <> "" Then
                    make = " and g.makename='" & Trim(cmbmake.Text) & "'"
                End If
                If Trim(cmbwhse.Text) <> "All" Then
                    whse = " and g.whsename='" & Trim(cmbwhse.Text) & "'"
                End If
            End If


            If Trim(cmbstat.Text) = ">6 Months" Then
                stat = "pmsstat='4'"
            ElseIf Trim(cmbstat.Text) = "Over Due" Then
                stat = "pmsstat='3'"
            ElseIf Trim(cmbstat.Text) = "Due Today" Then
                stat = "pmsstat='2'"
            ElseIf Trim(cmbstat.Text) = "Due Soon" Then
                stat = "pmsstat='1'"
            Else
                stat = "pmsstat<>'0'"
            End If


            pms_viewnotif(stat, plate & make & whse)

            lblcount.Text = grdpms.Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub
End Class