﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class assessall
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(assessall))
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.grd = New System.Windows.Forms.DataGridView()
        Me.aid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ctrnum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tripnum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.stp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.subj = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.emp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.comm = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dispo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.by = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.deyt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lbltripnum1 = New System.Windows.Forms.Label()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.EditDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReplyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DispositionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NotForPenaltyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WarningNotForPenaltyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ForPenaltyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CancelledToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.grd2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.list1 = New System.Windows.Forms.ListBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtdate = New System.Windows.Forms.TextBox()
        Me.txtstat = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtby = New System.Windows.Forms.TextBox()
        Me.ToolStrip0 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.addnewtool = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        CType(Me.grd, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.grd2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.ToolStrip0.SuspendLayout()
        Me.SuspendLayout()
        '
        'grd
        '
        Me.grd.AllowUserToAddRows = False
        Me.grd.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grd.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grd.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grd.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grd.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.grd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.aid, Me.ctrnum, Me.tripnum, Me.stp, Me.cat, Me.subj, Me.emp, Me.comm, Me.dispo, Me.by, Me.deyt})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.DefaultCellStyle = DataGridViewCellStyle3
        Me.grd.EnableHeadersVisualStyles = False
        Me.grd.GridColor = System.Drawing.Color.Salmon
        Me.grd.Location = New System.Drawing.Point(6, 19)
        Me.grd.Name = "grd"
        Me.grd.ReadOnly = True
        Me.grd.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        Me.grd.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.grd.RowHeadersWidth = 10
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.RowsDefaultCellStyle = DataGridViewCellStyle5
        Me.grd.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd.Size = New System.Drawing.Size(474, 374)
        Me.grd.TabIndex = 11
        '
        'aid
        '
        Me.aid.HeaderText = "ID"
        Me.aid.Name = "aid"
        Me.aid.ReadOnly = True
        Me.aid.Visible = False
        Me.aid.Width = 60
        '
        'ctrnum
        '
        Me.ctrnum.HeaderText = "Control#"
        Me.ctrnum.Name = "ctrnum"
        Me.ctrnum.ReadOnly = True
        '
        'tripnum
        '
        Me.tripnum.HeaderText = "Trip#"
        Me.tripnum.Name = "tripnum"
        Me.tripnum.ReadOnly = True
        Me.tripnum.Visible = False
        '
        'stp
        '
        Me.stp.HeaderText = "Step"
        Me.stp.Name = "stp"
        Me.stp.ReadOnly = True
        '
        'cat
        '
        Me.cat.HeaderText = "Category"
        Me.cat.Name = "cat"
        Me.cat.ReadOnly = True
        Me.cat.Width = 70
        '
        'subj
        '
        Me.subj.HeaderText = "Subject"
        Me.subj.Name = "subj"
        Me.subj.ReadOnly = True
        Me.subj.Width = 180
        '
        'emp
        '
        Me.emp.HeaderText = "Created by"
        Me.emp.Name = "emp"
        Me.emp.ReadOnly = True
        '
        'comm
        '
        Me.comm.HeaderText = "Date Created"
        Me.comm.Name = "comm"
        Me.comm.ReadOnly = True
        Me.comm.Width = 180
        '
        'dispo
        '
        Me.dispo.HeaderText = "Status"
        Me.dispo.Name = "dispo"
        Me.dispo.ReadOnly = True
        Me.dispo.Visible = False
        '
        'by
        '
        Me.by.HeaderText = "By"
        Me.by.Name = "by"
        Me.by.ReadOnly = True
        Me.by.Visible = False
        '
        'deyt
        '
        Me.deyt.HeaderText = "Date"
        Me.deyt.Name = "deyt"
        Me.deyt.ReadOnly = True
        Me.deyt.Visible = False
        '
        'lbltripnum1
        '
        Me.lbltripnum1.AutoSize = True
        Me.lbltripnum1.Location = New System.Drawing.Point(9, 34)
        Me.lbltripnum1.Name = "lbltripnum1"
        Me.lbltripnum1.Size = New System.Drawing.Size(91, 13)
        Me.lbltripnum1.TabIndex = 13
        Me.lbltripnum1.Text = "T.CAL-20-000000"
        Me.lbltripnum1.Visible = False
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditDetailsToolStripMenuItem, Me.ReplyToolStripMenuItem, Me.DispositionToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(134, 70)
        '
        'EditDetailsToolStripMenuItem
        '
        Me.EditDetailsToolStripMenuItem.Image = CType(resources.GetObject("EditDetailsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditDetailsToolStripMenuItem.Name = "EditDetailsToolStripMenuItem"
        Me.EditDetailsToolStripMenuItem.Size = New System.Drawing.Size(133, 22)
        Me.EditDetailsToolStripMenuItem.Text = "Edit Details"
        '
        'ReplyToolStripMenuItem
        '
        Me.ReplyToolStripMenuItem.Image = CType(resources.GetObject("ReplyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ReplyToolStripMenuItem.Name = "ReplyToolStripMenuItem"
        Me.ReplyToolStripMenuItem.Size = New System.Drawing.Size(133, 22)
        Me.ReplyToolStripMenuItem.Text = "Reply"
        '
        'DispositionToolStripMenuItem
        '
        Me.DispositionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NotForPenaltyToolStripMenuItem, Me.WarningNotForPenaltyToolStripMenuItem, Me.ForPenaltyToolStripMenuItem, Me.CancelledToolStripMenuItem})
        Me.DispositionToolStripMenuItem.Image = CType(resources.GetObject("DispositionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DispositionToolStripMenuItem.Name = "DispositionToolStripMenuItem"
        Me.DispositionToolStripMenuItem.Size = New System.Drawing.Size(133, 22)
        Me.DispositionToolStripMenuItem.Text = "Disposition"
        '
        'NotForPenaltyToolStripMenuItem
        '
        Me.NotForPenaltyToolStripMenuItem.Image = CType(resources.GetObject("NotForPenaltyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NotForPenaltyToolStripMenuItem.Name = "NotForPenaltyToolStripMenuItem"
        Me.NotForPenaltyToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.NotForPenaltyToolStripMenuItem.Text = "Not for Penalty"
        '
        'WarningNotForPenaltyToolStripMenuItem
        '
        Me.WarningNotForPenaltyToolStripMenuItem.Image = CType(resources.GetObject("WarningNotForPenaltyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.WarningNotForPenaltyToolStripMenuItem.Name = "WarningNotForPenaltyToolStripMenuItem"
        Me.WarningNotForPenaltyToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.WarningNotForPenaltyToolStripMenuItem.Text = "Warning. Not for Penalty"
        '
        'ForPenaltyToolStripMenuItem
        '
        Me.ForPenaltyToolStripMenuItem.Image = CType(resources.GetObject("ForPenaltyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ForPenaltyToolStripMenuItem.Name = "ForPenaltyToolStripMenuItem"
        Me.ForPenaltyToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.ForPenaltyToolStripMenuItem.Text = "For Penalty"
        '
        'CancelledToolStripMenuItem
        '
        Me.CancelledToolStripMenuItem.Image = CType(resources.GetObject("CancelledToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CancelledToolStripMenuItem.Name = "CancelledToolStripMenuItem"
        Me.CancelledToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.CancelledToolStripMenuItem.Text = "Cancelled"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.grd)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 50)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(486, 399)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Trip#"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.GroupBox5)
        Me.GroupBox2.Controls.Add(Me.GroupBox3)
        Me.GroupBox2.Controls.Add(Me.GroupBox4)
        Me.GroupBox2.Location = New System.Drawing.Point(504, 50)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(428, 399)
        Me.GroupBox2.TabIndex = 15
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Control#"
        '
        'GroupBox5
        '
        Me.GroupBox5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox5.Controls.Add(Me.grd2)
        Me.GroupBox5.Location = New System.Drawing.Point(6, 167)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(414, 226)
        Me.GroupBox5.TabIndex = 8
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Comments"
        '
        'grd2
        '
        Me.grd2.AllowUserToAddRows = False
        Me.grd2.AllowUserToDeleteRows = False
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grd2.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle6
        Me.grd2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grd2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grd2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.grd2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd2.DefaultCellStyle = DataGridViewCellStyle8
        Me.grd2.EnableHeadersVisualStyles = False
        Me.grd2.GridColor = System.Drawing.Color.Salmon
        Me.grd2.Location = New System.Drawing.Point(7, 19)
        Me.grd2.Name = "grd2"
        Me.grd2.ReadOnly = True
        Me.grd2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.OldLace
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        Me.grd2.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.grd2.RowHeadersWidth = 10
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd2.RowsDefaultCellStyle = DataGridViewCellStyle10
        Me.grd2.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd2.Size = New System.Drawing.Size(400, 201)
        Me.grd2.TabIndex = 12
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.HeaderText = "Comments"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Width = 180
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "By"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.list1)
        Me.GroupBox3.Location = New System.Drawing.Point(206, 25)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(213, 136)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Employee"
        '
        'list1
        '
        Me.list1.FormattingEnabled = True
        Me.list1.Location = New System.Drawing.Point(6, 27)
        Me.list1.Name = "list1"
        Me.list1.Size = New System.Drawing.Size(201, 95)
        Me.list1.TabIndex = 0
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label3)
        Me.GroupBox4.Controls.Add(Me.txtdate)
        Me.GroupBox4.Controls.Add(Me.txtstat)
        Me.GroupBox4.Controls.Add(Me.Label2)
        Me.GroupBox4.Controls.Add(Me.txtby)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 25)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(194, 136)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Status"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 89)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(33, 13)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Date:"
        '
        'txtdate
        '
        Me.txtdate.Location = New System.Drawing.Point(7, 105)
        Me.txtdate.Name = "txtdate"
        Me.txtdate.Size = New System.Drawing.Size(167, 20)
        Me.txtdate.TabIndex = 9
        '
        'txtstat
        '
        Me.txtstat.Location = New System.Drawing.Point(6, 27)
        Me.txtstat.Name = "txtstat"
        Me.txtstat.Size = New System.Drawing.Size(167, 20)
        Me.txtstat.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(22, 13)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "By:"
        '
        'txtby
        '
        Me.txtby.Location = New System.Drawing.Point(7, 66)
        Me.txtby.Name = "txtby"
        Me.txtby.Size = New System.Drawing.Size(167, 20)
        Me.txtby.TabIndex = 8
        '
        'ToolStrip0
        '
        Me.ToolStrip0.BackColor = System.Drawing.Color.Green
        Me.ToolStrip0.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator1, Me.addnewtool, Me.ToolStripSeparator2})
        Me.ToolStrip0.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip0.Name = "ToolStrip0"
        Me.ToolStrip0.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ToolStrip0.Size = New System.Drawing.Size(944, 25)
        Me.ToolStrip0.TabIndex = 16
        Me.ToolStrip0.Text = "ToolStrip1"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.ForeColor = System.Drawing.Color.White
        Me.ToolStripSeparator1.Margin = New System.Windows.Forms.Padding(0, 0, 14, 0)
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'addnewtool
        '
        Me.addnewtool.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.addnewtool.ForeColor = System.Drawing.Color.White
        Me.addnewtool.Image = CType(resources.GetObject("addnewtool.Image"), System.Drawing.Image)
        Me.addnewtool.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.addnewtool.Name = "addnewtool"
        Me.addnewtool.Size = New System.Drawing.Size(68, 22)
        Me.addnewtool.Text = "NEW      "
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.ForeColor = System.Drawing.Color.White
        Me.ToolStripSeparator2.Margin = New System.Windows.Forms.Padding(0, 0, 14, 0)
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'assessall
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(944, 461)
        Me.Controls.Add(Me.ToolStrip0)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lbltripnum1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "assessall"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "All Assessment"
        CType(Me.grd, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.grd2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ToolStrip0.ResumeLayout(False)
        Me.ToolStrip0.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grd As DataGridView
    Friend WithEvents lbltripnum1 As Label
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents EditDetailsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReplyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DispositionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NotForPenaltyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WarningNotForPenaltyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ForPenaltyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CancelledToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents list1 As ListBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtdate As TextBox
    Friend WithEvents txtstat As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtby As TextBox
    Friend WithEvents grd2 As DataGridView
    Friend WithEvents aid As DataGridViewTextBoxColumn
    Friend WithEvents ctrnum As DataGridViewTextBoxColumn
    Friend WithEvents tripnum As DataGridViewTextBoxColumn
    Friend WithEvents stp As DataGridViewTextBoxColumn
    Friend WithEvents cat As DataGridViewTextBoxColumn
    Friend WithEvents subj As DataGridViewTextBoxColumn
    Friend WithEvents emp As DataGridViewTextBoxColumn
    Friend WithEvents comm As DataGridViewTextBoxColumn
    Friend WithEvents dispo As DataGridViewTextBoxColumn
    Friend WithEvents by As DataGridViewTextBoxColumn
    Friend WithEvents deyt As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents ToolStrip0 As ToolStrip
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents addnewtool As ToolStripLabel
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
End Class
