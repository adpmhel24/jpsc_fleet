﻿Imports System.Data.SqlClient
Public Class assessviewemp
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand
    Public frm As String

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Private Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub
    Private Sub assessviewemp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        viewall(login.whse, "")
    End Sub

    Private Sub viewall(ByVal whse As String, ByVal ss As String)
        Try
            grd.Rows.Clear()

            sql = "Select systemid,username,fullname,workgroup from tblusers where status='1' and (whsename='" & whse & "' or whsename='All')"
            If ss <> "" Then
                sql = sql & " and (username like '%" & ss & "%' or fullname like '%" & ss & "%')"
            End If
            sql = sql & " order by workgroup, username, fullname"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grd.Rows.Add(dr("systemid"), dr("username"), dr("fullname"), dr("workgroup"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grd_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd.CellDoubleClick
        If frm = "assessadd" Then
            Dim f As String = grd.Rows(grd.CurrentRow.Index).Cells("full").Value
            For i = 0 To assessadd.list1.Items.Count - 1
                If assessadd.list1.Items(i) = f Then
                    MsgBox("Already added.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
            Next

            assessadd.list1.Items.Add(f)

        ElseIf frm = "assessedit" Then
            Dim f As String = grd.Rows(grd.CurrentRow.Index).Cells("full").Value
            For i = 0 To assessedit.list1.Items.Count - 1
                If assessedit.list1.Items(i) = f Then
                    MsgBox("Already added.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
            Next

            assessedit.list1.Items.Add(f)
        End If

        Me.Dispose()
    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        If Trim(txt.Text) <> "" Then
            viewall(login.whse, Trim(txt.Text.ToString.Replace("'", "''")))
        Else
            MsgBox("Input username.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub txt_TextChanged(sender As Object, e As EventArgs) Handles txt.TextChanged
        If Trim(txt.Text) = "" Then
            viewall(login.whse, "")
        End If
    End Sub

    Private Sub txt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt.KeyPress
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btnsearch.PerformClick()
        End If
    End Sub

    Private Sub grd_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd.CellContentClick

    End Sub
End Class