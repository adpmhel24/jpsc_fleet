﻿Imports System.Data.SqlClient
Module notifs
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub


    Public Sub Counter_notif(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                'Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                mditrip.Timer1.Stop()

                Dim cnt7 As Integer = 0, cnt8 As Integer = 0, cnt9 As Integer = 0, cntpoi As Integer = 0
                If (login.neym <> "LC Accounting Staff" And login.neym <> "AGI Accounting Staff") Then
                    'step 7 pending for more than two days
                    sql = "Select count(tripsumid) as cnt"
                    sql = sql & " from vTripNotifStep7"
                    sql = sql & " where whsename='" & login.whse & "'"
                    command.CommandText = sql
                    cnt7 = command.ExecuteScalar

                    sql = "Select count(tripsumid) as cnt"
                    sql = sql & " from vTripNotifStep8"
                    sql = sql & " where whsename='" & login.whse & "'"
                    sql = sql & " and Arrival is not null"
                    command.CommandText = sql
                    cnt8 = command.ExecuteScalar

                    sql = "Select count(tripnum) as cnt"
                    sql = sql & " from vTripTempPoi"
                    sql = sql & " where whsename='" & login.whse & "'"
                    command.CommandText = sql
                    cntpoi = command.ExecuteScalar
                End If

                sql = "Select count(tripsumid) as cnt"
                sql = sql & " from vTripNotifStep9"
                sql = sql & " where whsename='" & login.whse & "' and DaysDue>=2"
                command.CommandText = sql
                cnt9 = command.ExecuteScalar


                ' Attempt to commit the transaction.
                transaction.Commit()
                'Me.Cursor = Cursors.Default
                If cnt7 > 0 Then
                    mditrip.Step7PendingToolStripMenuItem.Visible = True
                    mditrip.Step7PendingToolStripMenuItem.Text = "Step 7 Pending (" & cnt7 & ")"
                Else
                    mditrip.Step7PendingToolStripMenuItem.Visible = False
                    mditrip.Step7PendingToolStripMenuItem.Text = "Step 7 Pending"
                End If

                If cnt8 > 0 Then
                    mditrip.Step8PendingToolStripMenuItem.Visible = True
                    mditrip.Step8PendingToolStripMenuItem.Text = "Step 8 Pending (" & cnt8 & ")"
                Else
                    mditrip.Step8PendingToolStripMenuItem.Visible = False
                    mditrip.Step8PendingToolStripMenuItem.Text = "Step 8 Pending"
                End If

                If cnt9 > 0 Then
                    mditrip.Step9PendingToolStripMenuItem.Visible = True
                    mditrip.Step9PendingToolStripMenuItem.Text = "Step 9 Pending (" & cnt9 & ")"
                Else
                    mditrip.Step9PendingToolStripMenuItem.Visible = False
                    mditrip.Step9PendingToolStripMenuItem.Text = "Step 9 Pending"
                End If

                If cntpoi > 0 Then
                    mditrip.PendingToolStripMenuItem.Visible = True
                    mditrip.PendingToolStripMenuItem.Text = "Temporary POI (" & cntpoi & ")"
                Else
                    mditrip.PendingToolStripMenuItem.Visible = False
                    mditrip.PendingToolStripMenuItem.Text = "Temporary POI"
                End If


                mditrip.NotificationsToolStripMenuItem.Text = "Notifications (" & cnt7 + cnt8 + cnt9 + cntpoi & ")"

                'mditrip.Timer1.Start()

            Catch ex As Exception
                'Me.Cursor = Cursors.Default
                ' MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    'Me.Cursor = Cursors.Default
                    ' transaction.Rollback()
                Catch ex2 As Exception
                    'Me.Cursor = Cursors.Default
                    ' MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Public Sub Counter_IncidentDrafts(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                'Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                Dim drafts As Integer = 0
                sql = "Select Count(i.caseid) as cnt"
                sql = sql & " from tbltripincident i right outer join tbltripsum s on i.tripnum=s.tripnum"
                sql = sql & " where i.status='1' and i.whsename='" & login.whse & "'"
                command.CommandText = sql
                drafts = command.ExecuteScalar


                Dim forapprov As Integer = 0
                sql = "Select Count(i.caseid) as cnt"
                sql = sql & " from tbltripincident i right outer join tbltripsum s on i.tripnum=s.tripnum"
                sql = sql & " where i.status='2' and i.whsename='" & login.whse & "'"
                command.CommandText = sql
                forapprov = command.ExecuteScalar


                Dim returned As Integer = 0
                sql = "Select Count(i.caseid) as cnt"
                sql = sql & " from tbltripincident i right outer join tbltripsum s on i.tripnum=s.tripnum"
                sql = sql & " where i.status='3' and i.whsename='" & login.whse & "'"
                command.CommandText = sql
                returned = command.ExecuteScalar


                ' Attempt to commit the transaction.
                transaction.Commit()
                'Me.Cursor = Cursors.Default
                If drafts > 0 Then
                    tviolationtripsum.draftstool.Text = "DRAFTS (" & drafts & ")      "
                Else
                    tviolationtripsum.draftstool.Text = "DRAFTS      "
                End If
                If forapprov > 0 Then
                    tviolationtripsum.ApproveToolHead.Text = "For APPROVAL (" & forapprov & ")      "
                Else
                    tviolationtripsum.ApproveToolHead.Text = "For APPROVAL      "
                End If
                If returned > 0 Then
                    tviolationtripsum.reviseTool.Text = "For REVISION (" & forapprov & ")      "
                Else
                    tviolationtripsum.reviseTool.Text = "For REVISION      "
                End If


            Catch ex As Exception
                'Me.Cursor = Cursors.Default
                ' MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    'Me.Cursor = Cursors.Default
                    ' transaction.Rollback()
                Catch ex2 As Exception
                    'Me.Cursor = Cursors.Default
                    ' MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Public Sub Counter_CheckTSR(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                'Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                Dim tsr As Integer = 0
                sql = "Select Count(tsid) as cnt"
                sql = sql & " from tbltruckstatus0 where dateverified is null and whsename='" & login.whse & "' and status<>'3'"
                command.CommandText = sql
                tsr = command.ExecuteScalar


                ' Attempt to commit the transaction.
                transaction.Commit()
                'Me.Cursor = Cursors.Default
                If tsr > 0 Then
                    truckstat.verifytool.Text = "For CHECKING (" & tsr & ")      "
                Else
                    truckstat.verifytool.Text = "For CHECKING      "
                End If

            Catch ex As Exception
                'Me.Cursor = Cursors.Default
                ' MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    'Me.Cursor = Cursors.Default
                    ' transaction.Rollback()
                Catch ex2 As Exception
                    'Me.Cursor = Cursors.Default
                    ' MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub
End Module
