﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.ComponentModel
Imports System.Net
Imports System.Net.WebClient
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports System.Text.Encoding

Public Class motorpool
    Public wctab As String = ""
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Dim ofdstp1 As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim ofdstp2 As New OpenFileDialog With {.Filter = "Images|*.jpg;*.bmp;*.png;*.gif;*.wmf"}
    Dim picstp1 As PictureBox, meronstp1 As Boolean = False
    Dim picstp2 As PictureBox, meronstp2 As Boolean = False
    Dim picstp3 As PictureBox, meronstp3 As Boolean = False
    Dim picstp4 As PictureBox, meronstp4 As Boolean = False
    Private bgw0 As BackgroundWorker, threadEnabled0 As Boolean = False, grdsql0 As String
    Private bgw As BackgroundWorker, threadEnabled As Boolean = False, grdsql As String
    Private bgw2 As BackgroundWorker, threadEnabled2 As Boolean = False, grdsql2 As String
    Private bgw3 As BackgroundWorker, threadEnabled3 As Boolean = False, grdsql3 As String
    Private bgw_1 As BackgroundWorker, threadEnabled_1 As Boolean = False, grdsql_1 As String
    Private bgw_2 As BackgroundWorker, threadEnabled_2 As Boolean = False, grdsql_2 As String
    Dim wid As Int32, widlbl As Int32
    Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer
    Public cnf As Boolean

    Private bgwnot As BackgroundWorker, threadEnablednot As Boolean = False, grdsqlnot As String
    Private bgwava As BackgroundWorker, threadEnabledava As Boolean = False, grdsqlava As String

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Private Sub motorpool_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        plate()
        tripstep0()
    End Sub

    Private Sub motorpool_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dim a As String = MsgBox("Are you sure you want to close?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            'Stop background operation
            If threadEnabled0 = True Then
                If bgw0.IsBusy = True Then
                    If bgw0.WorkerSupportsCancellation = True Then
                        bgw0.CancelAsync()
                    End If
                End If
            End If

            If threadEnabled = True Then
                If bgw.IsBusy = True Then
                    If bgw.WorkerSupportsCancellation = True Then
                        bgw.CancelAsync()
                    End If
                End If
            End If

            If threadEnabled2 = True Then
                If bgw2.IsBusy = True Then
                    If bgw2.WorkerSupportsCancellation = True Then
                        bgw2.CancelAsync()
                    End If
                End If
            End If

            If threadEnabled3 = True Then
                If bgw3.IsBusy = True Then
                    If bgw3.WorkerSupportsCancellation = True Then
                        bgw3.CancelAsync()
                    End If
                End If
            End If

            If threadEnabled_1 = True Then
                If bgw_1.IsBusy = True Then
                    If bgw_1.WorkerSupportsCancellation = True Then
                        bgw_1.CancelAsync()
                    End If
                End If
            End If

            If threadEnabled_2 = True Then
                If bgw_2.IsBusy = True Then
                    If bgw_2.WorkerSupportsCancellation = True Then
                        bgw_2.CancelAsync()
                    End If
                End If
            End If

            If threadEnablednot = True Then
                If bgwnot.IsBusy = True Then
                    If bgwnot.WorkerSupportsCancellation = True Then
                        bgwnot.CancelAsync()
                    End If
                End If
            End If

            If threadEnabledava = True Then
                If bgwava.IsBusy = True Then
                    If bgwava.WorkerSupportsCancellation = True Then
                        bgwava.CancelAsync()
                    End If
                End If
            End If

            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub TabControl1_MouseClick(sender As Object, e As MouseEventArgs) Handles TabControl1.MouseClick
        If TabControl1.SelectedIndex = 0 Then
            wctab = "tab0"
            If grdstep0.Rows.Count = 0 Then
                tripstep1()
            End If
        ElseIf TabControl1.SelectedIndex = 1 Then
            wctab = "tab1"
            If grdstep1.Rows.Count = 0 Then
                tripstep1()
            End If
        ElseIf TabControl1.SelectedIndex = 2 Then
            wctab = "tab2"
            If grdstep2.Rows.Count = 0 Then
                tripstep2()
            End If
        ElseIf TabControl1.SelectedIndex = 3 Then
            wctab = "tab3"
            If grdstep2.Rows.Count = 0 Then
                btnsearch.PerformClick()
            End If
        ElseIf TabControl1.SelectedIndex = 4 Then
            wctab = "tab4"
            If grdnot.Rows.Count = 0 Then
                btnrefnot.PerformClick()
            End If
        ElseIf TabControl1.SelectedIndex = 5 Then
            wctab = "tab5"
            If grdava.Rows.Count = 0 Then
                btnrefava.PerformClick()
            End If
        ElseIf TabControl1.SelectedIndex = 6 Then
            wctab = "tab6"
            If grdapp_com.Rows.Count = 0 Then
                btncompleted.PerformClick()
            End If
        End If
    End Sub
    Private Sub tripstep0()
        Try
            Dim dtServerDateTime As Date
            connect()
            cmd = New SqlCommand("Select CAST(GetDate() as Date)", conn)
            dtServerDateTime = cmd.ExecuteScalar
            datefrom.MaxDate = dtServerDateTime
            conn.Close()

            Me.Cursor = Cursors.WaitCursor
            grp0.Enabled = True
            grdstep0.Rows.Clear()

            sql = "Select mid, platenum, vtype, tcondition, ArrivedTime FROM vMCforInspect"
            sql = sql & " where ArrivedAt='" & login.whse & "' and tcondition='0' order by mid"

            grdsql0 = sql

            bgw0 = New BackgroundWorker()
            bgw0.WorkerSupportsCancellation = True

            AddHandler bgw0.DoWork, New DoWorkEventHandler(AddressOf bgw0_DoWork)
            AddHandler bgw0.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw0_Completed)
            m_addRowDelegate0 = New AddRowDelegate0(AddressOf AddDGVRow0)

            If Not bgw0.IsBusy Then
                lblload0.Visible = True
                bgw0.WorkerReportsProgress = True
                bgw0.WorkerSupportsCancellation = True
                bgw0.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub bgw0_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabled0 = True

        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If

        Dim cmdx As SqlCommand = New SqlCommand(grdsql0, connection)
        Dim drx As SqlDataReader = cmdx.ExecuteReader
        While drx.Read
            If bgw0.CancellationPending = True Then
                e.Cancel = True
                Exit Sub
            Else
                AddDGVRow0(drx("mid"), drx("platenum"), drx("vtype"), Format(drx("ArrivedTime"), "MM/dd hh:mm tt"))
            End If
        End While
        drx.Dispose()
        cmdx.Dispose()
        connection.Close()
    End Sub

    Delegate Sub AddRowDelegate0(ByVal value0 As Object, ByVal value1 As Object, ByVal value2 As Object, ByVal value3 As Object)
    Private m_addRowDelegate0 As AddRowDelegate0

    Private Sub grdstep0_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdstep0.CellContentClick

    End Sub

    Private Sub AddDGVRow0(ByVal val0 As Integer, ByVal val1 As String, ByVal val2 As String, ByVal val3 As String)
        If threadEnabled0 = True Then
            If Me.InvokeRequired Then
                Me.BeginInvoke(New AddRowDelegate0(AddressOf AddDGVRow0), val0, val1, val2, val3)
            Else
                grdstep0.Rows.Add(val0, val1, val2, val3)
            End If
        End If
    End Sub

    Private Sub bgw0_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        '/lblloading.Visible = False
        If e.Error IsNot Nothing Then
            Me.Cursor = Cursors.Default
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            Me.Cursor = Cursors.Default
            MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            Me.Cursor = Cursors.Default
            'If whatstep = 1 Then
            grdstep0.SuspendLayout()
            grdstep0.ResumeLayout()
            gstep0.Enabled = True
            lblload0.Visible = False
            If grdstep0.Rows.Count = 0 Then
                zero0()
                grp0.Enabled = False
            Else
                grp0.Enabled = True
                Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                grdstep0.Rows(0).Cells(1).Selected = True
                grdstep0_CellClick(grdstep1, eventArgs)
            End If
            ' End If
            '/Me.WindowState = FormWindowState.Maximized
        End If
    End Sub

    Private Sub zero0()
        lblplate0.Text = ""
        lbltype0.Text = ""
        btnstartfor.Text = "TIME START CHECK-UP"
        btnstartfor.Enabled = True
    End Sub

    Private Sub tripstep1()
        Try
            Dim dtServerDateTime As Date
            connect()
            cmd = New SqlCommand("Select CAST(GetDate() as Date)", conn)
            dtServerDateTime = cmd.ExecuteScalar
            datefrom.MaxDate = dtServerDateTime
            conn.Close()


            Me.Cursor = Cursors.WaitCursor
            grp1.Enabled = True
            grdstep1.Rows.Clear()

            sql = "Select mid, platenum, vtype, tcondition, ArrivedTime FROM vMCforInspect"
            sql = sql & " where ArrivedAt='" & login.whse & "' and tcondition='1' order by mid"

            grdsql = sql

            bgw = New BackgroundWorker()
            bgw.WorkerSupportsCancellation = True

            AddHandler bgw.DoWork, New DoWorkEventHandler(AddressOf bgw_DoWork)
            AddHandler bgw.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw_Completed)
            AddHandler bgw.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw_ProgressChanged)
            m_addRowDelegate = New AddRowDelegate(AddressOf AddDGVRow)

            If Not bgw.IsBusy Then
                lblload1.Visible = True
                bgw.WorkerReportsProgress = True
                bgw.WorkerSupportsCancellation = True
                bgw.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub bgw_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabled = True

        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If

        Dim cmdx As SqlCommand = New SqlCommand(grdsql, connection)
        Dim drx As SqlDataReader = cmdx.ExecuteReader
        While drx.Read
            If bgw.CancellationPending = True Then
                e.Cancel = True
                Exit Sub
            Else
                AddDGVRow(drx("mid"), drx("platenum"), drx("vtype"), Format(drx("ArrivedTime"), "MM/dd hh:mm tt"))
            End If
        End While
        drx.Dispose()
        cmdx.Dispose()
        connection.Close()
    End Sub

    Delegate Sub AddRowDelegate(ByVal value0 As Object, ByVal value1 As Object, ByVal value2 As Object, ByVal value3 As Object)
    Private m_addRowDelegate As AddRowDelegate

    Private Sub grdstep1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdstep1.CellContentClick

    End Sub

    Private Sub AddDGVRow(ByVal val0 As Integer, ByVal val1 As String, ByVal val2 As String, ByVal val3 As String)
        If threadEnabled = True Then
            If Me.InvokeRequired Then
                Me.BeginInvoke(New AddRowDelegate(AddressOf AddDGVRow), val0, val1, val2, val3)
            Else
                grdstep1.Rows.Add(val0, val1, val2, val3)
            End If
        End If
    End Sub

    Private Sub bgw_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        '/lblloading.Visible = False
        If e.Error IsNot Nothing Then
            Me.Cursor = Cursors.Default
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            Me.Cursor = Cursors.Default
            MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            Me.Cursor = Cursors.Default
            'If whatstep = 1 Then
            grdstep1.SuspendLayout()
                grdstep1.ResumeLayout()
                gstep1.Enabled = True
                lblload1.Visible = False
                If grdstep1.Rows.Count = 0 Then
                    zero1()
                    grp1.Enabled = False
                Else
                    grp1.Enabled = True
                    Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                    grdstep1.Rows(0).Cells(1).Selected = True
                    grdstep1_CellClick(grdstep1, eventArgs)
                End If
            ' End If
            '/Me.WindowState = FormWindowState.Maximized
        End If
    End Sub

    Private Sub btnrefstep1_Click(sender As Object, e As EventArgs) Handles btnrefstep1.Click
        tripstep1()
    End Sub

    Private Sub bgw_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label12.Text = e.ProgressPercentage.ToString() & "% complete"
        gstep1.Enabled = False
        lblload1.Visible = True
    End Sub

    Private Sub btnstartpre_Click(sender As Object, e As EventArgs) Handles btnstartpre.Click
        Try
            If login.neym <> "Motorpool Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If checkcompleted(lblplate1.Tag) = True Then
                Me.Cursor = Cursors.Default
                MsgBox(lblplate1.Text & " is already check-up. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            cnf = False
            confirmchecker.GroupBox1.Text = login.neym
            confirmchecker.btncnf = False
            confirmchecker.tripnumber = ""
            confirmchecker.ShowDialog()
            If cnf = True Then
                StartStep1(strconn, confirmchecker.checkerneym)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub StartStep1(ByVal connectionString As String, ByVal startedby As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim drstep As SqlDataReader
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                Dim xx As Boolean = False
                command.CommandText = "Select c.tcondition,c.chknum,i.startdate,i.remsinspect from tblmscheckup c"
                command.CommandText = command.CommandText & " left outer join tblmsinspect i On c.mid=i.mid where c.mid='" & lblplate1.Tag & "' And c.tcondition='1'"
                drstep = command.ExecuteReader
                If drstep.Read Then
                    If IsDBNull(drstep("startdate")) = False Then
                        Dim starttime As Date = CDate(drstep("startdate").ToString)
                        btnstartpre.Text = "TIME START CHECK-UP: " & Format(starttime, "HH:mm")
                        txtrems1.Text = drstep("remsinspect").ToString
                        txtchk.Text = drstep("chknum").ToString
                        startprefalse()
                        btnimgadd1.Enabled = True
                        btnexempt1.Enabled = True
                        btnconfirm1.Enabled = True
                        btnrepair.Enabled = True
                        xx = True
                    End If
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Refresh list.", MsgBoxStyle.Information, "")
                    grp1.Enabled = False
                    Exit Sub
                End If
                drstep.Dispose()

                If xx = False Then
                    command.CommandText = "Insert into tblmsinspect (mid,startby,startdate,frm) values (@mid,@startby,GetDate(),'Inspection')"
                    command.Parameters.AddWithValue("@mid", lblplate1.Tag)
                    command.Parameters.AddWithValue("@startby", startedby)
                    command.ExecuteNonQuery()

                    command.CommandText = "Update tblmscheckup set tcondition=@tcon where mid=@mid1"
                    command.Parameters.AddWithValue("@tcon", "1")
                    command.Parameters.AddWithValue("@mid1", lblplate1.Tag)
                    command.ExecuteNonQuery()
                End If

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

                If xx = False Then
                    SelectStep1(strconn)
                    imgcancelfalse1()
                    startprefalse()
                End If

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
            End Try
        End Using
    End Sub

    Private Sub imgcancelfalse1()
        cmbimg1.Text = ""
        lblimgdate1.Text = ""
        lblimgname1.Text = ""
        btnimgadd1.Text = "Add Photo"
        btnimgrename1.Text = "Rename"
        btnimgadd1.Enabled = True
        btnimgrename1.Enabled = True
        btnimgremove1.Enabled = True
        btnimgcancel1.Enabled = False
        btnimgdl1.Enabled = True
        btnimgfull1.Enabled = True
        btnimgrefresh1.Enabled = True
        btnexempt1.Enabled = True
        btnconfirm1.Enabled = True
    End Sub
    Private Function checkcompleted(ByVal mid As String) As Boolean
        Try
            Dim completedstep As Boolean = False
            sql = "Select mid from tblmscheckup where mid='" & mid & "' and (tcondition='2')" ' or tcondition='3'
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                completedstep = True
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Return completedstep

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Function

    Private Sub btnimgadd1_Click(sender As Object, e As EventArgs) Handles btnimgadd1.Click
        Try
            If login.neym <> "Motorpool Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If checkcompleted(lblplate1.Tag) = True Then
                Me.Cursor = Cursors.Default
                MsgBox(lblplate1.Text & " is already inspected. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgadd1.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofdstp1.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox1.Image = Nothing
                    Dim bmp As New Bitmap(ofdstp1.FileName)
                    imgbox1.Image = bmp

                    '/imgbox1.Image = LoadImage(ofdstp1.FileName)
                    cmbimg1.Text = ofdstp1.SafeFileName.ToString.Replace("'", "")
                    cmbimg1.Enabled = True
                    cmbimg1.Focus()

                    lblCompressionLevel.Text = ""

                    ' Display the file's size.
                    Dim file_info As New FileInfo(ofdstp1.FileName)
                    lblOriginalSize.Text = FormatBytes(file_info.Length)
                    If Microsoft.VisualBasic.Right(ofdstp1.FileName.ToString, 3) = "png" Then
                        lblDesiredSize.Text = FormatBytes(file_info.Length * 0.3)
                    Else
                        lblDesiredSize.Text = "1.10 MB" 'FormatBytes(file_info.Length * 0.4)
                    End If
                    lblCompressedSize.Text = ""
                    lblCompressionLevel.Text = ""

                    Me.Cursor = Cursors.Default
                    imgpanel1.Enabled = False
                    '/enabletab4only()
                    imgcanceltrue1()
                    btnimgadd1.Enabled = True
                    btnimgadd1.Text = "Save"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(cmbimg1.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg1.Focus()
                    Exit Sub
                End If

                If cmbimg1.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photoname.", MsgBoxStyle.Exclamation, "")
                    cmbimg1.Text = ""
                    cmbimg1.Focus()
                    Exit Sub
                End If

                Dim origsize As String = lblOriginalSize.Text
                If Val(origsize.Substring(0, origsize.Length - 2)) > 1 And Microsoft.VisualBasic.Right(origsize, 2) = "MB" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Image exceeds the maximum file size 1MB." & vbCrLf & "Compressing image. Please wait.", MsgBoxStyle.Information)

                    Button3.PerformClick()
                    pgbar1.Visible = True

                    'COMPRESS IMAGE THEN REPLACE IMGBOX1.IMAGE NG COMPRESSED NA IMAGE
                    imgbox1.Image = compressimage(imgbox1.Image, Trim(cmbimg1.Text))
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.WaitCursor
                'insert photo in tblimg
                'search image name if existing
                conn.Open()
                '/connect()
                sql = "Select img.name from tblmsinspect ins right outer join tblmsimg img on ins.pid=img.pid"
                sql = sql & " where ins.pid=(Select top 1 pid from tblmsinspect where mid=ins.mid order by pid DESC) And ins.mid='" & lblplate1.Tag & "' and img.name='" & Trim(cmbimg1.Text) & "'"
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg1.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg1.Focus()

                    pgbar1.Value = 0
                    pgbar1.Visible = False
                    Exit Sub
                Else
                    Dim ms As New MemoryStream()

                    'save record in database
                    connect()
                    '/cmd = New SqlCommand("Insert into tbldispatchstp1 values(@tripnum,@name,@img,@status,@datecreated,@createdby)", conn)
                    cmd = New SqlCommand("Insert into tblmsimg values((Select top 1 pid from tblmsinspect where mid='" & lblplate1.Tag & "' order by pid DESC),@name,@img,@status,GetDate(),@createdby)", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(cmbimg1.Text)))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                    imgbox1.Image.Save(ms, Imaging.ImageFormat.Jpeg)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                    cmd.ExecuteNonQuery()
                    conn.Close()

                    pgbar1.Value = 0
                    pgbar1.Visible = False

                    MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    pgbar1.Value = 0
                    imgbox1.Image = Nothing
                    imgbox1.BackColor = Color.Empty
                    imgbox1.Invalidate()
                    ms.Close()
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.Default
                btnimgadd1.Text = "Add Photo"
                imgcancelfalse1()
                imgpanel1.Enabled = True
                '/enableall()
                btnimgrefresh1.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub
    Public Sub imgcanceltrue1()
        btnimgadd1.Enabled = False
        btnimgrename1.Enabled = False
        btnimgremove1.Enabled = False
        btnimgcancel1.Enabled = True
        btnimgdl1.Enabled = False
        btnimgfull1.Enabled = True
        btnimgrefresh1.Enabled = False
    End Sub
    Private Function compressimage(ByVal picimage As Image, ByVal picname As String)

        Me.Cursor = Cursors.WaitCursor
        Dim desired_size As Double = FormattedBytesToBytes(lblDesiredSize.Text)
        '/MsgBox(desired_size)
        If desired_size > 10 Then
            lblCompressionLevel.Text = ""
            lblCompressedSize.Text = ""

            Dim file_name As String = picname
            Dim file_size As Long
            For compression_level As Integer = 100 To 10 Step -1
                ' Save the file into a memory stream.
                Dim memory_stream As MemoryStream = SaveJpegIntoStream(picimage, compression_level)

                ' See how big it is.
                file_size = memory_stream.Length
                If file_size <= desired_size Then
                    ' Display the final size and image.
                    ' Save the file.
                    '/My.Computer.FileSystem.WriteAllBytes(file_name, memory_stream.ToArray(), False)
                    Dim ms As New MemoryStream(memory_stream.ToArray())
                    picimage = Image.FromStream(ms)
                    '/picNew.Image = LoadImage(file_name)
                    lblCompressionLevel.Text = compression_level
                    lblCompressedSize.Text = FormatBytes(file_size)
                    Exit For
                End If
            Next
            Me.Cursor = Cursors.Default
        End If

        Return picimage

        If desired_size < 10 Then
            MessageBox.Show("Invalid desired size.", "Invalid Size", MessageBoxButtons.OK, MessageBoxIcon.Error)
            lblDesiredSize.Focus()
        End If

    End Function

    Private Sub btnimgrename1_Click(sender As Object, e As EventArgs) Handles btnimgrename1.Click
        Try
            If login.neym <> "Motorpool Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If checkcompleted(lblplate1.Tag) = True Then
                Me.Cursor = Cursors.Default
                MsgBox(lblplate1.Text & " is already inspected. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgrename1.Text = "Rename" Then
                If Trim(cmbimg1.Text) <> "" And imgbox1.Image IsNot Nothing Then
                    Dim tempname As String = Trim(cmbimg1.Text)
                    If tempname.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Cannot rename photo.", MsgBoxStyle.Exclamation, "")
                        cmbimg1.Focus()
                        Exit Sub
                    End If
                    cmbimg1.Enabled = True
                    cmbimg1.Focus()
                ElseIf Trim(cmbimg1.Text) = "" And imgbox1.Image IsNot Nothing Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg1.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    cmbimg1.Focus()
                    Exit Sub
                End If

                imgpanel1.Enabled = False
                imgcanceltrue1()
                btnimgrename1.Enabled = True
                btnimgrename1.Text = "Save"
            Else
                'search image name if existing
                connect()
                sql = "Select img.name from tblmsinspect ins right outer join tblmsimg img on ins.pid=img.pid"
                sql = sql & " where ins.pid=(Select top 1 pid from tblmsinspect where mid=ins.mid order by pid DESC) And ins.mid='" & lblplate1.Tag & "' and img.name='" & Trim(cmbimg1.Text) & "'"
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg1.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg1.Focus()
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                Me.Cursor = Cursors.Default

                If cmbimg1.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photo name.", MsgBoxStyle.Exclamation, "")
                    cmbimg1.Text = ""
                    cmbimg1.Focus()
                    Exit Sub
                End If

                'irename.. update yung name lng where imgid = lblimgid.text
                sql = "Update tblmsimg set name='" & Trim(cmbimg1.Text) & "' where iid='" & lblimgid1.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                btnimgrename1.Text = "Rename"
                imgcancelfalse1()
                imgpanel1.Enabled = True
                btnimgrefresh1.PerformClick()
                Me.Cursor = Cursors.Default
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub btnimgremove1_Click(sender As Object, e As EventArgs) Handles btnimgremove1.Click
        Try
            If login.neym <> "Motorpool Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If checkcompleted(lblplate1.Tag) = True Then
                Me.Cursor = Cursors.Default
                MsgBox(lblplate1.Text & " is already inspected. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(cmbimg1.Text) <> "" And imgbox1.Image IsNot Nothing Then
                Me.Cursor = Cursors.Default

                If cmbimg1.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot delete signature", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2)
                If a = vbYes Then
                    'delete image where imgid=lblimgid.text
                    sql = "Delete from tblmsimg where iid='" & lblimgid1.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully removed.", MsgBoxStyle.Information, "")

                    imgcancelfalse1()
                    imgpanel1.Enabled = True
                    btnimgrefresh1.PerformClick()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                cmbimg1.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub btnimgcancel1_Click(sender As Object, e As EventArgs) Handles btnimgcancel1.Click
        imgpanel1.Enabled = True
        imgbox1.Image = Nothing
        cmbimg1.Text = ""
        lblimgid1.Text = ""
        imgcancelfalse1()

        If meronstp1 = False Then
            btnimgrename1.Enabled = False
            btnimgremove1.Enabled = False
            btnimgcancel1.Enabled = False
            btnimgdl1.Enabled = False
            btnimgfull1.Enabled = False
        Else
            imgcancelfalse1()
        End If
    End Sub

    Private Sub btnimgfull1_Click(sender As Object, e As EventArgs) Handles btnimgfull1.Click
        If lblimgid1.Text <> "" Or imgbox1.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox1.Image
            viewimage.lblimgname.Text = cmbimg1.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub btnimgrefresh1_Click(sender As Object, e As EventArgs) Handles btnimgrefresh1.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meronstp1 = False
            imgpanel1.Visible = False
            imgpanel1.Controls.Clear()
            imgpanel1.Visible = True

            Dim ctr As Integer = 0
            sql = "Select img.* from tblmsinspect ins right outer join tblmsimg img on ins.pid=img.pid"
            sql = sql & " where ins.pid=(Select top 1 pid from tblmsinspect where mid=ins.mid order by pid DESC) And ins.mid='" & lblplate1.Tag & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                meronstp1 = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                picstp1 = New PictureBox
                picstp1.Image = Image.FromStream(ms)
                ms.Dispose()
                picstp1.SizeMode = PictureBoxSizeMode.Zoom
                picstp1.SetBounds(wid, y, 104, 100)
                'picstp1.BackColor = Color.AliceBlue
                picstp1.Tag = dr("iid")
                picstp1.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler picstp1.Click, AddressOf convertPic1
                imgpanel1.Controls.Add(picstp1)
                imgpanel1.Controls.Add(lbl)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            imgbox1.Image = Nothing
            cmbimg1.Text = ""
            lblimgid1.Text = ""
            lblimgdate1.Text = ""
            lblimgname1.Text = ""

            Me.Cursor = Cursors.Default

            If meronstp1 = False Then
                btnimgrename1.Enabled = False
                btnimgremove1.Enabled = False
                btnimgcancel1.Enabled = False
                btnimgdl1.Enabled = False
                btnimgfull1.Enabled = False
                btnconfirm1.Enabled = False
            Else
                imgcancelfalse1()
            End If

            If grdstep1.Rows.Count = 0 Then
                grp1.Enabled = False
            Else
                grp1.Enabled = True
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Sub convertPic1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            picstp1 = CType(sender, PictureBox)
            imgbox1.Image = picstp1.Image
            lblimgid1.Text = picstp1.Tag

            sql = "Select name,datecreated,createdby from tblmsimg where iid='" & lblimgid1.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbimg1.Text = dr("name")
                If IsDBNull(dr("datecreated")) = False Then
                    lblimgdate1.Text = Format(dr("datecreated"), "MM/dd/yyyy h:mm tt")
                Else
                    lblimgdate1.Text = ""
                End If
                lblimgname1.Text = dr("createdby").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub btnconfirm1_Click(sender As Object, e As EventArgs) Handles btnconfirm1.Click
        Try
            If login.neym <> "Motorpool Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If checkcompleted(lblplate1.Tag) = True Then
                Me.Cursor = Cursors.Default
                MsgBox(lblplate1.Text & " is already inspected. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL1 HAS CONTROLS
            If imgpanel1.Controls.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            'txtchk.Text = txtchk.Text.ToString.Replace("'", "")
            'If Trim(txtchk.Text) = "" Then
            '    Me.Cursor = Cursors.Default
            '    MsgBox("Input Checklist#.", MsgBoxStyle.Exclamation, "")
            '    txtchk.Focus()
            '    Exit Sub
            'End If

            cnf = False
            confirmchecker.GroupBox1.Text = login.neym
            confirmchecker.btncnf = False
            confirmchecker.tripnumber = ""
            confirmchecker.ShowDialog()
            If cnf = True Then
                FinishStep1(strconn, 2, confirmchecker.checkerneym)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub FinishStep1(ByVal connectionString As String, ByVal tcon As Integer, ByVal finishby As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim drstep As SqlDataReader
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                'generate checklist#

                Dim trnum As String = "1", temp As String = ""
                'check kung pang ilang tripnum NA SA YEAR NA 2018 na
                command.CommandText = "select count(m.mid) from tblmscheckup m right join tbltripsum s on s.tripnum=m.tripnum"
                command.CommandText = command.CommandText & " where s.tripyear=year(GetDate()) and s.whsename='" & login.whse & "' and m.tcondition=2"
                trnum = command.ExecuteScalar + 1

                Dim prefix As String = ""
                sql = "Select whsecode from tblwhse where whsename='" & login.whse & "' and status='1'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    prefix = dr("whsecode")
                End If
                dr.Dispose()

                'If trnum < 1000000 Then
                '    For vv As Integer = 1 To 6 - trnum.Length
                '        temp += "0"
                '    Next
                'End If

                txtchk.Text = "MM." & prefix & "-" & Format(Date.Now, "yy") & "-" & temp & trnum

                'update tblmsinspect
                command.CommandText = "Update tblmscheckup set tcondition=@tcon, chknum=@chknum where mid=@mid and tcondition='1'"
                command.Parameters.AddWithValue("@tcon", tcon)
                command.Parameters.AddWithValue("@chknum", Trim(txtchk.Text.ToString.Replace("'", "")))
                command.Parameters.AddWithValue("@mid", lblplate1.Tag)
                command.ExecuteNonQuery()

                command.CommandText = "Update tblmsinspect set finishby=@finishby, finishdate=GetDate(), remsinspect=@rems, tcondition=@tcon1, chknum=@chknum1"
                command.CommandText = command.CommandText & " where mid=@mid1 and finishdate is null"
                command.Parameters.AddWithValue("@finishby", finishby)
                command.Parameters.AddWithValue("@rems", Trim(txtrems1.Text.ToString.Replace("'", "''")))
                command.Parameters.AddWithValue("@tcon1", tcon)
                command.Parameters.AddWithValue("@chknum1", Trim(txtchk.Text.ToString.Replace("'", "")))
                command.Parameters.AddWithValue("@mid1", lblplate1.Tag)
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

                Dim tconstat As String
                If tcon = 2 Then
                    tconstat = "GOOD CONDITION"
                ElseIf tcon = 3 Then
                    tconstat = "FOR REPAIR"
                End If
                MsgBox(lblplate1.Text & " - " & tconstat, MsgBoxStyle.Information, "")
                zero1()
                tripstep1()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
            End Try
        End Using
    End Sub

    Private Sub btnrepair_Click(sender As Object, e As EventArgs) Handles btnrepair.Click
        Try
            If login.neym <> "Motorpool Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If checkcompleted(lblplate1.Tag) = True Then
                Me.Cursor = Cursors.Default
                MsgBox(lblplate1.Text & " is already inspected. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL1 HAS CONTROLS
            If imgpanel1.Controls.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            txtchk.Text = txtchk.Text.ToString.Replace("'", "")
            If Trim(txtchk.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Input Checklist#.", MsgBoxStyle.Exclamation, "")
                txtchk.Focus()
                Exit Sub
            End If

            cnf = False
            confirmchecker.GroupBox1.Text = login.neym
            confirmchecker.btncnf = False
            confirmchecker.tripnumber = ""
            confirmchecker.ShowDialog()
            If cnf = True Then
                FinishStep1(strconn, 3, confirmchecker.checkerneym)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub btnrefstep2_Click(sender As Object, e As EventArgs) Handles btnrefstep2.Click
        tripstep2()
    End Sub
    Private Sub tripstep2()
        Try
            Me.Cursor = Cursors.WaitCursor
            grp2.Enabled = True
            grdstep2.Rows.Clear()

            sql = "Select mid, platenum, vtype, ArrivedTime FROM vMCforRepair"
            sql = sql & " where ArrivedAt='" & login.whse & "' order by mid"

            grdsql2 = sql

            bgw2 = New BackgroundWorker()
            bgw2.WorkerSupportsCancellation = True

            AddHandler bgw2.DoWork, New DoWorkEventHandler(AddressOf bgw2_DoWork)
            AddHandler bgw2.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw2_Completed)
            AddHandler bgw2.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw2_ProgressChanged)
            m_addRowDelegate2 = New AddRowDelegate2(AddressOf AddDGVRow2)

            If Not bgw2.IsBusy Then
                lblload2.Visible = True
                bgw2.WorkerReportsProgress = True
                bgw2.WorkerSupportsCancellation = True
                bgw2.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub bgw2_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabled2 = True

        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If

        Dim cmdx As SqlCommand = New SqlCommand(grdsql2, connection)
        Dim drx As SqlDataReader = cmdx.ExecuteReader
        While drx.Read
            If bgw2.CancellationPending = True Then
                e.Cancel = True
                Exit Sub
            End If

            AddDGVRow2(drx("mid"), drx("platenum"), drx("vtype"), Format(drx("ArrivedTime"), "MM/dd hh:mm tt"))
            'End If
        End While
        drx.Dispose()
        cmdx.Dispose()
        connection.Close()
    End Sub

    Delegate Sub AddRowDelegate2(ByVal value0 As Object, ByVal value1 As Object, ByVal value2 As Object, ByVal value3 As Object)
    Private m_addRowDelegate2 As AddRowDelegate2

    Private Sub AddDGVRow2(ByVal val0 As Integer, ByVal val1 As String, ByVal val2 As String, ByVal val3 As String)
        If threadEnabled2 = True Then
            If Me.InvokeRequired Then
                Me.BeginInvoke(New AddRowDelegate2(AddressOf AddDGVRow2), val0, val1, val2, val3)
            Else
                grdstep2.Rows.Add(val0, val1, val2, val3)
            End If
        End If
    End Sub

    Private Sub bgw2_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label12.Text = e.ProgressPercentage.ToString() & "% complete"
        gstep2.Enabled = False
        lblload2.Visible = True
    End Sub

    Private Sub grdstep2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdstep2.CellContentClick

    End Sub

    Private Sub bgw2_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        '/lblloading.Visible = False
        If e.Error IsNot Nothing Then
            Me.Cursor = Cursors.Default
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            Me.Cursor = Cursors.Default
            MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            Me.Cursor = Cursors.Default
            grdstep2.SuspendLayout()
            grdstep2.ResumeLayout()
            gstep2.Enabled = True
            lblload2.Visible = False
            If grdstep2.Rows.Count = 0 Then
                zero2()
                grp2.Enabled = False
            Else
                grp2.Enabled = True
                Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                grdstep2.Rows(0).Cells(1).Selected = True
                grdstep2_CellClick(grdstep2, eventArgs)
            End If
        End If
    End Sub

    Private Sub zero1()
        lblplate1.Text = ""
        lbltype1.Text = ""
        txtrems1.Text = ""
        txtchk.Text = ""
        lblstart.Text = ""
        btnstartpre.Text = "TIME START CHECK-UP"

        btnimgadd1.Text = "Add Photo"
        btnimgrename1.Text = "Rename"
        btnimgadd1.Enabled = False
        btnimgremove1.Enabled = False
        btnimgcancel1.Enabled = False
        btnimgrename1.Enabled = False
        btnimgfull1.Enabled = False
        'btnimgrefresh1.Enabled = False
        btnconfirm1.Enabled = False
        btnrepair.Enabled = False
        btnexempt1.Enabled = False

        imgpanel1.Visible = False
        imgpanel1.Controls.Clear()
        imgpanel1.Visible = True
    End Sub

    Private Sub grdstep1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdstep1.CellClick
        Try
            zero1()
            grp1.Enabled = False
            Me.Cursor = Cursors.WaitCursor

            lblplate1.Tag = grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(0).Value
            lblplate1.Text = grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(1).Value
            lbltype1.Text = grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(2).Value

            SelectStep1(strconn)

            btnimgrefresh1.PerformClick()

            grp1.Text = "Photos"

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.message & vbcrlf & vbcrlf & ex.stacktrace, MsgBoxStyle.Information)
        End Try
    End Sub
    Private Sub SelectStep1(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim drstep As SqlDataReader
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                btnstartpre.Text = "TIME START CHECK-UP"
                command.CommandText = "Select top 1 c.tcondition,i.chknum,i.startby,i.startdate,i.remsinspect from tblmscheckup c"
                command.CommandText = command.CommandText & " left outer join tblmsinspect i On c.mid=i.mid where c.mid='" & lblplate1.Tag & "' And c.tcondition='1'"
                command.CommandText = command.CommandText & " order by pid DESC"
                drstep = command.ExecuteReader
                If drstep.Read Then
                    grp1.Enabled = True
                    If IsDBNull(drstep("startdate")) = False Then
                        btnstartpre.Text = "TIME START CHECK-UP: " & Format(drstep("startdate"), "HH:mm")
                        txtrems1.Text = drstep("remsinspect").ToString
                        txtchk.Text = drstep("chknum").ToString
                        lblstart.Text = drstep("startby").ToString
                        startprefalse()
                        btnimgadd1.Enabled = True
                        btnexempt1.Enabled = True
                        btnconfirm1.Enabled = True
                        btnrepair.Enabled = True
                    Else
                        btnstartpre.Enabled = True
                        txtrems1.Enabled = False
                        txtrems1.Text = ""
                        txtchk.Enabled = False
                        txtchk.Text = ""
                        lblstart.Text = ""
                        btnimgadd1.Enabled = False
                        btnexempt1.Enabled = False
                    End If
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Refresh list.", MsgBoxStyle.Information, "")
                    grp1.Enabled = False
                End If
                drstep.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
            End Try
        End Using
    End Sub

    Private Sub btnstartdiesel_Click(sender As Object, e As EventArgs) Handles btnstartdiesel.Click
        Try
            If login.neym <> "Motorpool Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If checkcompleted(lblplate2.Tag) = True Then
                Me.Cursor = Cursors.Default
                MsgBox(lblplate2.Text & " is already inspected. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            cnf = False
            confirmchecker.GroupBox1.Text = login.neym
            confirmchecker.btncnf = False
            confirmchecker.tripnumber = ""
            confirmchecker.ShowDialog()
            If cnf = True Then
                StartStep2(strconn, confirmchecker.checkerneym)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub
    Private Sub StartStep2(ByVal connectionString As String, ByVal startedby As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim drstep As SqlDataReader
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                Dim xx As Boolean = False
                command.CommandText = "Select c.tcondition,i.startdate,i.remsinspect from tblmscheckup c"
                command.CommandText = command.CommandText & " left outer join tblmsinspect i On c.mid=i.mid and i.finishdate is null"
                command.CommandText = command.CommandText & " where c.mid='" & lblplate2.Tag & "' And c.tcondition='3'"
                drstep = command.ExecuteReader
                If drstep.Read Then
                    If IsDBNull(drstep("startdate")) = False Then
                        Dim starttime As Date = CDate(drstep("startdate").ToString)
                        btnstartdiesel.Text = "TIME START CHECK-UP: " & Format(starttime, "HH:mm")
                        txtrems2.Text = drstep("remsinspect").ToString
                        startdieselfalse()
                        btnimgadd2.Enabled = True
                        btnconfirm2.Enabled = True
                        xx = True
                    End If
                End If
                drstep.Dispose()

                If xx = False Then
                    command.CommandText = "Insert into tblmsinspect (mid,startby,startdate,frm) values (@mid,@startby,GetDate(),'Under Repair')"
                    command.Parameters.AddWithValue("@mid", lblplate2.Tag)
                    command.Parameters.AddWithValue("@startby", startedby)
                    command.ExecuteNonQuery()
                End If

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                btnstartdiesel.Text = "TIME START CHECK-UP: " & Format(Date.Now, "HH:mm")
                startdieselfalse()
                btnimgadd2.Enabled = True
                btnconfirm2.Enabled = True

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
            End Try
        End Using
    End Sub
    Public Sub imgcancelfalse2()
        cmbimg2.Text = ""
        lblimgdate2.Text = ""
        lblimgname2.Text = ""
        btnimgadd2.Text = "Add Photo"
        btnimgrename2.Text = "Rename"
        btnimgadd2.Enabled = True
        btnimgrename2.Enabled = True
        btnimgremove2.Enabled = True
        btnimgcancel2.Enabled = False
        btnimgdl2.Enabled = True
        btnimgfull2.Enabled = True
        btnimgrefresh2.Enabled = True
        btnconfirm2.Enabled = True
    End Sub

    Private Sub btnimgadd2_Click(sender As Object, e As EventArgs) Handles btnimgadd2.Click
        Try
            If login.neym <> "Motorpool Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If checkcompleted(lblplate2.Tag) = True Then
                Me.Cursor = Cursors.Default
                MsgBox(lblplate2.Text & " is already inspected. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgadd2.Text = "Add Photo" Then
                '  ofd.Multiselect = True
                If ofdstp2.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    imgbox2.Image = Nothing
                    Dim bmp As New Bitmap(ofdstp2.FileName)
                    imgbox2.Image = bmp

                    '/imgbox2.Image = LoadImage(ofdstp2.FileName)
                    cmbimg2.Text = ofdstp2.SafeFileName.ToString.Replace("'", "")
                    cmbimg2.Enabled = True
                    cmbimg2.Focus()

                    lblCompressionLevel.Text = ""

                    ' Display the file's size.
                    Dim file_info As New FileInfo(ofdstp2.FileName)
                    lblOriginalSize.Text = FormatBytes(file_info.Length)
                    If Microsoft.VisualBasic.Right(ofdstp2.FileName.ToString, 3) = "png" Then
                        lblDesiredSize.Text = FormatBytes(file_info.Length * 0.3)
                    Else
                        lblDesiredSize.Text = "1.10 MB" 'FormatBytes(file_info.Length * 0.4)
                    End If
                    lblCompressedSize.Text = ""
                    lblCompressionLevel.Text = ""

                    Me.Cursor = Cursors.Default
                    imgpanel2.Enabled = False
                    '/enabletab4only()
                    imgcanceltrue2()
                    btnimgadd2.Enabled = True
                    btnimgadd2.Text = "Save"
                Else
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            Else
                If Trim(cmbimg2.Text) = "" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg2.Focus()
                    Exit Sub
                End If

                If cmbimg2.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photoname.", MsgBoxStyle.Exclamation, "")
                    cmbimg2.Text = ""
                    cmbimg2.Focus()
                    Exit Sub
                End If

                Dim origsize As String = lblOriginalSize.Text
                If Val(origsize.Substring(0, origsize.Length - 2)) > 1 And Microsoft.VisualBasic.Right(origsize, 2) = "MB" Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Image exceeds the maximum file size 1MB." & vbCrLf & "Compressing image. Please wait.", MsgBoxStyle.Information)

                    Button3.PerformClick()
                    pgbar2.Visible = True

                    'COMPRESS IMAGE THEN REPLACE IMGBOX2.IMAGE NG COMPRESSED NA IMAGE
                    imgbox2.Image = compressimage(imgbox2.Image, Trim(cmbimg2.Text))
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.WaitCursor
                'insert photo in tblimg
                'search image name if existing
                conn.Open()
                '/connect()
                sql = "Select img.name from tblmsinspect rep right outer join tblmsimg img on rep.pid=img.pid"
                sql = sql & " where rep.pid=(Select top 1 pid from tblmsinspect where mid=rep.mid and finishdate is null order by pid DESC) and rep.mid='" & lblplate2.Tag & "' and img.name='" & Trim(cmbimg2.Text) & "'"
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg2.Text) & " is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg2.Focus()

                    pgbar2.Value = 0
                    pgbar2.Visible = False
                    Exit Sub
                Else
                    Dim ms As New MemoryStream()

                    'save record in database
                    connect()
                    '/cmd = New SqlCommand("Insert into tbldispatchstp2 values(@tripnum,@name,@img,@status,@datecreated,@createdby)", conn)
                    cmd = New SqlCommand("Insert into tblmsimg values((Select top 1 pid from tblmsinspect where mid='" & lblplate2.Tag & "' order by pid DESC),@name,@img,@status,GetDate(),@createdby)", conn)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("name", Trim(cmbimg2.Text)))
                    cmd.Parameters.Add(New SqlClient.SqlParameter("status", 1))
                    imgbox2.Image.Save(ms, Imaging.ImageFormat.Jpeg)
                    Dim data As Byte() = ms.GetBuffer()
                    Dim img As New SqlParameter("@img", SqlDbType.Image)
                    img.Value = data
                    cmd.Parameters.Add(img)
                    cmd.Parameters.Add(New SqlClient.SqlParameter("createdby", login.cashier))
                    cmd.ExecuteNonQuery()
                    conn.Close()

                    pgbar2.Value = 0
                    pgbar2.Visible = False

                    MessageBox.Show("Image saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    pgbar2.Value = 0
                    imgbox2.Image = Nothing
                    imgbox2.BackColor = Color.Empty
                    imgbox2.Invalidate()
                    ms.Close()
                    Me.Cursor = Cursors.Default
                End If

                Me.Cursor = Cursors.Default
                btnimgadd2.Text = "Add Photo"
                imgcancelfalse2()
                imgpanel2.Enabled = True
                '/enableall()
                btnimgrefresh2.PerformClick()
                Me.Cursor = Cursors.Default
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub
    Public Sub imgcanceltrue2()
        btnimgadd2.Enabled = False
        btnimgrename2.Enabled = False
        btnimgremove2.Enabled = False
        btnimgcancel2.Enabled = True
        btnimgdl2.Enabled = False
        btnimgfull2.Enabled = True
        btnimgrefresh2.Enabled = False
        'btnexempt2.Enabled = False
    End Sub

    Private Sub btnimgrename2_Click(sender As Object, e As EventArgs) Handles btnimgrename2.Click
        Try
            If login.neym <> "Motorpool Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If checkcompleted(lblplate2.Tag) = True Then
                Me.Cursor = Cursors.Default
                MsgBox(lblplate2.Text & " is already inspected. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If btnimgrename2.Text = "Rename" Then
                If Trim(cmbimg2.Text) <> "" And imgbox2.Image IsNot Nothing Then
                    Dim tempname As String = Trim(cmbimg2.Text)
                    If tempname.ToLower.Contains("signature") Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Cannot rename photo.", MsgBoxStyle.Exclamation, "")
                        cmbimg2.Focus()
                        Exit Sub
                    End If
                    cmbimg2.Enabled = True
                    cmbimg2.Focus()
                ElseIf Trim(cmbimg2.Text) = "" And imgbox2.Image IsNot Nothing Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input photo name first.", MsgBoxStyle.Exclamation, "")
                    cmbimg2.Focus()
                    Exit Sub
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                    cmbimg2.Focus()
                    Exit Sub
                End If

                imgpanel2.Enabled = False
                imgcanceltrue2()
                btnimgrename2.Enabled = True
                btnimgrename2.Text = "Save"
            Else
                'search image name if existing
                connect()
                sql = "Select img.name from tblmsinspect rep right outer join tblmsimg img on rep.pid=img.pid"
                sql = sql & " where rep.pid=(Select top 1 pid from tblmsinspect where mid=rep.mid and finishdate is null order by pid DESC) and rep.mid='" & lblplate2.Tag & "' and img.name='" & Trim(cmbimg2.Text) & "'"
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader()
                If dr.Read = True Then
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Image " & Trim(cmbimg2.Text) & " Is already exist.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    cmbimg2.Focus()
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                Me.Cursor = Cursors.Default

                If cmbimg2.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid photo name.", MsgBoxStyle.Exclamation, "")
                    cmbimg2.Text = ""
                    cmbimg2.Focus()
                    Exit Sub
                End If

                'irename.. update yung name lng where imgid = lblimgid.text
                sql = "Update tblmsimg Set name='" & Trim(cmbimg2.Text) & "' where iid='" & lblimgid2.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                conn.Close()

                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")

                btnimgrename2.Text = "Rename"
                imgcancelfalse2()
                imgpanel2.Enabled = True
                btnimgrefresh2.PerformClick()
                Me.Cursor = Cursors.Default
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub btnimgremove2_Click(sender As Object, e As EventArgs) Handles btnimgremove2.Click
        Try
            If login.neym <> "Motorpool Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If checkcompleted(lblplate2.Tag) = True Then
                Me.Cursor = Cursors.Default
                MsgBox(lblplate2.Text & " is already inspected. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(cmbimg2.Text) <> "" And imgbox2.Image IsNot Nothing Then
                Me.Cursor = Cursors.Default

                If cmbimg2.Text.ToLower.Contains("signature") Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Cannot delete signature", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If

                Dim a As String = MsgBox("Are you sure you want to remove photo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2)
                If a = vbYes Then
                    'delete image where imgid=lblimgid.text
                    sql = "Delete from tblmsimg where iid='" & lblimgid2.Text & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully removed.", MsgBoxStyle.Information, "")

                    imgcancelfalse2()
                    imgpanel2.Enabled = True
                    btnimgrefresh2.PerformClick()
                End If
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
                cmbimg2.Focus()
                Exit Sub
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub btnimgfull2_Click(sender As Object, e As EventArgs) Handles btnimgfull2.Click
        If lblimgid2.Text <> "" Or imgbox2.Image IsNot Nothing Then
            viewimage.imgbox.Image = imgbox2.Image
            viewimage.lblimgname.Text = cmbimg2.Text
            viewimage.ShowDialog()
        Else
            MsgBox("Select photo first.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub btnimgrefresh2_Click(sender As Object, e As EventArgs) Handles btnimgrefresh2.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim lbl As Label
            Dim wid As Int32, widlbl As Int32
            Dim temp As Integer = 0, y As Integer, mody As Integer, row As Integer

            meronstp2 = False
            imgpanel2.Visible = False
            imgpanel2.Controls.Clear()
            imgpanel2.Visible = True

            Dim ctr As Integer = 0
            sql = "Select img.* from tblmsinspect rep right outer join tblmsimg img On rep.pid=img.pid"
            sql = sql & " where rep.pid=(Select top 1 pid from tblmsinspect where mid=rep.mid and finishdate is null order by pid DESC) And rep.mid='" & lblplate2.Tag & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                meronstp2 = True
                Me.Cursor = Cursors.WaitCursor
                temp = temp + 1
                mody = temp Mod 5
                row = temp / 5

                If mody = 1 Then
                    y = (row * 100) + (40 * row)
                    wid = 0
                    widlbl = 0
                End If

                Dim data As Byte() = DirectCast(dr("img"), Byte())
                Dim ms As New MemoryStream(data)

                picstp2 = New PictureBox
                picstp2.Image = Image.FromStream(ms)
                ms.Dispose()
                picstp2.SizeMode = PictureBoxSizeMode.Zoom
                picstp2.SetBounds(wid, y, 104, 100)
                'picstp2.BackColor = Color.AliceBlue
                picstp2.Tag = dr("iid")
                picstp2.BorderStyle = BorderStyle.FixedSingle
                wid += 111

                lbl = New Label
                lbl.Text = dr("name")
                lbl.AutoSize = False
                lbl.BackColor = Color.Aquamarine
                lbl.TextAlign = ContentAlignment.MiddleCenter
                lbl.Size = New System.Drawing.Size(104, lbl.Height)
                lbl.Location = New System.Drawing.Point(widlbl, 105 + y)
                widlbl += 111

                AddHandler picstp2.Click, AddressOf convertPic2
                imgpanel2.Controls.Add(picstp2)
                imgpanel2.Controls.Add(lbl)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            imgbox2.Image = Nothing
            cmbimg2.Text = ""
            lblimgid2.Text = ""
            lblimgdate2.Text = ""
            lblimgname2.Text = ""

            Me.Cursor = Cursors.Default

            If meronstp2 = False Then
                btnimgrename2.Enabled = False
                btnimgremove2.Enabled = False
                btnimgcancel2.Enabled = False
                btnimgdl2.Enabled = False
                btnimgfull2.Enabled = False
                btnconfirm2.Enabled = False
            Else
                imgcancelfalse2()
            End If

            If grdstep2.Rows.Count = 0 Then
                grp2.Enabled = False
            Else
                grp2.Enabled = True
            End If

            Me.Cursor = Cursors.Default

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Sub convertPic2(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'CONVERT SENDER INTO PICTUREBOX
        Try
            picstp2 = CType(sender, PictureBox)
            imgbox2.Image = picstp2.Image
            lblimgid2.Text = picstp2.Tag

            sql = "Select name,datecreated,createdby from tblmsimg where iid='" & lblimgid2.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                cmbimg2.Text = dr("name")
                If IsDBNull(dr("datecreated")) = False Then
                    lblimgdate2.Text = Format(dr("datecreated"), "MM/dd/yyyy h:mm tt")
                Else
                    lblimgdate2.Text = ""
                End If
                lblimgname2.Text = dr("createdby").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub btnconfirm2_Click(sender As Object, e As EventArgs) Handles btnconfirm2.Click
        Try
            If login.neym <> "Motorpool Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If checkcompleted(lblplate2.Tag) = True Then
                Me.Cursor = Cursors.Default
                MsgBox(lblplate2.Text & " is already inspected. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            'CHECK IF IMGPANEL2 HAS CONTROLS
            If imgpanel2.Controls.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("NO ATTACHMENTS.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If


            cnf = False
            confirmchecker.GroupBox1.Text = login.neym
            confirmchecker.btncnf = False
            confirmchecker.tripnumber = ""
            confirmchecker.ShowDialog()
            If cnf = True Then
                FinishStep2(strconn, 0, confirmchecker.checkerneym)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub
    Private Sub FinishStep2(ByVal connectionString As String, ByVal tcon As Integer, ByVal finishby As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim drstep As SqlDataReader
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                'update tblmsinspect
                command.CommandText = "Update tblmscheckup set tcondition=@tcon where mid=@mid and tcondition='3'"
                command.Parameters.AddWithValue("@tcon", tcon)
                command.Parameters.AddWithValue("@mid", lblplate2.Tag)
                command.ExecuteNonQuery()

                command.CommandText = "Update tblmsinspect set finishby=@finishby, finishdate=GetDate(), remsinspect=@rems, tcondition='0' where mid=@mid1 and finishdate is null"
                command.Parameters.AddWithValue("@finishby", finishby)
                command.Parameters.AddWithValue("@rems", Trim(txtrems2.Text.ToString.Replace("'", "''")))
                command.Parameters.AddWithValue("@mid1", lblplate2.Tag)
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

                MsgBox(lblplate2.Text & " is allowed to travel.", MsgBoxStyle.Information, "")
                zero2()
                tripstep2()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
            End Try
        End Using
    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            GroupBox1.Text = "Searched"
            grdlist.Rows.Clear()

            ' Format(datefrom.value,"yyyy/MM/dd")


            If Trim(txtid.Text) <> "" Then
                sql = "Select distinct mid, platenum, vtype, tcondition FROM vMClogs where mid='" & Trim(txtid.Text) & "'"
            ElseIf Format(datefrom.Value, "yyyy/MM/dd") <> Format(dateto.Value, "yyyy/MM/dd") Then
                Dim days As Integer = DateDiff(DateInterval.Day, CDate(Format(datefrom.Value, "yyyy/MM/dd")), CDate(Format(dateto.Value, "yyyy/MM/dd")))
                If days > 7 Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Input plate#.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                Else
                    If Trim(cmbplate.Text) <> "" Then
                        sql = "Select distinct mid, platenum, vtype, tcondition FROM vMClogs"
                        sql = sql & " where checkupdate>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and checkupdate<='" & Format(dateto.Value, "yyyy/MM/dd") & "'"
                        sql = sql & " and platenum='" & Trim(cmbplate.Text) & "'"
                        sql = sql & " order by vtype,platenum"
                    Else
                        sql = "Select distinct mid, platenum, vtype, tcondition FROM vMClogs"
                        sql = sql & " where checkupdate>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and checkupdate<='" & Format(dateto.Value, "yyyy/MM/dd") & "'"
                        If Trim(cmbplate.Text) <> "" Then
                            sql = sql & " and platenum='" & Trim(cmbplate.Text) & "'"
                        End If
                        sql = sql & " order by vtype,platenum"
                    End If
                End If
            Else
                sql = "Select distinct mid, platenum, vtype, tcondition FROM vMClogs"
                sql = sql & " where checkupdate>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and checkupdate<='" & Format(dateto.Value, "yyyy/MM/dd") & "'"
                If Trim(cmbplate.Text) <> "" Then
                    sql = sql & " and platenum='" & Trim(cmbplate.Text) & "'"
                End If
                sql = sql & " order by vtype,platenum"
            End If

            grdsql3 = sql

            bgw3 = New BackgroundWorker()
            bgw3.WorkerSupportsCancellation = True

            AddHandler bgw3.DoWork, New DoWorkEventHandler(AddressOf bgw3_DoWork)
            AddHandler bgw3.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw3_Completed)
            AddHandler bgw3.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw3_ProgressChanged)
            m_addRowDelegate3 = New AddRowDelegate3(AddressOf AddDGVRow3)

            If Not bgw3.IsBusy Then
                lblload3.Visible = True
                bgw3.WorkerReportsProgress = True
                bgw3.WorkerSupportsCancellation = True
                bgw3.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub
    Private Sub bgw3_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabled3 = True

        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If

        Dim cmdx As SqlCommand = New SqlCommand(grdsql3, connection)
        Dim drx As SqlDataReader = cmdx.ExecuteReader
        While drx.Read
            If bgw3.CancellationPending = True Then
                e.Cancel = True
                Exit Sub
            End If

            AddDGVRow3(drx("mid"), drx("platenum"), drx("vtype"), drx("tcondition"))
        End While
        drx.Dispose()
        cmdx.Dispose()
        connection.Close()
    End Sub

    Delegate Sub AddRowDelegate3(ByVal value0 As Object, ByVal value1 As Object, ByVal value2 As Object, ByVal value3 As Object)
    Private m_addRowDelegate3 As AddRowDelegate3

    Private Sub AddDGVRow3(ByVal val0 As Integer, ByVal val1 As String, ByVal val2 As String, ByVal val3 As String)
        If threadEnabled3 = True Then
            If Me.InvokeRequired Then
                Me.BeginInvoke(New AddRowDelegate3(AddressOf AddDGVRow3), val0, val1, val2, val3)
            Else
                grdlist.Rows.Add(val0, val1, val2, val3)
            End If
        End If
    End Sub

    Private Sub grdnot_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdnot.CellContentClick

    End Sub

    Private Sub bgw3_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        '/lblloading.Visible = False
        If e.Error IsNot Nothing Then
            Me.Cursor = Cursors.Default
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            Me.Cursor = Cursors.Default
            MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            Me.Cursor = Cursors.Default
            'If whatstep = 1 Then
            grdlist.SuspendLayout()
            grdlist.ResumeLayout()
            grdlist.Enabled = True
            lblload3.Visible = False
            If grdlist.Rows.Count = 0 Then
                'grp1.Enabled = False
                'MsgBox("No record found.", MsgBoxStyle.Critical, "")
                lblload3.Visible = False
            Else
                'grp1.Enabled = True
                Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                grdlist.Rows(0).Cells(0).Selected = True
                grdlist_CellClick(grdlist, eventArgs)
            End If
            ' End If
            '/Me.WindowState = FormWindowState.Maximized
        End If
    End Sub

    Private Sub bgw3_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        '/Me.Label12.Text = e.ProgressPercentage.ToString() & "% complete"
        grdlist.Enabled = False
        lblload3.Visible = True
    End Sub

    Private Sub btnimgcancel2_Click(sender As Object, e As EventArgs) Handles btnimgcancel2.Click
        imgpanel2.Enabled = True
        imgbox2.Image = Nothing
        cmbimg2.Text = ""
        lblimgid2.Text = ""
        imgcancelfalse2()

        If meronstp2 = False Then
            btnimgrename2.Enabled = False
            btnimgremove2.Enabled = False
            btnimgcancel2.Enabled = False
            btnimgdl2.Enabled = False
            btnimgfull2.Enabled = False
        Else
            imgcancelfalse2()
        End If
    End Sub

    Private Sub startprefalse()
        btnstartpre.Enabled = False
        txtrems1.Enabled = True
        txtchk.Enabled = True
        btnimgadd1.Enabled = True
        btnimgrename1.Enabled = True
        btnimgremove1.Enabled = True
        btnimgfull1.Enabled = True
        btnimgrefresh1.Enabled = True
    End Sub

    Public Sub zero2()
        lblplate2.Text = ""
        lbltype2.Text = ""
        txtrems2.Text = ""

        btnstartdiesel.Text = "TIME START TRUCK CLEARANCE"

        btnimgadd2.Text = "Add Photo"
        btnimgrename2.Text = "Rename"
        btnimgadd2.Enabled = False
        btnimgremove2.Enabled = False
        btnimgcancel2.Enabled = False
        btnimgrename2.Enabled = False
        btnimgfull2.Enabled = False
        'btnimgrefresh2.Enabled = False
        btnconfirm2.Enabled = False

        imgpanel2.Visible = False
        imgpanel2.Controls.Clear()
        imgpanel2.Visible = True
    End Sub

    Private Sub grdstep2_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdstep2.CellClick
        Try
            zero2()
            grp2.Enabled = False
            Me.Cursor = Cursors.WaitCursor

            lblplate2.Tag = grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(0).Value
            lblplate2.Text = grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(1).Value
            lbltype2.Text = grdstep2.Rows(grdstep2.CurrentRow.Index).Cells(2).Value

            SelectStep2(strconn)

            btnimgrefresh2.PerformClick()

            grp2.Text = "Photos"

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.message & vbcrlf & vbcrlf & ex.stacktrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub SelectStep2(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim drstep As SqlDataReader
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                btnstartdiesel.Text = "TIME START TRUCK CLEARANCE"
                command.CommandText = "Select top 1 c.tcondition,c.chknum,i.startdate,i.remsinspect from tblmscheckup c"
                command.CommandText = command.CommandText & " left outer join tblmsinspect i On c.mid=i.mid and i.finishdate is null"
                command.CommandText = command.CommandText & " where c.mid='" & lblplate2.Tag & "' And c.tcondition='3' order by i.pid DESC"
                drstep = command.ExecuteReader
                If drstep.Read Then
                    grp2.Enabled = True
                    If IsDBNull(drstep("startdate")) = False Then
                        btnstartdiesel.Text = "TIME START TRUCK CLEARANCE: " & Format(drstep("startdate"), "HH:mm")
                        txtrems2.Text = drstep("remsinspect").ToString
                        'txtchk.Text = drstep("chknum").ToString
                        startdieselfalse()
                        btnimgadd2.Enabled = True
                        btnconfirm2.Enabled = True
                        btnrepair.Enabled = True
                    Else
                        btnstartdiesel.Enabled = True
                        txtrems2.Enabled = False
                        txtrems2.Text = ""
                        'txtchk.Enabled = False
                        'txtchk.Text = ""
                        btnimgadd2.Enabled = False
                    End If
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Refresh list.", MsgBoxStyle.Information, "")
                    grp2.Enabled = False
                End If
                drstep.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
            End Try
        End Using
    End Sub

    Private Sub txtplatenot_TextChanged(sender As Object, e As EventArgs) Handles txtplatenot.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789"
        Dim theText As String = txtplatenot.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtplatenot.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtplatenot.Text.Length - 1
            Letter = txtplatenot.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtplatenot.Text = theText
        txtplatenot.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub startdieselfalse()
        btnstartdiesel.Enabled = False
        txtrems2.Enabled = True

        btnimgadd2.Enabled = True
        btnimgrename2.Enabled = True
        btnimgremove2.Enabled = True
        btnimgfull2.Enabled = True
        btnimgrefresh2.Enabled = True
    End Sub

    Private Sub btnview_Click(sender As Object, e As EventArgs) Handles btnview.Click
        viewpends()
    End Sub

    Private Sub viewpends()
        Try
            Me.Cursor = Cursors.WaitCursor
            cmbplate.Text = ""
            cmbtype.Text = ""
            txtid.Text = ""
            GroupBox1.Text = "Pending"
            grdlist.Rows.Clear()

            sql = "Select mid, platenum, vtype, tcondition FROM vMC"
            sql = sql & " where tcondition<>'2' order by vtype, platenum"

            grdsql3 = sql

            bgw3 = New BackgroundWorker()
            bgw3.WorkerSupportsCancellation = True

            AddHandler bgw3.DoWork, New DoWorkEventHandler(AddressOf bgw3_DoWork)
            AddHandler bgw3.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgw3_Completed)
            AddHandler bgw3.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgw3_ProgressChanged)
            m_addRowDelegate3 = New AddRowDelegate3(AddressOf AddDGVRow3)

            If Not bgw3.IsBusy Then
                lblload3.Visible = True
                bgw3.WorkerReportsProgress = True
                bgw3.WorkerSupportsCancellation = True
                bgw3.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub datefrom_ValueChanged(sender As Object, e As EventArgs) Handles datefrom.ValueChanged
        dateto.MinDate = datefrom.Value
    End Sub

    Private Sub txtid_TextChanged(sender As Object, e As EventArgs) Handles txtid.TextChanged
        Dim charactersDisallowed As String = "0123456789" ' if allowed ung to follow "toflwTOFLW1234567890 "
        Dim theText As String = txtid.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtid.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtid.Text.Length - 1
            Letter = txtid.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtid.Text = theText
        txtid.Select(SelectionIndex - Change, 0)

        If Trim(txtid.Text) <> "" Then
            cmbplate.Enabled = False
            cmbtype.Enabled = False
            datefrom.Enabled = False
            dateto.Enabled = False
        Else
            cmbplate.Enabled = True
            cmbtype.Enabled = True
            datefrom.Enabled = True
            dateto.Enabled = True
        End If
    End Sub

    Private Sub grdlist_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdlist.CellClick
        Try
            'grp1.Enabled = False
            Me.Cursor = Cursors.WaitCursor

            lblplatebig.Tag = grdlist.Rows(grdlist.CurrentRow.Index).Cells(0).Value
            lblplatebig.Text = grdlist.Rows(grdlist.CurrentRow.Index).Cells(1).Value
            'lbltype1.Text = grdstep1.Rows(grdstep1.CurrentRow.Index).Cells(2).Value

            grdlogs.Rows.Clear()
            SelectList(strconn, lblplatebig.Tag)

            'grp1.Text = "Photos"

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.message & vbcrlf & vbcrlf & ex.stacktrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub SelectList(ByVal connectionString As String, ByVal mid As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Select * from tblmsinspect where mid='" & mid & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                While dr.Read
                    Dim condi As String = ""
                    If IsDBNull(dr("tcondition")) = False Then
                        If dr("tcondition") = 0 Then
                            condi = "Truck Clearance"
                        ElseIf dr("tcondition") = 1 Then
                            condi = "In-Progress"
                        ElseIf dr("tcondition") = 2 Then
                            condi = "Good Condition"
                        ElseIf dr("tcondition") = 3 Then
                            condi = "For Repair"
                        End If
                    Else
                        condi = "In-Progress"
                    End If

                    grdlogs.Rows.Add(dr("pid"), dr("startdate"), dr("startby"), dr("finishdate"), dr("finishby"), dr("remsinspect"), dr("chknum"), condi)
                End While
                dr.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub cmbplate_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbplate.SelectedIndexChanged

    End Sub

    Private Sub btnrefstep0_Click(sender As Object, e As EventArgs) Handles btnrefstep0.Click
        tripstep0()
    End Sub

    Private Sub btnstartfor_Click(sender As Object, e As EventArgs) Handles btnstartfor.Click
        Try
            If login.neym <> "Motorpool Inspector" Then
                Me.Cursor = Cursors.Default
                MsgBox("Access Denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If checkcompleted(lblplate0.Tag) = True Then
                Me.Cursor = Cursors.Default
                MsgBox(lblplate0.Text & " is already check-up. Refresh the list.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            cnf = False
            confirmchecker.GroupBox1.Text = login.neym
            confirmchecker.btncnf = False
            confirmchecker.tripnumber = ""
            confirmchecker.ShowDialog()
            If cnf = True Then
                StartStep0(strconn, confirmchecker.checkerneym)
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub
    Private Sub StartStep0(ByVal connectionString As String, ByVal startedby As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim drstep As SqlDataReader
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                command.CommandText = "Select c.tcondition,c.chknum,i.startdate,i.remsinspect from tblmscheckup c"
                command.CommandText = command.CommandText & " left outer join tblmsinspect i On c.mid=i.mid where c.mid='" & lblplate0.Tag & "' And c.tcondition<>'0'"
                drstep = command.ExecuteReader
                If drstep.Read Then
                    Me.Cursor = Cursors.Default
                    MsgBox(lblplate0.Text & " is NOT for inspection. Refresh list.", MsgBoxStyle.Information, "")
                    grp0.Enabled = False
                    Exit Sub
                End If
                drstep.Dispose()

                command.CommandText = "Insert into tblmsinspect (mid,startby,startdate,frm,uploaded) values (@mid,@startby,GetDate(),'Inspection',0)"
                command.Parameters.AddWithValue("@mid", lblplate0.Tag)
                command.Parameters.AddWithValue("@startby", startedby)
                command.ExecuteNonQuery()

                command.CommandText = "Update tblmscheckup set tcondition=@tcon where mid=@mid1"
                command.Parameters.AddWithValue("@tcon", "1")
                command.Parameters.AddWithValue("@mid1", lblplate0.Tag)
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                tripstep0()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
            End Try
        End Using
    End Sub

    Private Sub grdlist_RowPrePaint(sender As Object, e As DataGridViewRowPrePaintEventArgs) Handles grdlist.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grdlist.Rows(e.RowIndex)
            If dgvRow.Cells("tcon3").Value = 2 Then
                dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(128, 255, 128)
            ElseIf dgvRow.Cells("tcon3").Value = 3 Then
                dgvRow.DefaultCellStyle.BackColor = Color.MistyRose
            Else
                dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 192)
            End If
        End If
    End Sub

    Private Sub txtid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtid.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btnsearch.PerformClick()
        End If
    End Sub

    Private Sub txtplateava_TextChanged(sender As Object, e As EventArgs) Handles txtplateava.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789"
        Dim theText As String = txtplateava.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtplateava.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtplateava.Text.Length - 1
            Letter = txtplateava.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtplateava.Text = theText
        txtplateava.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub plate()
        Try
            cmbplate.Items.Clear()
            cmbplate.Items.Add("")

            sql = "Select platenum from tblgeneral where company='J. Poon & Sons' order by platenum"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbplate.Items.Add(dr1("platenum"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub cmbplate_TextChanged(sender As Object, e As EventArgs) Handles cmbplate.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789"
        Dim theText As String = cmbplate.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbplate.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbplate.Text.Length - 1
            Letter = cmbplate.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbplate.Text = theText
        cmbplate.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As Object, e As DoWorkEventArgs)

    End Sub

    Private Sub cmbplate_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbplate.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbplate_Leave(sender As Object, e As EventArgs) Handles cmbplate.Leave
        getvtype()
    End Sub

    Public Sub getvtype()
        Try
            Me.Cursor = Cursors.WaitCursor

            If Trim(cmbplate.Text) <> "" Then
                If Not cmbplate.Items.Contains(Trim(cmbplate.Text.ToUpper)) Then
                    cmbplate.Text = ""
                    cmbtype.Text = ""
                Else
                    sql = "Select platenum,vtype from tblgeneral"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    While dr.Read
                        Dim plnum As String = dr("platenum")
                        If plnum = Trim(cmbplate.Text.ToUpper) Then
                            cmbplate.SelectedItem = plnum
                            cmbtype.Text = dr("vtype")
                        End If
                    End While
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Else
                cmbplate.Text = ""
                cmbtype.Text = ""
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub btncompleted_Click(sender As Object, e As EventArgs) Handles btncompleted.Click
        If Format(dfcom.Value, "yyyy/MM/dd") <> Format(dtcom.Value, "yyyy/MM/dd") And Trim(txtapp.Text) = "" Then
            Me.Cursor = Cursors.Default
            MsgBox("Input plate#.", MsgBoxStyle.Exclamation, "")
            txtapp.Focus()
            Exit Sub
        Else
            'maximum of 60 days only
            Dim days As Integer = DateDiff(DateInterval.Day, CDate(Format(dfcom.Value, "yyyy/MM/dd")), CDate(Format(dtcom.Value, "yyyy/MM/dd")))
            If days > 60 Then
                Me.Cursor = Cursors.Default
                MsgBox("Maximum of 60 days only.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If
        End If

        grdapp_com.Rows.Clear()
        get_app_completed()
        If grdapp_com.Rows.Count <> 0 Then
            lblloadcom.Visible = False
        Else
            MsgBox("No record found.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub grdstep0_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdstep0.CellClick
        zero0()
        grp0.Enabled = False
        Me.Cursor = Cursors.Default

        lblplate0.Tag = grdstep0.Rows(grdstep0.CurrentRow.Index).Cells(0).Value
        lblplate0.Text = grdstep0.Rows(grdstep0.CurrentRow.Index).Cells(1).Value
        lbltype0.Text = grdstep0.Rows(grdstep0.CurrentRow.Index).Cells(2).Value

        SelectStep0(strconn)

        grp0.Text = "Photos"
    End Sub

    Private Sub dfcom_ValueChanged(sender As Object, e As EventArgs) Handles dfcom.ValueChanged
        dtcom.MinDate = dfcom.Value
    End Sub

    Private Sub SelectStep0(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim drstep As SqlDataReader
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                command.CommandText = "Select c.tcondition,c.chknum,i.startdate,i.remsinspect from tblmscheckup c"
                command.CommandText = command.CommandText & " left outer join tblmsinspect i On c.mid=i.mid where c.mid='" & lblplate0.Tag & "' And c.tcondition<>'0'"
                drstep = command.ExecuteReader
                If drstep.Read Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Refresh list.", MsgBoxStyle.Information, "")
                    grp0.Enabled = False
                    Exit Sub
                End If
                drstep.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                grp0.Enabled = True

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
            End Try
        End Using
    End Sub

    Private Sub txtplatenot_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtplatenot.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btnnot.PerformClick()
        End If
    End Sub

    Private Sub btnnot_Click(sender As Object, e As EventArgs) Handles btnnot.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            grdnot.Rows.Clear()

            ' Format(datefrom.value,"yyyy/MM/dd")

            If Trim(txtplatenot.Text) <> "" Then
                sql = "Select * FROM vMCnotArrived where platenum like '%" & Trim(txtplatenot.Text) & "%' and whsename='" & login.whse & "' order by whsename,vtype, platenum"
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Input plate#.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            grdsqlnot = sql

            bgwnot = New BackgroundWorker()
            bgwnot.WorkerSupportsCancellation = True

            AddHandler bgwnot.DoWork, New DoWorkEventHandler(AddressOf bgwnot_DoWork)
            AddHandler bgwnot.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgwnot_Completed)
            m_addRowDelegatenot = New AddRowDelegatenot(AddressOf AddDGVRownot)

            If Not bgwnot.IsBusy Then
                lblloadnot.Visible = True
                bgwnot.WorkerReportsProgress = True
                bgwnot.WorkerSupportsCancellation = True
                bgwnot.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub
    Private Sub bgwnot_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnablednot = True

        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If

        Dim cmdx As SqlCommand = New SqlCommand(grdsqlnot, connection)
        Dim drx As SqlDataReader = cmdx.ExecuteReader
        While drx.Read
            If bgwnot.CancellationPending = True Then
                e.Cancel = True
                Exit Sub
            End If

            AddDGVRownot(drx("tripnum"), drx("platenum"), drx("vtype"), drx("tripstat"))
        End While
        drx.Dispose()
        cmdx.Dispose()
        connection.Close()
    End Sub

    Private Sub lblimgdate1_Click(sender As Object, e As EventArgs) Handles lblimgdate1.Click

    End Sub

    Private Sub txtapp_TextChanged(sender As Object, e As EventArgs) Handles txtapp.TextChanged
        If Trim(txtapp.Text) <> "" Then
            txtappid.Text = ""
            txtappid.Enabled = False
        Else
            txtappid.Enabled = True
        End If
    End Sub

    Private Sub txtappid_TextChanged(sender As Object, e As EventArgs) Handles txtappid.TextChanged
        If Trim(txtappid.Text) <> "" Then
            txtapp.Text = ""
            txtapp.Enabled = False
            dfcom.Enabled = False
            dtcom.Enabled = False
        Else
            txtapp.Enabled = True
            dfcom.Enabled = True
            dtcom.Enabled = True
        End If
    End Sub

    Delegate Sub AddRowDelegatenot(ByVal value0 As Object, ByVal value1 As Object, ByVal value2 As Object, ByVal value3 As Object)
    Private m_addRowDelegatenot As AddRowDelegatenot

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub AddDGVRownot(ByVal val0 As String, ByVal val1 As String, ByVal val2 As String, ByVal val3 As String)
        If threadEnablednot = True Then
            If Me.InvokeRequired Then
                Me.BeginInvoke(New AddRowDelegatenot(AddressOf AddDGVRownot), val0, val1, val2, val3)
            Else
                grdnot.Rows.Add(val0, val1, val2, val3)
            End If
        End If
    End Sub

    Private Sub grdava_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdava.CellContentClick

    End Sub

    Private Sub bgwnot_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        btnrefnot.Enabled = True
        '/lblloading.Visible = False
        If e.Error IsNot Nothing Then
            Me.Cursor = Cursors.Default
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            Me.Cursor = Cursors.Default
            MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            Me.Cursor = Cursors.Default
            'If whatstep = 1 Then
            grdnot.SuspendLayout()
            grdnot.ResumeLayout()
            grdnot.Enabled = True
            lblloadnot.Visible = False
            If grdnot.Rows.Count = 0 Then
                'grp1.Enabled = False
                'MsgBox("No record found.", MsgBoxStyle.Critical, "")
            Else
                'grp1.Enabled = True
                'Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                'grdnot.Rows(0).Cells(0).Selected = True
                'grdnot_CellClick(grdnot, eventArgs)
            End If
            ' End If
            '/Me.WindowState = FormWindowState.Maximized
        End If
    End Sub

    Private Sub btnrefnot_Click(sender As Object, e As EventArgs) Handles btnrefnot.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            grdnot.Rows.Clear()

            grdsqlnot = "Select * FROM vMCnotArrived where whsename='" & login.whse & "' order by whsename,vtype, platenum"
            btnrefnot.Enabled = False

            bgwnot = New BackgroundWorker()
            bgwnot.WorkerSupportsCancellation = True

            AddHandler bgwnot.DoWork, New DoWorkEventHandler(AddressOf bgwnot_DoWork)
            AddHandler bgwnot.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgwnot_Completed)
            m_addRowDelegatenot = New AddRowDelegatenot(AddressOf AddDGVRownot)

            If Not bgwnot.IsBusy Then
                lblloadnot.Visible = True
                bgwnot.WorkerReportsProgress = True
                bgwnot.WorkerSupportsCancellation = True
                bgwnot.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub btnavail_Click(sender As Object, e As EventArgs) Handles btnava.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            grdava.Rows.Clear()

            ' Format(datefrom.value,"yyyy/MM/dd")

            If Trim(txtplateava.Text) <> "" Then
                sql = "Select * FROM vMCAvailable where platenum like '%" & Trim(txtplateava.Text) & "%' order by vtype, platenum"
            Else
                Me.Cursor = Cursors.Default
                MsgBox("Input plate#.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            grdsqlava = sql

            bgwava = New BackgroundWorker()
            bgwava.WorkerSupportsCancellation = True

            AddHandler bgwava.DoWork, New DoWorkEventHandler(AddressOf bgwava_DoWork)
            AddHandler bgwava.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgwava_Completed)
            m_addRowDelegateava = New AddRowDelegateava(AddressOf AddDGVRowava)

            If Not bgwava.IsBusy Then
                lblloadava.Visible = True
                bgwava.WorkerReportsProgress = True
                bgwava.WorkerSupportsCancellation = True
                bgwava.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub
    Private Sub bgwava_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabledava = True

        Dim connection As SqlConnection
        connection = New SqlConnection
        connection.ConnectionString = strconn
        If connection.State <> ConnectionState.Open Then
            connection.Open()
        End If

        Dim cmdx As SqlCommand = New SqlCommand(grdsqlava, connection)
        Dim drx As SqlDataReader = cmdx.ExecuteReader
        While drx.Read
            If bgwava.CancellationPending = True Then
                e.Cancel = True
                Exit Sub
            End If

            AddDGVRowava(drx("platenum"), drx("vtype"), drx("chknum"))
        End While
        drx.Dispose()
        cmdx.Dispose()
        connection.Close()
    End Sub

    Private Sub bgwava_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)

    End Sub

    Delegate Sub AddRowDelegateava(ByVal value0 As Object, ByVal value1 As Object, ByVal value2 As Object)
    Private m_addRowDelegateava As AddRowDelegateava

    Private Sub AddDGVRowava(ByVal val0 As String, ByVal val1 As String, ByVal val2 As String)
        If threadEnabledava = True Then
            If Me.InvokeRequired Then
                Me.BeginInvoke(New AddRowDelegateava(AddressOf AddDGVRowava), val0, val1, val2)
            Else
                grdava.Rows.Add(val0, val1, val2)
            End If
        End If
    End Sub

    Private Sub grdlist_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdlist.CellContentClick

    End Sub

    Private Sub bgwava_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        '/lblloading.Visible = False
        btnrefava.Enabled = True
        If e.Error IsNot Nothing Then
            Me.Cursor = Cursors.Default
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            Me.Cursor = Cursors.Default
            MsgBox("Operation is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            Me.Cursor = Cursors.Default
            'If whatstep = 1 Then
            grdava.SuspendLayout()
            grdava.ResumeLayout()
            grdava.Enabled = True
            lblloadava.Visible = False
        End If
    End Sub

    Private Sub btnrefava_Click(sender As Object, e As EventArgs) Handles btnrefava.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            grdava.Rows.Clear()

            grdsqlava = "Select * FROM vMCAvailable order by vtype, platenum"
            btnrefava.Enabled = False

            bgwava = New BackgroundWorker()
            bgwava.WorkerSupportsCancellation = True

            AddHandler bgwava.DoWork, New DoWorkEventHandler(AddressOf bgwava_DoWork)
            AddHandler bgwava.ProgressChanged, New ProgressChangedEventHandler(AddressOf bgwava_ProgressChanged)
            AddHandler bgwava.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf bgwava_Completed)
            m_addRowDelegateava = New AddRowDelegateava(AddressOf AddDGVRowava)

            If Not bgwava.IsBusy Then
                lblloadava.Visible = True
                bgwava.WorkerReportsProgress = True
                bgwava.WorkerSupportsCancellation = True
                bgwava.RunWorkerAsync() 'start ng select query
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub txtplateava_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtplateava.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btnava.PerformClick()
        End If
    End Sub

    Private Sub btnapp_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub get_app_completed()
        Dim api_query As String = "http://" & login.connStrMS & "/api/Checklist"
        Dim request As WebRequest = WebRequest.Create(api_query)
        request.Credentials = CredentialCache.DefaultCredentials
        Dim response As WebResponse = request.GetResponse()
        'Dim okie As String = ((CType(response, HttpWebResponse)).StatusDescription) 'OK
        Dim getResponses As String = ""

        Using dataStream As Stream = response.GetResponseStream()
            Dim reader As StreamReader = New StreamReader(dataStream)
            Dim responseFromServer As String = reader.ReadToEnd()
            'If responseFromServer.Contains(currentversion) Then

            'End If
            getResponses = (responseFromServer)
        End Using
        response.Close()

        Deserializations_Completed(getResponses)
    End Sub

    Private Sub Deserializations_Completed(ByVal json As String)
        Try
            ' JsonConvert.DeserializeObject(Of List(Of Receiver))(json)
            ' JsonConvert.DeserializeObject(Of Dictionary(Of String, Receiver))(json)
            ' JsonConvert.DeserializeObject(Of gps_hash)(json)
            'Dim jsonResult = JsonConvert.DeserializeObject(json).ToString()
            Dim jsonResult = JsonConvert.DeserializeObject(Of List(Of m_app_completed))(json)
            For Each num In jsonResult
                'dates
                Dim sdeyt As Date = Format(CDate(num.c_date), "MM/dd/yyyy")
                Dim fdeyt As Date = Format(CDate(dfcom.Value), "MM/dd/yyyy")
                Dim tdeyt As Date = Format(CDate(dtcom.Value), "MM/dd/yyyy")
                If num.status = "Completed" And num.second_Stat = "1" Then
                    If Trim(txtapp.Text) <> "" And fdeyt <= sdeyt And sdeyt <= tdeyt Then
                        If num.platenumber = Trim(txtapp.Text) Then
                            grdapp_com.Rows.Add(num.mid, num.platenumber, num.vehicle_type, "", "", Format(num.c_date, "yyyy/MM/dd"), Format(num.c_start, "HH:mm:ss"), Format(num.c_finish, "HH:mm:ss"), num.mechanic, num.tvirnum)
                        End If
                    ElseIf Trim(txtappid.Text) <> "" Then
                        If num.mid = Trim(txtappid.Text) Then
                            grdapp_com.Rows.Add(num.mid, num.platenumber, num.vehicle_type, "", "", Format(num.c_date, "yyyy/MM/dd"), Format(num.c_start, "HH:mm:ss"), Format(num.c_finish, "HH:mm:ss"), num.mechanic, num.tvirnum)
                        End If
                    ElseIf fdeyt = sdeyt And sdeyt = tdeyt Then
                        grdapp_com.Rows.Add(num.mid, num.platenumber, num.vehicle_type, "", "", Format(num.c_date, "yyyy/MM/dd"), Format(num.c_start, "HH:mm:ss"), Format(num.c_finish, "HH:mm:ss"), num.mechanic, num.tvirnum)
                    End If
                End If
            Next

            ExecutefillTripnum(strconn)

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub ExecutefillTripnum(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                For Each row As DataGridViewRow In grdapp_com.Rows
                    Dim mid As Integer = grdapp_com.Rows(row.Index).Cells(0).Value

                    sql = "Select m.tripnum, d.datestp6 from tblmscheckup m"
                    sql = sql & " inner join tbldispatchsum d on m.tripnum=d.tripnum"
                    sql = sql & " where mid='" & mid & "'"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    If dr.Read Then
                        grdapp_com.Rows(row.Index).Cells(3).Value = dr("tripnum")
                        grdapp_com.Rows(row.Index).Cells(4).Value = Format(dr("datestp6"), "yyyy/MM/dd HH:mm:ss")
                    End If
                    dr.Dispose()
                Next

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btnupload_Click(sender As Object, e As EventArgs) Handles btnupload.Click
        Dim dataToPost As String = getUploadedFalse()
        ExecuteUpload(strconn, dataToPost)
    End Sub
    Private Sub ExecuteUpload(ByVal connectionString As String, ByVal dataToPost As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                Dim returnresult As Integer = 0
                Dim parsedObject = JsonConvert.DeserializeObject(Of m_forupload)(dataToPost)
                For Each num In parsedObject.tblCheckList
                    'MsgBox(num.mid)
                    sql = "Update tblmsinspect set uploaded=1 where mid='" & num.mid & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                    Dim dta As New TblCheckListz()
                    dta = New TblCheckListz

                    With dta
                        .whse_branch = num.whse_branch
                        .mid = num.mid
                        .platenumber = num.platenumber
                        .vehicle_type = num.vehicle_type
                        .driver = num.driver
                        .c_date = num.c_date
                        .c_start = num.c_start
                        .c_finish = num.c_finish
                        .tvirnum = num.tvirnum
                        .attachment = num.attachment
                        .mechanic = num.mechanic
                        .status = num.status
                        .second_Stat = num.second_Stat
                        .uploaddate = num.uploaddate
                        .remarks = num.remarks
                    End With

                    Dim strserialize As String = JsonConvert.SerializeObject(dta)
                    Dim data = UTF8.GetBytes(strserialize)
                    MsgBox("Dummy database of motorpool")
                    Dim result_post = SendRequest("http://122.3.139.108:8082/api/Checklist", data, "application/json", "POST")
                    returnresult = result_post.Count
                Next


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                'MsgBox("ok")
                If returnresult > 0 Then
                    MsgBox("Uploaded.", MsgBoxStyle.Information, "")
                Else
                    MsgBox("Cannot upload.", MsgBoxStyle.Critical, "")
                End If

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub
    Private Function SendRequest(uri As String, jsonDataBytes As Byte(), contentType As String, method As String) As String
        Dim response As String
        Dim request As WebRequest

        request = WebRequest.Create(uri)
        request.ContentLength = jsonDataBytes.Length
        request.ContentType = contentType
        request.Method = method

        Using requestStream = request.GetRequestStream
            requestStream.Write(jsonDataBytes, 0, jsonDataBytes.Length)
            requestStream.Close()

            Using responseStream = request.GetResponse.GetResponseStream
                Using reader As New StreamReader(responseStream)
                    response = reader.ReadToEnd()
                End Using
            End Using
        End Using

        Return response
    End Function

    Private Function getUploadedFalse()
        Dim jsonstring As String = ""
        Dim api_query As String = "http://192.168.11.17:8082/api/MSInspect?uploaded=false"
        Dim request As WebRequest = WebRequest.Create(api_query)
        request.Credentials = CredentialCache.DefaultCredentials
        Dim response As WebResponse = request.GetResponse()
        'Dim okie As String = ((CType(response, HttpWebResponse)).StatusDescription) 'OK


        Using dataStream As Stream = response.GetResponseStream()
            Dim reader As StreamReader = New StreamReader(dataStream)
            Dim responseFromServer As String = reader.ReadToEnd()
            'If responseFromServer.Contains(currentversion) Then

            'End If
            jsonstring = (responseFromServer)
        End Using
        response.Close()

        jsonstring = "{""tblCheckList"":" & jsonstring & "}"

        Return jsonstring
    End Function

    Private Sub txtapp_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtapp.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.enter Then
            btncompleted.PerformClick()
        End If
    End Sub

    Private Sub txtappid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtappid.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btncompleted.PerformClick()
        End If
    End Sub
End Class