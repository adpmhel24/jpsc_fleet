﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.ComponentModel

Public Class poi
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String
    Dim stat As String

    Public cnf As Boolean = False
    Dim clickbtn As String = ""
    Private backgroundWorker As BackgroundWorker, threadEnabled As Boolean, gridsql As String
    Private backgroundWorkertags As BackgroundWorker, threadEnabledtags As Boolean, gridsqltags As String, logwhse As String

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Private Sub poi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        logwhse = login.whse
    End Sub

    Private Sub btnview_Click(sender As Object, e As EventArgs) Handles btnview.Click
        Try
            viewall()

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub viewall()
        Try
            clickbtn = "View All"

            grdpoi.Rows.Clear()

            gridsql = "Select distinct p.poiid, p.poiname, p.address, p.latitude, p.longitude, p.area, d.value as distance, t.value as time, p.status"
            gridsql = gridsql & " from tblpoi p left outer join tblpoidistance d on p.poiid=d.poiid and d.whsename='" & login.whse & "'"
            gridsql = gridsql & " left outer join tblpoitime t on p.poiid=t.poiid and t.whsename='" & login.whse & "'"
            gridsql = gridsql & " order by p.poiname"

            lblloading.Visible = True
            GroupBox1.Enabled = False
            ProgressBar1.Style = ProgressBarStyle.Marquee
            ProgressBar1.Visible = True
            ProgressBar1.Minimum = 0

            backgroundWorker = New BackgroundWorker()
            backgroundWorker.WorkerSupportsCancellation = True
            backgroundWorkertags = New BackgroundWorker()
            backgroundWorkertags.WorkerSupportsCancellation = True

            AddHandler backgroundWorker.DoWork, New DoWorkEventHandler(AddressOf backgroundWorker_DoWork)
            AddHandler backgroundWorker.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorker_Completed)
            m_addRowDelegate = New addRowDelegate(AddressOf addDGVRow)

            AddHandler backgroundWorkertags.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkertags_DoWork)
            AddHandler backgroundWorkertags.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkertags_Completed)
            m_tagsRowDelegate = New tagsRowDelegate(AddressOf tagsDGVRow)

            If Not backgroundWorker.IsBusy Then
                backgroundWorker.WorkerReportsProgress = True
                backgroundWorker.WorkerSupportsCancellation = True
                backgroundWorker.RunWorkerAsync() 'start ng select query
            End If


            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub backgroundWorker_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        'Me.Invoke(New updateProgressDelegate(AddressOf updateProgressBar))
        '//dito ilalagay yung select statement
        'For i As Integer = 1 To 100
        '    backgroundWorker.ReportProgress(i)
        '    System.Threading.Thread.Sleep(100)
        'Next

        If backgroundWorker.CancellationPending = True Then
            e.Cancel = True
            Exit Sub
        Else
            threadEnabled = True
            Dim i As Integer = 0
            Dim stat As String = ""
            Dim connection As SqlConnection
            connection = New SqlConnection
            connection.ConnectionString = strconn
            If connection.State <> ConnectionState.Open Then
                connection.Open()
            End If
            cmd = New SqlCommand(gridsql, connection)
            Dim drx As SqlDataReader = cmd.ExecuteReader
            While drx.Read
                If drx("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If

                'If grdpoi.InvokeRequired Then
                '    If threadEnabled = True Then
                '        grdpoi.Invoke(m_addRowDelegate, drx("poiid"), drx("poiname"), drx("address"), drx("latitude"), drx("longitude"), drx("value"), stat)
                '    End If
                'Else
                addDGVRow(drx("poiid"), drx("poiname"), drx("address"), drx("latitude"), drx("longitude"), drx("distance"), drx("time"), drx("area"), stat)
                'End If
                'backgroundWorker.ReportProgress(i + 1)
                i += 1
            End While
            drx.Dispose()
            cmd.Dispose()
            connection.Close()
        End If
    End Sub

    Delegate Sub addRowDelegate(ByVal v0 As Object, ByVal v1 As Object, ByVal v2 As Object, ByVal v3 As Object, ByVal v4 As Object, ByVal v5 As Object, ByVal v6 As Object, ByVal v7 As Object, ByVal v8 As Object)
    Private m_addRowDelegate As addRowDelegate

    Private Sub addDGVRow(ByVal v0 As Object, ByVal v1 As Object, ByVal v2 As Object, ByVal v3 As Object, ByVal v4 As Object, ByVal v5 As Object, ByVal v6 As Object, ByVal v7 As Object, ByVal v8 As Object)
        If threadEnabled = True Then
            If grdpoi.InvokeRequired Then
                grdpoi.BeginInvoke(New addRowDelegate(AddressOf addDGVRow), v0, v1, v2, v3, v4, v5, v6, v7, v8)
            Else
                Dim est As String = "", dys As String = "", hrs As String = "", mins As String = ""
                If IsDBNull(v6) = False Then
                    Dim d = TimeSpan.FromMinutes(v6)
                    If d.Days = 1 Then
                        dys = d.Days & " day"
                    ElseIf d.Days > 1 Then
                        dys = d.Days & " days"
                    End If

                    If d.Hours = 1 Then
                        hrs = d.Hours & " hr"
                    ElseIf d.Hours > 1 Then
                        hrs = d.Hours & " hrs"
                    End If

                    If d.Minutes = 1 Then
                        mins = d.Minutes & " min"
                    ElseIf d.Minutes > 1 Then
                        mins = d.Minutes & " mins"
                    End If
                    est = Trim(dys & " " & hrs & " " & mins)
                End If
                grdpoi.Rows.Add(v0, v1, v2, v3, v4, v5, est, v7, "", v8)
                grdpoi.Rows(grdpoi.Rows.Count - 1).Cells("taym").Tag = v6.ToString
            End If
        End If
    End Sub

    Private Sub backgroundWorker_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        If Not backgroundWorker.IsBusy Then
            backgroundWorkertags.WorkerReportsProgress = True
            backgroundWorkertags.WorkerSupportsCancellation = True
            backgroundWorkertags.RunWorkerAsync()
        End If
        'Me.Cursor = Cursors.Default
        ''ProgressBar1.Visible = False
        ''ProgressBar1.Style = ProgressBarStyle.Blocks
        ''lblloading.Visible = False
        ''Panel1.Enabled = True
        'If e.Error IsNot Nothing Then
        '    MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        'ElseIf e.Cancelled = True Then
        '    MsgBox("Operation Is cancelled.", MsgBoxStyle.Exclamation, "")
        'Else
        '    If grdpoi.Rows.Count = 0 Then
        '        MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
        '    Else
        '        'If Trim(txttrip.Text) = "" And Trim(txtref.Text) = "" Then
        '        '    'MsgBox("Loading data completed.", MsgBoxStyle.Information, "")
        '        'End If
        '    End If
        'End If
    End Sub
    Private Sub backgroundWorkertags_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        threadEnabledtags = True

        For Each row As DataGridViewRow In grdpoi.Rows
            If backgroundWorkertags.CancellationPending = True Then
                e.Cancel = True
                Exit For
            End If

            gridsqltags = "Declare @result varchar(1000)"
            gridsqltags = gridsqltags & vbCrLf
            gridsqltags = gridsqltags & " Select @result = stuff((select ', '+convert(varchar(10),tag)"
            gridsqltags = gridsqltags & " from tblpoitags where poiid='" & grdpoi.Rows(row.Index).Cells("Id").Value & "' and status='1'"
            gridsqltags = gridsqltags & " For xml path (''), type).value('.','nvarchar(max)'),1,1,'')"
            gridsqltags = gridsqltags & vbCrLf
            gridsqltags = gridsqltags & " select @result as ptags"
            Dim connection As SqlConnection
            connection = New SqlConnection
            connection.ConnectionString = strconn
            If connection.State <> ConnectionState.Open Then
                connection.Open()
            End If
            cmd = New SqlCommand(gridsqltags, connection)
            Dim drx1 As SqlDataReader = cmd.ExecuteReader
            If drx1.Read Then
                tagsDGVRow(row.Index, drx1("ptags").ToString)
            End If
            drx1.Dispose()
            cmd.Dispose()
            connection.Close()
        Next
    End Sub

    Delegate Sub tagsRowDelegate(ByVal rowin As Object, ByVal val1 As Object)
    Private m_tagsRowDelegate As tagsRowDelegate

    Private Sub tagsDGVRow(ByVal rowin As Integer, ByVal val1 As String)
        If threadEnabledtags = True Then
            If grdpoi.InvokeRequired Then
                grdpoi.BeginInvoke(New tagsRowDelegate(AddressOf tagsDGVRow), rowin, val1)
            Else
                grdpoi.Rows(rowin).Cells("tayp").Value = val1
            End If
        End If
    End Sub
    Private Sub backgroundWorkertags_Completed(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        Me.Cursor = Cursors.Default
        ProgressBar1.Visible = False
        ProgressBar1.Style = ProgressBarStyle.Blocks
        lblloading.Visible = False
        GroupBox1.Enabled = True
        If e.Error IsNot Nothing Then
            MsgBox(e.Error.ToString, MsgBoxStyle.Critical, "")
        ElseIf e.Cancelled = True Then
            MsgBox("Operation Is cancelled.", MsgBoxStyle.Exclamation, "")
        Else
            If grdpoi.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            Else
                'If Trim(txttrip.Text) = "" And Trim(txtref.Text) = "" Then
                '    'MsgBox("Loading data completed.", MsgBoxStyle.Information, "")
                'End If
            End If
        End If
    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try
            clickbtn = "Search"

            If Trim(txtid.Text) = "" And Trim(txtpoi.Text) = "" And Trim(txtadd.Text) = "" And Trim(txtlat.Text) = "" And Trim(txtlng.Text) = "" Then
                MsgBox("Input poi.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            Else
                If Trim(txtid.Text).Length < 1 And Trim(txtpoi.Text).Length < 2 And Trim(txtadd.Text).Length < 2 And Trim(txtlat.Text).Length < 3 And Trim(txtlng.Text).Length < 3 Then
                    MsgBox("Input atleast 2 characters.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
            End If

            grdpoi.Rows.Clear()

            gridsql = "Select distinct p.poiid, p.poiname, p.address, p.latitude, p.longitude, p.area, d.value As distance, t.value As time, p.status"
            gridsql = gridsql & " from tblpoi p left outer join tblpoidistance d On p.poiid=d.poiid And d.whsename='" & login.whse & "'"
            gridsql = gridsql & " left outer join tblpoitime t on p.poiid=t.poiid and t.whsename='" & login.whse & "'"
            gridsql = gridsql & " where p.poiid<>''"

            'search
            If Trim(txtid.Text) <> "" Then
                gridsql = gridsql & " and p.poiid='" & txtid.Text & "'"
            End If

            If Trim(txtpoi.Text) <> "" Then
                gridsql = gridsql & " and p.poiname like '%" & Trim(txtpoi.Text.ToString.Replace("'", "''")) & "%'"
            End If

            If Trim(txtadd.Text) <> "" Then
                gridsql = gridsql & " and p.address like '%" & Trim(txtadd.Text.ToString.Replace("'", "''")) & "%'"
            End If

            If Trim(txtlat.Text) <> "" Then
                gridsql = gridsql & " and p.latitude = '" & Trim(txtlat.Text) & "'"
            End If

            If Trim(txtlng.Text) <> "" Then
                gridsql = gridsql & " and p.longitude = '" & Trim(txtlng.Text) & "'"
            End If

            gridsql = gridsql & " order by p.poiname"

            lblloading.Visible = True
            GroupBox1.Enabled = False
            ProgressBar1.Style = ProgressBarStyle.Marquee
            ProgressBar1.Visible = True
            ProgressBar1.Minimum = 0

            backgroundWorker = New BackgroundWorker()
            backgroundWorker.WorkerSupportsCancellation = True
            backgroundWorkertags = New BackgroundWorker()
            backgroundWorkertags.WorkerSupportsCancellation = True

            AddHandler backgroundWorker.DoWork, New DoWorkEventHandler(AddressOf backgroundWorker_DoWork)
            AddHandler backgroundWorker.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorker_Completed)
            m_addRowDelegate = New addRowDelegate(AddressOf addDGVRow)

            AddHandler backgroundWorkertags.DoWork, New DoWorkEventHandler(AddressOf backgroundWorkertags_DoWork)
            AddHandler backgroundWorkertags.RunWorkerCompleted, New RunWorkerCompletedEventHandler(AddressOf backgroundWorkertags_Completed)
            m_tagsRowDelegate = New tagsRowDelegate(AddressOf tagsDGVRow)

            If Not backgroundWorker.IsBusy Then
                backgroundWorker.WorkerReportsProgress = True
                backgroundWorker.WorkerSupportsCancellation = True
                backgroundWorker.RunWorkerAsync() 'start ng select query
            End If


            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            'check if complete details
            If Trim(txtpoi.Text) <> "" And Trim(txtadd.Text) <> "" And Trim(txtlat.Text) <> "" And Trim(txtlng.Text) <> "" And Trim(txtdis.Text) <> "" Then
                If IsNumeric(Trim(txtlat.Text)) = True Then
                    If Val(Trim(txtlat.Text)) < 0 Then
                        MsgBox("Invalid latitude.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                Else
                    MsgBox("Invalid latitude.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
                If IsNumeric(Trim(txtlng.Text)) = True Then
                    If Val(Trim(txtlng.Text)) < 0 Then
                        MsgBox("Invalid longitude.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                Else
                    MsgBox("Invalid longitude.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If

                If Trim(txttym.Text) <> "" Then
                    If IsNumeric(Trim(txttym.Text)) = True Then
                        If Val(Trim(txttym.Text)) < 0 Then
                            MsgBox("Invalid travel time.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If
                    Else
                        MsgBox("Invalid travel time.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                End If

                If IsNumeric(Trim(txtdis.Text)) = True Then
                    If Val(Trim(txtdis.Text)) > -1 Then
                        Dim lat As Double = Trim(txtlat.Text)
                        Dim lng As Double = Trim(txtlng.Text)

                        'check if already exist
                        sql = "Select status from tblpoi where latitude='" & lat & "' and longitude='" & lng & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            MsgBox("POI is already exist.", MsgBoxStyle.Exclamation, "")
                            txtpoi.Text = ""
                            txtpoi.Focus()
                            Exit Sub
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        cnf = False
                        confirmsave.GroupBox1.Text = login.neym
                        confirmsave.ShowDialog()
                        If cnf = True Then
                            ExecuteAdd(strconn)
                        End If
                    Else
                        MsgBox("Invalid distance.", MsgBoxStyle.Exclamation, "")
                    End If
                Else
                    MsgBox("Invalid distance.", MsgBoxStyle.Exclamation, "")
                End If
            Else
                MsgBox("Complete the fields.", MsgBoxStyle.Exclamation, "")
            End If
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub ExecuteAdd(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                Dim poiname As String = Trim(txtpoi.Text).ToString.Replace("'", "''")
                Dim address As String = Trim(txtadd.Text).ToString.Replace("'", "''")
                Dim lat As Double = Trim(txtlat.Text)
                Dim lng As Double = Trim(txtlng.Text)
                Dim distance As Double = Trim(txtdis.Text)
                Dim taym As Integer = Val(Trim(txttym.Text))
                Dim area As String = Trim(txtarea.Text).ToString.Replace("'", "''")

                sql = "Insert into tblpoi (poiname, address, latitude, longitude, area, datecreated, createdby, datemodified, modifiedby, status) values"
                sql = sql & " ('" & poiname & "', '" & address & "', '" & lat & "', '" & lng & "', '" & area & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                command.CommandText = sql
                command.ExecuteNonQuery()

                sql = "Insert into tblpoidistance (poiid, whsename, value, datecreated, createdby, datemodified, modifiedby, status)"
                sql = sql & " values ((Select TOP 1 poiid from tblpoi where latitude='" & lat & "' and longitude='" & lng & "' order by poiid DESC), '" & login.whse & "', '" & distance & "',"
                sql = sql & " GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                command.CommandText = sql
                command.ExecuteNonQuery()

                sql = "Insert into tblpoitime (poiid, whsename, value, datecreated, createdby, datemodified, modifiedby, status)"
                sql = sql & " values ((Select TOP 1 poiid from tblpoi where latitude='" & lat & "' and longitude='" & lng & "' order by poiid DESC), '" & login.whse & "',"
                If taym <> 0 Then
                    sql = sql & " '" & taym & "',"
                Else
                    sql = sql & " null,"
                End If
                sql = sql & " GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                command.CommandText = sql
                command.ExecuteNonQuery()


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully added.", MsgBoxStyle.Information, "")

                txtid.Text = ""
                txtid.ReadOnly = False
                txtadd.Text = ""
                txtlat.Text = ""
                txtlng.Text = ""
                txtdis.Text = ""
                txttym.Text = ""
                txtarea.Text = ""
                txtpoi.Focus()
                btnupdate.Text = "Update"
                btnsearch.Enabled = True
                btndeactivate.Enabled = True
                btnadd.Enabled = True

                btnsearch.PerformClick()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            Dim poiid As Integer, poiname As String, address As String, lat As Double, lng As Double, distance As String, taymins As String, area As String, tayp As String

            If grdpoi.SelectedRows.Count = 1 Or grdpoi.SelectedCells.Count = 1 Then
                If btnupdate.Text = "Update" Then
                    If grdpoi.Rows(grdpoi.CurrentRow.Index).Cells("Status").Value = "Deactivated" Then
                        MsgBox("Cannot update deactivated customer.", MsgBoxStyle.Exclamation, "")
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If

                    poiid = grdpoi.Rows(grdpoi.CurrentRow.Index).Cells("Id").Value
                    poiname = grdpoi.Rows(grdpoi.CurrentRow.Index).Cells("Poiname").Value
                    address = grdpoi.Rows(grdpoi.CurrentRow.Index).Cells("address").Value
                    lat = grdpoi.Rows(grdpoi.CurrentRow.Index).Cells("Latitude").Value
                    lng = grdpoi.Rows(grdpoi.CurrentRow.Index).Cells("Longitude").Value
                    distance = grdpoi.Rows(grdpoi.CurrentRow.Index).Cells("Distance").Value.ToString
                    taymins = grdpoi.Rows(grdpoi.CurrentRow.Index).Cells("taym").Tag.ToString
                    area = grdpoi.Rows(grdpoi.CurrentRow.Index).Cells("area").Value.ToString

                    txtid.Text = poiid
                    txtid.ReadOnly = True
                    txtpoi.Text = poiname
                    txtadd.Text = address
                    txtlat.Text = lat
                    txtlng.Text = lng
                    txtdis.Text = distance
                    txttym.Text = taymins
                    txtarea.Text = area

                    list1.Items.Clear()
                    sql = "Select tag from tblpoitags where status='1' and poiid='" & poiid & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    While dr.Read
                        list1.Items.Add(dr("tag").ToString)
                    End While
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    btnsearch.Enabled = False
                    btnadd.Enabled = False
                    btnupdate.Text = "Save"
                    btncancel.Enabled = True
                    btndeactivate.Enabled = False
                    linkadd.Enabled = True
                Else
                    'update
                    If Trim(txtpoi.Text) <> "" And Trim(txtadd.Text) <> "" And Trim(txtlat.Text) <> "" And Trim(txtlng.Text) <> "" Then
                        If IsNumeric(Trim(txtlat.Text)) = True Then
                            If Val(Trim(txtlat.Text)) < 0 Then
                                MsgBox("Invalid latitude.", MsgBoxStyle.Exclamation, "")
                                Exit Sub
                            End If
                        Else
                            MsgBox("Invalid latitude.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If
                        If IsNumeric(Trim(txtlng.Text)) = True Then
                            If Val(Trim(txtlng.Text)) < 0 Then
                                MsgBox("Invalid longitude.", MsgBoxStyle.Exclamation, "")
                                Exit Sub
                            End If
                        Else
                            MsgBox("Invalid longitude.", MsgBoxStyle.Exclamation, "")
                            Exit Sub
                        End If

                        If Trim(txtdis.Text) <> "" Then
                            If IsNumeric(Trim(txtdis.Text)) = True Then
                                If Val(Trim(txtdis.Text)) < 0 Then
                                    MsgBox("Invalid distance.", MsgBoxStyle.Exclamation, "")
                                    Exit Sub
                                End If
                            Else
                                MsgBox("Invalid distance.", MsgBoxStyle.Exclamation, "")
                                Exit Sub
                            End If
                        End If

                        If Trim(txttym.Text) <> "" Then
                            If IsNumeric(Trim(txttym.Text)) = True Then
                                If Val(Trim(txttym.Text)) < 0 Then
                                    MsgBox("Invalid travel time.", MsgBoxStyle.Exclamation, "")
                                    Exit Sub
                                End If
                            Else
                                MsgBox("Invalid travel time.", MsgBoxStyle.Exclamation, "")
                                Exit Sub
                            End If
                        End If
                    Else
                        MsgBox("Complete the fields.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If

                    'check if already exist
                    sql = "Select status from tblpoi where latitude='" & lat & "' and longitude='" & lng & "' and address='" & Trim(txtadd.Text.ToString.Replace("'", "''")) & "' and poiid<>'" & poiid & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox("POI is already exist.", MsgBoxStyle.Exclamation, "")
                        txtpoi.Text = ""
                        txtpoi.Focus()
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    cnf = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()
                    If cnf = True Then
                        ExecuteUpdate(strconn)
                    End If
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub ExecuteUpdate(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                Dim poiid As Integer = txtid.Text
                Dim poiname As String = Trim(txtpoi.Text).ToString.Replace("'", "''")
                Dim address As String = Trim(txtadd.Text).ToString.Replace("'", "''")
                Dim lat As Double = Trim(txtlat.Text)
                Dim lng As Double = Trim(txtlng.Text)
                Dim distance As Double = Val(Trim(txtdis.Text))
                Dim tymmins As Integer = Val(Trim(txttym.Text))
                Dim area As String = Trim(txtarea.Text).ToString.Replace("'", "''")

                sql = "Update tblpoi set poiname='" & poiname & "', address='" & address & "', latitude='" & lat & "', longitude='" & lng & "', area='" & area & "',"
                sql = sql & " datemodified=GetDate(), modifiedby='" & login.cashier & "' where poiid='" & poiid & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                If Trim(txtdis.Text) <> "" Then
                    sql = "Update tblpoidistance set value='" & distance & "' where poiid='" & poiid & "' and whsename='" & login.whse & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                Else
                    sql = "Update tblpoidistance set value=null where poiid='" & poiid & "' and whsename='" & login.whse & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                End If

                If Trim(txttym.Text) <> "" Then
                    sql = "Update tblpoitime set value='" & tymmins & "' where poiid='" & poiid & "' and whsename='" & login.whse & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                Else
                    sql = "Update tblpoitime set value=null where poiid='" & poiid & "' and whsename='" & login.whse & "'"
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                End If

                For i = 0 To list1.Items.Count - 1
                    Dim existna As Boolean = False
                    sql = "Select tag from tblpoitags where poiid='" & poiid & "' and tag='" & list1.Items(i).ToString.Replace("'", "''") & "'"
                    command.CommandText = sql
                    dr = command.ExecuteReader
                    If dr.Read Then
                        existna = True
                    End If
                    dr.Dispose()

                    If existna = False Then
                        sql = "Insert into tblpoitags (poiid, tag, datecreated, createdby, datemodified, modifiedby, status)"
                        sql = sql & " values ('" & poiid & "', '" & list1.Items(i).ToString.Replace("'", "''") & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                        command.CommandText = sql
                        command.ExecuteNonQuery()
                    End If
                Next


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")
                btnupdate.Text = "Update"
                btnsearch.Enabled = True
                btnadd.Enabled = True
                btndeactivate.Enabled = True
                linkadd.Enabled = False
                txtid.Text = ""
                txtid.ReadOnly = False
                txtadd.Text = ""
                txtlat.Text = ""
                txtlng.Text = ""
                txtdis.Text = ""
                txttym.Text = ""
                txtarea.Text = ""
                list1.Items.Clear()

                If clickbtn = "Search" Then
                    btnsearch.PerformClick()
                Else
                    btnview.PerformClick()
                End If

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub grdpoi_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdpoi.CellContentClick

    End Sub

    Private Sub btndeactivate_Click(sender As Object, e As EventArgs) Handles btndeactivate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdpoi.SelectedRows.Count = 1 Or grdpoi.SelectedCells.Count = 1 Then
                txtid.Tag = grdpoi.Rows(grdpoi.CurrentRow.Index).Cells(0).Value
                If btndeactivate.Text = "&Deactivate" Then
                    'check if theres item available status
                    sql = "Select status from tblortrans where (poiid='" & txtid.Tag & "' or pup_poiid='" & txtid.Tag & "') and (status='0' or status='1') and cancel='0'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox("Cannot deactivate. POI name is still in use.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    cnf = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()
                    If cnf = True Then
                        sql = "Update tblpoi set status='0', datemodified=GetDate(), modifiedby='" & login.cashier & "' where poiid='" & txtid.Tag & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        txtid.Tag = ""
                        If clickbtn = "Search" Then
                            btnsearch.PerformClick()
                        Else
                            btnview.PerformClick()
                        End If
                    End If

                Else
                    cnf = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()
                    If cnf = True Then
                        sql = "Update tblpoi set status='1', datemodified=GetDate(), modifiedby='" & login.cashier & "' where poiid='" & txtid.Tag & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        txtid.Tag = ""
                        If clickbtn = "Search" Then
                            btnsearch.PerformClick()
                        Else
                            btnview.PerformClick()
                        End If
                    End If
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub btnimport_Click(sender As Object, e As EventArgs) Handles btnimport.Click
        If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
            MsgBox("Access denied!", MsgBoxStyle.Critical, "")
            Exit Sub
        End If
        importpoi.ShowDialog()
    End Sub

    Private Sub btncancel_Click(sender As Object, e As EventArgs) Handles btncancel.Click
        txtid.Text = ""
        txtid.ReadOnly = False
        txtpoi.Text = ""
        txtadd.Text = ""
        txtlat.Text = ""
        txtlng.Text = ""
        txtdis.Text = ""
        txttym.Text = ""
        txtarea.Text = ""
        txtpoi.Focus()
        btnupdate.Text = "Update"
        btnsearch.Enabled = True
        btndeactivate.Enabled = True
        btnadd.Enabled = True
        linkadd.Enabled = False
        list1.Items.Clear()
    End Sub

    Private Sub btnexport_Click(sender As Object, e As EventArgs) Handles btnexport.Click

    End Sub

    Private Sub txtlat_TextChanged(sender As Object, e As EventArgs) Handles txtlat.TextChanged

    End Sub

    Private Sub grdpoi_SelectionChanged(sender As Object, e As EventArgs) Handles grdpoi.SelectionChanged
        If grdpoi.Rows(grdpoi.CurrentRow.Index).Cells("Status").Value = "Active" Then
            btndeactivate.Text = "&Deactivate"
        Else
            btndeactivate.Text = "A&ctivate"
        End If
    End Sub

    Private Sub txtlng_TextChanged(sender As Object, e As EventArgs) Handles txtlng.TextChanged

    End Sub

    Private Sub poi_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If threadEnabled = True Then
            If backgroundWorker.IsBusy = True Then
                If backgroundWorker.WorkerSupportsCancellation = True Then
                    backgroundWorker.CancelAsync()
                    threadEnabled = False
                End If
            End If
        End If

        If threadEnabledtags = True Then
            If backgroundWorkertags.IsBusy = True Then
                If backgroundWorkertags.WorkerSupportsCancellation = True Then
                    backgroundWorkertags.CancelAsync()
                    threadEnabledtags = False
                End If
            End If
        End If

        Me.Dispose()
    End Sub

    Private Sub txtdis_TextChanged(sender As Object, e As EventArgs) Handles txtdis.TextChanged

    End Sub

    Private Sub txtlat_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtlat.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtid_TextChanged(sender As Object, e As EventArgs) Handles txtid.TextChanged

    End Sub

    Private Sub txtlng_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtlng.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub linkadd_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles linkadd.LinkClicked
        poitagsadd.ShowDialog()
    End Sub

    Private Sub txttym_TextChanged(sender As Object, e As EventArgs) Handles txttym.TextChanged

    End Sub

    Private Sub list1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles list1.SelectedIndexChanged

    End Sub

    Private Sub txtdis_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtdis.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtid_Leave(sender As Object, e As EventArgs) Handles txtid.Leave
        If Trim(txtid.Text) <> "" Then
            If IsNumeric(Trim(txtid.Text)) = False Then
                MsgBox("Invalid POI ID.", MsgBoxStyle.Exclamation, "")
                txtid.Text = ""
                txtid.Focus()
            End If
        End If
    End Sub

    Private Sub list1_KeyDown(sender As Object, e As KeyEventArgs) Handles list1.KeyDown
        If linkadd.Enabled = True Then
            Dim a As String = MsgBox("Are you sure you want to remove?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "")
            If a = vbYes Then
                ExecuteRemoveTag(strconn)
                If e.KeyCode = Keys.Delete AndAlso list1.SelectedItem <> Nothing Then
                    list1.Items.RemoveAt(list1.SelectedIndex)
                End If
            End If
        End If
    End Sub

    Private Sub ExecuteRemoveTag(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                Dim poiid As Integer = txtid.Text

                sql = "Update tblpoitags set status=0 where tag='" & list1.Items(list1.SelectedIndex) & "' and status='1'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                'delete

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub
End Class