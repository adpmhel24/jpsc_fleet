﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class assessedit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(assessedit))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtcom = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.linkadd = New System.Windows.Forms.LinkLabel()
        Me.list1 = New System.Windows.Forms.ListBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btncat = New System.Windows.Forms.Button()
        Me.txtstep = New System.Windows.Forms.TextBox()
        Me.txtsub = New System.Windows.Forms.TextBox()
        Me.txttrip = New System.Windows.Forms.TextBox()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Trip#:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Step:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 68)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Subject:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtcom)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 118)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(288, 155)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Logistics"
        '
        'txtcom
        '
        Me.txtcom.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtcom.Location = New System.Drawing.Point(6, 27)
        Me.txtcom.Multiline = True
        Me.txtcom.Name = "txtcom"
        Me.txtcom.Size = New System.Drawing.Size(276, 121)
        Me.txtcom.TabIndex = 7
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.linkadd)
        Me.GroupBox2.Controls.Add(Me.list1)
        Me.GroupBox2.Location = New System.Drawing.Point(306, 118)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(213, 155)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Employee"
        '
        'linkadd
        '
        Me.linkadd.AutoSize = True
        Me.linkadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.linkadd.LinkColor = System.Drawing.Color.Green
        Me.linkadd.Location = New System.Drawing.Point(177, 11)
        Me.linkadd.Name = "linkadd"
        Me.linkadd.Size = New System.Drawing.Size(35, 13)
        Me.linkadd.TabIndex = 1
        Me.linkadd.TabStop = True
        Me.linkadd.Text = "+ Add"
        '
        'list1
        '
        Me.list1.FormattingEnabled = True
        Me.list1.Location = New System.Drawing.Point(6, 27)
        Me.list1.Name = "list1"
        Me.list1.Size = New System.Drawing.Size(201, 121)
        Me.list1.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btncat)
        Me.GroupBox3.Controls.Add(Me.txtstep)
        Me.GroupBox3.Controls.Add(Me.txtsub)
        Me.GroupBox3.Controls.Add(Me.txttrip)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(507, 100)
        Me.GroupBox3.TabIndex = 8
        Me.GroupBox3.TabStop = False
        '
        'btncat
        '
        Me.btncat.Image = CType(resources.GetObject("btncat.Image"), System.Drawing.Image)
        Me.btncat.Location = New System.Drawing.Point(479, 63)
        Me.btncat.Name = "btncat"
        Me.btncat.Size = New System.Drawing.Size(22, 22)
        Me.btncat.TabIndex = 6
        Me.btncat.UseVisualStyleBackColor = True
        '
        'txtstep
        '
        Me.txtstep.BackColor = System.Drawing.Color.White
        Me.txtstep.Location = New System.Drawing.Point(60, 39)
        Me.txtstep.Name = "txtstep"
        Me.txtstep.ReadOnly = True
        Me.txtstep.Size = New System.Drawing.Size(440, 20)
        Me.txtstep.TabIndex = 5
        '
        'txtsub
        '
        Me.txtsub.BackColor = System.Drawing.Color.White
        Me.txtsub.Location = New System.Drawing.Point(60, 65)
        Me.txtsub.Name = "txtsub"
        Me.txtsub.ReadOnly = True
        Me.txtsub.Size = New System.Drawing.Size(413, 20)
        Me.txtsub.TabIndex = 4
        '
        'txttrip
        '
        Me.txttrip.BackColor = System.Drawing.Color.White
        Me.txttrip.Location = New System.Drawing.Point(60, 13)
        Me.txttrip.Name = "txttrip"
        Me.txttrip.ReadOnly = True
        Me.txttrip.Size = New System.Drawing.Size(440, 20)
        Me.txttrip.TabIndex = 3
        '
        'btnsave
        '
        Me.btnsave.Image = CType(resources.GetObject("btnsave.Image"), System.Drawing.Image)
        Me.btnsave.Location = New System.Drawing.Point(445, 279)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(75, 23)
        Me.btnsave.TabIndex = 9
        Me.btnsave.Text = "Save"
        Me.btnsave.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnsave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'assessedit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(531, 308)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.btnsave)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "assessedit"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Edit"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtcom As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents linkadd As LinkLabel
    Friend WithEvents list1 As ListBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents btncat As Button
    Friend WithEvents txtstep As TextBox
    Friend WithEvents txtsub As TextBox
    Friend WithEvents txttrip As TextBox
    Friend WithEvents btnsave As Button
End Class
