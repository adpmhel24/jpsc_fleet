﻿Public Class m_app_completed
    Public Property mid As Nullable(Of Integer)
    Public Property platenumber As String
    Public Property vehicle_type As String
    Public Property tvirnum As String
    Public Property c_date As Date
    Public Property c_finish As Nullable(Of DateTime)
    Public Property c_start As Nullable(Of DateTime)
    Public Property mechanic As String
    Public Property second_Stat As String
    Public Property status As String
    Public Property remarks As String
End Class
