﻿Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel
Public Class importpoi
    Dim SheetList As New ArrayList
    Dim MyConnection As OleDbConnection
    Dim DtSet As System.Data.DataSet
    Dim MyCommand As OleDbDataAdapter
    Dim ii As Integer
    Dim checkBoxColumn As New DataGridViewCheckBoxColumn()
    Dim ds As New DataSet
    Dim dv As DataView

    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim derrors As Boolean = False
    Public importcnf As Boolean = False

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub importpoi_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub importpoi_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Dispose()
    End Sub

    Private Sub importpoi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'DtSet.Clear()
        txtPath.Text = ""
        btnLoadData.Enabled = False
        btncheck.Enabled = False
        btnadd.Enabled = False
        'dgvdata.Rows.Clear()
        dgvdata.Columns.Clear()
    End Sub

    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        With OpenFileDialog1
            .FileName = "Excel File"
            .Filter = "Excel Worksheets|*.xls;*.xlsx"
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                txtPath.Text = .FileName
                If txtPath.Text <> "" Then
                    btnLoadData.Enabled = True
                    btncheck.Enabled = False
                    btnadd.Enabled = False
                Else
                    btnLoadData.Enabled = False
                End If
            End If
        End With
    End Sub

    Private Sub btnLoadData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadData.Click
        Try
            ' DtSet.Clear()
            Me.Cursor = Cursors.WaitCursor

            MyConnection = New OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0;Data Source='" & txtPath.Text & "';Extended Properties=""Excel 8.0;HDR={1}""")

            Dim objExcel As Excel.Application
            Dim objWorkBook As Excel.Workbook
            Dim objWorkSheets As Excel.Worksheet
            Dim ExcelSheetName As String = ""

            objExcel = CreateObject("Excel.Application")
            objWorkBook = objExcel.Workbooks.Open(txtPath.Text)

            For Each objWorkSheets In objWorkBook.Worksheets
                SheetList.Add(objWorkSheets.Name)
            Next

            MyCommand = New OleDbDataAdapter("select * from [" & SheetList(0) & "$]", MyConnection)
            MyCommand.TableMappings.Add("Table", "Net-informations.com")
            'MsgBox(SheetList(0).ToString)
            DtSet = New System.Data.DataSet
            MyCommand.Fill(DtSet)
            dgvdata.DataSource = DtSet.Tables(0)
            ' MyCommand.Dispose()
            MyConnection.Close()

            objWorkBook.Close()
            objExcel.Quit()

            releaseObject(objWorkBook)
            releaseObject(objExcel)

            Me.Cursor = Cursors.Default

            dgvdata.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True
            'dgvdata.ColumnHeadersHeight = 40
            dgvdata.Columns(0).Width = 200
            dgvdata.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
            dgvdata.Columns(1).Width = 200
            dgvdata.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
            dgvdata.Columns(2).Width = 180
            dgvdata.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
            dgvdata.Columns(3).Width = 200
            dgvdata.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

            If dgvdata.Rows.Count <> 0 Then
                btncheck.Enabled = True
            Else
                btncheck.Enabled = False
            End If

            derrors = False

            'remember: sa price kung nde sya numeric di sya iloload
            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " + ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub btncheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncheck.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            'dito magaganap ung checking of errors
            '////check yung per column if wlng magkaparehas n item code and item name

            checkinput()

            If derrors = False Then
                MsgBox("Click add button to continue.", MsgBoxStyle.Information, "")
                btnadd.Enabled = True
            Else
                MsgBox("Error occurred. Please correct the highlighted errors and try again.", MsgBoxStyle.Critical, "")
                btnadd.Enabled = False
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checkinput()
        Try
            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                'cells(0)


                'check if null
                If dgvdata.Rows(row.Index).Cells(0).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(0).ToolTipText = "POI Name should not be null."
                    dgvdata.Rows(row.Index).Cells(0).Selected = True
                    dgvdata.Rows(row.Index).Cells(0).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                'check if null
                If dgvdata.Rows(row.Index).Cells(1).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(1).ToolTipText = "POI Address should not be null."
                    dgvdata.Rows(row.Index).Cells(1).Selected = True
                    dgvdata.Rows(row.Index).Cells(1).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(2).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(2).ToolTipText = "Latitude should not be null."
                    dgvdata.Rows(row.Index).Cells(2).Selected = True
                    dgvdata.Rows(row.Index).Cells(2).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(3).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(3).ToolTipText = "Longitude should not be null."
                    dgvdata.Rows(row.Index).Cells(3).Selected = True
                    dgvdata.Rows(row.Index).Cells(3).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                'If dgvdata.Rows(row.Index).Cells(6).Value.ToString = "" Then
                '    dgvdata.ClearSelection()
                '    dgvdata.Rows(row.Index).Cells(6).ToolTipText = "null."
                '    dgvdata.Rows(row.Index).Cells(6).Selected = True
                '    dgvdata.Rows(row.Index).Cells(6).Style.BackColor = Color.Yellow
                '    dgvdata.ClearSelection()
                'End If

                If dgvdata.Rows(row.Index).Cells(0).Value.ToString <> "" Then
                    sql = "Select latitude,longitude from tblpoi where latitude='" & dgvdata.Rows(row.Index).Cells(2).Value & "' and longitude='" & dgvdata.Rows(row.Index).Cells(3).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(0).ToolTipText = "POI coordinates" & dgvdata.Rows(row.Index).Cells(0).Value.ToString & " is already exist."
                        dgvdata.Rows(row.Index).Cells(0).Selected = True
                        dgvdata.Rows(row.Index).Cells(0).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            importcnf = False
            If derrors = False Then
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If importcnf = True Then
                    ExecuteAdd(strconn)
                End If
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteAdd(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                For Each row As DataGridViewRow In dgvdata.Rows
                    Dim ipoi As String = Trim(dgvdata.Rows(row.Index).Cells(0).Value.ToString.Replace("'", "''"))
                    Dim iadd As String = Trim(dgvdata.Rows(row.Index).Cells(1).Value.ToString.Replace("'", "''"))
                    Dim ilat As String = dgvdata.Rows(row.Index).Cells(2).Value
                    Dim ilng As String = dgvdata.Rows(row.Index).Cells(3).Value
                    'Dim whse1 As String = Val(dgvdata.Rows(row.Index).Cells(4).Value.ToString)
                    'Dim whse2 As String = Val(dgvdata.Rows(row.Index).Cells(5).Value.ToString)
                    'Dim whse3 As String = Val(dgvdata.Rows(row.Index).Cells(6).Value.ToString)
                    'Dim whse4 As String = Val(dgvdata.Rows(row.Index).Cells(7).Value.ToString)
                    'Dim whse5 As String = Val(dgvdata.Rows(row.Index).Cells(8).Value.ToString)
                    'Dim whse6 As String = Val(dgvdata.Rows(row.Index).Cells(9).Value.ToString)
                    'Dim whse7 As String = Val(dgvdata.Rows(row.Index).Cells(10).Value.ToString)

                    sql = "Insert into tblpoi (poiname, address, latitude, longitude, datecreated, createdby, datemodified, modifiedby, status) values"
                    sql = sql & " ('" & ipoi & "', '" & iadd & "', '" & ilat & "', '" & ilng & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                    command.CommandText = sql
                    command.ExecuteNonQuery()

                    For Each col As DataGridViewColumn In dgvdata.Columns
                        If col.Index >= 4 Then
                            If Trim(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString) <> "" Then
                                Dim whsedis As Double = Val(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString)
                                sql = "Insert into tblpoidistance (poiid, whsename, value, datecreated, createdby, datemodified, modifiedby, status)"
                                sql = sql & " values ((Select TOP 1 poiid from tblpoi where latitude='" & ilat & "' and longitude='" & ilng & "' order by poiid DESC), '" & dgvdata.Columns(col.Index).HeaderText & "', '" & whsedis & "',"
                                sql = sql & " GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                            Else
                                'null ung value
                                sql = "Insert into tblpoidistance (poiid, whsename, value, datecreated, createdby, datemodified, modifiedby, status)"
                                sql = sql & " values ((Select TOP 1 poiid from tblpoi where latitude='" & ilat & "' and longitude='" & ilng & "' order by poiid DESC), '" & dgvdata.Columns(col.Index).HeaderText & "', null,"
                                sql = sql & " GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                            End If

                            command.CommandText = sql
                            command.ExecuteNonQuery()
                        End If
                    Next
                Next


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully Added.", MsgBoxStyle.Information, "")
                Me.Close()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        Try
            checkpoi()

            'Exit Sub
            importcnf = False
            If derrors = False Then
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If importcnf = True Then
                    ExecuteUpdate(strconn)
                End If
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub


    Private Sub ExecuteUpdate(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                For Each row As DataGridViewRow In dgvdata.Rows
                    Dim ipoiid As String = Trim(dgvdata.Rows(row.Index).Cells(22).Value.ToString)
                    If ipoiid <> "" Then
                        'MsgBox(ipoiid)
                        'Exit Sub
                        For Each col As DataGridViewColumn In dgvdata.Columns
                            If col.Index >= 4 And col.Index <= 21 And col.HeaderText.Contains("Time") = False Then
                                If Trim(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString) <> "" Then
                                    'Dim taym As String = Trim(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString)
                                    'Dim strTest() As String, intMinutes As Integer
                                    'strTest = Split(taym, ":")
                                    'intMinutes = CInt(strTest(0)) * 60 + CInt(strTest(1))
                                    Dim vv As Integer = Val(Trim(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString))
                                    'MsgBox(intMinutes)
                                    'Dim whsetime As Double = Val(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString)
                                    sql = "Insert into tblpoitime (poiid, whsename, value, datecreated, createdby, datemodified, modifiedby, status)"
                                    sql = sql & " values ('" & ipoiid & "', '" & dgvdata.Columns(col.Index).HeaderText & "', '" & vv & "',"
                                    sql = sql & " GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                                Else
                                    'null ung value
                                    sql = "Insert into tblpoitime (poiid, whsename, value, datecreated, createdby, datemodified, modifiedby, status)"
                                    sql = sql & " values ('" & ipoiid & "', '" & dgvdata.Columns(col.Index).HeaderText & "', null,"
                                    sql = sql & " GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                                End If

                                command.CommandText = sql
                                command.ExecuteNonQuery()
                            End If
                        Next
                    End If
                Next


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")
                Me.Close()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub


    Public Sub checkpoi()
        Try
            'add column sa dulo
            dgvdata.Columns.Add("poiid", "ID")
            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                'cells(0)


                'check if null
                If dgvdata.Rows(row.Index).Cells(0).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(0).ToolTipText = "POI Name should not be null."
                    dgvdata.Rows(row.Index).Cells(0).Selected = True
                    dgvdata.Rows(row.Index).Cells(0).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                'check if null
                If dgvdata.Rows(row.Index).Cells(1).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(1).ToolTipText = "POI Address should not be null."
                    dgvdata.Rows(row.Index).Cells(1).Selected = True
                    dgvdata.Rows(row.Index).Cells(1).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(2).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(2).ToolTipText = "Latitude should not be null."
                    dgvdata.Rows(row.Index).Cells(2).Selected = True
                    dgvdata.Rows(row.Index).Cells(2).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(3).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(3).ToolTipText = "Longitude should not be null."
                    dgvdata.Rows(row.Index).Cells(3).Selected = True
                    dgvdata.Rows(row.Index).Cells(3).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                'If dgvdata.Rows(row.Index).Cells(6).Value.ToString = "" Then
                '    dgvdata.ClearSelection()
                '    dgvdata.Rows(row.Index).Cells(6).ToolTipText = "null."
                '    dgvdata.Rows(row.Index).Cells(6).Selected = True
                '    dgvdata.Rows(row.Index).Cells(6).Style.BackColor = Color.Yellow
                '    dgvdata.ClearSelection()
                'End If

                If dgvdata.Rows(row.Index).Cells(0).Value.ToString <> "" Then
                    sql = "Select poiid from tblpoi where latitude='" & dgvdata.Rows(row.Index).Cells(2).Value & "' and longitude='" & dgvdata.Rows(row.Index).Cells(3).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        dgvdata.Rows(row.Index).Cells(22).Value = dr("poiid")
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            dgvdata.Columns.Add("5", "POI ID")
            dgvdata.Columns.Add("6", "DIS MilAOR")
            dgvdata.Columns.Add("7", "TIME MILAOR")
            dgvdata.Columns.Add("8", "DIS C3")
            dgvdata.Columns.Add("9", "TIME C3")
            dgvdata.Columns.Add("10", "DIS CAL")
            dgvdata.Columns.Add("11", "TIME CAL")
            dgvdata.Columns.Add("12", "DIS PGB")
            dgvdata.Columns.Add("13", "TIME PGB")
            dgvdata.Columns.Add("14", "DIS CEB")
            dgvdata.Columns.Add("15", "TIME CEB")
            dgvdata.Columns.Add("16", "DIS DAV")
            dgvdata.Columns.Add("17", "TIME DAV")
            dgvdata.Columns.Add("18", "DIS BCD")
            dgvdata.Columns.Add("19", "TIME BCD")
            dgvdata.Columns.Add("20", "DIS TAC")
            dgvdata.Columns.Add("21", "TIME TAC")
            dgvdata.Columns.Add("22", "DIS ILO")
            dgvdata.Columns.Add("23", "TIME ILO")

            For Each row As DataGridViewRow In dgvdata.Rows
                If dgvdata.Rows(row.Index).Cells(1).Value.ToString <> "" Then
                    Dim pid As Boolean = False
                    sql = "Select poiid from tblpoi where latitude='" & dgvdata.Rows(row.Index).Cells(3).Value & "' and longitude='" & dgvdata.Rows(row.Index).Cells(4).Value & "' and status='1'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        dgvdata.Rows(row.Index).Cells(5).Value = dr("poiid")
                        pid = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    If pid = True Then
                        sql = "Select p.poiid, d.whsename, d.value from tblpoi p left outer join tblpoidistance d on p.poiid=d.poiid where p.poiid='" & dgvdata.Rows(row.Index).Cells(5).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        While dr.Read
                            If dr("whsename") = "Milaor" Then
                                dgvdata.Rows(row.Index).Cells(6).Value = dr("value").ToString
                            ElseIf dr("whsename") = "C3 Manila" Then
                                dgvdata.Rows(row.Index).Cells(8).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Calamba" Then
                                dgvdata.Rows(row.Index).Cells(10).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Pagbilao" Then
                                dgvdata.Rows(row.Index).Cells(12).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Cebu" Then
                                dgvdata.Rows(row.Index).Cells(14).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Davao" Then
                                dgvdata.Rows(row.Index).Cells(16).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Bacolod" Then
                                dgvdata.Rows(row.Index).Cells(18).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Tacloban" Then
                                dgvdata.Rows(row.Index).Cells(20).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Ilo-Ilo" Then
                                dgvdata.Rows(row.Index).Cells(22).Value = dr("value").ToString
                            End If
                        End While
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        sql = "Select p.poiid, d.whsename, d.value from tblpoi p left outer join tblpoitime d on p.poiid=d.poiid where p.poiid='" & dgvdata.Rows(row.Index).Cells(5).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        While dr.Read
                            If dr("whsename") = "Milaor" Then
                                dgvdata.Rows(row.Index).Cells(7).Value = dr("value").ToString
                            ElseIf dr("whsename") = "C3 Manila" Then
                                dgvdata.Rows(row.Index).Cells(9).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Calamba" Then
                                dgvdata.Rows(row.Index).Cells(11).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Pagbilao" Then
                                dgvdata.Rows(row.Index).Cells(13).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Cebu" Then
                                dgvdata.Rows(row.Index).Cells(15).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Davao" Then
                                dgvdata.Rows(row.Index).Cells(17).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Bacolod" Then
                                dgvdata.Rows(row.Index).Cells(19).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Tacloban" Then
                                dgvdata.Rows(row.Index).Cells(21).Value = dr("value").ToString
                            ElseIf dr("whsename") = "Ilo-Ilo" Then
                                dgvdata.Rows(row.Index).Cells(23).Value = dr("value").ToString
                            End If
                        End While
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        Dim cus As String = ""
                        sql = "select c.customer, cp.poiid from tblcustomer c inner join tblcuspoi cp on c.cusid=cp.cusid where cp.poiid='" & dgvdata.Rows(row.Index).Cells(5).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        While dr.Read
                            If cus = "" Then
                                cus = dr("customer")
                            Else
                                cus = cus & " / " & dr("customer")
                            End If
                        End While
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        dgvdata.Rows(row.Index).Cells(0).Value = cus
                    End If

                End If
            Next
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        derrors = False
        modifycol()

        importcnf = False
        If derrors = False Then
            confirmsave.GroupBox1.Text = login.neym
            confirmsave.ShowDialog()
            If importcnf = True Then
                ExecuteAddUpdatePOI(strconn)
            End If
        Else
            MsgBox("with error")
        End If
    End Sub

    Private Sub modifycol()
        dgvdata.Columns(5).Name = "m1"
        dgvdata.Columns(5).HeaderText = "Milaor"
        dgvdata.Columns(7).Name = "m2"
        dgvdata.Columns(7).HeaderText = "Milaor"

        dgvdata.Columns(8).Name = "cm1"
        dgvdata.Columns(8).HeaderText = "C3 Manila"
        dgvdata.Columns(10).Name = "cm2"
        dgvdata.Columns(10).HeaderText = "C3 Manila"

        dgvdata.Columns(11).Name = "c1"
        dgvdata.Columns(11).HeaderText = "Calamba"
        dgvdata.Columns(13).Name = "c2"
        dgvdata.Columns(13).HeaderText = "Calamba"

        dgvdata.Columns(14).Name = "p1"
        dgvdata.Columns(14).HeaderText = "Pagbilao"
        dgvdata.Columns(16).Name = "p2"
        dgvdata.Columns(16).HeaderText = "Pagbilao"

        dgvdata.Columns(17).Name = "cb1"
        dgvdata.Columns(17).HeaderText = "Cebu"
        dgvdata.Columns(19).Name = "cb2"
        dgvdata.Columns(19).HeaderText = "Cebu"

        dgvdata.Columns(20).Name = "d1"
        dgvdata.Columns(20).HeaderText = "Davao"
        dgvdata.Columns(22).Name = "d2"
        dgvdata.Columns(22).HeaderText = "Davao"

        dgvdata.Columns(23).Name = "bc1"
        dgvdata.Columns(23).HeaderText = "Bacolod"
        dgvdata.Columns(25).Name = "bc2"
        dgvdata.Columns(25).HeaderText = "Bacolod"

        dgvdata.Columns(26).Name = "t1"
        dgvdata.Columns(26).HeaderText = "Tacloban"
        dgvdata.Columns(28).Name = "t2"
        dgvdata.Columns(28).HeaderText = "Tacloban"

        dgvdata.Columns(29).Name = "l1"
        dgvdata.Columns(29).HeaderText = "Ilo-Ilo"
        dgvdata.Columns(31).Name = "l2"
        dgvdata.Columns(31).HeaderText = "Ilo-Ilo"
    End Sub

    Private Sub insertpoiid()
        Try
            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                'cells(0)


                'check if null
                If dgvdata.Rows(row.Index).Cells(0).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(0).ToolTipText = "POI Name should not be null."
                    dgvdata.Rows(row.Index).Cells(0).Selected = True
                    dgvdata.Rows(row.Index).Cells(0).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                'check if null
                If dgvdata.Rows(row.Index).Cells(1).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(1).ToolTipText = "POI Address should not be null."
                    dgvdata.Rows(row.Index).Cells(1).Selected = True
                    dgvdata.Rows(row.Index).Cells(1).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(2).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(2).ToolTipText = "Latitude should not be null."
                    dgvdata.Rows(row.Index).Cells(2).Selected = True
                    dgvdata.Rows(row.Index).Cells(2).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(3).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(3).ToolTipText = "Longitude should not be null."
                    dgvdata.Rows(row.Index).Cells(3).Selected = True
                    dgvdata.Rows(row.Index).Cells(3).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(0).Value.ToString <> "" Then
                    sql = "Select poiid from tblpoi where poiname='" & dgvdata.Rows(row.Index).Cells(0).Value.ToString.Replace("'", "''") & "' and latitude='" & dgvdata.Rows(row.Index).Cells(2).Value & "' and longitude='" & dgvdata.Rows(row.Index).Cells(3).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        dgvdata.Rows(row.Index).Cells(4).Value = dr("poiid")
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteAddUpdatePOI(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                'For Each row As DataGridViewRow In dgvdata.Rows

                '    MsgBox(row.Index)
                '    End If
                'Next

                'Exit Sub
                For Each row As DataGridViewRow In dgvdata.Rows
                    'If row.Index >= 0 And row.Index <= 4999 Then
                    Dim poiname As String = Trim(dgvdata.Rows(row.Index).Cells(0).Value.ToString.Replace("'", "''"))
                    Dim poiaddress As String = Trim(dgvdata.Rows(row.Index).Cells(1).Value.ToString.Replace("'", "''"))
                    Dim lat As String = Trim(dgvdata.Rows(row.Index).Cells(2).Value)
                    Dim lng As String = Trim(dgvdata.Rows(row.Index).Cells(3).Value)
                    Dim ipoiid As String = Trim(dgvdata.Rows(row.Index).Cells(4).Value.ToString)
                    If ipoiid <> "" Then
                        'Update
                        'MsgBox(ipoiid)
                        For Each col As DataGridViewColumn In dgvdata.Columns
                            If (col.Index = 5 Or col.Index = 8 Or col.Index = 11 Or col.Index = 14 Or col.Index = 17 Or col.Index = 20 Or col.Index = 23 Or col.Index = 26 Or col.Index = 29) Then
                                'Distance
                                'MsgBox("Distance " & dgvdata.Columns(col.Index).HeaderText)

                                If Trim(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString) <> "" Then
                                    'Dim vv As Double = Val(Trim(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString))

                                    'sql = "Update tblpoidistance set value='" & vv & "'"
                                    'sql = sql & " where poiid='" & ipoiid & "' and whsename='" & dgvdata.Columns(col.Index).HeaderText & "'"
                                    'command.CommandText = sql
                                    'command.ExecuteNonQuery()

                                    'Else
                                    '    'null ung value
                                    '    sql = "Update tblpoidistance set value=null"
                                    '    sql = sql & " where poiid='" & ipoiid & "' and whsename='" & dgvdata.Columns(col.Index).HeaderText & "' and value is null"
                                End If
                                'col.Index = Trim(txt.Text) Then 

                            ElseIf (col.Index = 7 Or col.Index = 10 Or col.Index = 13 Or col.Index = 16 Or col.Index = 19 Or col.Index = 22 Or col.Index = 25 Or col.Index = 28 Or col.Index = 31) Then
                                'Time in mins
                                'MsgBox("Time " & dgvdata.Columns(col.Index).HeaderText)
                                If Trim(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString) <> "" Then
                                    Dim vv As Integer = Val(Trim(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString))

                                    sql = "Update tblpoitime set value='" & vv & "'"
                                    sql = sql & " where poiid='" & ipoiid & "' and whsename='" & dgvdata.Columns(col.Index).HeaderText & "'"
                                    command.CommandText = sql
                                    command.ExecuteNonQuery()
                                    'Else
                                    '    'null ung value
                                    '    sql = "Update tblpoitime set value=null"
                                    '    sql = sql & " where poiid='" & ipoiid & "' and whsename='" & dgvdata.Columns(col.Index).HeaderText & "' and value is null"
                                End If

                            End If
                        Next
                    Else
                        'MsgBox(poiname)
                        'Insert into tblpoi
                        'sql = "Insert into tblpoi (poiname, address, latitude, longitude, datecreated, createdby, datemodified, modifiedby, status) values"
                        'sql = sql & " ('" & poiname & "', '" & poiaddress & "', '" & lat & "', '" & lng & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                        'command.CommandText = sql
                        'command.ExecuteNonQuery()

                        'For Each col As DataGridViewColumn In dgvdata.Columns
                        '    If (col.Index = 5 Or col.Index = 8 Or col.Index = 11 Or col.Index = 14 Or col.Index = 17 Or col.Index = 20 Or col.Index = 23 Or col.Index = 26 Or col.Index = 29) Then
                        '        'Distance
                        '        If Trim(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString) <> "" Then
                        '            Dim vv As Double = Val(Trim(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString))

                        '            sql = "Insert into tblpoidistance (poiid, whsename, value, datecreated, createdby, datemodified, modifiedby, status)"
                        '            sql = sql & " values ((Select TOP 1 poiid from tblpoi where latitude='" & lat & "' and longitude='" & lng & "' order by poiid DESC),"
                        '            sql = sql & " '" & dgvdata.Columns(col.Index).HeaderText & "', '" & vv & "',"
                        '            sql = sql & " GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                        '        Else
                        '            'null ung value
                        '            sql = "Insert into tblpoidistance (poiid, whsename, value, datecreated, createdby, datemodified, modifiedby, status)"
                        '            sql = sql & " values ((Select TOP 1 poiid from tblpoi where latitude='" & lat & "' and longitude='" & lng & "' order by poiid DESC),"
                        '            sql = sql & " '" & dgvdata.Columns(col.Index).HeaderText & "', null,"
                        '            sql = sql & " GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                        '        End If
                        '        command.CommandText = sql
                        '        command.ExecuteNonQuery()

                        '    ElseIf (col.Index = 7 Or col.Index = 10 Or col.Index = 13 Or col.Index = 16 Or col.Index = 19 Or col.Index = 22 Or col.Index = 25 Or col.Index = 28 Or col.Index = 31) Then
                        '        'Time in mins
                        '        If Trim(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString) <> "" Then
                        '            Dim vv As Integer = Val(Trim(dgvdata.Rows(row.Index).Cells(col.Index).Value.ToString))

                        '            sql = "Insert into tblpoitime (poiid, whsename, value, datecreated, createdby, datemodified, modifiedby, status)"
                        '            sql = sql & " values ((Select TOP 1 poiid from tblpoi where latitude='" & lat & "' and longitude='" & lng & "' order by poiid DESC),"
                        '            sql = sql & " '" & dgvdata.Columns(col.Index).HeaderText & "', '" & vv & "',"
                        '            sql = sql & " GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                        '        Else
                        '            'null ung value
                        '            sql = "Insert into tblpoitime (poiid, whsename, value, datecreated, createdby, datemodified, modifiedby, status)"
                        '            sql = sql & " values ((Select TOP 1 poiid from tblpoi where latitude='" & lat & "' and longitude='" & lng & "' order by poiid DESC),"
                        '            sql = sql & " '" & dgvdata.Columns(col.Index).HeaderText & "', null,"
                        '            sql = sql & " GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                        '        End If
                        '        command.CommandText = sql
                        '        command.ExecuteNonQuery()
                        '    End If
                        'Next
                    End If
                    'Else
                    '    Exit For
                    'End If
                Next


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully Saved.", MsgBoxStyle.Information, "")
                'Me.Close()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        insertpoiid()
        Button2.Enabled = True
    End Sub
End Class