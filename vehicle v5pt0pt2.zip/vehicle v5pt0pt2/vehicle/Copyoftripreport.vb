﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Windows.Forms
Imports Excel = Microsoft.Office.Interop.Excel

Public Class Copyoftripreport
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Public sqlcondition As String = ""

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub tripreport_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated

    End Sub

    Private Sub tripreport_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

    End Sub

    Private Sub tripreport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        grdrep.Columns(6).Frozen = True
        loadplate()
        loadvtype()
        loaddriver()
        loadhelper()
        loadorigin()
        loadtripstat()
        loadcustomer()
        loadpickup()
    End Sub

    Public Sub loadplate()
        Try
            cmbplate.Items.Clear()

            sql = "Select * from tblgeneral order by platenum"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbplate.Items.Add(dr("platenum"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbplate.Items.Count <> 0 Then
                cmbplate.Items.Add("All")
                cmbplate.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadvtype()
        Try
            cmbtype.Items.Clear()

            sql = "Select * from tblvtype order by vtype"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbtype.Items.Add(dr("vtype"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbtype.Items.Count <> 0 Then
                cmbtype.Items.Add("All")
                cmbtype.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loaddriver()
        Try
            cmbdriver.Items.Clear()

            sql = "Select driver from tbldriver order by driver"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbdriver.Items.Add(dr("driver"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbdriver.Items.Count <> 0 Then
                cmbdriver.Items.Add("All")
                cmbdriver.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadhelper()
        Try
            cmbhelper.Items.Clear()

            sql = "Select * from tblhelper order by helper"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbhelper.Items.Add(dr("helper"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If cmbhelper.Items.Count <> 0 Then
                cmbhelper.Items.Add("All")
                cmbhelper.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadorigin()
        Try
            cmborigin.Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tblwhse where status='1' order by whsename"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmborigin.Items.Add(dr1("whsename"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            If cmborigin.Items.Count <> 0 Then
                cmborigin.Items.Add("All")
                cmborigin.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadtripstat()
        Try
            cmbtripstat.Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            cmbtripstat.Items.Add("Completed")
            cmbtripstat.Items.Add("In Process")
            cmbtripstat.Items.Add("Cancelled")

            If cmbtripstat.Items.Count <> 0 Then
                cmbtripstat.Items.Add("All")
                cmbtripstat.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadcustomer()
        Try
            cmbrec.Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(4), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tblcustomer where status='1' order by customer"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbrec.Items.Add(dr1("customer"))
            End While
            dr1.Dispose()
            cmd1.Dispose()
            conn.Close()

            If cmbrec.Items.Count <> 0 Then
                cmbrec.Items.Add("All")
                cmbrec.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub loadpickup()
        Try
            cmbpick.Items.Clear()
            cmbpick.Items.Add("")

            sql = "Select * from tblwhse where status='1' and (company='Atlantic Grains' or company='Supplier Warehouse') order by whsename"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                cmbpick.Items.Add(dr("whsename").ToString.ToUpper)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub btnok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try

            sqlcondition = " where tripsum.datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and tripsum.datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "'"

            If Trim(cmbplate.Text) <> "" And Trim(cmbplate.Text) <> "All" Then
                sqlcondition = sqlcondition & " and tripsum.platenum='" & Trim(cmbplate.Text) & "'"
            End If

            If Trim(cmbtype.Text) <> "" And Trim(cmbtype.Text) <> "All" Then
                'sqlcondition = sqlcondition & " and vtype='" & Trim(cmbtype.Text) & "'"
            End If

            If Trim(cmbdriver.Text) <> "" And Trim(cmbdriver.Text) <> "All" Then
                sqlcondition = sqlcondition & " and tripsum.driver='" & Trim(cmbdriver.Text) & "'"
            End If

            If Trim(cmbhelper.Text) <> "" And Trim(cmbhelper.Text) <> "All" Then
                sqlcondition = sqlcondition & " and tripsum.helper='" & Trim(cmbhelper.Text) & "'"
            End If

            If Trim(cmborigin.Text) <> "" And Trim(cmborigin.Text) <> "All" Then
                sqlcondition = sqlcondition & " and tripsum.origin='" & Trim(cmborigin.Text) & "'"
            End If

            If Trim(cmbtripstat.Text) <> "" And Trim(cmbtripstat.Text) <> "All" Then
                sqlcondition = sqlcondition & " and tripsum.status='" & Trim(cmbtripstat.Text) & "'"
            End If

            If Trim(cmbdispatch.Text) <> "" And Trim(cmbdispatch.Text) <> "All" Then
                'sqlcondition = sqlcondition & " and tbldispatchsum.status='" & Trim(cmbdispatch.Text) & "'"
            End If

            If Trim(cmbrec.Text) <> "" And Trim(cmbrec.Text) <> "All" Then
                sqlcondition = sqlcondition & " and tblortrans.customer='" & Trim(cmbrec.Text) & "'"
            End If

            If Trim(cmbtranstype.Text) <> "" And Trim(cmbtranstype.Text) <> "All" Then
                sqlcondition = sqlcondition & " and tblortrans.transtype='" & Trim(cmbtranstype.Text) & "'"
            End If

            If Trim(cmbpick.Text) <> "" And Trim(cmbpick.Text) <> "All" Then
                sqlcondition = sqlcondition & " and tblortrans.status='" & Trim(cmbpick.Text) & "'"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        Try
            If Trim(cmbtranstype.Text) <> "" And cmbtranstype.Text.Contains("PICKUP") And Trim(cmbpick.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Select pick up from.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If

            Me.Cursor = Cursors.WaitCursor

            Dim inSql As String = ""
            Dim firstPart As String
            Dim lastPart As String
            Dim selectStart As Integer
            Dim fromStart As Integer
            Dim fields As String()

            Dim sonum As String = "", ponum As String = "", swsnum As String = ""

            grdrep.Rows.Clear()
            'sql = "Select * from tbltripsum where tripsum.datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and tripsum.datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "'"
            'RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum

            sql = "SELECT tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.helper, tblortrans.transnum, tblortrans.customer, tblortrans.transtype, tblortrans.refnum, tblortrans.arnum, tblortrans.rdrnum, tblortrans.drnum, tblortrans.dnnum, tblortrans.notes, tblortrans.itrnum, tblortrans.itnum, tblortrans.grponum, Sum(tblorder.qty) as delqty, tblgeneral.vtype"

            sql = sql & " FROM tbltripitems RIGHT OUTER JOIN tbltripsum ON tbltripitems.tripnum=tbltripsum.tripnum"
            sql = sql & " RIGHT OUTER JOIN tblortrans ON tbltripitems.transnum=tblortrans.transnum"
            sql = sql & " RIGHT OUTER JOIN tblorder ON tblortrans.transnum=tblorder.transnum"
            sql = sql & " RIGHT OUTER JOIN tblgeneral ON tbltripsum.platenum=tblgeneral.platenum"
            sql = sql & " where datepick>='" & Format(datefrom.Value, "yyyy/MM/dd") & "' and datepick<='" & Format(dateto.Value, "yyyy/MM/dd") & "' and tbltripsum.whsename='" & login.whse & "'"

            If Trim(cmbplate.Text) <> "" And Trim(cmbplate.Text) <> "All" Then
                sql = sql & " and tbltripsum.platenum='" & Trim(cmbplate.Text) & "'"
            End If

            If Trim(cmbtype.Text) <> "" And Trim(cmbtype.Text) <> "All" Then
                sql = sql & " and tblgeneral.vtype='" & Trim(cmbtype.Text) & "'"
            End If

            If Trim(cmbdriver.Text) <> "" And Trim(cmbdriver.Text) <> "All" Then
                sql = sql & " and tbltripsum.driver='" & Trim(cmbdriver.Text) & "'"
            End If

            If Trim(cmbrec.Text) <> "" And Trim(cmbrec.Text) <> "All" Then
                sql = sql & " and tblortrans.customer='" & Trim(cmbrec.Text) & "'"
            End If

            If Trim(cmbtranstype.Text) <> "" Then
                If cmbtranstype.Text.Contains("PICKUP") Then
                    sql = sql & " and tblortrans.transtype='" & Trim(cmbtranstype.Text) & " FRM " & Trim(cmbpick.Text) & "'"
                Else
                    sql = sql & " and tblortrans.transtype='" & Trim(cmbtranstype.Text) & "'"
                End If
            End If

            sql = sql & " group by tbltripsum.datepick, tbltripsum.tripnum, tbltripsum.platenum, tbltripsum.driver, tbltripsum.helper, tblortrans.transnum, tblortrans.customer, tblortrans.transtype, tblortrans.refnum, tblortrans.arnum, tblortrans.rdrnum, tblortrans.drnum, tblortrans.dnnum, tblortrans.notes, tblortrans.itrnum, tblortrans.itnum, tblortrans.grponum, tblgeneral.vtype"

            sql = sql & " order by tripnum"

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                sonum = ""
                ponum = ""
                swsnum = ""

                If dr("refnum").ToString.Contains("/") Then

                    'MsgBox(dr("refnum").ToString)
                    inSql = dr("refnum").ToString

                    selectStart = inSql.IndexOf("SO")
                    fromStart = inSql.IndexOf("#") + 1
                    selectStart = selectStart + 2
                    firstPart = inSql.Substring(fromStart, inSql.Length - fromStart)
                    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

                    fields = firstPart.Split(" ")
                    firstPart = ""

                    sonum = fields(0).ToString

                    inSql = lastPart
                    selectStart = inSql.IndexOf("PO")
                    fromStart = inSql.IndexOf("#") + 1
                    selectStart = selectStart + 2
                    firstPart = inSql.Substring(fromStart, inSql.Length - fromStart)
                    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

                    fields = firstPart.Split("#")
                    firstPart = ""

                    ponum = lastPart

                ElseIf dr("refnum").ToString.Contains("SO#") And Not dr("refnum").ToString.Contains("/") Then

                    inSql = dr("refnum").ToString

                    selectStart = inSql.IndexOf("SO")
                    fromStart = inSql.IndexOf("#") + 1
                    selectStart = selectStart + 2
                    firstPart = inSql.Substring(selectStart, (fromStart - selectStart))
                    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

                    'fields = firstPart.Split("")
                    firstPart = ""

                    'MsgBox(lastPart)
                    sonum = lastPart

                ElseIf dr("refnum").ToString.Contains("PO#") And Not dr("refnum").ToString.Contains("/") Then

                    inSql = dr("refnum").ToString

                    selectStart = inSql.IndexOf("PO")
                    fromStart = inSql.IndexOf("#") + 1
                    selectStart = selectStart + 2
                    firstPart = inSql.Substring(selectStart, (fromStart - selectStart))
                    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

                    'fields = firstPart.Split("")
                    firstPart = ""

                    'MsgBox(lastPart)
                    ponum = lastPart

                ElseIf dr("refnum").ToString.Contains("SWS#") And Not dr("refnum").ToString.Contains("/") Then

                    inSql = dr("refnum").ToString

                    selectStart = inSql.IndexOf("SWS")
                    fromStart = inSql.IndexOf("#") + 1
                    selectStart = selectStart + 2
                    firstPart = inSql.Substring(selectStart, (fromStart - selectStart))
                    lastPart = inSql.Substring(fromStart, inSql.Length - fromStart)

                    'fields = firstPart.Split("")
                    firstPart = ""

                    'MsgBox(lastPart)
                    swsnum = lastPart

                End If

                grdrep.Rows.Add(Format(dr("datepick"), "yyyy/MM/dd"), dr("tripnum"), dr("platenum"), dr("vtype"), dr("driver"), dr("helper"), dr("transnum"), dr("customer"), dr("transtype"), dr("delqty"), sonum, ponum, swsnum, dr("arnum"), dr("rdrnum"), dr("drnum"), dr("dnnum"), dr("itrnum"), dr("itnum"), dr("grponum"), "")
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            Dim a As String = "", b As String = ""
            For Each row As DataGridViewRow In grdrep.Rows
                Dim stat As String = ""

                sql = "Select * from tbltripitems where tripnum='" & grdrep.Rows(row.Index).Cells(1).Value & "' and transnum='" & grdrep.Rows(row.Index).Cells(6).Value & "'"
                connect()
                Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
                Dim dr1 As SqlDataReader = cmd1.ExecuteReader
                If dr1.Read Then
                    If dr1("status") = 0 Then
                        stat = "Cancelled"
                    ElseIf dr1("status") = 2 Then
                        stat = "Completed"
                    ElseIf dr1("status") = 3 Then
                        stat = "Removed"
                    ElseIf dr1("status") = 4 Then
                        stat = "Rescheduled"
                    ElseIf dr1("status") = 5 Then
                        stat = "For AR Credit Memo"
                    ElseIf dr1("status") = 1 Then
                        stat = "In Process"
                    End If

                    grdrep.Rows(row.Index).Cells(20).Value = stat
                End If
                dr1.Dispose()
                cmd1.Dispose()
                conn.Close()

                'If row.Index = 0 Then
                '    grdrep.Rows(row.Index).DefaultCellStyle.BackColor = Color.Yellow
                'Else
                '    a = grdrep.Rows(row.Index - 1).Cells(1).Value
                '    b = grdrep.Rows(row.Index).Cells(1).Value
                '    If a = b Then
                '        grdrep.Rows(row.Index).DefaultCellStyle.BackColor = grdrep.Rows(row.Index - 1).DefaultCellStyle.BackColor
                '    Else
                '        grdrep.Rows(row.Index).DefaultCellStyle.BackColor = Color.LightGreen
                '        If grdrep.Rows(row.Index - 1).DefaultCellStyle.BackColor = Color.LightGreen Then
                '            grdrep.Rows(row.Index).DefaultCellStyle.BackColor = Color.Yellow
                '        End If
                '    End If
                'End If


                sql = "Select * from tbltripsum where tripnum='" & grdrep.Rows(row.Index).Cells(1).Value & "'"
                connect()
                cmd1 = New SqlCommand(sql, conn)
                dr1 = cmd1.ExecuteReader
                If dr1.Read Then
                    If dr1("status") = 0 Then
                        stat = "Cancelled"
                    ElseIf dr1("status") = 3 Then
                        stat = "Cancelled"
                    End If

                    grdrep.Rows(row.Index).Cells(20).Value = stat
                End If
                dr1.Dispose()
                cmd1.Dispose()
                conn.Close()
            Next

            If grdrep.Rows.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("No record found.", MsgBoxStyle.Critical, "")
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbplate_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbplate.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbplate_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbplate.Leave
        Try
            If Trim(cmbplate.Text) <> "" And Trim(cmbplate.Text) <> "All" And Trim(cmbplate.Text) <> "ALL" And Trim(cmbplate.Text) <> "all" Then
                sql = "Select * from tblgeneral where platenum='" & Trim(cmbplate.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbtype.Text = dr("vtype")
                Else
                    cmbplate.SelectedItem = "All"
                    cmbtype.SelectedItem = "All"
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Else
                cmbplate.SelectedItem = "All"
                cmbtype.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbtype_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbtype.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbtype_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbtype.Leave
        Try
            If Trim(cmbtype.Text) <> "" And Trim(cmbtype.Text) <> "All" And Trim(cmbtype.Text) <> "ALL" And Trim(cmbtype.Text) <> "all" Then
                sql = "Select * from tblvtype where vtype='" & Trim(cmbtype.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then

                Else
                    cmbtype.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbdriver_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbdriver.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbdriver_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbdriver.Leave
        Try
            If Trim(cmbdriver.Text) <> "" And Trim(cmbdriver.Text) <> "All" And Trim(cmbdriver.Text) <> "ALL" And Trim(cmbdriver.Text) <> "all" Then
                sql = "Select * from tbldriver where driver='" & Trim(cmbdriver.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then

                Else
                    cmbdriver.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbhelper_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbhelper.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbhelper_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbhelper.Leave
        Try
            If Trim(cmbhelper.Text) <> "" And Trim(cmbhelper.Text) <> "All" And Trim(cmbhelper.Text) <> "ALL" And Trim(cmbhelper.Text) <> "all" Then
                sql = "Select * from tblhelper where helper='" & Trim(cmbhelper.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then

                Else
                    cmbhelper.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmborigin_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmborigin.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmborigin_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmborigin.Leave
        Try
            If Trim(cmborigin.Text) <> "" And Trim(cmborigin.Text) <> "All" And Trim(cmborigin.Text) <> "ALL" And Trim(cmborigin.Text) <> "all" Then
                sql = "Select * from tblwhse where whsename='" & Trim(cmborigin.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then

                Else
                    cmborigin.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbtripstat_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbtripstat.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbrec_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbrec.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbrec_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbrec.Leave
        Try
            If Trim(cmbrec.Text) <> "" And Trim(cmbrec.Text) <> "All" And Trim(cmbrec.Text) <> "ALL" And Trim(cmbrec.Text) <> "all" Then
                sql = "Select * from tblcustomer where customer='" & Trim(cmbrec.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbrec.Text = dr("customer")
                Else
                    cmbrec.SelectedItem = "All"
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()
            Else
                cmbrec.SelectedItem = "All"
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbtranstype_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbtranstype.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbtranstype_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbtranstype.Leave
        If Trim(cmbtranstype.Text) <> "" Then
            If Trim(cmbtranstype.Text).ToUpper <> "JPSC STOCK TRANSFER PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "JPSC STOCK TRANSFER WHSE TO WHSE" And Trim(cmbtranstype.Text).ToUpper <> "JPSC SALES TRANSACTION" And Trim(cmbtranstype.Text).ToUpper <> "JPSC SALES TRANSACTION PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "CUSTOMER SALES TRANSACTION WHSE" And Trim(cmbtranstype.Text).ToUpper <> "CUSTOMER SALES TRANSACTION PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "TRUCKING STOCK TRANSFER PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "TRUCKING SALES TRANSACTION PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "TRUCKING SALES TRANSACTION WHSE" Then
                MsgBox("Invalid transaction type.", MsgBoxStyle.Exclamation, "")
                cmbtranstype.Text = ""
                cmbpick.Text = ""
                cmbpick.Enabled = False
                Exit Sub
            End If
        End If

        Try
            If cmbtranstype.SelectedIndex = 0 Then
                cmbpick.Enabled = False

            Else
                If cmbtranstype.Text.ToString.Contains("PICKUP") Then
                    If cmbpick.Text = "" Then
                        cmbpick.Enabled = True

                    Else
                        cmbpick.Enabled = True
                    End If

                Else
                    cmbpick.Text = ""
                    cmbpick.Enabled = False

                    If cmbtranstype.SelectedItem = "JPSC STOCK TRANSFER WHSE TO WHSE" Then

                    ElseIf cmbtranstype.SelectedItem = "JPSC SALES TRANSACTION" Then

                    ElseIf cmbtranstype.SelectedItem = "CUSTOMER SALES TRANSACTION WHSE" Then

                    ElseIf cmbtranstype.SelectedItem = "TRUCKING SALES TRANSACTION WHSE" Then

                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub cmbtranstype_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbtranstype.SelectedIndexChanged
        If Trim(cmbtranstype.Text) <> "" Then
            If Trim(cmbtranstype.Text).ToUpper <> "JPSC STOCK TRANSFER PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "JPSC STOCK TRANSFER WHSE TO WHSE" And Trim(cmbtranstype.Text).ToUpper <> "JPSC SALES TRANSACTION" And Trim(cmbtranstype.Text).ToUpper <> "JPSC SALES TRANSACTION PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "CUSTOMER SALES TRANSACTION WHSE" And Trim(cmbtranstype.Text).ToUpper <> "CUSTOMER SALES TRANSACTION PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "TRUCKING STOCK TRANSFER PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "TRUCKING SALES TRANSACTION PICKUP" And Trim(cmbtranstype.Text).ToUpper <> "TRUCKING SALES TRANSACTION WHSE" Then
                MsgBox("Invalid transaction type.", MsgBoxStyle.Exclamation, "")
                cmbtranstype.Text = ""
                cmbpick.Text = ""
                cmbpick.Enabled = False
                Exit Sub
            End If
        End If

        Try
            If cmbtranstype.SelectedIndex = 0 Then
                cmbpick.Enabled = False

            Else
                If cmbtranstype.SelectedItem.ToString.Contains("PICKUP") Then
                    If cmbpick.Text = "" Then
                        cmbpick.Enabled = True

                    Else
                        cmbpick.Enabled = True
                    End If

                Else
                    cmbpick.Text = ""
                    cmbpick.Enabled = False

                    If cmbtranstype.SelectedItem = "JPSC STOCK TRANSFER WHSE TO WHSE" Then

                    ElseIf cmbtranstype.SelectedItem = "JPSC SALES TRANSACTION" Then

                    ElseIf cmbtranstype.SelectedItem = "CUSTOMER SALES TRANSACTION WHSE" Then

                    ElseIf cmbtranstype.SelectedItem = "TRUCKING SALES TRANSACTION WHSE" Then

                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub txtrems_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrems.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtrems_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtrems.TextChanged
        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtrems.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtrems.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtrems.Text.Length - 1
            Letter = txtrems.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtrems.Text = theText
        txtrems.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub tripreport_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub grdrep_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdrep.CellContentClick

    End Sub

    Private Sub grdrep_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles grdrep.RowPrePaint
        'If e.RowIndex > -1 Then
        '    Dim dgvRow As DataGridViewRow = grddispatch.Rows(e.RowIndex)
        '    '<== But this is the name assigned to it in the properties of the control
        '    'If CDate(Format(dgvRow.Cells(1).Value, "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-1), "yyyy/MM/dd")) Then
        '    If dgvRow.Cells(0).Tag = 3 Then 'step1
        '        dgvRow.DefaultCellStyle.BackColor = Color.DeepSkyBlue
        '    End If
        'End If

        Dim dgvRow As DataGridViewRow = grdrep.Rows(e.RowIndex)
        If grdrep.Rows(e.RowIndex).Cells(20).Value = "Cancelled" Then
            grdrep.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.DeepSkyBlue
        Else
            If e.RowIndex = 0 Then
                grdrep.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Yellow
            Else
                Dim a As String = grdrep.Rows(e.RowIndex - 1).Cells(1).Value
                Dim b As String = grdrep.Rows(e.RowIndex).Cells(1).Value
                If a = b Then
                    grdrep.Rows(e.RowIndex).DefaultCellStyle.BackColor = grdrep.Rows(e.RowIndex - 1).DefaultCellStyle.BackColor
                Else
                    grdrep.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.LightGreen
                    If grdrep.Rows(e.RowIndex - 1).DefaultCellStyle.BackColor = Color.LightGreen Then
                        grdrep.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.Yellow
                    End If
                End If
            End If
        End If


    End Sub
End Class