﻿Imports System.IO
Imports System.Data.SqlClient
Public Class assessviewcat
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand
    Public frm As String

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Private Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub assessviewcat_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If frm = "assessadd" Then
            viewall(assessadd.txtstep.Tag)
        ElseIf frm = "assessedit" Then
            viewall(assessedit.txtstep.Tag)
        End If
    End Sub

    Private Sub viewall(ByVal stp As String)
        Try
            grd.Rows.Clear()

            sql = "Select acid,step,category,subject,remarks,status from tblassesscat where status='1'"
            sql = sql & " and (step='" & stp & "' or step='Create Order' or step='Trip Scheduling')"
            If Trim(txt.Text) <> "" Then
                sql = sql & " (category like '%" & Trim(txt.Text.Replace("'", "''")) & "%' or subject like '%" & Trim(txt.Text.Replace("'", "''")) & "%' or remarks like '%" & Trim(txt.Text.Replace("'", "''")) & "%')"
            End If
            sql = sql & " order by step,category,subject"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                Dim stat As String = "Active"
                If dr("status") = 0 Then
                    stat = "Deactivated"
                End If
                grd.Rows.Add(dr("acid"), dr("step"), dr("category"), dr("subject"), dr("remarks"), stat)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grd_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd.CellDoubleClick
        If frm = "assessadd" Then
            assessadd.txtstep.Text = grd.Rows(grd.CurrentRow.Index).Cells("stp").Value
            assessadd.txtsub.Text = grd.Rows(grd.CurrentRow.Index).Cells("subj").Value
            assessadd.txtsub.Tag = grd.Rows(grd.CurrentRow.Index).Cells("acid").Value
        ElseIf frm = "assessedit" Then
            assessedit.txtstep.Text = grd.Rows(grd.CurrentRow.Index).Cells("stp").Value
            assessedit.txtsub.Text = grd.Rows(grd.CurrentRow.Index).Cells("subj").Value
            assessedit.txtsub.Tag = grd.Rows(grd.CurrentRow.Index).Cells("acid").Value
        End If
        Me.Dispose()
    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        If Trim(txt.Text) <> "" Then
            viewall(assessadd.txtstep.Tag)
        Else
            MsgBox("Input text.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub txt_TextChanged(sender As Object, e As EventArgs) Handles txt.TextChanged
        If Trim(txt.Text) = "" Then
            viewall(assessadd.txtstep.Tag)
        End If
    End Sub

    Private Sub txt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt.KeyPress
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            btnsearch.PerformClick()
        End If
    End Sub
End Class