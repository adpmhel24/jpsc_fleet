﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class bodytyp
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim stat As String
    Public bodycnf As Boolean = False

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            If Trim(txtbody.Text) = "" Then
                grdbody.Rows.Clear()
                MsgBox("Input body type first.", MsgBoxStyle.Exclamation, "")
                txtbody.Focus()
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

            sql = "Select * from tblbody where bodytype like '" & Trim(txtbody.Text) & "%'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                grdbody.Rows.Clear()
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdbody.Rows.Add(dr("bodyid"), dr("bodytype"), stat)
                txtbody.Text = ""
            Else
                MsgBox("Cannot found " & Trim(txtbody.Text), MsgBoxStyle.Critical, "")
                txtbody.Text = ""
                txtbody.Focus()
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If Trim(txtbody.Text) <> "" Then
                sql = "Select * from tblbody where bodytype='" & Trim(txtbody.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    MsgBox(Trim(txtbody.Text) & " is already exist", MsgBoxStyle.Information, "")
                    btnupdate.Text = "&Update"
                    txtbody.Text = ""
                    txtbody.Focus()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                bodycnf = False
                confirm.ShowDialog()
                If bodycnf = True Then
                    sql = "Insert into tblbody (bodytype, datecreated, createdby, datemodified, modifiedby, status) values('" & Trim(txtbody.Text) & "',GetDate(),'" & login.cashier & "',GetDate(),'" & login.cashier & "','1')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                    btnview.PerformClick()
                End If

                txtbody.Text = ""
                txtbody.Focus()
                bodycnf = False
            Else
                MsgBox("Input body type first", MsgBoxStyle.Exclamation, "")
                txtbody.Focus()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        Try
            grdbody.Rows.Clear()
            Dim stat As String = ""

            sql = "Select * from tblbody"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdbody.Rows.Add(dr("bodyid"), dr("bodytype"), stat)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If grdbody.Rows.Count = 0 Then
                btnupdate.Enabled = False
                btndeactivate.Enabled = False
            Else
                btnupdate.Enabled = True
                btndeactivate.Enabled = True
            End If

            btncancel.PerformClick()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtbody_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtbody.Leave
        txtbody.Text = StrConv(txtbody.Text, VbStrConv.Uppercase)
    End Sub

    Private Sub txttype_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtbody.TextChanged
        If Trim(txtbody.Text) <> "" Then
            btncancel.Enabled = True
        ElseIf Trim(txtbody.Text) = "" And btnupdate.Text = "&Save" Then
            btncancel.Enabled = True
        Else
            btncancel.Enabled = False
        End If

        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtbody.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtbody.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtbody.Text.Length - 1
            Letter = txtbody.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtbody.Text = theText
        txtbody.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub body_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnview.PerformClick()
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        txtbody.Text = ""
        btnupdate.Text = "&Update"
        btnsearch.Enabled = True
        btnadd.Enabled = True
        btndeactivate.Enabled = True
        btncancel.Enabled = False
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdbody.SelectedRows.Count = 1 Or grdbody.SelectedCells.Count = 1 Then
                If btnupdate.Text = "&Update" Then
                    If grdbody.Rows(grdbody.CurrentRow.Index).Cells(2).Value = "Deactivated" Then
                        MsgBox("Cannot update deactivated body type.", MsgBoxStyle.Exclamation, "")
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    lblcat.Text = grdbody.Rows(grdbody.CurrentRow.Index).Cells(1).Value
                    txtbody.Text = grdbody.Rows(grdbody.CurrentRow.Index).Cells(1).Value
                    lblid.Text = grdbody.Rows(grdbody.CurrentRow.Index).Cells(0).Value
                    btnsearch.Enabled = False
                    btnadd.Enabled = False
                    btnupdate.Text = "&Save"
                    btncancel.Enabled = True
                    btndeactivate.Enabled = False
                Else
                    'update
                    If Trim(txtbody.Text) = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Body type should not be empty.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If

                    sql = "Select * from tblbody where bodytype='" & Trim(txtbody.Text) & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox(Trim(txtbody.Text) & " is already exist", MsgBoxStyle.Information, "")
                        btnupdate.Text = "&Update"
                        btnsearch.Enabled = True
                        btnadd.Enabled = True
                        btncancel.Enabled = False
                        btndeactivate.Enabled = True
                        txtbody.Text = ""
                        txtbody.Focus()
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    bodycnf = False
                    confirm.ShowDialog()
                    If bodycnf = True Then
                        If Trim(txtbody.Text) <> Trim(lblcat.Text) Then
                            sql = "Update tblbody set bodytype='" & Trim(txtbody.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where bodyid='" & lblid.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()
                            'If Trim(txtbody.Text) <> Trim(lblcat.Text) Then
                            'update other tbl in database
                            sql = "Update tblgeneral set bodytype='" & Trim(txtbody.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where bodytype='" & lblcat.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()
                        End If

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    btnupdate.Text = "&Update"
                    btnsearch.Enabled = True
                    btnadd.Enabled = True
                    btncancel.Enabled = False
                    btndeactivate.Enabled = True
                    txtbody.Text = ""
                    txtbody.Focus()
                    bodycnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
                btnview.PerformClick()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btndeactivate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndeactivate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdbody.SelectedRows.Count = 1 Or grdbody.SelectedCells.Count = 1 Then
                lblid.Text = grdbody.Rows(grdbody.CurrentRow.Index).Cells(0).Value
                If btndeactivate.Text = "&Deactivate" Then
                    'check if theres item available status
                    sql = "Select * from tblgeneral where bodytype='" & grdbody.Rows(grdbody.CurrentRow.Index).Cells(1).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox("Cannot deactivate. Body type is still in use.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    bodycnf = False
                    confirm.ShowDialog()
                    If bodycnf = True Then
                        sql = "Update tblbody set status='0', datemodified=GetDate(), modifiedby='" & login.cashier & "' where bodyid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    bodycnf = False
                Else
                    bodycnf = False
                    confirm.ShowDialog()
                    If bodycnf = True Then
                        sql = "Update tblbody set status='1', datemodified=GetDate(), modifiedby='" & login.cashier & "' where bodyid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    bodycnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdbody_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdbody.CellContentClick

    End Sub

    Private Sub grdbody_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdbody.SelectionChanged
        If grdbody.Rows(grdbody.CurrentRow.Index).Cells(2).Value = "Active" Then
            btndeactivate.Text = "&Deactivate"
        Else
            btndeactivate.Text = "A&ctivate"
        End If
    End Sub
End Class