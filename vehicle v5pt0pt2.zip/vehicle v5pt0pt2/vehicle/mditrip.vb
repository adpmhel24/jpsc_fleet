﻿Imports System.Data.OleDb
Imports System.IO
Imports System.Data.SqlClient
Imports System.Security
Imports System.Security.Cryptography
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Imports System.Text
Imports System.Linq

Public Class mditrip
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand
    Public steps As String, connectSAP As Boolean, connStrLC As String
    Dim hasrows7 As Boolean = False
    Dim hasrows8 As Boolean = False

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub mdiform_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub MenuStrip2_ItemAdded(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemEventArgs) Handles MenuStrip2.ItemAdded
        Dim s As String = e.Item.GetType().ToString()
        If (s = "System.Windows.Forms.MdiControlStrip+SystemMenuItem") Then
            e.Item.Visible = False
        End If
    End Sub

    Private Sub mdiform_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim a As String = MsgBox("Are you sure you want to logout?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            Timer1.Stop()
            savelogout()
            login.connectline = ""
            login.Show()

            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub logouttool_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Public Sub savelogout()
        Try
            Dim logid As Integer = 0

            sql = "Select TOP 1 systemid from tbllogin where cast(datelogin as date)='" & Format(Date.Now, "yyyy/MM/dd") & "' and username='" & login.cashier & "' and logout='' order by systemid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                logid = dr("systemid")
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()


            sql = "Update tbllogin set datelogout=GetDate(), logout='" & Format(Date.Now, "HH:mm") & "' where systemid='" & logid & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            conn.Close()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub TripDispatchingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TripDispatchingToolStripMenuItem.Click
        Dim myForm As New tripdispatch
        tripdispatch.Text = tripdispatch.Text
        tripdispatch.MdiParent = Me
        tripdispatch.WindowState = FormWindowState.Maximized
        tripdispatch.selectstep = 0
        tripdispatch.Show()
    End Sub

    Private Sub CreateOrderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateOrderToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Me.Cursor = Cursors.WaitCursor
            'check muna kung may connection sa sAP
            'If Application.OpenForms().OfType(Of mainmenucreate).Any Then
            '    'MessageBox.Show("Opened") 'need iclose ang create order form para macheck kung connected na sa LC
            'Else
            '    Dim linesdsh = System.IO.File.ReadAllLines("cnstringdashboard.txt")
            '    connStrLC = linesdsh(2)

            '    connectSAP = checkconnection(connStrLC, "LC")
            '    If connectSAP = False Then
            '        Me.Cursor = Cursors.Default
            '        MsgBox("Can't connect to LC server.", MsgBoxStyle.Exclamation, "")
            '    Else
            '        Me.Cursor = Cursors.Default
            '        MsgBox("Connected to LC server.", MsgBoxStyle.Information, "")
            '    End If
            'End If


            Me.Cursor = Cursors.Default
            Dim myForm As New mainmenucreate
            '/mainmenucreate.Text = mainmenucreate.Text 
            If login.svrlc = False Then
                mainmenucreate.lblstat.Visible = True
                mainmenucreate.chklc.Checked = False
            Else
                mainmenucreate.lblstat.Visible = False
            End If
            mainmenucreate.edittrans = False
            mainmenucreate.MdiParent = Me
            mainmenucreate.WindowState = FormWindowState.Maximized
            mainmenucreate.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Function checkconnection(ByVal str As String, ByVal whse As String) As Boolean
        Dim chkstr As Boolean = False
        Try
            Static conn As SqlConnection
            conn = New SqlConnection(str)
            conn.Open()
            If conn.State = ConnectionState.Open Then
                chkstr = True
            End If
            conn.Close()
        Catch ex As Exception
            Return chkstr
        End Try
        Return chkstr
    End Function

    Private Sub CategoryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CategoryToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New category
            '/category.Text = category.Text 
            category.MdiParent = Me
            category.WindowState = FormWindowState.Maximized
            category.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub ItemsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ItemsToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New newitems
            '/newitems.Text = newitems.Text 
            newitems.MdiParent = Me
            newitems.WindowState = FormWindowState.Maximized
            newitems.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub CustomerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomerToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New customer
            '/customer.Text = customer.Text 
            customer.MdiParent = Me
            customer.WindowState = FormWindowState.Maximized
            customer.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub DriverToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DriverToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New newdriver
            '/newdriver.Text = newdriver.Text 
            newdriver.MdiParent = Me
            newdriver.WindowState = FormWindowState.Maximized
            newdriver.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub HelperToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelperToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New newhelper
            '/newhelper.Text = newhelper.Text 
            newhelper.MdiParent = Me
            newhelper.WindowState = FormWindowState.Maximized
            newhelper.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub CompanyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CompanyToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New comps
            '/comps.Text = comps.Text 
            comps.MdiParent = Me
            comps.WindowState = FormWindowState.Maximized
            comps.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub WarehouseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WarehouseToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New whse
            '/whse.Text = whse.Text 
            whse.MdiParent = Me
            whse.WindowState = FormWindowState.Maximized
            whse.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub DocumentsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DocumentsToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New doc
            '/doc.Text = doc.Text 
            doc.MdiParent = Me
            doc.WindowState = FormWindowState.Maximized
            doc.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub TripDispatchSummaryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TripDispatchSummaryToolStripMenuItem.Click
        Dim myForm As New tripdispatchsum
        '/tripdispatchsum.Text = tripdispatchsum.Text 
        tripdispatchsum.MdiParent = Me
        tripdispatchsum.WindowState = FormWindowState.Maximized
        tripdispatchsum.Show()
    End Sub

    Private Sub TripSchedulingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TripSchedulingToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New tripadd
            '/tripadd.Text = tripadd.Text 
            tripadd.MdiParent = Me
            tripadd.WindowState = FormWindowState.Maximized
            tripadd.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub TripSummaryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TripSummaryToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New tripsum
            '/tripsum.Text = tripsum.Text 
            tripsum.MdiParent = Me
            tripsum.WindowState = FormWindowState.Maximized
            tripsum.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub OrderTransactionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrderTransactionsToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New trans
            '/trans.Text = trans.Text 
            trans.MdiParent = Me
            trans.WindowState = FormWindowState.Maximized
            trans.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub LoginLogsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginLogsToolStripMenuItem.Click
        Dim myForm As New loginlogs
        '/loginlogs.Text = loginlogs.Text 
        loginlogs.MdiParent = Me
        loginlogs.WindowState = FormWindowState.Maximized
        loginlogs.Show()
    End Sub

    Private Sub UsersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UsersToolStripMenuItem.Click
        Dim myForm As New users
        '/users.Text = users.Text 
        users.MdiParent = Me
        users.WindowState = FormWindowState.Maximized
        users.Show()
    End Sub

    Private Sub VersionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VersionToolStripMenuItem.Click
        Dim myForm As New version
        '/version.Text = version.Text 
        version.MdiParent = Me
        version.WindowState = FormWindowState.Maximized
        version.Show()
    End Sub

    Private Sub TripScheduleReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TripScheduleReportToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New tripreport
            '/tripreport.Text = tripreport.Text 
            tripreport.MdiParent = Me
            tripreport.WindowState = FormWindowState.Maximized
            tripreport.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub ForChangeOilToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ForChangeOilToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New forchangeoil
            '/forchangeoil.Text = forchangeoil.Text 
            forchangeoil.MdiParent = Me
            forchangeoil.WindowState = FormWindowState.Maximized
            forchangeoil.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub AdjustQtyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AdjustQtyToolStripMenuItem.Click
        Dim myForm As New transqty
        '/transqty.Text = transqty.Text 
        transqty.MdiParent = Me
        transqty.WindowState = FormWindowState.Maximized
        transqty.Show()
    End Sub

    Private Sub InsertIntoDashboardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InsertIntoDashboardToolStripMenuItem.Click
        Dim myForm As New dashboard
        '/dashboard.Text = dashboard.Text 
        dashboard.MdiParent = Me
        dashboard.WindowState = FormWindowState.Maximized
        dashboard.Show()
    End Sub

    Private Sub RestoreCommentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RestoreCommentToolStripMenuItem.Click
        Dim myForm As New rptcomment
        '/rptcomment.Text = rptcomment.Text 
        rptcomment.MdiParent = Me
        rptcomment.WindowState = FormWindowState.Maximized
        rptcomment.Show()
    End Sub

    Private Sub DeletePreviousAttachmentsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeletePreviousAttachmentsToolStripMenuItem.Click
        Dim myForm As New sqlqueries
        '/sqlqueries.Text = sqlqueries.Text 
        sqlqueries.MdiParent = Me
        sqlqueries.WindowState = FormWindowState.Maximized
        sqlqueries.Show()
    End Sub

    Private Sub VehicleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New vmain
            '/vmain.Text = vmain.Text 
            vmain.MdiParent = Me
            vmain.WindowState = FormWindowState.Maximized
            vmain.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub mditrip_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        If login.neym <> "Guard" And login.neym <> "Motorpool Inspector" And login.neym <> "LC Accounting Staff" And login.neym <> "AGI Accounting Staff" Then
            'checkhasrows7()
            'If hasrows7 = True Then
            '    pendingstep7.ShowDialog()
            'End If

            'checkhasrows8()
            'If hasrows8 = True Then
            '    pendingstep8.ShowDialog()
            'End If

            'pendings.ShowDialog()

            Counter_notif(strconn)

            If login.whse <> "JP-Store" Then
                ForChangeOilToolStripMenuItem.PerformClick()
            End If
        ElseIf login.neym = "Motorpool Inspector" Then
            MPInspectionToolStripMenuItem.PerformClick()
        End If
    End Sub

    Public Sub checkhasrows7()
        Try
            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step7<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) Then
                        hasrows7 = True
                        Exit While
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Public Sub checkhasrows8()
        Try
            sql = "Select tbltripsum.tripsumid, tbltripsum.tripnum, tbltripsum.platenum, tbldispatchsum.datestp6 from tbltripsum right outer join tbldispatchsum on tbltripsum.tripnum=tbldispatchsum.tripnum where tbldispatchsum.step6='1' and tbldispatchsum.step8<>'1' and tbltripsum.status='1' and tbltripsum.whsename='" & login.whse & "' order by datepick"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If IsDBNull(dr("datestp6")) = False Then
                    If CDate(Format(dr("datestp6"), "yyyy/MM/dd")) <= CDate(Format(Date.Now.AddDays(-2), "yyyy/MM/dd")) Then
                        hasrows8 = True
                        Exit While
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub PendingStatusToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PendingStatusToolStripMenuItem.Click
        Dim myForm As New trippending
        '/users.Text = users.Text 
        trippending.MdiParent = Me
        trippending.WindowState = FormWindowState.Maximized
        trippending.Show()
    End Sub

    Private Sub TripTodayToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles TripTodayToolStripMenuItem1.Click
        If login.neym <> "Guard" Then
            Dim myForm As New tripchecktruck
            '/users.Text = users.Text 
            tripchecktruck.MdiParent = Me
            tripchecktruck.WindowState = FormWindowState.Normal
            tripchecktruck.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub TruckEndingOdometerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TruckEndingOdometerToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New vodometer
            '/vmain.Text = vmain.Text 
            vodometer.MdiParent = Me
            vodometer.WindowState = FormWindowState.Maximized
            vodometer.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub TripViaShippingLinesPendingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TripViaShippingLinesPendingToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New tripship
            '/vmain.Text = vmain.Text 
            tripship.MdiParent = Me
            tripship.WindowState = FormWindowState.Maximized
            tripship.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub ServiceVehicleOdometerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ServiceVehicleOdometerToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New tripship
            '/vmain.Text = vmain.Text 
            vservice.MdiParent = Me
            vservice.WindowState = FormWindowState.Maximized
            vservice.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub GPSAccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GPSAccountToolStripMenuItem.Click
        vgps.MdiParent = Me
        vgps.WindowState = FormWindowState.Normal
        vgps.Show()
    End Sub

    Private Sub POIToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles POIToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New tripship
            '/vmain.Text = vmain.Text 
            poi.MdiParent = Me
            poi.WindowState = FormWindowState.Maximized
            poi.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        Dim a As String = MsgBox("Are you sure you want to logout?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            savelogout()
            login.connectline = ""
            login.Show()
            Me.Dispose()
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Counter_notif(strconn)
    End Sub

    Private Sub TrafficViolationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TrafficViolationToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New tviolation
            '/vmain.Text = vmain.Text 
            tviolation.MdiParent = Me
            tviolation.WindowState = FormWindowState.Maximized
            tviolation.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub VehicularAccidentLTOApprehensionToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VehicularAccidentLTOApprehensionToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New tviolationtrip
            '/vmain.Text = vmain.Text 
            tviolationtripsum.MdiParent = Me
            tviolationtripsum.WindowState = FormWindowState.Maximized
            tviolationtripsum.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub TruckStatusToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TruckStatusToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New truckstat
            '/vmain.Text = vmain.Text 
            truckstat.MdiParent = Me
            truckstat.WindowState = FormWindowState.Maximized
            truckstat.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub ForContainerStuffingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ForContainerStuffingToolStripMenuItem.Click
        If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        Else
            Dim myForm As New tripshiplist
            '/vmain.Text = vmain.Text 
            tripshiplist.MdiParent = Me
            tripshiplist.WindowState = FormWindowState.Normal
            tripshiplist.Show()
        End If
    End Sub

    Private Sub NotificationsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NotificationsToolStripMenuItem.Click
        Counter_notif(strconn)
    End Sub

    Private Sub TransactionTypeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TransactionTypeToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New transactype
            '/whse.Text = whse.Text 
            transactype.MdiParent = Me
            transactype.WindowState = FormWindowState.Maximized
            transactype.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub MotorpoolInspectionStatusToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MotorpoolInspectionStatusToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New trcondition
            '/whse.Text = whse.Text 
            trcondition.MdiParent = Me
            trcondition.WindowState = FormWindowState.Maximized
            trcondition.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub PendingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PendingToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New pendingpoi
            '/vmain.Text = vmain.Text 
            pendingpoi.MdiParent = Me
            pendingpoi.WindowState = FormWindowState.Maximized
            pendingpoi.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub MPInspectionToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MPInspectionToolStripMenuItem.Click
        If login.neym = "Motorpool Inspector" Or login.neym = "Administrator" Or login.neym = "Supervisor" Or login.neym = "Logistics Staff" Then
            Dim myForm As New motorpool
            '/vmain.Text = vmain.Text 
            motorpool.MdiParent = Me
            motorpool.WindowState = FormWindowState.Maximized
            motorpool.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub Step9PendingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Step9PendingToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New pendingstep8
            '/vmain.Text = vmain.Text 
            pendingstep9.MdiParent = Me
            pendingstep9.WindowState = FormWindowState.Maximized
            pendingstep9.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub CategoryToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles CategoryToolStripMenuItem1.Click
        assesscat.MdiParent = Me
        assesscat.WindowState = FormWindowState.Maximized
        assesscat.Show()
    End Sub

    Private Sub MotorpoolToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles MotorpoolToolStripMenuItem1.Click

    End Sub

    Private Sub EnableToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EnableToolStripMenuItem.Click
        sql = "Update tblactivate set status=1 where id=1"
        connect()
        cmd = New SqlCommand(sql, conn)
        cmd.ExecuteNonQuery()
        cmd.Dispose()
        MsgBox("Enabled.", MsgBoxStyle.Information, "")
    End Sub

    Private Sub DisableToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DisableToolStripMenuItem.Click
        sql = "Update tblactivate set status=0 where id=1"
        connect()
        cmd = New SqlCommand(sql, conn)
        cmd.ExecuteNonQuery()
        cmd.Dispose()
        MsgBox("Disabled.", MsgBoxStyle.Information, "")
    End Sub

    Private Sub SampleSAPAPIToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SampleSAPAPIToolStripMenuItem.Click
        Dim myForm As New Form3
        Form3.MdiParent = Me
        'Form3.WindowState = FormWindowState.Maximized
        Form3.Show()
    End Sub

    Private Sub UploadOfflineDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UploadOfflineDataToolStripMenuItem.Click

    End Sub

    Private Sub PerYearToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles PerYearToolStripMenuItem.Click
        Dim myForm As New tripreport_year
        tripreport_year.MdiParent = Me
        tripreport_year.WindowState = FormWindowState.Maximized
        tripreport_year.Show()
    End Sub

    Private Sub Step8OendingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Step8PendingToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New pendingstep8
            '/vmain.Text = vmain.Text 
            pendingstep8.MdiParent = Me
            pendingstep8.WindowState = FormWindowState.Maximized
            pendingstep8.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub Step7PendingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Step7PendingToolStripMenuItem.Click
        If login.neym <> "Guard" Then
            Dim myForm As New pendingstep7
            '/vmain.Text = vmain.Text 
            pendingstep7.MdiParent = Me
            pendingstep7.WindowState = FormWindowState.Maximized
            pendingstep7.Show()
        Else
            MsgBox("Access denied.", MsgBoxStyle.Critical, "")
        End If
    End Sub
End Class