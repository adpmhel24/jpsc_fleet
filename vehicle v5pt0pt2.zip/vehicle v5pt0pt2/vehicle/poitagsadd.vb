﻿Public Class poitagsadd
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For i = 0 To poi.list1.Items.Count - 1
            If Trim(txt.Text.ToLower) = poi.list1.Items(i).ToLower Then
                MsgBox(Trim(txt.Text) & " already added.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            End If
        Next

        poi.list1.Items.Add(Trim(txt.Text))
        Me.Dispose()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Dispose()
    End Sub
End Class