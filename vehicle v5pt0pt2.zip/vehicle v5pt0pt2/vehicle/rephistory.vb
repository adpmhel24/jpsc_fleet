﻿Imports System.IO
Imports System.Data.SqlClient

Public Class rephistory
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim norf As Boolean = False

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        viewall()
    End Sub

    Public Sub viewall()
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim s As Date = Date.Now
            Dim meron As Boolean = False
            grdrepair.Rows.Clear()

            sql = "Select * from tblrm where finish='1' and status='1' and genid='" & vmanage.lblid.Text & "'"
            If Trim(txtsearch.Text) <> "" Then
                sql = sql & " and description like '%" & Trim(txtsearch.Text) & "%'"
            End If
            sql = sql & " order by datestart"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If Format(s, "yyyy/MM/dd") > Format(dr("datestart"), "yyyy/MM/dd") Then
                    s = dr("datestart")
                End If

                Dim finish As Boolean = False
                If dr("finish") = 1 Then
                    finish = True
                Else
                    finish = False
                End If

                If IsDBNull(dr("datefinish")) = True Then
                    grdrepair.Rows.Add(dr("rmid"), dr("rmtype"), dr("description"), dr("reason"), Format(dr("datestart"), "yyyy/MM/dd"), finish, dr("datefinish").ToString, dr("mechanic").ToString)
                Else
                    grdrepair.Rows.Add(dr("rmid"), dr("rmtype"), dr("description"), dr("reason"), Format(dr("datestart"), "yyyy/MM/dd"), finish, Format(dr("datefinish"), "yyyy/MM/dd"), dr("mechanic").ToString)
                End If

                meron = True
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If meron = True Then
                datefrom.Value = s
            End If

            If grdrepair.Rows.Count = 0 Then
                Me.Cursor = Cursors.Default
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub rephistory_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Dispose()
    End Sub

    Private Sub rephistory_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        viewall()

        datefrom.MaxDate = Date.Now
        dateto.MinDate = datefrom.Value
        dateto.MaxDate = Date.Now
        datefrom.CustomFormat = "yyyy/MM/dd"
        dateto.CustomFormat = "yyyy/MM/dd"

        If grdrepair.Rows.Count = 0 Then
            Me.Close()
        End If
    End Sub

    Private Sub datefrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datefrom.ValueChanged
        dateto.MinDate = datefrom.Value
        viewindate()
    End Sub

    Private Sub dateto_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dateto.ValueChanged
        viewindate()
    End Sub

    Public Sub viewindate()
        Try
            grdrepair.Rows.Clear()

            sql = "Select * from tblrm where finish='1' and status='1' and genid='" & vmanage.lblid.Text & "'"
            If Trim(txtsearch.Text) <> "" Then
                sql = sql & " and description like '%" & Trim(txtsearch.Text) & "%'"
            End If
            sql = sql & " order by datestart"

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("datestart") >= Format(datefrom.Value, "yyyy/MM/dd") And dr("datestart") <= Format(dateto.Value, "yyyy/MM/dd") Then
                    Dim finish As Boolean = False
                    If dr("finish") = 1 Then
                        finish = True
                    Else
                        finish = False
                    End If

                    If IsDBNull(dr("datefinish")) = True Then
                        grdrepair.Rows.Add(dr("rmid"), dr("rmtype"), dr("description"), dr("reason"), Format(dr("datestart"), "yyyy/MM/dd"), finish, dr("datefinish").ToString, dr("mechanic").ToString)
                    Else
                        grdrepair.Rows.Add(dr("rmid"), dr("rmtype"), dr("description"), dr("reason"), Format(dr("datestart"), "yyyy/MM/dd"), finish, Format(dr("datefinish"), "yyyy/MM/dd"), dr("mechanic").ToString)
                    End If
                End If
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If grdrepair.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
                btnprint.Enabled = False
            Else
                btnprint.Enabled = True
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprint.Click
        rptrephistoryprev.Close()
        rptrephistoryprev.MdiParent = mdiform
        rptrephistoryprev.Show()
        rptrephistoryprev.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub txtsearch_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtsearch.KeyPress
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            viewindate()
        End If
    End Sub
End Class