﻿Public Class m_forupload
    Public Property tblCheckList As List(Of TblCheckListx)
    'End Class

    Public Class TblCheckListx
        Public Property whse_branch As String
        Public Property mid As String
        Public Property platenumber As String
        Public Property vehicle_type As String
        Public Property driver As String
        Public Property c_date As Date
        Public Property c_start As String
        Public Property c_finish As String
        Public Property tvirnum As String
        Public Property attachment As Byte()
        Public Property mechanic As String
        Public Property status As String
        Public Property second_Stat As String
        Public Property uploaddate As String
        Public Property remarks As String
        Public Property id As Integer
        Public Property additional As String
        Public Property check_item As String
        Public Property checklist_status As String
        Public Property jo_number As String
        Public Property pass_number As String
    End Class
End Class

Public Class TblCheckListz
    Public Property whse_branch As String
    Public Property mid As String
    Public Property platenumber As String
    Public Property vehicle_type As String
    Public Property driver As String
    Public Property c_date As Date
    Public Property c_start As String
    Public Property c_finish As String
    Public Property tvirnum As String
    Public Property attachment As Byte()
    Public Property mechanic As String
    Public Property status As String
    Public Property second_Stat As String
    Public Property uploaddate As String
    Public Property remarks As String
    Public Property id As Integer
    Public Property additional As String
    Public Property check_item As String
    Public Property checklist_status As String
    Public Property jo_number As String
    Public Property pass_number As String
End Class
