﻿Imports System.IO
Imports System.Data.SqlClient
Public Class customerpoi
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String, selectedrow As Integer

    Public cuscnf As Boolean, poiid As Integer
    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Close()
        End If
    End Sub
    Private Sub customerpoi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        viewpoi()
    End Sub

    Private Sub txtdis_TextChanged(sender As Object, e As EventArgs) Handles txtdis.TextChanged
        Dim charactersDisallowed As String = "0123456789."
        Dim theText As String = txtdis.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtdis.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtdis.Text.Length - 1
            Letter = txtdis.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtdis.Text = theText
        txtdis.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub viewpoi()
        Try
            sql = "Select d.value as distance, t.value as tym from tblpoi p"
            sql = sql & " inner join tblpoidistance d on d.poiid=p.poiid"
            sql = sql & " inner join tblpoitime t on t.poiid=p.poiid"
            sql = sql & " where p.poiid='" & poiid & "' and d.whsename='" & login.whse & "' and t.whsename='" & login.whse & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                txtdis.Text = dr("distance").ToString
                txttym.Text = dr("tym").ToString
            End If
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub customerpoi_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Me.Dispose()
    End Sub

    Private Sub txtdis_KeyDown(sender As Object, e As KeyEventArgs) Handles txtdis.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Your code here
            SendKeys.Send("{TAB}")
            e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txtdis.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txtdis.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txtdis.Paste()
        End If
    End Sub

    Private Sub txtdis_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtdis.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                'cmp()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txtdis.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            e.Handled = True
                        Else
                            txtdis.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txtdis.Text) <> "" And txtdis.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txtdis.Text) <> "" And txtdis.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'validate distance and time
        If Trim(txtdis.Text) <> "" Then
            If IsNumeric(Trim(txtdis.Text)) = False Then
                MsgBox("Invalid distance.", MsgBoxStyle.Exclamation, "")
                txtdis.Focus()
                Exit Sub
            End If
        Else
            'null
        End If

        If Trim(txttym.Text) <> "" Then
            If IsNumeric(Trim(txttym.Text)) = False Then
                MsgBox("Invalid travel time.", MsgBoxStyle.Exclamation, "")
                txttym.Focus()
                Exit Sub
            End If
        Else
            'null
        End If


        cuscnf = False
        confirmsave.GroupBox1.Text = login.neym
        confirmsave.ShowDialog()
        If cuscnf = True Then
            ExecuteSave(strconn)
        End If
    End Sub

    Private Sub ExecuteSave(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                If Trim(txtdis.Text) <> "" Then
                    sql = "Update tblpoidistance set value='" & Trim(txtdis.Text) & "', modifiedby='" & login.cashier & "', datemodified=GetDate() where poiid='" & poiid & "' and whsename='" & login.whse & "'"
                Else 'null
                    sql = "Update tblpoidistance set value=null, modifiedby='" & login.cashier & "', datemodified=GetDate() where poiid='" & poiid & "' and whsename='" & login.whse & "'"
                End If
                command.CommandText = sql
                Dim x1 As Integer = command.ExecuteNonQuery()
                If x1 = 0 Then
                    'insert
                    sql = "Insert into tblpoidistance (poiid, whsename, value, datecreated, createdby, datemodified, modifiedby, status)"
                    If Trim(txtdis.Text) <> "" Then
                        sql = sql & " values ('" & poiid & "', '" & login.whse & "', '" & Trim(txtdis.Text) & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                    Else 'null
                        sql = sql & " values ('" & poiid & "', '" & login.whse & "', null, GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                    End If
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                End If


                If Trim(txttym.Text) <> "" Then
                    sql = "Update tblpoitime set value='" & Trim(txttym.Text) & "', modifiedby='" & login.cashier & "', datemodified=GetDate() where poiid='" & poiid & "' and whsename='" & login.whse & "'"
                Else 'null
                    sql = "Update tblpoitime set value=null, modifiedby='" & login.cashier & "', datemodified=GetDate() where poiid='" & poiid & "' and whsename='" & login.whse & "'"
                End If
                command.CommandText = sql
                Dim x2 As Integer = command.ExecuteNonQuery()
                If x2 = 0 Then
                    'insert
                    sql = "Insert into tblpoitime (poiid, whsename, value, datecreated, createdby, datemodified, modifiedby, status)"
                    If Trim(txttym.Text) <> "" Then
                        sql = sql & " values ('" & poiid & "', '" & login.whse & "', '" & Trim(txttym.Text) & "', GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                    Else 'null
                        sql = sql & " values ('" & poiid & "', '" & login.whse & "', null, GetDate(), '" & login.cashier & "', GetDate(), '" & login.cashier & "', '1')"
                    End If
                    command.CommandText = sql
                    command.ExecuteNonQuery()
                End If


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully saved.", MsgBoxStyle.Information, "")
                customeraddress.load_customer2()
                Me.Dispose()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub txttym_TextChanged(sender As Object, e As EventArgs) Handles txttym.TextChanged
        Dim charactersDisallowed As String = "0123456789."
        Dim theText As String = txttym.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txttym.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txttym.Text.Length - 1
            Letter = txttym.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txttym.Text = theText
        txttym.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txttym_KeyDown(sender As Object, e As KeyEventArgs) Handles txttym.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Your code here
            SendKeys.Send("{TAB}")
            e.Handled = True

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.A Then
            txttym.SelectAll()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.C Then
            txttym.Copy()
        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then
            txttym.Paste()
        End If
    End Sub

    Private Sub txttym_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txttym.KeyPress
        Try
            Dim n As Integer = 0
            If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
                'cmp()
            End If

            If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 1 And Asc(e.KeyChar) <> 3 And Asc(e.KeyChar) <> 24 And Asc(e.KeyChar) <> 25 And Asc(e.KeyChar) <> 26 And Asc(e.KeyChar) <> 46 Then
                If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                    e.Handled = True
                Else
                    If Val(txttym.Text) = 0 Then
                        If Asc(e.KeyChar) = 48 Then
                            e.Handled = True
                        Else
                            txttym.Text = ""
                        End If
                    End If
                End If
            Else
                If Asc(e.KeyChar) = 46 And Trim(txttym.Text) <> "" And txttym.Text.Contains(".") = False Then

                ElseIf Asc(e.KeyChar) = 46 And Trim(txttym.Text) <> "" And txttym.Text.Contains(".") = True Then
                    e.Handled = True
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class