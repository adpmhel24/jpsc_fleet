﻿Imports System.Data.SqlClient

Module checkstep8
    Public Function PrevTrip(ByVal trip_platenum As String, ByVal trip_date As String) As Boolean
        Dim step8open As Boolean = False, logwh As String = "", sql As String = "", strconn As String = ""

        If login.whse = "Calamba" Then
            logwh = "Milaor"
            If login.svrmil = False Then
                Exit Function
            End If
            strconn = "Data Source=192.168.10.131,1433;Network Library=DBMSSOCN;Initial Catalog=vehicledb;User ID=admin;Password=serveradmin;"
        ElseIf login.whse = "Milaor" Then
            logwh = "Calamba"
            strconn = "Data Source=192.168.12.130,1433;Network Library=DBMSSOCN;Initial Catalog=vehicledb;User ID=admin;Password=serveradmin;"
        End If

        Using connection As New SqlConnection(strconn)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim drstep As SqlDataReader
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                '/command.CommandText =
                '/command.ExecuteNonQuery()
                command.CommandText = "Select tbldispatchsum.tripnum from tbldispatchsum"
                command.CommandText = command.CommandText & " inner join tbltripsum on tbldispatchsum.tripnum=tbltripsum.tripnum"
                command.CommandText = command.CommandText & " where platenum='" & trip_platenum & "' and step8=0 and complete=0"
                command.CommandText = command.CommandText & " and tbltripsum.whsename='" & logwh & "' and tbltripsum.status=1 and cast(tbltripsum.datepick as date) <= '" & trip_date & "'"

                '/command.CommandText = 
                drstep = command.ExecuteReader
                If drstep.Read Then
                    step8open = True
                End If
                drstep.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()

            Catch ex As Exception
                ' Attempt to roll back the transaction. 
                step8open = False
                Try
                    'transaction.Rollback()

                Catch ex2 As Exception
                    step8open = False
                End Try
            End Try
        End Using

        Return step8open
    End Function
End Module
