﻿Imports System.Data.SqlClient
Public Class assessall
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand
    Public cnf As Boolean

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Private Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub
    Private Sub assessall_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        view(lbltripnum1.Text)
    End Sub

    Public Sub view(ByVal tripnum As String)
        Try
            grd.Rows.Clear()

            sql = "Select Distinct aid, ctrnum, tripnum, step, category, subject, status, createdby, datecreated, modifiedby, datemodified from vAssess order by step,category,subject"
            connect()
            cmd = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd.ExecuteReader
            While dr1.Read
                Dim stat As String = "Active"
                If dr1("status") = 4 Then
                    stat = "Cancelled"
                ElseIf dr1("status") = 3 Then
                    stat = "For Penalty"
                ElseIf dr1("status") = 2 Then
                    stat = "Warning. Not for Penalty"
                ElseIf dr1("status") = 1 Then
                    stat = "Not for Penalty"
                ElseIf dr1("status") = 0 Then
                    stat = "Created"
                End If
                grd.Rows.Add(dr1("aid"), dr1("ctrnum"), dr1("tripnum"), dr1("step"), dr1("category"), dr1("subject"), dr1("createdby"), dr1("datecreated"), stat, dr1("modifiedby"), dr1("datemodified"))
            End While
            dr1.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grd_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd.CellContentClick
        If e.RowIndex > -1 Then
            'If e.ColumnIndex = 6 Then
            '    'view all comments
            '    viewcomms(grd.Rows(e.RowIndex).Cells("aid").Value)
            '    If assessemp.grd.Rows.Count > 1 Then
            '        assessemp.ShowDialog()
            '    End If

            'ElseIf e.ColumnIndex = 7 Then
            '    'view all comments
            '    viewcomms(grd.Rows(e.RowIndex).Cells("aid").Value)
            '    If assessviewcom.grd.Rows.Count > 1 Then
            '        assessviewcom.grd.Location = New Point(12, 12)
            '        assessviewcom.grd.Size = New Point(453, 314)
            '        assessviewcom.GroupBox1.Visible = False
            '        assessviewcom.ShowDialog()
            '    End If
            'End If
        End If
    End Sub
    Public Sub viewemp(ByVal aid As Integer)
        Try
            assessviewemp.grd.Rows.Clear()

            sql = "Select amid, comment, comby, datecom from tblassesscom where aid='" & aid & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                assessviewcom.grd.Rows.Add(dr("amid"), dr("comment"), dr("comby"), dr("datecom"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub viewcomms(ByVal aid As Integer)
        Try
            assessviewcom.grd.Rows.Clear()

            sql = "Select amid, comment, comby, datecom from tblassesscom where aid='" & aid & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                assessviewcom.grd.Rows.Add(dr("amid"), dr("comment"), dr("comby"), dr("datecom"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub EditDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditDetailsToolStripMenuItem.Click
        'check kung hindi pa nadisposition
        Try
            ExecuteEdit(strconn, grd.Rows(grd.CurrentRow.Index).Cells("aid").Value)

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteEdit(ByVal connectionString As String, ByVal aid As Integer)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Select status from tblassess where aid='" & aid & "' and status<>0"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    MsgBox("Cannot edit assess.", MsgBoxStyle.Critical, "")
                    Exit Sub
                End If
                dr.Dispose()

                Dim ctr As Integer = 0
                sql = "SELECT a.aid, a.ctrnum, a.tripnum, c.step, c.category, u.fullname, c.subject, m.comment, m.comby, m.datecom, a.status, a.createdby, a.datecreated, a.modifiedby, a.datemodified, a.whsename"
                sql = sql & " FROM dbo.tblassess AS a INNER JOIN"
                sql = sql & " dbo.tblassesscat AS c ON c.acid = a.acid INNER JOIN"
                sql = sql & " dbo.tblassesscom As m On m.aid = a.aid INNER JOIN"
                sql = sql & " dbo.tblassessemp AS e ON e.aid = a.aid INNER JOIN"
                sql = sql & " dbo.tblusers As u On u.systemid = e.userid where a.aid='" & aid & "'"
                command.CommandText = sql
                dr = command.ExecuteReader
                While dr.Read
                    If ctr = 0 Then
                        assessedit.GroupBox3.Text = dr("ctrnum")
                        assessedit.txttrip.Text = dr("tripnum")
                        assessedit.txtstep.Text = dr("step")
                        assessedit.txtstep.Tag = dr("step")
                        assessedit.txtsub.Text = dr("subject")
                        assessedit.txtcom.Text = dr("comment")
                        assessedit.list1.Items.Add(dr("fullname"))
                    Else
                        For i = 0 To assessedit.list1.Items.Count - 1
                            If assessedit.list1.Items(i) <> dr("fullname") Then
                                assessedit.list1.Items.Add(dr("fullname"))
                            End If
                        Next
                    End If
                    ctr += 1
                End While
                dr.Dispose()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                assessedit.ShowDialog()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub ReplyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReplyToolStripMenuItem.Click
        viewcomms(grd.Rows(grd.CurrentRow.Index).Cells("aid").Value)
        assessviewcom.grd.Location = New Point(12, 127)
        assessviewcom.grd.Size = New Point(453, 199)
        assessviewcom.GroupBox1.Visible = True
        assessviewcom.ShowDialog()
    End Sub

    Private Sub grd_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles grd.CellMouseClick
        If e.Button = Windows.Forms.MouseButtons.Right And e.RowIndex > -1 Then
            grd.ClearSelection()
            grd.Rows(e.RowIndex).Cells(e.ColumnIndex).Selected = True

            'selectedrow = e.RowIndex
            Me.ContextMenuStrip1.Show(Cursor.Position)
        End If
    End Sub

    Private Sub NotForPenaltyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NotForPenaltyToolStripMenuItem.Click
        cnf = False
        confirmsave.GroupBox1.Text = login.neym
        confirmsave.ShowDialog()
        If cnf = True Then
            ExecuteSave(strconn, 1)
        End If
    End Sub

    Private Sub ExecuteSave(ByVal connectionString As String, ByVal stat As Integer)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()

                sql = "Update tblassess set status='" & stat & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where aid='" & grd.Rows(grd.CurrentRow.Index).Cells("aid").Value & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully saved.", MsgBoxStyle.Information, "")

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
            End Try
        End Using
    End Sub

    Private Sub grd_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd.CellClick

    End Sub

    Private Sub grd_SelectionChanged(sender As Object, e As EventArgs) Handles grd.SelectionChanged
        Try
            GroupBox2.Text = "Control# " & grd.Rows(grd.CurrentRow.Index).Cells("ctrnum").Value
            txtstat.Text = grd.Rows(grd.CurrentRow.Index).Cells("dispo").Value
            txtby.Text = grd.Rows(grd.CurrentRow.Index).Cells("by").Value
            txtdate.Text = grd.Rows(grd.CurrentRow.Index).Cells("deyt").Value

            list1.Items.Clear()

            sql = "Select Distinct fullname from vAssess where aid='" & grd.Rows(grd.CurrentRow.Index).Cells("aid").Value & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                list1.Items.Add(dr("fullname"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            grd2.Rows.Clear()
            sql = "Select Distinct comment, comby, datecom from vAssess where aid='" & grd.Rows(grd.CurrentRow.Index).Cells("aid").Value & "' order by datecom"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                grd2.Rows.Add(dr("comment"), dr("comby"), dr("datecom"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
        End Try
    End Sub

    Private Sub addnewtool_Click(sender As Object, e As EventArgs) Handles addnewtool.Click
        If login.neym = "Administrator" Or login.neym = "Administrator" Or login.neym = "Administrator" Then
            assessadd.txttrip.Text = lbltripnum1.Text
            assessadd.txttrip.ReadOnly = True
            assessadd.txtstep.Text = "Step " & viewsteps.lblstep.Text
            assessadd.txtstep.Tag = "Step " & viewsteps.lblstep.Text
            assessadd.txtstep.ReadOnly = True
            assessadd.txtcom.Text = Trim(viewsteps.txtcomment.Text)
            assessadd.ShowDialog()
        Else
            MsgBox("Access denied!", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub assessall_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Me.Dispose()
    End Sub
End Class