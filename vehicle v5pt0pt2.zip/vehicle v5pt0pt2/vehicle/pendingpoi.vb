﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Windows.Forms
Imports CrystalDecisions.ReportSource
Imports System.Drawing.Printing
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.ComponentModel

Public Class pendingpoi
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand, logwhse As String

    Private backgroundWorkerdestin As BackgroundWorker, threadEnableddestin As Boolean
    Dim selectedrow As Integer = -1
    Public cnfpoi As Boolean

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub pendingpoi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        logwhse = login.whse
    End Sub

    Public Sub viewpendingpoi()
        Try
            Dim stuffing As Boolean
            grd.Rows.Clear()

            sql = "Select * from vTripTempPoi"
            sql = sql & " where whsename='" & login.whse & "' order by Arrival"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                stuffing = False
                If IsDBNull(dr("stuffing")) = False Then
                    If dr("stuffing") = 1 Then
                        stuffing = True
                    End If
                End If
                grd.Rows.Add(dr("tripsumid"), dr("tripnum"), dr("platenum"), dr("driver"), dr("transnum"), dr("cusid"), dr("customer"), dr("notes"), stuffing, dr("Arrival"), dr("DaysDue"))
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            grd.SuspendLayout()
            grd.ResumeLayout()
            grd.ClearSelection()

            If selectedrow > -1 And cnfpoi = True Then
                Dim MyDesiredIndex As Integer

                If selectedrow <= grd.RowCount - 1 Then
                    MyDesiredIndex = selectedrow
                    Dim eventArgs = New DataGridViewCellEventArgs(4, 0)
                    grd.Rows(MyDesiredIndex).Cells(4).Selected = True
                    grd_CellClick(grd, eventArgs)

                ElseIf selectedrow = grd.RowCount Then
                    MyDesiredIndex = selectedrow - 1

                    Dim eventArgs = New DataGridViewCellEventArgs(4, 0)
                    grd.Rows(MyDesiredIndex).Cells(4).Selected = True
                    grd_CellClick(grd, eventArgs)
                End If

                grd.FirstDisplayedScrollingRowIndex = MyDesiredIndex
            Else  'If selectedrow = -1 Then
                Dim eventArgs = New DataGridViewCellEventArgs(1, 0)
                grd.Rows(0).Cells(4).Selected = True
                grd_CellClick(grd, eventArgs)

                grd.FirstDisplayedScrollingRowIndex = 0
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub count()
        lblcount.Text = grd.Rows.Count.ToString("n2")
    End Sub

    Private Sub grd_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd.CellContentClick
        If e.RowIndex > -1 Then
            If e.ColumnIndex = 4 Then
                Dim cell As DataGridViewCell = grd.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grd.CurrentCell = cell
                If grd.Item(e.ColumnIndex, e.RowIndex).Value IsNot Nothing Then
                    viewtrans.Text = "View Transaction"
                    viewtrans.lbltripnum.Text = grd.Item("tripnum", e.RowIndex).Value.ToString
                    viewtrans.grouptrans.Visible = False
                    viewtrans.txttrans.Text = grd.Item(e.ColumnIndex, e.RowIndex).Value
                    viewtrans.sing = True
                    viewtrans.ShowDialog()
                End If
            End If
        End If
    End Sub

    Private Sub pendingpoi_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        'If backgroundWorkerdestin.IsBusy = True Then
        '    If backgroundWorkerdestin.WorkerSupportsCancellation = True Then
        '        backgroundWorkerdestin.CancelAsync()
        '    End If
        'End If

        Me.Dispose()
    End Sub

    Private Sub pendingpoi_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        If lblstep.Text = "poi" Then
            cnfpoi = False
            viewpendingpoi()
            count()
        End If
    End Sub

    Private Sub UpdateGPSPOIToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateGPSPOIToolStripMenuItem.Click
        If login.neym <> "Logistics Staff" And login.neym <> "Supervisor" And login.neym <> "Administrator" And login.neym <> "Manager" And login.neym <> "Encoder" Then
            MsgBox("Access denied!", MsgBoxStyle.Critical, "")
        Else
            poiselect.frm = "pendingpoi"
            poiselect.customer = grd.Rows(selectedrow).Cells("customer").Value
            poiselect.ShowDialog()
            If pendingpoiup.txtpoi.Text <> "" Then
                pendingpoiup.lbltrip.Text = grd.Rows(selectedrow).Cells("tripnum").Value
                pendingpoiup.lblplate.Text = grd.Rows(selectedrow).Cells("platenum").Value
                pendingpoiup.lbltrans.Text = grd.Rows(selectedrow).Cells("transnum").Value
                pendingpoiup.lblcus.Text = grd.Rows(selectedrow).Cells("customer").Value
                pendingpoiup.ShowDialog()
            End If
        End If
    End Sub

    Private Sub GPSPOIToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GPSPOIToolStripMenuItem.Click
        If grd.SelectedCells.Count = 1 Or grd.SelectedRows.Count = 1 Then
            customeraddress.lblcusid.Text = grd.Rows(selectedrow).Cells(5).Value
            customeraddress.lblcus.Text = grd.Rows(selectedrow).Cells(6).Value
            customeraddress.ShowDialog()
        Else
            MsgBox("Select one transaction.", MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    Private Sub grd_CellPainting(sender As Object, e As DataGridViewCellPaintingEventArgs) Handles grd.CellPainting
        Me.Cursor = Cursors.Default
        'Exit Sub

        'Paint everything except the ErrorIcon the standard way.
        e.Paint(e.ClipBounds, e.PaintParts And Not DataGridViewPaintParts.ErrorIcon)

        'Paint the ErrorIcon, if necessary, the custom way.
        If (e.PaintParts And DataGridViewPaintParts.ErrorIcon) = DataGridViewPaintParts.ErrorIcon Then
            If e.ErrorText <> "" And (e.ColumnIndex = 4) Then

                With e.Graphics
                    Dim gstate As Drawing2D.GraphicsState = .Save()
                    Dim iconRect As Rectangle = New Rectangle(e.CellBounds.Right - 20, e.CellBounds.Top + e.CellBounds.Height \ 2 - 8, 13, 13)
                    Dim backColor As Color
                    If (e.State And DataGridViewElementStates.Selected) = DataGridViewElementStates.Selected Then
                        backColor = e.CellStyle.SelectionBackColor
                    Else
                        backColor = e.CellStyle.BackColor
                    End If

                    'Restrict drawing within cell boundaries.
                    .SetClip(e.CellBounds)
                    'Clear background area behind the icon.
                    Using brush As New SolidBrush(backColor)
                        .FillRectangle(brush, iconRect)
                    End Using
                    'Draw the icon.

                    .DrawIcon(SystemIcons.Information, iconRect)

                    .Restore(gstate)
                End With
            End If
        End If

        e.Handled = True
    End Sub

    Private Sub grd_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles grd.CellMouseClick
        If e.Button = Windows.Forms.MouseButtons.Right And e.RowIndex > -1 Then
            If e.ColumnIndex = 4 Or e.ColumnIndex = 6 Then
                grd.ClearSelection()
                grd.Rows(e.RowIndex).Cells(e.ColumnIndex).Selected = True

                selectedrow = e.RowIndex
                Me.ContextMenuStrip1.Show(Cursor.Position)
            End If
        End If
    End Sub

    Private Sub ViewTripInformationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewTripInformationToolStripMenuItem.Click
        viewtripinfo.lblid.Text = grd.Rows(selectedrow).Cells(0).Value
        viewtripinfo.lbltripnum.Text = grd.Rows(selectedrow).Cells("tripnum").Value
        viewtripinfo.Text = "Trip Information (" & grd.Rows(selectedrow).Cells("tripnum").Value & ")"
        viewtripinfo.ShowDialog()
    End Sub

    Private Sub grd_RowPrePaint(sender As Object, e As DataGridViewRowPrePaintEventArgs) Handles grd.RowPrePaint
        If e.RowIndex > -1 Then
            Dim dgvRow As DataGridViewRow = grd.Rows(e.RowIndex)
            If dgvRow.Cells("pier").Value = True Then
                dgvRow.Cells("pier").Style.BackColor = Color.Yellow
            Else
                dgvRow.Cells("pier").Style.BackColor = dgvRow.Cells(1).Style.BackColor
            End If

            If IsDBNull(dgvRow.Cells("due").Value) = False Then
                If dgvRow.Cells("due").Value >= 4 Then
                    dgvRow.DefaultCellStyle.BackColor = Color.FromArgb(255, 192, 192)
                Else
                    dgvRow.Cells("due").Style.BackColor = dgvRow.Cells(1).Style.BackColor
                End If
            End If
        End If
    End Sub

    Private Sub grd_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd.CellClick

    End Sub
End Class