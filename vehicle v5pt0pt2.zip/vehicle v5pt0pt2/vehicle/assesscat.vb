﻿Imports System.IO
Imports System.Data.SqlClient

Public Class assesscat
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public cnf As Boolean

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Private Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub assesscat_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnview.PerformClick()
    End Sub

    Private Sub btnview_Click(sender As Object, e As EventArgs) Handles btnview.Click
        Try
            grd.Rows.Clear()

            sql = "Select acid,step,category,subject,remarks,status from tblassesscat order by step,category,subject"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                Dim stat As String = "Active"
                If dr("status") = 0 Then
                    stat = "Deactivated"
                End If
                grd.Rows.Add(dr("acid"), dr("step"), dr("category"), dr("subject"), dr("remarks"), stat)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If Trim(txtstep.Text) <> "" And Trim(txtcat.Text) <> "" And Trim(txtsub.Text) <> "" Then
                sql = "Select acid from tblassesscat where step='" & Trim(txtstep.Text.ToString.Replace("'", "''")) & "'"
                sql = sql & " and subject='" & Trim(txtsub.Text.ToString.Replace("'", "''")) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    Me.Cursor = Cursors.Default
                    MsgBox("Already exist", MsgBoxStyle.Information, "")
                    btnupdate.Text = "&Update"
                    txtstep.Focus()
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                cnf = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If cnf = True Then
                    sql = "Insert into tblassesscat (step, category, subject, remarks, datecreated, createdby, datemodified, modifiedby, status)"
                    sql = sql & " values('" & Trim(txtstep.Text.ToString.Replace("'", "''")) & "','" & Trim(txtcat.Text.ToString.Replace("'", "''")) & "',"
                    sql = sql & " '" & Trim(txtsub.Text.ToString.Replace("'", "''")) & "','" & Trim(txtrems.Text.ToString.Replace("'", "''")) & "', GetDate(),'" & login.cashier & "',GetDate(),'" & login.cashier & "','1')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully added", MsgBoxStyle.Information, "")
                    txtid.Text = ""
                    txtstep.Text = ""
                    txtcat.Text = ""
                    txtsub.Text = ""
                    txtrems.Text = ""
                    btnview.PerformClick()
                End If

            Else
                MsgBox("Complete required fields.", MsgBoxStyle.Exclamation, "")
                txtstep.Focus()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btncancel_Click(sender As Object, e As EventArgs) Handles btncancel.Click
        txtid.Text = ""
        txtstep.Text = ""
        txtcat.Text = ""
        txtsub.Text = ""
        txtrems.Text = ""
        btnupdate.Text = "&Update"
        btnadd.Enabled = True
        btndeactivate.Enabled = True
        btncancel.Enabled = False
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grd.SelectedRows.Count = 1 Or grd.SelectedCells.Count = 1 Then
                If btnupdate.Text = "&Update" Then
                    If grd.Rows(grd.CurrentRow.Index).Cells(2).Value = "Deactivated" Then
                        MsgBox("Cannot update deactivated body type.", MsgBoxStyle.Exclamation, "")
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    txtid.Text = grd.Rows(grd.CurrentRow.Index).Cells("acid").Value
                    txtstep.Text = grd.Rows(grd.CurrentRow.Index).Cells("stp").Value
                    txtcat.Text = grd.Rows(grd.CurrentRow.Index).Cells("cat").Value
                    txtsub.Text = grd.Rows(grd.CurrentRow.Index).Cells("subj").Value
                    txtrems.Text = grd.Rows(grd.CurrentRow.Index).Cells("rems").Value
                    btnadd.Enabled = False
                    btnupdate.Text = "&Save"
                    btncancel.Enabled = True
                    btndeactivate.Enabled = False
                Else
                    'update
                    If Trim(txtstep.Text) <> "" And Trim(txtcat.Text) <> "" And Trim(txtsub.Text) <> "" Then
                        sql = "Select acid from tblassesscat where step='" & Trim(txtstep.Text.ToString.Replace("'", "''")) & "'"
                        sql = sql & " and category='" & Trim(txtcat.Text.ToString.Replace("'", "''")) & "'"
                        sql = sql & " and subject='" & Trim(txtsub.Text.ToString.Replace("'", "''")) & "'"
                        sql = sql & " and remarks='" & Trim(txtrems.Text.ToString.Replace("'", "''")) & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        If dr.Read Then
                            Me.Cursor = Cursors.Default
                            MsgBox("Already exist", MsgBoxStyle.Information, "")
                            txtstep.Focus()
                            Exit Sub
                        End If
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        cnf = False
                        confirmsave.GroupBox1.Text = login.neym
                        confirmsave.ShowDialog()
                        If cnf = True Then
                            ExecuteUpdate(strconn)
                        End If
                    Else
                        MsgBox("Complete required fields.", MsgBoxStyle.Exclamation, "")
                        txtstep.Focus()
                    End If
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub


    Private Sub ExecuteUpdate(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Update tblassesscat set step='" & Trim(txtstep.Text.ToString.Replace("'", "''")) & "', category='" & Trim(txtcat.Text.ToString.Replace("'", "''")) & "',"
                sql = sql & " subject='" & Trim(txtsub.Text.ToString.Replace("'", "''")) & "', remarks='" & Trim(txtrems.Text.ToString.Replace("'", "''")) & "',"
                sql = sql & " datemodified=GetDate(), modifiedby='" & login.cashier & "' where acid='" & txtid.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully saved.", MsgBoxStyle.Information, "")
                btncancel.PerformClick()
                btnview.PerformClick()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
            End Try
        End Using
    End Sub

    Private Sub grd_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd.CellContentClick

    End Sub

    Private Sub grd_SelectionChanged(sender As Object, e As EventArgs) Handles grd.SelectionChanged
        If grd.Rows(grd.CurrentRow.Index).Cells("stat").Value = "Active" Then
            btndeactivate.Text = "&Deactivate"
        Else
            btndeactivate.Text = "A&ctivate"
        End If
    End Sub

    Private Sub btndeactivate_Click(sender As Object, e As EventArgs) Handles btndeactivate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grd.SelectedRows.Count = 1 Or grd.SelectedCells.Count = 1 Then
                If btndeactivate.Text = "&Deactivate" Then
                    'check if theres item available status
                    sql = "Select acid from tblassess where acid='" & grd.Rows(grd.CurrentRow.Index).Cells("acid").Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox("Cannot deactivate.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    cnf = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()
                    If cnf = True Then
                        sql = "Update tblassesscat set status='0', datemodified=GetDate(), modifiedby='" & login.cashier & "' where acid='" & grd.Rows(grd.CurrentRow.Index).Cells("acid").Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully deactivated", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                Else
                    cnf = False
                    confirmsave.GroupBox1.Text = login.neym
                    confirmsave.ShowDialog()
                    If cnf = True Then
                        sql = "Update tblassesscat status='1', datemodified=GetDate(), modifiedby='" & login.cashier & "' where acid='" & grd.Rows(grd.CurrentRow.Index).Cells("acid").Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully activated", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class