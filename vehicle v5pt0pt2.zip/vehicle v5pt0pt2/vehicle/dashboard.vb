﻿Imports System.IO
Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports Excel = Microsoft.Office.Interop.Excel

Public Class dashboard
    Dim SheetList As New ArrayList
    Dim MyConnection As OleDbConnection
    Dim DtSet As System.Data.DataSet
    Dim MyCommand As OleDbDataAdapter
    Dim ii As Integer
    Dim checkBoxColumn As New DataGridViewCheckBoxColumn()
    Dim ds As New DataSet
    Dim dv As DataView

    Dim lines = System.IO.File.ReadAllLines("cnstringdashboard.txt")
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim derrors As Boolean = False
    Public importcnf As Boolean = False

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub dashboard_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        '/moduless.Show()
    End Sub

    Private Sub importitems_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            DtSet.Clear()
            txtPath.Text = ""
            btnLoadData.Enabled = False
            btncheck.Enabled = False
            btnadd.Enabled = False
            dgvdata.Rows.Clear()
            dgvdata.Columns.Clear()
            Me.Dispose()
        Catch ex As Exception
            ' MsgBox(ex.message & vbcrlf & vbcrlf & ex.stacktrace)
        End Try
    End Sub

    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        With OpenFileDialog1
            .FileName = "Excel File"
            .Filter = "Excel Worksheets|*.xls;*.xlsx"
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                txtPath.Text = .FileName
                If txtPath.Text <> "" Then
                    btnLoadData.Enabled = True
                    btncheck.Enabled = False
                    btnadd.Enabled = False
                Else
                    btnLoadData.Enabled = False
                End If
            End If
        End With
    End Sub

    Private Sub btnLoadData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadData.Click
        Dim sheetName As String
        Try
            MyConnection = New OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0;Data Source='" & txtPath.Text & "';Extended Properties=""Excel 8.0;HDR={1}""")

            Dim objExcel As Excel.Application
            Dim objWorkBook As Excel.Workbook
            Dim objWorkSheets As Excel.Worksheet
            Dim ExcelSheetName As String = ""

            objExcel = CreateObject("Excel.Application")
            objWorkBook = objExcel.Workbooks.Open(txtPath.Text)

            For Each objWorkSheets In objWorkBook.Worksheets
                SheetList.Add(objWorkSheets.Name)
            Next

            MyCommand = New OleDbDataAdapter("select * from [" & SheetList(0) & "$]", MyConnection)
            MyCommand.TableMappings.Add("Table", "Net-informations.com")
            'MsgBox(SheetList(0).ToString)
            DtSet = New System.Data.DataSet
            MyCommand.Fill(DtSet)
            dgvdata.DataSource = DtSet.Tables(0)
            ' MyCommand.Dispose()
            MyConnection.Close()

            objWorkBook.Close()
            objExcel.Quit()

            releaseObject(objWorkBook)
            releaseObject(objExcel)

            Me.Cursor = Cursors.Default

            dgvdata.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True
            'dgvdata.ColumnHeadersHeight = 40
            dgvdata.Columns(0).Width = 150
            dgvdata.Columns(1).Width = 150

            If dgvdata.Rows.Count <> 0 Then
                btncheck.Enabled = True
            Else
                btncheck.Enabled = False
            End If

            derrors = False

            'remember: sa price kung nde sya numeric di sya iloload

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " + ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub btncheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncheck.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            'dito magaganap ung checking of errors
            '////check yung per column if wlng magkaparehas n item code and item name

            If Trim(txttripid.Text) = "" Or Val(txttripid.Text) = 0 Then
                MsgBox("Input tripid.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(txttripnum.Text) = "" Then
                MsgBox("Input trip#.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            If Trim(txttrans.Text) = "" Then
                MsgBox("Input trans#.", MsgBoxStyle.Information, "")
                Exit Sub
            End If

            checksonum()

            If derrors = False Then
                MsgBox("Click add button to continue.", MsgBoxStyle.Information, "")
                btnadd.Enabled = True
                btnupdate.Enabled = True
            Else
                MsgBox("Error occurred. Please correct the highlighted errors and try again.", MsgBoxStyle.Critical, "")
                btnadd.Enabled = False
                btnupdate.Enabled = False
            End If


        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checksonum()
        Try
            'check if category in the datagrid are in the tblorcat

            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                If dgvdata.Rows(row.Index).Cells(0).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(0).Value = dgvdata.Rows(row.Index).Cells(0).Value.ToString.Replace("'", "")
                    ' dgvdata.ClearSelection()
                    ' dgvdata.Rows(row.Index).Cells(0).ToolTipText = "Category " & dgvdata.Rows(row.Index).Cells(0).Value.ToString & " has an invalid character."
                    ' dgvdata.Rows(row.Index).Cells(0).Selected = True
                    ' dgvdata.Rows(row.Index).Cells(0).Style.BackColor = Color.Yellow
                    ' dgvdata.ClearSelection()
                    ' derrors = True
                End If

                'check if null
                If dgvdata.Rows(row.Index).Cells(0).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(0).ToolTipText = "SO# should not be null."
                    dgvdata.Rows(row.Index).Cells(0).Selected = True
                    dgvdata.Rows(row.Index).Cells(0).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(0).Value.ToString <> "" Then
                    'check if numeric
                    If IsNumeric(dgvdata.Rows(row.Index).Cells(0).Value.ToString) = False Then
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(0).ToolTipText = "SO# " & dgvdata.Rows(row.Index).Cells(0).Value.ToString & " should be a number."
                        dgvdata.Rows(row.Index).Cells(0).Selected = True
                        dgvdata.Rows(row.Index).Cells(0).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    End If
                End If

                '/////////////////////////
                'check if there's no apostrophe
                If dgvdata.Rows(row.Index).Cells(1).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(1).Value = dgvdata.Rows(row.Index).Cells(1).Value.ToString.Replace("'", "")
                    ' dgvdata.ClearSelection()
                    ' dgvdata.Rows(row.Index).Cells(1).ToolTipText = "Category " & dgvdata.Rows(row.Index).Cells(1).Value.ToString & " has an invalid character."
                    ' dgvdata.Rows(row.Index).Cells(1).Selected = True
                    ' dgvdata.Rows(row.Index).Cells(1).Style.BackColor = Color.Yellow
                    ' dgvdata.ClearSelection()
                    ' derrors = True
                End If

                'check if null
                If dgvdata.Rows(row.Index).Cells(1).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(1).ToolTipText = "Qty should not be null."
                    dgvdata.Rows(row.Index).Cells(1).Selected = True
                    dgvdata.Rows(row.Index).Cells(1).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If dgvdata.Rows(row.Index).Cells(1).Value.ToString <> "" Then
                    'check if numeric
                    If IsNumeric(dgvdata.Rows(row.Index).Cells(1).Value.ToString) = False Then
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(1).ToolTipText = "Qty " & dgvdata.Rows(row.Index).Cells(1).Value.ToString & " should be a number."
                        dgvdata.Rows(row.Index).Cells(1).Selected = True
                        dgvdata.Rows(row.Index).Cells(1).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    End If
                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            If derrors = False Then
                importcnf = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If importcnf = True Then

                    For Each row As DataGridViewRow In dgvdata.Rows
                        Dim iso As Integer = Val(dgvdata.Rows(row.Index).Cells(0).Value.ToString)
                        Dim iqty As Double = dgvdata.Rows(row.Index).Cells(1).Value
                        Dim itripid As Integer = Val(txttripid.Text)
                        Dim itripnum As String = Trim(txttripnum.Text)
                        Dim itrans As String = Trim(txttrans.Text)

                        sql = "Insert into tblsostatus (tripid, linktripstat, tripnum, status, transnum, sonum, soqty, cancel, step7, step9) values ('" & itripid & "', '2', '" & itripnum & "', '2', '" & itrans & "', '" & iso & "', '" & iqty & "', '0', '1', '1')"
                        connect()
                        cmd = New SqlCommand(sql, conn) 'New OleDbCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()
                    Next

                    MsgBox("Successfully Added.", MsgBoxStyle.Information, "")
                End If
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            If derrors = False Then
                importcnf = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If importcnf = True Then

                    For Each row As DataGridViewRow In dgvdata.Rows
                        Dim iso As Integer = Val(dgvdata.Rows(row.Index).Cells(0).Value.ToString)
                        Dim iqty As Double = dgvdata.Rows(row.Index).Cells(1).Value
                        Dim itripid As Integer = Val(txttripid.Text)
                        Dim itripnum As String = Trim(txttripnum.Text)
                        Dim itrans As String = Trim(txttrans.Text)

                        '/sql = "Insert into tblsostatus (tripid, linktripstat, tripnum, status, transnum, sonum, soqty, cancel, step7, step9) values ('" & itripid & "', '2', '" & itripnum & "', '2', '" & itrans & "', '" & iso & "', '" & iqty & "', '0', '1', '1')"
                        'sql = "Update tblsostatus set soqty='" & iqty & "' where sonum='" & iso & "' and tripid='" & itripid & "'"
                        sql = "Update tblsostatus set soqty='" & iqty & "' where sonum='" & iso & "' and tripid='" & itripid & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn) 'New OleDbCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()
                    Next

                    MsgBox("Successfully Updated.", MsgBoxStyle.Information, "")
                End If
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub dashboard_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If login.neym = "Administrator" Then
            btninsert.Visible = True
        Else
            btninsert.Visible = False
        End If
    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        Try
            '/If derrors = False Then
            importcnf = False
            confirmsave.GroupBox1.Text = login.neym
            confirmsave.ShowDialog()
            If importcnf = True Then

                For Each row As DataGridViewRow In dgvdata.Rows
                    Dim itripid As Integer = dgvdata.Rows(row.Index).Cells(0).Value
                    Dim ilink As Integer = dgvdata.Rows(row.Index).Cells(1).Value
                    Dim itripnum As String = dgvdata.Rows(row.Index).Cells(2).Value
                    Dim istatus As Integer = dgvdata.Rows(row.Index).Cells(3).Value
                    Dim itrans As String = dgvdata.Rows(row.Index).Cells(4).Value
                    Dim isonum As Integer = dgvdata.Rows(row.Index).Cells(5).Value
                    Dim isoqty As Double = dgvdata.Rows(row.Index).Cells(6).Value
                    Dim icancel As Integer = dgvdata.Rows(row.Index).Cells(7).Value
                    Dim istep7 As Integer = dgvdata.Rows(row.Index).Cells(8).Value
                    Dim istep9 As Integer = dgvdata.Rows(row.Index).Cells(9).Value

                    sql = "Select * from tblsostatus where sonum='" & isonum & "' and tripid='" & itripid & "' and tripnum like 'T.CAL%'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then

                    Else
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        sql = "Insert into tblsostatus (tripid, linktripstat, tripnum, status, transnum, sonum, soqty, cancel, step7, step9)"
                        sql = sql & " values ('" & itripid & "', '" & ilink & "', '" & itripnum & "', '" & istatus & "', '" & itrans & "', '" & isonum & "', '" & isoqty & "', '" & icancel & "', '" & istep7 & "', '" & istep9 & "')"
                        connect()
                        cmd = New SqlCommand(sql, conn) 'New OleDbCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                Next

                MsgBox("Successfully Added.", MsgBoxStyle.Information, "")
            End If
            '/End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub
End Class