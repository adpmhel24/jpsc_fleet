﻿Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Text
Imports System.Globalization
Imports System.ComponentModel

Public Class pendingpoiup
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Private backgroundWorkerdestin As BackgroundWorker, threadEnableddestin As Boolean, cancelpending As Boolean = False
    Dim gridsql As String = ""
    Public cnf As Boolean

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub pendingpoiup_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnok_Click(sender As Object, e As EventArgs) Handles btnok.Click
        cnf = False
        confirmsave.GroupBox1.Text = login.neym
        confirmsave.ShowDialog()
        If cnf = True Then
            ExecuteOk(strconn)
        End If
    End Sub

    Private Sub ExecuteOk(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                Dim poiid As Integer
                'check POIid
                sql = "Select poiid from tblpoi where poiname='" & Trim(txtpoi.Text.ToString.Replace("'", "''")) & "' and address='" & Trim(txtadd.Text.ToString.Replace("'", "''")) & "' and status='1'"
                command.CommandText = sql
                dr = command.ExecuteReader
                If dr.Read Then
                    poiid = dr("poiid")
                Else
                    Me.Cursor = Cursors.Default
                    MsgBox("Invalid poi.", MsgBoxStyle.Exclamation, "")
                    Exit Sub
                End If
                dr.Dispose()

                sql = "Update tblortrans set poiid='" & poiid & "' where transnum='" & lbltrans.Text & "'"
                command.CommandText = sql
                command.ExecuteNonQuery()

                sql = "Insert into tbltemppoilogs (tripnum,transnum,dateupdated,updatedby) values ('" & lbltrip.Text & "','" & lbltrans.Text & "',GetDate(),'" & login.cashier & "')"
                command.CommandText = sql
                command.ExecuteNonQuery()


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully saved.", MsgBoxStyle.Information, "")
                pendingpoi.cnfpoi = True
                pendingpoi.viewpendingpoi()
                Me.Dispose()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub pendingpoiup_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        ' ExecuteCheck(strconn)
    End Sub
    Private Sub ExecuteCheck(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                Dim poiid As Integer
                sql = "Select o.customer, p.poiname from tblortrans o"
                sql = sql & " Right outer join tblpoi p on p.poiid=o.poiid where o.transnum='" & lbltrans.Text & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    lblcus.Text = dr("customer")
                    If dr("poiname") <> "---TEMPORARY POI---" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Already updated. Refresh list.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                        Me.Dispose()
                    End If
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()


                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                'poi()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
                ' Attempt to roll back the transaction. 
                Try
                    Me.Cursor = Cursors.Default
                    transaction.Rollback()
                Catch ex2 As Exception
                    Me.Cursor = Cursors.Default
                    MsgBox("2: " & ex2.Message & vbCrLf & vbCrLf & "Please try again.", MsgBoxStyle.Information, "")
                End Try
            End Try
        End Using
    End Sub

    Private Sub pendingpoiup_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Me.Dispose()
    End Sub
End Class