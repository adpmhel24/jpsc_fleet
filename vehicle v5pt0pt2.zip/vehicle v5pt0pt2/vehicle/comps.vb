﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class comps
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim stat As String
    Public compscnf As Boolean = False

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            If Trim(txtcomp.Text) = "" Then
                grdcomps.Rows.Clear()
                MsgBox("Input company name first.", MsgBoxStyle.Exclamation, "")
                txtcomp.Focus()
                Me.Cursor = Cursors.Default
                Exit Sub
            End If

            grdcomps.Rows.Clear()
            sql = "Select * from tblcompany where company like '" & Trim(txtcomp.Text) & "%'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdcomps.Rows.Add(dr("compid"), dr("company"), dr("address"), stat)
                txtcomp.Text = ""
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If grdcomps.Rows.Count = 0 Then
                MsgBox("Cannot found " & Trim(txtcomp.Text), MsgBoxStyle.Critical, "")
                txtcomp.Text = ""
                txtcomp.Focus()
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If Trim(txtcomp.Text) <> "" Then
                sql = "Select * from tblcompany where company='" & Trim(txtcomp.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    MsgBox(Trim(txtcomp.Text) & " is already exist", MsgBoxStyle.Information, "")
                    btnupdate.Text = "&Update"
                    txtcomp.Text = ""
                    txtcomp.Focus()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

                compscnf = False
                confirm.ShowDialog()
                If compscnf = True Then
                    sql = "Insert into tblcompany (company, address, datecreated, createdby, datemodified, modifiedby, status) values('" & Trim(txtcomp.Text) & "','" & Trim(txtdes.Text) & "',GetDate(),'" & login.cashier & "',GetDate(),'" & login.cashier & "','1')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully Added", MsgBoxStyle.Information, "")
                    btnview.PerformClick()
                End If

                txtcomp.Text = ""
                txtcomp.Focus()
                compscnf = False
            Else
                MsgBox("Input company name first", MsgBoxStyle.Exclamation, "")
                txtcomp.Focus()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        Try
            grdcomps.Rows.Clear()
            Dim stat As String = ""


            sql = "Select * from tblcompany"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If
                grdcomps.Rows.Add(dr("compid"), dr("company"), dr("address"), stat)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

            If grdcomps.Rows.Count = 0 Then
                btnupdate.Enabled = False
            Else
                btnupdate.Enabled = True
            End If

            btncancel.PerformClick()

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txtcomp_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtcomp.Leave
        txtcomp.Text = StrConv(txtcomp.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txtcomp_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcomp.TextChanged
        If (Trim(txtcomp.Text) <> "" Or Trim(txtdes.Text) <> "") Then
            btncancel.Enabled = True
        ElseIf (Trim(txtcomp.Text) = "" And Trim(txtdes.Text) = "") And btnupdate.Text = "&Save" Then
            btncancel.Enabled = True
        Else
            btncancel.Enabled = False
        End If

        Dim charactersDisallowed As String = "'"
        Dim theText As String = txtcomp.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtcomp.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtcomp.Text.Length - 1
            Letter = txtcomp.Text.Substring(x, 1)
            If charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtcomp.Text = theText
        txtcomp.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub txtdes_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtdes.Leave
        txtdes.Text = StrConv(txtdes.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txtdes_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdes.TextChanged
        If (Trim(txtcomp.Text) <> "" Or Trim(txtdes.Text) <> "") Then
            btncancel.Enabled = True
        ElseIf (Trim(txtcomp.Text) = "" And Trim(txtdes.Text) = "") And btnupdate.Text = "&Save" Then
            btncancel.Enabled = True
        Else
            btncancel.Enabled = False
        End If

        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789.-/"
        Dim theText As String = txtdes.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txtdes.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txtdes.Text.Length - 1
            Letter = txtdes.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txtdes.Text = theText
        txtdes.Select(SelectionIndex - Change, 0)
    End Sub

    Private Sub comps_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        
    End Sub

    Private Sub comps_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnview.PerformClick()
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        txtcomp.Text = ""
        txtdes.Text = ""
        btnupdate.Text = "&Update"
        btnsearch.Enabled = True
        btndeactivate.Enabled = True
        btnadd.Enabled = True
        btncancel.Enabled = False
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdcomps.SelectedRows.Count = 1 Or grdcomps.SelectedCells.Count = 1 Then
                If btnupdate.Text = "&Update" Then
                    If grdcomps.Rows(grdcomps.CurrentRow.Index).Cells(3).Value = "Deactivated" Then
                        MsgBox("Cannot update deactivated company.", MsgBoxStyle.Exclamation, "")
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    lblcat.Text = grdcomps.Rows(grdcomps.CurrentRow.Index).Cells(1).Value
                    txtcomp.Text = grdcomps.Rows(grdcomps.CurrentRow.Index).Cells(1).Value
                    txtdes.Text = grdcomps.Rows(grdcomps.CurrentRow.Index).Cells(2).Value
                    lblid.Text = grdcomps.Rows(grdcomps.CurrentRow.Index).Cells(0).Value
                    btnsearch.Enabled = False
                    btnadd.Enabled = False
                    btnupdate.Text = "&Save"
                    btncancel.Enabled = True
                    btndeactivate.Enabled = False
                Else
                    'update
                    If Trim(txtcomp.Text) = "" Then
                        Me.Cursor = Cursors.Default
                        MsgBox("Company name should not be empty.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If

                    sql = "Select * from tblcompany where company='" & Trim(txtcomp.Text) & "' and address='" & Trim(txtdes.Text) & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox(Trim(txtcomp.Text) & " is already exist", MsgBoxStyle.Information, "")
                        btnupdate.Text = "&Update"
                        btnsearch.Enabled = True
                        btnadd.Enabled = True
                        btncancel.Enabled = False
                        btndeactivate.Enabled = False
                        txtcomp.Text = ""
                        txtdes.Text = ""
                        txtcomp.Focus()
                        Me.Cursor = Cursors.Default
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    compscnf = False
                    confirm.ShowDialog()
                    If compscnf = True Then
                        If Trim(txtcomp.Text) <> Trim(lblcat.Text) Then
                            sql = "Update tblcompany set company='" & Trim(txtcomp.Text) & "', address='" & Trim(txtdes.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where compid='" & lblid.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'update other tbl in database
                            sql = "Update tblgeneral set company='" & Trim(txtcomp.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where company='" & lblcat.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()

                            'update other tbl in database
                            sql = "Update tblwhse set company='" & Trim(txtcomp.Text) & "', datemodified=GetDate(), modifiedby='" & login.cashier & "' where company='" & lblcat.Text & "'"
                            connect()
                            cmd = New SqlCommand(sql, conn)
                            cmd.ExecuteNonQuery()
                            cmd.Dispose()
                            conn.Close()
                        End If

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    btnupdate.Text = "&Update"
                    btnsearch.Enabled = True
                    btnadd.Enabled = True
                    btndeactivate.Enabled = True
                    btncancel.Enabled = False
                    txtcomp.Text = ""
                    txtdes.Text = ""
                    txtcomp.Focus()
                    compscnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
                btnview.PerformClick()
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btndeactivate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndeactivate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If grdcomps.SelectedRows.Count = 1 Or grdcomps.SelectedCells.Count = 1 Then
                lblid.Text = grdcomps.Rows(grdcomps.CurrentRow.Index).Cells(0).Value
                If btndeactivate.Text = "&Deactivate" Then
                    'check if theres item available status
                    sql = "Select * from tblgeneral where company='" & grdcomps.Rows(grdcomps.CurrentRow.Index).Cells(1).Value & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        MsgBox("Cannot deactivate. Company is still in use.", MsgBoxStyle.Exclamation, "")
                        Exit Sub
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    compscnf = False
                    confirm.ShowDialog()
                    If compscnf = True Then
                        sql = "Update tblcompany set status='0', datemodified=GetDate(), modifiedby='" & login.cashier & "' where compid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    compscnf = False
                Else
                    compscnf = False
                    confirm.ShowDialog()
                    If compscnf = True Then
                        sql = "Update tblcompany set status='1', datemodified=GetDate(), modifiedby='" & login.cashier & "' where compid='" & lblid.Text & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully Saved", MsgBoxStyle.Information, "")
                        btnview.PerformClick()
                    End If

                    compscnf = False
                End If
            Else
                MsgBox("Select only one", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grdcomps_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdcomps.SelectionChanged
        If grdcomps.Rows(grdcomps.CurrentRow.Index).Cells(3).Value = "Active" Then
            btndeactivate.Text = "&Deactivate"
        Else
            btndeactivate.Text = "A&ctivate"
        End If
    End Sub
End Class