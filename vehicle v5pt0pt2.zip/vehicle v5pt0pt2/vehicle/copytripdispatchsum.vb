﻿Imports System.iio
Imports System.Data.SqlClient

Public Class copytripdispatchsum
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Public Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub tripdispatchsum_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub tripdispatchsum_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim a As String = MsgBox("Are you sure you want to close?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "")
        If a = vbYes Then
            moduless.Show()
            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub tripdispatchsum_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cmbplate.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbplate.DropDownStyle = ComboBoxStyle.DropDown
        cmbplate.AutoCompleteSource = AutoCompleteSource.ListItems

        cmbdriver.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cmbdriver.DropDownStyle = ComboBoxStyle.DropDown
        cmbdriver.AutoCompleteSource = AutoCompleteSource.ListItems

        datefrom.MaxDate = Date.Now
        dateto.MinDate = datefrom.Value

        grddispatch.Columns(7).Frozen = True

        If login.whse = "C3 Manila" Then
            lbltrip.Text = "T.MNL-"
        ElseIf login.whse = "Calamba" Then
            lbltrip.Text = "T.CAL-"
        ElseIf login.whse = "Pagbilao" Then
            lbltrip.Text = "T.PGB-"
        ElseIf login.whse = "Milaor" Then
            lbltrip.Text = "T.MIL-"
        ElseIf login.whse = "Cebu" Then
            lbltrip.Text = "T.CEB-"
        ElseIf login.whse = "Davao" Then
            lbltrip.Text = "T.DAV-"
        ElseIf login.whse = "Lc Office" Then
            lbltrip.Text = "T.LCO-"
        End If

        plate()
        driver()
        viewall()
    End Sub

    Public Sub plate()
        Try
            cmbplate.Items.Clear()
            cmbplate.Items.Add("")
            Dim plnum As String = ""

            sql = "Select * from tblgeneral"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                If dr1("platenum") = "" And dr1("vplate") <> "" Then
                    plnum = dr1("vplate")
                ElseIf dr1("platenum") = "" And dr1("vplate") = "" And dr1("csticker") <> "" Then
                    plnum = dr1("csticker")
                Else
                    plnum = dr1("platenum")
                End If

                cmbplate.Items.Add(plnum)
            End While
            dr1.Dispose()
            cmd1.Dispose()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub viewall()
        Try
            txttrip.Text = ""
            cmbdriver.Text = ""
            cmbplate.Text = ""

            grddispatch.Rows.Clear()

            'sql = "Select * from tbltripsum where tbltripsum.status='1'"
            sql = "Select * from tbltripsum where status<'2' and whsename='" & login.whse & "' order by datepick"
            connect()
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            While drx.Read
                grddispatch.Rows.Add(drx("tripsumid"), Format(drx("datepick"), "MM/dd/yyyy"), drx("tripnum"), drx("platenum"), "", drx("driver"), "", drx("etd"))
                If drx("status") = 3 Then
                    grddispatch.Rows(grddispatch.Rows.Count - 1).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                End If
            End While
            drx.Dispose()
            cmdx.Dispose()


            For Each row As DataGridViewRow In grddispatch.Rows
                sql = "Select * from tblgeneral where (platenum='" & grddispatch.Rows(row.Index).Cells(3).Value & "' or vplate='" & grddispatch.Rows(row.Index).Cells(3).Value & "' or csticker='" & grddispatch.Rows(row.Index).Cells(3).Value & "')"
                connect()
                Dim cmdx1 As SqlCommand = New SqlCommand(sql, conn)
                Dim drx1 As SqlDataReader = cmdx1.ExecuteReader
                If drx1.Read Then
                    grddispatch.Item(4, row.Index).Value = drx1("vtype")
                End If
                drx1.Dispose()
                cmdx1.Dispose()
                conn.Close()
            Next


            For Each row As DataGridViewRow In grddispatch.Rows
                sql = "Select * from tbldispatchsum where tripnum='" & grddispatch.Rows(row.Index).Cells(2).Value & "'"
                connect()
                Dim cmdx1 As SqlCommand = New SqlCommand(sql, conn)
                Dim drx1 As SqlDataReader = cmdx1.ExecuteReader
                If drx1.Read Then
                    Dim whatstep As String = "ON QUEUE"
                    Dim des As String = ""
                    If drx1("step1") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp1").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp1").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp1") & " ( " & drx1("datestp1").ToString & " )"
                            whatstep = "STEP 1"
                        End If

                        grddispatch.Item(8, row.Index).Value = des
                        grddispatch.Item(8, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step2") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp2").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp2").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp2") & " ( " & drx1("datestp2").ToString & " )"
                            whatstep = "STEP 2"
                        End If

                        grddispatch.Item(9, row.Index).Value = des
                        grddispatch.Item(9, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step3") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp3").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp3").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp3") & " ( " & drx1("datestp3").ToString & " )"
                            whatstep = "STEP 3"
                        End If

                        grddispatch.Item(10, row.Index).Value = des
                        grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step4") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp4").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp4").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp4") & " ( " & drx1("datestp4").ToString & " )"
                            whatstep = "STEP 4"
                        End If

                        grddispatch.Item(12, row.Index).Value = des
                        grddispatch.Item(12, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step5") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp5").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp5").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp5") & " ( " & drx1("datestp5").ToString & " )"
                            whatstep = "STEP 5"
                            If IsDBNull(drx1("timedep")) = False Then
                                whatstep = "DISPATCHED"
                                grddispatch.Item(14, row.Index).Value = "Time Departure: " & drx1("timedep")
                            End If
                        End If

                        grddispatch.Item(13, row.Index).Value = des
                        grddispatch.Item(13, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step6") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp6").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp6").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp6") & " ( " & drx1("datestp6").ToString & " )"
                            whatstep = "STEP 6"
                            grddispatch.Item(20, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                        End If

                        grddispatch.Item(14, row.Index).Value = des
                        grddispatch.Item(14, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step7") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp7").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp7").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp7") & " ( " & drx1("datestp7").ToString & " )"
                            whatstep = "STEP 7"
                        End If

                        grddispatch.Item(15, row.Index).Value = des
                        grddispatch.Item(15, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step8") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp8").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp8").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp8") & " ( " & drx1("datestp8").ToString & " )"
                            whatstep = "STEP 8"
                        End If

                        grddispatch.Item(16, row.Index).Value = des
                        grddispatch.Item(16, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step9") = 1 Then
                        If drx1("namestp9").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp9").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp9") & " ( " & drx1("datestp9").ToString & " )"
                        Else
                            des = ""
                        End If

                        grddispatch.Item(19, row.Index).Value = des
                        grddispatch.Item(19, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                        whatstep = "COMPLETED"
                        grddispatch.Item(20, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                    End If
                    grddispatch.Item(20, row.Index).Value = whatstep

                End If
                drx1.Dispose()
                cmdx1.Dispose()
                conn.Close()
            Next



            For Each row As DataGridViewRow In grddispatch.Rows
                If grddispatch.Rows(row.Index).Cells(0).Value.ToString <> "" Then

                    sql = "SELECT * FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum where tbltripsum.tripnum='" & grddispatch.Rows(row.Index).Cells(2).Value & "' and tbltripsum.datepick>='" & Format(datefrom.Value, "MM/dd/yyyy") & "' and tbltripsum.datepick<='" & Format(dateto.Value, "MM/dd/yyyy") & "' and tbltripsum.whsename='" & login.whse & "'"
                    connect()
                    Dim cmdx1 As SqlCommand = New SqlCommand(sql, conn)
                    Dim drx1 As SqlDataReader = cmdx1.ExecuteReader
                    If drx1.Read Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            grddispatch.Item(20, row.Index).Value = "RESCUED BY " & drx1("rescue").ToString
                        End If

                        Dim starttime As Date
                        Dim finishtime As Date
                        If IsDBNull(drx1("startload")) = False And IsDBNull(drx1("datestp3")) = False Then
                            Dim timeCheck As Boolean
                            timeCheck = IsDate(drx1("startload"))
                            If timeCheck = True Then
                                'MsgBox(Trim(txttime.Text) & timeCheck)
                                starttime = CDate(drx1("startload").ToString)
                                finishtime = CDate(drx1("datestp3").ToString)
                                grddispatch.Item(11, row.Index).Value = Format(starttime, "HH:mm") & Format(finishtime, "HH:mm")

                            End If
                        End If

                        If IsDBNull(drx1("etd")) = False And IsDBNull(drx1("datestp3")) = False Then
                            If drx1("datestp3") > drx1("etd") Then
                                'MsgBox("greater than the etd")
                                grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(255, 192, 128)
                                Exit Sub
                            End If
                        End If

                        Dim idlec As TimeSpan


                        'MsgBox(idlec.ToString)
                        If grddispatch.Rows(row.Index).Cells(14).Value IsNot Nothing And grddispatch.Rows(row.Index).Cells(15).Value IsNot Nothing Then
                            If Trim(finishtime.ToString) <> "" And Trim(starttime.ToString) <> "" Then
                                idlec = finishtime - starttime
                                'Dim ckac As Boolean = IsDate(grddispatch.Rows(row.Index).Cells(14).Value)
                                'Dim ckacd As Boolean = IsDate(grddispatch.Rows(row.Index).Cells(15).Value)

                                'If ckac = True And ckacd = True Then
                                If idlec.Hours < 0 Or idlec.Minutes < 0 Or idlec.Days < 0 Then
                                    grddispatch.Rows(row.Index).Cells(11).Value = "Invalid date/time"

                                ElseIf idlec.Hours >= 2 And idlec.Minutes > 0 Or idlec.Days < 0 Then
                                    'grddispatch.Rows(row.Index).Cells(11).Value = idlec.Hours & ":" & idlec.Minutes & " >2hrs"
                                    grddispatch.Rows(row.Index).Cells(11).Value = "2"
                                    grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(255, 192, 128)

                                ElseIf idlec.Hours = 1 And idlec.Minutes > 30 Or idlec.Days < 0 Then
                                    'grddispatch.Rows(row.Index).Cells(11).Value = idlec.Hours & ":" & idlec.Minutes & " >1:30 <=2:00"
                                    grddispatch.Rows(row.Index).Cells(11).Value = "1"
                                    grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(128, 255, 128)

                                ElseIf idlec.Days > 0 Then
                                    grddispatch.Rows(row.Index).Cells(11).Value = "3"
                                    grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(255, 192, 128)

                                Else
                                    grddispatch.Rows(row.Index).Cells(11).Value = idlec.Days & "day(s) " & idlec.Hours & ":" & idlec.Minutes
                                End If
                            End If
                        End If
                    Else
                        'grddispatch.Rows(row.index).Cells(11).Value = "00:00"
                    End If
                    drx1.Dispose()
                    cmdx1.Dispose()
                    conn.Close()
                End If
            Next

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        txttrip.Text = ""
        cmbplate.Enabled = True
        cmbdriver.Enabled = True
        datefrom.Enabled = True
        dateto.Enabled = True
        datefrom.Value = datefrom.MaxDate
        viewall()
    End Sub

    Private Sub grddispatch_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grddispatch.CellClick

    End Sub

    Private Sub grddispatch_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grddispatch.CellContentClick
        Try
            'link
            If e.ColumnIndex = 2 And e.RowIndex > -1 Then
                Dim cell As DataGridViewCell = grddispatch.Rows(e.RowIndex).Cells(e.ColumnIndex)
                grddispatch.CurrentCell = cell
                ' Me.ContextMenuStrip2.Show(Cursor.Position)
                If grddispatch.RowCount <> 0 Then
                    If grddispatch.Item(2, grddispatch.CurrentRow.Index).Value IsNot Nothing Then
                        'viewtrans.txttrans.Text = grddispatch.Item(2, grddispatch.CurrentRow.Index).Value
                        'populate grdtrans
                        viewtrans.grouptrans.Visible = True
                        viewtrans.grdtrans.Rows.Clear()
                        sql = "Select * from tbltripitems where tripnum='" & grddispatch.Item(2, grddispatch.CurrentRow.Index).Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        dr = cmd.ExecuteReader
                        While dr.Read
                            viewtrans.grdtrans.Rows.Add(dr("transnum"))
                        End While
                        dr.Dispose()
                        cmd.Dispose()
                        conn.Close()

                        viewtrans.ShowDialog()
                    End If
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub grddispatch_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grddispatch.CellDoubleClick
        'check if selected cell=1 and what column index
        If grddispatch.SelectedCells.Count = 1 Then
            If e.ColumnIndex = 8 And e.RowIndex > -1 Then
                If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(8).Value IsNot Nothing Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(8).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(8).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "1"
                        viewstep1.Text = "View Step1 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                        viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                        viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                        viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.ColumnIndex = 9 And e.RowIndex > -1 Then
                If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(9).Value IsNot Nothing Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(9).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(9).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "2"
                        viewstep1.Text = "View Step2 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                        viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                        viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                        viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.ColumnIndex = 10 And e.RowIndex > -1 Then
                If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(10).Value IsNot Nothing Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(10).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(10).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "3"
                        viewstep1.Text = "View Step3 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(1).Value & " )"
                        viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                        viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                        viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                        viewstep1.ShowDialog()
                    End If
                End If

            ElseIf e.ColumnIndex = 12 And e.RowIndex > -1 Then
                If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(12).Value IsNot Nothing Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(12).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(12).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "4"
                        viewstep1.Text = "View Step4 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                        viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                        viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                        viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.ColumnIndex = 13 And e.RowIndex > -1 Then
                If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(13).Value IsNot Nothing Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(13).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(13).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "5"
                        viewstep1.Text = "View Step5 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                        viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                        viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                        viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.ColumnIndex = 14 And e.RowIndex > -1 Then
                If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(14).Value IsNot Nothing Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(14).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(14).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "6"
                        viewstep1.Text = "View Step6 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                        viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                        viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                        viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.ColumnIndex = 15 And e.RowIndex > -1 Then
                If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(15).Value IsNot Nothing Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(15).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(15).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "7"
                        viewstep1.Text = "View Step7 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                        viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                        viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                        viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.ColumnIndex = 16 And e.RowIndex > -1 Then
                If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(16).Value IsNot Nothing Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(16).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(16).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "8"
                        viewstep1.Text = "View Step8 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                        viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                        viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                        viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                        viewstep1.ShowDialog()
                    End If
                End If
            ElseIf e.ColumnIndex = 19 And e.RowIndex > -1 Then
                If grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(19).Value IsNot Nothing Then
                    If Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(19).Value.ToString.Contains("SKIPPED") And Not grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(19).Value.ToString.Contains("RESCUE TRIP#") Then

                        viewstep1.lblstep.Text = "9"
                        viewstep1.Text = "View Step9 ( TRIP# " & grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value & " )"
                        viewstep1.lbltripnum1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(2).Value
                        viewstep1.lblplate1.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(3).Value
                        viewstep1.txtdes.Text = grddispatch.Rows(grddispatch.CurrentRow.Index).Cells(6).Value
                        viewstep1.ShowDialog()
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub cmbplate_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbplate.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbplate_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbplate.Leave
        getdriver()
    End Sub

    Public Sub getdriver()
        Try
            If Trim(cmbplate.Text) <> "" Then
                If Not cmbplate.Items.Contains(Trim(cmbplate.Text.ToUpper)) Then
                    cmbplate.Text = ""
                    cmbdriver.Text = ""
                Else
                    sql = "Select * from tblgeneral where status='1'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    While dr.Read
                        Dim plnum As String = ""
                        If dr("platenum") = "" And dr("vplate") <> "" Then
                            plnum = dr("vplate")
                        ElseIf dr("platenum") = "" And dr("vplate") = "" And dr("csticker") <> "" Then
                            plnum = dr("csticker")
                        Else
                            plnum = dr("platenum")
                        End If
                        If plnum = Trim(cmbplate.Text.ToUpper) Then
                            cmbplate.SelectedItem = plnum
                            cmbdriver.SelectedItem = dr("driver")
                        End If
                    End While
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()
                End If
            Else
                cmbdriver.SelectedItem = ""
                cmbplate.Text = ""
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbplate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbplate.TextChanged
        Dim charactersDisallowed As String = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ 0123456789"
        Dim theText As String = cmbplate.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = cmbplate.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To cmbplate.Text.Length - 1
            Letter = cmbplate.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        cmbplate.Text = theText
        cmbplate.Select(SelectionIndex - Change, 0)
    End Sub

    Public Sub driver()
        Try
            cmbdriver.Items.Clear()
            cmbdriver.Items.Add("")
            '/CType(Me.grdadd.Columns(8), DataGridViewComboBoxColumn).Items.Clear()
            '/CType(Me.grdadd.Columns(8), DataGridViewComboBoxColumn).Items.Add("")

            sql = "Select * from tbldriver order by driver"
            'check whse and dates
            connect()
            Dim cmd1 As SqlCommand = New SqlCommand(sql, conn)
            Dim dr1 As SqlDataReader = cmd1.ExecuteReader
            While dr1.Read
                cmbdriver.Items.Add(dr1("driver"))
            End While
            dr1.Dispose()
            cmd1.Dispose()

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub cmbdriver_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbdriver.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbdriver_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbdriver.Leave
        Try
            If Trim(cmbdriver.Text) <> "" Then

                sql = "Select * from tbldriver where driver='" & Trim(cmbdriver.Text) & "'"
                connect()
                cmd = New SqlCommand(sql, conn)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    cmbdriver.SelectedItem = dr("driver")
                Else
                    cmbdriver.Text = ""
                End If
                dr.Dispose()
                cmd.Dispose()
                conn.Close()

            Else
                cmbdriver.SelectedItem = ""
                cmbdriver.Text = ""
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub datefrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles datefrom.ValueChanged
        dateto.MinDate = datefrom.Value
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            If Trim(txttrip.Text) <> "" Then
                tripsearch()
                Exit Sub
            End If


            grddispatch.Rows.Clear()

            sql = "Select * from tbltripsum where datepick>='" & Format(datefrom.Value, "MM/dd/yyyy") & "' and datepick<='" & Format(dateto.Value, "MM/dd/yyyy") & "' and whsename='" & login.whse & "'"
            If cmbplate.Text <> "" Then
                sql = sql & " and platenum='" & cmbplate.Text & "'"
            End If

            If cmbdriver.Text <> "" Then
                sql = sql & " and driver='" & cmbdriver.Text & "'"
            End If

            sql = sql & " order by datepick"

            connect()
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            While drx.Read
                grddispatch.Rows.Add(drx("tripsumid"), Format(drx("datepick"), "MM/dd/yyyy"), drx("tripnum"), drx("platenum"), "", drx("driver"), "", drx("etd"))
                If drx("status") = 3 Then
                    grddispatch.Rows(grddispatch.Rows.Count - 1).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                End If
            End While
            drx.Dispose()
            cmdx.Dispose()



            For Each row As DataGridViewRow In grddispatch.Rows
                sql = "Select * from tblgeneral where (platenum='" & grddispatch.Rows(row.Index).Cells(3).Value & "' or vplate='" & grddispatch.Rows(row.Index).Cells(3).Value & "' or csticker='" & grddispatch.Rows(row.Index).Cells(3).Value & "')"
                connect()
                Dim cmdx1 As SqlCommand = New SqlCommand(sql, conn)
                Dim drx1 As SqlDataReader = cmdx1.ExecuteReader
                If drx1.Read Then
                    grddispatch.Item(4, row.Index).Value = drx1("vtype")
                End If
                drx1.Dispose()
                cmdx1.Dispose()
                conn.Close()
            Next


            For Each row As DataGridViewRow In grddispatch.Rows
                sql = "Select * from tbldispatchsum where tripnum='" & grddispatch.Rows(row.Index).Cells(2).Value & "'"
                connect()
                Dim cmdx1 As SqlCommand = New SqlCommand(sql, conn)
                Dim drx1 As SqlDataReader = cmdx1.ExecuteReader
                If drx1.Read Then
                    Dim whatstep As String = "ON QUEUE"
                    Dim des As String = ""
                    If drx1("step1") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp1").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp1").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp1") & " ( " & drx1("datestp1").ToString & " )"
                            whatstep = "STEP 1"
                        End If

                        grddispatch.Item(8, row.Index).Value = des
                        grddispatch.Item(8, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step2") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp2").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp2").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp2") & " ( " & drx1("datestp2").ToString & " )"
                            whatstep = "STEP 2"
                        End If

                        grddispatch.Item(9, row.Index).Value = des
                        grddispatch.Item(9, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step3") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp3").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp3").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp3") & " ( " & drx1("datestp3").ToString & " )"
                            whatstep = "STEP 3"
                        End If

                        grddispatch.Item(10, row.Index).Value = des
                        grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step4") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp4").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp4").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp4") & " ( " & drx1("datestp4").ToString & " )"
                            whatstep = "STEP 4"
                        End If

                        grddispatch.Item(12, row.Index).Value = des
                        grddispatch.Item(12, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step5") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp5").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp5").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp5") & " ( " & drx1("datestp5").ToString & " )"
                            whatstep = "STEP 5"
                            If IsDBNull(drx1("timedep")) = False Then
                                whatstep = "DISPATCHED"
                                grddispatch.Item(14, row.Index).Value = "Time Departure: " & drx1("timedep")
                            End If
                        End If

                        grddispatch.Item(13, row.Index).Value = des
                        grddispatch.Item(13, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step6") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp6").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp6").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp6") & " ( " & drx1("datestp6").ToString & " )"
                            whatstep = "STEP 6"
                            grddispatch.Item(20, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                        End If

                        grddispatch.Item(14, row.Index).Value = des
                        grddispatch.Item(14, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step7") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp7").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp7").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp7") & " ( " & drx1("datestp7").ToString & " )"
                            whatstep = "STEP 7"
                        End If

                        grddispatch.Item(15, row.Index).Value = des
                        grddispatch.Item(15, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step8") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp8").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp8").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp8") & " ( " & drx1("datestp8").ToString & " )"
                            whatstep = "STEP 8"
                        End If

                        grddispatch.Item(16, row.Index).Value = des
                        grddispatch.Item(16, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step9") = 1 Then
                        If drx1("namestp9").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp9").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp9") & " ( " & drx1("datestp9").ToString & " )"
                        Else
                            des = ""
                        End If

                        grddispatch.Item(19, row.Index).Value = des
                        grddispatch.Item(19, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                        whatstep = "COMPLETED"
                        grddispatch.Item(20, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                    End If
                    grddispatch.Item(20, row.Index).Value = whatstep

                End If
                drx1.Dispose()
                cmdx1.Dispose()
                conn.Close()
            Next


            For Each row As DataGridViewRow In grddispatch.Rows
                If grddispatch.Rows(row.Index).Cells(0).Value.ToString <> "" Then

                    sql = "SELECT * FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum where tbltripsum.tripnum='" & grddispatch.Rows(row.Index).Cells(2).Value & "' and tbltripsum.datepick>='" & Format(datefrom.Value, "MM/dd/yyyy") & "' and tbltripsum.datepick<='" & Format(dateto.Value, "MM/dd/yyyy") & "' and tbltripsum.whsename='" & login.whse & "'"
                    connect()
                    Dim cmdx1 As SqlCommand = New SqlCommand(sql, conn)
                    Dim drx1 As SqlDataReader = cmdx1.ExecuteReader
                    If drx1.Read Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            grddispatch.Item(20, row.Index).Value = "RESCUED BY " & drx1("rescue").ToString
                        End If

                        Dim starttime As Date
                        Dim finishtime As Date
                        If IsDBNull(drx1("startload")) = False Then
                            Dim timeCheck As Boolean
                            timeCheck = IsDate(drx1("startload"))
                            If timeCheck = True Then
                                'MsgBox(Trim(txttime.Text) & timeCheck)
                                starttime = CDate(drx1("startload").ToString)
                                finishtime = CDate(drx1("datestp3").ToString)
                                grddispatch.Item(11, row.Index).Value = Format(starttime, "HH:mm") & Format(finishtime, "HH:mm")

                            End If
                        End If

                        If IsDBNull(drx1("etd")) = False And IsDBNull(drx1("datestp3")) = False Then
                            If drx1("datestp3") > drx1("etd") Then
                                'MsgBox("greater than the etd")
                                grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(255, 192, 128)
                                Exit Sub
                            End If
                        End If

                        Dim idlec As TimeSpan


                        'MsgBox(idlec.ToString)
                        If grddispatch.Rows(row.Index).Cells(14).Value IsNot Nothing And grddispatch.Rows(row.Index).Cells(15).Value IsNot Nothing Then
                            If Trim(finishtime.ToString) <> "" And Trim(starttime.ToString) <> "" Then
                                idlec = finishtime - starttime
                                'Dim ckac As Boolean = IsDate(grddispatch.Rows(row.Index).Cells(14).Value)
                                'Dim ckacd As Boolean = IsDate(grddispatch.Rows(row.Index).Cells(15).Value)

                                'If ckac = True And ckacd = True Then
                                If idlec.Hours < 0 Or idlec.Minutes < 0 Or idlec.Days < 0 Then
                                    grddispatch.Rows(row.Index).Cells(11).Value = "Invalid date/time"

                                ElseIf idlec.Hours >= 2 And idlec.Minutes > 0 Or idlec.Days < 0 Then
                                    'grddispatch.Rows(row.Index).Cells(11).Value = idlec.Hours & ":" & idlec.Minutes & " >2hrs"
                                    grddispatch.Rows(row.Index).Cells(11).Value = "2"
                                    grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(255, 192, 128)

                                ElseIf idlec.Hours = 1 And idlec.Minutes > 30 Or idlec.Days < 0 Then
                                    'grddispatch.Rows(row.Index).Cells(11).Value = idlec.Hours & ":" & idlec.Minutes & " >1:30 <=2:00"
                                    grddispatch.Rows(row.Index).Cells(11).Value = "1"
                                    grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(128, 255, 128)

                                ElseIf idlec.Days > 0 Then
                                    grddispatch.Rows(row.Index).Cells(11).Value = "3"
                                    grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(255, 192, 128)

                                Else
                                    grddispatch.Rows(row.Index).Cells(11).Value = idlec.Days & "day(s) " & idlec.Hours & ":" & idlec.Minutes
                                End If
                            End If
                        End If


                        'diesel standard

                    End If
                    drx1.Dispose()
                    cmdx1.Dispose()
                    conn.Close()
                End If
            Next

            If grddispatch.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            'MsgBox(ex.tostring, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txttrip_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttrip.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        End If
        If Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            tripsearch()
        End If
    End Sub

    Public Sub tripsearch()
        Try
            grddispatch.Rows.Clear()

            sql = "Select * from tbltripsum where tripnum='" & lbltrip.Text & txttrip.Text & "' and whsename='" & login.whse & "'"
            connect()
            Dim cmdx As SqlCommand = New SqlCommand(sql, conn)
            Dim drx As SqlDataReader = cmdx.ExecuteReader
            While drx.Read
                grddispatch.Rows.Add(drx("tripsumid"), Format(drx("datepick"), "MM/dd/yyyy"), drx("tripnum"), drx("platenum"), "", drx("driver"), "", drx("etd"))
                If drx("status") = 3 Then
                    grddispatch.Rows(grddispatch.Rows.Count - 1).DefaultCellStyle.BackColor = Color.DeepSkyBlue
                End If
            End While
            drx.Dispose()
            cmdx.Dispose()


            For Each row As DataGridViewRow In grddispatch.Rows
                sql = "Select * from tblgeneral where (platenum='" & grddispatch.Rows(row.Index).Cells(3).Value & "' or vplate='" & grddispatch.Rows(row.Index).Cells(3).Value & "' or csticker='" & grddispatch.Rows(row.Index).Cells(3).Value & "')"
                connect()
                Dim cmdx1 As SqlCommand = New SqlCommand(sql, conn)
                Dim drx1 As SqlDataReader = cmdx1.ExecuteReader
                If drx1.Read Then
                    grddispatch.Item(4, row.Index).Value = drx1("vtype")
                End If
                drx1.Dispose()
                cmdx1.Dispose()
                conn.Close()
            Next


            For Each row As DataGridViewRow In grddispatch.Rows
                sql = "Select * from tbldispatchsum where tripnum='" & grddispatch.Rows(row.Index).Cells(2).Value & "'"
                connect()
                Dim cmdx1 As SqlCommand = New SqlCommand(sql, conn)
                Dim drx1 As SqlDataReader = cmdx1.ExecuteReader
                If drx1.Read Then
                    Dim whatstep As String = "ON QUEUE"
                    Dim des As String = ""
                    If drx1("step1") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp1").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp1").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp1") & " ( " & drx1("datestp1").ToString & " )"
                            whatstep = "STEP 1"
                        End If

                        grddispatch.Item(8, row.Index).Value = des
                        grddispatch.Item(8, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step2") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp2").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp2").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp2") & " ( " & drx1("datestp2").ToString & " )"
                            whatstep = "STEP 2"
                        End If

                        grddispatch.Item(9, row.Index).Value = des
                        grddispatch.Item(9, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step3") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp3").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp3").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp3") & " ( " & drx1("datestp3").ToString & " )"
                            whatstep = "STEP 3"
                        End If

                        grddispatch.Item(10, row.Index).Value = des
                        grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step4") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp4").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp4").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp4") & " ( " & drx1("datestp4").ToString & " )"
                            whatstep = "STEP 4"
                        End If

                        grddispatch.Item(12, row.Index).Value = des
                        grddispatch.Item(12, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step5") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp5").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp5").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp5") & " ( " & drx1("datestp5").ToString & " )"
                            whatstep = "STEP 5"
                            If IsDBNull(drx1("timedep")) = False Then
                                whatstep = "DISPATCHED"
                                grddispatch.Item(14, row.Index).Value = "Time Departure: " & drx1("timedep")
                            End If
                        End If

                        grddispatch.Item(13, row.Index).Value = des
                        grddispatch.Item(13, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step6") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp6").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp6").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp6") & " ( " & drx1("datestp6").ToString & " )"
                            whatstep = "STEP 6"
                            grddispatch.Item(20, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                        End If

                        grddispatch.Item(14, row.Index).Value = des
                        grddispatch.Item(14, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step7") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp7").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp7").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp7") & " ( " & drx1("datestp7").ToString & " )"
                            whatstep = "STEP 7"
                        End If

                        grddispatch.Item(15, row.Index).Value = des
                        grddispatch.Item(15, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step8") = 1 Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            des = "RESCUE TRIP# " & drx1("rescue")
                        ElseIf drx1("namestp8").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp8").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp8") & " ( " & drx1("datestp8").ToString & " )"
                            whatstep = "STEP 8"
                        End If

                        grddispatch.Item(16, row.Index).Value = des
                        grddispatch.Item(16, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)

                    End If
                    If drx1("step9") = 1 Then
                        If drx1("namestp9").ToString = "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = "SKIPPED"
                        ElseIf drx1("namestp9").ToString <> "" And (drx1("rescue").ToString = "" Or drx1("rescue").ToString = "-") Then
                            des = drx1("namestp9") & " ( " & drx1("datestp9").ToString & " )"
                        Else
                            des = ""
                        End If

                        grddispatch.Item(19, row.Index).Value = des
                        grddispatch.Item(19, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                        whatstep = "COMPLETED"
                        grddispatch.Item(20, row.Index).Style.BackColor = Color.FromArgb(255, 255, 128)
                    End If
                    grddispatch.Item(20, row.Index).Value = whatstep

                End If
                drx1.Dispose()
                cmdx1.Dispose()
                conn.Close()
            Next


            For Each row As DataGridViewRow In grddispatch.Rows
                If grddispatch.Rows(row.Index).Cells(0).Value.ToString <> "" Then

                    sql = "SELECT * FROM tbltripsum RIGHT OUTER JOIN tbldispatchsum ON tbltripsum.tripnum=tbldispatchsum.tripnum where tbltripsum.tripnum='" & grddispatch.Rows(row.Index).Cells(2).Value & "' and tbltripsum.datepick>='" & Format(datefrom.Value, "MM/dd/yyyy") & "' and tbltripsum.datepick<='" & Format(dateto.Value, "MM/dd/yyyy") & "' and tbltripsum.whsename='" & login.whse & "'"
                    connect()
                    Dim cmdx1 As SqlCommand = New SqlCommand(sql, conn)
                    Dim drx1 As SqlDataReader = cmdx1.ExecuteReader
                    If drx1.Read Then
                        If drx1("rescue").ToString <> "" And drx1("rescue").ToString <> "-" Then
                            grddispatch.Item(20, row.Index).Value = "RESCUED BY " & drx1("rescue").ToString
                        End If

                        Dim starttime As Date
                        Dim finishtime As Date
                        If IsDBNull(drx1("startload")) = False Then
                            Dim timeCheck As Boolean
                            timeCheck = IsDate(drx1("startload"))
                            If timeCheck = True Then
                                'MsgBox(Trim(txttime.Text) & timeCheck)
                                starttime = CDate(drx1("startload").ToString)
                                finishtime = CDate(drx1("datestp3").ToString)
                                grddispatch.Item(11, row.Index).Value = Format(starttime, "HH:mm") & Format(finishtime, "HH:mm")

                            End If
                        End If

                        If IsDBNull(drx1("etd")) = False And IsDBNull(drx1("datestp3")) = False Then
                            If drx1("datestp3") > drx1("etd") Then
                                'MsgBox("greater than the etd")
                                grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(255, 192, 128)
                                Exit Sub
                            End If
                        End If

                        Dim idlec As TimeSpan


                        'MsgBox(idlec.ToString)
                        If grddispatch.Rows(row.Index).Cells(14).Value IsNot Nothing And grddispatch.Rows(row.Index).Cells(15).Value IsNot Nothing Then
                            If Trim(finishtime.ToString) <> "" And Trim(starttime.ToString) <> "" Then
                                idlec = finishtime - starttime
                                'Dim ckac As Boolean = IsDate(grddispatch.Rows(row.Index).Cells(14).Value)
                                'Dim ckacd As Boolean = IsDate(grddispatch.Rows(row.Index).Cells(15).Value)

                                'If ckac = True And ckacd = True Then
                                If idlec.Hours < 0 Or idlec.Minutes < 0 Or idlec.Days < 0 Then
                                    grddispatch.Rows(row.Index).Cells(11).Value = "Invalid date/time"

                                ElseIf idlec.Hours >= 2 And idlec.Minutes > 0 Or idlec.Days < 0 Then
                                    'grddispatch.Rows(row.Index).Cells(11).Value = idlec.Hours & ":" & idlec.Minutes & " >2hrs"
                                    grddispatch.Rows(row.Index).Cells(11).Value = "2"
                                    grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(255, 192, 128)

                                ElseIf idlec.Hours = 1 And idlec.Minutes > 30 Or idlec.Days < 0 Then
                                    'grddispatch.Rows(row.Index).Cells(11).Value = idlec.Hours & ":" & idlec.Minutes & " >1:30 <=2:00"
                                    grddispatch.Rows(row.Index).Cells(11).Value = "1"
                                    grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(128, 255, 128)

                                ElseIf idlec.Days > 0 Then
                                    grddispatch.Rows(row.Index).Cells(11).Value = "3"
                                    grddispatch.Item(10, row.Index).Style.BackColor = Color.FromArgb(255, 192, 128)

                                Else
                                    grddispatch.Rows(row.Index).Cells(11).Value = idlec.Days & "day(s) " & idlec.Hours & ":" & idlec.Minutes
                                End If
                            End If
                        End If
                    Else
                        'grddispatch.Rows(row.index).Cells(11).Value = "00:00"
                    End If
                    drx1.Dispose()
                    cmdx1.Dispose()
                    conn.Close()
                End If
            Next

            If grddispatch.Rows.Count = 0 Then
                MsgBox("No Record Found.", MsgBoxStyle.Critical, "")
            End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub txttrip_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttrip.TextChanged
        Dim charactersDisallowed As String = "0123456789"
        Dim theText As String = txttrip.Text
        Dim Letter As String
        Dim SelectionIndex As Integer = txttrip.SelectionStart
        Dim Change As Integer

        For x As Integer = 0 To txttrip.Text.Length - 1
            Letter = txttrip.Text.Substring(x, 1)
            If Not charactersDisallowed.Contains(Letter) Then
                theText = theText.Replace(Letter, String.Empty)
                Change = 1
            End If
        Next

        txttrip.Text = theText
        txttrip.Select(SelectionIndex - Change, 0)

        If Trim(txttrip.Text) <> "" Then
            cmbplate.Enabled = False
            cmbdriver.Enabled = False
            datefrom.Enabled = False
            dateto.Enabled = False
        Else
            cmbplate.Enabled = True
            cmbdriver.Enabled = True
            datefrom.Enabled = True
            dateto.Enabled = True
            btnview.PerformClick()
        End If
    End Sub

    Public Sub colorcoding()
        Try
            For Each row As DataGridViewRow In grddispatch.Rows
                If grddispatch.Rows(row.Index).Cells(10).Value.ToString IsNot Nothing Then

                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.ToString, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub btnprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub grddispatch_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grddispatch.SelectionChanged
        count()
    End Sub

    Public Sub count()
        Try
            lblcount.Text = "     Selected Rows Count: " & grddispatch.SelectedRows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class