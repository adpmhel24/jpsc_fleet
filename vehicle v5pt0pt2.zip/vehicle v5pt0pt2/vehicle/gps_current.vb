﻿Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Public Class gps_current
    Public Property success As Boolean
    Public Property user_time As String
    'Public Property states As States_current
    Public Property states As States_current ' List(Of NumericJson)

    Public Class States_current
        <JsonProperty("trackerID")> 'tracker_id dapat nakalagay
        Public Property Item1 As tracker_id
        <JsonProperty("2")>
        Public Property Item2 As tracker_id2
    End Class

    'Public Class NumericJson
    '    <JsonProperty("1")>
    '    Public Property Item1 As tracker_id
    '    <JsonProperty("2")>
    '    Public Property Item2 As tracker_id2
    'End Class

    Public Class tracker_id
        Public Property source_id As Integer
        Public Property gps As Gps
        Public Property connection_status As String
        Public Property movement_status As String
        Public Property gsm As Gsm
        Public Property last_update As String
        Public Property battery_level As Object
        Public Property battery_update As Object
        Public Property inputs As List(Of Boolean)
        Public Property inputs_update As String
        Public Property outputs As List(Of Boolean)
        Public Property outputs_update As String
        Public Property actual_track_update As String
    End Class

    Public Class Location
        Public Property lat As Double
        Public Property lng As Double
    End Class

    Public Class Gps
        Public Property updated As Object
        Public Property signal_level As Integer
        Public Property location As Location
        Public Property heading As Integer
        Public Property speed As Integer
        Public Property alt As Integer
    End Class

    Public Class Gsm
        Public Property updated As String
        Public Property signal_level As Integer
        Public Property network_name As String
        Public Property roaming As Object
    End Class
    '///////////////////////

    Public Class tracker_id2
        Public Property source_id As Integer
        Public Property gps As Gps2
        Public Property connection_status As String
        Public Property movement_status As String
        Public Property gsm As Gsm2
        Public Property last_update As String
        Public Property battery_level As Integer
        Public Property battery_update As String
        Public Property inputs As List(Of Boolean)
        Public Property inputs_update As String
        Public Property outputs As List(Of Boolean)
        Public Property outputs_update As String
        Public Property actual_track_update As String
    End Class

    Public Class Location2
        Public Property lat As Double
        Public Property lng As Double
    End Class

    Public Class Gps2
        Public Property updated As String
        Public Property signal_level As Integer
        Public Property location As Location
        Public Property heading As Integer
        Public Property speed As Integer
        Public Property alt As Integer
    End Class

    Public Class Gsm2
        Public Property updated As String
        Public Property signal_level As Integer
        Public Property network_name As String
        Public Property roaming As Object
    End Class
End Class
