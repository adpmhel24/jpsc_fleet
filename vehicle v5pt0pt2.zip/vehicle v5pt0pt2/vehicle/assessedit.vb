﻿Imports System.Data.SqlClient
Public Class assessedit
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand
    Public cnf As Boolean

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Private Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub assessedit_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Me.Dispose()
    End Sub

    Private Sub assessedit_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btncat_Click(sender As Object, e As EventArgs) Handles btncat.Click
        assessviewcat.frm = "assessedit"
        assessviewcat.ShowDialog()
    End Sub

    Private Sub linkadd_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles linkadd.LinkClicked
        assessviewemp.frm = "assessedit"
        assessviewemp.ShowDialog()
    End Sub

    Private Sub list1_KeyDown(sender As Object, e As KeyEventArgs) Handles list1.KeyDown
        If e.KeyCode = Keys.Delete AndAlso list1.SelectedItem <> Nothing Then
            list1.Items.RemoveAt(list1.SelectedIndex)
        End If
    End Sub

    Private Sub list1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles list1.SelectedIndexChanged

    End Sub

    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        Try
            If list1.Items.Count = 0 Then
                MsgBox("Add employee.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            ElseIf Trim(txtcom.Text) = "" Then
                MsgBox("Input logistics' comment.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            ElseIf Trim(txtsub.Text) = "" Then
                MsgBox("Select subject.", MsgBoxStyle.Exclamation, "")
                Exit Sub
            Else
                cnf = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If cnf = True Then
                    ExecuteSave(strconn)
                End If
            End If

            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub ExecuteSave(ByVal connectionString As String)
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Dim command As SqlCommand = connection.CreateCommand()
            Dim transaction As SqlTransaction
            transaction = connection.BeginTransaction("SampleTransaction")
            command.Connection = connection
            command.Transaction = transaction

            Try
                Me.Cursor = Cursors.WaitCursor
                '/command.CommandText = sql
                '/command.ExecuteNonQuery()
                sql = "Update tblassess where aid='" & GroupBox3.Text & "'"

                sql = "Update tblassessemp where aid="

                ' Attempt to commit the transaction.
                transaction.Commit()
                Me.Cursor = Cursors.Default
                MsgBox("Successfully saved.", MsgBoxStyle.Information, "")
                assessall.view(txttrip.Text)
                Me.Dispose()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("1: " & ex.Message, MsgBoxStyle.Exclamation, "")
            End Try
        End Using
    End Sub
End Class