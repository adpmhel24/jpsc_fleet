Imports System.IO

Public Class Form1
    Private Sub mnuFileOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileOpen.Click
        If ofdOriginal.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Try
                ' Load the original image.
                picOriginal.Image = LoadImage(ofdOriginal.FileName)
                picNew.Image = Nothing
                txtCompressionLevel.Clear()

                ' Display the file's size.
                Dim file_info As New FileInfo(ofdOriginal.FileName)
                txtOriginalSize.Text = FormatBytes(file_info.Length)
                txtDesiredSize.Text = FormatBytes(file_info.Length * 0.5)
                If Microsoft.VisualBasic.Right(ofdOriginal.FileName.ToString, 3) = "png" Then
                    txtDesiredSize.Text = FormatBytes(file_info.Length * 0.3)
                Else
                    txtDesiredSize.Text = FormatBytes(file_info.Length * 0.4)
                End If
                txtCompressedSize.Clear()
                txtCompressionLevel.Clear()
            Catch ex As Exception
                MessageBox.Show("Error loading picture file " & ofdOriginal.FileName & vbCrLf & ex.Message, "File Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub mnuFileSaveAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSaveAs.Click
        Try
            Dim desired_size As Double = FormattedBytesToBytes(txtDesiredSize.Text)
            If desired_size < 10 Then
                MessageBox.Show("Invalid desired size.", "Invalid Size", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtDesiredSize.Focus()
                Exit Sub
            End If

            If sfdJpeg.ShowDialog() = Windows.Forms.DialogResult.OK Then
                picNew.Image = Nothing
                txtCompressionLevel.Clear()
                txtCompressedSize.Clear()

                Dim file_name As String = sfdJpeg.FileName
                Dim file_size As Long
                For compression_level As Integer = 100 To 10 Step -1
                    ' Save the file into a memory stream.
                    Dim memory_stream As MemoryStream = SaveJpegIntoStream(picOriginal.Image, compression_level)

                    ' See how big it is.
                    file_size = memory_stream.Length
                    If file_size <= desired_size Then
                        ' Display the final size and image.
                        ' Save the file.
                        My.Computer.FileSystem.WriteAllBytes(file_name, memory_stream.ToArray(), False)
                        Dim ms As New MemoryStream(memory_stream.ToArray())
                        picNew.Image = Image.FromStream(ms)
                        '/tripdispatch.imgbox1.Image = Image.FromStream(ms)
                        '/picNew.Image = LoadImage(file_name)
                        txtCompressionLevel.Text = compression_level
                        txtCompressedSize.Text = FormatBytes(file_size)
                        Exit For
                    End If
                Next compression_level
            End If

        Catch ex As Exception
            MessageBox.Show("Error saving file." & vbCrLf & ex.Message, "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        picNew.Image.Save("C:\Users\Admin\Desktop\" & Trim(txtname.Text) & ".jpeg", Imaging.ImageFormat.Jpeg) ' picNew.Image.RawFormat)
    End Sub

    Private Function compressimage(ByVal picimage As Image, ByVal picname As String)

        Me.Cursor = Cursors.WaitCursor
        Dim desired_size As Double = FormattedBytesToBytes(txtDesiredSize.Text)
        '/MsgBox(desired_size)
        If desired_size > 10 Then
            txtCompressionLevel.Text = ""
            txtCompressedSize.Text = ""

            Dim file_name As String = picname
            Dim file_size As Long
            For compression_level As Integer = 100 To 10 Step -1
                ' Save the file into a memory stream.
                Dim memory_stream As MemoryStream = SaveJpegIntoStream(picimage, compression_level)

                ' See how big it is.
                file_size = memory_stream.Length
                If file_size <= desired_size Then
                    ' Display the final size and image.
                    ' Save the file.
                    '/My.Computer.FileSystem.WriteAllBytes(file_name, memory_stream.ToArray(), False)
                    Dim ms As New MemoryStream(memory_stream.ToArray())
                    picimage = Image.FromStream(ms)
                    '/picNew.Image = LoadImage(file_name)
                    txtCompressionLevel.Text = compression_level
                    txtCompressedSize.Text = FormatBytes(file_size)
                    Exit For
                End If
            Next
            Me.Cursor = Cursors.Default
        End If

        Return picimage

        If desired_size < 10 Then
            MessageBox.Show("Invalid desired size.", "Invalid Size", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtDesiredSize.Focus()
        End If

    End Function

    ' Load a bitmap so it's not locked.
    Private Function LoadImage(ByVal file_name As String) As Bitmap
        Using bm As New Bitmap(file_name)
            Dim bm2 As New Bitmap(bm)
            Return bm2
        End Using
    End Function

    Private Sub txtDesiredSize_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDesiredSize.TextChanged

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            picNew.Image = compressimage(picOriginal.Image, Trim(txtname.Text))
        Catch ex As System.Data.SqlClient.SqlException
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Function GetResizedImage(ByVal Data As Byte(), ByVal NewWidth As Integer, ByVal NewHeight As Integer) As Byte()
        Try
            Dim ms As New IO.MemoryStream(Data)
            Dim bmp As New Bitmap(ms)
            Dim ResizedBMP As New Bitmap(NewWidth, NewHeight)
            Dim g As Graphics = Graphics.FromImage(bmp)
            g.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic
            g.DrawImage(ResizedBMP, 0, 0, NewWidth, NewHeight)
            Dim NewImageStream As New IO.MemoryStream
            ResizedBMP.Save(NewImageStream, System.Drawing.Imaging.ImageFormat.Jpeg)
            Return NewImageStream.ToArray
        Catch
            Throw
        End Try
    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub picOriginal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picOriginal.Click
        PictureBox1.Image = picOriginal.Image
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        '/ viewimage.imgbox.Image = PictureBox1.Image
        '/ viewimage.lblimgid.Text = 1
        '/ viewimage.ShowDialog()
    End Sub
End Class
