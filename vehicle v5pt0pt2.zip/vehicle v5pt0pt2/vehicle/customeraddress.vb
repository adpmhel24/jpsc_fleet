﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Drawing

Public Class customeraddress
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String, selectedrow As Integer

    Public cuscnf As Boolean
    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Close()
        End If
    End Sub
    Private Sub customeraddress_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        load_customer2()
    End Sub
    Public Sub load_customer2()
        Try
            Dim stat As String = ""
            grdcus2.Rows.Clear()

            sql = "Select c.id,p.poiid,p.poiname,p.address,d.value as distance,t.value as tym,p.latitude,p.longitude,c.status from tblcuspoi c "
            sql = sql & " right outer join tblpoi p on c.poiid=p.poiid"
            sql = sql & " left outer join tblpoidistance d on p.poiid=d.poiid and d.whsename='" & login.whse & "'"
            sql = sql & " left outer join tblpoitime t on p.poiid=t.poiid and t.whsename='" & login.whse & "'"
            sql = sql & " where c.cusid='" & lblcusid.Text & "'"
            sql = sql & " group by c.id,p.poiid,p.poiname,p.address,d.value,t.value,p.latitude,p.longitude,c.status"
            sql = sql & " order by p.poiname"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If

                Dim est As String = "", dys As String = "", hrs As String = "", mins As String = ""
                If IsDBNull(dr("tym")) = False Then
                    Dim d = TimeSpan.FromMinutes(dr("tym"))
                    If d.Days = 1 Then
                        dys = d.Days & " day"
                    ElseIf d.Days > 1 Then
                        dys = d.Days & " days"
                    End If

                    If d.Hours = 1 Then
                        hrs = d.Hours & " hr"
                    ElseIf d.Hours > 1 Then
                        hrs = d.Hours & " hrs"
                    End If

                    If d.Minutes = 1 Then
                        mins = d.Minutes & " min"
                    ElseIf d.Minutes > 1 Then
                        mins = d.Minutes & " mins"
                    End If
                    est = Trim(dys & " " & hrs & " " & mins)
                End If

                grdcus2.Rows.Add(dr("id"), dr("poiid"), dr("poiname"), dr("address"), dr("distance"), est, dr("latitude"), dr("longitude"), stat)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If Trim(txtname.Text) = "" Or Trim(txtaddress.Text) = "" Then
                Me.Cursor = Cursors.Default
                MsgBox("Complete the required fields.", MsgBoxStyle.Exclamation, "")
                txtname.Focus()
                Exit Sub
            End If

            Dim meronna As Boolean = False
            sql = "Select status from tblcuspoi where cusid='" & lblcusid.Text & "' and poiid='" & lblpoiid.Text & "'"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            If dr.Read Then
                meronna = True
            End If
            dr.Dispose()
            cmd.ExecuteReader()
            conn.Close()


            If meronna = False Then
                cuscnf = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If cuscnf = True Then
                    sql = "Insert into tblcuspoi (cusid,poiid,datecreated,createdby,datemodified,modifiedby,status) values"
                    sql = sql & " ('" & lblcusid.Text & "','" & lblpoiid.Text & "',GetDate(),'" & login.cashier & "',GetDate(),'" & login.cashier & "','1')"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    conn.Close()

                    MsgBox("Successfully added.", MsgBoxStyle.Information, "")
                    txtname.Text = ""
                    txtaddress.Text = ""
                    lblpoiid.Text = ""
                    load_customer2()
                End If
            Else
                MsgBox(Trim(txtname.Text) & " is already exist.", MsgBoxStyle.Exclamation, "")
                txtname.Text = ""
                txtaddress.Text = ""
                lblpoiid.Text = ""
            End If


        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub customeraddress_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Me.Dispose()
    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
            MsgBox("Access denied!", MsgBoxStyle.Critical, "")
            Exit Sub
        End If

        vpoiselect.frm = Me.Name
        vpoiselect.ShowDialog()
    End Sub

    Private Sub btndeactivate_Click(sender As Object, e As EventArgs) Handles btndeactivate.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            'selected make sure isang cell oir row then update sa db gawing status=0
            If grdcus2.SelectedCells.Count = 1 Or grdcus2.SelectedRows.Count = 1 Then
                cuscnf = False
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If cuscnf = True Then
                    If btndeactivate.Text = "&Deactivate" Then
                        sql = "Update tblcuspoi set status='0' where id='" & grdcus2.Rows(grdcus2.CurrentRow.Index).Cells("id").Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully deactivated.", MsgBoxStyle.Information, "")
                        load_customer2()
                    Else
                        sql = "Update tblcuspoi set status='1' where id='" & grdcus2.Rows(grdcus2.CurrentRow.Index).Cells("id").Value & "'"
                        connect()
                        cmd = New SqlCommand(sql, conn)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        conn.Close()

                        MsgBox("Successfully activated.", MsgBoxStyle.Information, "")
                        load_customer2()
                    End If
                End If
            Else
                MsgBox("Select one only.", MsgBoxStyle.Exclamation, "")
            End If

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub grdcus2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdcus2.CellContentClick

    End Sub

    Private Sub grdcus2_SelectionChanged(sender As Object, e As EventArgs) Handles grdcus2.SelectionChanged
        If grdcus2.Rows.Count <> 0 Then
            If grdcus2.Rows(grdcus2.CurrentRow.Index).Cells("status").Value = "Active" Then
                btndeactivate.Text = "&Deactivate"
            Else
                btndeactivate.Text = "&Activate"
            End If
        End If
    End Sub

    Private Sub btncancel_Click(sender As Object, e As EventArgs) Handles btncancel.Click
        txtname.Text = ""
        txtaddress.Text = ""
        lblpoiid.Text = ""
    End Sub

    Private Sub btnimport_Click(sender As Object, e As EventArgs) Handles btnimport.Click
        If login.neym <> "Administrator" And login.neym <> "Supervisor" Then
            MsgBox("Access denied!", MsgBoxStyle.Critical, "")
            Exit Sub
        End If
        importcustomerpoi.ShowDialog()
    End Sub

    Private Sub UpdateGPSPOIToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateGPSPOIToolStripMenuItem.Click
        customerpoi.poiid = grdcus2.Rows(selectedrow).Cells("poiid").Value
        customerpoi.ShowDialog()
    End Sub

    Private Sub grdcus2_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles grdcus2.CellMouseClick
        If e.Button = Windows.Forms.MouseButtons.Right And e.RowIndex > -1 Then
            If login.neym <> "Administrator" And login.neym <> "Supervisor" Then
                'MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If
            If e.ColumnIndex = 2 Then
                If grdcus2.Rows(e.RowIndex).Cells("status").Value = "Active" Then
                    If grdcus2.Rows(e.RowIndex).Cells("poiname").Value = "---TEMPORARY POI---" Then
                        MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                    Else
                        grdcus2.ClearSelection()
                        grdcus2.Rows(e.RowIndex).Cells(2).Selected = True

                        selectedrow = e.RowIndex
                        Me.ContextMenuStrip1.Show(Cursor.Position)
                    End If
                Else
                    MsgBox("Deactivated!", MsgBoxStyle.Exclamation, "")
                End If
            End If
        End If
    End Sub
End Class