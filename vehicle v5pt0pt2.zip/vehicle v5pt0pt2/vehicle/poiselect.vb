﻿Imports System.IO
Imports System.Data.SqlClient
Public Class poiselect
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String, selectedrow As Integer
    Public customer As String, frm As String

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Private Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Close()
        End If
    End Sub
    Private Sub poiselect_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        load_customer2()
        If grdcus2.Rows.Count = 0 Then
            MsgBox("Cannot found recipient: " & customer & ".", MsgBoxStyle.Critical, "")
        End If
    End Sub

    Private Sub grdcus2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdcus2.CellContentClick

    End Sub

    Private Sub load_customer2()
        Try
            Dim stat As String = ""
            grdcus2.Rows.Clear()

            sql = "Select c.id,p.poiid,p.poiname,p.address,d.value as distance,t.value as tym,p.latitude,p.longitude,c.status from tblcuspoi c "
            sql = sql & " right outer join tblpoi p on c.poiid=p.poiid"
            sql = sql & " right outer join tblpoidistance d on p.poiid=d.poiid and d.whsename='" & login.whse & "'"
            sql = sql & " left outer join tblpoitime t on p.poiid=t.poiid and t.whsename='" & login.whse & "'"
            sql = sql & " inner join tblcustomer cc on cc.cusid=c.cusid"
            sql = sql & " where cc.customer='" & Trim(customer.ToString.Replace("'", "''")) & "' and c.status='1'" 'and d.value is not null 
            If frm <> "mainmenucreate" Then
                sql = sql & " and p.poiname <> '---TEMPORARY POI---'"
            End If
            sql = sql & " group by c.id,p.poiid,p.poiname,p.address,d.value,t.value,p.latitude,p.longitude,c.status"
            sql = sql & " order by p.poiname"
            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If

                Dim est As String = "", dys As String = "", hrs As String = "", mins As String = ""
                If IsDBNull(dr("tym")) = False Then
                    Dim d = TimeSpan.FromMinutes(dr("tym"))
                    If d.Days = 1 Then
                        dys = d.Days & " day"
                    ElseIf d.Days > 1 Then
                        dys = d.Days & " days"
                    End If

                    If d.Hours = 1 Then
                        hrs = d.Hours & " hr"
                    ElseIf d.Hours > 1 Then
                        hrs = d.Hours & " hrs"
                    End If

                    If d.Minutes = 1 Then
                        mins = d.Minutes & " min"
                    ElseIf d.Minutes > 1 Then
                        mins = d.Minutes & " mins"
                    End If
                    est = Trim(dys & " " & hrs & " " & mins)
                End If

                grdcus2.Rows.Add(dr("id"), dr("poiid"), dr("poiname"), dr("address"), dr("distance"), est, dr("latitude"), dr("longitude"), stat)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try
            Dim stat As String = ""
            grdcus2.Rows.Clear()

            sql = "Select c.id,p.poiid,p.poiname,p.address,d.value as distance,t.value as tym,p.latitude,p.longitude,c.status from tblcuspoi c "
            sql = sql & " right outer join tblpoi p on c.poiid=p.poiid"
            sql = sql & " right outer join tblpoidistance d on p.poiid=d.poiid and d.whsename='" & login.whse & "'"
            sql = sql & " left outer join tblpoitime t on p.poiid=t.poiid and t.whsename='" & login.whse & "'"
            sql = sql & " inner join tblcustomer cc on cc.cusid=c.cusid"
            sql = sql & " where cc.customer='" & Trim(customer.ToString.Replace("'", "''")) & "' and c.status='1'"
            If Trim(txtpoi.Text) <> "" Then
                sql = sql & " and p.poiname like '%" & Trim(txtpoi.Text.ToString.Replace("'", "''")) & "%'"
            ElseIf Trim(txtadd.Text) <> "" Then
                sql = sql & " and p.address like '%" & Trim(txtadd.Text.ToString.Replace("'", "''")) & "%'"
            End If
            If frm <> "mainmenucreate" Then
                sql = sql & " and p.poiname <> '---TEMPORARY POI---'"
            End If
            sql = sql & " group by c.id,p.poiid,p.poiname,p.address,d.value,t.value,p.latitude,p.longitude,c.status"
            sql = sql & " order by p.poiname"

            connect()
            cmd = New SqlCommand(sql, conn)
            dr = cmd.ExecuteReader
            While dr.Read
                If dr("status") = 1 Then
                    stat = "Active"
                Else
                    stat = "Deactivated"
                End If

                Dim est As String = "", dys As String = "", hrs As String = "", mins As String = ""
                If IsDBNull(dr("tym")) = False Then
                    Dim d = TimeSpan.FromMinutes(dr("tym"))
                    If d.Days = 1 Then
                        dys = d.Days & " day"
                    ElseIf d.Days > 1 Then
                        dys = d.Days & " days"
                    End If

                    If d.Hours = 1 Then
                        hrs = d.Hours & " hr"
                    ElseIf d.Hours > 1 Then
                        hrs = d.Hours & " hrs"
                    End If

                    If d.Minutes = 1 Then
                        mins = d.Minutes & " min"
                    ElseIf d.Minutes > 1 Then
                        mins = d.Minutes & " mins"
                    End If
                    est = Trim(dys & " " & hrs & " " & mins)
                End If

                grdcus2.Rows.Add(dr("id"), dr("poiid"), dr("poiname"), dr("address"), dr("distance"), est, dr("latitude"), dr("longitude"), stat)
            End While
            dr.Dispose()
            cmd.Dispose()
            conn.Close()

        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub txtpoi_TextChanged(sender As Object, e As EventArgs) Handles txtpoi.TextChanged

    End Sub

    Private Sub grdcus2_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdcus2.CellDoubleClick
        If e.RowIndex > -1 Then
            If frm = "mainmenucreate" Then
                mainmenucreate.cmbdestin.Text = grdcus2.Rows(grdcus2.CurrentRow.Index).Cells("poiname").Value
                mainmenucreate.cmbadd.Text = grdcus2.Rows(grdcus2.CurrentRow.Index).Cells("address").Value
                mainmenucreate.lblpoiid.Text = grdcus2.Rows(grdcus2.CurrentRow.Index).Cells("id").Value
                Me.Dispose()

            ElseIf frm = "pendingpoi" Then
                If grdcus2.Rows(grdcus2.CurrentRow.Index).Cells("distance").Value.ToString = "" Then
                    MsgBox("Update distance first.", MsgBoxStyle.Exclamation, "")
                Else
                    pendingpoiup.txtpoi.Text = grdcus2.Rows(grdcus2.CurrentRow.Index).Cells("poiname").Value
                    pendingpoiup.txtadd.Text = grdcus2.Rows(grdcus2.CurrentRow.Index).Cells("address").Value
                    Me.Dispose()
                End If

            ElseIf frm = "viewsteps" Then
                If grdcus2.Rows(grdcus2.CurrentRow.Index).Cells("distance").Value.ToString = "" Then
                    MsgBox("Update distance first.", MsgBoxStyle.Exclamation, "")
                Else
                    pendingpoiup.txtpoi.Text = grdcus2.Rows(grdcus2.CurrentRow.Index).Cells("poiname").Value
                    pendingpoiup.txtadd.Text = grdcus2.Rows(grdcus2.CurrentRow.Index).Cells("address").Value
                    Me.Dispose()
                End If
            End If
        End If
    End Sub

    Private Sub txtadd_TextChanged(sender As Object, e As EventArgs) Handles txtadd.TextChanged

    End Sub

    Private Sub txtpoi_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtpoi.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            If Trim(txtpoi.Text) <> "" Then
                btnsearch.PerformClick()
            End If
        End If
    End Sub

    Private Sub btnview_Click(sender As Object, e As EventArgs) Handles btnview.Click
        txtpoi.Text = ""
        txtadd.Text = ""
        load_customer2()
    End Sub

    Private Sub txtadd_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtadd.KeyPress
        If Asc(e.KeyChar) = 39 Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = Windows.Forms.Keys.Enter Then
            If Trim(txtadd.Text) <> "" Then
                btnsearch.PerformClick()
            End If
        End If
    End Sub

    Private Sub poiselect_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Me.Dispose()
    End Sub
End Class