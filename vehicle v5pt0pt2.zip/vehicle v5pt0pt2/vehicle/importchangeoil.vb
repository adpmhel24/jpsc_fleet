﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel

Public Class importchangeoil
    Dim SheetList As New ArrayList
    Dim MyConnection As OleDbConnection
    Dim DtSet As System.Data.DataSet
    Dim MyCommand As OleDbDataAdapter
    Dim ii As Integer
    Dim checkBoxColumn As New DataGridViewCheckBoxColumn()
    Dim ds As New DataSet
    Dim dv As DataView

    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String

    Dim derrors As Boolean = False, wzero As Boolean = False
    Public importcnf As Boolean = False

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub importchangeoil_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'DtSet.Clear()
        txtPath.Text = ""
        btnLoadData.Enabled = False
        btncheck.Enabled = False
        btnadd.Enabled = False
        'dgvdata.Rows.Clear()
        'DtSet.Clear()
        dgvdata.Columns.Clear()
    End Sub

    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        With OpenFileDialog1
            .FileName = "Excel File"
            .Filter = "Excel Worksheets|*.xls;*.xlsx"
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                txtPath.Text = .FileName
                If txtPath.Text <> "" Then
                    btnLoadData.Enabled = True
                    btncheck.Enabled = False
                    btnadd.Enabled = False
                Else
                    btnLoadData.Enabled = False
                End If
            End If
        End With
    End Sub

    Private Sub btnLoadData_Click(sender As Object, e As EventArgs) Handles btnLoadData.Click
        Try
            dgvdata.Columns.Clear()
            ' DtSet.Clear()
            Me.Cursor = Cursors.WaitCursor
            'x86 target cpu ---->  Microsoft.Jet.OLEDB.4.0
            'anycpu target cpu ---->  Microsoft.ACE.OLEDB.12.0
            MyConnection = New OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0;Data Source='" & txtPath.Text & "';Extended Properties=""Excel 8.0;HDR={1}""")

            Dim objExcel As Excel.Application
            Dim objWorkBook As Excel.Workbook
            Dim objWorkSheets As Excel.Worksheet
            Dim ExcelSheetName As String = ""

            objExcel = CreateObject("Excel.Application")
            objWorkBook = objExcel.Workbooks.Open(txtPath.Text)

            For Each objWorkSheets In objWorkBook.Worksheets
                SheetList.Add(objWorkSheets.Name)
            Next

            MyCommand = New OleDbDataAdapter("select * from [" & SheetList(0) & "$]", MyConnection)
            MyCommand.TableMappings.Add("Table", "Net-informations.com")
            'MsgBox(SheetList(0).ToString)
            DtSet = New System.Data.DataSet
            MyCommand.Fill(DtSet)
            dgvdata.DataSource = DtSet.Tables(0)
            ' MyCommand.Dispose()
            MyConnection.Close()

            objWorkBook.Close()
            objExcel.Quit()

            releaseObject(objWorkBook)
            releaseObject(objExcel)

            Me.Cursor = Cursors.Default

            dgvdata.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True
            'dgvdata.ColumnHeadersHeight = 40
            dgvdata.Columns(0).Width = 150
            dgvdata.Columns(1).Width = 150
            dgvdata.Columns(2).Width = 150
            dgvdata.Columns(3).Width = 150

            If dgvdata.Rows.Count <> 0 Then
                btncheck.Enabled = True
            Else
                btncheck.Enabled = False
            End If

            derrors = False

            btnadd.Enabled = False
            'remember: sa price kung nde sya numeric di sya iloload
            Me.Cursor = Cursors.Default
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " + ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub btncheck_Click(sender As Object, e As EventArgs) Handles btncheck.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If wzero = False Then
                'If dgvdata.ColumnCount = 9 Then
                dgvdata.Columns.Add(4, "Interval Mileage")
                dgvdata.Columns.Add(5, "Next Odometer Change Oil")
                dgvdata.Columns.Add(6, "ID")
                dgvdata.Columns(6).Visible = False

                checkplate()
                checkplnull()
                checkmiles()
            Else
                checkeditedmiles()
            End If

            If derrors = False Then
                If wzero = False Then
                    MsgBox("Click update button to continue.", MsgBoxStyle.Information, "")
                    btnadd.Enabled = True
                    btncheck.Enabled = False
                    dgvdata.ReadOnly = True
                Else
                    MsgBox("Error occurred. Please correct the highlighted errors and try again.", MsgBoxStyle.Critical, "")
                    btnadd.Enabled = False
                End If
            Else
                MsgBox("Error occurred. Please correct the highlighted errors and try again.", MsgBoxStyle.Critical, "")
                btnadd.Enabled = False
            End If
            'Else
            ' MsgBox("Invalid Columns.", MsgBoxStyle.Critical, "")
            'End If

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checkplnull()
        Try
            For Each row As DataGridViewRow In dgvdata.Rows
                'check if null yung tatlong platenum
                If dgvdata.Rows(row.Index).Cells(0).Value.ToString = "" Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(0).ToolTipText = "Plate number should not be null."
                    dgvdata.Rows(row.Index).Cells(0).Selected = True
                    dgvdata.Rows(row.Index).Cells(0).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                End If

                If IsDate(dgvdata.Rows(row.Index).Cells(1).Value) = False Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(1).ToolTipText = "Invalid date."
                    dgvdata.Rows(row.Index).Cells(1).Selected = True
                    dgvdata.Rows(row.Index).Cells(1).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                Else
                    If CDate(Format(dgvdata.Rows(row.Index).Cells(1).Value, "yyyy/MM/dd")) > CDate(Format(Date.Now, "yyyy/MM/dd")) Then
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(1).ToolTipText = "Invalid date."
                        dgvdata.Rows(row.Index).Cells(1).Selected = True
                        dgvdata.Rows(row.Index).Cells(1).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    End If
                End If

                If IsNumeric(dgvdata.Rows(row.Index).Cells(2).Value) = False Then
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(2).ToolTipText = "Invalid odometer."
                    dgvdata.Rows(row.Index).Cells(2).Selected = True
                    dgvdata.Rows(row.Index).Cells(2).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                    derrors = True
                Else
                    If Val(dgvdata.Rows(row.Index).Cells(2).Value) < 0 Then
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(2).ToolTipText = "Invalid odometer."
                        dgvdata.Rows(row.Index).Cells(2).Selected = True
                        dgvdata.Rows(row.Index).Cells(2).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    Else

                    End If
                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Public Sub checkplate()
        Try
            'check if category in the datagrid are in the tblcat

            'platenum

            For Each row As DataGridViewRow In dgvdata.Rows
                'check if there's no apostrophe
                If dgvdata.Rows(row.Index).Cells(0).Value.ToString.Contains("'") Then
                    dgvdata.Rows(row.Index).Cells(0).Value = dgvdata.Rows(row.Index).Cells(0).Value.ToString.Replace("'", "")
                End If

                Dim plnum As String = ""
                If dgvdata.Rows(row.Index).Cells(0).Value.ToString <> "" Then
                    plnum = dgvdata.Rows(row.Index).Cells(0).Value.ToString
                End If


                If plnum <> "" Then
                    sql = "Select genid, platenum from tblgeneral where platenum='" & plnum & "'"
                    connect()
                    cmd = New SqlCommand(sql, conn)
                    dr = cmd.ExecuteReader
                    If dr.Read Then
                        'gawing tooltip ung mga msgbox
                        'kc iibahin ko nlng ng background color ung cells na may error
                        dgvdata.Rows(row.Index).Cells(6).Value = dr("platenum")
                        dgvdata.Rows(row.Index).Cells(6).Value = dr("genid")
                    Else
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(0).ToolTipText = "Cannot found plate number " & dgvdata.Rows(row.Index).Cells(0).Value.ToString & "."
                        dgvdata.Rows(row.Index).Cells(0).Selected = True
                        dgvdata.Rows(row.Index).Cells(0).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                        derrors = True
                    End If
                    dr.Dispose()
                    cmd.Dispose()
                    conn.Close()

                    'Dim mls As Double
                    'If dgvdata.Rows(row.Index).Cells(6).Value = "FUSO 10WH" Then
                    '    mls = 25000
                    'Else
                    '    mls = 15000
                    'End If
                    'dgvdata.Rows(row.Index).Cells(4).Value = dgvdata.Rows(row.Index).Cells(2).Value + mls
                End If
            Next

        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub checkmiles()
        Try
            If login.svrlc = False Then
                Me.Cursor = Cursors.Default
                MsgBox("Can't connect to LC server.", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            wzero = False
            For Each row As DataGridViewRow In dgvdata.Rows
                If dgvdata.Rows(row.Index).Cells(0).Value <> "" Then
                    dgvdata.Rows(row.Index).Cells(4).Value = pms_miles(dgvdata.Rows(row.Index).Cells(0).Value)
                    compute_nextodo(row.Index)
                    If dgvdata.Rows(row.Index).Cells(4).Value = 0 Then
                        wzero = True
                        dgvdata.ClearSelection()
                        dgvdata.Rows(row.Index).Cells(4).ToolTipText = "No previous record. Edit invalid interval mileage."
                        dgvdata.Rows(row.Index).Cells(4).Selected = True
                        dgvdata.Rows(row.Index).Cells(4).Style.BackColor = Color.Yellow
                        dgvdata.ClearSelection()
                    End If
                End If
            Next

            If wzero = True Then
                dgvdata.ReadOnly = False
                dgvdata.Columns(0).ReadOnly = True
                dgvdata.Columns(1).ReadOnly = True
                dgvdata.Columns(2).ReadOnly = True
                dgvdata.Columns(3).ReadOnly = True
                dgvdata.Columns(5).ReadOnly = True
                dgvdata.Columns(6).ReadOnly = True
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally

        End Try
    End Sub

    Private Sub checkeditedmiles()
        For Each row As DataGridViewRow In dgvdata.Rows
            If Trim(dgvdata.Rows(row.Index).Cells(4).Value) <> "" Then
                If IsNumeric(dgvdata.Rows(row.Index).Cells(4).Value) = False Then
                    wzero = True
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(4).ToolTipText = "Edit invalid interval mileage."
                    dgvdata.Rows(row.Index).Cells(4).Selected = True
                    dgvdata.Rows(row.Index).Cells(4).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                ElseIf Val(dgvdata.Rows(row.Index).Cells(4).Value) <= 0 Then
                    wzero = True
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(4).ToolTipText = "Edit invalid interval mileage."
                    dgvdata.Rows(row.Index).Cells(4).Selected = True
                    dgvdata.Rows(row.Index).Cells(4).Style.BackColor = Color.Yellow
                    dgvdata.ClearSelection()
                Else
                    wzero = False
                    compute_nextodo(row.Index)
                    dgvdata.ClearSelection()
                    dgvdata.Rows(row.Index).Cells(4).ToolTipText = ""
                    dgvdata.Rows(row.Index).Cells(4).Selected = True
                    dgvdata.Rows(row.Index).Cells(4).Style.BackColor = Color.White
                    dgvdata.ClearSelection()
                End If
            Else
                wzero = True
                dgvdata.ClearSelection()
                dgvdata.Rows(row.Index).Cells(4).ToolTipText = "Edit invalid interval mileage."
                dgvdata.Rows(row.Index).Cells(4).Selected = True
                dgvdata.Rows(row.Index).Cells(4).Style.BackColor = Color.Yellow
                dgvdata.ClearSelection()
            End If
        Next
    End Sub

    Private Sub compute_nextodo(ByVal ndex As Integer)
        dgvdata.Rows(ndex).Cells(5).Value = dgvdata.Rows(ndex).Cells(2).Value + dgvdata.Rows(ndex).Cells(4).Value
    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Try
            If login.neym <> "Administrator" And login.neym <> "Supervisor" And login.neym <> "Logistics Staff" Then
                MsgBox("Access denied!", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            If login.svrlc = False Then
                Me.Cursor = Cursors.Default
                MsgBox("Can't connect to LC server.", MsgBoxStyle.Critical, "")
                Exit Sub
            End If

            importcnf = False
            If derrors = False Then
                confirmsave.GroupBox1.Text = login.neym
                confirmsave.ShowDialog()
                If importcnf = True Then
                    For Each row As DataGridViewRow In dgvdata.Rows
                        Dim iplate As String = dgvdata.Rows(row.Index).Cells(0).Value.ToString
                        Dim idate As Date = dgvdata.Rows(row.Index).Cells(1).Value
                        Dim ilastodo As Double = dgvdata.Rows(row.Index).Cells(2).Value
                        Dim irems As String = dgvdata.Rows(row.Index).Cells(3).Value.ToString.Replace("'", "")
                        Dim imls As Double = dgvdata.Rows(row.Index).Cells(4).Value
                        Dim inextodo As Double = dgvdata.Rows(row.Index).Cells(5).Value
                        Dim igenid As Integer = dgvdata.Rows(row.Index).Cells(6).Value

                        Dim added As Boolean = pms_add(igenid, iplate, "Change Oil", idate, login.whse, imls, ilastodo, inextodo, irems)
                        If added = True Then

                        End If
                    Next
                    MsgBox("Successfully Updated.", MsgBoxStyle.Information, "")
                    Me.Close()
                End If
            End If
        Catch ex As System.InvalidOperationException
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        Catch ex As Exception
            Me.Cursor = Cursors.Default
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, MsgBoxStyle.Information)
        Finally
            disconnect()
        End Try
    End Sub

    Private Sub importchangeoil_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If DtSet IsNot Nothing Then
            DtSet.Clear()
        End If
        dgvdata.Columns.Clear()
    End Sub
End Class