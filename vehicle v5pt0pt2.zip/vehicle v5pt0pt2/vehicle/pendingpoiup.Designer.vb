﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class pendingpoiup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(pendingpoiup))
        Me.lbltrip = New System.Windows.Forms.Label()
        Me.lblplate = New System.Windows.Forms.Label()
        Me.lbltrans = New System.Windows.Forms.Label()
        Me.lblcus = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnok = New System.Windows.Forms.Button()
        Me.txtpoi = New System.Windows.Forms.TextBox()
        Me.txtadd = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lbltrip
        '
        Me.lbltrip.AutoSize = True
        Me.lbltrip.Location = New System.Drawing.Point(12, 9)
        Me.lbltrip.Name = "lbltrip"
        Me.lbltrip.Size = New System.Drawing.Size(0, 13)
        Me.lbltrip.TabIndex = 0
        '
        'lblplate
        '
        Me.lblplate.AutoSize = True
        Me.lblplate.Location = New System.Drawing.Point(199, 9)
        Me.lblplate.Name = "lblplate"
        Me.lblplate.Size = New System.Drawing.Size(0, 13)
        Me.lblplate.TabIndex = 1
        '
        'lbltrans
        '
        Me.lbltrans.AutoSize = True
        Me.lbltrans.Location = New System.Drawing.Point(12, 33)
        Me.lbltrans.Name = "lbltrans"
        Me.lbltrans.Size = New System.Drawing.Size(0, 13)
        Me.lbltrans.TabIndex = 2
        '
        'lblcus
        '
        Me.lblcus.AutoSize = True
        Me.lblcus.Location = New System.Drawing.Point(199, 33)
        Me.lblcus.Name = "lblcus"
        Me.lblcus.Size = New System.Drawing.Size(0, 13)
        Me.lblcus.TabIndex = 3
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(6, 96)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(34, 14)
        Me.Label12.TabIndex = 52
        Me.Label12.Text = "Addr:"
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.Label11.Location = New System.Drawing.Point(6, 63)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(30, 30)
        Me.Label11.TabIndex = 51
        Me.Label11.Text = "Drop Off:"
        '
        'btnok
        '
        Me.btnok.BackColor = System.Drawing.Color.Gainsboro
        Me.btnok.Image = CType(resources.GetObject("btnok.Image"), System.Drawing.Image)
        Me.btnok.Location = New System.Drawing.Point(258, 153)
        Me.btnok.Name = "btnok"
        Me.btnok.Size = New System.Drawing.Size(75, 23)
        Me.btnok.TabIndex = 53
        Me.btnok.Text = "Ok"
        Me.btnok.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnok.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnok.UseVisualStyleBackColor = False
        '
        'txtpoi
        '
        Me.txtpoi.BackColor = System.Drawing.Color.White
        Me.txtpoi.Location = New System.Drawing.Point(42, 63)
        Me.txtpoi.Name = "txtpoi"
        Me.txtpoi.ReadOnly = True
        Me.txtpoi.Size = New System.Drawing.Size(291, 20)
        Me.txtpoi.TabIndex = 54
        '
        'txtadd
        '
        Me.txtadd.BackColor = System.Drawing.Color.White
        Me.txtadd.Location = New System.Drawing.Point(42, 93)
        Me.txtadd.Multiline = True
        Me.txtadd.Name = "txtadd"
        Me.txtadd.ReadOnly = True
        Me.txtadd.Size = New System.Drawing.Size(291, 51)
        Me.txtadd.TabIndex = 55
        '
        'pendingpoiup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(345, 185)
        Me.Controls.Add(Me.txtadd)
        Me.Controls.Add(Me.txtpoi)
        Me.Controls.Add(Me.btnok)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.lblcus)
        Me.Controls.Add(Me.lbltrans)
        Me.Controls.Add(Me.lblplate)
        Me.Controls.Add(Me.lbltrip)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "pendingpoiup"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GPS POI"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbltrip As Label
    Friend WithEvents lblplate As Label
    Friend WithEvents lbltrans As Label
    Friend WithEvents lblcus As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents btnok As Button
    Friend WithEvents txtpoi As TextBox
    Friend WithEvents txtadd As TextBox
End Class
