﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class customeraddress
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(customeraddress))
        Me.lblcusid = New System.Windows.Forms.Label()
        Me.lblcus = New System.Windows.Forms.Label()
        Me.grdcus2 = New System.Windows.Forms.DataGridView()
        Me.txtaddress = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btndeactivate = New System.Windows.Forms.Button()
        Me.btncancel = New System.Windows.Forms.Button()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.lblpoiid = New System.Windows.Forms.Label()
        Me.btnimport = New System.Windows.Forms.Button()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.UpdateGPSPOIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.poiid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.poiname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.address = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.distance = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tym = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lng = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.status = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.grdcus2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblcusid
        '
        Me.lblcusid.AutoSize = True
        Me.lblcusid.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.lblcusid.Location = New System.Drawing.Point(506, 11)
        Me.lblcusid.Name = "lblcusid"
        Me.lblcusid.Size = New System.Drawing.Size(0, 15)
        Me.lblcusid.TabIndex = 0
        Me.lblcusid.Visible = False
        '
        'lblcus
        '
        Me.lblcus.AutoSize = True
        Me.lblcus.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.lblcus.Location = New System.Drawing.Point(116, 11)
        Me.lblcus.Name = "lblcus"
        Me.lblcus.Size = New System.Drawing.Size(0, 15)
        Me.lblcus.TabIndex = 1
        '
        'grdcus2
        '
        Me.grdcus2.AllowUserToAddRows = False
        Me.grdcus2.AllowUserToDeleteRows = False
        Me.grdcus2.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        Me.grdcus2.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdcus2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdcus2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.grdcus2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdcus2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.grdcus2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdcus2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.id, Me.poiid, Me.poiname, Me.address, Me.distance, Me.tym, Me.lat, Me.lng, Me.status})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdcus2.DefaultCellStyle = DataGridViewCellStyle3
        Me.grdcus2.EnableHeadersVisualStyles = False
        Me.grdcus2.GridColor = System.Drawing.Color.Salmon
        Me.grdcus2.Location = New System.Drawing.Point(15, 147)
        Me.grdcus2.Name = "grdcus2"
        Me.grdcus2.ReadOnly = True
        Me.grdcus2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdcus2.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.grdcus2.RowHeadersWidth = 10
        Me.grdcus2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.grdcus2.Size = New System.Drawing.Size(895, 311)
        Me.grdcus2.TabIndex = 12
        '
        'txtaddress
        '
        Me.txtaddress.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaddress.Location = New System.Drawing.Point(85, 58)
        Me.txtaddress.Margin = New System.Windows.Forms.Padding(3, 5, 3, 5)
        Me.txtaddress.Multiline = True
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.ReadOnly = True
        Me.txtaddress.Size = New System.Drawing.Size(517, 48)
        Me.txtaddress.TabIndex = 46
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 15)
        Me.Label1.TabIndex = 48
        Me.Label1.Text = "Address:"
        '
        'txtname
        '
        Me.txtname.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname.Location = New System.Drawing.Point(85, 32)
        Me.txtname.Margin = New System.Windows.Forms.Padding(3, 5, 3, 5)
        Me.txtname.MaxLength = 200
        Me.txtname.Name = "txtname"
        Me.txtname.ReadOnly = True
        Me.txtname.Size = New System.Drawing.Size(479, 21)
        Me.txtname.TabIndex = 45
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 35)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 15)
        Me.Label2.TabIndex = 47
        Me.Label2.Text = "POI Name:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 11)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 15)
        Me.Label3.TabIndex = 49
        Me.Label3.Text = "Customer Code:"
        '
        'btndeactivate
        '
        Me.btndeactivate.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndeactivate.Image = CType(resources.GetObject("btndeactivate.Image"), System.Drawing.Image)
        Me.btndeactivate.Location = New System.Drawing.Point(210, 114)
        Me.btndeactivate.Name = "btndeactivate"
        Me.btndeactivate.Size = New System.Drawing.Size(119, 27)
        Me.btndeactivate.TabIndex = 52
        Me.btndeactivate.Text = "&Deactivate"
        Me.btndeactivate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btndeactivate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btndeactivate.UseVisualStyleBackColor = True
        '
        'btncancel
        '
        Me.btncancel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.Image = CType(resources.GetObject("btncancel.Image"), System.Drawing.Image)
        Me.btncancel.Location = New System.Drawing.Point(335, 114)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(119, 27)
        Me.btncancel.TabIndex = 53
        Me.btncancel.Text = "&Clear"
        Me.btncancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'btnadd
        '
        Me.btnadd.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Image = CType(resources.GetObject("btnadd.Image"), System.Drawing.Image)
        Me.btnadd.Location = New System.Drawing.Point(85, 114)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(119, 27)
        Me.btnadd.TabIndex = 50
        Me.btnadd.Text = "&Add"
        Me.btnadd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnadd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'btnsearch
        '
        Me.btnsearch.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsearch.Location = New System.Drawing.Point(570, 29)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(32, 27)
        Me.btnsearch.TabIndex = 56
        Me.btnsearch.Text = ". . ."
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'lblpoiid
        '
        Me.lblpoiid.AutoSize = True
        Me.lblpoiid.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpoiid.Location = New System.Drawing.Point(13, 91)
        Me.lblpoiid.Name = "lblpoiid"
        Me.lblpoiid.Size = New System.Drawing.Size(41, 15)
        Me.lblpoiid.TabIndex = 57
        Me.lblpoiid.Text = "POI ID"
        '
        'btnimport
        '
        Me.btnimport.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimport.Image = CType(resources.GetObject("btnimport.Image"), System.Drawing.Image)
        Me.btnimport.Location = New System.Drawing.Point(460, 114)
        Me.btnimport.Name = "btnimport"
        Me.btnimport.Size = New System.Drawing.Size(119, 27)
        Me.btnimport.TabIndex = 58
        Me.btnimport.Text = "&Import"
        Me.btnimport.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimport.UseVisualStyleBackColor = True
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UpdateGPSPOIToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(113, 26)
        '
        'UpdateGPSPOIToolStripMenuItem
        '
        Me.UpdateGPSPOIToolStripMenuItem.Image = CType(resources.GetObject("UpdateGPSPOIToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UpdateGPSPOIToolStripMenuItem.Name = "UpdateGPSPOIToolStripMenuItem"
        Me.UpdateGPSPOIToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.UpdateGPSPOIToolStripMenuItem.Text = "Update"
        '
        'id
        '
        Me.id.HeaderText = "ID"
        Me.id.Name = "id"
        Me.id.ReadOnly = True
        Me.id.Width = 80
        '
        'poiid
        '
        Me.poiid.HeaderText = "POI ID"
        Me.poiid.Name = "poiid"
        Me.poiid.ReadOnly = True
        Me.poiid.Width = 80
        '
        'poiname
        '
        Me.poiname.HeaderText = "Name"
        Me.poiname.MinimumWidth = 200
        Me.poiname.Name = "poiname"
        Me.poiname.ReadOnly = True
        Me.poiname.Width = 200
        '
        'address
        '
        Me.address.HeaderText = "Address"
        Me.address.MinimumWidth = 10
        Me.address.Name = "address"
        Me.address.ReadOnly = True
        Me.address.Width = 300
        '
        'distance
        '
        Me.distance.HeaderText = "Standard Distance (Km)"
        Me.distance.Name = "distance"
        Me.distance.ReadOnly = True
        Me.distance.Width = 120
        '
        'tym
        '
        Me.tym.HeaderText = "Travel Time"
        Me.tym.Name = "tym"
        Me.tym.ReadOnly = True
        '
        'lat
        '
        Me.lat.HeaderText = "Latitude"
        Me.lat.Name = "lat"
        Me.lat.ReadOnly = True
        '
        'lng
        '
        Me.lng.HeaderText = "Longitude"
        Me.lng.Name = "lng"
        Me.lng.ReadOnly = True
        '
        'status
        '
        Me.status.HeaderText = "Status"
        Me.status.Name = "status"
        Me.status.ReadOnly = True
        '
        'customeraddress
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(922, 470)
        Me.Controls.Add(Me.btnimport)
        Me.Controls.Add(Me.lblpoiid)
        Me.Controls.Add(Me.btnsearch)
        Me.Controls.Add(Me.btndeactivate)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtaddress)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.grdcus2)
        Me.Controls.Add(Me.lblcus)
        Me.Controls.Add(Me.lblcusid)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "customeraddress"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GPS POI Address"
        CType(Me.grdcus2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblcusid As Label
    Friend WithEvents lblcus As Label
    Friend WithEvents grdcus2 As DataGridView
    Friend WithEvents txtaddress As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtname As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btndeactivate As Button
    Friend WithEvents btncancel As Button
    Friend WithEvents btnadd As Button
    Friend WithEvents btnsearch As Button
    Friend WithEvents lblpoiid As Label
    Friend WithEvents btnimport As Button
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents UpdateGPSPOIToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents id As DataGridViewTextBoxColumn
    Friend WithEvents poiid As DataGridViewTextBoxColumn
    Friend WithEvents poiname As DataGridViewTextBoxColumn
    Friend WithEvents address As DataGridViewTextBoxColumn
    Friend WithEvents distance As DataGridViewTextBoxColumn
    Friend WithEvents tym As DataGridViewTextBoxColumn
    Friend WithEvents lat As DataGridViewTextBoxColumn
    Friend WithEvents lng As DataGridViewTextBoxColumn
    Friend WithEvents status As DataGridViewTextBoxColumn
End Class
