﻿Public Class assessemp
    Private Sub assessemp_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class