﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class newdriver
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(newdriver))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnimport = New System.Windows.Forms.Button()
        Me.btncanceladd = New System.Windows.Forms.Button()
        Me.btnvadd = New System.Windows.Forms.Button()
        Me.btnvdeac = New System.Windows.Forms.Button()
        Me.grddriver = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lbllastsearch = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.lblselect = New System.Windows.Forms.Label()
        Me.chkdeac = New System.Windows.Forms.CheckBox()
        Me.btnrefresh = New System.Windows.Forms.Button()
        Me.btncancelfilter = New System.Windows.Forms.Button()
        Me.txtsearch = New System.Windows.Forms.TextBox()
        Me.btnok = New System.Windows.Forms.Button()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.cmbcompsch = New System.Windows.Forms.ComboBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbwhsesch = New System.Windows.Forms.ComboBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tab1 = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblprimary = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.imgphoto = New System.Windows.Forms.PictureBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.cmbcompany = New System.Windows.Forms.ComboBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.cmbwhse = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.datebirth = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtcontact = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtlicense = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtdriver = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblid = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.btncancelupdate = New System.Windows.Forms.Button()
        Me.lbldreason = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.listbox = New System.Windows.Forms.ListBox()
        Me.btnupdriver = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtrems = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.tab2 = New System.Windows.Forms.TabPage()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.lblexp = New System.Windows.Forms.Label()
        Me.chkuse = New System.Windows.Forms.CheckBox()
        Me.btnremovedoc = New System.Windows.Forms.Button()
        Me.lbldocid = New System.Windows.Forms.Label()
        Me.cmbinterval = New System.Windows.Forms.ComboBox()
        Me.num = New System.Windows.Forms.NumericUpDown()
        Me.dateexpired = New System.Windows.Forms.DateTimePicker()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.btnadddoc = New System.Windows.Forms.Button()
        Me.cmbdocname = New System.Windows.Forms.ComboBox()
        Me.btnattach = New System.Windows.Forms.Button()
        Me.datelastrenew = New System.Windows.Forms.DateTimePicker()
        Me.txtattachname = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.grddoc = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewLinkColumn()
        Me.btncanceldoc = New System.Windows.Forms.Button()
        Me.btnviewalldoc = New System.Windows.Forms.Button()
        Me.btnupdatedoc = New System.Windows.Forms.Button()
        Me.tab4 = New System.Windows.Forms.TabPage()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.btnimgdl = New System.Windows.Forms.Button()
        Me.lblimgid = New System.Windows.Forms.Label()
        Me.btnimgset = New System.Windows.Forms.Button()
        Me.btnimgfull = New System.Windows.Forms.Button()
        Me.btnimgupdate = New System.Windows.Forms.Button()
        Me.txtimg = New System.Windows.Forms.TextBox()
        Me.imgpanel = New System.Windows.Forms.Panel()
        Me.imgbox = New System.Windows.Forms.PictureBox()
        Me.btnimgremove = New System.Windows.Forms.Button()
        Me.btnimgadd = New System.Windows.Forms.Button()
        Me.btnimgcancel = New System.Windows.Forms.Button()
        Me.btnimgrefresh = New System.Windows.Forms.Button()
        Me.btnimgrename = New System.Windows.Forms.Button()
        Me.lbldriverbig = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmbtype = New System.Windows.Forms.ComboBox()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.grddriver, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.tab1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.imgphoto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.tab2.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.num, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grddoc, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab4.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        CType(Me.imgbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.AutoScroll = True
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(2, 3)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(466, 656)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.btnimport)
        Me.Panel1.Controls.Add(Me.btncanceladd)
        Me.Panel1.Controls.Add(Me.btnvadd)
        Me.Panel1.Controls.Add(Me.btnvdeac)
        Me.Panel1.Controls.Add(Me.grddriver)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(456, 650)
        Me.Panel1.TabIndex = 0
        '
        'btnimport
        '
        Me.btnimport.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnimport.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimport.Image = CType(resources.GetObject("btnimport.Image"), System.Drawing.Image)
        Me.btnimport.Location = New System.Drawing.Point(3, 612)
        Me.btnimport.Name = "btnimport"
        Me.btnimport.Size = New System.Drawing.Size(112, 27)
        Me.btnimport.TabIndex = 39
        Me.btnimport.Text = "&Import Driver"
        Me.btnimport.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimport.UseVisualStyleBackColor = True
        '
        'btncanceladd
        '
        Me.btncanceladd.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncanceladd.Enabled = False
        Me.btncanceladd.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncanceladd.Image = CType(resources.GetObject("btncanceladd.Image"), System.Drawing.Image)
        Me.btncanceladd.Location = New System.Drawing.Point(343, 610)
        Me.btncanceladd.Name = "btncanceladd"
        Me.btncanceladd.Size = New System.Drawing.Size(105, 30)
        Me.btncanceladd.TabIndex = 27
        Me.btncanceladd.Text = "Cancel"
        Me.btncanceladd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncanceladd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncanceladd.UseVisualStyleBackColor = True
        '
        'btnvadd
        '
        Me.btnvadd.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnvadd.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnvadd.Image = CType(resources.GetObject("btnvadd.Image"), System.Drawing.Image)
        Me.btnvadd.Location = New System.Drawing.Point(121, 610)
        Me.btnvadd.Name = "btnvadd"
        Me.btnvadd.Size = New System.Drawing.Size(105, 30)
        Me.btnvadd.TabIndex = 25
        Me.btnvadd.Text = "Add Driver"
        Me.btnvadd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnvadd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnvadd.UseVisualStyleBackColor = True
        '
        'btnvdeac
        '
        Me.btnvdeac.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnvdeac.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnvdeac.Image = CType(resources.GetObject("btnvdeac.Image"), System.Drawing.Image)
        Me.btnvdeac.Location = New System.Drawing.Point(232, 610)
        Me.btnvdeac.Name = "btnvdeac"
        Me.btnvdeac.Size = New System.Drawing.Size(105, 30)
        Me.btnvdeac.TabIndex = 26
        Me.btnvdeac.Text = "Deactivate"
        Me.btnvdeac.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnvdeac.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnvdeac.UseVisualStyleBackColor = True
        '
        'grddriver
        '
        Me.grddriver.AllowUserToAddRows = False
        Me.grddriver.AllowUserToDeleteRows = False
        Me.grddriver.AllowUserToResizeRows = False
        Me.grddriver.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grddriver.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grddriver.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddriver.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grddriver.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grddriver.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.Column1, Me.Column5})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddriver.DefaultCellStyle = DataGridViewCellStyle2
        Me.grddriver.Location = New System.Drawing.Point(3, 198)
        Me.grddriver.MultiSelect = False
        Me.grddriver.Name = "grddriver"
        Me.grddriver.ReadOnly = True
        Me.grddriver.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddriver.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.grddriver.RowHeadersWidth = 10
        Me.grddriver.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddriver.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.grddriver.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grddriver.Size = New System.Drawing.Size(450, 406)
        Me.grddriver.TabIndex = 6
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.HeaderText = "id"
        Me.DataGridViewTextBoxColumn13.MinimumWidth = 190
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        Me.DataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn13.Visible = False
        Me.DataGridViewTextBoxColumn13.Width = 190
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.HeaderText = "Driver Name"
        Me.DataGridViewTextBoxColumn14.MinimumWidth = 150
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        Me.DataGridViewTextBoxColumn14.Width = 150
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.HeaderText = "License #"
        Me.DataGridViewTextBoxColumn15.MinimumWidth = 130
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        Me.DataGridViewTextBoxColumn15.Width = 130
        '
        'Column1
        '
        Me.Column1.HeaderText = "Notifications"
        Me.Column1.MinimumWidth = 120
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 120
        '
        'Column5
        '
        Me.Column5.HeaderText = "Status"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.lbllastsearch)
        Me.GroupBox1.Controls.Add(Me.Label48)
        Me.GroupBox1.Controls.Add(Me.lblselect)
        Me.GroupBox1.Controls.Add(Me.chkdeac)
        Me.GroupBox1.Controls.Add(Me.btnrefresh)
        Me.GroupBox1.Controls.Add(Me.btncancelfilter)
        Me.GroupBox1.Controls.Add(Me.txtsearch)
        Me.GroupBox1.Controls.Add(Me.btnok)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Controls.Add(Me.cmbcompsch)
        Me.GroupBox1.Controls.Add(Me.Label33)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.cmbwhsesch)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(450, 186)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Search Manage"
        '
        'lbllastsearch
        '
        Me.lbllastsearch.AutoSize = True
        Me.lbllastsearch.Location = New System.Drawing.Point(7, 136)
        Me.lbllastsearch.Name = "lbllastsearch"
        Me.lbllastsearch.Size = New System.Drawing.Size(24, 15)
        Me.lbllastsearch.TabIndex = 38
        Me.lbllastsearch.Text = "sql"
        Me.lbllastsearch.Visible = False
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(6, 157)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(42, 15)
        Me.Label48.TabIndex = 37
        Me.Label48.Text = "Whse:"
        '
        'lblselect
        '
        Me.lblselect.AutoSize = True
        Me.lblselect.Location = New System.Drawing.Point(49, 157)
        Me.lblselect.Name = "lblselect"
        Me.lblselect.Size = New System.Drawing.Size(0, 15)
        Me.lblselect.TabIndex = 36
        '
        'chkdeac
        '
        Me.chkdeac.AutoSize = True
        Me.chkdeac.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkdeac.ForeColor = System.Drawing.Color.OrangeRed
        Me.chkdeac.Location = New System.Drawing.Point(273, 117)
        Me.chkdeac.Name = "chkdeac"
        Me.chkdeac.Size = New System.Drawing.Size(126, 16)
        Me.chkdeac.TabIndex = 3
        Me.chkdeac.Text = "View Deactivated Driver"
        Me.chkdeac.UseVisualStyleBackColor = True
        '
        'btnrefresh
        '
        Me.btnrefresh.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefresh.Image = CType(resources.GetObject("btnrefresh.Image"), System.Drawing.Image)
        Me.btnrefresh.Location = New System.Drawing.Point(314, 147)
        Me.btnrefresh.Name = "btnrefresh"
        Me.btnrefresh.Size = New System.Drawing.Size(94, 23)
        Me.btnrefresh.TabIndex = 5
        Me.btnrefresh.Text = "Refresh"
        Me.btnrefresh.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnrefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnrefresh.UseVisualStyleBackColor = True
        '
        'btncancelfilter
        '
        Me.btncancelfilter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancelfilter.Image = CType(resources.GetObject("btncancelfilter.Image"), System.Drawing.Image)
        Me.btncancelfilter.Location = New System.Drawing.Point(376, 81)
        Me.btncancelfilter.Name = "btncancelfilter"
        Me.btncancelfilter.Size = New System.Drawing.Size(33, 23)
        Me.btncancelfilter.TabIndex = 32
        Me.btncancelfilter.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancelfilter.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancelfilter.UseVisualStyleBackColor = True
        '
        'txtsearch
        '
        Me.txtsearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtsearch.Location = New System.Drawing.Point(193, 81)
        Me.txtsearch.Name = "txtsearch"
        Me.txtsearch.Size = New System.Drawing.Size(177, 21)
        Me.txtsearch.TabIndex = 0
        '
        'btnok
        '
        Me.btnok.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnok.Image = CType(resources.GetObject("btnok.Image"), System.Drawing.Image)
        Me.btnok.Location = New System.Drawing.Point(214, 147)
        Me.btnok.Name = "btnok"
        Me.btnok.Size = New System.Drawing.Size(94, 23)
        Me.btnok.TabIndex = 4
        Me.btnok.Text = "Ok"
        Me.btnok.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnok.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnok.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(108, 84)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(79, 15)
        Me.Label25.TabIndex = 35
        Me.Label25.Text = "Driver Name:"
        '
        'cmbcompsch
        '
        Me.cmbcompsch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcompsch.FormattingEnabled = True
        Me.cmbcompsch.Location = New System.Drawing.Point(193, 20)
        Me.cmbcompsch.Name = "cmbcompsch"
        Me.cmbcompsch.Size = New System.Drawing.Size(215, 23)
        Me.cmbcompsch.TabIndex = 2
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(69, 23)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(118, 15)
        Me.Label33.TabIndex = 29
        Me.Label33.Text = "Assigned Company:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(113, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 15)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Warehouse:"
        '
        'cmbwhsesch
        '
        Me.cmbwhsesch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbwhsesch.FormattingEnabled = True
        Me.cmbwhsesch.Location = New System.Drawing.Point(193, 50)
        Me.cmbwhsesch.Name = "cmbwhsesch"
        Me.cmbwhsesch.Size = New System.Drawing.Size(215, 23)
        Me.cmbwhsesch.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.AutoScroll = True
        Me.Panel2.Controls.Add(Me.TabControl1)
        Me.Panel2.Controls.Add(Me.lbldriverbig)
        Me.Panel2.Location = New System.Drawing.Point(467, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(864, 660)
        Me.Panel2.TabIndex = 1
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.tab1)
        Me.TabControl1.Controls.Add(Me.tab2)
        Me.TabControl1.Controls.Add(Me.tab4)
        Me.TabControl1.Location = New System.Drawing.Point(3, 75)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(858, 568)
        Me.TabControl1.TabIndex = 3
        '
        'tab1
        '
        Me.tab1.Controls.Add(Me.GroupBox2)
        Me.tab1.Controls.Add(Me.btncancelupdate)
        Me.tab1.Controls.Add(Me.lbldreason)
        Me.tab1.Controls.Add(Me.GroupBox3)
        Me.tab1.Controls.Add(Me.btnupdriver)
        Me.tab1.Controls.Add(Me.GroupBox4)
        Me.tab1.Controls.Add(Me.Label29)
        Me.tab1.Controls.Add(Me.Label27)
        Me.tab1.Location = New System.Drawing.Point(4, 24)
        Me.tab1.Name = "tab1"
        Me.tab1.Padding = New System.Windows.Forms.Padding(3)
        Me.tab1.Size = New System.Drawing.Size(850, 540)
        Me.tab1.TabIndex = 0
        Me.tab1.Text = "General"
        Me.tab1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.cmbtype)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.lblprimary)
        Me.GroupBox2.Controls.Add(Me.Label53)
        Me.GroupBox2.Controls.Add(Me.imgphoto)
        Me.GroupBox2.Controls.Add(Me.Label34)
        Me.GroupBox2.Controls.Add(Me.cmbcompany)
        Me.GroupBox2.Controls.Add(Me.Label31)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.cmbwhse)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.datebirth)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.txtcontact)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.txtlicense)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.txtdriver)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.lblid)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Location = New System.Drawing.Point(21, 15)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(723, 286)
        Me.GroupBox2.TabIndex = 37
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Identification"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(354, 143)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(18, 16)
        Me.Label6.TabIndex = 70
        Me.Label6.Text = "**"
        '
        'lblprimary
        '
        Me.lblprimary.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblprimary.AutoSize = True
        Me.lblprimary.Location = New System.Drawing.Point(582, 28)
        Me.lblprimary.Name = "lblprimary"
        Me.lblprimary.Size = New System.Drawing.Size(38, 15)
        Me.lblprimary.TabIndex = 69
        Me.lblprimary.Text = "imgid"
        Me.lblprimary.Visible = False
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(425, 30)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(42, 15)
        Me.Label53.TabIndex = 48
        Me.Label53.Text = "Photo:"
        Me.Label53.Visible = False
        '
        'imgphoto
        '
        Me.imgphoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgphoto.Location = New System.Drawing.Point(428, 49)
        Me.imgphoto.Name = "imgphoto"
        Me.imgphoto.Size = New System.Drawing.Size(258, 175)
        Me.imgphoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgphoto.TabIndex = 47
        Me.imgphoto.TabStop = False
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Red
        Me.Label34.Location = New System.Drawing.Point(354, 171)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(18, 16)
        Me.Label34.TabIndex = 46
        Me.Label34.Text = "**"
        '
        'cmbcompany
        '
        Me.cmbcompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcompany.FormattingEnabled = True
        Me.cmbcompany.Location = New System.Drawing.Point(143, 171)
        Me.cmbcompany.Name = "cmbcompany"
        Me.cmbcompany.Size = New System.Drawing.Size(200, 23)
        Me.cmbcompany.TabIndex = 42
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(25, 174)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(63, 15)
        Me.Label31.TabIndex = 45
        Me.Label31.Text = "Company:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Red
        Me.Label23.Location = New System.Drawing.Point(354, 204)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(18, 16)
        Me.Label23.TabIndex = 44
        Me.Label23.Text = "**"
        '
        'cmbwhse
        '
        Me.cmbwhse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbwhse.FormattingEnabled = True
        Me.cmbwhse.Location = New System.Drawing.Point(143, 204)
        Me.cmbwhse.Name = "cmbwhse"
        Me.cmbwhse.Size = New System.Drawing.Size(200, 23)
        Me.cmbwhse.TabIndex = 41
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(25, 208)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(74, 15)
        Me.Label10.TabIndex = 43
        Me.Label10.Text = "Warehouse:"
        '
        'datebirth
        '
        Me.datebirth.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datebirth.Location = New System.Drawing.Point(143, 141)
        Me.datebirth.Name = "datebirth"
        Me.datebirth.Size = New System.Drawing.Size(200, 21)
        Me.datebirth.TabIndex = 39
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(25, 146)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 15)
        Me.Label5.TabIndex = 38
        Me.Label5.Text = "Birthday:"
        '
        'txtcontact
        '
        Me.txtcontact.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtcontact.Location = New System.Drawing.Point(143, 110)
        Me.txtcontact.Name = "txtcontact"
        Me.txtcontact.Size = New System.Drawing.Size(200, 21)
        Me.txtcontact.TabIndex = 37
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(25, 84)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 15)
        Me.Label4.TabIndex = 36
        Me.Label4.Text = "License #:"
        '
        'txtlicense
        '
        Me.txtlicense.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtlicense.Location = New System.Drawing.Point(143, 81)
        Me.txtlicense.Name = "txtlicense"
        Me.txtlicense.Size = New System.Drawing.Size(200, 21)
        Me.txtlicense.TabIndex = 35
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(25, 113)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(62, 15)
        Me.Label3.TabIndex = 34
        Me.Label3.Text = "Contact #:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Red
        Me.Label9.Location = New System.Drawing.Point(354, 55)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(18, 16)
        Me.Label9.TabIndex = 33
        Me.Label9.Text = "**"
        '
        'txtdriver
        '
        Me.txtdriver.Location = New System.Drawing.Point(143, 52)
        Me.txtdriver.Name = "txtdriver"
        Me.txtdriver.Size = New System.Drawing.Size(200, 21)
        Me.txtdriver.TabIndex = 32
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 15)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "Driver Name:"
        '
        'lblid
        '
        Me.lblid.AutoSize = True
        Me.lblid.Location = New System.Drawing.Point(140, 30)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(0, 15)
        Me.lblid.TabIndex = 29
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(25, 30)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(62, 15)
        Me.Label22.TabIndex = 30
        Me.Label22.Text = "Entry ID #:"
        '
        'btncancelupdate
        '
        Me.btncancelupdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncancelupdate.Enabled = False
        Me.btncancelupdate.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancelupdate.Image = CType(resources.GetObject("btncancelupdate.Image"), System.Drawing.Image)
        Me.btncancelupdate.Location = New System.Drawing.Point(684, 494)
        Me.btncancelupdate.Name = "btncancelupdate"
        Me.btncancelupdate.Size = New System.Drawing.Size(90, 30)
        Me.btncancelupdate.TabIndex = 25
        Me.btncancelupdate.Text = "Cancel"
        Me.btncancelupdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncancelupdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncancelupdate.UseVisualStyleBackColor = True
        '
        'lbldreason
        '
        Me.lbldreason.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lbldreason.AutoSize = True
        Me.lbldreason.ForeColor = System.Drawing.Color.Red
        Me.lbldreason.Location = New System.Drawing.Point(171, 507)
        Me.lbldreason.Name = "lbldreason"
        Me.lbldreason.Size = New System.Drawing.Size(53, 15)
        Me.lbldreason.TabIndex = 36
        Me.lbldreason.Text = "dreason"
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.Controls.Add(Me.listbox)
        Me.GroupBox3.Location = New System.Drawing.Point(21, 339)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(372, 150)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Notifications"
        '
        'listbox
        '
        Me.listbox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.listbox.FormattingEnabled = True
        Me.listbox.ItemHeight = 15
        Me.listbox.Location = New System.Drawing.Point(28, 19)
        Me.listbox.Name = "listbox"
        Me.listbox.Size = New System.Drawing.Size(317, 109)
        Me.listbox.Sorted = True
        Me.listbox.TabIndex = 25
        '
        'btnupdriver
        '
        Me.btnupdriver.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnupdriver.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdriver.Image = CType(resources.GetObject("btnupdriver.Image"), System.Drawing.Image)
        Me.btnupdriver.Location = New System.Drawing.Point(586, 494)
        Me.btnupdriver.Name = "btnupdriver"
        Me.btnupdriver.Size = New System.Drawing.Size(90, 30)
        Me.btnupdriver.TabIndex = 27
        Me.btnupdriver.Text = "Update"
        Me.btnupdriver.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnupdriver.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnupdriver.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.Controls.Add(Me.txtrems)
        Me.GroupBox4.Location = New System.Drawing.Point(404, 339)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(340, 147)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Remarks"
        '
        'txtrems
        '
        Me.txtrems.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtrems.Location = New System.Drawing.Point(27, 24)
        Me.txtrems.Multiline = True
        Me.txtrems.Name = "txtrems"
        Me.txtrems.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtrems.Size = New System.Drawing.Size(297, 117)
        Me.txtrems.TabIndex = 26
        '
        'Label29
        '
        Me.Label29.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(35, 507)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(80, 14)
        Me.Label29.TabIndex = 35
        Me.Label29.Text = "- Reqiured field"
        '
        'Label27
        '
        Me.Label27.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.Red
        Me.Label27.Location = New System.Drawing.Point(20, 508)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(18, 16)
        Me.Label27.TabIndex = 34
        Me.Label27.Text = "**"
        '
        'tab2
        '
        Me.tab2.Controls.Add(Me.GroupBox6)
        Me.tab2.Location = New System.Drawing.Point(4, 24)
        Me.tab2.Name = "tab2"
        Me.tab2.Size = New System.Drawing.Size(850, 540)
        Me.tab2.TabIndex = 2
        Me.tab2.Text = "Documents"
        Me.tab2.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox6.Controls.Add(Me.lblexp)
        Me.GroupBox6.Controls.Add(Me.chkuse)
        Me.GroupBox6.Controls.Add(Me.btnremovedoc)
        Me.GroupBox6.Controls.Add(Me.lbldocid)
        Me.GroupBox6.Controls.Add(Me.cmbinterval)
        Me.GroupBox6.Controls.Add(Me.num)
        Me.GroupBox6.Controls.Add(Me.dateexpired)
        Me.GroupBox6.Controls.Add(Me.Label20)
        Me.GroupBox6.Controls.Add(Me.btnadddoc)
        Me.GroupBox6.Controls.Add(Me.cmbdocname)
        Me.GroupBox6.Controls.Add(Me.btnattach)
        Me.GroupBox6.Controls.Add(Me.datelastrenew)
        Me.GroupBox6.Controls.Add(Me.txtattachname)
        Me.GroupBox6.Controls.Add(Me.Label17)
        Me.GroupBox6.Controls.Add(Me.Label16)
        Me.GroupBox6.Controls.Add(Me.Label15)
        Me.GroupBox6.Controls.Add(Me.grddoc)
        Me.GroupBox6.Controls.Add(Me.btncanceldoc)
        Me.GroupBox6.Controls.Add(Me.btnviewalldoc)
        Me.GroupBox6.Controls.Add(Me.btnupdatedoc)
        Me.GroupBox6.Location = New System.Drawing.Point(19, 15)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(798, 529)
        Me.GroupBox6.TabIndex = 7
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Manage Document Expiration"
        '
        'lblexp
        '
        Me.lblexp.AutoSize = True
        Me.lblexp.Location = New System.Drawing.Point(438, 17)
        Me.lblexp.Name = "lblexp"
        Me.lblexp.Size = New System.Drawing.Size(26, 15)
        Me.lblexp.TabIndex = 40
        Me.lblexp.Text = "exp"
        Me.lblexp.Visible = False
        '
        'chkuse
        '
        Me.chkuse.AutoSize = True
        Me.chkuse.Checked = True
        Me.chkuse.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkuse.Location = New System.Drawing.Point(58, 95)
        Me.chkuse.Name = "chkuse"
        Me.chkuse.Size = New System.Drawing.Size(141, 19)
        Me.chkuse.TabIndex = 39
        Me.chkuse.Text = "Use Tracking Interval"
        Me.chkuse.UseVisualStyleBackColor = True
        '
        'btnremovedoc
        '
        Me.btnremovedoc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnremovedoc.Image = CType(resources.GetObject("btnremovedoc.Image"), System.Drawing.Image)
        Me.btnremovedoc.Location = New System.Drawing.Point(365, 179)
        Me.btnremovedoc.Name = "btnremovedoc"
        Me.btnremovedoc.Size = New System.Drawing.Size(101, 30)
        Me.btnremovedoc.TabIndex = 35
        Me.btnremovedoc.Text = "Remove"
        Me.btnremovedoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnremovedoc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnremovedoc.UseVisualStyleBackColor = True
        '
        'lbldocid
        '
        Me.lbldocid.AutoSize = True
        Me.lbldocid.Location = New System.Drawing.Point(219, 18)
        Me.lbldocid.Name = "lbldocid"
        Me.lbldocid.Size = New System.Drawing.Size(39, 15)
        Me.lbldocid.TabIndex = 38
        Me.lbldocid.Text = "Docid"
        Me.lbldocid.Visible = False
        '
        'cmbinterval
        '
        Me.cmbinterval.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbinterval.Enabled = False
        Me.cmbinterval.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmbinterval.FormattingEnabled = True
        Me.cmbinterval.Items.AddRange(New Object() {"", "Year(s)", "Month(s)", "Day(s)"})
        Me.cmbinterval.Location = New System.Drawing.Point(282, 91)
        Me.cmbinterval.Name = "cmbinterval"
        Me.cmbinterval.Size = New System.Drawing.Size(123, 23)
        Me.cmbinterval.TabIndex = 28
        '
        'num
        '
        Me.num.Enabled = False
        Me.num.Location = New System.Drawing.Point(222, 92)
        Me.num.Maximum = New Decimal(New Integer() {31, 0, 0, 0})
        Me.num.Name = "num"
        Me.num.Size = New System.Drawing.Size(54, 21)
        Me.num.TabIndex = 27
        '
        'dateexpired
        '
        Me.dateexpired.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dateexpired.Location = New System.Drawing.Point(222, 119)
        Me.dateexpired.Name = "dateexpired"
        Me.dateexpired.Size = New System.Drawing.Size(218, 21)
        Me.dateexpired.TabIndex = 29
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(55, 124)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(93, 15)
        Me.Label20.TabIndex = 26
        Me.Label20.Text = "Expiration Date:"
        '
        'btnadddoc
        '
        Me.btnadddoc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadddoc.Image = CType(resources.GetObject("btnadddoc.Image"), System.Drawing.Image)
        Me.btnadddoc.Location = New System.Drawing.Point(58, 179)
        Me.btnadddoc.Name = "btnadddoc"
        Me.btnadddoc.Size = New System.Drawing.Size(94, 30)
        Me.btnadddoc.TabIndex = 33
        Me.btnadddoc.Text = "Add"
        Me.btnadddoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnadddoc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnadddoc.UseVisualStyleBackColor = True
        '
        'cmbdocname
        '
        Me.cmbdocname.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbdocname.FormattingEnabled = True
        Me.cmbdocname.Location = New System.Drawing.Point(222, 36)
        Me.cmbdocname.Name = "cmbdocname"
        Me.cmbdocname.Size = New System.Drawing.Size(268, 23)
        Me.cmbdocname.TabIndex = 25
        '
        'btnattach
        '
        Me.btnattach.Location = New System.Drawing.Point(480, 145)
        Me.btnattach.Name = "btnattach"
        Me.btnattach.Size = New System.Drawing.Size(25, 23)
        Me.btnattach.TabIndex = 31
        Me.btnattach.Text = "..."
        Me.btnattach.UseVisualStyleBackColor = True
        Me.btnattach.Visible = False
        '
        'datelastrenew
        '
        Me.datelastrenew.CustomFormat = ""
        Me.datelastrenew.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.datelastrenew.Location = New System.Drawing.Point(222, 65)
        Me.datelastrenew.Name = "datelastrenew"
        Me.datelastrenew.Size = New System.Drawing.Size(218, 21)
        Me.datelastrenew.TabIndex = 26
        '
        'txtattachname
        '
        Me.txtattachname.Location = New System.Drawing.Point(222, 146)
        Me.txtattachname.Name = "txtattachname"
        Me.txtattachname.Size = New System.Drawing.Size(244, 21)
        Me.txtattachname.TabIndex = 30
        Me.txtattachname.Visible = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(55, 153)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(66, 15)
        Me.Label17.TabIndex = 18
        Me.Label17.Text = "Attach File:"
        Me.Label17.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(55, 70)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(115, 15)
        Me.Label16.TabIndex = 17
        Me.Label16.Text = "Last Renewal Date:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(55, 44)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(104, 15)
        Me.Label15.TabIndex = 16
        Me.Label15.Text = "Document Name:"
        '
        'grddoc
        '
        Me.grddoc.AllowUserToAddRows = False
        Me.grddoc.AllowUserToDeleteRows = False
        Me.grddoc.AllowUserToResizeRows = False
        Me.grddoc.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grddoc.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grddoc.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddoc.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.grddoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grddoc.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.Column4, Me.Column3, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.Column2})
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.NullValue = Nothing
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddoc.DefaultCellStyle = DataGridViewCellStyle6
        Me.grddoc.Location = New System.Drawing.Point(11, 223)
        Me.grddoc.MultiSelect = False
        Me.grddoc.Name = "grddoc"
        Me.grddoc.ReadOnly = True
        Me.grddoc.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddoc.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.grddoc.RowHeadersWidth = 10
        Me.grddoc.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grddoc.RowsDefaultCellStyle = DataGridViewCellStyle8
        Me.grddoc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grddoc.Size = New System.Drawing.Size(776, 288)
        Me.grddoc.TabIndex = 38
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "id"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 190
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn1.Visible = False
        Me.DataGridViewTextBoxColumn1.Width = 190
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Document Name"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 200
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 200
        '
        'Column4
        '
        Me.Column4.HeaderText = "Last Renewal Date"
        Me.Column4.MinimumWidth = 160
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Width = 160
        '
        'Column3
        '
        Me.Column3.HeaderText = "Tracking Interval"
        Me.Column3.MinimumWidth = 140
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 140
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "Expiration Date"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 140
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn3.Width = 140
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "Status"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 120
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Width = 120
        '
        'Column2
        '
        Me.Column2.HeaderText = "Attachment"
        Me.Column2.MinimumWidth = 150
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Visible = False
        Me.Column2.Width = 150
        '
        'btncanceldoc
        '
        Me.btncanceldoc.Enabled = False
        Me.btncanceldoc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncanceldoc.Image = CType(resources.GetObject("btncanceldoc.Image"), System.Drawing.Image)
        Me.btncanceldoc.Location = New System.Drawing.Point(265, 179)
        Me.btncanceldoc.Name = "btncanceldoc"
        Me.btncanceldoc.Size = New System.Drawing.Size(94, 30)
        Me.btncanceldoc.TabIndex = 36
        Me.btncanceldoc.Text = "Cancel"
        Me.btncanceldoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncanceldoc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncanceldoc.UseVisualStyleBackColor = True
        '
        'btnviewalldoc
        '
        Me.btnviewalldoc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnviewalldoc.Image = CType(resources.GetObject("btnviewalldoc.Image"), System.Drawing.Image)
        Me.btnviewalldoc.Location = New System.Drawing.Point(472, 179)
        Me.btnviewalldoc.Name = "btnviewalldoc"
        Me.btnviewalldoc.Size = New System.Drawing.Size(94, 30)
        Me.btnviewalldoc.TabIndex = 37
        Me.btnviewalldoc.Text = "View All"
        Me.btnviewalldoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnviewalldoc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnviewalldoc.UseVisualStyleBackColor = True
        '
        'btnupdatedoc
        '
        Me.btnupdatedoc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdatedoc.Image = CType(resources.GetObject("btnupdatedoc.Image"), System.Drawing.Image)
        Me.btnupdatedoc.Location = New System.Drawing.Point(158, 179)
        Me.btnupdatedoc.Name = "btnupdatedoc"
        Me.btnupdatedoc.Size = New System.Drawing.Size(101, 30)
        Me.btnupdatedoc.TabIndex = 34
        Me.btnupdatedoc.Text = "Update"
        Me.btnupdatedoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnupdatedoc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnupdatedoc.UseVisualStyleBackColor = True
        '
        'tab4
        '
        Me.tab4.Controls.Add(Me.GroupBox9)
        Me.tab4.Location = New System.Drawing.Point(4, 24)
        Me.tab4.Name = "tab4"
        Me.tab4.Size = New System.Drawing.Size(850, 540)
        Me.tab4.TabIndex = 6
        Me.tab4.Text = "Photo"
        Me.tab4.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox9.Controls.Add(Me.btnimgdl)
        Me.GroupBox9.Controls.Add(Me.lblimgid)
        Me.GroupBox9.Controls.Add(Me.btnimgset)
        Me.GroupBox9.Controls.Add(Me.btnimgfull)
        Me.GroupBox9.Controls.Add(Me.btnimgupdate)
        Me.GroupBox9.Controls.Add(Me.txtimg)
        Me.GroupBox9.Controls.Add(Me.imgpanel)
        Me.GroupBox9.Controls.Add(Me.imgbox)
        Me.GroupBox9.Controls.Add(Me.btnimgremove)
        Me.GroupBox9.Controls.Add(Me.btnimgadd)
        Me.GroupBox9.Controls.Add(Me.btnimgcancel)
        Me.GroupBox9.Controls.Add(Me.btnimgrefresh)
        Me.GroupBox9.Controls.Add(Me.btnimgrename)
        Me.GroupBox9.Location = New System.Drawing.Point(17, 5)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(818, 527)
        Me.GroupBox9.TabIndex = 0
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Photos"
        '
        'btnimgdl
        '
        Me.btnimgdl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgdl.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgdl.Image = CType(resources.GetObject("btnimgdl.Image"), System.Drawing.Image)
        Me.btnimgdl.Location = New System.Drawing.Point(576, 420)
        Me.btnimgdl.Name = "btnimgdl"
        Me.btnimgdl.Size = New System.Drawing.Size(208, 30)
        Me.btnimgdl.TabIndex = 64
        Me.btnimgdl.Text = "Download Photo"
        Me.btnimgdl.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgdl.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgdl.UseVisualStyleBackColor = True
        '
        'lblimgid
        '
        Me.lblimgid.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblimgid.AutoSize = True
        Me.lblimgid.Location = New System.Drawing.Point(536, 504)
        Me.lblimgid.Name = "lblimgid"
        Me.lblimgid.Size = New System.Drawing.Size(38, 15)
        Me.lblimgid.TabIndex = 68
        Me.lblimgid.Text = "imgid"
        Me.lblimgid.Visible = False
        '
        'btnimgset
        '
        Me.btnimgset.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgset.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgset.Image = CType(resources.GetObject("btnimgset.Image"), System.Drawing.Image)
        Me.btnimgset.Location = New System.Drawing.Point(576, 348)
        Me.btnimgset.Name = "btnimgset"
        Me.btnimgset.Size = New System.Drawing.Size(208, 30)
        Me.btnimgset.TabIndex = 62
        Me.btnimgset.Text = "Set as Primary Photo"
        Me.btnimgset.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgset.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgset.UseVisualStyleBackColor = True
        '
        'btnimgfull
        '
        Me.btnimgfull.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgfull.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgfull.Image = CType(resources.GetObject("btnimgfull.Image"), System.Drawing.Image)
        Me.btnimgfull.Location = New System.Drawing.Point(576, 456)
        Me.btnimgfull.Name = "btnimgfull"
        Me.btnimgfull.Size = New System.Drawing.Size(208, 30)
        Me.btnimgfull.TabIndex = 65
        Me.btnimgfull.Text = "View Larger"
        Me.btnimgfull.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgfull.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgfull.UseVisualStyleBackColor = True
        '
        'btnimgupdate
        '
        Me.btnimgupdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgupdate.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgupdate.Image = CType(resources.GetObject("btnimgupdate.Image"), System.Drawing.Image)
        Me.btnimgupdate.Location = New System.Drawing.Point(576, 384)
        Me.btnimgupdate.Name = "btnimgupdate"
        Me.btnimgupdate.Size = New System.Drawing.Size(208, 30)
        Me.btnimgupdate.TabIndex = 63
        Me.btnimgupdate.Text = "Update Photo"
        Me.btnimgupdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgupdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgupdate.UseVisualStyleBackColor = True
        '
        'txtimg
        '
        Me.txtimg.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtimg.BackColor = System.Drawing.Color.White
        Me.txtimg.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtimg.Location = New System.Drawing.Point(539, 248)
        Me.txtimg.Name = "txtimg"
        Me.txtimg.ReadOnly = True
        Me.txtimg.Size = New System.Drawing.Size(273, 22)
        Me.txtimg.TabIndex = 57
        '
        'imgpanel
        '
        Me.imgpanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.imgpanel.AutoScroll = True
        Me.imgpanel.BackColor = System.Drawing.SystemColors.Control
        Me.imgpanel.Location = New System.Drawing.Point(6, 20)
        Me.imgpanel.Name = "imgpanel"
        Me.imgpanel.Size = New System.Drawing.Size(527, 501)
        Me.imgpanel.TabIndex = 63
        '
        'imgbox
        '
        Me.imgbox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.imgbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgbox.Location = New System.Drawing.Point(539, 20)
        Me.imgbox.Name = "imgbox"
        Me.imgbox.Size = New System.Drawing.Size(273, 219)
        Me.imgbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgbox.TabIndex = 62
        Me.imgbox.TabStop = False
        '
        'btnimgremove
        '
        Me.btnimgremove.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgremove.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgremove.Image = CType(resources.GetObject("btnimgremove.Image"), System.Drawing.Image)
        Me.btnimgremove.Location = New System.Drawing.Point(576, 312)
        Me.btnimgremove.Name = "btnimgremove"
        Me.btnimgremove.Size = New System.Drawing.Size(101, 30)
        Me.btnimgremove.TabIndex = 60
        Me.btnimgremove.Text = "Remove"
        Me.btnimgremove.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgremove.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgremove.UseVisualStyleBackColor = True
        '
        'btnimgadd
        '
        Me.btnimgadd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgadd.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgadd.Image = CType(resources.GetObject("btnimgadd.Image"), System.Drawing.Image)
        Me.btnimgadd.Location = New System.Drawing.Point(576, 276)
        Me.btnimgadd.Name = "btnimgadd"
        Me.btnimgadd.Size = New System.Drawing.Size(101, 30)
        Me.btnimgadd.TabIndex = 58
        Me.btnimgadd.Text = "Add Photo"
        Me.btnimgadd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgadd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgadd.UseVisualStyleBackColor = True
        '
        'btnimgcancel
        '
        Me.btnimgcancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgcancel.Enabled = False
        Me.btnimgcancel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgcancel.Image = CType(resources.GetObject("btnimgcancel.Image"), System.Drawing.Image)
        Me.btnimgcancel.Location = New System.Drawing.Point(683, 312)
        Me.btnimgcancel.Name = "btnimgcancel"
        Me.btnimgcancel.Size = New System.Drawing.Size(101, 30)
        Me.btnimgcancel.TabIndex = 61
        Me.btnimgcancel.Text = "Cancel"
        Me.btnimgcancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgcancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgcancel.UseVisualStyleBackColor = True
        '
        'btnimgrefresh
        '
        Me.btnimgrefresh.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgrefresh.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrefresh.Image = CType(resources.GetObject("btnimgrefresh.Image"), System.Drawing.Image)
        Me.btnimgrefresh.Location = New System.Drawing.Point(576, 492)
        Me.btnimgrefresh.Name = "btnimgrefresh"
        Me.btnimgrefresh.Size = New System.Drawing.Size(208, 30)
        Me.btnimgrefresh.TabIndex = 66
        Me.btnimgrefresh.Text = "Refresh"
        Me.btnimgrefresh.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrefresh.UseVisualStyleBackColor = True
        '
        'btnimgrename
        '
        Me.btnimgrename.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnimgrename.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimgrename.Image = CType(resources.GetObject("btnimgrename.Image"), System.Drawing.Image)
        Me.btnimgrename.Location = New System.Drawing.Point(683, 276)
        Me.btnimgrename.Name = "btnimgrename"
        Me.btnimgrename.Size = New System.Drawing.Size(101, 30)
        Me.btnimgrename.TabIndex = 59
        Me.btnimgrename.Text = "Rename"
        Me.btnimgrename.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnimgrename.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnimgrename.UseVisualStyleBackColor = True
        '
        'lbldriverbig
        '
        Me.lbldriverbig.BackColor = System.Drawing.Color.White
        Me.lbldriverbig.Font = New System.Drawing.Font("Arial", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldriverbig.Location = New System.Drawing.Point(3, 6)
        Me.lbldriverbig.Name = "lbldriverbig"
        Me.lbldriverbig.Size = New System.Drawing.Size(857, 66)
        Me.lbldriverbig.TabIndex = 2
        Me.lbldriverbig.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(25, 241)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(123, 15)
        Me.Label7.TabIndex = 71
        Me.Label7.Text = "Assigned Truck Type:"
        '
        'cmbtype
        '
        Me.cmbtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbtype.FormattingEnabled = True
        Me.cmbtype.Location = New System.Drawing.Point(143, 236)
        Me.cmbtype.Name = "cmbtype"
        Me.cmbtype.Size = New System.Drawing.Size(200, 23)
        Me.cmbtype.TabIndex = 72
        '
        'newdriver
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1334, 671)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.Panel2)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "newdriver"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Driver"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.grddriver, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.tab1.ResumeLayout(False)
        Me.tab1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.imgphoto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.tab2.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.num, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grddoc, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab4.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.imgbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents cmbcompsch As System.Windows.Forms.ComboBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbwhsesch As System.Windows.Forms.ComboBox
    Friend WithEvents chkdeac As System.Windows.Forms.CheckBox
    Friend WithEvents btnrefresh As System.Windows.Forms.Button
    Friend WithEvents btncancelfilter As System.Windows.Forms.Button
    Friend WithEvents txtsearch As System.Windows.Forms.TextBox
    Friend WithEvents btnok As System.Windows.Forms.Button
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents grddriver As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lbldriverbig As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tab1 As System.Windows.Forms.TabPage
    Friend WithEvents btncancelupdate As System.Windows.Forms.Button
    Friend WithEvents lbldreason As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents listbox As System.Windows.Forms.ListBox
    Friend WithEvents btnupdriver As System.Windows.Forms.Button
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtrems As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents tab2 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents lblexp As System.Windows.Forms.Label
    Friend WithEvents chkuse As System.Windows.Forms.CheckBox
    Friend WithEvents btnremovedoc As System.Windows.Forms.Button
    Friend WithEvents lbldocid As System.Windows.Forms.Label
    Friend WithEvents cmbinterval As System.Windows.Forms.ComboBox
    Friend WithEvents num As System.Windows.Forms.NumericUpDown
    Friend WithEvents dateexpired As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents btnadddoc As System.Windows.Forms.Button
    Friend WithEvents cmbdocname As System.Windows.Forms.ComboBox
    Friend WithEvents btnattach As System.Windows.Forms.Button
    Friend WithEvents datelastrenew As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtattachname As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents grddoc As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewLinkColumn
    Friend WithEvents btncanceldoc As System.Windows.Forms.Button
    Friend WithEvents btnviewalldoc As System.Windows.Forms.Button
    Friend WithEvents btnupdatedoc As System.Windows.Forms.Button
    Friend WithEvents tab4 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents btnimgdl As System.Windows.Forms.Button
    Friend WithEvents lblimgid As System.Windows.Forms.Label
    Friend WithEvents btnimgset As System.Windows.Forms.Button
    Friend WithEvents btnimgfull As System.Windows.Forms.Button
    Friend WithEvents btnimgupdate As System.Windows.Forms.Button
    Friend WithEvents txtimg As System.Windows.Forms.TextBox
    Friend WithEvents imgpanel As System.Windows.Forms.Panel
    Friend WithEvents imgbox As System.Windows.Forms.PictureBox
    Friend WithEvents btnimgremove As System.Windows.Forms.Button
    Friend WithEvents btnimgadd As System.Windows.Forms.Button
    Friend WithEvents btnimgcancel As System.Windows.Forms.Button
    Friend WithEvents btnimgrefresh As System.Windows.Forms.Button
    Friend WithEvents btnimgrename As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblid As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtdriver As System.Windows.Forms.TextBox
    Friend WithEvents datebirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtcontact As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtlicense As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents cmbcompany As System.Windows.Forms.ComboBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents cmbwhse As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents imgphoto As System.Windows.Forms.PictureBox
    Friend WithEvents lbllastsearch As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents lblselect As System.Windows.Forms.Label
    Friend WithEvents btncanceladd As System.Windows.Forms.Button
    Friend WithEvents btnvadd As System.Windows.Forms.Button
    Friend WithEvents btnvdeac As System.Windows.Forms.Button
    Friend WithEvents lblprimary As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnimport As System.Windows.Forms.Button
    Friend WithEvents cmbtype As ComboBox
    Friend WithEvents Label7 As Label
End Class
