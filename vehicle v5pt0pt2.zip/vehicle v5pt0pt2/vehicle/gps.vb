﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Net
Imports System.Net.WebClient
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Module gps
    Dim lines = System.IO.File.ReadAllLines(login.connectline)
    Dim strconn As String = lines(0)
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim sql As String
    Dim JsonHash As String = "", JsonTracker As String = "", hashstring As String = "", trackerIDstring As String = ""

    Private Sub connect()
        conn = New SqlConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    'Private Sub get_account()
    '    Try
    '        Dim account As String = "", password As String = ""
    '        sql = "Select account, password From tblgpsaccount Where status ='1'"
    '        connect()
    '        cmd = New SqlCommand(sql, conn)
    '        dr = cmd.ExecuteReader
    '        If dr.Read Then
    '            account = dr("account")
    '            password = dr("password")
    '        End If
    '        dr.Dispose()
    '        cmd.Dispose()
    '        conn.Close()

    '        If account <> "" Then
    '            get_Hash(account, users.Decrypt(password))
    '        End If

    '    Catch ex As Exception
    '        MsgBox(ex.message & vbcrlf & vbcrlf & ex.stacktrace)
    '    End Try
    'End Sub

    Public Function get_Hash(ByVal account As String, ByVal password As String) As String
        Try
            hashstring = ""
            Dim api_query As String = "https://api.mgps.online/user/auth/?login=" & account & "&password=" & password
            Dim request As WebRequest = WebRequest.Create(api_query)
            request.Credentials = CredentialCache.DefaultCredentials
            Dim response As WebResponse = request.GetResponse()
            'TextBox1.Text = ((CType(response, HttpWebResponse)).StatusDescription) 'OK

            Using dataStream As Stream = response.GetResponseStream()
                Dim reader As StreamReader = New StreamReader(dataStream)
                Dim responseFromServer As String = reader.ReadToEnd()
                'If responseFromServer.Contains(currentversion) Then

                'End If
                JsonHash = (responseFromServer)
            End Using

            response.Close()

            hashstring = Deserializations_Hash(JsonHash)
            Return hashstring
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Function

    Private Function Deserializations_Hash(ByVal json As String) As String
        Try
            ' JsonConvert.DeserializeObject(Of List(Of Receiver))(json)
            ' JsonConvert.DeserializeObject(Of Dictionary(Of String, Receiver))(json)
            ' JsonConvert.DeserializeObject(Of gps_hash)(json)
            'Dim jsonResult = JsonConvert.DeserializeObject(json).ToString()
            Dim ss As String = ""
            Dim parsedObject = JsonConvert.DeserializeObject(Of gps_hash)(json)
            If parsedObject.success = True Then
                ss = parsedObject.hash
            End If

            Return ss
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Function

    Public Function get_tracker(ByVal platenum As String)
        Try
            Dim api_query As String = "https://api.mgps.online/tracker/list?hash=" & hashstring
            Dim request As WebRequest = WebRequest.Create(api_query)
            request.Credentials = CredentialCache.DefaultCredentials
            Dim response As WebResponse = request.GetResponse()
            'Dim okie As String = ((CType(response, HttpWebResponse)).StatusDescription) 'OK


            Using dataStream As Stream = response.GetResponseStream()
                Dim reader As StreamReader = New StreamReader(dataStream)
                Dim responseFromServer As String = reader.ReadToEnd()
                'If responseFromServer.Contains(currentversion) Then

                'End If
                JsonTracker = (responseFromServer)
            End Using

            response.Close()

            trackerIDstring = Deserializations_tracker(JsonTracker, platenum)

            Return trackerIDstring

        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Function

    Private Function Deserializations_tracker(ByVal json As String, ByVal platenum As String) As String
        Try
            Dim tracker_id As String = "", tracker_label As String = ""
            ' JsonConvert.DeserializeObject(Of List(Of Receiver))(json)
            ' JsonConvert.DeserializeObject(Of Dictionary(Of String, Receiver))(json)
            ' JsonConvert.DeserializeObject(Of gps_hash)(json)
            'Dim jsonResult = JsonConvert.DeserializeObject(json).ToString()
            Dim parsedObject = JsonConvert.DeserializeObject(Of gps_tracker)(json)
            If parsedObject.success = True Then
                For Each num In parsedObject.list
                    If num.label.ToString.Contains(platenum) = True Then
                        tracker_id = num.id
                        tracker_label = num.label
                        Exit For
                    End If
                Next
            End If

            Return tracker_id
            'Return tracker_label
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try
    End Function
End Module
