﻿Public Class gps_hash
    Public Property success As Boolean
    Public Property hash As String
End Class
