﻿Public Class Form1
    Dim dirpath As String = My.Application.Info.DirectoryPath
    Dim wclient As New System.Net.WebClient
    Dim tool As String = dirpath + "\AutoUpdateMain.exe"

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
    End Sub

    Public Sub getupdate()
        If System.IO.File.Exists(tool) Then
            System.IO.File.Delete(tool)
            wclient.DownloadFileAsync(New Uri("https://www.dropbox.com/s/lbs2m6hminhl3bh/AutoUpdateMain.exe?dl=1"), dirpath + "\AutoUpdateMain.exe")
            Timer1.Start()
        Else
            wclient.DownloadFileAsync(New Uri("https://www.dropbox.com/s/lbs2m6hminhl3bh/AutoUpdateMain.exe?dl=1"), dirpath + "\AutoUpdateMain.exe")
            Timer1.Start()
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Process.Start(dirpath + "\AutoUpdateMain.exe")
        Application.Exit()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        For Each proc As Process In Process.GetProcesses
            If proc.ProcessName = "AutoUpdateMain" Then
                proc.Kill()
                getupdate()
            Else
                getupdate()
            End If
        Next
    End Sub
End Class
