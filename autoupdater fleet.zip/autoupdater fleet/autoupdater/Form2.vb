﻿Imports System.IO
Imports System.Data.SqlClient
Imports ICSharpCode.SharpZipLib.Zip

Public Class Form2
    Dim lines = System.IO.File.ReadAllLines("connectionstring.txt")
    Dim strconn As String = lines(0)
    Dim sql As String
    Dim conn As SqlConnection
    Dim dr As SqlDataReader
    Dim cmd As SqlCommand

    Dim logpath As String = My.Application.Info.DirectoryPath.ToString
    Dim file As String = logpath + "\Updated.zip"

    Public Sub connect()
        conn = New SqlConnection 'New OleDb.OleDbConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Open()
        End If
    End Sub

    Public Sub disconnect()
        conn = New SqlConnection 'New OleDb.OleDbConnection
        conn.ConnectionString = strconn
        If conn.State <> ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub WriteWordDoc(ByVal filename As String, ByVal data As Byte())
        Dim fs As New System.IO.FileStream(filename, IO.FileMode.Create)
        Dim bw As New System.IO.BinaryWriter(fs)
        bw.Write(data)
        bw.Close()
        fs.Close()
    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        real()
    End Sub

    Private Sub real()
        For Each p As Process In Process.GetProcesses
            If p.ProcessName = "vehicle" Then 'If you don't know what your program's process name is, simply run your program, run windows task manager, select 'processes' tab, scroll down untill you find your programs name.
                p.Kill()
            End If
        Next
        '/IO.File.Delete(logpath & "\vehicle.exe")
        downloadapp()
    End Sub

    Private Sub downloadapp()
        Try
            sql = "SELECT Top 1 appfile FROM tblversion where appfile is not null and status='1' order by systemid DESC"
            connect()
            cmd = New SqlCommand(sql, conn)
            Dim rdr As SqlDataReader = cmd.ExecuteReader
            If rdr.Read Then
                WriteWordDoc(file, rdr("appfile"))
            Else
                MsgBox(file & " not found")
                Exit Sub
            End If
            rdr.Close()
            conn.Close()

            Threading.Thread.Sleep(2000) 'freeze thread for 5 seconds...

            ExtractArchive(file, logpath)
            movefiles()

            Timer1.Start()

        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Information, "")
        End Try
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Process.Start(logpath + "\vehicle.exe")
        Application.Exit()
    End Sub

    Public Sub ExtractArchive(ByVal zipFilename As String, ByVal ExtractDir As String)
        Dim Redo As Integer = 1
        Dim MyZipInputStream As ZipInputStream
        Dim MyFileStream As FileStream
        MyZipInputStream = New ZipInputStream(New FileStream(zipFilename, FileMode.Open, FileAccess.Read))
        Dim MyZipEntry As ZipEntry = MyZipInputStream.GetNextEntry
        Directory.CreateDirectory(ExtractDir)
        While Not MyZipEntry Is Nothing
            If (MyZipEntry.IsDirectory) Then
                Directory.CreateDirectory(ExtractDir & "\" & MyZipEntry.Name)
            Else
                If Not Directory.Exists(ExtractDir & "\" & Path.GetDirectoryName(MyZipEntry.Name)) Then
                    Directory.CreateDirectory(ExtractDir & "\" & Path.GetDirectoryName(MyZipEntry.Name))
                End If
                MyFileStream = New FileStream(ExtractDir & "\" & MyZipEntry.Name, FileMode.OpenOrCreate, FileAccess.Write)
                Dim count As Integer
                Dim buffer(4096) As Byte
                count = MyZipInputStream.Read(buffer, 0, 4096)
                While count > 0
                    MyFileStream.Write(buffer, 0, count)
                    count = MyZipInputStream.Read(buffer, 0, 4096)
                End While
                MyFileStream.Close()
            End If
            Try
                MyZipEntry = MyZipInputStream.GetNextEntry
            Catch ex As Exception
                MyZipEntry = Nothing
            End Try
        End While
        If Not (MyZipInputStream Is Nothing) Then
            MyZipInputStream.Close()
        End If
        If Not (MyFileStream Is Nothing) Then
            MyFileStream.Close()
        End If
    End Sub

    Private Sub movefiles()
        Try
            Dim sourcePath As String = logpath + "\Updated"
            Dim destination As String = logpath
            If (Directory.Exists(sourcePath)) Then
                For Each fName As String In Directory.GetFiles(sourcePath)
                    If System.IO.File.Exists(fName) Then
                        Dim dFile As String = String.Empty

                        dFile = Path.GetFileName(fName)
                        Dim dFilePath As String = String.Empty

                        dFilePath = destination & "\" & dFile

                        If Not (System.IO.File.Exists(dFilePath)) Then
                            System.IO.File.Move(fName, dFilePath)
                        Else
                            Microsoft.VisualBasic.FileIO.FileSystem.MoveFile(fName, dFilePath, True)
                        End If
                    End If
                Next
                System.IO.Directory.Delete(sourcePath) 'folder
                System.IO.File.Delete(logpath + "\Updated.zip") 'file
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class