﻿Imports System.Collections.Generic
Public Class M_MSInspect
    Public Property mid As Integer
    'Public Property [event] As String
    Public Property platenum As String
    Public Property vtype As String
    Public Property tcondition As Integer
    Public Property chknum As String
    Public Property ArrivedAt As String
    Public Property ArrivedTime As String
    Public Property AssignedAt As String
End Class

Public Class MSCheckup
    Public Property tripnum As String
    Public Property tcondition As Integer
    Public Property chknum As String
End Class

Public Class CreateForInspection
    Inherits MSCheckup

End Class

Public Class ReadMCForInspect
    Inherits M_MSInspect

    Public Sub New(ByVal row As DataRow)
        mid = Convert.ToInt32(row("mid"))
        platenum = row("platenum").ToString()
        vtype = row("vtype").ToString()
        tcondition = Convert.ToInt32(row("tcondition"))
        chknum = row("chknum").ToString()
        ArrivedAt = row("ArrivedAt").ToString()
        ArrivedTime = row("ArrivedTime").ToString()
        AssignedAt = row("AssignedAt").ToString()
    End Sub

    Public Property mid As Integer
    Public Property platenum As String
    Public Property vtype As String
    Public Property tcondition As Integer
    Public Property chknum As String
    Public Property ArrivedAt As String
    Public Property ArrivedTime As String
    Public Property AssignedAt As String
End Class
