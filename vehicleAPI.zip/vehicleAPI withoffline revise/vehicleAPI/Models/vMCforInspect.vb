﻿Public Class vMCforInspect
    Public Property mid As Integer
    Public Property platenum As String
    Public Property vtype As String
    Public Property tcondition As String
    Public Property chknum As String
    Public Property tripnum As String
    Public Property ArrivedAt As String
    Public Property ArrivedTime As String
    Public Property AssignedAt As String
End Class

Public Class Readall
    Inherits vMCforInspect

    Public Sub New(ByVal row As DataRow)
        mid = Convert.ToInt32(row("mid"))
        platenum = row("platenum").ToString()
        vtype = row("vtype").ToString()
        tcondition = Convert.ToInt32(row("tcondition"))
        chknum = row("chknum").ToString()
        tripnum = row("tripnum").ToString()
        ArrivedAt = row("ArrivedAt").ToString()
        ArrivedTime = row("ArrivedTime").ToString()
        AssignedAt = row("AssignedAt").ToString()
    End Sub
End Class
