﻿Public Class M_notArrived
    Public Property platenum As String
    Public Property vtype As String
    Public Property driver As String
    Public Property tripnum As String
    Public Property tripstat As String
    Public Property whsename As String
End Class

Public Class ReadallnotArrived
    Inherits M_notArrived

    Public Sub New(ByVal row As DataRow)
        platenum = row("platenum").ToString()
        vtype = row("vtype").ToString()
        driver = row("driver").ToString()
        tripnum = row("tripnum").ToString()
        tripstat = row("tripstat").ToString()
        whsename = row("whsename").ToString()
    End Sub
End Class
