﻿Public Class getForUpload
    'Public Property ArrayOftblCheckList As ArrayOftblCheckList
    'Public Property tblCheckList As TblCheckList

    'Public Class ArrayOftblCheckList
    Public Property tblCheckListx As List(Of TblCheckList)
    'End Class

    Public Class TblCheckList
        Public Property whse_branch As String
        Public Property mid As String
        Public Property platenumber As String
        Public Property vehicle_type As String
        Public Property driver As String
        Public Property c_date As Date
        Public Property c_start As String
        Public Property c_finish As String
        Public Property tvirnum As String
        Public Property attachment As Byte()
        Public Property mechanic As String
        Public Property status As String
        Public Property second_Stat As Nullable(Of Integer)
        Public Property uploaddate As String
        Public Property remarks As String
        Public Property id As Integer
        Public Property additional As String
        Public Property check_item As String
        Public Property checklist_status As String
        Public Property jo_number As String
        Public Property pass_number As String
    End Class
End Class

Public Class ReadallforUploadx
    Inherits getForUpload

    Public Sub New(ByVal row As DataRow)
        'attachment = row("attachment")

        whse_branch = row("whse_branch").ToString()
        c_date = row("c_date")
        c_start = row("c_start").ToString()
        c_finish = row("c_finish").ToString()
        mid = Convert.ToInt32(row("mid"))
        platenumber = row("platenumber").ToString()
        vehicle_type = row("vehicle_type").ToString()
        driver = row("driver").ToString()
        tvirnum = row("tvirnum").ToString()
        mechanic = row("mechanic").ToString()
        status = row("status").ToString()
        second_Stat = row("second_Stat").ToString()
        remarks = row("remarks").ToString()
        uploaddate = row("uploaddate").ToString()
    End Sub

    Public Property whse_branch As String
    Public Property mid As String
    Public Property platenumber As String
    Public Property vehicle_type As String
    Public Property driver As String
    Public Property c_date As Date
    Public Property c_start As String
    Public Property c_finish As String
    Public Property tvirnum As String
    Public Property attachment As Byte()
    Public Property mechanic As String
    Public Property status As String
    Public Property second_Stat As String
    Public Property uploaddate As String
    Public Property remarks As String
    Public Property id As Integer
    Public Property additional As String
    Public Property check_item As String
    Public Property checklist_status As String
    Public Property jo_number As String
    Public Property pass_number As String
End Class
