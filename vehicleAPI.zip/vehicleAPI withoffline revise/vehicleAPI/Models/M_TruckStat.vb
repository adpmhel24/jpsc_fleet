﻿Public Class M_TruckStat
    Public Property platenum As String
    Public Property vtype As String
    Public Property AssignedAt As String
    Public Property tripnum As String
    Public Property tripStat As String
    Public Property ArrivedAt As String
    Public Property ArrivedTime As String
    Public Property mid As String
    Public Property inspectStat As String
    Public Property chknum As String
End Class

Public Class ReadallInspectStat
    Inherits M_TruckStat

    Public Sub New(ByVal row As DataRow)
        platenum = row("platenum").ToString()
        vtype = row("vtype").ToString()
        AssignedAt = row("AssignedAt").ToString()
        tripnum = row("tripnum").ToString()
        tripStat = row("tripStat").ToString()
        ArrivedAt = row("ArrivedAt").ToString()
        ArrivedTime = row("ArrivedTime").ToString()
        mid = row("mid").ToString()
        inspectStat = row("inspectStat").ToString()
        chknum = row("chknum").ToString()
    End Sub
End Class
