﻿Public Class M_AvailableTrucks
    Public Property platenum As String
    Public Property vtype As String
    Public Property tripnum As String
    Public Property mid As Integer
    Public Property tcondition As Integer
    Public Property chknum As String
    Public Property ArrivedAt As String
    Public Property AssignedAt As String
End Class

Public Class ReadallAvailable
    Inherits M_AvailableTrucks

    Public Sub New(ByVal row As DataRow)
        platenum = row("platenum").ToString()
        vtype = row("vtype").ToString()
        tripnum = row("tripnum").ToString()
        mid = Convert.ToInt32(row("mid"))
        tcondition = Convert.ToInt32(row("tcondition"))
        chknum = row("chknum").ToString()
        ArrivedAt = row("ArrivedAt").ToString()
        AssignedAt = row("AssignedAt").ToString()
    End Sub
End Class
