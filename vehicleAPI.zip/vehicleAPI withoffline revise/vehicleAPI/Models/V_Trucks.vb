﻿Public Class V_Trucks
    Public Property platenum As String
    Public Property vtype As String
    Public Property whsename As String
End Class
