﻿Imports System.Net
Imports System.Web.Http
Imports System.Data.SqlClient
Imports System.IO
Imports vehicledataaccess
Imports System.Configuration

Public Class TripController
    Inherits ApiController

    Private conn As SqlConnection
    Private adapter As SqlDataAdapter

    Public Function Get_notArrived(ByVal Arrived As String) As IHttpActionResult
        Dim arr As String = ""
        If Arrived.ToLower <> "false" Then
            arr = " where whsename is null"
        End If

        conn = New SqlConnection
        conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("conn_vehicledb").ToString
        Dim dt As DataTable = New DataTable
        Dim sql As String = "Select * from vMCnotArrived" & arr
        adapter = New SqlDataAdapter(sql, conn)
        adapter.Fill(dt)

        Dim allavail As List(Of M_notArrived) = New List(Of M_notArrived)(dt.Rows.Count)

        If (dt.Rows.Count > 0) Then
            For Each row As DataRow In dt.Rows
                allavail.Add(New ReadallnotArrived(row))
            Next
        End If

        Return Ok(allavail)
    End Function
End Class
