﻿Imports System.Net
Imports System.Web.Http
Imports System.Data.SqlClient
Imports System.IO
Imports vehicledataaccess
Imports System.Configuration

Public Class MSInspectionController
    Inherits ApiController

    Private conn As SqlConnection
    Private adapter As SqlDataAdapter

    ' GET api/<controller>
    Public Function get_forInspection(ByVal Arrivedat As String) As IHttpActionResult
        conn = New SqlConnection
        conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("conn_vehicledb").ToString
        Dim dt As DataTable = New DataTable
        Dim sql As String = "Select * from vMCforInspect where ArrivedAt='" & Arrivedat & "' and tcondition='0' order by platenum"
        adapter = New SqlDataAdapter(sql, conn)
        adapter.Fill(dt)

        Dim allavail As List(Of vMCforInspect) = New List(Of vMCforInspect)(dt.Rows.Count)

        If (dt.Rows.Count > 0) Then
            For Each row As DataRow In dt.Rows
                allavail.Add(New Readall(row))
            Next
        End If

        Return Ok(allavail)
    End Function

    Public Function get_middetails(ByVal mid As Integer) As IHttpActionResult
        conn = New SqlConnection
        conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("conn_vehicledb").ToString
        Dim dt As DataTable = New DataTable
        Dim sql As String = "Select * from vMC where mid='" & mid & "'"
        adapter = New SqlDataAdapter(sql, conn)
        adapter.Fill(dt)

        Dim allavail As List(Of vMCforInspect) = New List(Of vMCforInspect)(dt.Rows.Count)

        If (dt.Rows.Count > 0) Then
            For Each row As DataRow In dt.Rows
                allavail.Add(New Readall(row))
            Next
        End If

        Return Ok(allavail)
    End Function

    Public Function get_offlinechknum(ByVal chknum As String) As IHttpActionResult
        conn = New SqlConnection
        conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("conn_vehicledb").ToString
        Dim dt As DataTable = New DataTable
        Dim sql As String = "Select * from vMCforUpload where tvirnum='" & chknum & "' and uploaded='1'"
        adapter = New SqlDataAdapter(sql, conn)
        adapter.Fill(dt)

        Dim allavail As List(Of TblCheckList) = New List(Of TblCheckList)(dt.Rows.Count)

        If (dt.Rows.Count > 0) Then
            For Each row As DataRow In dt.Rows
                allavail.Add(New ReadallUploadedChecklist(row))
            Next
        End If

        Return Ok(allavail)
    End Function

    Public Function getdetails(ByVal uploaded As String) As IHttpActionResult
        Dim upl As Integer = -1
        If uploaded.ToLower = "false" Then
            upl = 0
        End If

        conn = New SqlConnection
        conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("conn_vehicledb").ToString
        Dim dt As DataTable = New DataTable
        Dim sql As String = "Select * from vMCforUpload where uploaded='" & upl & "'"
        adapter = New SqlDataAdapter(sql, conn)
        adapter.Fill(dt)

        Dim allavail As List(Of TblCheckList) = New List(Of TblCheckList)(dt.Rows.Count)

        If (dt.Rows.Count > 0) Then
            For Each row As DataRow In dt.Rows
                allavail.Add(New ReadallforUpload(row))
            Next
        End If

        Return Ok(allavail)
    End Function

    Public Function getLastStatus(ByVal platenum As String) As IHttpActionResult
        conn = New SqlConnection
        conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("conn_vehicledb").ToString
        Dim dt As DataTable = New DataTable
        Dim sql As String = "Select * from vMCTruckStat where platenum='" & platenum & "'"
        adapter = New SqlDataAdapter(sql, conn)
        adapter.Fill(dt)

        Dim allavail As List(Of M_TruckStat) = New List(Of M_TruckStat)(dt.Rows.Count)

        If (dt.Rows.Count > 0) Then
            For Each row As DataRow In dt.Rows
                allavail.Add(New ReadallInspectStat(row))
            Next
        End If

        Return Ok(allavail)
    End Function

    Public Function getAllInspectStat(ByVal inspectStat As String) As IHttpActionResult
        Dim upl As Integer = -1

        conn = New SqlConnection
        conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("conn_vehicledb").ToString
        Dim dt As DataTable = New DataTable
        Dim sql As String = "Select * from vMCTruckStat"
        If inspectStat.ToLower <> "all" Then
            If inspectStat.ToLower = "for inspection" Or inspectStat.ToLower = "in-progress" Or inspectStat.ToLower = "done - good condition" Or inspectStat.ToLower = "under repair" Or inspectStat.ToLower = "need manual checklist" Then
                sql = sql & " where inspectStat='" & inspectStat.ToLower & "'"
            Else
                sql = sql & " where platenum='" & upl & "'"
            End If
        End If
        adapter = New SqlDataAdapter(sql, conn)
        adapter.Fill(dt)

        Dim allavail As List(Of M_TruckStat) = New List(Of M_TruckStat)(dt.Rows.Count)

        If (dt.Rows.Count > 0) Then
            For Each row As DataRow In dt.Rows
                allavail.Add(New ReadallInspectStat(row))
            Next
        End If

        Return Ok(allavail)
    End Function

    ' POST api/<controller>
    Public Function PostValue(<FromBody()> ByVal value As CreateForInspection) As IHttpActionResult
        conn = New SqlConnection
        conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("conn_vehicledb").ToString
        Dim sql As String = "Insert into tblmscheckup (tripnum,tcondition) values (@tripnum,@tcondition)"
        Dim insertcommand As SqlCommand = New SqlCommand(sql, conn)
        insertcommand.Parameters.AddWithValue("@tripnum", value.tripnum)
        insertcommand.Parameters.AddWithValue("@tcondition", value.tcondition)
        conn.Open()

        Dim Result As Integer = insertcommand.ExecuteNonQuery()
        If Result > 0 Then
            Return Ok()
        End If
    End Function

    ' PUT api/<controller>/5

    Public Function PutValue(ByVal mid As Integer, <FromBody()> ByVal mscheckup As tblmscheckup)
        Using entities As New vehicledbEntities
            Dim entity = entities.tblmscheckups.FirstOrDefault(Function(e) e.mid = mid)
            entity.tcondition = mscheckup.tcondition
            entity.chknum = mscheckup.chknum

            entities.SaveChanges()
            'maam mamaya ko ituloy sige po
        End Using
    End Function

    ' DELETE api/<controller>/5
    Public Sub DeleteValue(ByVal id As Integer)

    End Sub
End Class
