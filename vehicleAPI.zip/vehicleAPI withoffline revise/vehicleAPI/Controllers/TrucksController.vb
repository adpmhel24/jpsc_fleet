﻿Imports System.Net
Imports System.Web.Http
Imports System.Data.SqlClient
Imports System.IO
Imports vehicledataaccess
Imports System.Configuration

Public Class TrucksController
    Inherits ApiController

    Private conn As SqlConnection
    Private adapter As SqlDataAdapter

    Public Function get_list() As IHttpActionResult
        Dim comp As String = "J. Poon & Sons", mname As String = "Truck", stat As Integer = 1
        Dim vde As vehicledbEntities = New vehicledbEntities()
        Dim general As List(Of tblgeneral) = vde.tblgenerals.Where(Function(e) e.company = comp And e.makename = mname And e.status = stat).ToList()
        Dim qry = From g In general
                  Select New V_Trucks With {
                            .platenum = g.platenum,
                            .vtype = g.vtype,
                            .whsename = g.whsename
                          }
        Return Ok(qry)
    End Function

    Public Function get_platenumdetails(ByVal platenum As String) As IHttpActionResult
        Dim comp As String = "J. Poon & Sons", mname As String = "Truck", stat As Integer = 1
        Dim vde As vehicledbEntities = New vehicledbEntities()
        Dim general As List(Of tblgeneral) = vde.tblgenerals.Where(Function(e) e.company = comp And e.makename = mname And e.status = stat And e.platenum = platenum).ToList()
        Dim qry = From g In general
                  Select New V_Trucks With {
                            .platenum = g.platenum,
                            .vtype = g.vtype,
                            .whsename = g.whsename
                          }
        Return Ok(qry)
    End Function

    Public Function Get_AvailableTrucks(ByVal ArrivedAt As String) As IHttpActionResult
        conn = New SqlConnection
        conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("conn_vehicledb").ToString
        Dim dt As DataTable = New DataTable
        Dim sql As String = "Select * from vMCAvailable where ArrivedAt='" & ArrivedAt & "'"
        adapter = New SqlDataAdapter(sql, conn)
        adapter.Fill(dt)

        Dim allavail As List(Of M_AvailableTrucks) = New List(Of M_AvailableTrucks)(dt.Rows.Count)

        If (dt.Rows.Count > 0) Then
            For Each row As DataRow In dt.Rows
                allavail.Add(New ReadallAvailable(row))
            Next
        End If

        Return Ok(allavail)
    End Function
End Class
